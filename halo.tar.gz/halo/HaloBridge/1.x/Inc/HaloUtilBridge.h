#ifndef _HALOUTIL_BRIDGE_H
#define _HALOUTIL_BRIDGE_H

namespace Bridge
{
	class HaloUtilBridge : public ScriptInstanceBridge
	{
	public:
		HaloUtilBridge(IUtility* utility) : ScriptInstanceBridge(utility) {}

		virtual inline const char* getScriptClassName() const {return "HALOUtil";}
		virtual void mapScriptInterface(ScriptContext& context);

	private:
		static ScriptObject extractForegroundColor(IUtility* self, const ScriptArray& args);
		static ScriptObject extractIconColor(IUtility* self, const ScriptArray& args);
		static ScriptObject getCurrentResolution(IUtility* self, const ScriptArray& args);
		static ScriptObject asyncRelease(IUtility* self, const ScriptArray& args);
		static ScriptObject setOrientation(IUtility* self, const ScriptArray& args);
		static ScriptObject getOrientation(IUtility* self, const ScriptArray& args);
		static ScriptObject applyOrientation(IUtility* self, const ScriptArray& args);
		static ScriptObject isCursorVisible(IUtility* self, const ScriptArray& args);

		DEFINE_KEY_MAP_FUNCS(IUtility, CC_BLACK);
		DEFINE_KEY_MAP_FUNCS(IUtility, CC_WHITE);
		DEFINE_KEY_MAP_FUNCS(IUtility, RESOLUTION_1080);
		DEFINE_KEY_MAP_FUNCS(IUtility, RESOLUTION_720);
	};
}

#endif