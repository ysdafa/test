#ifndef _HALOUTIL_BRIDGE_H
#define _HALOUTIL_BRIDGE_H

namespace Bridge
{
	class HaloUtilBridge : public ScriptInstanceBridge
	{
	public:
		HaloUtilBridge(IUtility* utility) : ScriptInstanceBridge(utility) {}

		virtual inline const char* getScriptClassName() const {return "HALOUtil";}
		virtual void mapScriptInterface(ScriptContext& context);

	private:
		static ScriptObject extractForegroundColor(IUtility* self, const ScriptArray& args);
		static ScriptObject getCurrentResolution(IUtility* self, const ScriptArray& args);
		static ScriptObject asyncRelease(IUtility* self, const ScriptArray& args);

	};
}

#endif