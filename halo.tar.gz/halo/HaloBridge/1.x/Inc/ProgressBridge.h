#ifndef _PROGRESS_BRIDGE_H
#define _PROGRESS_BRIDGE_H

namespace Bridge
{
	using namespace HALO;

	class ProgressListenerBridge : public BaseListenerBridge
	{
	public:

	protected:
		virtual inline const char* getScriptClassName() const { return "ProgressListener"; }
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);

	private:
	};

	class InternalProgressListener : public IProgressListener
	{
	public:
		DEFINE_CALLBACK_FUNCTION(ValueChanged);
		
		virtual bool OnValueChanged(class IProgress* progress);
	};

	class ProgressBridge : public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "Progress"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

	private:
		static ScriptObject setProgressColor(CProgress* self, const ScriptArray& args);
		static ScriptObject setBackgroundColor(CProgress* self, const ScriptArray& args);
		static ScriptObject setThumbSize(CProgress* self, const ScriptArray& args);

		static ScriptObject addListener(CProgress* self, const ScriptArray& args);
		static ScriptObject removeListener(CProgress* self, const ScriptArray& args);

		static ScriptObject setProgressImage(CProgress* self, const ScriptArray& args);
		static ScriptObject setBackgroundImage(CProgress* self, const ScriptArray& args);
		static ScriptObject setValue(CProgress* self, const ScriptArray& args);
		static ScriptObject setMinMaxValue(CProgress* self, const ScriptArray& args);
		static ScriptObject setMinValue(CProgress* self, const ScriptArray& args);
		static ScriptObject setMaxValue(CProgress* self, const ScriptArray& args);
		static ScriptObject setReverse(CProgress* self, const ScriptArray& args);
	};
}

#endif