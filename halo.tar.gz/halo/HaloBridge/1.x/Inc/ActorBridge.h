#ifndef _ACTORBRIDGE_H
#define _ACTORBRIDGE_H

#define ARG_IS_VALID(object, string, type) ASSERT(true == object.has(string) && true == object.get(string).type())
#define ARG_HAS_STRING(object, string) ASSERT(true == object.has(string))

namespace Bridge
{
	class ActorListenerBridge : public BaseListenerBridge 
	{
	public:

	protected:
		virtual inline const char* getScriptClassName() const {return "FirstShownListener";}
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);

	private:
	};

	class InternalActorListener : public IActorListener, public BaseInternalListener
	{
	public:
		InternalActorListener(ActorListenerBridge *owner) : BaseInternalListener(owner) { }
		DEFINE_CALLBACK_FUNCTION(FirstFocusIn);

		//virtual bool OnFirstFocusIn(class IWidgetExtension* actor);
		
		DEFINE_FOCUS_EVENT_FUNCTION(FirstFocusIn);
	};

	class ActorBridge : public WidgetExBridge
	{
	public:
		template<typename NATIVE_TYPE>
		static ScriptObject wrapNativeObjectToJS(NATIVE_TYPE *object)
		{
			return wrapExistingNativeObject<NATIVE_TYPE>(object);
		}

		template<typename NATIVE_TYPE>
		static NATIVE_TYPE* unwrapObject(ScriptObject wrappedNativeObject)
		{
			return unwrapNativeObject<NATIVE_TYPE>(wrappedNativeObject);
		}

	protected:
		virtual inline const char* getScriptClassName() const {return "Actor";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

	private:

		// Methods
		static ScriptObject setParent(CActor* self, const ScriptArray& args);
		static ScriptObject setBackgroundColor(CActor* self, const ScriptArray& args);
		static ScriptObject setSize(CActor* self, const ScriptArray& args);
		static ScriptObject setPositon(CActor* self, const ScriptArray& args);
		static ScriptObject setLayout(CActor* self, const ScriptArray& args);
		static ScriptObject setOrientation(CActor* self, const ScriptArray& args);
		

		static ScriptObject show(CActor* self, const ScriptArray& args);
		static ScriptObject hide(CActor* self, const ScriptArray& args);

		static ScriptObject setClipArea(CActor* self, const ScriptArray& args);
		static ScriptObject removeClipArea(CActor* self, const ScriptArray& args);
		static ScriptObject setAlpha(CActor* self, const ScriptArray& args);
		static ScriptObject setPivotPoint(CActor* self, const ScriptArray& args);
		static ScriptObject setRotation(CActor* self, const ScriptArray& args);
		static ScriptObject setScale(CActor* self, const ScriptArray& args);
		static ScriptObject addChild(CActor* self, const ScriptArray& args);
		static ScriptObject numOfChildren(CActor* self, const ScriptArray& args);
		static ScriptObject destroyAllChildren(CActor* self, const ScriptArray& args);
		static ScriptObject raise(CActor* self, const ScriptArray& args);
		static ScriptObject lower(CActor* self, const ScriptArray& args);
		static ScriptObject enable(CActor* self, const ScriptArray& args);
		static ScriptObject enableFocus(CActor* self, const ScriptArray& args);
		static ScriptObject enablePointerFocus(CActor* self, const ScriptArray& args);
		static ScriptObject setFocus(CActor* self, const ScriptArray& args);
		static ScriptObject killFocus(CActor* self, const ScriptArray& args);
		static ScriptObject isFocused(CActor* self, const ScriptArray& args);
		static ScriptObject setTabWindow(CActor* self, const ScriptArray& args);
		static ScriptObject moveTab(CActor* self, const ScriptArray& args);
		
		
		static ScriptObject addMouseListener(CActor* self, const ScriptArray& args);
		static ScriptObject addKeyboardListener(CActor* self, const ScriptArray& args);
		static ScriptObject addClickListener(CActor* self, const ScriptArray& args);
		static ScriptObject addKeyLongPressListener(CActor* self, const ScriptArray& args);
		static ScriptObject addFocusListener(CActor* self, const ScriptArray& args);
		static ScriptObject addDragListener(CActor* self, const ScriptArray& args);
		static ScriptObject removeMouseListener(CActor* self, const ScriptArray& args);
		static ScriptObject removeKeyboardListener(CActor* self, const ScriptArray& args);
		static ScriptObject removeClickListener(CActor* self, const ScriptArray& args);
		static ScriptObject removeKeyLongPressListener(CActor* self, const ScriptArray& args);
		static ScriptObject removeFocusListener(CActor* self, const ScriptArray& args);
		static ScriptObject removeDragListener(CActor* self, const ScriptArray& args);
		static ScriptObject addCursorListener(CActor* self, const ScriptArray& args);
		static ScriptObject removeCursorListener(CActor* self, const ScriptArray& args);

		static ScriptObject addActorListener(CActor* self, const ScriptArray& args);		

		static ScriptObject addAction(CActor* self, const ScriptArray& args);
		static ScriptObject removeAction(CActor* self, const ScriptArray& args);

		static ScriptObject bindTransition(CActor* self, const ScriptArray& args);

		static ScriptObject m_getOrientation(CActor* self);
		static void m_setOrientation(CActor* self, ScriptObject value);

	};
}

#endif
