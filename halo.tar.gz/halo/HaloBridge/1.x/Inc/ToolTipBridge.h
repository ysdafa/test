#ifndef _TOOLTIP_BRIDGE_H
#define _TOOLTIP_BRIDGE_H

namespace Bridge
{
	class ToolTipBridge : public virtual ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "ToolTip"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

	private:
		// Methods
		static ScriptObject resize(CToolTip* self, const ScriptArray& args);
		static ScriptObject setPopupImage(CToolTip* self, const ScriptArray& args);
		static ScriptObject setTailImage(CToolTip* self, const ScriptArray& args);
		static ScriptObject setTailPosition(CToolTip* self, const ScriptArray& args);
		static ScriptObject setTailSize(CToolTip* self, const ScriptArray& args);
		static ScriptObject setTailOffset(CToolTip* self, const ScriptArray& args);
		static ScriptObject setText(CToolTip* self, const ScriptArray& args);
		static ScriptObject setFont(CToolTip* self, const ScriptArray& args);
		static ScriptObject setFontSize(CToolTip* self, const ScriptArray& args);
		static ScriptObject setTextColor(CToolTip* self, const ScriptArray& args);
		static ScriptObject setTextBackgroundColor(CToolTip* self, const ScriptArray& args);
		static ScriptObject setFrameWidth(CToolTip* self, const ScriptArray& args);
		static ScriptObject setFrameColor(CToolTip* self, const ScriptArray& args);
		static ScriptObject enableReserver(CToolTip* self, const ScriptArray& args);
		static ScriptObject setUpTailImage(CToolTip* self, const ScriptArray& args);
		static ScriptObject setDownTailImage(CToolTip* self, const ScriptArray& args);
		static ScriptObject setLeftTailImage(CToolTip* self, const ScriptArray& args);
		static ScriptObject setRightTailImage(CToolTip* self, const ScriptArray& args);
		static ScriptObject setShowTime(CToolTip* self, const ScriptArray& args);
	public:
		static CToolTip::EToolTipTailSide deserializeSide(std::string stateStr, CToolTip::EToolTipTailSide theDefault);
		static CToolTip::EToolTipTailPosition deserializePosition(std::string stateStr, CToolTip::EToolTipTailPosition theDefault);
	};
}

#endif