#ifndef _DEVICEMANAGER_BRIDGE_H
#define _DEVICEMANAGER_BRIDGE_H

namespace Bridge
{
	class DeviceManagerBridge : public ScriptInstanceBridge
	{
	public:
		DeviceManagerBridge(IDeviceManager* deviceManager) : ScriptInstanceBridge(deviceManager) {}

		virtual inline const char* getScriptClassName() const {return "DeviceManager";}
		virtual void mapScriptInterface(ScriptContext& context);

		static ScriptObject getDevice(IDeviceManager* self, const ScriptArray& args);
		static ScriptObject getGrabedActor(IDeviceManager* self, const ScriptArray& args);

		static ScriptObject enableDevice(IDeviceManager* self, const ScriptArray& args);
		static ScriptObject isDeviceEnabled(IDeviceManager* self, const ScriptArray& args);
	};
}

#endif