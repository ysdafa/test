#ifndef _STAGEBRIDGE_H
#define _STAGEBRIDGE_H

namespace Bridge
{
	class StageBridge : public ScriptInstanceBridge
	{
	public:
		StageBridge(IStage* stage) :ScriptInstanceBridge(stage) {}

		virtual void mapScriptInterface(ScriptContext& context);
		virtual const char* getScriptClassName() const { return "Stage"; }

		static ScriptObject enableFPSShown(IStage* self, const ScriptArray& args);
		static ScriptObject setFPSShownInterval(IStage* self, const ScriptArray& args);
		static ScriptObject setFPSLabelFont(IStage* self, const ScriptArray& args);

	};
}

#endif //_STAGEBRIDGE_H
