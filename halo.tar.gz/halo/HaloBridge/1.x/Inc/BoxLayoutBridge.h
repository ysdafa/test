#ifndef _BOXLAYOUTBRIDGE_H
#define _BOXLAYOUTBRIDGE_H

namespace Bridge
{
	class BoxLayoutBridge : public LayoutManagerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "BoxLayout"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual ILayout* constructWidget(const ScriptArray& args);

	private:
		static ScriptObject SetPackStartFlag(ILayout* self, const ScriptArray& args);
		static ScriptObject FlagPackStart(ILayout* self, const ScriptArray& args);
		static ScriptObject SetSpacing(ILayout* self, const ScriptArray& args);
		static ScriptObject Spacing(ILayout* self, const ScriptArray& args);
		static ScriptObject EnableHomogeneous(ILayout* self, const ScriptArray& args);
		static ScriptObject IsHomogeneousEnable(ILayout* self, const ScriptArray& args);
		static ScriptObject SetDirection(ILayout* self, const ScriptArray& args);
		static ScriptObject Direction(ILayout* self, const ScriptArray& args);
	};
}

#endif