#ifndef _LOADING_BRIDGE_H
#define _LOADING_BRIDGE_H

namespace Bridge
{
	using namespace HALO;
	class LoadingBridge : public ActorBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const { return "Loading"; }
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);
		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

	private:
		static ScriptObject m_SetTextColor(CLoading* self, const ScriptArray& args);		
		static ScriptObject m_Play(CLoading* self, const ScriptArray& args);
		static ScriptObject m_Pause(CLoading* self, const ScriptArray& args);
		static ScriptObject m_Stop(CLoading* self, const ScriptArray& args);
	};
}

#endif