#ifndef _GRIDLAYOUT_BRIDGE_H
#define _GRIDLAYOUT_BRIDGE_H

namespace Bridge
{
	class GridLayoutListListenerBridge : public BaseListenerBridge
	{
	public:

	protected:
		virtual inline const char* getScriptClassName() const {return "GridListControlListener";}
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);

	private:
	};

	class InternalGridListener : public IGridListControlListener
	{
	public:
		DEFINE_CALLBACK_FUNCTION(ItemLoaded);
		DEFINE_CALLBACK_FUNCTION(ItemUnloaded);
		DEFINE_CALLBACK_FUNCTION(AsyncItemLoad);
		DEFINE_CALLBACK_FUNCTION(FocusChanged);
		DEFINE_CALLBACK_FUNCTION(FocusChangeMotionStart);
		DEFINE_CALLBACK_FUNCTION(MoveOut);
		DEFINE_CALLBACK_FUNCTION(ItemIndexChanged);
		DEFINE_CALLBACK_FUNCTION(ItemClicked);
		DEFINE_CALLBACK_FUNCTION(EnterKeyLongPressed);

		virtual bool OnItemLoaded(class IGridListControl* list, int groupIndex, int itemIndex);
		virtual bool OnItemUnloaded(class IGridListControl* list, int groupIndex, int itemIndex);
		virtual bool OnAsyncItemLoad(class IGridListControl *list, int groupIndex, int itemIndex);
		virtual bool OnFocusChanged(class IGridListControl *list, int fromGroupIndex, int fromItemIndex, int toGroupIndex, int toItemIndex);
		virtual bool OnFocusChangeMotionStart(class IGridListControl* list, int fromGroupIndex, int fromItemIndex, int toGroupIndex, int toItemIndex);
		virtual bool OnMoveOut(class IGridListControl* list, EDirection direction, int fromGroupIndex, int fromItemIndex);
		virtual bool OnItemIndexChanged(class IGridListControl* list, int fromGroupIndex, int fromItemIndex, int toGroupIndex, int toItemIndex);
		virtual bool OnItemClicked(class IGridListControl* list, int groupIndex, int itemIndex);
		virtual bool OnEnterKeyLongPressed(class IGridListControl *list, int groupIndex, int itemIndex);
	protected:

	private:

	};

	class GridLayoutListBridge : public virtual DataListBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "GridListControl";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual CDataListControl* constructSubWidget(Widget* parent, float width, float height, const ScriptObject& argObject);

	private:
		// Methods
		static ScriptObject m_AddGroup(CGridListControl* self, const ScriptArray& args);
		static ScriptObject m_AddStyle(CGridListControl* self, const ScriptArray& args);
		static ScriptObject m_AddColumn(CGridListControl* self, const ScriptArray& args);
		static ScriptObject m_AddRowToColumn(CGridListControl* self, const ScriptArray& args);
		static ScriptObject m_AddRowToAllColumn(CGridListControl* self, const ScriptArray& args);
		static ScriptObject m_MergeCells(CGridListControl* self, const ScriptArray& args);
		static ScriptObject m_SetStyle(CGridListControl* self, const ScriptArray& args);
		static ScriptObject m_TransformStyle(CGridListControl* self, const ScriptArray& args);
		//static ScriptObject m_TransformAllGroupStyle(CGridListControl* self, const ScriptArray& args);
		static ScriptObject m_EnlargeFocusItem(CGridListControl* self, const ScriptArray& args);
		static ScriptObject m_SetFocusItemIndex(CGridListControl* self, const ScriptArray& args);
		static ScriptObject m_GetFocusItemIndex(CGridListControl* self, const ScriptArray& args);
		static ScriptObject m_SetAnimationDuration(CGridListControl* self, const ScriptArray& args);

		static ScriptObject m_AddDataGroup(CGridListControl* self, const ScriptArray& args);
		static ScriptObject m_AddData(CGridListControl* self, const ScriptArray& args);
		static ScriptObject m_GetData(CGridListControl* self, const ScriptArray& args);

		static ScriptObject m_InsertData(CGridListControl* self, const ScriptArray& args);
		static ScriptObject m_RemoveData(CGridListControl* self, const ScriptArray& args);


		static ScriptObject m_AttachGroupTitle(CGridListControl* self, const ScriptArray& args);

		static ScriptObject m_AddListListener(CGridListControl* self, const ScriptArray& args);

		static ScriptObject columnCount(CGridListControl* self, const ScriptArray& args);

		static ScriptObject updateItem(CGridListControl* self, const ScriptArray& args);

		static ScriptObject updateAllItems(CGridListControl* self, const ScriptArray& args);

		static ScriptObject clearDataSource(CGridListControl* self, const ScriptArray& args);

		static ScriptObject addRegularGrid(CGridListControl* self, const ScriptArray& args);

		static ScriptObject setBufferColumnSize(CGridListControl* self, const ScriptArray& args);

		static ScriptObject renderer(CGridListControl* self, const ScriptArray& args);

		static ScriptObject getOnScreenRange(CGridListControl* self, const ScriptArray& args);

		static ScriptObject itemCount(CGridListControl* self, const ScriptArray& args);

		static ScriptObject enableItem(CGridListControl* self, const ScriptArray& args);

		static ScriptObject isItemEnabled(CGridListControl* self, const ScriptArray& args);

		static ScriptObject m_IsThumbStyleOfItemEnable(CGridListControl* self, const ScriptArray& args);

		static ScriptObject m_GetThumbnailStyle(CGridListControl* self, const ScriptArray& args);

		static ScriptObject m_SetCheckToThumbnailOfGroup(CGridListControl* self, const ScriptArray& args);

		static ScriptObject m_SetCheckToThumbnailOfItem(CGridListControl* self, const ScriptArray& args);

		static ScriptObject m_EnableThumbnailStyleOfGroup(CGridListControl* self, const ScriptArray& args);

		static ScriptObject m_EnableThumbnailStyleOfItem(CGridListControl* self, const ScriptArray& args);

		static ScriptObject m_StartScrollPlayer(CGridListControl* self, const ScriptArray& args);

		static ScriptObject m_StopScrollPlayer(CGridListControl* self, const ScriptArray& args);
	};
}

#endif