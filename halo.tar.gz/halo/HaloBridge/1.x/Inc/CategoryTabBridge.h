#ifndef _CATEGORYTAB_BRIDGE_H
#define _CATEGORYTAB_BRIDGE_H

namespace Bridge
{

	class CategoryTabListenerBridge : public BaseListenerBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const { return "CategoryTabListener"; }
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);
	};

	class CategoryTabListener : public ICategoryTabListener
	{
	public:
		DEFINE_CALLBACK_FUNCTION(TabChanged);
		virtual bool OnTabChanged(class ICategoryTab* list, int index);
		DEFINE_CALLBACK_FUNCTION(TabClicked);
		virtual bool OnTabClicked(class ICategoryTab* tab, int index);
		DEFINE_CALLBACK_FUNCTION(TabMouseIn);
		virtual bool OnTabMouseIn(class ICategoryTab* tab, int index);
		DEFINE_CALLBACK_FUNCTION(TabMouseOut);
		virtual bool OnTabMouseOut(class ICategoryTab* tab, int index);
		DEFINE_CALLBACK_FUNCTION(LeftArrowsClicked);
		virtual bool OnLeftArrowsClicked(class ICategoryTab* tab);
		DEFINE_CALLBACK_FUNCTION(RightArrowsClicked);
		virtual bool OnRightArrowsClicked(class ICategoryTab* tab);
	protected:

	private:

	};

	class CategoryTabBridge : public virtual ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "CategoryTab"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

	private:
		// Methods
		static ScriptObject resize(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setMargin(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabSpacing(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabSpliterSize(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabSpliterImage(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabSpliterColor(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabFont(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabFontSize(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabText(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabTextColor(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabImage(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabColor(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setArrowsSize(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setArrowsImage(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setBackgroundImage(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setBackgroundColor(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject addTab(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject removeTab(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject currentTabIndex(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject currentTabText(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject tabText(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject changeTab(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject numberOfTab(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject addCategoryTabListener(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject removeCategoryTabListener(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject enableLooping(CCategoryTab* self, const ScriptArray& args);

		static ScriptObject setTabTextMargin(CCategoryTab* self, const ScriptArray& args); 		static ScriptObject getTabTextMargin(CCategoryTab* self, const ScriptArray& args);		static ScriptObject enableHighlightBar(CCategoryTab* self, const ScriptArray& args);		static ScriptObject setHighlightBarHeight(CCategoryTab* self, const ScriptArray& args);		static ScriptObject getHighlightBarHeight(CCategoryTab* self, const ScriptArray& args);		static ScriptObject setHighlightBarColor(CCategoryTab* self, const ScriptArray& args);		static ScriptObject setTabTextLimitWidth(CCategoryTab* self, const ScriptArray& args);		static ScriptObject getTabTextLimitWidth(CCategoryTab* self, const ScriptArray& args);		static ScriptObject enableAlignTabsCenter(CCategoryTab* self, const ScriptArray& args);		

		static ScriptObject setTabIconImage(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabIconSize(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabIconMargin(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject showTabIcon(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject hideTabIcon(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject isTabIconShow(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject enableChangeTab(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject showFocus(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject hideFocus(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject swapSubTab(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject hideTabCheckBox(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject showTabCheckBox(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject showTabLeftImage(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject showTabRightImage(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject hideTabLeftImage(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject hideTabRightImage(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabLeftImage(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabRightImage(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject enableDragSubTab(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject getTabCheckBoxSelectedIndexes(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabTargetHeight(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabChecked(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject isTabChecked(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject enableAutoShowImage(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject getTabWidth(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject getTabHeight(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject getTabX(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject getTabY(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabScrollAttribute(CCategoryTab* self, const ScriptArray& args);
		
	public:
		static CCategoryTab::ECategoryTabState deserializeState(std::string stateStr, CCategoryTab::ECategoryTabState theDefault);
		static ClutterTimelineDirection deserializeTextScrollDirection(std::string directionStr, ClutterTimelineDirection theDefault);
		static ClutterTextScrollType deserializeTextScrollType(std::string typeStr, ClutterTextScrollType theDefault);
	};
}

#endif