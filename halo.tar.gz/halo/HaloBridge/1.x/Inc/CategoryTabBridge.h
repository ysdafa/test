#ifndef _CATEGORYTAB_BRIDGE_H
#define _CATEGORYTAB_BRIDGE_H

namespace Bridge
{

	class CategoryTabListenerBridge : public BaseListenerBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const { return "CategoryTabListener"; }
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);
	};

	class CategoryTabChangedListener : public ICategoryTabChangedListener
	{
	public:
		DEFINE_CALLBACK_FUNCTION(TabChanged);
		virtual bool OnTabChanged(class ICategoryTab* list, int index);
	protected:

	private:

	};

	class CategoryTabBridge : public virtual ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "CategoryTab"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

	private:
		// Methods
		static ScriptObject resize(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setMargin(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabSpacing(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabSpliterSize(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabSpliterImage(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabSpliterColor(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabFont(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabFontSize(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabTextColor(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabImage(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setTabColor(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setArrowsSize(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setArrowsImage(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setBackgroundImage(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject setBackgroundColor(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject addTab(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject removeTab(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject currentTabIndex(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject currentTabText(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject tabText(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject changeTab(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject numberOfTab(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject addTabChangedListener(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject removeTabChangedListener(CCategoryTab* self, const ScriptArray& args);
		static ScriptObject enableLooping(CCategoryTab* self, const ScriptArray& args);

		static ScriptObject setTabTextMargin(CCategoryTab* self, const ScriptArray& args); 		static ScriptObject getTabTextMargin(CCategoryTab* self, const ScriptArray& args);		static ScriptObject enableHightlightBar(CCategoryTab* self, const ScriptArray& args);		static ScriptObject setHighlightBarHeight(CCategoryTab* self, const ScriptArray& args);		static ScriptObject getHighlightBarHeight(CCategoryTab* self, const ScriptArray& args);		static ScriptObject setHighlightBarColor(CCategoryTab* self, const ScriptArray& args);		static ScriptObject setTabTextLimitWidth(CCategoryTab* self, const ScriptArray& args);		static ScriptObject getTabTextLimitWidth(CCategoryTab* self, const ScriptArray& args);		static ScriptObject enableAlignTabsCenter(CCategoryTab* self, const ScriptArray& args);		

	public:
		static CCategoryTab::ECategoryTabState deserializeState(std::string stateStr, CCategoryTab::ECategoryTabState theDefault);
	};
}

#endif