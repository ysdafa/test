#ifndef _RADIOBUTTONGROUP_BRIDGE_H
#define _RADIOBUTTONGROUP_BRIDGE_H

namespace Bridge
{
	using namespace HALO;
	class RadioButtonGroupListenerBridge : public BaseListenerBridge
	{
	public:

	protected:
		virtual inline const char* getScriptClassName() const { return "RadioButtonGroupListener"; }
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);

	private:
	};

	class InternalRadioButtonGroupListener : public OnCheckedChangedListener
	{
	public:
		DEFINE_CALLBACK_FUNCTION(SelectedChanged);

		virtual bool OnCheckChanged(class ISelectButtonGroup* list , int index , bool ischecked ,ISelectButton* checkcontrol);
	};
	class RadioButtonGroupBridge : virtual public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "RadioButtonGroup"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget*  constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);
	private:
		
		static ScriptObject addButton(CRadioButtonGroup* self, const ScriptArray& args);

		static ScriptObject removeButton(CRadioButtonGroup* self, const ScriptArray& args);

		static ScriptObject getItemById(CRadioButtonGroup* self, const ScriptArray& args);

		static ScriptObject setDefaultFocus(CRadioButtonGroup* self, const ScriptArray& args);

		static ScriptObject numofItem(CRadioButtonGroup* self, const ScriptArray& args);

		static ScriptObject addlistener(CRadioButtonGroup* self, const ScriptArray& args);

		static ScriptObject setDefaultSelectedItem(CRadioButtonGroup* self, const ScriptArray& args);

		static ScriptObject getSelectedItemIndex(CRadioButtonGroup* self, const ScriptArray& args);

		static ScriptObject removeListener(CRadioButtonGroup* self, const ScriptArray& args);
	};
}

#endif