#ifndef _RICHTEXTBRIDGE_H
#define _RICHTEXTBRIDGE_H

#ifndef WIN32
#define HAVE_ECORE_IMF
#endif

namespace Bridge
{
	class RichTextBridge : public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "RichText";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual HALO::IActor* constructWidget(HALO::IActor* parent, float width, float height, const ScriptObject& argObject);
		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);
	private:
		static ScriptObject setText(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject text(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject setTextColor(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject setBackgroundColor(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject setCursorColor(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject setSelectionColor(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject setHighLightColor(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject enableMultline(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject setFont(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject setFontSize(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject insertText(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject deleteText(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject enableHighLightMove(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject moveHighLight(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject moveCursor(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject copy(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject cut(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject paste(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject setCharFormat(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject setParagraphFormat(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject setCursorBlinkInterval(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject setSelection(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject enableEditable(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject enableSelectable(HALO::CRichText* self, const ScriptArray& args);
#ifdef HAVE_ECORE_IMF		
		static ScriptObject GetIMEData(HALO::CRichText *self, const ScriptArray& args);

		static ScriptObject SetIMEData(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject EnableIMFOnFocus(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject ShowIMFContext(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject HideIMFContext(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject FocusInIMFContext(HALO::CRichText* self, const ScriptArray& args);

		static ScriptObject FocusOutIMFContext(HALO::CRichText* self, const ScriptArray& args);
#endif
	};
}

#endif
