#ifndef _ACTION_BRIDGE_H
#define _ACTION_BRIDGE_H

namespace Bridge
{
	class ActionBridge : public ScriptBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "Action";}
		
		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args)
		{
			return constructSubAction(args);
		}

		virtual IAction* constructSubAction(const ScriptArray& args) = 0;

		virtual inline void destroyFromScript(void* destroyedObject)
		{
		}

	public:
		virtual bool IsInterestEvent(IEvent* event);
		virtual bool Process(IEvent* inEvent, IEvent** outEvent);

	protected:
		ScriptFunction m_isInterestEventType;
		ScriptFunction m_onProcess;
		bool isInterestEventType;
		bool isOnProcess;

	};

	class ClickActionBridge : public ActionBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "ClickAction";}
		
		virtual void mapScriptInterface(ScriptContext& context);

		virtual IAction* constructSubAction(const ScriptArray& args);
	
	};

	class DragActionBridge : public ActionBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "DragAction";}
		
		virtual void mapScriptInterface(ScriptContext& context);

		virtual IAction* constructSubAction(const ScriptArray& args);

	private:
		static ScriptObject setDragAxis(IAction* self, const ScriptArray& args);
		static ScriptObject setDragArea(IAction* self, const ScriptArray& args);
		static ScriptObject getDragAxis(IAction* self, const ScriptArray& args);
		static ScriptObject getDragArea(IAction* self, const ScriptArray& args);
	};

	class GestureActionBridge : public ActionBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "GestureAction";}
		
		virtual void mapScriptInterface(ScriptContext& context);

		virtual IAction* constructSubAction(const ScriptArray& args);
	};

	class KeyLongPressActionBridge : public ActionBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "KeyLongPressAction";}
		
		virtual void mapScriptInterface(ScriptContext& context);

		virtual IAction* constructSubAction(const ScriptArray& args);
		
	private:
		static ScriptObject addKeyLongPressKey(IAction* self, const ScriptArray& args);
		static ScriptObject removeKeyLongPressKey(IAction* self, const ScriptArray& args);
	};

	class KeyCombinationActionBridge : public ActionBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "KeyCombinationAction";}
		
		virtual void mapScriptInterface(ScriptContext& context);

		virtual IAction* constructSubAction(const ScriptArray& args);
	};

}

#endif