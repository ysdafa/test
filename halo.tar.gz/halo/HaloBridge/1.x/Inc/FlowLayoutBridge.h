#ifndef _FLOWLAYOUTBRIDGE_H
#define _FLOWLAYOUTBRIDGE_H

namespace Bridge
{
	class FlowLayoutBridge : public LayoutManagerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "FlowLayout"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual ILayout* constructWidget(const ScriptArray& args);

	private:
		static ScriptObject EnableHomogeneous(ILayout* self, const ScriptArray& args);
		static ScriptObject IsHomogeneousEnabled(ILayout* self, const ScriptArray& args);
		static ScriptObject SetDirection(ILayout* self, const ScriptArray& args);
		static ScriptObject Direction(ILayout* self, const ScriptArray& args);
		static ScriptObject EnableSnapToGrid(ILayout* self, const ScriptArray& args);
		static ScriptObject IsSnapToGridEnabled(ILayout* self, const ScriptArray& args);
		static ScriptObject SetColumnSpacing(ILayout* self, const ScriptArray& args);
		static ScriptObject ColumnSpacing(ILayout* self, const ScriptArray& args);
		static ScriptObject SetRowSpacing(ILayout* self, const ScriptArray& args);
		static ScriptObject RowSpacing(ILayout* self, const ScriptArray& args);
		static ScriptObject SetColumnWidth(ILayout* self, const ScriptArray& args);
		static ScriptObject GetMinColumnWidth(ILayout* self, const ScriptArray& args);
		static ScriptObject GetMaxColumnWidth(ILayout* self, const ScriptArray& args);
		static ScriptObject SetRowHeight(ILayout* self, const ScriptArray& args);
		static ScriptObject GetMinRowHeight(ILayout* self, const ScriptArray& args);
		static ScriptObject GetMaxRowHeight(ILayout* self, const ScriptArray& args);
	};
}

#endif