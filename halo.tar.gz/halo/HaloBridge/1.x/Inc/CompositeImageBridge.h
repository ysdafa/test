#ifndef _COMPOSITEIMAGEBRIDGE_H
#define _COMPOSITEIMAGEBRIDGE_H

namespace Bridge
{
	class CompositeImageBridge : public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "CompositeImage";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

		virtual Color getDefaultColor() { return Color(0, 0, 0, 0); }
	private:
		static ScriptObject setImage(CCompositeImage* self, const ScriptArray& args);
	};
}

#endif