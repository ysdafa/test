#ifndef _SLIDER_BRIDGE_H
#define _SLIDER_BRIDGE_H

namespace Bridge
{
	using namespace HALO;
	class SliderBridge : public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "Slider"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

	private:
		static ScriptObject setMinMaxValue(CSlider* self, const ScriptArray& args);
		static ScriptObject setValue(CSlider* self, const ScriptArray& args);
		static ScriptObject setThumbImage(CSlider* self, const ScriptArray& args);
		static ScriptObject setThumbSize(CSlider* self, const ScriptArray& args);
		static ScriptObject setFillImage(CSlider* self, const ScriptArray& args);
		static ScriptObject setBackgroundImage(CSlider* self, const ScriptArray& args);
		static ScriptObject addListener(CSlider* self, const ScriptArray& args);
		static ScriptObject removeListener(CSlider* self, const ScriptArray& args);
	};
}

#endif