#ifndef _TEXTWIDGETHELPERBRIDGE_H
#define _TEXTWIDGETHELPERBRIDGE_H

#define ARG_IS_VALID(object, string, type) ASSERT(true == object.has(string) && true == object.get(string).type())
#define ARG_HAS_STRING(object, string) ASSERT(true == object.has(string))

namespace Bridge
{
	class TextWidgetExBridge : public TextWidgetBridge
	{
	public:
		template<typename NATIVE_TYPE>
		static ScriptObject wrapNativeObjectToJS(NATIVE_TYPE *object)
		{
			return wrapExistingNativeObject<NATIVE_TYPE>(object);
		}

		template<typename NATIVE_TYPE>
		static NATIVE_TYPE* unwrapObject(ScriptObject wrappedNativeObject)
		{
			return unwrapNativeObject<NATIVE_TYPE>(wrappedNativeObject);
		}

	protected:
		virtual inline const char* getScriptClassName() const {return "TextWidgetEx";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);
		virtual void destroyFromScript(void* destroyedObject);

	private:

		static ScriptObject handleDestroy(CTextWidgetEx* self, const ScriptArray& args);
		// Methods
		//static ScriptObject setParent(CTextWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setBackgroundColor(CTextWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setSize(CTextWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setPositon(CTextWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setLayout(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject isReversible(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject enableReverse(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject setOrientation(CTextWidgetEx* self, const ScriptArray& args);
		

		//static ScriptObject show(CTextWidgetEx* self, const ScriptArray& args);
		//static ScriptObject hide(CTextWidgetEx* self, const ScriptArray& args);

		//static ScriptObject setClipArea(CTextWidgetEx* self, const ScriptArray& args);
		//static ScriptObject removeClipArea(CTextWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setAlpha(CTextWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setPivotPoint(CTextWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setRotation(CTextWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setScale(CTextWidgetEx* self, const ScriptArray& args);
		//static ScriptObject addChild(CTextWidgetEx* self, const ScriptArray& args);
		//static ScriptObject numOfChildren(CTextWidgetEx* self, const ScriptArray& args);
		//static ScriptObject destroyAllChildren(CTextWidgetEx* self, const ScriptArray& args);
		//static ScriptObject raise(CTextWidgetEx* self, const ScriptArray& args);
		//static ScriptObject lower(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject enable(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject enableFocus(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject enablePointerFocus(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject setFocus(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject killFocus(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject isFocused(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject setTabWindow(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject moveTab(CTextWidgetEx* self, const ScriptArray& args);
		
		
		static ScriptObject addMouseListener(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject addKeyboardListener(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject addClickListener(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject addKeyLongPressListener(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject addFocusListener(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject addDragListener(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject addCursorListener(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeMouseListener(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeKeyboardListener(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeClickListener(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeKeyLongPressListener(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeFocusListener(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeDragListener(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeCursorListener(CTextWidgetEx* self, const ScriptArray& args);

		static ScriptObject addActorListener(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeActorListener(CTextWidgetEx* self, const ScriptArray& args);

		static ScriptObject addAction(CTextWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeAction(CTextWidgetEx* self, const ScriptArray& args);

		//static ScriptObject bindTransition(CTextWidgetEx* self, const ScriptArray& args);

		static ScriptObject m_getOrientation(CTextWidgetEx* self);
		static void m_setOrientation(CTextWidgetEx* self, ScriptObject value);
		static ScriptObject m_isReversible(CTextWidgetEx* self);
		static void m_enableReverse(CTextWidgetEx* self, ScriptObject value);

		static void setShadow(CTextWidgetEx* self, ScriptObject val);
		static volt::graphics::VerticalLayoutAlignment deserializeVerticalAlignment(std::string);
		static std::string serializeVerticalAlignment(volt::graphics::VerticalLayoutAlignment);

		static ScriptObject getAlignment(CTextWidgetEx* self);
		static void setAlignment(CTextWidgetEx* self, ScriptObject);
	};
}

#endif
