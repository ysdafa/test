#ifndef _TRANSITION_BRIDGE_H
#define _TRANSITION_BRIDGE_H

namespace Bridge
{
	class AnimatableBridge : public ScriptBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "Animatable";}
		
		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args)
		{
			ASSERT(1 == args.Length());
			return constructSubAnimatable(args[0]);
		}

		virtual IAnimatable* constructSubAnimatable(const ScriptObject& argObject) = 0;

	public:

	private:
		static ScriptObject m_BindTransition(IAnimatable* self, const ScriptArray& args);
	};

	class TransitionBridge : public ScriptBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "Transition";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);

		virtual inline void destroyFromScript(void* destroyedObject)
		{
			ITransition* trans = reinterpret_cast<ITransition*>(destroyedObject);
			delete trans;
		}

	public:

	private:
		static ScriptObject m_SetDuration(ITransition* self, const ScriptArray& args);
		static ScriptObject m_SetDestination(ITransition* self, const ScriptArray& args);
		static ScriptObject m_Play(ITransition* self, const ScriptArray& args);
	};
}

#endif