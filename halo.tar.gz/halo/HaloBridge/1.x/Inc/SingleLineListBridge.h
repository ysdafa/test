#ifndef _SINGLELINELIST_BRIDGE_H
#define _SINGLELINELIST_BRIDGE_H

namespace Bridge
{
	class SingleLineListListenerBridge : public BaseListenerBridge
	{
	public:

	protected:
		virtual inline const char* getScriptClassName() const {return "SingleLineListControlListener";}
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);

	private:
	};

	class InternalSingleLineListener : public ISingleLineListControlListener
	{
	public:
		DEFINE_CALLBACK_FUNCTION(ItemLoaded);
		DEFINE_CALLBACK_FUNCTION(ItemUnloaded);
		DEFINE_CALLBACK_FUNCTION(AsyncItemLoad);
		DEFINE_CALLBACK_FUNCTION(FocusChanged);
		DEFINE_CALLBACK_FUNCTION(FocusChangeMotionStart);
		DEFINE_CALLBACK_FUNCTION(MoveOut);
		DEFINE_CALLBACK_FUNCTION(ItemClicked);
		DEFINE_CALLBACK_FUNCTION(EnterKeyLongPressed);

		virtual bool OnItemLoaded(class ISingleLineListControl* list, IData *data, int itemIndex);
		virtual bool OnItemUnloaded(class ISingleLineListControl* list, IData *data, int itemIndex);
		virtual bool OnAsyncItemLoad(class ISingleLineListControl *list, IData *data, int itemIndex);
		virtual bool OnFocusChanged(class ISingleLineListControl *list, int fromItemIndex, int toItemIndex);
		virtual bool OnFocusChangeMotionStart(class ISingleLineListControl* list, int fromItemIndex, int toItemIndex);
		virtual bool OnMoveOut(class ISingleLineListControl* list, EDirection direction, int fromItemIndex);
		virtual bool OnItemClicked(class ISingleLineListControl* list, int itemIndex);
		virtual bool OnEnterKeyLongPressed(class ISingleLineListControl *list, int itemIndex);

	protected:

	private:

	};

	class SingleLineListBridge : public virtual DataListBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "SingleLineListControl";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual CDataListControl* constructSubWidget(Widget* parent, float width, float height, const ScriptObject& argObject);

	public:

	private:
		static ScriptObject m_AddData(CSingleLineListControl* self, const ScriptArray& args);

		static ScriptObject m_GetData(CSingleLineListControl* self, const ScriptArray& args);

		static ScriptObject m_ClearDataSource(CSingleLineListControl* self, const ScriptArray& args);

		static ScriptObject m_AddItem(CSingleLineListControl* self, const ScriptArray& args);

		static ScriptObject m_InsertItem(CSingleLineListControl* self, const ScriptArray& args);

		static ScriptObject m_SetItemSpace(CSingleLineListControl* self, const ScriptArray& args);

		static ScriptObject m_DeleteItem(CSingleLineListControl* self, const ScriptArray& args);

		static ScriptObject m_NumofItem(CSingleLineListControl* self, const ScriptArray& args);

		static ScriptObject m_UpdateItem(CSingleLineListControl* self, const ScriptArray& args);

		static ScriptObject m_UpdateAllItem(CSingleLineListControl* self, const ScriptArray& args);

		static ScriptObject m_SetAnimationDuration(CSingleLineListControl* self, const ScriptArray& args);

		static ScriptObject m_AddListListener(CSingleLineListControl* self, const ScriptArray& args);

		static ScriptObject m_Renderer(CSingleLineListControl* self, const ScriptArray& args);

		static ScriptObject m_GetStartItemInWindow(CSingleLineListControl* self, const ScriptArray& args);
	};
}

#endif