#ifndef _EVENTBRIDGE_H_
#define _EVENTBRIDGE_H_

namespace Bridge{

	class EventBridge : public ScriptBridge
	{
	protected:

		virtual inline const char* getScriptClassName() const {return "Event";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);

		virtual inline void destroyFromScript(void* destroyedObject)
		{
			IEvent* event = reinterpret_cast<IEvent*>(destroyedObject);
			delete event;
		}

		virtual IEvent* constructEvent(const ScriptArray& args);

    public:
		EventBridge()
		{
			allowGarbageCollection = false;
		}

	private:
		//method
		static ScriptObject clone(IEvent* self, const ScriptArray& args);
		static ScriptObject setReceiver(IEvent* self, const ScriptArray& args);
		static ScriptObject receiver(IEvent* self, const ScriptArray& args);
		static ScriptObject setEventType(IEvent* self, const ScriptArray& args);
		static ScriptObject isEventType(IEvent* self, const ScriptArray& args);

		static ScriptObject putInt(IEvent* self, const ScriptArray& args);
		static ScriptObject putDouble(IEvent* self, const ScriptArray& args);
		static ScriptObject putFloat(IEvent* self, const ScriptArray& args);
		static ScriptObject putChar(IEvent* self, const ScriptArray& args);
		static ScriptObject putString(IEvent* self, const ScriptArray& args);
		static ScriptObject putPointor(IEvent* self, const ScriptArray& args);
		static ScriptObject getInt(IEvent* self, const ScriptArray& args);
		static ScriptObject getDouble(IEvent* self, const ScriptArray& args);
		static ScriptObject getFloat(IEvent* self, const ScriptArray& args);
		static ScriptObject getChar(IEvent* self, const ScriptArray& args);
		static ScriptObject getString(IEvent* self, const ScriptArray& args);
		static ScriptObject getPointor(IEvent* self, const ScriptArray& args);
	};

	class MouseEventBridge : public EventBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "MouseEvent";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual IEvent* constructEvent(const ScriptArray& args);
	private:
		//method
		static ScriptObject getModifierType(IEvent* self, const ScriptArray& args);
		static ScriptObject getX(IEvent* self, const ScriptArray& args);
		static ScriptObject getY(IEvent* self, const ScriptArray& args);
		static ScriptObject setModifierType(IEvent* self, const ScriptArray& args);
		static ScriptObject setX(IEvent* self, const ScriptArray& args);
		static ScriptObject setY(IEvent* self, const ScriptArray& args);
	};

	class KeyboardEventBridge : public EventBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "KeyboardEvent";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual IEvent* constructEvent(const ScriptArray& args);
	private:
		//method
		static ScriptObject getModifierType(IEvent* self, const ScriptArray& args);
		static ScriptObject getKeyVal(IEvent* self, const ScriptArray& args);
		static ScriptObject getHardwareKeyCode(IEvent* self, const ScriptArray& args);
		static ScriptObject getUnicodeValue(IEvent* self, const ScriptArray& args);
		static ScriptObject setModifierType(IEvent* self, const ScriptArray& args);
		static ScriptObject setKeyVal(IEvent* self, const ScriptArray& args);
		static ScriptObject setHardwareKeyCode(IEvent* self, const ScriptArray& args);
		static ScriptObject setUnicodeValue(IEvent* self, const ScriptArray& args);	
	};

	class DragEventBridge : public EventBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "DragEvent";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual IEvent* constructEvent(const ScriptArray& args);

	private:
		//method
		static ScriptObject dragSignalType(IEvent* self, const ScriptArray& args);
		static ScriptObject pressCoords(IEvent* self, const ScriptArray& args);
		static ScriptObject motionCoords(IEvent* self, const ScriptArray& args);
		static ScriptObject motionDelta(IEvent* self, const ScriptArray& args);

		static std::string serializeDragSignalType(EDragSignalType);
	};

	class GestureEventBridge : public EventBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "GestureEvent";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual IEvent* constructEvent(const ScriptArray& args);

	private:
		//method
		static ScriptObject gestureSignalType(IEvent* self, const ScriptArray& args);
		static ScriptObject thresholdTriggerDistance(IEvent* self, const ScriptArray& args);
		static ScriptObject touchPoints(IEvent* self, const ScriptArray& args);
		static ScriptObject currentPoints(IEvent* self, const ScriptArray& args);

		static std::string serializeGestureSignalType(EGestureSignalType);
	};

	class SystemEventBridge : public EventBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "SystemEvent";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual IEvent* constructEvent(const ScriptArray& args);
	};

	class CustomEventBridge : public EventBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "CustomEvent";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual IEvent* constructEvent(const ScriptArray& args);

	private:
		//method
		static ScriptObject setEventType(IEvent* self, const ScriptArray& args);
	};

	class RemoconEventBridge : public EventBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "RemoconEvent";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual IEvent* constructEvent(const ScriptArray& args);
	};

	class MotionEventBridge : public EventBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "MotionEvent";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual IEvent* constructEvent(const ScriptArray& args);
	};

	class TouchEventBridge : public EventBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "TouchEvent";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual IEvent* constructEvent(const ScriptArray& args);
	};

	class RidgeEventBridge : public EventBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "RidgeEvent";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual IEvent* constructEvent(const ScriptArray& args);
	};

	class CursorEventBridge : public EventBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "CursorEvent";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual IEvent* constructEvent(const ScriptArray& args);
	};

	class SensorEventBridge : public EventBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "SensorEvent";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual IEvent* constructEvent(const ScriptArray& args);
	};

	class ClickEventBridge : public EventBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "ClickEvent";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual IEvent* constructEvent(const ScriptArray& args);
	};
	
	class LongPressEventBridge : public EventBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "LongPressEvent";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual IEvent* constructEvent(const ScriptArray& args);
	};
	
	class FocusEventBridge : public EventBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "FocusEvent";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual IEvent* constructEvent(const ScriptArray& args);
	};

}

#endif
