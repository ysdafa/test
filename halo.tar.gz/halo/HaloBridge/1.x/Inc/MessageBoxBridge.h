#ifndef _MESSAGEBOX_BRIDGE_H
#define _MESSAGEBOX_BRIDGE_H

namespace Bridge
{
	class MessageBoxListenerBridge : public BaseListenerBridge
	{
	public:

	protected:
		virtual inline const char* getScriptClassName() const {return "MessageBoxListener";}
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);

	private:
	};
	
	class InternalMessageBoxListener : public IMessageBoxListener
	{
	public:
		DEFINE_CALLBACK_FUNCTION(ButtonEvent);
		DEFINE_CALLBACK_FUNCTION(TimeOut);

		bool OnButtonEvent(class IMessageBox* messagebox, const int nButtonIndex, IMessageBoxListener::EEventTypes eventType);
		bool OnTimeOut(class IMessageBox* messagebox);

	protected:
		static std::string deserializeState(IMessageBoxListener::EEventTypes eventType);
		static std::string deserializeButtonState(IMessageBox::EMessageButtons buttonType);

	private:
	};
	
	class MessageBoxBridge :virtual public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "MessageBox"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget*  constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

	private:
		static ScriptObject setBGColor(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setTitleRect(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setTitleTextColor(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setTitleTextAlignment(CMessageBox* self, const ScriptArray& args);
		static ScriptObject titleTextLineCount(CMessageBox* self, const ScriptArray& args);
		static ScriptObject setTitleLineRect(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setTitleLineColor(CMessageBox* self, const ScriptArray &args);
		
		static ScriptObject setContentRect(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setContentTextColor(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setContentTextAlignment(CMessageBox* self, const ScriptArray& args);
		static ScriptObject contentTextLineCount(CMessageBox* self, const ScriptArray& args);
		static ScriptObject contentTextLineHeight(CMessageBox* self, const ScriptArray& args);
		static ScriptObject setContent2Rect(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setContentText2Color(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setContentText2Alignment(CMessageBox* self, const ScriptArray& args);
		static ScriptObject contentText2LineCount(CMessageBox* self, const ScriptArray& args);
		static ScriptObject setButtonRect(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setButtonImage(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setButtonBackgroundColor(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setButtonText(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setButtonTextColor(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setButtonTextFontSize(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setButtonBorderColor(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setButtonBorderWidth(CMessageBox* self, const ScriptArray &args);
		static ScriptObject addListener(CMessageBox* self, const ScriptArray &args);
		static ScriptObject removeListener(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setLoadingAttr(CMessageBox* self, const ScriptArray &args);

		// TODO: do not use these Apis, they will be deprecated later
		static ScriptObject setTitleText(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setTitleTextFont(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setContentText(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setContentTextFont(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setContentText2(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setContentText2Font(CMessageBox* self, const ScriptArray &args);
		static ScriptObject setDefaultFocus(CMessageBox* self, const ScriptArray &args);
		static ScriptObject supportTTS(CMessageBox* self, const ScriptArray &args);


		static void parseMessageBoxParams(const ScriptObject& options, CMessageBox::TMessageBoxAttr& attr);

	public:
		static CMessageBox::EMessageButtons deserializeButtonState(std::string stateStr, CMessageBox::EMessageButton theDefault);
		static CMessageBox::EMessageContents deserializeState(std::string stateStr, CMessageBox::EMessageContent theDefault);
		static int deserializeAlignment(std::string alignMent);
		
	};
}

#endif
