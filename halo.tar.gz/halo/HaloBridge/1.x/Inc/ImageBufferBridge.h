#ifndef _IMAGEBUFFERBRIDGE_H
#define _IMAGEBUFFERBRIDGE_H

namespace Bridge
{
	class ImageBufferBridge : public virtual ScriptBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "ImageBuffer";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);

		virtual inline void destroyFromScript(void* destroyedObject)
		{
			IImageBuffer* buffer = reinterpret_cast<IImageBuffer*>(destroyedObject);
			delete buffer;
		}

		virtual IImageBuffer* constructWidget(const ScriptArray& args);

	public:
		ImageBufferBridge()
		{
			allowGarbageCollection = false;
		}

	private:

		// Methods
		static ScriptObject clone(IImageBuffer* self, const ScriptArray& args);
		static ScriptObject setImagePath(IImageBuffer* self, const ScriptArray& args);
	};
}

#endif