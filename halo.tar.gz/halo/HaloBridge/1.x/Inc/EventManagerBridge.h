#ifndef _EVENTMANAGERBRIDGE_H_
#define _EVENTMANAGERBRIDGE_H_

namespace Bridge{

class EventManagerBridge : public ScriptInstanceBridge
{
public:
	
	EventManagerBridge(IEventManager* eventManager) : ScriptInstanceBridge(eventManager) {}

	virtual void mapScriptInterface(ScriptContext& context);

	virtual const char* getScriptClassName() const { return "eventManager"; };

	//method
	static ScriptObject sendEventLocal(IEventManager* self, const ScriptArray& args);
	static ScriptObject sendEventLocalSync(IEventManager* self, const ScriptArray& args);
	static ScriptObject sendEventRemote(IEventManager* self, const ScriptArray& args);

	static ScriptObject addSystemEventListener(IEventManager* self, const ScriptArray& args);
	static ScriptObject removeSystemEventListener(IEventManager* self, const ScriptArray& args);
	static ScriptObject addCustomEventListener(IEventManager* self, const ScriptArray& args);
	static ScriptObject removeCustomEventListener(IEventManager* self, const ScriptArray& args);
	static ScriptObject getEventType(IEventManager* self, const ScriptArray& args);
	static ScriptObject getEventName(IEventManager* self, const ScriptArray& args);
	static ScriptObject registerInterestingEvent(IEventManager* self, const ScriptArray& args);
	static ScriptObject unregisterInterestingEvent(IEventManager* self, const ScriptArray& args);
	static ScriptObject setKeyLongPressInterval(IEventManager* self, const ScriptArray& args);
	static ScriptObject getKeyLongPressInterval(IEventManager* self, const ScriptArray& args);
};

}

#endif
