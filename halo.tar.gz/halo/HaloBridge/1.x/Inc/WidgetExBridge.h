#ifndef _WIDGETHELPERBRIDGE_H
#define _WIDGETHELPERBRIDGE_H

#define ARG_IS_VALID(object, string, type) ASSERT(true == object.has(string) && true == object.get(string).type())
#define ARG_HAS_STRING(object, string) ASSERT(true == object.has(string))

namespace Bridge
{
	class WidgetExListenerBridge : public BaseListenerBridge 
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "WidgetExListener";}
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);
	};

	class InternalWidgetExListener : public IActorListener, public BaseInternalListener
	{
	public:
		InternalWidgetExListener(WidgetExListenerBridge *owner) : BaseInternalListener(owner) { }

		DEFINE_CALLBACK_FUNCTION(HighContrastChanged);
		DEFINE_CALLBACK_FUNCTION(EnlargeChanged);

		virtual bool OnHighContrastChanged(class IWidgetExtension *actor, bool flagHighContrast);
		virtual bool OnEnlargeChanged(class IWidgetExtension *actor, bool flagEnlarge);

	};

	class WidgetExBridge : public WidgetBridge 
	{
	public:
		const std::set<void*> *InstanceCreatedObjects()
		{
			return &instanceCreatedObjects;
		}

		template<typename NATIVE_TYPE>
		static ScriptObject wrapNativeObjectToJS(NATIVE_TYPE *object)
		{
			return wrapExistingNativeObject<NATIVE_TYPE>(object);
		}

		template<typename NATIVE_TYPE>
		static NATIVE_TYPE* unwrapObject(ScriptObject wrappedNativeObject)
		{
			return unwrapNativeObject<NATIVE_TYPE>(wrappedNativeObject);
		}

	protected:
		virtual inline const char* getScriptClassName() const {return "WidgetEx";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);
		virtual void destroyFromScript(void* destroyedObject);

	private:

		static ScriptObject handleDestroy(CWidgetEx* self, const ScriptArray& args);
		// Methods
		//static ScriptObject setParent(CWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setBackgroundColor(CWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setSize(CWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setPositon(CWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setLayout(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject isReversible(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject enableReverse(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject setOrientation(CWidgetEx* self, const ScriptArray& args);
		

		//static ScriptObject show(CWidgetEx* self, const ScriptArray& args);
		//static ScriptObject hide(CWidgetEx* self, const ScriptArray& args);

		//static ScriptObject setClipArea(CWidgetEx* self, const ScriptArray& args);
		//static ScriptObject removeClipArea(CWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setAlpha(CWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setPivotPoint(CWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setRotation(CWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setScale(CWidgetEx* self, const ScriptArray& args);
		//static ScriptObject addChild(CWidgetEx* self, const ScriptArray& args);
		//static ScriptObject numOfChildren(CWidgetEx* self, const ScriptArray& args);
		//static ScriptObject destroyAllChildren(CWidgetEx* self, const ScriptArray& args);
		//static ScriptObject raise(CWidgetEx* self, const ScriptArray& args);
		//static ScriptObject lower(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject enable(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject enableFocus(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject enablePointerFocus(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject setFocus(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject killFocus(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject isFocused(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject setTabWindow(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject moveTab(CWidgetEx* self, const ScriptArray& args);
		
		
		static ScriptObject addMouseListener(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject addKeyboardListener(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject addClickListener(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject addKeyLongPressListener(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject addFocusListener(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject addDragListener(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject addCursorListener(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeMouseListener(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeKeyboardListener(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeClickListener(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeKeyLongPressListener(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeFocusListener(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeDragListener(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeCursorListener(CWidgetEx* self, const ScriptArray& args);

		static ScriptObject addFirstShownListener(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeFirstShownListener(CWidgetEx* self, const ScriptArray& args);

		static ScriptObject addActorListener(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeActorListener(CWidgetEx* self, const ScriptArray& args);

		static ScriptObject addAction(CWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeAction(CWidgetEx* self, const ScriptArray& args);

		//static ScriptObject bindTransition(CWidgetEx* self, const ScriptArray& args);

		static ScriptObject m_getOrientation(CWidgetEx* self);
		static void m_setOrientation(CWidgetEx* self, ScriptObject value);
		static ScriptObject m_isReversible(CWidgetEx* self);
		static void m_enableReverse(CWidgetEx* self, ScriptObject value);

	};
}

#endif
