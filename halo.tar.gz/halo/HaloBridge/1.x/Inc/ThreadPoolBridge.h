#ifndef _THREADPOOLBRIDGE_H
#define _THREADPOOLBRIDGE_H

namespace Bridge
{
	class ThreadPoolBridge : public virtual ScriptBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "ThreadPool";}

		virtual void mapScriptInterface(ScriptContext& context)
		{
		}

		virtual void* constructFromScript(const ScriptArray& args);

		virtual inline void destroyFromScript(void* destroyedObject)
		{
		}

		virtual IThreadPool* constructThreadPool(int maxThreadCount, int minReserveTheadCount, int maxPendingTaskCount);

	public:
		ThreadPoolBridge()
		{
		}

	};
}

#endif