#ifndef _TOGGLEBUTTON_BRIDGE_H
#define _TOGGLEBUTTON_BRIDGE_H

namespace Bridge
{
	class ToggleButtonBridge:virtual public ActorBridge , public ToggleButtonListener
	{
	public:
		enum E_LISTENER_TYPE
		{
			TOGGLE_ON = 0,
			TOGGLE_OFF,
		
		};

		virtual inline const char* getScriptClassName() const { return "ToggleButton"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual IActor* constructWidget(IActor* parent, float width, float height ,const ScriptObject& argObject);

		virtual void OnToggleOn(class IToggleButton *togglebutton);

		virtual void OnToggleOff(class IToggleButton *togglebutton);

	private:
		ScriptFunction m_listListenerCallback;

		static ScriptObject setCheckImage(CToggleButton* self, const ScriptArray& args);

		static ScriptObject setImage(CToggleButton* self, const ScriptArray& args);

		static ScriptObject setText(CToggleButton* self, const ScriptArray& args);

		static ScriptObject setTextFontSize(CToggleButton* self, const ScriptArray& args);

		static ScriptObject setCheck(CToggleButton* self, const ScriptArray& args);

		static ScriptObject enableChecked(CToggleButton* self, const ScriptArray& args);

		static ScriptObject isChecked(CToggleButton* self, const ScriptArray& args);

		static ScriptObject addlistener(CToggleButton* self, const ScriptArray& args);

		static IToggleButton::EItemState deserializeItemState(std::string stateStr, IToggleButton::EItemState theDefault);

		static IToggleButton::ECheckState deserializeCheckState(std::string stateStr, IToggleButton::ECheckState theDefault);
	};
}

#endif