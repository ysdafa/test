#ifndef _INPUTBOX_BRIDGE_H
#define _INPUTBOX_BRIDGE_H

#ifndef WIN32
#define HAVE_ECORE_IMF
#endif

namespace Bridge
{
	class InputBoxBridge :virtual public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "InputBox"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget*  constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

	private:
	
		static ScriptObject setText(CInputBox* self, const ScriptArray &args);
		
		static ScriptObject setImage(CInputBox* self, const ScriptArray &args);

		static ScriptObject setTextBGColor(CInputBox* self, const ScriptArray &args);

		static ScriptObject setTextColor(CInputBox* self, const ScriptArray &args);
		
		static ScriptObject setSelectionColor(CInputBox* self, const ScriptArray &args);

		static ScriptObject setCursorColor(CInputBox* self, const ScriptArray &args);

		static ScriptObject setFont(CInputBox* self, const ScriptArray &args);

		static ScriptObject setFontSize(CInputBox* self, const ScriptArray &args);

		static ScriptObject setTextMaxCount(CInputBox* self, const ScriptArray &args);

		static ScriptObject setTexHAlignment(CInputBox* self, const ScriptArray &args);

		static ScriptObject insertText(CInputBox* self, const ScriptArray &args);

		static void parseMessageBoxParams(const ScriptObject& options, CInputBox::TInputBoxAttr& attr);

		static IInputBox::T_INPUTBOX_STATE deserializeState(std::string stateStr, IInputBox::T_INPUTBOX_STATE state);

		static int deserializeAlignment(std::string alignMent);

#ifdef HAVE_ECORE_IMF		
		static ScriptObject enableIME(CInputBox *self, const ScriptArray& args);
#endif
	};
}

#endif
