#ifndef _SELECTBUTTON_BRIDGE_H
#define _SELECTBUTTON_BRIDGE_H

namespace Bridge
{
	class SelectButtonBridge :virtual public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "SelectButton"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);
	private:
		static ScriptObject setItemText(CSelectButton* self, const ScriptArray &args);
		
		static ScriptObject itemText(CSelectButton* self, const ScriptArray &args);
		
		static ScriptObject setItemTextFontSize(CSelectButton* self, const ScriptArray &args);

		static ScriptObject setItemTextColor(CSelectButton* self, const ScriptArray &args);
		
		static ScriptObject setTextFont(CSelectButton* self, const ScriptArray &args);
		
		static ScriptObject textFont(CSelectButton* self, const ScriptArray &args);
		
		static ScriptObject setBoxBackGroudImage(CSelectButton* self, const ScriptArray &args);

		static ScriptObject setCheckImage(CSelectButton* self, const ScriptArray &args);

		static ScriptObject setBoxBackGroudImageOpacity(CSelectButton* self, const ScriptArray &args);

		static ScriptObject setCheckImageOpacity(CSelectButton* self, const ScriptArray &args);
		
		static ScriptObject updateImageAttr(CSelectButton* self, const ScriptArray &args);

		static ScriptObject setId(CSelectButton* self, const ScriptArray &args);
		
		static ScriptObject getId(CSelectButton* self, const ScriptArray &args);		
	
		static ScriptObject setTextAlignment(CSelectButton* self, const ScriptArray &args);

		static ScriptObject show(CSelectButton* self, const ScriptArray &args);

		static ScriptObject setCheck(CSelectButton* self, const ScriptArray &args);

		static ScriptObject isChecked(CSelectButton* self, const ScriptArray &args);

		static ScriptObject enableChecked(CSelectButton* self, const ScriptArray &args);

		

		static ScriptObject setAttachText(CSelectButton* self, const ScriptArray &args);	

	public:
		static CSelectButton::EItemState deserializeState(std::string stateStr, CSelectButton::EItemState theDefault);

	};
}

#endif