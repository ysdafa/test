#ifndef _RENDER_BRIDGE_H
#define _RENDER_BRIDGE_H

namespace Bridge
{
	enum E_CALLBACK_TYPE
	{
		DRAW_CALLBACK = 0,
		UPDATE_CALLBACK,
		RESIZE_CALLBACK
	};

	class RendererBridge : public virtual ScriptBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "Renderer";}
		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);

		virtual inline void destroyFromScript(void* destroyedObject)
		{
		}

	public:
		RendererBridge(void)
		{
			allowGarbageCollection = false;
		}

		static void destroyRenderer(class InternalRender *renderer);

	private:
	};

	class InternalRender : public IRenderer
	{
	public:
		InternalRender(void) : m_root(NULL), m_thumbnail(NULL){};
		virtual ~InternalRender(void);
		
		struct TCallback 
		{
			TCallback(void)
			{
				flagExist = false;
			}

			bool flagExist;
			ScriptFunction function;
		};

		RendererBridge *bridge;

		DEFINE_CALLBACK_FUNCTION(Draw);
		DEFINE_CALLBACK_FUNCTION(Update);
		DEFINE_CALLBACK_FUNCTION(Resize);
		DEFINE_CALLBACK_FUNCTION(TransformStyle);
		DEFINE_CALLBACK_FUNCTION(Release);

		virtual void Draw(IData *data, IActor* parent, E_DRAW_TYPE drawType);
		virtual void Update(IData *data, IActor* parent);
		virtual void Resize(IData *data, IActor* parent, ClutterSize destSize, bool flagAni, int animationDuration);
		virtual void OnTransformStyle(IData *data, IActor* parent, int fromStyle, int toStyle, int parentWidth, int parentHeight, bool flagAni, int animationDuration);

		Widget* Root(void)
		{
			return m_root;
		}

		Widget* GetRootWidget(void) const
		{
			return m_root;
		}

		void SetRootWidget(Widget *root)
		{
			m_root = root;
		}

		CThumbnail* GetThumbnail(void) const
		{
			return m_thumbnail;
		}

		void SetThumbnail(CThumbnail *thumbnail)
		{
			m_thumbnail = thumbnail;
		}

		IThumbnail* Thumbnail(void) const
		{
			return m_thumbnail;
		}

	private:
		Widget *m_root;
		CThumbnail *m_thumbnail;
	};
}

#endif