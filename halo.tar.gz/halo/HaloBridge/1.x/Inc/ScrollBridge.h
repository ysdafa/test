#ifndef _SCROLL_BRIDGE_H
#define _SCROLL_BRIDGE_H

namespace Bridge
{
	using namespace HALO;

	class ScrollListenerBridge : public BaseListenerBridge
	{
	public:

	protected:
		virtual inline const char* getScriptClassName() const { return "ScrollListener"; }
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);

	private:
	};

	class InternalScrollListener : public IScrollListener
	{
	public:
		DEFINE_CALLBACK_FUNCTION(ValueChanged);

		virtual bool OnValueChanged(class IScroll* scroll, EValueChangedType type);
	};

	class ScrollBridge : public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "Scroll"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

	private:
		static ScriptObject setMinValue(CScroll* self, const ScriptArray& args);
		static ScriptObject setMaxValue(CScroll* self, const ScriptArray& args);
		static ScriptObject setValue(CScroll* self, const ScriptArray& args);
		static ScriptObject setMinCurMaxValue(CScroll* self, const ScriptArray& args);

		static ScriptObject setRolloverTrackHeight(CScroll* self, const ScriptArray& args);

		static ScriptObject setPointingNormalBackgroundImage(CScroll* self, const ScriptArray& args);
		static ScriptObject setPointingOverBackgroundImage(CScroll* self, const ScriptArray& args);

		static ScriptObject setTrackShadowHeight(CScroll* self, const ScriptArray& args);
		static ScriptObject setTrackShadowColor(CScroll* self, const ScriptArray& args);

		static ScriptObject setPointingNormalThumbImage(CScroll* self, const ScriptArray& args);
		static ScriptObject setPointingNormalThumbSize(CScroll* self, const ScriptArray& args);

		static ScriptObject setPointingOverThumbImage(CScroll* self, const ScriptArray& args);
		static ScriptObject setPointingOverThumbSize(CScroll* self, const ScriptArray& args);

		static ScriptObject setPointingFocusThumbImage(CScroll* self, const ScriptArray& args);
		static ScriptObject setPointingFocusThumbSize(CScroll* self, const ScriptArray& args);


		static ScriptObject addListener(CScroll* self, const ScriptArray& args);
		static ScriptObject removeListener(CScroll* self, const ScriptArray& args);

		// not using now
	private:
		static ScriptObject setPreviousArrowImage(CScroll* self, const ScriptArray& args);
		static ScriptObject setPreviousArrowSize(CScroll* self, const ScriptArray& args);

		static ScriptObject setNextArrowImage(CScroll* self, const ScriptArray& args);
		static ScriptObject setNextArrowSize(CScroll* self, const ScriptArray& args);

		static ScriptObject setLongPressIntervalOnArrowButton(CScroll* self, const ScriptArray& args);
		static ScriptObject setMovingStepOnArrowButton(CScroll* self, const ScriptArray& args);
	};
}

#endif