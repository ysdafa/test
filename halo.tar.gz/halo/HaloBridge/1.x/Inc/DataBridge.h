#ifndef _DATA_BRIDGE_H
#define _DATA_BRIDGE_H

using namespace HALO;

namespace Bridge
{
	class DataBridge : public virtual ScriptBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "Data";}
		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);

		virtual void destroyFromScript(void* destroyedObject);

	public:

	private:
		static ScriptObject m_curUsingData(IData* self, const ScriptArray& args);
	};
}

#endif