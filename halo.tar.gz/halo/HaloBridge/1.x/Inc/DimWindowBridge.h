#ifndef _DIMWINDOWBRIDGE_H
#define _DIMWINDOWBRIDGE_H

namespace Bridge
{
	class DimWindowBridge : public ActorBridge
	{
	public:
		virtual const char* getScriptClassName() const { return "DimWindow"; }
		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

		virtual Color getDefaultColor() { return Color(0, 0, 0, 150); }

		static ScriptObject addTransparentArea(CDimWindow* self, const ScriptArray& args);
		static ScriptObject clearTransparentArea(CDimWindow* self, const ScriptArray& args);

	};
}

#endif //_DIMWINDOWBRIDGE_H
