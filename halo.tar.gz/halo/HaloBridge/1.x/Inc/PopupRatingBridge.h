#ifndef _POPUPRATING_BRIDGE_H
#define _POPUPRATING_BRIDGE_H

namespace Bridge
{
	class PopupRatingListenerBridge : public BaseListenerBridge
	{
	public:

	protected:
		virtual inline const char* getScriptClassName() const {return "PopupRatingListener";}
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);

	private:
	};
	
	class InternalPopupRatingListener : public IPopupRatingListener
	{
	public:
		DEFINE_CALLBACK_FUNCTION(ButtonEvent);
		DEFINE_CALLBACK_FUNCTION(StarIconEvent);
		DEFINE_CALLBACK_FUNCTION(TimeOut);

		bool OnButtonEvent(class IPopupRating* popupRating, const int nButtonIndex, IPopupRatingListener::EEventTypes eventType);
		bool OnStarIconEvent(class IPopupRating* popupRating, IPopupRatingListener::EEventTypes eventType);
		bool OnTimeOut(class IPopupRating* popupRating);

	protected:
		static std::string deserializeState(IPopupRatingListener::EEventTypes eventType);
		static std::string deserializeButtonState(IPopupRating::EPopupRatingButtons buttonType);

	private:
	};
	
	class PopupRatingBridge :virtual public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "PopupRating"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget*  constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

	private:
		static ScriptObject setBGColor(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setTitleRect(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setTitleTextColor(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setTitleTextAlignment(CPopupRating* self, const ScriptArray& args);
		static ScriptObject setTitleLineRect(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setTitleLineColor(CPopupRating* self, const ScriptArray &args);
		
		static ScriptObject setContentRect(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setContentTextColor(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setContentTextAlignment(CPopupRating* self, const ScriptArray& args);

		static ScriptObject setStarIconRect(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setStarIconsBGRect(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setStarIconsBGColor(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setArrowButtonRect(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setArrowButtonImage(CPopupRating* self, const ScriptArray &args);
		
		static ScriptObject setButtonRect(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setButtonImage(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setButtonBackgroundColor(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setButtonText(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setButtonTextColor(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setButtonTextFontSize(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setButtonBorderColor(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setButtonBorderWidth(CPopupRating* self, const ScriptArray &args);
		static ScriptObject addListener(CPopupRating* self, const ScriptArray &args);
		static ScriptObject removeListener(CPopupRating* self, const ScriptArray &args);

		static void parsePopupRatingParams(const ScriptObject& options, CPopupRating::TPopupRatingAttr& attr);

		// TODO: do not use these Apis, they will be deprecated later
		static ScriptObject setTitleText(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setTitleTextFont(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setContentText(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setContentTextFont(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setStarIconUnmarkedImage(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setStarIconMarkedImage(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setDefaultFocus(CPopupRating* self, const ScriptArray &args);
		static ScriptObject defaultFocus(CPopupRating* self, const ScriptArray &args);
		static ScriptObject setMarkedStarIconNumber(CPopupRating* self, const ScriptArray &args);
		static ScriptObject markedStarIconNumber(CPopupRating* self, const ScriptArray &args);
		static ScriptObject supportTTS(CPopupRating* self, const ScriptArray &args);

	public:
		static CPopupRating::EPopupRatingStarIcons deserializeStarIconState(std::string stateStr, CPopupRating::EPopupRatingStarIcons theDefault);
		static CPopupRating::EPopupRatingArrowButtons deserializeArrowButtonState(std::string stateStr, CPopupRating::EPopupRatingArrowButtons theDefault);
		static CPopupRating::EPopupRatingButtons deserializeButtonState(std::string stateStr, CPopupRating::EPopupRatingButtons theDefault);
		static CPopupRating::EPopupRatingTypes deserializeState(std::string stateStr, CPopupRating::EPopupRatingTypes theDefault);
		static int deserializeAlignment(std::string alignMent);
	};
}

#endif
