#ifndef _BASE_DEFINE_H_
#define _BASE_DEFINE_H

#define DEFINE_CALLBACK_FUNCTION(x) TCallback x##Cb; \
	const ScriptFunction& Get##x##CallBack(void) const \
						{ \
						return (x##Cb.function); \
						} \
						void Set##x##CallBack(const ScriptFunction &function) \
						{\
						x##Cb.flagExist = true; \
						x##Cb.function = function; \
						}


#define DEFINE_INTERNAL_CLASS_BEGIN(e) \
class Internal##e##Listener : public BaseInternalListener, public I##e##Listener \
	{\
	public:\
	Internal##e##Listener(e##ListenerBridge *owner) : BaseInternalListener(owner) {} 

#define DEFINE_INTERNAL_CLASS_END() };

#define DEFINE_EVENT_FUNCTION(e, x) \
	virtual bool On##x(IActor* pWindow, I##e##Event* pEvent) \
	{\
if (true == x##Cb.flagExist)\
	{\
	ScriptArray args; \
	args.set(0, t_owner->WrapNativeObjectToJS(dynamic_cast<CActor*>(pWindow))); \
	args.set(1, ScriptObject((int)(pEvent))); \
	x##Cb.function.invoke(args); \
	}\
	return true;\
	}

#define DEFINE_KEYBOARD_EVENT_FUNCTION(x) \
	virtual bool On##x(IActor* pWindow, IKeyboardEvent* pEvent) \
	{\
if (true == x##Cb.flagExist)\
	{\
	ScriptArray args; \
	args.set(0, t_owner->WrapNativeObjectToJS(dynamic_cast<CActor*>(pWindow))); \
	args.set(1, ScriptObject(pEvent->GetKeyVal())); \
	x##Cb.function.invoke(args); \
	}\
	return true; \
	}

#define DEFINE_SYSTEM_EVENT_FUNCTION(x) \
	virtual bool On##x(IEvent* pEvent) \
	{\
if (true == x##Cb.flagExist)\
	{\
	ScriptArray args; \
	args.set(0, ScriptObject((int)(pEvent))); \
	x##Cb.function.invoke(args); \
	}\
	return true; \
	}

struct TCallback 
{
	TCallback(void)
	{
		flagExist = false;
	}

	bool flagExist;
	Bridge::ScriptFunction function;
};

#endif