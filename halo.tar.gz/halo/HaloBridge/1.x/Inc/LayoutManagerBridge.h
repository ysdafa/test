#ifndef _LAYOUTMANAGER_BRIDGE_H
#define _LAYOUTMANAGER_BRIDGE_H

using namespace HALO;

namespace Bridge
{	
	class LayoutManagerBridge : public virtual ScriptBridge
	{
	public:

		virtual void mapScriptInterface(ScriptContext& context);
		
		virtual void* constructFromScript(const ScriptArray& args);

		virtual inline void destroyFromScript(void* destroyedObject)
		{
			ILayout* buffer = reinterpret_cast<ILayout*>(destroyedObject);
			delete buffer;
		}

		virtual ILayout* constructWidget(const ScriptArray& args) = 0;

	private:
		// Methods
		static ScriptObject SetActorXAlign(ILayout* self, const ScriptArray& args);
		static ScriptObject ActorXAlign(ILayout* self, const ScriptArray& args);
		static ScriptObject SetActorYAlign(ILayout* self, const ScriptArray& args);
		static ScriptObject ActorYAlign(ILayout* self, const ScriptArray& args);
		static ScriptObject CopyMargin(ILayout* self, const ScriptArray& args);
		static ScriptObject SetMargin(ILayout* self, const ScriptArray& args);
		static ScriptObject GetMargin(ILayout* self, const ScriptArray& args);
		static ScriptObject SetMarginTop(ILayout* self, const ScriptArray& args);
		static ScriptObject MarginTop(ILayout* self, const ScriptArray& args);
		static ScriptObject SetMarginRight(ILayout* self, const ScriptArray& args);
		static ScriptObject MarginRight(ILayout* self, const ScriptArray& args);
		static ScriptObject SetMarginBottom(ILayout* self, const ScriptArray& args);
		static ScriptObject MarginBottom(ILayout* self, const ScriptArray& args);
		static ScriptObject SetMarginLeft(ILayout* self, const ScriptArray& args);
		static ScriptObject MarginLeft(ILayout* self, const ScriptArray& args);
		static ScriptObject SetXExpandFlag(ILayout* self, const ScriptArray& args);
		static ScriptObject FlagXExpand(ILayout* self, const ScriptArray& args);
		static ScriptObject SetYExpandFlag(ILayout* self, const ScriptArray& args);
		static ScriptObject FlagYExpand(ILayout* self, const ScriptArray& args);
	};
}

#endif