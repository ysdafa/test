#ifndef _CHECKBOXGROUP_BRIDGE_H
#define _CHECKBOXGROUP_BRIDGE_H

namespace Bridge
{
	using namespace HALO;

	class CheckBoxGroupListenerBridge : public BaseListenerBridge
	{
	public:

	protected:
		virtual inline const char* getScriptClassName() const { return "CheckBoxGroupListener"; }
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);

	private:
	};

	class InternalCheckBoxGroupListener : public OnCheckedChangedListener
	{
	public:
		DEFINE_CALLBACK_FUNCTION(CheckedChanged);

		virtual bool OnCheckChanged(class ISelectButtonGroup* list , int index , bool ischecked ,ISelectButton* checkcontrol);
	};

	class CheckBoxGroupBridge : virtual public ActorBridge 
	{
	public:
		virtual inline const char* getScriptClassName() const { return "CheckBoxGroup"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget*  constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);
	private:

		static ScriptObject addButton(CCheckBoxGroup* self, const ScriptArray& args);

		static ScriptObject removeButton(CCheckBoxGroup* self, const ScriptArray& args);
		
		static ScriptObject getItemById(CCheckBoxGroup* self, const ScriptArray& args);

		static ScriptObject setDefaultFocus(CCheckBoxGroup* self, const ScriptArray& args);
		
		static ScriptObject numofItem(CCheckBoxGroup* self, const ScriptArray& args);

		static ScriptObject addlistener(CCheckBoxGroup* self, const ScriptArray& args);

		static ScriptObject removeListener(CCheckBoxGroup* self, const ScriptArray& args);
		
		static ScriptObject getSelectedItemIndexes(CCheckBoxGroup* self, const ScriptArray& args);

		static ScriptObject setDefaultSelectedItem(CCheckBoxGroup* self, const ScriptArray& args);
	};
}

#endif