#ifndef _BINLAYOUTBRIDGE_H
#define _BINLAYOUTBRIDGE_H

namespace Bridge
{
	class BinLayoutBridge : public LayoutManagerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "BinLayout"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual ILayout* constructWidget(const ScriptArray& args);

	private:
		//static ScriptObject setImage(HALO::IActor* self, const ScriptArray& args);
	};
}

#endif