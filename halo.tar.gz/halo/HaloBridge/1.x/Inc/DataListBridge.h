#ifndef _DATALIST_BRIDGE_H
#define _DATALIST_BRIDGE_H

namespace Bridge
{
	class RendererProviderBridge : public ScriptBridge
	{
	public:

	protected:
		virtual inline const char* getScriptClassName() const {return "RendererProvider";}
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);
		virtual void destroyFromScript(void* pointerToDestroyedObject);

	private:
		static ScriptObject m_HandleDestroy(class InternalProvider* self, const ScriptArray& args);
	};

	class InternalProvider : public IRendererProvider
	{
	public:
		virtual IRenderer* GetRenderer(IData *data, IActor* parent);
		DEFINE_CALLBACK_FUNCTION(Provider);
	};

	class DataListBridge : public virtual ActorBridge
	{
	protected:
		ScriptObject t_listListener;

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

		virtual CDataListControl* constructSubWidget(Widget* parent, float width, float height, const ScriptObject& argObject) = 0;

	public:

	private:
		// Methods
		static ScriptObject loadData(CDataListControl* self, const ScriptArray& args);

		static ScriptObject enlargeFocusedItem(CDataListControl* self, const ScriptArray& args);
		
		static ScriptObject moveFocus(CDataListControl* self, const ScriptArray& args);

		static ScriptObject showFocus(CDataListControl* self, const ScriptArray& args);

		static ScriptObject hideFocus(CDataListControl* self, const ScriptArray& args);

		static ScriptObject m_SetRenderProvider(CDataListControl* self, const ScriptArray& args);

		static ScriptObject scrollVisibleArea(CDataListControl* self, const ScriptArray& args);

		static ScriptObject attachScrollBar(CDataListControl* self, const ScriptArray& args);

		static ScriptObject m_SetDimWindowColor(CDataListControl* self, const ScriptArray& args);

		static ScriptObject m_Dim(CDataListControl* self, const ScriptArray& args);

		static ScriptObject m_SetFocusImage(CDataListControl* self, const ScriptArray& args);

		static ScriptObject m_SetCursorScrollInfo(CDataListControl* self, const ScriptArray& args);
	};
}

#endif