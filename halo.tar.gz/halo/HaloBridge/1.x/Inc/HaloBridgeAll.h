#ifndef _HALO_BRIDGE_ALL_H_
#define _HALO_BRIDGE_ALL_H_

#include <clutter/clutter.h>
#include "ScriptBridge.h"
#include "WidgetBridge.h"
#include "Halo1_0.h"
#include "Halo.h"
#include "HaloUtilBridge.h"
#include "UtilityBridge.h"
#include "BaseDefine.h"
#include "ListenerBridge.h"

#include "StageBridge.h"
#include "TransitionBridge.h"

#include "ActionBridge.h"
#include "ActorBridge.h"
#include "DimWindowBridge.h"
#include "AsyncTaskBridge.h"

#include "ThumbnailBridge.h"
#include "RenderBridge.h"
#include "DataBridge.h"
#include "DataListBridge.h"
#include "SingleLineListBridge.h"
#include "GridLayoutListBridge.h"
#include "FirstScreenControlBridge.h"

#include "CheckBoxGroupBridge.h"
#include "RadioButtonGroupBridge.h"
#include "DeviceBridge.h"
#include "DeviceManagerBridge.h"

#include "EventBridge.h"
#include "EventManagerBridge.h"

#include "LayoutManagerBridge.h"
#include "BinLayoutBridge.h"
#include "BoxLayoutBridge.h"
#include "FixedLayoutBridge.h"
#include "FlowLayoutBridge.h"
#include "GridLayoutBridge.h"

#include "TextBridge.h"
#include "RichTextBridge.h"
#include "ImageBufferBridge.h"
#include "HaloImageBridge.h"
#include "CompositeImageBridge.h"

#include "ButtonBridge.h"
#include "LabelBridge.h"
#include "PageControlBridge.h"
#include "ProgressBridge.h"
#include "RectangleBridge.h"
#include "ScrollBridge.h"
#include "SliderBridge.h"
#include "ToggleButtonBridge.h"

#include "ThreadPoolBridge.h"
#include "SelectButtonBridge.h"

#include "MessageBoxBridge.h"
#include "InputBoxBridge.h"
#include "LoadingBridge.h"

#include "CategoryTabBridge.h"
#include "ToolTipBridge.h"
#include "PopupRatingBridge.h"
#include "PinPopupBridge.h"
#include "VideoActorBridge.h"
#include "TTSEngineBridge.h"
#endif
