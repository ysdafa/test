#include "HaloBridgeAll.h"

using namespace HALO;
using namespace Bridge;

bool CategoryTabListener::OnTabChanged(class ICategoryTab* list, int index)
{
	if (true == TabChangedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CCategoryTab*>(list)));
		args.set(1, ScriptObject(index));
		TabChangedCb.function.invoke(args);
	}
	return true;
}
bool CategoryTabListener::OnTabClicked(class ICategoryTab* list, int index)
{
	if (true == TabClickedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CCategoryTab*>(list)));
		args.set(1, ScriptObject(index));
		TabClickedCb.function.invoke(args);
	}
	return true;
}
bool CategoryTabListener::OnTabMouseIn(class ICategoryTab* list, int index)
{
	if (true == TabMouseInCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CCategoryTab*>(list)));
		args.set(1, ScriptObject(index));
		TabMouseInCb.function.invoke(args);
	}
	return true;
}
bool CategoryTabListener::OnTabMouseOut(class ICategoryTab* list, int index)
{
	if (true == TabMouseOutCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CCategoryTab*>(list)));
		args.set(1, ScriptObject(index));
		TabMouseOutCb.function.invoke(args);
	}
	return true;
}
bool CategoryTabListener::OnLeftArrowsClicked(class ICategoryTab* list)
{
	if (true == LeftArrowsClickedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CCategoryTab*>(list)));
		LeftArrowsClickedCb.function.invoke(args);
	}
	return true;
}
bool CategoryTabListener::OnRightArrowsClicked(class ICategoryTab* list)
{
	if (true == RightArrowsClickedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CCategoryTab*>(list)));
		RightArrowsClickedCb.function.invoke(args);
	}
	return true;
}

void CategoryTabListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	context.bindFunction<CategoryTabListener, &CategoryTabListener::GetTabChangedCallBack, &CategoryTabListener::SetTabChangedCallBack>("onTabChanged");
	context.bindFunction<CategoryTabListener, &CategoryTabListener::GetTabClickedCallBack, &CategoryTabListener::SetTabClickedCallBack>("onTabClicked");
	context.bindFunction<CategoryTabListener, &CategoryTabListener::GetTabMouseInCallBack, &CategoryTabListener::SetTabMouseInCallBack>("onTabMouseIn");
	context.bindFunction<CategoryTabListener, &CategoryTabListener::GetTabMouseOutCallBack, &CategoryTabListener::SetTabMouseOutCallBack>("onTabMouseOut");
	context.bindFunction<CategoryTabListener, &CategoryTabListener::GetLeftArrowsClickedCallBack, &CategoryTabListener::SetLeftArrowsClickedCallBack>("onLeftArrowsClicked");
	context.bindFunction<CategoryTabListener, &CategoryTabListener::GetRightArrowsClickedCallBack, &CategoryTabListener::SetRightArrowsClickedCallBack>("onRightArrowsClicked");
}

void* CategoryTabListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new CategoryTabListener;
}

void Bridge::CategoryTabBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);
	context.captureMethodCall<CCategoryTab, &resize>("resize");
	context.captureMethodCall<CCategoryTab, &setMargin>("setMargin");
	context.captureMethodCall<CCategoryTab, &setTabSpacing>("setTabSpacing");
	context.captureMethodCall<CCategoryTab, &setTabSpliterSize>("setTabSpliterSize");
	context.captureMethodCall<CCategoryTab, &setTabSpliterImage>("setTabSpliterImage");
	context.captureMethodCall<CCategoryTab, &setTabSpliterColor>("setTabSpliterColor");

	context.captureMethodCall<CCategoryTab, &enableLooping>("enableLooping");

	context.captureMethodCall<CCategoryTab, &setTabFont>("setTabFont");  //text
	context.captureMethodCall<CCategoryTab, &setTabFont>("setTabFontName");  //text
	context.captureMethodCall<CCategoryTab, &setTabFontSize>("setTabFontSize");   //text button
	context.captureMethodCall<CCategoryTab, &setTabTextColor>("setTabTextColor");
	context.captureMethodCall<CCategoryTab, &setTabImage>("setTabImage");
	context.captureMethodCall<CCategoryTab, &setTabColor>("setTabColor");
	context.captureMethodCall<CCategoryTab, &setTabText>("setTabText");

	context.captureMethodCall<CCategoryTab, &setArrowsSize>("setArrowsSize");
	context.captureMethodCall<CCategoryTab, &setArrowsImage>("setArrowsImage");

	context.captureMethodCall<CCategoryTab, &setBackgroundImage>("setBackgroundImage");
	context.captureMethodCall<CCategoryTab, &setBackgroundColor>("setBackgroundColor");

	context.captureMethodCall<CCategoryTab, &addTab>("addTab");
	context.captureMethodCall<CCategoryTab, &removeTab>("removeTab");

	context.captureMethodCall<CCategoryTab, &currentTabIndex>("currentTabIndex");
	context.captureMethodCall<CCategoryTab, &currentTabText>("currentTabText");
	context.captureMethodCall<CCategoryTab, &tabText>("tabText");

	context.captureMethodCall<CCategoryTab, &changeTab>("changeTab");
	context.captureMethodCall<CCategoryTab, &numberOfTab>("numberOfTab");

	context.captureMethodCall<CCategoryTab, &addCategoryTabListener>("addCategoryTabListener");
	context.captureMethodCall<CCategoryTab, &removeCategoryTabListener>("removeCategoryTabListener");

	context.captureMethodCall<CCategoryTab, &setTabTextMargin>("setTabTextMargin");
	context.captureMethodCall<CCategoryTab, &getTabTextMargin>("getTabTextMargin");
	context.captureMethodCall<CCategoryTab, &enableHighlightBar>("enableHightlightBar");
	context.captureMethodCall<CCategoryTab, &enableHighlightBar>("enableHighlightBar");
	context.captureMethodCall<CCategoryTab, &setHighlightBarHeight>("setHighlightBarHeight");
	context.captureMethodCall<CCategoryTab, &getHighlightBarHeight>("getHighlightBarHeight");
	context.captureMethodCall<CCategoryTab, &setHighlightBarColor>("setHighlightBarColor");
	context.captureMethodCall<CCategoryTab, &setTabTextLimitWidth>("setTabTextLimitNumber");
	context.captureMethodCall<CCategoryTab, &getTabTextLimitWidth>("getTabTextLimitNumber");
	context.captureMethodCall<CCategoryTab, &setTabTextLimitWidth>("setTabTextLimitWidth");
	context.captureMethodCall<CCategoryTab, &getTabTextLimitWidth>("getTabTextLimitWidth");
	context.captureMethodCall<CCategoryTab, &enableAlignTabsCenter>("enableAlignTabsCenter");
	context.captureMethodCall<CCategoryTab, &showTabIcon>("showTabIcon");
	context.captureMethodCall<CCategoryTab, &hideTabIcon>("hideTabIcon");
	context.captureMethodCall<CCategoryTab, &isTabIconShow>("isTabIconShow");

	context.captureMethodCall<CCategoryTab, &setTabIconImage>("setTabIconImage");
	context.captureMethodCall<CCategoryTab, &setTabIconSize>("setTabIconSize");
	context.captureMethodCall<CCategoryTab, &setTabIconMargin>("setTabIconMargin");
	context.captureMethodCall<CCategoryTab, &enableChangeTab>("setEnableChangeTab");
	context.captureMethodCall<CCategoryTab, &showFocus>("showFocus");
	context.captureMethodCall<CCategoryTab, &hideFocus>("hideFocus");
	context.captureMethodCall<CCategoryTab, &swapSubTab>("swapSubTab");
	context.captureMethodCall<CCategoryTab, &hideTabCheckBox>("hideTabCheckBox");
	context.captureMethodCall<CCategoryTab, &showTabCheckBox>("showTabCheckBox");
	context.captureMethodCall<CCategoryTab, &showTabLeftImage>("showTabLeftImage");
	context.captureMethodCall<CCategoryTab, &showTabRightImage>("showTabRightImage");
	context.captureMethodCall<CCategoryTab, &hideTabLeftImage>("hideTabLeftImage");
	context.captureMethodCall<CCategoryTab, &hideTabRightImage>("hideTabRightImage");
	context.captureMethodCall<CCategoryTab, &setTabLeftImage>("setTabLeftImage");
	context.captureMethodCall<CCategoryTab, &setTabRightImage>("setTabRightImage");
	context.captureMethodCall<CCategoryTab, &enableDragSubTab>("enableDragSubTab");
	context.captureMethodCall<CCategoryTab, &getTabCheckBoxSelectedIndexes>("getTabCheckBoxSelectedIndexes");
	context.captureMethodCall<CCategoryTab, &setTabChecked>("setTabChecked");
	context.captureMethodCall<CCategoryTab, &isTabChecked>("isTabChecked"); 
	context.captureMethodCall<CCategoryTab, &enableAutoShowImage>("enableAutoShowImage");
	context.captureMethodCall<CCategoryTab, &getTabWidth>("getTabWidth");
	context.captureMethodCall<CCategoryTab, &getTabHeight>("getTabHeight");
	context.captureMethodCall<CCategoryTab, &getTabX>("getTabX");
	context.captureMethodCall<CCategoryTab, &getTabY>("getTabY");
	context.captureMethodCall<CCategoryTab, &setTabScrollAttribute>("setTabScrollAttribute");

	context.bindString<CCategoryTab, &CCategoryTab::TabFont, &CCategoryTab::SetTabFont>("tabFont");
	context.bindString<CCategoryTab, &CCategoryTab::LeftArrowsImage, &CCategoryTab::SetLeftArrowsImage>("leftArrowImage");
	context.bindString<CCategoryTab, &CCategoryTab::RightArrowsImage, &CCategoryTab::SetRightArrowsImage>("rightArrowImage");
	context.bindString<CCategoryTab, &CCategoryTab::BackgroundImage, &CCategoryTab::SetBackgroundImage>("backgroundImage");
	context.bindBoolean<CCategoryTab, &CCategoryTab::IsLoopingEnabled, &CCategoryTab::EnableLooping>("isEnableLooping");
	context.bindBoolean<CCategoryTab, &CCategoryTab::IsHightlightBarEnabled, &CCategoryTab::EnableHighlightBar>("isEnableHighlightbar");
	context.bindBoolean<CCategoryTab, &CCategoryTab::IsAlignTabsCenterEnabled, &CCategoryTab::EnableAlignTabsCenter>("isEnableAligntabsCenter");
	context.bindBoolean<CCategoryTab, &CCategoryTab::IsChangeTabEnabled, &CCategoryTab::EnableChangeTab>("enableChangeTab");
	context.bindBoolean<CCategoryTab, &CCategoryTab::IsTabsKeyEnabled, &CCategoryTab::EnableTabsKey>("enableTabsKey");
	context.bindBoolean<CCategoryTab, &CCategoryTab::IsHighlightBarBottom, &CCategoryTab::EnableHighlightBarBottom>("highlightbarBottom");
	context.bindNumber<CCategoryTab, float, &CCategoryTab::TabTextLimitWidth, &CCategoryTab::SetTabTextLimitWidth>("textLimit");
	context.bindNumber<CCategoryTab, float, &CCategoryTab::TabTextLeftMargin, &CCategoryTab::SetTabTextLeftMargin>("textMargin");
	context.bindNumber<CCategoryTab, float, &CCategoryTab::TabTextLeftMargin, &CCategoryTab::SetTabTextLeftMargin>("textLeftMargin");
	context.bindNumber<CCategoryTab, float, &CCategoryTab::TabTextRightMargin, &CCategoryTab::SetTabTextRightMargin>("textRightMargin");
	context.bindNumber<CCategoryTab, float, &CCategoryTab::TabIconMargin, &CCategoryTab::SetTabIconMargin>("iconMargin");
}

Widget* Bridge::CategoryTabBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	if (width < 0)
	{
		width = 0;
	}
	if (height < 0)
	{
		height = 0;
	}
	CCategoryTab* tab = new CCategoryTab;
	tab->Initialize(parent, width, height);
	tab->SetPosition(x, y);

	ScriptObject options = args[0];
	Color bgColor = Color(255, 255, 255, 255);
	if (options.has("color"))
	{
		bgColor = ScriptToColor(options.get("color"));

	}
	tab->SetBackgroundColor(*bgColor.toClutterColor());
	if (options.has("margin"))
	{
		if (options.get("margin").has("left") && options.get("margin").has("right") && options.get("margin").has("top") && options.get("margin").has("bottom"))
		{
			float top = 0, bottom = 0, left = 0, right = 0;
			top = static_cast<float>(options.get("margin")["top"].asNumber());
			bottom = static_cast<float>(options.get("margin")["bottom"].asNumber());
			left = static_cast<float>(options.get("margin")["left"].asNumber());
			right = static_cast<float>(options.get("margin")["right"].asNumber());
			tab->SetMargin(top, bottom, left, right);
		}
	}
	if (options.has("spliterSize"))
	{
		if (options.get("spliterSize").has("w") && options.get("spliterSize").has("h"))
		{
			float width = 0, height = 0;
			width = static_cast<float>(options.get("spliterSize")["w"].asNumber());
			height = static_cast<float>(options.get("spliterSize")["h"].asNumber());
			tab->SetSpliterSize(width, height, -1);
		}
	}
	if (options.has("enableLooping"))
	{
		tab->EnableLooping(options.get("enableLooping").asBool());
	}
	if (options.has("tabFont"))
	{
		tab->SetTabFont(options.get("tabFont").asString().data());
	}
	if (options.has("unselectedFontSize"))
	{
		tab->SetTabFontSize(ICategoryTab::STATE_UNSELECTED, static_cast<int>(options.get("unselectedFontSize").asNumber()));
	}
	if (options.has("selectedFontSize"))
	{
		tab->SetTabFontSize(ICategoryTab::STATE_SELECTED, static_cast<int>(options.get("selectedFontSize").asNumber()));
	}
	if (options.has("highlightedFontSize"))
	{
		tab->SetTabFontSize(ICategoryTab::STATE_HIGHLIGHTED, static_cast<int>(options.get("highlightedFontSize").asNumber()));
	}
	if (options.has("arrowSize"))
	{
		if (options.get("arrowSize").has("w") && options.get("arrowSize").has("h"))
		{
			float width = 0, height = 0;
			width = static_cast<float>(options.get("arrowSize")["w"].asNumber());
			height = static_cast<float>(options.get("arrowSize")["h"].asNumber());
			tab->SetLeftArrowsSize(width, height);
			tab->SetRightArrowsSize(width, height);
		}
	}
	if (options.has("leftArrowImage"))
	{
		tab->SetLeftArrowsImage(options.get("leftArrowImage").asString());
	}
	if (options.has("rightArrowImage"))
	{
		tab->SetRightArrowsImage(options.get("rightArrowImage").asString());
	}
	if (options.has("backgroundImage"))
	{
		tab->SetBackgroundImage(options.get("backgroundImage").asString());
	}
	if (options.has("highlightbarColor"))
	{
		bgColor = ScriptToColor(options.get("highlightbarColor"));
		tab->SetHighlightBarColor(*bgColor.toClutterColor());
	}
	if (options.has("highlightbarFocusedColor"))
	{
		bgColor = ScriptToColor(options.get("highlightbarFocusedColor"));
		tab->SetHighlightBarFocusedColor(*bgColor.toClutterColor());
	}
	if (options.has("highlightbarUnfocusedColor"))
	{
		bgColor = ScriptToColor(options.get("highlightbarUnfocusedColor"));
		tab->SetHighlightBarUnfocusedColor(*bgColor.toClutterColor());
	}
	if (options.has("spliterImage"))
	{
		tab->SetSpliterImage(options.get("spliterImage").asString());
	}
	if (options.has("spliterColor"))
	{
		bgColor = ScriptToColor(options.get("spliterColor"));
		tab->SetSpliterColor(*bgColor.toClutterColor());
	}
	if (options.has("enableHighlightbar"))
	{
		tab->EnableHighlightBar(options.get("enableHighlightbar").asBool());
	}
	if (options.has("highlightbarHeight"))
	{
		tab->SetHighlightBarHeight(static_cast<float>(options.get("highlightbarHeight").asNumber()));
	}
	if (options.has("textLeftMargin"))
	{
		tab->SetTabTextLeftMargin(static_cast<float>(options.get("textLeftMargin").asNumber()));
	}
	if (options.has("textRightMargin"))
	{
		tab->SetTabTextRightMargin(static_cast<float>(options.get("textRightMargin").asNumber()));
	}
	if (options.has("textMargin"))
	{
		tab->SetTabTextLeftMargin(static_cast<float>(options.get("textMargin").asNumber()));
		tab->SetTabTextRightMargin(static_cast<float>(options.get("textMargin").asNumber()));
	}
	if (options.has("textLimit"))
	{
		tab->SetTabTextLimitWidth(static_cast<float>(options.get("textLimit").asNumber()));
	}
	if (options.has("enableAlignTabsCenter"))
	{
		tab->EnableAlignTabsCenter(options.get("enableAlignTabsCenter").asBool());
	}
	if (options.has("enableAlignTabscenter"))
	{
		tab->EnableAlignTabsCenter(options.get("enableAlignTabscenter").asBool());
	}
	if (options.has("enableAligntabsCenter"))
	{
		tab->EnableAlignTabsCenter(options.get("enableAlignTabscenter").asBool());
	}
	if (options.has("tabIconImage"))
	{
		int alpha = 255;
		if (options.has("tabIconAlpha"))
		{
			alpha = static_cast<int>(options.get("tabIconAlpha").asNumber());
		}
		tab->SetTabIconImage(CCategoryTab::STATE_ALL, options.get("tabIconImage").asString(), alpha, -1);
	}
	if (options.has("tabIconSize"))
	{
		if (options.get("tabIconSize").has("w") && options.get("tabIconSize").has("h"))
		{
			float width = 0, height = 0;
			width = static_cast<float>(options.get("tabIconSize")["w"].asNumber());
			height = static_cast<float>(options.get("tabIconSize")["h"].asNumber());
			tab->SetTabIconSize(width, height, -1);
		}
	}
	if (options.has("tabIconMargin"))
	{
		tab->SetTabIconMargin(static_cast<float>(options.get("tabIconMargin").asNumber()));
	}
	if (options.has("enableChangetab"))
	{
		tab->EnableChangeTab(options.get("enableChangetab").asBool());
	}
	if (options.has("highligthFocusAnimation"))
	{
		if (options.get("highligthFocusAnimation").has("unfocus") && options.get("highligthFocusAnimation").has("focused") && options.get("highligthFocusAnimation").has("duration"))
		{
			float unfocusHeight = -1, focusHeight = -1, time = -1;
			unfocusHeight = static_cast<float>(options.get("highligthFocusAnimation")["unfocus"].asNumber());
			focusHeight = static_cast<float>(options.get("highligthFocusAnimation")["focused"].asNumber());
			time = static_cast<int>(options.get("highligthFocusAnimation")["duration"].asNumber());
			tab->SetHighlightBarFocusAnimation(unfocusHeight, focusHeight, CCategoryTab::ANIMATION_CUSTOM_MODE, time);
		}
	}
	if (options.has("highligthMoveAnimation"))
	{
		if (options.get("highligthMoveAnimation").has("duration"))
		{
			int time = -1;
			time = static_cast<int>(options.get("highligthMoveAnimation")["duration"].asNumber());
			tab->SetHighlightBarMoveAnimation(CCategoryTab::ANIMATION_CUSTOM_MODE, time);
		}
	}
	if (options.has("highligthMoveAnimationDuration"))
	{
		int time = static_cast<int>(options.get("highligthMoveAnimationDuration").asNumber());
		tab->SetHighlightBarMoveAnimation(CCategoryTab::ANIMATION_CUSTOM_MODE, time);
	}
	if (options.has("highlightFocusAnimation"))
	{
		if (options.get("highlightFocusAnimation").has("unfocus") && options.get("highlightFocusAnimation").has("focused") && options.get("highlightFocusAnimation").has("duration"))
		{
			float unfocusHeight = -1, focusHeight = -1, time = -1;
			unfocusHeight = static_cast<float>(options.get("highlightFocusAnimation")["unfocus"].asNumber());
			focusHeight = static_cast<float>(options.get("highlightFocusAnimation")["focused"].asNumber());
			time = static_cast<int>(options.get("highlightFocusAnimation")["duration"].asNumber());
			tab->SetHighlightBarFocusAnimation(unfocusHeight, focusHeight, CCategoryTab::ANIMATION_CUSTOM_MODE, time);
		}		
	}
	if (options.has("highlightMoveAnimation"))
	{
		if (options.get("highlightMoveAnimation").has("duration"))
		{
			int time = -1;
			time = static_cast<int>(options.get("highlightMoveAnimation")["duration"].asNumber());
			tab->SetHighlightBarMoveAnimation(CCategoryTab::ANIMATION_CUSTOM_MODE, time);
		}
	}
	if (options.has("highlightMoveAnimationDuration"))
	{
		int time = static_cast<int>(options.get("highlightMoveAnimationDuration").asNumber());
		tab->SetHighlightBarMoveAnimation(CCategoryTab::ANIMATION_CUSTOM_MODE, time);
	}
	if (options.has("tabCheckimage"))
	{
		if (options.get("tabCheckimage").has("normal"))
		{
			tab->SetTabCheckImage(CCategoryTab::STATE_SELECT_NORMAL, options.get("tabCheckimage")["normal"].asString());
		}
		if (options.get("tabCheckimage").has("focused"))
		{
			tab->SetTabCheckImage(CCategoryTab::STATE_SELECT_FOCUSED, options.get("tabCheckimage")["focused"].asString());
		}
		if (options.get("tabCheckimage").has("selected"))
		{
			tab->SetTabCheckImage(CCategoryTab::STATE_SELECT_SELECTED, options.get("tabCheckimage")["selected"].asString());
		}
		if (options.get("tabCheckimage").has("all"))
		{
			tab->SetTabCheckImage(CCategoryTab::STATE_SELECT_ALL, options.get("tabCheckimage")["all"].asString());
		}
	}
	if (options.has("tabBoxbackgroundimage"))
	{
		if (options.get("tabBoxbackgroundimage").has("normal"))
		{
			tab->SetTabBoxBackGroudImage(CCategoryTab::STATE_SELECT_NORMAL, options.get("tabBoxbackgroundimage")["normal"].asString());
		}
		if (options.get("tabBoxbackgroundimage").has("focused"))
		{
			tab->SetTabBoxBackGroudImage(CCategoryTab::STATE_SELECT_FOCUSED, options.get("tabBoxbackgroundimage")["focused"].asString());
		}
		if (options.get("tabBoxbackgroundimage").has("selected"))
		{
			tab->SetTabBoxBackGroudImage(CCategoryTab::STATE_SELECT_SELECTED, options.get("tabBoxbackgroundimage")["selected"].asString());
		}
		if (options.get("tabBoxbackgroundimage").has("all"))
		{
			tab->SetTabBoxBackGroudImage(CCategoryTab::STATE_SELECT_ALL, options.get("tabBoxbackgroundimage")["all"].asString());
		}
	}
	if (options.has("tabCheckimageOpacity"))
	{
		if (options.get("tabCheckimageOpacity").has("normal"))
		{
			tab->SetTabCheckImageOpacity(CCategoryTab::STATE_SELECT_NORMAL, static_cast<int>(options.get("tabCheckimageOpacity")["normal"].asNumber()));
		}
		if (options.get("tabCheckimageOpacity").has("focused"))
		{
			tab->SetTabCheckImageOpacity(CCategoryTab::STATE_SELECT_FOCUSED, static_cast<int>(options.get("tabCheckimageOpacity")["focused"].asNumber()));
		}
		if (options.get("tabCheckimageOpacity").has("selected"))
		{
			tab->SetTabCheckImageOpacity(CCategoryTab::STATE_SELECT_SELECTED, static_cast<int>(options.get("tabCheckimageOpacity")["selected"].asNumber()));
		}
		if (options.get("tabCheckimageOpacity").has("all"))
		{
			tab->SetTabCheckImageOpacity(CCategoryTab::STATE_SELECT_ALL, static_cast<int>(options.get("tabCheckimageOpacity")["all"].asNumber()));
		}
	}
	if (options.has("tabBoxbackgroundimageOpacity"))
	{
		if (options.get("tabBoxbackgroundimageOpacity").has("normal"))
		{
			tab->SetTabBoxBackGroudImageOpacity(CCategoryTab::STATE_SELECT_NORMAL, static_cast<int>(options.get("tabBoxbackgroundimageOpacity")["normal"].asNumber()));
		}
		if (options.get("tabBoxbackgroundimageOpacity").has("focused"))
		{
			tab->SetTabBoxBackGroudImageOpacity(CCategoryTab::STATE_SELECT_FOCUSED, static_cast<int>(options.get("tabBoxbackgroundimageOpacity")["focused"].asNumber()));
		}
		if (options.get("tabBoxbackgroundimageOpacity").has("selected"))
		{
			tab->SetTabBoxBackGroudImageOpacity(CCategoryTab::STATE_SELECT_SELECTED, static_cast<int>(options.get("tabBoxbackgroundimageOpacity")["selected"].asNumber()));
		}
		if (options.get("tabBoxbackgroundimageOpacity").has("all"))
		{
			tab->SetTabBoxBackGroudImageOpacity(CCategoryTab::STATE_SELECT_ALL, static_cast<int>(options.get("tabBoxbackgroundimageOpacity")["all"].asNumber()));
		}
	}
	if (options.has("tabLeftImage"))
	{
		if (options.get("tabLeftImage").has("w") && options.get("tabLeftImage").has("h") && options.get("tabLeftImage").has("m"))
		{
			float width = 0, height = 0, margin = 0;
			width = static_cast<float>(options.get("tabLeftImage")["w"].asNumber());
			height = static_cast<float>(options.get("tabLeftImage")["h"].asNumber());
			margin = static_cast<float>(options.get("tabLeftImage")["m"].asNumber());
			tab->SetTabLeftImageSize(width, height, margin);
		}
	}
	if (options.has("tabRightImage"))
	{
		if (options.get("tabRightImage").has("w") && options.get("tabRightImage").has("h") && options.get("tabRightImage").has("m"))
		{
			float width = 0, height = 0, margin = 0;
			width = static_cast<float>(options.get("tabRightImage")["w"].asNumber());
			height = static_cast<float>(options.get("tabRightImage")["h"].asNumber());
			margin = static_cast<float>(options.get("tabRightImage")["m"].asNumber());
			tab->SetTabRightImageSize(width, height, margin);
		}
	}
	if (options.has("tabLeftImagePath"))
	{
		tab->SetTabLeftImagePath(options.get("tabLeftImagePath").asString(), -1);
	}
	if (options.has("tabRightImagePath"))
	{
		tab->SetTabRightImagePath(options.get("tabRightImagePath").asString(), -1);
	}

	if (options.has("tabCheckBox"))
	{
		
		if (options.get("tabCheckBox").has("w") && options.get("tabCheckBox").has("h"))
		{
			float width = 0, height = 0;
			width = static_cast<float>(options.get("tabCheckBox")["w"].asNumber());
			height = static_cast<float>(options.get("tabCheckBox")["h"].asNumber());
			tab->SetTabCheckBoxSize(width, height);
		}
		if (options.get("tabCheckBox").has("m"))
		{
			float margin = 0;
			margin = static_cast<float>(options.get("tabCheckBox")["m"].asNumber());
			tab->SetTabCheckBoxMargin(margin);
		}
	}
	if (options.has("swapSubTabDuration"))
	{
		tab->SetSwapSubTabDuration(static_cast<int>(options.get("swapSubTabDuration").asNumber()));
	}
	if (options.has("tabTargetHeightMin"))
	{
		tab->SetTabTargetHeight(static_cast<float>(options.get("tabTargetHeightMin").asNumber()), -1);
	}
	if (options.has("tabTargetHeightMax"))
	{
		tab->SetTabTargetHeight(-1, static_cast<float>(options.get("tabTargetHeightMax").asNumber()));
	}
	if (options.has("tabTextScroll"))
	{
		int duration = 2500;
		float speed = 0.06f;
		int delay = 0;
		int repeat = -1;
		ClutterTextScrollType scrollType = CLUTTER_TEXT_SCROLL_START_OUTSIDE_STOP_OUTSIDE;
		ClutterTimelineDirection direction = CLUTTER_TIMELINE_BACKWARD;
		int continueGap = 0;

		if (options.get("tabTextScroll").has("duration"))
		{
			duration = static_cast<int>(options.get("tabTextScroll")["duration"].asNumber());
		}
		if (options.get("tabTextScroll").has("speed"))
		{
			speed = static_cast<float>(options.get("tabTextScroll")["speed"].asNumber());
		}
		if (options.get("tabTextScroll").has("delay"))
		{
			delay = static_cast<int>(options.get("tabTextScroll")["delay"].asNumber());
		}
		if (options.get("tabTextScroll").has("repeat"))
		{
			repeat = static_cast<int>(options.get("tabTextScroll")["repeat"].asNumber());
		}
		if (options.get("tabTextScroll").has("type"))
		{
			scrollType = deserializeTextScrollType(options.get("tabTextScroll")["type"].asString(), CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_OUTSIDE);
		}
		if (options.get("tabTextScroll").has("direction"))
		{
			direction = deserializeTextScrollDirection(options.get("tabTextScroll")["direction"].asString(), CLUTTER_TIMELINE_BACKWARD);
		}
		if (options.get("tabTextScroll").has("continueGap"))
		{
			continueGap = static_cast<int>(options.get("tabTextScroll")["continueGap"].asNumber());
		}
		tab->SetTabScrollAttribute(duration, speed, delay, repeat, scrollType, direction, continueGap);
	}
	return tab;
}

CCategoryTab::ECategoryTabState Bridge::CategoryTabBridge::deserializeState(std::string stateStr, CCategoryTab::ECategoryTabState theDefault)
{
	if (compareStrChar(stateStr, "unselected"))
	{
		return CCategoryTab::STATE_UNSELECTED;
	}
	else if (compareStrChar(stateStr, "selected"))
	{
		return CCategoryTab::STATE_SELECTED;
	}
	else if (compareStrChar(stateStr, "highlighted"))
	{
		return CCategoryTab::STATE_HIGHLIGHTED;
	}
	else if (compareStrChar(stateStr, "all"))
	{
		return CCategoryTab::STATE_ALL;
	}
	else
	{
		ASSERT(false && "The state string is invalid!");
		return theDefault;
	}
}

Bridge::ScriptObject Bridge::CategoryTabBridge::resize(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 2)
	{
		float width = 0, height = 0;
		if (args.has(0) && args[0].isNumber())
		{
			width = static_cast<float>(args[0].asNumber());
		}
		if (args.has(1) && args[1].isNumber())
		{
			height = static_cast<float>(args[1].asNumber());
		}
		self->Resize(width, height);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setMargin(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		float top = 0, bottom = 0, left = 0, right = 0;
		if (args.has(0) && args[0].isNumber())
		{
			top = static_cast<float>(args[0].asNumber());
		}
		if (args.has(1) && args[1].isNumber())
		{
			bottom = static_cast<float>(args[1].asNumber());
		}
		if (args.has(2) && args[2].isNumber())
		{
			left = static_cast<float>(args[2].asNumber());
		}
		if (args.has(3) && args[3].isNumber())
		{
			right = static_cast<float>(args[3].asNumber());
		}
		self->SetMargin(top, bottom, left, right);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabSpacing(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		float width = 0, height = 0;
		int index = -1;
		if (args.has(0) && args[0].isNumber())
		{
			width = static_cast<float>(args[0].asNumber());
		}
		if (args.has(1) && args[1].isNumber())
		{
			height = static_cast<float>(args[1].asNumber());
		}
		if (args.has(2) && args[2].isNumber())
		{
			index = static_cast<int>(args[2].asNumber());
		}
		self->SetSpliterSize(width, height, index);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabSpliterSize(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		float width = 0, height = 0;
		int index = -1;
		if (args.has(0) && args[0].isNumber())
		{
			width = static_cast<float>(args[0].asNumber());
		}
		if (args.has(1) && args[1].isNumber())
		{
			height = static_cast<float>(args[1].asNumber());
		}
		if (args.has(2) && args[2].isNumber())
		{
			index = static_cast<int>(args[2].asNumber());
		}
		self->SetSpliterSize(width, height, index);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::enableLooping(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isBool())
		{
			bool flag = args[0].asBool();
			self->EnableLooping(flag);
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabFont(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		std::string font;
		if (args.has(0) && args[0].isString())
		{
			font = args[0].asString();
		}
		self->SetTabFont(font);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabFontSize(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 1)
	{
		int size = 0;
		if (args.has(0) && args[0].isNumber())
		{
			size = static_cast<int>(args[0].asNumber());
		}
		self->SetTabFontSize(CCategoryTab::STATE_ALL, size);
	}
	else if (args.Length() > 1)
	{
		std::string state;
		int size = 0;
		if (args.has(0) && args[0].isString())
		{
			state = args[0].asString();
		}
		if (args.has(1) && args[1].isNumber())
		{
			size = static_cast<int>(args[1].asNumber());
		}
		self->SetTabFontSize(deserializeState(state, CCategoryTab::STATE_ALL), size);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabTextColor(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 4)
	{
		guint8 r = 0, g = 0, b = 0, a = 0;

		if (args.has(0) && args[0].isNumber()) 
		{ 
			r = (guint8)args[0].asNumber(); 
		}
		if (args.has(1) && args[1].isNumber()) 
		{ 
			g = (guint8)args[1].asNumber(); 
		}
		if (args.has(2) && args[2].isNumber()) 
		{ 
			b = (guint8)args[2].asNumber(); 
		}
		if (args.has(3) && args[3].isNumber()) 
		{ 
			a = (guint8)args[3].asNumber(); 
		}
		ClutterColor c = { r, g, b, a };
		self->SetTabTextColor(CCategoryTab::STATE_ALL, c);
	}
	else if (args.Length() > 4)
	{
		std::string state;
		if (args.has(0) && args[0].isString())
		{
			state = args[0].asString();
		}

		guint8 r = 0, g = 0, b = 0, a = 0;

		if (args.has(1) && args[1].isNumber())
		{
			r = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			g = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			b = (guint8)args[3].asNumber();
		}
		if (args.has(4) && args[4].isNumber())
		{
			a = (guint8)args[4].asNumber();
		}
		ClutterColor c = { r, g, b, a };
		self->SetTabTextColor(deserializeState(state, CCategoryTab::STATE_ALL), c);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabSpliterImage(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString())
		{
			self->SetSpliterImage(args[0].asString().data());
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabSpliterColor(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		guint8 r = 0, g = 0, b = 0, a = 0;

		if (args.has(0) && args[0].isNumber())
		{
			r = (guint8)args[0].asNumber();
		}
		if (args.has(1) && args[1].isNumber())
		{
			g = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			b = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			a = (guint8)args[3].asNumber();
		}
		ClutterColor c = { r, g, b, a };
		self->SetSpliterColor(c);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabImage(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 1)
	{
		if (args.has(0) && args[0].isString())
		{
			self->SetTabImage(CCategoryTab::STATE_ALL, args[0].asString().data());
		}
	}
	else if (args.Length() > 1)
	{
		std::string state;
		if (args.has(0) && args[0].isString())
		{
			state = args[0].asString();
			if (args.has(1) && args[1].isString())
			{
				self->SetTabImage(deserializeState(state, CCategoryTab::STATE_ALL), args[1].asString().data());
			}
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabColor(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 4)
	{
		guint8 r = 0, g = 0, b = 0, a = 0;

		if (args.has(0) && args[0].isNumber())
		{
			r = (guint8)args[0].asNumber();
		}
		if (args.has(1) && args[1].isNumber())
		{
			g = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			b = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			a = (guint8)args[3].asNumber();
		}
		ClutterColor c = { r, g, b, a };
		self->SetTabColor(CCategoryTab::STATE_ALL, c);
	}
	else if (args.Length() > 4)
	{
		std::string state;
		if (args.has(0) && args[0].isString())
		{
			state = args[0].asString();
		}

		guint8 r = 0, g = 0, b = 0, a = 0;

		if (args.has(1) && args[1].isNumber())
		{
			r = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			g = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			b = (guint8)args[3].asNumber();
		}
		if (args.has(4) && args[4].isNumber())
		{
			a = (guint8)args[4].asNumber();
		}
		ClutterColor c = { r, g, b, a };
		self->SetTabColor(deserializeState(state, CCategoryTab::STATE_ALL), c);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setArrowsSize(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		float left_width = 0, left_height = 0, right_width = 0, right_height = 0;
		if (args.has(0) && args[0].isNumber())
		{
			left_width = right_width = static_cast<float>(args[0].asNumber());
		}
		if (args.has(1) && args[1].isNumber())
		{
			left_height = right_height = static_cast<float>(args[1].asNumber());
		}
		if (args.has(2) && args[2].isNumber())
		{
			right_width = static_cast<float>(args[2].asNumber());
		}
		if (args.has(3) && args[3].isNumber())
		{
			right_height = static_cast<float>(args[3].asNumber());
		}
		self->SetLeftArrowsSize(left_width, left_height);
		self->SetRightArrowsSize(right_width, right_height);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setArrowsImage(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		if (args.has(0) && args[0].isString())
		{
			self->SetLeftArrowsImage(args[0].asString().data());
		}
		if (args.has(1) && args[1].isString())
		{
			self->SetRightArrowsImage(args[1].asString().data());
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setBackgroundImage(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString())
		{
			self->SetBackgroundImage(args[0].asString().data());
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setBackgroundColor(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		guint8 r = 0, g = 0, b = 0, a = 0;

		if (args.has(0) && args[0].isNumber())
		{
			r = (guint8)args[0].asNumber();
		}
		if (args.has(1) && args[1].isNumber())
		{
			g = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			b = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			a = (guint8)args[3].asNumber();
		}
		ClutterColor c = { r, g, b, a };
		self->SetBackgroundColor(c);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::addTab(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.Length() == 1 && args.has(0) && args[0].isString())
		{
			self->AddTab(args[0].asString().data());
		}
		else if (args.Length() == 2 && args.has(0) && args[0].isString())
		{
			int index = 0;
			if (args.has(1) && args[1].isNumber())
			{
				index = static_cast<int>(args[1].asNumber());
			}
			self->AddTab(args[0].asString().data(), index);
		}
		else if (args.Length() == 3 && args.has(0) && args[0].isString())
		{
			float width = 0, height = 0;
			if (args.has(1) && args[1].isNumber())
			{
				width = static_cast<float>(args[1].asNumber());
			}
			if (args.has(2) && args[2].isNumber())
			{
				height = static_cast<float>(args[2].asNumber());
			}
			self->AddTab(args[0].asString().data(), width, height);
		}
		else if (args.Length() == 4 && args.has(0) && args[0].isString())
		{
			float width = 0, height = 0;
			if (args.has(1) && args[1].isNumber())
			{
				width = static_cast<float>(args[1].asNumber());
			}
			if (args.has(2) && args[2].isNumber())
			{
				height = static_cast<float>(args[2].asNumber());
			}
			int index = 0;
			if (args.has(3) && args[3].isNumber())
			{
				index = static_cast<int>(args[3].asNumber());
			}
			self->AddTab(args[0].asString().data(), width, height, index);
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::removeTab(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			self->RemoveTab(static_cast<int>(args[0].asNumber()));
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::currentTabIndex(CCategoryTab* self, const ScriptArray& args)
{
	return ScriptObject(self->CurrentTabIndex());
}

Bridge::ScriptObject Bridge::CategoryTabBridge::currentTabText(CCategoryTab* self, const ScriptArray& args)
{
	return ScriptObject(self->CurrentTabText());
}

Bridge::ScriptObject Bridge::CategoryTabBridge::tabText(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			return ScriptObject(self->TabText(static_cast<int>(args[0].asNumber())));
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::changeTab(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			self->ChangeTab(static_cast<int>(args[0].asNumber()));
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::numberOfTab(CCategoryTab* self, const ScriptArray& args)
{
	return ScriptObject(self->NumberOfTab());
}

Bridge::ScriptObject Bridge::CategoryTabBridge::addCategoryTabListener(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		/*
		ICategoryTabChangedListener* listener = unwrapNativeObject<ICategoryTabChangedListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddTabChangedListener(listener);
		}
		*/
		CategoryTabListener *listener = unwrapNativeObject<CategoryTabListener>(args[0]);
		self->AddCategoryTabListener(listener);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::removeCategoryTabListener(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		/*
		ICategoryTabChangedListener* listener = unwrapNativeObject<ICategoryTabChangedListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveTabChangedListener(listener);
		}
		*/
		CategoryTabListener *listener = unwrapNativeObject<CategoryTabListener>(args[0]);
		self->RemoveCategoryTabListener(listener);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabTextMargin(CCategoryTab* self, const ScriptArray& args){	if (args.Length() > 0)
	{
		float leftMargin = 0, rightMargin = 0;
		if (args.has(0) && args[0].isNumber())
		{
			leftMargin = rightMargin = static_cast<float>(args[0].asNumber());
		}
		if (args.has(1) && args[1].isNumber())
		{
			rightMargin = static_cast<float>(args[1].asNumber());
		}
		self->SetTabTextLeftMargin(leftMargin);
		self->SetTabTextRightMargin(rightMargin);
	}
	return ScriptObject();}Bridge::ScriptObject Bridge::CategoryTabBridge::getTabTextMargin(CCategoryTab* self, const ScriptArray& args){	double num = -1;
	if (args.Length() < 1)
	{
		num = static_cast<double>(self->TabTextLeftMargin());
	}
	else if (args.has(0) && args[0].isString())
	{
		std::string side = args[0].asString();
		if (compareStrChar(side, "left"))
		{
			num = static_cast<double>(self->TabTextLeftMargin());
		}
		else if (compareStrChar(side, "right"))
		{
			num = static_cast<double>(self->TabTextRightMargin());
		}
	}
	return ScriptObject(num);}Bridge::ScriptObject Bridge::CategoryTabBridge::enableHighlightBar(CCategoryTab* self, const ScriptArray& args){	if (args.Length() == 1)
	{
		if (args.has(0) && args[0].isBool())
		{
			self->EnableHighlightBar(args[0].asBool());
		}
	}
	return ScriptObject();}Bridge::ScriptObject Bridge::CategoryTabBridge::setHighlightBarHeight(CCategoryTab* self, const ScriptArray& args){	if (args.Length() == 1)
	{
		if (args.has(0) && args[0].isNumber())
		{
			self->SetHighlightBarHeight(static_cast<float>(args[0].asNumber()));
		}
	}
	return ScriptObject();}Bridge::ScriptObject Bridge::CategoryTabBridge::getHighlightBarHeight(CCategoryTab* self, const ScriptArray& args){	double height = static_cast<double>(self->HighlightBarHeight());
	return ScriptObject(height);}Bridge::ScriptObject Bridge::CategoryTabBridge::setHighlightBarColor(CCategoryTab* self, const ScriptArray& args){	if (args.Length() == 4)
	{
		guint8 r = 0, g = 0, b = 0, a = 0;
		if (args.has(0) && args[0].isNumber())
		{
			r = (guint8)args[0].asNumber();
		}
		if (args.has(1) && args[1].isNumber())
		{
			g = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			b = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			a = (guint8)args[3].asNumber();
		}
		ClutterColor c = { r, g, b, a };
		self->SetHighlightBarColor(c);
	}	return ScriptObject();}Bridge::ScriptObject Bridge::CategoryTabBridge::setTabTextLimitWidth(CCategoryTab* self, const ScriptArray& args){	if (args.Length() == 1)
	{
		if (args.has(0) && args[0].isNumber())
		{
			self->SetTabTextLimitWidth(static_cast<float>(args[0].asNumber()));
		}
	}
	return ScriptObject();}Bridge::ScriptObject Bridge::CategoryTabBridge::getTabTextLimitWidth(CCategoryTab* self, const ScriptArray& args)
{
	double num = static_cast<double>(self->TabTextLimitWidth());
	return ScriptObject(num);
}

Bridge::ScriptObject Bridge::CategoryTabBridge::enableAlignTabsCenter(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 1)
	{
		if (args.has(0) && args[0].isBool())
		{
			self->EnableAlignTabsCenter(args[0].asBool());
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabIconImage(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 1 && args.has(0) && args[0].isString() && args.has(1) && args[1].isString())
	{
		std::string state;
		std::string image;
		int alpha = 255;
		int index = -1;
		state = args[0].asString();
		image = args[1].asString();
		if (args.has(2) && args[2].isNumber())
		{
			alpha = static_cast<int>(args[2].asNumber());
		}
		if (args.has(3) && args[3].isNumber())
		{
			index = static_cast<int>(args[3].asNumber());
		}
		self->SetTabIconImage(deserializeState(state, CCategoryTab::STATE_ALL), image, alpha, index);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabIconSize(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() >= 2)
	{
		if (args.has(0) && args[0].isNumber() && args.has(1) && args[1].isNumber())
		{
			float width = 0, height = 0;
			int index = -1;
			width = static_cast<float>(args[0].asNumber());
			height = static_cast<float>(args[1].asNumber());
			if (args.has(2) && args[2].isNumber())
			{
				index = static_cast<int>(args[2].asNumber());
			}
			self->SetTabIconSize(width, height, index);
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::showTabIcon(CCategoryTab* self, const ScriptArray& args)
{
	int index = -1;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			index = static_cast<int>(args[0].asNumber());
		}
	}
	self->ShowTabIcon(static_cast<int>(args[0].asNumber()));
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::hideTabIcon(CCategoryTab* self, const ScriptArray& args)
{
	int index = -1;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			index = static_cast<int>(args[0].asNumber());
		}
	}
	self->HideTabIcon(index);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::isTabIconShow(CCategoryTab* self, const ScriptArray& args)
{
	bool flag = false;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			flag = self->FlagTabIconShow(static_cast<int>(args[0].asNumber()));
		}
	}
	return ScriptObject(flag);
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabIconMargin(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			self->SetTabIconMargin(static_cast<float>(args[0].asNumber()));
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabText(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 2)
	{
		if (args.has(0) && args[0].isString() && args.has(1) && args[1].isNumber())
		{
			self->SetTabText(CCategoryTab::STATE_ALL, args[0].asString().data(), static_cast<int>(args[1].asNumber()));
		}
	}
	else if (args.Length() > 2)
	{
		if (args.has(0) && args[0].isString() && args.has(1) && args[1].isString() && args.has(2) && args[2].isNumber())
		{
			self->SetTabText(deserializeState(args[0].asString(), CCategoryTab::STATE_ALL), args[1].asString().data(), static_cast<int>(args[2].asNumber()));
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::enableChangeTab(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 1)
	{
		if (args.has(0) && args[0].isBool())
		{
			self->EnableChangeTab(args[0].asBool());
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::showFocus(CCategoryTab* self, const ScriptArray& args)
{
	self->ShowFocus();
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::hideFocus(CCategoryTab* self, const ScriptArray& args)
{
	self->HideFocus();
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::swapSubTab(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 2)
	{
		if (args.has(0) && args[0].isNumber() && args.has(1) && args[1].isNumber())
		{
			self->SwapSubTab(static_cast<int>(args[0].asNumber()), static_cast<int>(args[1].asNumber()));
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::hideTabCheckBox(CCategoryTab* self, const ScriptArray& args)
{
	self->HideTabCheckBox();
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::showTabCheckBox(CCategoryTab* self, const ScriptArray& args)
{
	self->ShowTabCheckBox();
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::showTabLeftImage(CCategoryTab* self, const ScriptArray& args)
{
	if (args.has(0) && args[0].isNumber())
	{
		self->ShowTabLeftImage(static_cast<int>(args[0].asNumber()));
	}
	return ScriptObject();
}
Bridge::ScriptObject Bridge::CategoryTabBridge::showTabRightImage(CCategoryTab* self, const ScriptArray& args)
{
	if (args.has(0) && args[0].isNumber())
	{
		self->ShowTabRightImage(static_cast<int>(args[0].asNumber()));
	}
	return ScriptObject();
}
Bridge::ScriptObject Bridge::CategoryTabBridge::hideTabLeftImage(CCategoryTab* self, const ScriptArray& args)
{
	self->HideTabLeftImage(static_cast<int>(args[0].asNumber()));
	return ScriptObject();
}
Bridge::ScriptObject Bridge::CategoryTabBridge::hideTabRightImage(CCategoryTab* self, const ScriptArray& args)
{
	self->HideTabRightImage(static_cast<int>(args[0].asNumber()));
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabLeftImage(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 2)
	{
		if (args.has(0) && args[0].isString() && args.has(1) && args[1].isNumber())
		{
			self->SetTabLeftImagePath(args[0].asString(), static_cast<int>(args[1].asNumber()));
		}
	}
	return ScriptObject();
}
Bridge::ScriptObject Bridge::CategoryTabBridge::setTabRightImage(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 2)
	{
		if (args.has(0) && args[0].isString() && args.has(1) && args[1].isNumber())
		{
			self->SetTabRightImagePath(args[0].asString(), static_cast<int>(args[1].asNumber()));
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::enableDragSubTab(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 1)
	{
		if (args.has(0) && args[0].isBool())
		{
			self->EnableDragTab(args[0].asBool());
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::getTabCheckBoxSelectedIndexes(CCategoryTab* self, const ScriptArray& args)
{
	std::vector<int> resultVector = self->GetTabCheckBoxSelectedIndexes();

	ScriptArray result;

	for (int i = 0; i < (int)resultVector.size(); i++)
	{
		result.set(i, ScriptObject(resultVector[i]));
	}

	return ScriptObject(result);
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabTargetHeight(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 2)
	{
		if (args.has(0) && args[0].isNumber() && args.has(1) && args[1].isNumber())
		{
			self->SetTabTargetHeight(static_cast<float>(args[0].asNumber()), static_cast<float>(args[1].asNumber()));
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabChecked(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 2)
	{
		if (args.has(0) && args[0].isNumber() && args.has(1) && args[1].isBool())
		{
			self->SetTabChecked(static_cast<int>(args[0].asNumber()), args[1].asBool());
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::isTabChecked(CCategoryTab* self, const ScriptArray& args)
{
	bool flag = false;
	if (args.Length() == 1)
	{
		if (args.has(0) && args[0].isNumber())
		{
			flag = self->IsTabChecked(static_cast<int>(args[0].asNumber()));
		}
	}
	return ScriptObject(flag);
}

Bridge::ScriptObject Bridge::CategoryTabBridge::enableAutoShowImage(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isBool())
		{
			self->EnableAutoShowImagesOnPressTab(args[0].asBool());
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::getTabWidth(CCategoryTab* self, const ScriptArray& args)
{
	float width = -1;
	float height = -1;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			self->GetTabSize(static_cast<int>(args[0].asNumber()), width, height);
		}
	}
	return ScriptObject(width);
}

Bridge::ScriptObject Bridge::CategoryTabBridge::getTabHeight(CCategoryTab* self, const ScriptArray& args)
{
	float width = -1;
	float height = -1;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			self->GetTabSize(static_cast<int>(args[0].asNumber()), width, height);
		}
	}
	return ScriptObject(height);
}

Bridge::ScriptObject Bridge::CategoryTabBridge::getTabX(CCategoryTab* self, const ScriptArray& args)
{
	int index = 0;
	float x = 0;
	float y = 0;
	bool flag = false;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			index = static_cast<int>(args[0].asNumber());
		}
		if (args.has(1) && args[1].isBool())
		{
			flag = args[1].asBool();
		}
		self->GetTabPosition(index, flag, x, y);
	}
	return ScriptObject(x);
}

Bridge::ScriptObject Bridge::CategoryTabBridge::getTabY(CCategoryTab* self, const ScriptArray& args)
{
	int index = 0;
	float x = 0;
	float y = 0;
	bool flag = false;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			index = static_cast<int>(args[0].asNumber());
		}
		if (args.has(1) && args[1].isBool())
		{
			flag = args[1].asBool();
		}
		self->GetTabPosition(index, flag, x, y);
	}
	return ScriptObject(y);
}

ClutterTimelineDirection CategoryTabBridge::deserializeTextScrollDirection(std::string directionStr, ClutterTimelineDirection theDefault)
{
	if (compareStrChar(directionStr, "forward")) { return CLUTTER_TIMELINE_FORWARD; }
	else if (compareStrChar(directionStr, "backward")) { return CLUTTER_TIMELINE_BACKWARD; }
	else { return theDefault; }
}

ClutterTextScrollType CategoryTabBridge::deserializeTextScrollType(std::string typeStr, ClutterTextScrollType theDefault)
{
	if (compareStrChar(typeStr, "start_outside_stop_outside")) { return CLUTTER_TEXT_SCROLL_START_OUTSIDE_STOP_OUTSIDE; }
	else if (compareStrChar(typeStr, "start_outside_stop_inside")) { return CLUTTER_TEXT_SCROLL_START_OUTSIDE_STOP_INSIDE; }
	else if (compareStrChar(typeStr, "start_inside_stop_outside")) { return CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_OUTSIDE; }
	else if (compareStrChar(typeStr, "start_inside_stop_inside")) { return CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_INSIDE; }
	else if (compareStrChar(typeStr, "continuous_scroll")) { return CLUTTER_TEXT_SCROLL_CONTINUOUS_SCROLL; }
	else { return theDefault; }
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabScrollAttribute(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 6)
	{
		int duration = 2500;
		float speed = 0.06f;
		int delay = 0;
		int repeat = -1;
		ClutterTextScrollType scrollType = CLUTTER_TEXT_SCROLL_START_OUTSIDE_STOP_OUTSIDE;
		ClutterTimelineDirection direction = CLUTTER_TIMELINE_BACKWARD;
		int continueGap = 0;

		if (args.has(0) && args[0].isNumber())
		{
			duration = static_cast<int>(args[0].asNumber());
		}
		if (args.has(1) && args[1].isNumber())
		{
			speed = static_cast<float>(args[1].asNumber());
		}
		if (args.has(2) && args[2].isNumber())
		{
			delay = static_cast<int>(args[2].asNumber());
		}
		if (args.has(3) && args[3].isNumber())
		{
			repeat = static_cast<int>(args[3].asNumber());
		}
		if (args.has(4) && args[4].isString())
		{
			scrollType = deserializeTextScrollType(args[4].asString(), CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_OUTSIDE);
		}
		if (args.has(5) && args[5].isString())
		{
			direction = deserializeTextScrollDirection(args[5].asString(), CLUTTER_TIMELINE_BACKWARD);
		}
		if (args.has(6) && args[6].isNumber())
		{
			continueGap = static_cast<int>(args[6].asNumber());
		}
		self->SetTabScrollAttribute(duration, speed, delay, repeat, scrollType, direction, continueGap);
	}

	return ScriptObject();
}