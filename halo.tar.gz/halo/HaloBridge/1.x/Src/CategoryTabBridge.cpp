#include "HaloBridgeAll.h"

using namespace HALO;
using namespace Bridge;

bool CategoryTabChangedListener::OnTabChanged(class ICategoryTab* list, int index)
{
	if (true == TabChangedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CCategoryTab*>(list)));
		args.set(1, ScriptObject(index));
		TabChangedCb.function.invoke(args);
	}
	return true;
}

void CategoryTabListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	context.bindFunction<CategoryTabChangedListener, &CategoryTabChangedListener::GetTabChangedCallBack, &CategoryTabChangedListener::SetTabChangedCallBack>("onTabChanged");
}

void* CategoryTabListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new CategoryTabChangedListener;
}

void Bridge::CategoryTabBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);
	context.captureMethodCall<CCategoryTab, &resize>("resize");
	context.captureMethodCall<CCategoryTab, &setMargin>("setMargin");
	context.captureMethodCall<CCategoryTab, &setTabSpacing>("setTabSpacing");
	context.captureMethodCall<CCategoryTab, &setTabSpliterSize>("setTabSpliterSize");
	context.captureMethodCall<CCategoryTab, &setTabSpliterImage>("setTabSpliterImage");
	context.captureMethodCall<CCategoryTab, &setTabSpliterColor>("setTabSpliterColor");

	context.captureMethodCall<CCategoryTab, &enableLooping>("enableLooping");

	context.captureMethodCall<CCategoryTab, &setTabFont>("setTabFont");  //text
	context.captureMethodCall<CCategoryTab, &setTabFont>("setTabFontName");  //text
	context.captureMethodCall<CCategoryTab, &setTabFontSize>("setTabFontSize");   //text button
	context.captureMethodCall<CCategoryTab, &setTabTextColor>("setTabTextColor");
	context.captureMethodCall<CCategoryTab, &setTabImage>("setTabImage");
	context.captureMethodCall<CCategoryTab, &setTabColor>("setTabColor");

	context.captureMethodCall<CCategoryTab, &setArrowsSize>("setArrowsSize");
	context.captureMethodCall<CCategoryTab, &setArrowsImage>("setArrowsImage");

	context.captureMethodCall<CCategoryTab, &setBackgroundImage>("setBackgroundImage");
	context.captureMethodCall<CCategoryTab, &setBackgroundColor>("setBackgroundColor");

	context.captureMethodCall<CCategoryTab, &addTab>("addTab");
	context.captureMethodCall<CCategoryTab, &removeTab>("removeTab");

	context.captureMethodCall<CCategoryTab, &currentTabIndex>("currentTabIndex");
	context.captureMethodCall<CCategoryTab, &currentTabText>("currentTabText");
	context.captureMethodCall<CCategoryTab, &tabText>("tabText");

	context.captureMethodCall<CCategoryTab, &changeTab>("changeTab");
	context.captureMethodCall<CCategoryTab, &numberOfTab>("numberOfTab");

	context.captureMethodCall<CCategoryTab, &addTabChangedListener>("addTabChangedListener");
	context.captureMethodCall<CCategoryTab, &removeTabChangedListener>("removeTabChangedListener");

	context.captureMethodCall<CCategoryTab, &setTabTextMargin>("setTabTextMargin");
	context.captureMethodCall<CCategoryTab, &getTabTextMargin>("getTabTextMargin");
	context.captureMethodCall<CCategoryTab, &enableHightlightBar>("enableHightlightBar");
	context.captureMethodCall<CCategoryTab, &setHighlightBarHeight>("setHighlightBarHeight");
	context.captureMethodCall<CCategoryTab, &getHighlightBarHeight>("getHighlightBarHeight");
	context.captureMethodCall<CCategoryTab, &setHighlightBarColor>("setHighlightBarColor");
	context.captureMethodCall<CCategoryTab, &setTabTextLimitWidth>("setTabTextLimitNumber");
	context.captureMethodCall<CCategoryTab, &getTabTextLimitWidth>("getTabTextLimitNumber");
	context.captureMethodCall<CCategoryTab, &setTabTextLimitWidth>("setTabTextLimitWidth");
	context.captureMethodCall<CCategoryTab, &getTabTextLimitWidth>("getTabTextLimitWidth");
	context.captureMethodCall<CCategoryTab, &enableAlignTabsCenter>("enableAlignTabsCenter");

	context.bindString<CCategoryTab, &CCategoryTab::TabFont, &CCategoryTab::SetTabFont>("tabFont");
	context.bindString<CCategoryTab, &CCategoryTab::LeftArrowsImage, &CCategoryTab::SetLeftArrowsImage>("leftArrowImage");
	context.bindString<CCategoryTab, &CCategoryTab::RightArrowsImage, &CCategoryTab::SetRightArrowsImage>("rightArrowImage");
	context.bindString<CCategoryTab, &CCategoryTab::BackgroundImage, &CCategoryTab::SetBackgroundImage>("backgroundImage");
	
	context.bindBoolean<CCategoryTab, &CCategoryTab::IsLoopingEnabled, &CCategoryTab::EnableLooping>("enableLooping");
	context.bindBoolean<CCategoryTab, &CCategoryTab::IsHightlightBarEnabled, &CCategoryTab::EnableHightlightBar>("enableHighlightbar");
	context.bindBoolean<CCategoryTab, &CCategoryTab::IsAlignTabsCenterEnabled, &CCategoryTab::EnableAlignTabsCenter>("enableAlignTabsCenter");
	context.bindNumber<CCategoryTab, float, &CCategoryTab::TabTextLimitWidth, &CCategoryTab::SetTabTextLimitWidth>("textLimit");
	context.bindNumber<CCategoryTab, float, &CCategoryTab::TabTextMargin, &CCategoryTab::SetTabTextMargin>("textMargin");
}

Widget* Bridge::CategoryTabBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	if (width < 0)
	{
		width = 0;
	}
	if (height < 0)
	{
		height = 0;
	}
	CCategoryTab* tab = new CCategoryTab;
	tab->Initialize(parent, width, height);
	tab->SetPosition(x, y);

	ScriptObject options = args[0];
	Color bgColor = Color(255, 255, 255, 255);
	if (options.has("color"))
	{
		bgColor = ScriptToColor(options.get("color"));

	}
	tab->SetBackgroundColor(*bgColor.toClutterColor());
	if (options.has("margin"))
	{
		if (options.get("margin").has("left") && options.get("margin").has("right") && options.get("margin").has("top") && options.get("margin").has("bottom"))
		{
			float top = 0, bottom = 0, left = 0, right = 0;
			top = static_cast<float>(options.get("margin")["top"].asNumber());
			top = static_cast<float>(options.get("margin")["bottom"].asNumber());
			top = static_cast<float>(options.get("margin")["left"].asNumber());
			top = static_cast<float>(options.get("margin")["right"].asNumber());
			tab->SetMargin(top, bottom, left, right);
		}
	}
	if (options.has("spliterSize"))
	{
		if (options.get("spliterSize").has("w") && options.get("spliterSize").has("h"))
		{
			float width = 0, height = 0;
			width = static_cast<float>(options.get("spliterSize")["w"].asNumber());
			height = static_cast<float>(options.get("spliterSize")["h"].asNumber());
			tab->SetSpliterSize(width, height);
		}
	}
	if (options.has("enableLooping"))
	{
		tab->EnableLooping(options.get("enableLooping").asBool());
	}
	if (options.has("tabFont"))
	{
		tab->SetTabFont(options.get("tabFont").asString().data());
	}
	if (options.has("arrowSize"))
	{
		if (options.get("arrowSize").has("w") && options.get("arrowSize").has("h"))
		{
			float width = 0, height = 0;
			width = static_cast<float>(options.get("arrowSize")["w"].asNumber());
			height = static_cast<float>(options.get("arrowSize")["h"].asNumber());
			tab->SetLeftArrowsSize(width, height);
			tab->SetRightArrowsSize(width, height);
		}
	}
	if (options.has("leftArrowImage"))
	{
		tab->SetLeftArrowsImage(options.get("leftArrowImage").asString());
	}
	if (options.has("rightArrowImage"))
	{
		tab->SetRightArrowsImage(options.get("rightArrowImage").asString());
	}
	if (options.has("backgroundImage"))
	{
		tab->SetBackgroundImage(options.get("backgroundImage").asString());
	}
	if (options.has("highlightbarColor"))
	{
		bgColor = ScriptToColor(options.get("highlightbarColor"));
		tab->SetHighlightBarColor(*bgColor.toClutterColor());
	}
	if (options.has("spliterImage"))
	{
		tab->SetSpliterImage(options.get("spliterImage").asString());
	}
	if (options.has("spliterColor"))
	{
		bgColor = ScriptToColor(options.get("spliterColor"));
		tab->SetSpliterColor(*bgColor.toClutterColor());
	}
	if (options.has("enableHighlightbar"))
	{
		tab->EnableHightlightBar(options.get("enableHighlightbar").asBool());
	}
	if (options.has("highlightbarHeight"))
	{
		tab->SetHighlightBarHeight(static_cast<float>(options.get("highlightbarHeight").asNumber()));
	}
	if (options.has("textMargin"))
	{
		tab->SetTabTextMargin(static_cast<float>(options.get("textMargin").asNumber()));
	}
	if (options.has("textLimit"))
	{
		tab->SetTabTextLimitWidth(static_cast<float>(options.get("textLimit").asNumber()));
	}
	if (options.has("enableAlignTabsCenter"))
	{
		tab->EnableAlignTabsCenter(options.get("enableAlignTabsCenter").asBool());
	}
	return tab;
}

CCategoryTab::ECategoryTabState Bridge::CategoryTabBridge::deserializeState(std::string stateStr, CCategoryTab::ECategoryTabState theDefault)
{
	if (compareStrChar(stateStr, "unselected"))
	{
		return CCategoryTab::STATE_UNSELECTED;
	}
	else if (compareStrChar(stateStr, "selected"))
	{
		return CCategoryTab::STATE_SELECTED;
	}
	else if (compareStrChar(stateStr, "highlighted"))
	{
		return CCategoryTab::STATE_HIGHLIGHTED;
	}
	else if (compareStrChar(stateStr, "all"))
	{
		return CCategoryTab::STATE_ALL;
	}
	else
	{
		ASSERT(false && "The state string is invalid!");
		return theDefault;
	}
}

Bridge::ScriptObject Bridge::CategoryTabBridge::resize(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 2)
	{
		float width = 0, height = 0;
		if (args.has(0) && args[0].isNumber())
		{
			width = static_cast<float>(args[0].asNumber());
		}
		if (args.has(1) && args[1].isNumber())
		{
			height = static_cast<float>(args[1].asNumber());
		}
		self->Resize(width, height);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setMargin(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		float top = 0, bottom = 0, left = 0, right = 0;
		if (args.has(0) && args[0].isNumber())
		{
			top = static_cast<float>(args[0].asNumber());
		}
		if (args.has(1) && args[1].isNumber())
		{
			bottom = static_cast<float>(args[1].asNumber());
		}
		if (args.has(2) && args[2].isNumber())
		{
			left = static_cast<float>(args[2].asNumber());
		}
		if (args.has(3) && args[3].isNumber())
		{
			right = static_cast<float>(args[3].asNumber());
		}
		self->SetMargin(top, bottom, left, right);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabSpacing(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		float width = 0, height = 0;
		if (args.has(0) && args[0].isNumber())
		{
			width = height = static_cast<float>(args[0].asNumber());
		}
		if (args.has(1) && args[1].isNumber())
		{
			height = static_cast<float>(args[1].asNumber());
		}
		self->SetSpliterSize(width, height);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabSpliterSize(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		float width = 0, height = 0;
		if (args.has(0) && args[0].isNumber())
		{
			width = static_cast<float>(args[0].asNumber());
		}
		if (args.has(1) && args[1].isNumber())
		{
			height = static_cast<float>(args[1].asNumber());
		}
		self->SetSpliterSize(width, height);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::enableLooping(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isBool())
		{
			bool flag = args[0].asBool();
			self->EnableLooping(flag);
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabFont(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		std::string font;
		if (args.has(0) && args[0].isString())
		{
			font = args[0].asString();
		}
		self->SetTabFont(font);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabFontSize(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 1)
	{
		int size = 0;
		if (args.has(0) && args[0].isNumber())
		{
			size = static_cast<int>(args[0].asNumber());
		}
		self->SetTabFontSize(CCategoryTab::STATE_ALL, size);
	}
	else if (args.Length() > 1)
	{
		std::string state;
		int size = 0;
		if (args.has(0) && args[0].isString())
		{
			state = args[0].asString();
		}
		if (args.has(1) && args[1].isNumber())
		{
			size = static_cast<int>(args[1].asNumber());
		}
		self->SetTabFontSize(deserializeState(state, CCategoryTab::STATE_ALL), size);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabTextColor(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 4)
	{
		guint8 r = 0, g = 0, b = 0, a = 0;

		if (args.has(0) && args[0].isNumber()) 
		{ 
			r = (guint8)args[0].asNumber(); 
		}
		if (args.has(1) && args[1].isNumber()) 
		{ 
			g = (guint8)args[1].asNumber(); 
		}
		if (args.has(2) && args[2].isNumber()) 
		{ 
			b = (guint8)args[2].asNumber(); 
		}
		if (args.has(3) && args[3].isNumber()) 
		{ 
			a = (guint8)args[3].asNumber(); 
		}
		ClutterColor c = { r, g, b, a };
		self->SetTabTextColor(CCategoryTab::STATE_ALL, c);
	}
	else if (args.Length() > 4)
	{
		std::string state;
		if (args.has(0) && args[0].isString())
		{
			state = args[0].asString();
		}

		guint8 r = 0, g = 0, b = 0, a = 0;

		if (args.has(1) && args[1].isNumber())
		{
			r = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			g = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			b = (guint8)args[3].asNumber();
		}
		if (args.has(4) && args[4].isNumber())
		{
			a = (guint8)args[4].asNumber();
		}
		ClutterColor c = { r, g, b, a };
		self->SetTabTextColor(deserializeState(state, CCategoryTab::STATE_ALL), c);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabSpliterImage(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString())
		{
			self->SetSpliterImage(args[0].asString().data());
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabSpliterColor(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		guint8 r = 0, g = 0, b = 0, a = 0;

		if (args.has(0) && args[0].isNumber())
		{
			r = (guint8)args[0].asNumber();
		}
		if (args.has(1) && args[1].isNumber())
		{
			g = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			b = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			a = (guint8)args[3].asNumber();
		}
		ClutterColor c = { r, g, b, a };
		self->SetSpliterColor(c);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabImage(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 1)
	{
		if (args.has(0) && args[0].isString())
		{
			self->SetTabImage(CCategoryTab::STATE_ALL, args[0].asString().data());
		}
	}
	else if (args.Length() > 1)
	{
		std::string state;
		if (args.has(0) && args[0].isString())
		{
			state = args[0].asString();
			if (args.has(1) && args[1].isString())
			{
				self->SetTabImage(deserializeState(state, CCategoryTab::STATE_ALL), args[1].asString().data());
			}
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabColor(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 4)
	{
		guint8 r = 0, g = 0, b = 0, a = 0;

		if (args.has(0) && args[0].isNumber())
		{
			r = (guint8)args[0].asNumber();
		}
		if (args.has(1) && args[1].isNumber())
		{
			g = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			b = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			a = (guint8)args[3].asNumber();
		}
		ClutterColor c = { r, g, b, a };
		self->SetTabColor(CCategoryTab::STATE_ALL, c);
	}
	else if (args.Length() > 4)
	{
		std::string state;
		if (args.has(0) && args[0].isString())
		{
			state = args[0].asString();
		}

		guint8 r = 0, g = 0, b = 0, a = 0;

		if (args.has(1) && args[1].isNumber())
		{
			r = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			g = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			b = (guint8)args[3].asNumber();
		}
		if (args.has(4) && args[4].isNumber())
		{
			a = (guint8)args[4].asNumber();
		}
		ClutterColor c = { r, g, b, a };
		self->SetTabColor(deserializeState(state, CCategoryTab::STATE_ALL), c);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setArrowsSize(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		float left_width = 0, left_height = 0, right_width = 0, right_height = 0;
		if (args.has(0) && args[0].isNumber())
		{
			left_width = right_width = static_cast<float>(args[0].asNumber());
		}
		if (args.has(1) && args[1].isNumber())
		{
			left_height = right_height = static_cast<float>(args[1].asNumber());
		}
		if (args.has(2) && args[2].isNumber())
		{
			right_width = static_cast<float>(args[2].asNumber());
		}
		if (args.has(3) && args[3].isNumber())
		{
			right_height = static_cast<float>(args[3].asNumber());
		}
		self->SetLeftArrowsSize(left_width, left_height);
		self->SetRightArrowsSize(right_width, right_height);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setArrowsImage(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		if (args.has(0) && args[0].isString())
		{
			self->SetLeftArrowsImage(args[0].asString().data());
		}
		if (args.has(1) && args[1].isString())
		{
			self->SetRightArrowsImage(args[1].asString().data());
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setBackgroundImage(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString())
		{
			self->SetBackgroundImage(args[0].asString().data());
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setBackgroundColor(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		guint8 r = 0, g = 0, b = 0, a = 0;

		if (args.has(0) && args[0].isNumber())
		{
			r = (guint8)args[0].asNumber();
		}
		if (args.has(1) && args[1].isNumber())
		{
			g = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			b = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			a = (guint8)args[3].asNumber();
		}
		ClutterColor c = { r, g, b, a };
		self->SetBackgroundColor(c);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::addTab(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.Length() == 1 && args.has(0) && args[0].isString())
		{
			self->AddTab(args[0].asString().data());
		}
		else if (args.Length() == 2 && args.has(0) && args[0].isString())
		{
			int index = 0;
			if (args.has(1) && args[1].isNumber())
			{
				index = static_cast<int>(args[1].asNumber());
			}
			self->AddTab(args[0].asString().data(), index);
		}
		else if (args.Length() == 3 && args.has(0) && args[0].isString())
		{
			float width = 0, height = 0;
			if (args.has(1) && args[1].isNumber())
			{
				width = static_cast<float>(args[1].asNumber());
			}
			if (args.has(2) && args[2].isNumber())
			{
				height = static_cast<float>(args[2].asNumber());
			}
			self->AddTab(args[0].asString().data(), width, height);
		}
		else if (args.Length() == 4 && args.has(0) && args[0].isString())
		{
			float width = 0, height = 0;
			if (args.has(1) && args[1].isNumber())
			{
				width = static_cast<float>(args[1].asNumber());
			}
			if (args.has(2) && args[2].isNumber())
			{
				height = static_cast<float>(args[2].asNumber());
			}
			int index = 0;
			if (args.has(3) && args[3].isNumber())
			{
				index = static_cast<int>(args[3].asNumber());
			}
			self->AddTab(args[0].asString().data(), width, height, index);
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::removeTab(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			self->RemoveTab(static_cast<int>(args[0].asNumber()));
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::currentTabIndex(CCategoryTab* self, const ScriptArray& args)
{
	return ScriptObject(self->CurrentTabIndex());
}

Bridge::ScriptObject Bridge::CategoryTabBridge::currentTabText(CCategoryTab* self, const ScriptArray& args)
{
	return ScriptObject(self->CurrentTabText());
}

Bridge::ScriptObject Bridge::CategoryTabBridge::tabText(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			return ScriptObject(self->TabText(static_cast<int>(args[0].asNumber())));
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::changeTab(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			self->ChangeTab(static_cast<int>(args[0].asNumber()));
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::numberOfTab(CCategoryTab* self, const ScriptArray& args)
{
	return ScriptObject(self->NumberOfTab());
}

Bridge::ScriptObject Bridge::CategoryTabBridge::addTabChangedListener(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		/*
		ICategoryTabChangedListener* listener = unwrapNativeObject<ICategoryTabChangedListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddTabChangedListener(listener);
		}
		*/
		CategoryTabChangedListener *listener = unwrapNativeObject<CategoryTabChangedListener>(args[0]);
		self->AddTabChangedListener(listener);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::removeTabChangedListener(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		/*
		ICategoryTabChangedListener* listener = unwrapNativeObject<ICategoryTabChangedListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveTabChangedListener(listener);
		}
		*/
		CategoryTabChangedListener *listener = unwrapNativeObject<CategoryTabChangedListener>(args[0]);
		self->RemoveTabChangedListener(listener);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CategoryTabBridge::setTabTextMargin(CCategoryTab* self, const ScriptArray& args){	if (args.Length() == 1)
	{
		if (args.has(0) && args[0].isNumber())
		{
			self->SetTabTextMargin(static_cast<float>(args[0].asNumber()));
		}
	}
	return ScriptObject();}Bridge::ScriptObject Bridge::CategoryTabBridge::getTabTextMargin(CCategoryTab* self, const ScriptArray& args){	double num = static_cast<double>(self->TabTextMargin());
	return ScriptObject(num);}Bridge::ScriptObject Bridge::CategoryTabBridge::enableHightlightBar(CCategoryTab* self, const ScriptArray& args){	if (args.Length() == 1)
	{
		if (args.has(0) && args[0].isBool())
		{
			self->EnableHightlightBar(args[0].asBool());
		}
	}
	return ScriptObject();}Bridge::ScriptObject Bridge::CategoryTabBridge::setHighlightBarHeight(CCategoryTab* self, const ScriptArray& args){	if (args.Length() == 1)
	{
		if (args.has(0) && args[0].isNumber())
		{
			self->SetHighlightBarHeight(static_cast<float>(args[0].asNumber()));
		}
	}
	return ScriptObject();}Bridge::ScriptObject Bridge::CategoryTabBridge::getHighlightBarHeight(CCategoryTab* self, const ScriptArray& args){	double height = static_cast<double>(self->HighlightBarHeight());
	return ScriptObject(height);}Bridge::ScriptObject Bridge::CategoryTabBridge::setHighlightBarColor(CCategoryTab* self, const ScriptArray& args){	if (args.Length() == 4)
	{
		guint8 r = 0, g = 0, b = 0, a = 0;
		if (args.has(0) && args[0].isNumber())
		{
			r = (guint8)args[0].asNumber();
		}
		if (args.has(1) && args[1].isNumber())
		{
			g = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			b = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			a = (guint8)args[3].asNumber();
		}
		ClutterColor c = { r, g, b, a };
		self->SetHighlightBarColor(c);
	}	return ScriptObject();}Bridge::ScriptObject Bridge::CategoryTabBridge::setTabTextLimitWidth(CCategoryTab* self, const ScriptArray& args){	if (args.Length() == 1)
	{
		if (args.has(0) && args[0].isNumber())
		{
			self->SetTabTextLimitWidth(static_cast<float>(args[0].asNumber()));
		}
	}
	return ScriptObject();}Bridge::ScriptObject Bridge::CategoryTabBridge::getTabTextLimitWidth(CCategoryTab* self, const ScriptArray& args)
{
	double num = static_cast<double>(self->TabTextLimitWidth());
	return ScriptObject(num);
}

Bridge::ScriptObject Bridge::CategoryTabBridge::enableAlignTabsCenter(CCategoryTab* self, const ScriptArray& args)
{
	if (args.Length() == 1)
	{
		if (args.has(0) && args[0].isBool())
		{
			self->EnableAlignTabsCenter(args[0].asBool());
		}
	}
	return ScriptObject();
}
