#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void* ThreadPoolBridge::constructFromScript(const ScriptArray& args)
{
	int maxThreadCount = 30;
	int minReserveTheadCount = 0;
	int maxPendingTaskCount = -1;
	if (args.Length() >= 1)
	{
		if (args.has(0) && args[0].isNumber())
		{
			maxThreadCount = (int)args[0].asNumber();
		}
	}
	if (args.Length() >= 2)
	{
		if (args.has(1) && args[1].isNumber())
		{
			minReserveTheadCount = (int)args[1].asNumber();
		}
	}
	if (args.Length() >= 3)
	{
		if (args.has(2) && args[2].isNumber())
		{
			maxPendingTaskCount = (int)args[2].asNumber();
		}
	}
	return constructThreadPool(maxThreadCount, minReserveTheadCount, maxPendingTaskCount);

}

IThreadPool* ThreadPoolBridge::constructThreadPool(int maxThreadCount, int minReserveTheadCount, int maxPendingTaskCount)
{
	IThreadPool* cThreadPool = IThreadPool::CreateInstance(maxThreadCount, minReserveTheadCount, maxPendingTaskCount);
	return cThreadPool;
}
