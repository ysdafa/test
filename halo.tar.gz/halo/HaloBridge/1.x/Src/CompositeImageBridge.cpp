#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void CompositeImageBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.captureMethodCall<CCompositeImage, &setImage>("setImage");
}

Widget* CompositeImageBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	CCompositeImage* cimage = dynamic_cast<CCompositeImage*>(ICompositeImage::CreateInstance(parent, width, height));

	return cimage;
}

ScriptObject CompositeImageBridge::setImage(CCompositeImage* self, const ScriptArray& args)
{ 
	if (args.Length() > 0)
	{
		if (args[0].isString())
		{
			self->SetImage(args[0].asString().data());
		}
		else
		{
			IImageBuffer* buffer = unwrapNativeObject<IImageBuffer>(args[0]);
			self->SetImage(buffer);
		}
	}

	return ScriptObject();
}
