#ifndef WIN32
#include "HaloBridgeAll.h"

using namespace HALO;
using namespace Bridge;

void VideoActorBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.captureMethodCall<CVideoActor, &play>("play");
	context.captureMethodCall<CVideoActor, &stop>("stop");
	context.captureMethodCall<CVideoActor, &pause>("pause");
	context.captureMethodCall<CVideoActor, &getPlayerState>("playerState");
	context.bindString<CVideoActor,&CVideoActor::Uri, &CVideoActor::SetUri>("uri");
	context.capturePropertyAccess<CVideoActor, &getVideoType, &setVideoType>("videoType");
}

Widget* VideoActorBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	if (width < 0)
	{
		width = 0;
	}
	if (height < 0)
	{
		height = 0;
	}
	CVideoActor* videoActor = new CVideoActor;

	ScriptObject options = args[0];
	
	ClutterVideoController type = CLUTTER_VC_TYPE_TV_MAIN;
	std::string typeStr;
	
	printf("typeStr is %s \n", typeStr.c_str() );

	if (options.has("type"))
	{
		typeStr = options.get("type").asString();
		type = deserializeType(typeStr);
	}

	videoActor->Initialize(parent, width, height, type);
	videoActor->SetPosition(x, y);
	if (options.has("uri"))
	{
		std::string uriStr = options.get("uri").asString();
		videoActor->SetUri(uriStr);
	}
		
	return videoActor;
}

ClutterVideoController VideoActorBridge::deserializeType(std::string typeStr)
{
	printf("deserializeType typestr is %s \n", typeStr.c_str() );
	ClutterVideoController type;

	if (typeStr == "tv_main")
	{
		type = CLUTTER_VC_TYPE_TV_MAIN;
	}
	else if(typeStr == "tv_pip")
	{
		type = CLUTTER_VC_TYPE_TV_PIP;
	}
	else if (typeStr == "mm_sync")
	{
		type = CLUTTER_VC_TYPE_MM_SYNC;
	}
	else if (typeStr == "mm_async")
	{
		type = CLUTTER_VC_TYPE_MM_ASYNC;
	}
	else
	{
		type = CLUTTER_VC_TYPE_INVALID;
	}
	return type;
}

std::string VideoActorBridge::serializeType(ClutterVideoController type)
{
	std::string typeStr;
	switch(type)
	{
	case CLUTTER_VC_TYPE_TV_MAIN:
		typeStr = "tv_main";
		break;
	case CLUTTER_VC_TYPE_TV_PIP:
		typeStr = "tv_pip";
		break;
	case CLUTTER_VC_TYPE_MM_SYNC:
		typeStr = "mm_sync";
		break;
	case CLUTTER_VC_TYPE_MM_ASYNC:
		typeStr = "mm_async";
		break;
	default:
		typeStr = "invalid";
		break;		
	}
	return typeStr;
}

std::string VideoActorBridge::serializePlayerState(ClutterVideoControllerState state)
{
  	std::string stateStr;
	switch(state)
	{

	case CLUTTER_PLAYER_STATE_IDLE:
		stateStr = "idle";
		break;
	case CLUTTER_PLAYER_STATE_READY:
		stateStr = "ready";
		break;
	case CLUTTER_PLAYER_STATE_PLAYING:
		stateStr = "playing";
		break;
	case CLUTTER_PLAYER_STATE_PAUSED:
		stateStr = "paused";
		break;
	default:
		stateStr = "none";
		break;		
	}
	return stateStr;
}
ScriptObject VideoActorBridge::play(CVideoActor* self, const ScriptArray &args)
{
	return ScriptObject( self->Play());
}
ScriptObject VideoActorBridge::stop(CVideoActor* self, const ScriptArray &args)
{
	return ScriptObject(self->Stop());
}
ScriptObject VideoActorBridge::pause(CVideoActor* self, const ScriptArray &args)
{		
	return ScriptObject(self->Pause());
}

ScriptObject VideoActorBridge::getVideoType(CVideoActor* self)
{
	ScriptObject videoType;
	ClutterVideoController type = self->VideoType();
	return ScriptObject(serializeType(type));
}

void VideoActorBridge::setVideoType(CVideoActor* self, ScriptObject scriptType)
{
	std::string typeStr;
	if(scriptType.isString())
	{
	   typeStr = scriptType.asString();
	}
	printf("setVideoType typestr is %s \n", typeStr.c_str() );
	self->SetVideoType(deserializeType(typeStr));
}

ScriptObject VideoActorBridge::getPlayerState(CVideoActor* self, const ScriptArray &args)
{
	ScriptObject playerState;
	ClutterVideoControllerState state = self->PlayerState();
	return ScriptObject(serializePlayerState(state));
}

#endif
