#include "HaloBridgeAll.h"

static HALO::util::Logger LOGGER("DataBridge");

using namespace Bridge;
using namespace HALO;

void DataBridge::mapScriptInterface(ScriptContext& context)
{
	context.bindBoolean<IData, &IData::IsReady, &IData::SetReady>("isReady");
//	context.bindNumber<IData, int, &IData::DataLoadType, &IData::SetDataLoadType>("loadType");

	context.bindNumber<IData, int, &IData::NumOfWindow, &IData::SetWindowNum>("numOfActor");
	context.captureMethodCall<IData, &m_curUsingData>("currentUsingData");
}

void* DataBridge::constructFromScript(const ScriptArray& args)
{
	H_LOG_0_PARAM(TRACE, LOGGER);
	IData* data = new IData;
	return data;
}

void DataBridge::destroyFromScript(void* destroyedObject)
{
	H_LOG_1_PARAM(TRACE, LOGGER, destroyedObject);
}

ScriptObject DataBridge::m_curUsingData(IData* self, const ScriptArray& args)
{
	return ScriptObject(self->curUsingSubData);
}
