#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void DataBridge::mapScriptInterface(ScriptContext& context)
{
	context.bindBoolean<IData, &IData::IsReady, &IData::SetReady>("isReady");
//	context.bindNumber<IData, int, &IData::DataLoadType, &IData::SetDataLoadType>("loadType");

	context.bindNumber<IData, int, &IData::NumOfWindow, &IData::SetWindowNum>("numOfActor");
	context.captureMethodCall<IData, &m_curUsingData>("currentUsingData");
}

ScriptObject DataBridge::m_curUsingData(IData* self, const ScriptArray& args)
{
	return ScriptObject(self->curUsingSubData);
}
