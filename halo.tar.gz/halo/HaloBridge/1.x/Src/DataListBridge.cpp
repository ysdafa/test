#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

class ResolutionScale
{
public:
	ResolutionScale(void) : flagAutoScale(false), m_hScale(1.0f), m_vScale(1.0f) {};

	virtual ~ResolutionScale(void)
	{
		if (NULL != m_ResolutionScale)
		{
			delete m_ResolutionScale;
		}
	}

	bool flagAutoScale;

	float HScaleRatio(void)
	{
		if (false == flagAutoScale)
		{
			return 1.0f;
		}
		else
		{
			return m_hScale;
		}
	}

	float VScaleRatio(void)
	{
		if (false == flagAutoScale)
		{
			return 1.0f;
		}
		else
		{
			return m_vScale;
		}
	}

	static ResolutionScale* ResolutionScaleObject(void)
	{
		if (NULL == m_ResolutionScale)
		{
			m_ResolutionScale = new ResolutionScale;

			int hRes, vRes;
			IUtility::GetInstance()->GetCurrentResolution(hRes, vRes);

			if (2560 == hRes && 1080 == vRes)
			{
				m_ResolutionScale->m_hScale = 1.0f;
				m_ResolutionScale->m_vScale = 1.0f;
			} 
			else
			{
				m_ResolutionScale->m_hScale = hRes / 1920.0f;
				m_ResolutionScale->m_vScale = vRes / 1080.0f;
			}
		}

		return m_ResolutionScale;
	}

protected:

private:
	float m_hScale;
	float m_vScale;

	static ResolutionScale* m_ResolutionScale;
};

ResolutionScale* ResolutionScale::m_ResolutionScale = NULL;

void RendererProviderBridge::mapScriptInterface(ScriptContext &context)
{
	context.bindFunction<InternalProvider, &InternalProvider::GetProviderCallBack, &InternalProvider::SetProviderCallBack>("funcGetRenderer");
	context.captureMethodCall<InternalProvider, &m_HandleDestroy>("destroy");
}

void* RendererProviderBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalProvider;
}

void RendererProviderBridge::destroyFromScript(void* pointerToDestroyedObject)
{
	
}

ScriptObject RendererProviderBridge::m_HandleDestroy(InternalProvider* self, const ScriptArray& args)
{
	delete self;
	return ScriptObject();
}

IRenderer* InternalProvider::GetRenderer(IData *data, IActor* parent)
{
	if (true == ProviderCb.flagExist)
	{
		float w, h;
		parent->GetSize(w, h);

		ScriptArray args;
		args.set(0, ScriptObject((double)w));
		args.set(1, ScriptObject((double)h));
		args.set(2, ActorBridge::wrapNativeObjectToJS<IData>(data));

		ScriptObject result = ProviderCb.function.invoke(args);
		IRenderer *render = ActorBridge::unwrapObject<IRenderer>(result);
		ASSERT(NULL != render);
		if (NULL != render)
		{
			InternalRender *realRender = dynamic_cast<InternalRender*>(render);
			if (NULL != realRender)
			{
				if (NULL != realRender->Root())
				{
					realRender->Root()->setParent(dynamic_cast<Widget*>(parent));
				}

				if (NULL != realRender->GetThumbnail())
				{
					CThumbnail *thumb = realRender->GetThumbnail();

					if (NULL != thumb)
					{
						thumb->SetParent(parent);
					}
				}
			}
		}

		return render;
	}
	else
	{
		return NULL;
	}
}

float DataListBridge::t_ScaleRatioWidth(void)
{
	ResolutionScale *resScaleObject = ResolutionScale::ResolutionScaleObject();
	return resScaleObject->HScaleRatio();
}

float DataListBridge::t_ScaleRatioHeight(void)
{
	ResolutionScale *resScaleObject = ResolutionScale::ResolutionScaleObject();
	return resScaleObject->VScaleRatio();
}

void DataListBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);
	context.captureMethodCall<CDataListControl, &loadData>("loadData");
	context.captureMethodCall<CDataListControl, &enlargeFocusedItem>("enlargeFocusedItem");
	context.captureMethodCall<CDataListControl, &moveFocus>("moveFocus");
	context.captureMethodCall<CDataListControl, &showFocus>("showFocus");
	context.captureMethodCall<CDataListControl, &hideFocus>("hideFocus");
	context.captureMethodCall<CDataListControl, &m_SetRenderProvider>("setRendererProvider");
	context.bindBoolean<CDataListControl, &CDataListControl::IsLoopLeftEnabled, &CDataListControl::EnableLoopLeft>("loopLeftFlag");
	context.bindBoolean<CDataListControl, &CDataListControl::IsLoopRightEnabled, &CDataListControl::EnableLoopRight>("loopRightFlag");
	context.captureMethodCall<CDataListControl, &attachScrollBar>("attachScrollBar");
	
	context.captureMethodCall<CDataListControl, &m_SetDimWindowColor>("setDimWindowColor");
	context.captureMethodCall<CDataListControl, &m_Dim>("dim");
	context.captureMethodCall<CDataListControl, &m_SetFocusImage>("setFocusImage");
	context.captureMethodCall<CDataListControl, &m_SetCursorScrollInfo>("setCursorScrollInfo");

	context.bindBoolean<CDataListControl, &CDataListControl::IsShadowEffectEnabled, &CDataListControl::EnableShadowEffect>("shadowEffectFlag");
	context.bindBoolean<CDataListControl, &CDataListControl::IsFoveaEffectEnabled, &CDataListControl::EnableFoveaEffect>("foveaEffect");
	//context.captureMethodCall<CDataListControl, &scrollVisibleArea>("scrollVisibleArea");//no plan to open this api.
}

Widget* DataListBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	ScriptObject argObject = args[0];

	x *= t_ScaleRatioWidth();
	y *= t_ScaleRatioHeight();

	width *= t_ScaleRatioWidth();
	height *= t_ScaleRatioHeight();

	CDataListControl *control = constructSubWidget(parent, width, height, argObject);
	control->SetPosition(x, y);

	return control;
}

ScriptObject DataListBridge::loadData(CDataListControl* self, const ScriptArray& args)
{
	self->LoadData();
	return ScriptObject();
}

ScriptObject DataListBridge::enlargeFocusedItem(CDataListControl* self, const ScriptArray& args)
{
	ASSERT(2 == args.Length() && true == args[0].isNumber() && true == args[1].isNumber());
	int w = args[0].asNumber();
	int h = args[1].asNumber();

	self->EnlargeFocusedItem(w, h);

	return ScriptObject();
}

ScriptObject DataListBridge::moveFocus(CDataListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length() && true == args[0].isString());

	std::string direction = args[0].asString();

	bool ret;

	if ("Left" == direction)
	{
		ret = self->MoveFocus(DIRECTION_LEFT);
	}
	else if ("Right" == direction)
	{
		ret = self->MoveFocus(DIRECTION_RIGHT);
	}
	else if ("Up" == direction)
	{
		ret = self->MoveFocus(DIRECTION_UP);
	}
	else if ("Down" == direction)
	{
		ret = self->MoveFocus(DIRECTION_DOWN);
	}
	else
	{
		ret = false;
		ASSERT(0 && "direction is not correct\n");
	}

	return ScriptObject(ret);
}

ScriptObject DataListBridge::showFocus(CDataListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length() && true == args[0].isString());

	bool ret;

	if ("true" == args[0].asString())
	{
		ret = self->ShowFocus(true);
	}
	else
	{
		ret = self->ShowFocus(false);
	}
	
	return ScriptObject(ret);
}

ScriptObject DataListBridge::hideFocus(CDataListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length() && true == args[0].isString());

	bool ret;

	if ("true" == args[0].asString())
	{
		ret = self->HideFocus(true);
	}
	else
	{
		ret = self->HideFocus(false);
	}

	return ScriptObject(ret);
}

ScriptObject DataListBridge::m_SetRenderProvider(CDataListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length());

	InternalProvider *provider = unwrapNativeObject<InternalProvider>(args[0]);
	ASSERT(NULL != provider);

	self->SetRendererProvider(provider);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::DataListBridge::scrollVisibleArea(CDataListControl* self, const ScriptArray& args)
{
	ASSERT(3 == args.Length() && true == args[0].isNumber() && true == args[1].isNumber() && true == args[2].isBool());
	
	int xOffset = args[0].asNumber();
	int yOffset = args[1].asNumber();
	bool flagAni = args[2].asBool();

	self->ScrollVisibleArea(xOffset, yOffset, flagAni);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::DataListBridge::attachScrollBar(CDataListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length());

	CScroll* scrollBar = unwrapNativeObject<CScroll>(args[0]);
	ASSERT(scrollBar != NULL);

	float x, y;
	scrollBar->GetPosition(x, y);

	x *= t_ScaleRatioWidth();
	y *= t_ScaleRatioHeight();

	scrollBar->SetPosition(x, y);

	self->AttachScrollBar(scrollBar);

	return ScriptObject();
}

ScriptObject DataListBridge::m_SetDimWindowColor(CDataListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length());
	ASSERT(NULL != self);

	ScriptObject object = args[0];
	ARG_IS_VALID(object, "alpha", isNumber);
	ARG_IS_VALID(object, "red", isNumber);
	ARG_IS_VALID(object, "green", isNumber);
	ARG_IS_VALID(object, "blue", isNumber);

	int a = (int)object.get("alpha").asNumber();
	int r = (int)object.get("red").asNumber();
	int g = (int)object.get("green").asNumber();
	int b = (int)object.get("blue").asNumber();

	self->SetColorOfDimWindow(a, r, g, b);

	return ScriptObject();
}

ScriptObject DataListBridge::m_Dim(CDataListControl* self, const ScriptArray& args)
{
	ASSERT(NULL != self && 1 == args.Length() && true == args[0].isBool());

	self->Dim(args[0].asBool());
	return ScriptObject();
}

ScriptObject DataListBridge::m_SetFocusImage(CDataListControl* self, const ScriptArray& args)
{
	if (args.Length() > 2)
	{
		if (args[0].isString())
		{
			std::string file = args[0].asString();
			int xOffset = args[1].isNumber() ? args[1].asNumber() : 0;
			int yOffset = args[2].isNumber() ? args[2].asNumber() : 0;
			self->SetFocusImage(file.c_str(), xOffset, yOffset);
		}
	}
	return ScriptObject();
}

ScriptObject DataListBridge::m_SetCursorScrollInfo(CDataListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length());
	ASSERT(NULL != self);

	ScriptObject object = args[0];
	ARG_IS_VALID(object, "scrollSpace", isNumber);
	ARG_IS_VALID(object, "inAreaSpace", isNumber);

	float scrollSpace = (float)object.get("scrollSpace").asNumber();
	float inAreaSpace = (float)object.get("inAreaSpace").asNumber();

	self->SetCursorScrollArea(scrollSpace, inAreaSpace);

	if (object.has("changeMount"))
	{
		ScriptObject content = object.get("changeMount");
		ASSERT(true == content.isNumber());

		self->SetChangeMount((float)content.asNumber());
	}
	
	return ScriptObject();
}