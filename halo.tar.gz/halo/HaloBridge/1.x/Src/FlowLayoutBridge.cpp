#include "HaloBridgeAll.h"
#include <string.h>

using namespace Bridge;
using namespace HALO;

void FlowLayoutBridge::mapScriptInterface(ScriptContext& context)
{
	LayoutManagerBridge::mapScriptInterface(context);
	context.captureMethodCall<ILayout, &EnableHomogeneous>("setHomogeneous");
	context.captureMethodCall<ILayout, &IsHomogeneousEnabled>("getHomogeneous");
	context.captureMethodCall<ILayout, &SetDirection>("setDirection");
	context.captureMethodCall<ILayout, &Direction>("getDirection");
	context.captureMethodCall<ILayout, &SetColumnSpacing>("setColumnSpacing");
	context.captureMethodCall<ILayout, &ColumnSpacing>("getColumnSpacing");
	context.captureMethodCall<ILayout, &SetRowSpacing>("setRowSpacing");
	context.captureMethodCall<ILayout, &RowSpacing>("getRowSpacing");
	context.captureMethodCall<ILayout, &SetColumnWidth>("setColumnWidth");
	context.captureMethodCall<ILayout, &GetMinColumnWidth>("getMinColumnWidth");
	context.captureMethodCall<ILayout, &GetMaxColumnWidth>("getMaxColumnWidth");
	context.captureMethodCall<ILayout, &SetRowHeight>("setRowHeight");
	context.captureMethodCall<ILayout, &GetMinRowHeight>("getMinRowHeight");
	context.captureMethodCall<ILayout, &GetMaxRowHeight>("getMaxRowHeight");
}

ILayout* FlowLayoutBridge::constructWidget(const ScriptArray& args)
{
	IFlowLayout *flowlayout = NULL;
;
	bool isLayoutInit = false;

	if (args.Length() > 0 && args[0].isString())
	{
		/*CLUTTER_FLOW_HORIZONTAL,
		CLUTTER_FLOW_VERTICAL*/
		std::string orientation;
		orientation = args[0].asString();
		if (orientation.compare("HORIZONTAL") == 0)
		{
			flowlayout = IFlowLayout::CreateInstance(CLUTTER_FLOW_HORIZONTAL);
			isLayoutInit = true;
		}
		else if (orientation.compare("VERTICAL") == 0)
		{
			flowlayout = IFlowLayout::CreateInstance(CLUTTER_FLOW_VERTICAL);
			isLayoutInit = true;
		}
	}	
	if (isLayoutInit == false)
	{
		flowlayout = IFlowLayout::CreateInstance(CLUTTER_FLOW_HORIZONTAL);
	}
	return flowlayout;
}

ScriptObject FlowLayoutBridge::EnableHomogeneous(ILayout* self, const ScriptArray& args)
{
	IFlowLayout *iLayout = dynamic_cast<IFlowLayout*>(self);
	if (iLayout != NULL && args.Length() > 0 && args[0].isBool())
	{
		iLayout->EnableHomogeneous(args[0].asBool());
	}
	return ScriptObject();
}

ScriptObject FlowLayoutBridge::IsHomogeneousEnabled(ILayout* self, const ScriptArray& args)
{
	IFlowLayout *iLayout = dynamic_cast<IFlowLayout*>(self);
	bool flag = false;
	if (iLayout != NULL)
	{
		iLayout->IsHomogeneousEnabled();
	}
	return ScriptObject(flag);
}

ScriptObject FlowLayoutBridge::SetDirection(ILayout* self, const ScriptArray& args)
{
	IFlowLayout *iLayout = dynamic_cast<IFlowLayout*>(self);
	if (iLayout != NULL && args.Length() > 0 && args[0].isString())
	{
		/*CLUTTER_FLOW_HORIZONTAL,
		CLUTTER_FLOW_VERTICAL*/
		std::string orientation;
		orientation = args[0].asString();
		if (orientation.compare("HORIZONTAL") == 0)
		{
			iLayout->SetDirection(CLUTTER_FLOW_HORIZONTAL);
		}
		else if (orientation.compare("VERTICAL") == 0)
		{
			iLayout->SetDirection(CLUTTER_FLOW_VERTICAL);
		}
	}
	return ScriptObject();
}

ScriptObject FlowLayoutBridge::Direction(ILayout* self, const ScriptArray& args)
{
	IFlowLayout *iLayout = dynamic_cast<IFlowLayout*>(self);
	std::string orientation = "";
	if (iLayout != NULL)
	{
		if (iLayout->Direction() == CLUTTER_FLOW_HORIZONTAL)
		{
			orientation = "HORIZONTAL";
		}
		else if (iLayout->Direction() == CLUTTER_FLOW_VERTICAL)
		{
			orientation = "VERTICAL";
		}	
	}
	return ScriptObject(orientation);
}

ScriptObject FlowLayoutBridge::SetColumnSpacing(ILayout* self, const ScriptArray& args)
{
	IFlowLayout *iLayout = dynamic_cast<IFlowLayout*>(self);
	if (iLayout != NULL && args.Length() > 0 && args[0].isNumber())
	{
		iLayout->SetColumnSpacing(args[0].asNumber());
	}
	return ScriptObject();
}

ScriptObject FlowLayoutBridge::ColumnSpacing(ILayout* self, const ScriptArray& args)
{
	IFlowLayout *iLayout = dynamic_cast<IFlowLayout*>(self);
	int spacing = -1;
	if (iLayout != NULL)
	{
		spacing = iLayout->ColumnSpacing();
	}
	return ScriptObject(spacing);
}

ScriptObject FlowLayoutBridge::SetRowSpacing(ILayout* self, const ScriptArray& args)
{
	IFlowLayout *iLayout = dynamic_cast<IFlowLayout*>(self);
	if (iLayout != NULL && args.Length() > 0 && args[0].isNumber())
	{
		iLayout->SetRowSpacing(args[0].asNumber());
	}
	return ScriptObject();
}

ScriptObject FlowLayoutBridge::RowSpacing(ILayout* self, const ScriptArray& args)
{
	IFlowLayout *iLayout = dynamic_cast<IFlowLayout*>(self);
	int spacing = -1;
	if (iLayout != NULL)
	{
		spacing = iLayout->RowSpacing();
	}
	return ScriptObject(spacing);
}

ScriptObject FlowLayoutBridge::SetColumnWidth(ILayout* self, const ScriptArray& args)
{
	IFlowLayout *iLayout = dynamic_cast<IFlowLayout*>(self);
	if (iLayout != NULL && args.Length() > 1 && args[0].isNumber() && args[1].isNumber())
	{
		iLayout->SetColumnWidth(args[0].asNumber(), args[1].asNumber());
	}
	return ScriptObject();
}

ScriptObject FlowLayoutBridge::GetMinColumnWidth(ILayout* self, const ScriptArray& args)
{
	IFlowLayout *iLayout = dynamic_cast<IFlowLayout*>(self);
	float min_width = 0;
	float max_width = 0;
	if (iLayout != NULL)
	{
		iLayout->GetColumnWidth(min_width, max_width);
	}
	return ScriptObject(min_width);
}

ScriptObject FlowLayoutBridge::GetMaxColumnWidth(ILayout* self, const ScriptArray& args)
{
	IFlowLayout *iLayout = dynamic_cast<IFlowLayout*>(self);
	float min_width = 0;
	float max_width = 0;
	if (iLayout != NULL)
	{	
		iLayout->GetColumnWidth(min_width, max_width);
	}
	return ScriptObject(max_width);
}

ScriptObject FlowLayoutBridge::SetRowHeight(ILayout* self, const ScriptArray& args)
{
	IFlowLayout *iLayout = dynamic_cast<IFlowLayout*>(self);
	if (iLayout != NULL && args.Length() > 1 && args[0].isNumber() && args[1].isNumber())
	{
		iLayout->SetRowHeight(args[0].asNumber(), args[1].asNumber());
	}
	return ScriptObject();
}

ScriptObject FlowLayoutBridge::GetMinRowHeight(ILayout* self, const ScriptArray& args)
{
	IFlowLayout *iLayout = dynamic_cast<IFlowLayout*>(self);
	float min_height = 0;
	float max_height = 0;
	if (iLayout != NULL)
	{	
		iLayout->GetRowHeight(min_height, max_height);
	}
	return ScriptObject(min_height);
}

ScriptObject FlowLayoutBridge::GetMaxRowHeight(ILayout* self, const ScriptArray& args)
{
	IFlowLayout *iLayout = dynamic_cast<IFlowLayout*>(self);
	float min_height = 0;
	float max_height = 0;
	if (iLayout != NULL)
	{	
		iLayout->GetRowHeight(min_height, max_height);
	}
	return ScriptObject(max_height);
}