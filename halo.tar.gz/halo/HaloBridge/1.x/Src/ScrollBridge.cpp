#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void Bridge::ScrollBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.bindNumber<CScroll, int, &CScroll::MinValue, &CScroll::SetMinValue>("minValue");
	context.bindNumber<CScroll, int, &CScroll::Value, &CScroll::SetValue>("value");
	context.bindNumber<CScroll, int, &CScroll::MaxValue, &CScroll::SetMaxValue>("maxValue");
	context.bindBoolean<CScroll, &CScroll::FlagActive, &CScroll::SetActive>("active");
	context.bindNumber<CScroll, float, &CScroll::TrackShadowHeight, &CScroll::SetTrackShadowHeight>("trackShadowHeight");
	context.bindNumber<CScroll, float, &CScroll::RolloverTrackHeight, &CScroll::SetRolloverTrackHeight>("rolloverTrackHeight");

	context.bindString<CScroll, &CScroll::PointingNormalBackgroundImage, &CScroll::SetPointingNormalBackgroundImage>("pointingNormalBackgroundImage");
	context.bindString<CScroll, &CScroll::PointingOverBackgroundImage, &CScroll::SetPointingOverBackgroundImage>("pointingOverBackgroundImage");

	context.bindString<CScroll, &CScroll::PointingNormalThumbImage, &CScroll::SetPointingNormalThumbImage>("pointingNormalThumbImage");
	context.bindString<CScroll, &CScroll::PointingOverThumbImage, &CScroll::SetPointingOverThumbImage>("pointingOverThumbImage");
	context.bindString<CScroll, &CScroll::PointingFocusThumbImage, &CScroll::SetPointingFocusThumbImage>("pointingFocusThumbImage");

	context.captureMethodCall<CScroll, &setMinCurMaxValue>("setMinCurMaxValue");
	context.captureMethodCall<CScroll, &setTrackShadowColor>("setTrackShadowColor");

	context.captureMethodCall<CScroll, &setPointingNormalThumbSize>("setPointingNormalThumbSize");
	context.captureMethodCall<CScroll, &setPointingOverThumbSize>("setPointingOverThumbSize");
	context.captureMethodCall<CScroll, &setPointingFocusThumbSize>("setPointingFocusThumbSize");

	context.captureMethodCall<CScroll, &addListener>("addListener");
	context.captureMethodCall<CScroll, &removeListener>("removeListener");

	// not using now
	context.captureMethodCall<CScroll, &setPreviousArrowImage>("setPreviousArrowImage");
	context.captureMethodCall<CScroll, &setPreviousArrowSize>("setPreviousArrowSize");

	context.captureMethodCall<CScroll, &setNextArrowImage>("setNextArrowImage");
	context.captureMethodCall<CScroll, &setNextArrowSize>("setNextArrowSize");

	context.captureMethodCall<CScroll, &setLongPressIntervalOnArrowButton>("setLongPressIntervalOnArrowButton");
	context.captureMethodCall<CScroll, &setMovingStepOnArrowButton>("setMovingStepOnArrowButton");


	// for old APIs
	context.captureMethodCall<CScroll, &setMinValue>("setMinValue");
	context.captureMethodCall<CScroll, &setMaxValue>("setMaxValue");
	context.captureMethodCall<CScroll, &setValue>("setValue");
	context.captureMethodCall<CScroll, &setMinCurMaxValue>("setMinCurMaxValue");

	//context.captureMethodCall<CScroll, &setTopTrackHeight>("setTopTrackHeight");
	//context.captureMethodCall<CScroll, &setTopTrackColor>("setTopTrackColor");

	context.captureMethodCall<CScroll, &setTrackShadowHeight>("setTrackShadowHeight");
	context.captureMethodCall<CScroll, &setTrackShadowColor>("setTrackShadowColor");

	context.captureMethodCall<CScroll, &setRolloverTrackHeight>("setRolloverTrackHeight");

	context.captureMethodCall<CScroll, &setPointingNormalThumbImage>("setPointingNormalThumbImage");
	context.captureMethodCall<CScroll, &setPointingNormalThumbSize>("setPointingNormalThumbSize");

	context.captureMethodCall<CScroll, &setPointingOverThumbImage>("setPointingOverThumbImage");
	context.captureMethodCall<CScroll, &setPointingOverThumbSize>("setPointingOverThumbSize");

	context.captureMethodCall<CScroll, &setPointingFocusThumbImage>("setPointingFocusThumbImage");
	context.captureMethodCall<CScroll, &setPointingFocusThumbSize>("setPointingFocusThumbSize");
}

Widget* Bridge::ScrollBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	ScriptObject options = args[0];

	float scrollWidth = 0;
	float topTrackHeight = 0;
	float bottomTrackHeight = 0;
	EDirectionType direction = TYPE_HORIZONTAL;

	if (options.has("width"))
	{
		scrollWidth = options.get("width").asNumber();
	}

	if (options.has("height"))
	{
		topTrackHeight = options.get("height").asNumber();
	}

	if (options.has("trackShadowHeight"))
	{
		bottomTrackHeight = options.get("trackShadowHeight").asNumber();
	}

	if (options.has("direction"))
	{
		std::string directionStr = options.get("direction").asString();
		if (directionStr == "horizontal")
		{
			direction = TYPE_HORIZONTAL;
		}
		else if (directionStr == "vertical")
		{
			direction = TYPE_VERTICAL;
		}
		else
		{
			ASSERT(!"Scroll type can only be 'horizontal' or 'vertical'.");
		}
	}
	
	CScroll* scroll = dynamic_cast<CScroll *>(IScroll::CreateInstance(parent, scrollWidth, topTrackHeight,direction));
	if (scroll == NULL)
	{
		return NULL;
	}
	scroll->setX(x);
	scroll->setY(y);
	
	// scroll property
	if (options.has("backgroundColor"))
	{
		ScriptObject val = options.get("backgroundColor");
		ClutterColor topTrackColor;
		memset(&topTrackColor, 0, sizeof(topTrackColor));
		if (val.has("r") || val.has("g") || val.has("b") || val.has("a"))
		{
			topTrackColor.red = (val.has("r")) ? val["r"].asNumber() : 0;
			topTrackColor.green = (val.has("g")) ? val["g"].asNumber() : 0;
			topTrackColor.blue = (val.has("b")) ? val["b"].asNumber() : 0;
			topTrackColor.alpha = (val.has("a")) ? val["a"].asNumber() : 255;
		}

		scroll->SetBackgroundColor(topTrackColor);
	}

	if (options.has("trackShadowColor"))
	{
		ScriptObject val = options.get("trackShadowColor");
		ClutterColor bottomTrackColor;
		memset(&bottomTrackColor, 0, sizeof(bottomTrackColor));
		if (val.has("r") || val.has("g") || val.has("b") || val.has("a"))
		{
			bottomTrackColor.red = (val.has("r")) ? val["r"].asNumber() : 0;
			bottomTrackColor.green = (val.has("g")) ? val["g"].asNumber() : 0;
			bottomTrackColor.blue = (val.has("b")) ? val["b"].asNumber() : 0;
			bottomTrackColor.alpha = (val.has("a")) ? val["a"].asNumber() : 255;
		}

		scroll->SetTrackShadowColor(bottomTrackColor);
	}

	if (options.has("minValue"))
	{
		int minValue = static_cast<int>(options.get("minValue").asNumber());
		scroll->SetMinValue(minValue);
	}

	if (options.has("maxValue"))
	{
		int maxValue = static_cast<int>(options.get("maxValue").asNumber());
		scroll->SetMaxValue(maxValue);
	}

	if (options.has("value"))
	{
		int currentValue = static_cast<int>(options.get("value").asNumber());
		scroll->SetValue(currentValue);
	}

	if (options.has("active"))
	{
		bool activeFlag = options.get("active").asBool();
		scroll->SetActive(activeFlag);
	}

	if (options.has("pointingNormalBackgroundImage"))
	{
		std::string pointingNormalThumbImagePath = options.get("pointingNormalBackgroundImage").asString();
		scroll->SetPointingNormalBackgroundImage(pointingNormalThumbImagePath);
	}

	if (options.has("pointingOverBackgroundImage"))
	{
		std::string pointingNormalThumbImagePath = options.get("pointingOverBackgroundImage").asString();
		scroll->SetPointingOverBackgroundImage(pointingNormalThumbImagePath);
	}

	float pointingNormalThumbImageWidth = 0;
	float pointingNormalThumbImageHeight = 0;
	if (options.has("pointingNormalThumbImageWidth"))
	{
		pointingNormalThumbImageWidth = static_cast<float>(options.get("pointingNormalThumbImageWidth").asNumber());
	}
	if (options.has("pointingNormalThumbImageWidth"))
	{
		pointingNormalThumbImageHeight = static_cast<float>(options.get("pointingNormalThumbImageHeight").asNumber());
	}
	scroll->SetPointingNormalThumbSize(pointingNormalThumbImageWidth, pointingNormalThumbImageHeight);

	if (options.has("pointingNormalThumbImage"))
	{
		std::string pointingNormalThumbImagePath = options.get("pointingNormalThumbImage").asString();
		scroll->SetPointingNormalThumbImage(pointingNormalThumbImagePath);
	}
	
	float pointingOverThumbImageWidth = 0;
	float pointingOverThumbImageHeight = 0;
	if (options.has("pointingOverThumbImageWidth"))
	{
		pointingOverThumbImageWidth = static_cast<float>(options.get("pointingOverThumbImageWidth").asNumber());
	}
	if (options.has("pointingOverThumbImageHeight"))
	{
		pointingOverThumbImageHeight = static_cast<float>(options.get("pointingOverThumbImageHeight").asNumber());
	}
	scroll->SetPointingOverThumbSize(pointingOverThumbImageWidth, pointingOverThumbImageHeight);

	if (options.has("pointingOverThumbImage"))
	{
		std::string pointingOverThumbImagePath = options.get("pointingOverThumbImage").asString();
		scroll->SetPointingOverThumbImage(pointingOverThumbImagePath);
	}

	float pointingFocusThumbImageWidth = 0;
	float pointingFocusThumbImageHeight = 0;
	if (options.has("pointingFocusThumbImageWidth"))
	{
		pointingFocusThumbImageWidth = static_cast<float>(options.get("pointingFocusThumbImageWidth").asNumber());
	}
	if (options.has("pointingFocusThumbImageHeight"))
	{
		pointingFocusThumbImageHeight = static_cast<float>(options.get("pointingFocusThumbImageHeight").asNumber());
	}
	scroll->SetPointingFocusThumbSize(pointingFocusThumbImageWidth, pointingFocusThumbImageHeight);
	
	if (options.has("pointingFocusThumbImage"))
	{
		std::string pointingFocusThumbImagePath = options.get("pointingFocusThumbImage").asString();
		scroll->SetPointingFocusThumbImage(pointingFocusThumbImagePath);
	}

	if (options.has("rolloverTopTrackHeight"))
	{
		float rolloverTopTrackHeight = static_cast<float>(options.get("rolloverTopTrackHeight").asNumber());
		scroll->SetRolloverTrackHeight(rolloverTopTrackHeight);
	}

	
	return scroll;
}

Bridge::ScriptObject Bridge::ScrollBridge::setPreviousArrowImage(CScroll* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 2);

	std::string stateStr = args[0].asString();
	IButton::EButtonState state;

	if (stateStr == "state_all")
	{
		state = IButton::STATE_ALL;
	}
	else
	{
		state = IButton::STATE_NORMAL;
	}

	std::string imagePath = args[1].asString();
	self->SetPreviousArrowImage(state, imagePath);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ScrollBridge::setPreviousArrowSize(CScroll* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 2);

	float width = static_cast<float>(args[0].asNumber());
	float height = static_cast<float>(args[1].asNumber());
	self->SetPreviousArrowSize(width, height);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ScrollBridge::setNextArrowImage(CScroll* scroll, const ScriptArray& args)
{
	ASSERT(args.Length() == 2);

	std::string stateStr = args[0].asString();
	IButton::EButtonState state;

	if (stateStr == "state_all")
	{
		state = IButton::STATE_ALL;
	}
	else
	{
		state = IButton::STATE_NORMAL;
	}

	std::string imagePath = args[1].asString();

	scroll->SetNextArrowImage(state, imagePath);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ScrollBridge::setNextArrowSize(CScroll* scroll, const ScriptArray& args)
{
	ASSERT(args.Length() == 2);

	float width = static_cast<float>(args[0].asNumber());
	float height = static_cast<float>(args[1].asNumber());
	scroll->SetNextArrowSize(width, height);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ScrollBridge::addListener(CScroll* scroll, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);

	if (args.Length() > 0)
	{
		IScrollListener* listener = unwrapNativeObject<IScrollListener>(args[0]);
		if (listener != nullptr)
		{
			scroll->AddListener(listener);
		}
	}

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ScrollBridge::removeListener(CScroll* scroll, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);


	if (args.Length() > 0)
	{
		IScrollListener* listener = unwrapNativeObject<IScrollListener>(args[0]);
		if (listener != nullptr)
		{
			scroll->RemoveListener(listener);
		}
	}

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ScrollBridge::setLongPressIntervalOnArrowButton(CScroll* scroll, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);
	int value = static_cast<int>(args[0].asNumber());
	scroll->SetLongPressIntervalOnArrowButton(value);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ScrollBridge::setMovingStepOnArrowButton(CScroll* scroll, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);
	int moveStep = static_cast<int>(args[0].asNumber());
	scroll->SetMovingStepOnArrowButton(moveStep);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ScrollBridge::setMinCurMaxValue(CScroll* scroll, const ScriptArray& args)
{
	ASSERT(args.Length() == 3);

	int minValue = static_cast<int>(args[0].asNumber());
	int curValue = static_cast<int>(args[1].asNumber());
	int maxValue = static_cast<int>(args[2].asNumber());

	scroll->SetMinCurMaxValue(minValue, curValue, maxValue);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ScrollBridge::setPointingNormalThumbSize(CScroll* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 2);
	float width = static_cast<float>(args[0].asNumber());
	float height = static_cast<float>(args[1].asNumber());
	self->SetPointingNormalThumbSize(width, height);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ScrollBridge::setPointingOverThumbSize(CScroll* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 2);
	float width = static_cast<float>(args[0].asNumber());
	float height = static_cast<float>(args[1].asNumber());
	self->SetPointingOverThumbSize(width, height);

	return ScriptObject();
}


Bridge::ScriptObject Bridge::ScrollBridge::setPointingFocusThumbSize(CScroll* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 2);
	float width = static_cast<float>(args[0].asNumber());
	float height = static_cast<float>(args[1].asNumber());
	self->SetPointingFocusThumbSize(width, height);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ScrollBridge::setTrackShadowColor(CScroll* self, const ScriptArray& args)
{
	guint8 r = 0, g = 0, b = 0, a = 0;

	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) { r = args[0].asNumber(); }
		if (args.has(1) && args[1].isNumber()) { g = args[1].asNumber(); }
		if (args.has(2) && args[2].isNumber()) { b = args[2].asNumber(); }
		if (args.has(3) && args[3].isNumber()) { a = args[3].asNumber(); }
	}
	ClutterColor c = { r, g, b, a };

	self->SetTrackShadowColor(c);

	return ScriptObject();
}

void Bridge::ScrollListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	context.bindFunction<InternalScrollListener, &InternalScrollListener::GetValueChangedCallBack, &InternalScrollListener::SetValueChangedCallBack>("onValueChanged");
}

void* Bridge::ScrollListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalScrollListener;
}

bool Bridge::InternalScrollListener::OnValueChanged(class IScroll* scroll, EValueChangedType type)
{
	if (true == ValueChangedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CScroll*>(scroll)));
		args.set(1, static_cast<EValueChangedType>(type));
		ValueChangedCb.function.invoke(args);
	}

	return true;
}


// for old APIs
Bridge::ScriptObject Bridge::ScrollBridge::setMinValue(CScroll* scroll, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);
	int value = static_cast<int>(args[0].asNumber());
	scroll->SetMinValue(value);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ScrollBridge::setMaxValue(CScroll* scroll, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);
	int value = static_cast<int>(args[0].asNumber());
	scroll->SetMaxValue(value);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ScrollBridge::setValue(CScroll* scroll, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);
	int value = static_cast<int>(args[0].asNumber());
	scroll->SetValue(value);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ScrollBridge::setPointingNormalThumbImage(CScroll* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);

	// argument is image path
	std::string imagePath = args[0].asString();
	self->SetPointingNormalThumbImage(imagePath);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ScrollBridge::setPointingOverThumbImage(CScroll* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);

	// argument is image path
	std::string imagePath = args[0].asString();
	self->SetPointingOverThumbImage(imagePath);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ScrollBridge::setPointingFocusThumbImage(CScroll* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);

	// argument is image path
	std::string imagePath = args[0].asString();
	self->SetPointingFocusThumbImage(imagePath);

	return ScriptObject();
}

//Bridge::ScriptObject Bridge::ScrollBridge::setTopTrackHeight(CScroll* self, const ScriptArray& args)
//{
//	ASSERT(args.Length() == 1);
//	float value = static_cast<float>(args[0].asNumber());
//	self->SetRolloverTrackHeight(value);
//
//	return ScriptObject();
//}
//
//Bridge::ScriptObject Bridge::ScrollBridge::setTopTrackColor(CScroll* self, const ScriptArray& args)
//{
//	guint8 r = 0, g = 0, b = 0, a = 0;
//
//	if (args.Length() > 0)
//	{
//		if (args.has(0) && args[0].isNumber()) { r = args[0].asNumber(); }
//		if (args.has(1) && args[1].isNumber()) { g = args[1].asNumber(); }
//		if (args.has(2) && args[2].isNumber()) { b = args[2].asNumber(); }
//		if (args.has(3) && args[3].isNumber()) { a = args[3].asNumber(); }
//	}
//	ClutterColor c = { r, g, b, a };
//
//	self->SetBackgroundColor(c);
//
//	return ScriptObject();
//}

Bridge::ScriptObject Bridge::ScrollBridge::setTrackShadowHeight(CScroll* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);
	float value = static_cast<float>(args[0].asNumber());
	self->SetTrackShadowHeight(value);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ScrollBridge::setRolloverTrackHeight(CScroll* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);
	float value = static_cast<float>(args[0].asNumber());
	self->SetRolloverTrackHeight(value);

	return ScriptObject();
}