#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void LabelBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.captureMethodCall<CLabel, &setImage>("setImage");
	context.captureMethodCall<CLabel, &setText>("setText");
	context.captureMethodCall<CLabel, &setTextColor>("setTextColor");
	context.captureMethodCall<CLabel, &setTextFont>("setTextFont");
	context.captureMethodCall<CLabel, &setFontSize>("setFontSize");
	context.captureMethodCall<CLabel, &enableMultiLine>("enableMultiLine");
}

//IActor* LabelBridge::constructWidget(IActor* parent, float width, float height, const ScriptObject& args)
//{
//	//printf("%d\n", args.Length());
//	//ASSERT(args.Length() == 0);
//
//	ILabel* label = ILabel::CreateInstance(parent, width, height);
//	return label;
//}

Widget* Bridge::LabelBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	CLabel* label = dynamic_cast<CLabel*>(ILabel::CreateInstance(parent, width, height));
	return label;
}

Bridge::ScriptObject Bridge::LabelBridge::enableMultiLine(CLabel* self, const ScriptArray& args)
{
	bool flag = false;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isBool())
		{
			flag = args[0].asBool();
		}
	}

	self->EnableMultiLine(flag);
	return ScriptObject();
}

ScriptObject LabelBridge::setImage(CLabel* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IImageBuffer* buffer = unwrapNativeObject<IImageBuffer>(args[0]);
		self->SetImage(buffer);
	}

	return ScriptObject();
}

ScriptObject LabelBridge::setText(CLabel* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString())
		{
			std::string textStr = args[0].asString().c_str();
			self->SetText(textStr.c_str());
		}
	}

	return ScriptObject();
}

ScriptObject LabelBridge::setTextColor(CLabel* self, const ScriptArray& args)
{
	guint8 r, g, b, a;
	r = g = b = a = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {r = static_cast<guint8>(args[0].asNumber());}
		if (args.has(1) && args[1].isNumber()) {g = static_cast<guint8>(args[1].asNumber());}
		if (args.has(2) && args[2].isNumber()) {b = static_cast<guint8>(args[2].asNumber());}
		if (args.has(3) && args[3].isNumber()) {a = static_cast<guint8>(args[3].asNumber());}
	}
	ClutterColor c = { r, g, b, a };
	self->SetTextColor(c);

	return ScriptObject();
}

ScriptObject LabelBridge::setTextFont(CLabel* self, const ScriptArray& args)
{
	std::string font;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString())
		{
			self->SetTextFont(args[0].asString().c_str());
		}
	}

	return ScriptObject();
}

ScriptObject LabelBridge::setFontSize(CLabel* self, const ScriptArray& args)
{
	int fontSize = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) { fontSize = (int)args[0].asNumber(); }
	}
	self->SetFontSize(fontSize);

	return ScriptObject();
}

