#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void RendererBridge::mapScriptInterface(ScriptContext& context)
{
	context.bindFunction<InternalRender, &InternalRender::GetDrawCallBack, &InternalRender::SetDrawCallBack>("onDraw");
	context.bindFunction<InternalRender, &InternalRender::GetUpdateCallBack, &InternalRender::SetUpdateCallBack>("onUpdate");
	context.bindFunction<InternalRender, &InternalRender::GetResizeCallBack, &InternalRender::SetResizeCallBack>("onResize");
	context.bindFunction<InternalRender, &InternalRender::GetTransformStyleCallBack, &InternalRender::SetTransformStyleCallBack>("onTransformStyle");
	context.bindFunction<InternalRender, &InternalRender::GetReleaseCallBack, &InternalRender::SetReleaseCallBack>("onRelease");
	context.bindNativeReference<InternalRender, Widget, &InternalRender::GetRootWidget, &InternalRender::SetRootWidget>("root");
	context.bindNativeReference<InternalRender, CThumbnail, &InternalRender::GetThumbnail, &InternalRender::SetThumbnail>("thumbnail");
}

void* RendererBridge::constructFromScript(const ScriptArray& args)
{
	InternalRender *renderer = new InternalRender;
	ASSERT(NULL != renderer);

	renderer->bridge = this;

	return renderer;
}

void RendererBridge::destroyRenderer(InternalRender *renderer)
{
#ifdef WIN32
	releaseForGarbageCollection(renderer);
#else
	releaseForGarbageCollection(renderer->bridge, renderer);
#endif
}

InternalRender::~InternalRender(void)
{
	RendererBridge::destroyRenderer(this);

	bool flagThumbIsSubOfRoot = false;

	for (Widget *p = m_thumbnail; NULL != p && false == flagThumbIsSubOfRoot; p = p->getParent())
	{
		if (m_root == p)
		{
			flagThumbIsSubOfRoot = true;
		}
	}

	if (NULL != m_root)
	{
		delete m_root;
	}

	if (NULL != m_thumbnail && false == flagThumbIsSubOfRoot)
	{
		delete m_thumbnail;
	}
}

void InternalRender::Draw(IData *data, IActor* parent, E_DRAW_TYPE drawType)
{
	if (true == DrawCb.flagExist)
	{
		std::string drawTypeString;

		switch (drawType)
		{
		case LOAD_DATA_DRAW:
			drawTypeString = "LoadData";
			break;

		case UNLOAD_DATA_DRAW:
			drawTypeString = "UnloadData";
			break;

		case UPDATE_DATA_DRAW:
			drawTypeString = "UpdateData";
			break;

		case ITEM_SCROLL_DRAW:
			drawTypeString = "ItemScroll";
			break;

		case FOCUS_CHANGE_START_FROM_DRAW:
			drawTypeString = "FromItemFocusChangeAniStart";
			break;

		case FOCUS_CHANGE_START_TO_DRAW:
			drawTypeString = "ToItemFocusChangeAniStart";
			break;
				
		case FOCUS_CHANGE_FINISH_FROM_DRAW:
			drawTypeString = "FormItemFocusChangeAniEnd";
			break;

		case FOCUS_CHANGE_FINISH_TO_DRAW:
			drawTypeString = "ToItemFocusChangeAniEnd";
			break;

		default:
			break;
		}

		float parentW, parentH;
		parent->GetSize(parentW, parentH);

		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(this));
		args.set(1, drawTypeString);
		args.set(2, ActorBridge::wrapNativeObjectToJS(data));
		args.set(3, parentW);
		args.set(4, parentH);

		DrawCb.function.invoke(args);
	}
}

void InternalRender::Update(IData *data, IActor* parent)
{
	if (true == UpdateCb.flagExist)
	{
		float parentW, parentH;
		parent->GetSize(parentW, parentH);

		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(data));
		args.set(1, parentW);
		args.set(2, parentH);

		UpdateCb.function.invoke(args);
	}
}

void InternalRender::Resize(IData *data, IActor* parent, ClutterSize destSize, bool flagAni, int animationDuration)
{
	if (true == ResizeCb.flagExist)
	{
		float parentW, parentH;
		parent->GetSize(parentW, parentH);

		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(this));
		args.set(1, ActorBridge::wrapNativeObjectToJS(data));
		args.set(2, destSize.width);
		args.set(3, destSize.height);

		std::string test = (true == flagAni) ? "withAni" : "noAni";
		args.set(4, test);
		args.set(5, animationDuration);

		ResizeCb.function.invoke(args);
	}
}

void InternalRender::OnTransformStyle(IData *data, IActor* parent, int fromStyle, int toStyle, int parentWidth, int parentHeight, bool flagAni, int animationDuration)
{
	if (true == TransformStyleCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(this));
		args.set(1, ActorBridge::wrapNativeObjectToJS(data));
		args.set(2, fromStyle);
		args.set(3, toStyle);

		args.set(4, parentWidth);
		args.set(5, parentHeight);

		std::string test = (true == flagAni) ? "withAni" : "noAni";
		args.set(6, test);
		args.set(7, animationDuration);

		TransformStyleCb.function.invoke(args);
	}
}