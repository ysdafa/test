#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void EventManagerBridge::mapScriptInterface(ScriptContext& context)
{
	//Methods
	context.captureMethodCall<IEventManager, &sendEventLocal>("sendEventLocal");
	context.captureMethodCall<IEventManager, &sendEventLocalSync>("sendEventLocalSync");
	context.captureMethodCall<IEventManager, &sendEventRemote>("sendEventRemote");

    context.captureMethodCall<IEventManager, &addSystemEventListener>("addSystemEventListener");
    context.captureMethodCall<IEventManager, &removeSystemEventListener>("removeSystemEventListener");
    context.captureMethodCall<IEventManager, &addCustomEventListener>("addCustomEventListener");
	context.captureMethodCall<IEventManager, &removeCustomEventListener>("removeCustomEventListener");
	context.captureMethodCall<IEventManager, &getEventType>("getEventType");
	context.captureMethodCall<IEventManager, &getEventName>("getEventName");
	context.captureMethodCall<IEventManager, &registerInterestingEvent>("registerInterestingEvent");
	context.captureMethodCall<IEventManager, &unregisterInterestingEvent>("unregisterInterestingEvent");
	context.captureMethodCall<IEventManager, &setKeyLongPressInterval>("setKeyLongPressInterval");
	context.captureMethodCall<IEventManager, &getKeyLongPressInterval>("getKeyLongPressInterval");
}

ScriptObject EventManagerBridge::sendEventLocal(IEventManager* self, const ScriptArray& args)
{
	//printf("EventManagerBridge::sendEventLocal self,args length %d\n",args.Length());
	IEvent *event1 = NULL;
	if (args.Length() > 0)
	{
		event1 = unwrapNativeObject<IEvent>(args[0]);
	}

	return ScriptObject(self->SendEventLocal(event1));	
}

ScriptObject EventManagerBridge::sendEventLocalSync(IEventManager* self, const ScriptArray& args)
{
	IEvent *reqEvent = NULL;
	IEvent *resEvent = NULL;
	if (args.Length() > 0)
	{
		reqEvent = unwrapNativeObject<IEvent>(args[0]);
		resEvent = unwrapNativeObject<IEvent>(args[1]);
	}

	return ScriptObject(self->SendEventLocalSync(reqEvent, resEvent));	
}

ScriptObject EventManagerBridge::sendEventRemote(IEventManager* self, const ScriptArray& args)
{
	std::string target;
	IEvent *requestEvent = NULL;
	bool bAsync = false;
	bool* pbHasResponse = NULL;
	IEvent *responseEvent = NULL;
	
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString())  
		{
			target = args[0].asString();
		}
		if (args.has(1))
		{
			requestEvent = unwrapNativeObject<IEvent>(args[1]);
		}
		if (args.has(2) && args[2].isBool())  
		{
			bAsync = args[2].asBool();	
		}
			
		if (args.has(3) && args[3].isBool())  
		{
			pbHasResponse = new bool;
			*pbHasResponse = args[3].asBool();
		}

		if (args.has(4))
		{
			responseEvent = unwrapNativeObject<IEvent>(args[4]);
		}
	}

	bool result = self->SendEventRemote(target.c_str(), requestEvent, bAsync, pbHasResponse, responseEvent);	

	ScriptObject object;
	object.set("result", ScriptObject(result));

	if (result && pbHasResponse)
	{
		object.set("response", ScriptObject(*pbHasResponse));
		delete pbHasResponse;
		pbHasResponse = NULL;
	}
	return object;
}

ScriptObject EventManagerBridge::addSystemEventListener(IEventManager* self, const ScriptArray& args)
{
	ISystemEventListener *systemListener = NULL;
	if (args.Length() > 0)
	{
		systemListener = unwrapNativeObject<ISystemEventListener>(args[0]);	
	}

	return ScriptObject(self->AddSystemEventListener(systemListener));
}

ScriptObject EventManagerBridge::removeSystemEventListener(IEventManager* self, const ScriptArray& args)
{
	ISystemEventListener *systemListener = NULL;
	if (args.Length() > 0)
	{
		systemListener = unwrapNativeObject<ISystemEventListener>(args[0]);	
	}

	return ScriptObject(self->RemoveSystemEventListener(systemListener));
}

ScriptObject EventManagerBridge::addCustomEventListener(IEventManager* self, const ScriptArray& args)
{
	ICustomEventListener *customListener = NULL;

	if (args.Length() > 0)
	{
		customListener = unwrapNativeObject<ICustomEventListener>(args[0]);	
	}

	return ScriptObject(self->AddCustomEventListener(customListener));
}

ScriptObject EventManagerBridge::removeCustomEventListener(IEventManager* self, const ScriptArray& args)
{
	ICustomEventListener *customListener = NULL;
	if (args.Length() > 0)
	{
		customListener = unwrapNativeObject<ICustomEventListener>(args[0]);	
	}

	return ScriptObject(self->RemoveCustomEventListener(customListener));
}

ScriptObject EventManagerBridge::getEventType(IEventManager* self, const ScriptArray& args)
{
	std::string eventName;

	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString())  
		{
			eventName = args[0].asString();	
		}
	}

	return ScriptObject(self->GetEventType(eventName.c_str()));
}

ScriptObject EventManagerBridge::getEventName(IEventManager* self, const ScriptArray& args)
{
	int eventType = 0;

	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())  
		{
			eventType = args[0].asNumber();	
		}
	}

	std::string eventName = self->GetEventName(eventType);
	
	return ScriptObject(eventName);
}


ScriptObject EventManagerBridge::registerInterestingEvent(IEventManager* self, const ScriptArray& args)
{
	std::string eventName;

	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString())  
		{
			eventName = args[0].asString();	
		}
	}

	self->RegisterInterestingEvent((char*)(eventName.c_str()));

	return ScriptObject();
}

ScriptObject EventManagerBridge::unregisterInterestingEvent(IEventManager* self, const ScriptArray& args)
{
	std::string eventName;

	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString())  
		{
			eventName = args[0].asString();	
		}
	}
	self->UnregisterInterestingEvent((char*)(eventName.c_str()));
	return ScriptObject();
}

ScriptObject EventManagerBridge::setKeyLongPressInterval(IEventManager* self, const ScriptArray& args)
{
	guint32 keyval = 0;

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) 
		{
			keyval = args[0].asNumber();
		}
	}
	
	self->SetKeyLongPressInterval(keyval);
	
	return ScriptObject();
}

ScriptObject EventManagerBridge::getKeyLongPressInterval(IEventManager* self, const ScriptArray& args)
{
	guint32 keyval = 0;
	
	keyval = self->KeyLongPressInterval();

	return ScriptObject((double)keyval);
}

