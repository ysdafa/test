#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void HaloUtilBridge::mapScriptInterface(ScriptContext& context)
{
	context.captureMethodCall<IUtility, &extractForegroundColor>("extractForegroundColor");
	context.captureMethodCall<IUtility, &getCurrentResolution>("getCurrentResolution");
	context.captureMethodCall<IUtility, &asyncRelease>("asyncRelease");
}

ScriptObject HaloUtilBridge::extractForegroundColor(IUtility* self, const ScriptArray& args)
{
	int from_r = 0, from_g = 0, from_b = 0;
	if (args.has(0) && args[0].isNumber())
	{
		from_r = args[0].asNumber();
	}
	if (args.has(1) && args[1].isNumber())
	{
		from_g = args[1].asNumber();
	}
	if (args.has(2) && args[2].isNumber())
	{
		from_b = args[2].asNumber();
	}

	int to_r = 0, to_g = 0, to_b = 0;
	ScriptObject retval = ScriptObject();
	retval.set("success", ScriptObject(self->ExtractForegroundColor(from_r, from_g, from_b, (uint*)&to_r, (uint*)&to_g, (uint*)&to_b)));
	ScriptObject colval = ScriptObject();
	colval.set("r", ScriptObject(to_r));
	colval.set("g", ScriptObject(to_g));
	colval.set("b", ScriptObject(to_b));
	retval.set("color", colval);

	return retval;
}

ScriptObject HaloUtilBridge::getCurrentResolution(IUtility* self, const ScriptArray& args)
{
	int hRes = 0, vRes = 0;

	ScriptObject retval = ScriptObject();
	retval.set("success", ScriptObject(self->GetCurrentResolution(hRes, vRes)));
	retval.set("hRes", hRes);
	retval.set("vRes", vRes);

	return retval;
}

ScriptObject HaloUtilBridge::asyncRelease(IUtility* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		Widget* target = unwrapNativeObject<Widget>(args[0]);
		self->AsyncRelease(target);
	}
	
	return ScriptObject();
}

