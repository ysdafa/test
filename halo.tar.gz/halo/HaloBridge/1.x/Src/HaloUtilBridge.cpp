#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

#define DEFINE_KEY_MAP(context,key) (context).bindNumber<HaloUtilBridge, int, \
	&HaloUtilBridge::get##key, \
	&HaloUtilBridge::set##key>(#key)

void HaloUtilBridge::mapScriptInterface(ScriptContext& context)
{
	context.captureMethodCall<IUtility, &extractForegroundColor>("extractForegroundColor");
	context.captureMethodCall<IUtility, &extractIconColor>("extractIconColor");
	context.captureMethodCall<IUtility, &getCurrentResolution>("getCurrentResolution");
	context.captureMethodCall<IUtility, &asyncRelease>("asyncRelease");
	context.captureMethodCall<IUtility, &setOrientation>("setOrientation");
	context.captureMethodCall<IUtility, &getOrientation>("getOrientation");
	context.captureMethodCall<IUtility, &applyOrientation>("applyOrientation");

	context.bindBoolean<IUtility, &IUtility::IsHighContrastEnabled, &IUtility::EnableHighContrast>("highContrast");
	context.bindBoolean<IUtility, &IUtility::IsEnlargeEnabled, &IUtility::EnableEnlarge>("enlarge");

	context.captureMethodCall<IUtility, &isCursorVisible>("isCursorVisible");
	context.bindBoolean<IUtility, &IUtility::Is720PEnabled, &IUtility::Enable720P>("enable720P");
	DEFINE_KEY_MAP(context, CC_BLACK);
	DEFINE_KEY_MAP(context, CC_WHITE);
	DEFINE_KEY_MAP(context, RESOLUTION_1080);
	DEFINE_KEY_MAP(context, RESOLUTION_720);
}

ScriptObject HaloUtilBridge::extractForegroundColor(IUtility* self, const ScriptArray& args)
{
	int from_r = 0, from_g = 0, from_b = 0;
	if (args.has(0) && args[0].isNumber())
	{
		from_r = args[0].asNumber();
	}
	if (args.has(1) && args[1].isNumber())
	{
		from_g = args[1].asNumber();
	}
	if (args.has(2) && args[2].isNumber())
	{
		from_b = args[2].asNumber();
	}

	int to_r = 0, to_g = 0, to_b = 0;
	ScriptObject retval = ScriptObject();
	retval.set("success", ScriptObject(self->ExtractForegroundColor(from_r, from_g, from_b, (uint*)&to_r, (uint*)&to_g, (uint*)&to_b)));
	ScriptObject colval = ScriptObject();
	colval.set("r", ScriptObject(to_r));
	colval.set("g", ScriptObject(to_g));
	colval.set("b", ScriptObject(to_b));
	retval.set("color", colval);

	return retval;
}

ScriptObject HaloUtilBridge::extractIconColor(IUtility* self, const ScriptArray& args)
{
	int from_r = 0, from_g = 0, from_b = 0;
	if (args.has(0) && args[0].isNumber()) { from_r = args[0].asNumber(); }
	if (args.has(1) && args[1].isNumber()) { from_g = args[1].asNumber(); }
	if (args.has(2) && args[2].isNumber()) { from_b = args[2].asNumber(); }

	IUtility::ColorCategory cc = self->ExtractIconColor(from_r, from_g, from_b);

	return ScriptObject(cc);
}

ScriptObject HaloUtilBridge::getCurrentResolution(IUtility* self, const ScriptArray& args)
{
	int hRes = 0, vRes = 0;

	ScriptObject retval = ScriptObject();
	retval.set("success", ScriptObject(self->GetCurrentResolution(hRes, vRes)));
	retval.set("hRes", hRes);
	retval.set("vRes", vRes);

	return retval;
}

ScriptObject HaloUtilBridge::asyncRelease(IUtility* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		Widget* target = unwrapNativeObject<Widget>(args[0]);
		self->AsyncRelease(target);
	}
	
	return ScriptObject();
}

ScriptObject HaloUtilBridge::setOrientation(IUtility* self, const ScriptArray& args)
{
	HALO_ASSERT(1 == args.Length() && true == args[0].isString());

	std::string orientationStr = args[0].asString();
	EOrientation orientationValue = ORIENTATION_LEFT_TO_RIGHT;

	if ("left-to-right" == orientationStr)
	{
		orientationValue = ORIENTATION_LEFT_TO_RIGHT;
	}
	else if ("right-to-left" == orientationStr)
	{
		orientationValue = ORIENTATION_RIGHT_TO_LEFT;
	}
	else
	{
		HALO_EXCEPTION(false,  "orientation value is not correct\n");
	}

	self->SetOrientation(orientationValue);

	return ScriptObject();
}

ScriptObject HaloUtilBridge::getOrientation(IUtility* self, const ScriptArray& args)
{
	EOrientation orientation = self->GetOrientation();
	if (orientation == ORIENTATION_LEFT_TO_RIGHT)
	{
		return ScriptObject("left-to-right");
	}
	else if (orientation == ORIENTATION_RIGHT_TO_LEFT)
	{
		return ScriptObject("right-to-left");
	}
	return ScriptObject();

}

ScriptObject HaloUtilBridge::applyOrientation(IUtility* self, const ScriptArray& args)
{
	self->ApplyOrientation();

	return ScriptObject();
}

ScriptObject HaloUtilBridge::isCursorVisible(IUtility* self, const ScriptArray& args)
{
	if (self)
	{
		return ScriptObject(self->IsCursorVisible());
	}
	return ScriptObject(false);
}
