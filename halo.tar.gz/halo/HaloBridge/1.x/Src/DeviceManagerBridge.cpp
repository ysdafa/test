#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void DeviceManagerBridge::mapScriptInterface(ScriptContext& context)
{
	//printf("DeviceManagerBridge::Function %s, context 0x%x\n", __FUNCTION__, &context);
	context.captureMethodCall<IDeviceManager, &getDevice>("getDevice");
	context.captureMethodCall<IDeviceManager, &getGrabedActor>("getGrabedActor");
	context.captureMethodCall<IDeviceManager, &enableDevice>("enableDevice");
	context.captureMethodCall<IDeviceManager, &isDeviceEnabled>("isDeviceEnabled");
}

ScriptObject DeviceManagerBridge::getDevice(IDeviceManager* self, const ScriptArray& args)
{
	int type = CLUTTER_N_DEVICE_TYPES;

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) 
		{
			type = args[0].asNumber();
			return ScriptObject((int)(self->GetDevice((ClutterInputDeviceType)type)));
		}		
	}
	
	return ScriptObject();
}

ScriptObject DeviceManagerBridge::getGrabedActor(IDeviceManager* self, const ScriptArray& args)
{
	if(args.Length() > 0)
	{
		if (args.has(0))
		{
			IDevice *device = unwrapNativeObject<IDevice>(args[0]);
			if (device != nullptr)
			{
					return wrapExistingNativeObject((IAnimatable*)self->GetGrabedActor(device));
			}
		}		
	}	

	return ScriptObject();
}

ScriptObject DeviceManagerBridge::enableDevice(IDeviceManager* self, const ScriptArray& args)
{
	bool flag = false;
	if(args.Length() > 0)
	{
		if (args.Length() == 2 && args[1].isBool())
		{
			flag = args[1].asBool();
		}

		IDevice *device = unwrapNativeObject<IDevice>(args[0]);
		if(device != nullptr) 
		{
			self->EnableDevice(device, flag);
		}
	}

	return ScriptObject();
}

ScriptObject DeviceManagerBridge::isDeviceEnabled(IDeviceManager* self, const ScriptArray& args)
{
	if(args.Length() > 0)
	{
		IDevice *device = unwrapNativeObject<IDevice>(args[0]);
		if(device != nullptr) 
		{
			//printf("[isDeviceEnabled] ret = %d\n", self->IsDeviceEnabled(device));
			return ScriptObject(self->IsDeviceEnabled(device));
		}
	}
	
	return ScriptObject();
}



