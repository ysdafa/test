#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void UtilityBridge::mapScriptInterface(ScriptContext& context)
{
	context.captureMethodCall<CUtility, &extractForegroundColor>("extractForegroundColor");
}

void* UtilityBridge::constructFromScript(const ScriptArray& args)
{
	return new CUtility;
}

ScriptObject UtilityBridge::extractForegroundColor(CUtility* self, const ScriptArray& args)
{
	int from_r = 0, from_g = 0, from_b = 0;
	if (args.has(0) && args[0].isNumber()) { from_r = args[0].asNumber(); }
	if (args.has(1) && args[1].isNumber()) { from_g = args[1].asNumber(); }
	if (args.has(2) && args[2].isNumber()) { from_b = args[2].asNumber(); }

	int to_r = 0, to_g = 0, to_b = 0;
	ScriptObject retval = ScriptObject();
	retval.set("success", ScriptObject(self->ExtractForegroundColor(from_r, from_g, from_b, (uint*)&to_r, (uint*)&to_g, (uint*)&to_b)));
	ScriptObject colval = ScriptObject();
	colval.set("r", ScriptObject(to_r));
	colval.set("g", ScriptObject(to_g));
	colval.set("b", ScriptObject(to_b));
	retval.set("color", colval);

	return retval;
}




