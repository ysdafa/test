#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void ImageBufferBridge::mapScriptInterface(ScriptContext& context)
{
	context.captureMethodCall<IImageBuffer, &clone>("clone");
	//context.captureMethodCall<IImageBuffer, &setImagePath>("setImagePath");
}

void* ImageBufferBridge::constructFromScript(const ScriptArray& args)
{
	IImageBuffer *cBuffer = constructWidget(args);
	return cBuffer;
}

IImageBuffer* ImageBufferBridge::constructWidget(const ScriptArray& args)
{
	IImageBuffer *cBuffer = NULL;
	if (args.Length() > 0)
	{
		if (args[0].isString() && args.has(1) && args[1].isNumber())
		{
			cBuffer = IImageBuffer::CreateInstance(args[0].asString().data(), args[1].asNumber());
		}
		else if (args[0].isString())
		{
			cBuffer = IImageBuffer::CreateInstance(args[0].asString().data());
		}
		else
		{
			cBuffer = IImageBuffer::CreateInstance(unwrapNativeObject<IImageBuffer>(args[0]));
		}
	}

	return cBuffer;
}

ScriptObject ImageBufferBridge::clone(IImageBuffer* self, const ScriptArray& args)
{
	IImageBuffer *cBuffer;
	cBuffer = self->Clone();

	return wrapExistingNativeObject(cBuffer);
}

ScriptObject ImageBufferBridge::setImagePath(IImageBuffer* self, const ScriptArray& args)
{
	return ScriptObject();
}
