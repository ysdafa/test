#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void ActionBridge::mapScriptInterface(ScriptContext& context)
{
}

bool ActionBridge::Process(IEvent* inEvent, IEvent** outEvent)
{
	if (isOnProcess)
	{
		ScriptArray args;
		args.set(0, wrapExistingNativeObject(inEvent));	
		args.set(1, wrapExistingNativeObject(outEvent));	

		m_onProcess.invoke(args);
	}

	return true;
}

bool ActionBridge::IsInterestEvent(IEvent* event)
{
	if (isInterestEventType)
	{
		ScriptArray args;
		args.set(0, wrapExistingNativeObject(event));		

		m_isInterestEventType.invoke(args);
	}

	return true;
}

// ClickActionBridge
void ClickActionBridge::mapScriptInterface(ScriptContext& context)
{
	ActionBridge::mapScriptInterface(context);
}

IAction* ClickActionBridge::constructSubAction(const ScriptArray& args)
{
	//printf("Function ClickActionBridge::%s, args length is %d\n", __FUNCTION__, args.Length());
	isInterestEventType = false;
	isOnProcess = false;
	IActor* actor = nullptr;
	CActor* p = nullptr;

	if (args.Length() > 0)
	{
		//actor = unwrapNativeObject<IActor>(args[0]); 
		p = unwrapNativeObject<CActor>(args[0]);
		actor = dynamic_cast<IActor*>(p);

		if (args.has(1))
		{
			ScriptObject options = args[1];
			if (options.has("isInterestEventType"))
			{
				m_isInterestEventType = options["isInterestEventType"].asFunction();
				isInterestEventType = true;
			}
			if (options.has("onProcess"))
			{
				m_onProcess = options["onProcess"].asFunction();
				isOnProcess = true;
			}	
		}
	}

	IClickAction* clickAction;
	clickAction = IClickAction::CreateInstance(actor);

	return clickAction;
}

// DragActionBridge
void DragActionBridge::mapScriptInterface(ScriptContext& context)
{
	ActionBridge::mapScriptInterface(context);

	context.captureMethodCall<IAction, &setDragAxis>("setDragAxis");
	context.captureMethodCall<IAction, &setDragArea>("setDragArea");
}

ScriptObject DragActionBridge::setDragAxis(IAction* self, const ScriptArray& args)
{
	IDragAction *dragAction = dynamic_cast<IDragAction*>(self);
	HALO_ASSERT(NULL != dragAction);
	guint8 axis = CLUTTER_DRAG_AXIS_NONE;

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) 
		{
			axis = args[0].asNumber();
		}
	}

	if (dragAction)
	{
		dragAction->SetDragAxis((ClutterDragAxis)axis);
	}	

	return ScriptObject();
}

ScriptObject DragActionBridge::getDragAxis(IAction* self, const ScriptArray& args)
{
	IDragAction *dragAction = dynamic_cast<IDragAction*>(self);
	HALO_ASSERT(NULL != dragAction);
	guint8 axis = CLUTTER_DRAG_AXIS_NONE;

	if (dragAction)
	{
		axis = dragAction->GetDragAxis();
	}	

	return ScriptObject(axis);
}

ScriptObject DragActionBridge::setDragArea(IAction* self, const ScriptArray& args)
{
	IDragAction *dragAction = dynamic_cast<IDragAction*>(self);
	HALO_ASSERT(NULL != dragAction);

	float x = 0.0;
	float y = 0.0;
	float w = 0.0;
	float h = 0.0;
	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) {x = args[0].asNumber();}
		if(args.has(1) && args[1].isNumber()) {y = args[1].asNumber();}
		if(args.has(2) && args[2].isNumber()) {w = args[2].asNumber();}
		if(args.has(3) && args[3].isNumber()) {h = args[3].asNumber();}
	}

	if (dragAction)
	{
		dragAction->SetDragArea(x, y, w, h);
	}

	

	return ScriptObject();
}

ScriptObject DragActionBridge::getDragArea(IAction* self, const ScriptArray& args)
{
	IDragAction *dragAction = dynamic_cast<IDragAction*>(self);
	HALO_ASSERT(NULL != dragAction);
	ClutterRect drag_area;

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) {drag_area.origin.x = args[0].asNumber();}
		if(args.has(1) && args[1].isNumber()) {drag_area.origin.y = args[1].asNumber();}
		if(args.has(2) && args[2].isNumber()) {drag_area.size.width = args[2].asNumber();}
		if(args.has(3) && args[3].isNumber()) {drag_area.size.height = args[3].asNumber();}
	}

	if (dragAction)
	{
		dragAction->GetDragArea(&drag_area);
	}	

	return ScriptObject();
}

IAction* DragActionBridge::constructSubAction(const ScriptArray& args)
{
	//printf("Function DragActionBridge::%s, args length is %d\n", __FUNCTION__, args.Length());
	isInterestEventType = false;
	isOnProcess = false;
	IActor* actor = nullptr;
	CActor* p = nullptr;


	if (args.Length() > 0)
	{
		p = unwrapNativeObject<CActor>(args[0]); 
		actor = dynamic_cast<IActor*>(p);

		if (args.has(1))
		{
			ScriptObject options = args[1];
			if (options.has("isInterestEventType"))
			{
				m_isInterestEventType = options["isInterestEventType"].asFunction();
				isInterestEventType = true;
			}
			if (options.has("onProcess"))
			{
				m_onProcess = options["onProcess"].asFunction();
				isOnProcess = true;
			}	
		}
				
	}

	IDragAction* dragAction;
	dragAction = IDragAction::CreateInstance(actor);

	return dragAction;
}

// GestureActionBridge
void GestureActionBridge::mapScriptInterface(ScriptContext& context)
{
	ActionBridge::mapScriptInterface(context);	
}

IAction* GestureActionBridge::constructSubAction(const ScriptArray& args)
{
	//printf("Function GestureActionBridge::%s, args length is %d\n", __FUNCTION__, args.Length());
	isInterestEventType = false;
	isOnProcess = false;
	IActor* actor = nullptr;
	CActor* p = nullptr;

	if (args.Length() > 0)
	{
		p = unwrapNativeObject<CActor>(args[0]);
		actor = dynamic_cast<IActor*>(p);

		if (args.has(1))
		{
			ScriptObject options = args[1];
			if (options.has("isInterestEventType"))
			{
				m_isInterestEventType = options["isInterestEventType"].asFunction();
				isInterestEventType = true;
			}
			if (options.has("onProcess"))
			{
				m_onProcess = options["onProcess"].asFunction();
				isOnProcess = true;
			}	
		}
	}

	IGestureAction* gestureAction;
	gestureAction = IGestureAction::CreateInstance(actor);

	return gestureAction;
}

// KeyLongPressActionBridge
void KeyLongPressActionBridge::mapScriptInterface(ScriptContext& context)
{
	ActionBridge::mapScriptInterface(context);

	context.captureMethodCall<IAction, &addKeyLongPressKey>("addKeyLongPressKey");
	context.captureMethodCall<IAction, &removeKeyLongPressKey>("removeKeyLongPressKey");
}

ScriptObject KeyLongPressActionBridge::addKeyLongPressKey(IAction* self, const ScriptArray& args)
{
	IKeyLongPressAction *keyLongPressAction = dynamic_cast<IKeyLongPressAction*>(self);
	HALO_ASSERT(NULL != keyLongPressAction);
	guint32 keyval = 0;

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) 
		{
			keyval = args[0].asNumber();
		}
	}

	if (keyLongPressAction)
	{
		keyLongPressAction->AddLongPressKey(keyval);
	}	

	return ScriptObject();
}

ScriptObject KeyLongPressActionBridge::removeKeyLongPressKey(IAction* self, const ScriptArray& args)
{
	IKeyLongPressAction *keyLongPressAction = dynamic_cast<IKeyLongPressAction*>(self);
	HALO_ASSERT(NULL != keyLongPressAction);
	guint32 keyval = 0;

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) 
		{
			keyval = args[0].asNumber();
		}
	}

	if (keyLongPressAction)
	{
		keyLongPressAction->RemoveLongPressKey(keyval);
	}

	return ScriptObject();	
}

IAction* KeyLongPressActionBridge::constructSubAction(const ScriptArray& args)
{
	//printf("Function KeyLongPressActionBridge::%s, args length is %d\n", __FUNCTION__, args.Length());
	isInterestEventType = false;
	isOnProcess = false;
	IActor* actor = nullptr;
	CActor* p = nullptr;

	if (args.Length() > 0)
	{
		//actor = unwrapNativeObject<IActor>(args[0]); 
		p = unwrapNativeObject<CActor>(args[0]);
		actor = dynamic_cast<IActor*>(p);

		if (args.has(1))
		{
			ScriptObject options = args[1];
			if (options.has("isInterestEventType"))
			{
				m_isInterestEventType = options["isInterestEventType"].asFunction();
				isInterestEventType = true;
			}
			if (options.has("onProcess"))
			{
				m_onProcess = options["onProcess"].asFunction();
				isOnProcess = true;
			}		
		}
	}

	IKeyLongPressAction* keyLongPressAction;
	keyLongPressAction = IKeyLongPressAction::CreateInstance(actor);

	return keyLongPressAction;
}

// KeyCombinationActionBridge
void KeyCombinationActionBridge::mapScriptInterface(ScriptContext& context)
{
	ActionBridge::mapScriptInterface(context);
}

IAction* KeyCombinationActionBridge::constructSubAction(const ScriptArray& args)
{
	//printf("Function KeyCombinationActionBridge::%s, args length is %d\n", __FUNCTION__, args.Length());
	isInterestEventType = false;
	isOnProcess = false;
	IActor* actor = nullptr;
	CActor* p = nullptr;

	if (args.Length() > 0)
	{
		//actor = unwrapNativeObject<IActor>(args[0]); 
		p = unwrapNativeObject<CActor>(args[0]);
		actor = dynamic_cast<IActor*>(p); 

		if (args.has(1))
		{
			ScriptObject options = args[1];
			if (options.has("isInterestEventType"))
			{
				m_isInterestEventType = options["isInterestEventType"].asFunction();
				isInterestEventType = true;
			}
			if (options.has("onProcess"))
			{
				m_onProcess = options["onProcess"].asFunction();
				isOnProcess = true;
			}	
		}
	}

	IKeyCombinationAction* keyCombinationAction;
	keyCombinationAction = IKeyCombinationAction::CreateInstance(actor);

	return keyCombinationAction;
}




