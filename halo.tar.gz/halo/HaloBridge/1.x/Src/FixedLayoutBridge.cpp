#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void FixedLayoutBridge::mapScriptInterface(ScriptContext& context)
{
	LayoutManagerBridge::mapScriptInterface(context);
}

ILayout* FixedLayoutBridge::constructWidget(const ScriptArray& args)
{
	IFixedLayout *fixedlayout = IFixedLayout::CreateInstance();
	return fixedlayout;

}

