#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;
using namespace v8;

#if 0
typedef struct _Args
{
	Isolate* isolate;
	void* param;
}Args;
#endif

void TaskListenerBridge::mapScriptInterface(ScriptContext& context)
{
	context.captureMethodCall<ITaskListener, &SetTask>("SetTask");
	context.captureMethodCall<ITaskListener, &GetTask>("GetTask");
}
void* TaskListenerBridge::constructFromScript(const ScriptArray& args)
{
	TaskListenerBridge* taskListenerBridge = new TaskListenerBridge();
	ScriptObject options;
	if (args.Length() > 0)
	{
		options = args[0];
		if (options.has("OnStart"))
		{
			taskListenerBridge->m_OnStart = options.get("OnStart").asFunction();
		}
		if (options.has("OnUpdate"))
		{
			taskListenerBridge->m_OnUpdate = options.get("OnUpdate").asFunction();
		}
		if (options.has("OnFinish"))
		{
			taskListenerBridge->m_OnFinish = options.get("OnFinish").asFunction();
		}
		if (options.has("OnCancel"))
		{
			taskListenerBridge->m_OnCancel = options.get("OnCancel").asFunction();
		}
	}
	return taskListenerBridge;
}

ScriptObject TaskListenerBridge::SetTask(ITaskListener* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IAsyncTask* task = unwrapNativeObject<IAsyncTask>(args[0]);
		if (task != NULL)
		{
			self->SetTask(task);
		}
	}
	return ScriptObject();
}

ScriptObject TaskListenerBridge::GetTask(ITaskListener* self, const ScriptArray& args)
{
	IAsyncTask* task = self->GetTask();
	return wrapExistingNativeObject<IAsyncTask>(task);
}
void* TaskListenerBridge::OnStart(void* params)
{
	void* ret = NULL;
#if 0
	Isolate* isolate = NULL;
	Isolate* current = Isolate::GetCurrent();
	if (current == NULL)
	{
		g_message("Isolate is NULL.");
	}
	else
	{
		g_message("Isolate is %p", current);
	}
	void* param = NULL;
	if (params)
	{
		isolate = ((Args*)params)->isolate;
		param = ((Args*)params)->param;
	}
	if (isolate == NULL)
	{
		//! Remove gbs building warning
		char *temp = (char*)params;
		delete temp;
		return NULL;
	}
	Locker locker(isolate);
	current = Isolate::GetCurrent();
	if (current == NULL)
	{
		g_message("Isolate is NULL.");
	}
	else
	{
		g_message("Isolate is %p", current);
	}
	//HandleScope scope(isolate);
	Isolate::Scope isolate_scope(isolate);
	current = Isolate::GetCurrent();
	if (current == NULL)
	{
		g_message("Isolate is NULL.");
	}
	else
	{
		g_message("Isolate is %p", current);
	}
	ScriptArray args;
	if (param)
	{
		args.set(0, ScriptObject((double)(long)param));
	}
	//ScriptFunction func(m_OnStart);
	//ScriptObject result = func.invoke(args);
	ScriptObject result = m_OnStart.invoke(args);
#endif
#if 0
	Isolate* newIsolate = Isolate::New();
	Isolate::Scope isolate_scope(newIsolate);
	v8::HandleScope scope;

	Local<v8::Context> context = Context::New(newIsolate);
	Context::Scope cscope(context);

	ScriptArray args;
	if (params)
	{
		args.set(0, ScriptObject((double)(long)params));
	}
	ScriptObject result = m_OnStart.invoke(args);
	if (result.isNumber())
	{
		ret = (void*)(long)result.asNumber();
	}
#endif
	//delete params;
	//! Remove gbs building warning
	char *temp = (char*)params;
	delete temp;
	return ret;

}
bool TaskListenerBridge::OnUpdate(void* result)
{
	bool ret = false;
	ScriptArray args;
	args.set(0, ScriptObject((double)(long)result));
	ScriptObject resultObject = m_OnUpdate.invoke(args);
	if (resultObject.isBool())
	{
		ret = resultObject.asBool();
	}
	return ret;;
}
bool TaskListenerBridge::OnFinish(void* result)
{
	bool ret = false;
	ScriptArray args;
	args.set(0, ScriptObject((double)(long)result));
	ScriptObject resultObject = m_OnFinish.invoke(args);
	if (resultObject.isBool())
	{
		ret = resultObject.asBool();
	}
	return ret;
}
bool TaskListenerBridge::OnCancel(void* params)
{
	bool ret = false;
	ScriptArray args;
	args.set(0, ScriptObject((double)(long)params));
	ScriptObject result = m_OnCancel.invoke(args);
	if (result.isBool())
	{
		ret = result.asBool();
	}
	return ret;
}

void AsyncTaskBridge::mapScriptInterface(ScriptContext& context)
{
	context.captureMethodCall<IAsyncTask, &Execute>("Execute");
	context.captureMethodCall<IAsyncTask, &Update>("Update");
	context.captureMethodCall<IAsyncTask, &Cancel>("Cancel");
	context.captureMethodCall<IAsyncTask, &SetTaskListener>("SetTaskListener");
	context.captureMethodCall<IAsyncTask, &RemoveTaskListener>("RemoveTaskListener");
}
void* AsyncTaskBridge::constructFromScript(const ScriptArray& args)
{
#if 0
	Args* tArgs = new Args;
	tArgs->isolate = Isolate::GetCurrent();
	{
		//Locker locker(tArgs.isolate);
		//Isolate::Scope scope(tArgs.isolate);
		HandleScope scope(tArgs->isolate);
	}
#endif
	void* params = NULL;
	IThreadPool* threadPool = NULL;
	if (args.Length() >= 1)
	{
		if (args.has(0) && args[0].isNumber())
		{
			params = (void*)(long)args[0].asNumber();
#if 0
			tArgs->param = params;
#endif
		}
	}
	if (args.Length() >= 2)
	{
		threadPool = unwrapNativeObject<IThreadPool>(args[1]);
	}
	//return constructAsyncTask((void*)tArgs, threadPool);
	return constructAsyncTask((void*)params, threadPool);
}

IAsyncTask* AsyncTaskBridge::constructAsyncTask(void* params, IThreadPool* threadPool)
{
	IAsyncTask* cAsyncTask;
	if (params && threadPool)
	{
		cAsyncTask = IAsyncTask::CreateInstance(params, threadPool);
	}
	else if (params)
	{
		cAsyncTask = IAsyncTask::CreateInstance(params);
	}
	else
	{
		cAsyncTask = IAsyncTask::CreateInstance();
	}

	return cAsyncTask;
}

ScriptObject AsyncTaskBridge::Execute(IAsyncTask* self, const ScriptArray& args)
{
	Isolate* isolate = Isolate::GetCurrent();
	if (isolate)
	{
		g_message("Current = %p", isolate);
	}
	else
	{
		g_message("Current = NULL");
	}
	self->Execute();
	return ScriptObject();
}

ScriptObject AsyncTaskBridge::Update(IAsyncTask* self, const ScriptArray& args)
{
	void* result = NULL;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			result = (void*)(long)args[0].asNumber();
		}
	}
	self->Update(result);
	return ScriptObject();
}

ScriptObject AsyncTaskBridge::Cancel(IAsyncTask* self, const ScriptArray& args)
{
	self->Cancel();
	return ScriptObject();
}

ScriptObject AsyncTaskBridge::SetTaskListener(IAsyncTask* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		//ITaskListener* taskListener = unwrapNativeObject<ITaskListener>(args[0]);
		TaskListenerBridge* taskListener = unwrapNativeObject<TaskListenerBridge>(args[0]);
		if (taskListener != NULL)
		{
			self->SetTaskListener(taskListener);
		}
	}
	return ScriptObject();
}

ScriptObject AsyncTaskBridge::RemoveTaskListener(IAsyncTask* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		ITaskListener* taskListener = unwrapNativeObject<ITaskListener>(args[0]);
		if (taskListener != NULL)
		{
			self->RemoveTaskListener(taskListener);
		}
	}
	return ScriptObject();
}
