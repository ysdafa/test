#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void BinLayoutBridge::mapScriptInterface(ScriptContext& context)
{
	LayoutManagerBridge::mapScriptInterface(context);
}

ILayout* BinLayoutBridge::constructWidget(const ScriptArray& args)
{
	IBinLayout *binlayout = IBinLayout::CreateInstance();
	return binlayout;

}

