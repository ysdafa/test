#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void StageBridge::mapScriptInterface(ScriptContext& context)
{
	context.captureMethodCall<IStage, &enableFPSShown>("enableFPSShown");
	context.captureMethodCall<IStage, &setFPSShownInterval>("setFPSShownInterval");
	context.captureMethodCall<IStage, &setFPSLabelFont>("setFPSLabelFont");
	context.captureMethodCall<IStage, &show>("show");
}

ScriptObject StageBridge::enableFPSShown(IStage* self, const ScriptArray& args)
{
	bool flagEnable = false;
	if (args.Length() > 0)
	{
		if (args[0].isBool())
		{
			flagEnable = args[0].asBool();
		}
	}
	
	//self->EnableFPSShown(flagEnable);
	return ScriptObject();
}

ScriptObject StageBridge::setFPSShownInterval(IStage* self, const ScriptArray& args)
{
	double sec = 1.0;
	if (args.Length() > 0)
	{
		if (args[0].isNumber())
		{
			sec = args[0].asNumber();
		}
	}
	//self->SetFPSShownInterval(sec);
	return ScriptObject();
}

ScriptObject StageBridge::setFPSLabelFont(IStage* self, const ScriptArray& args)
{
	std::string font;
	if (args.Length() > 0)
	{
		if (args[0].isString()) 
		{ 
			font = args[0].asString();
		}
	}
	//self->SetFPSLabelFont(font.c_str());

	return ScriptObject();
}

ScriptObject StageBridge::show(IStage* self, const ScriptArray& args)
{
	IStage* stage = IStage::GetInstance();
	stage->Show();
	return ScriptObject();
}
