#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void EventBridge::mapScriptInterface(ScriptContext& context)
{
	//Methods
	context.captureMethodCall<IEvent, &clone>("clone");
	context.captureMethodCall<IEvent, &setReceiver>("setReceiver");
	context.captureMethodCall<IEvent, &receiver>("receiver");
    context.captureMethodCall<IEvent, &setEventType>("setEventType");
    context.captureMethodCall<IEvent, &isEventType>("isEventType");

    context.captureMethodCall<IEvent, &putInt>("putInt");
    context.captureMethodCall<IEvent, &putDouble>("putDouble");
	context.captureMethodCall<IEvent, &putFloat>("putFloat");
	context.captureMethodCall<IEvent, &putChar>("putChar");
	context.captureMethodCall<IEvent, &putString>("putString");
	context.captureMethodCall<IEvent, &putPointor>("putPointor");
	context.captureMethodCall<IEvent, &getInt>("getInt");
    context.captureMethodCall<IEvent, &getDouble>("getDouble");
	context.captureMethodCall<IEvent, &getFloat>("getFloat");
	context.captureMethodCall<IEvent, &getChar>("getChar");
	context.captureMethodCall<IEvent, &getString>("getString");
	context.captureMethodCall<IEvent, &getPointor>("getPointor");

}

IEvent* EventBridge::constructEvent(const ScriptArray& args)
{
	//printf("EventBridge::constructEvent self, args length %d\n", args.Length());
	IEvent *pEvent = nullptr;

	if (args.Length() > 0)
	{
		if (args[0].isNumber())
		{
			pEvent = (IEvent*)((long)args[0].asNumber());
		}
	}
	else
	{
		pEvent = IEvent::CreateInstance();
	}

	return pEvent;
}

void* EventBridge::constructFromScript(const ScriptArray& args)
{
	IEvent *event = constructEvent(args);

	return event;
}

ScriptObject EventBridge::clone(IEvent* self, const ScriptArray& args)
{
	return wrapExistingNativeObject(self->Clone());	
}

ScriptObject EventBridge::setReceiver(IEvent* self, const ScriptArray& args)
{
	IActor *actor = NULL;

	if (args.Length() > 0)
	{
		CActor *object = unwrapNativeObject<CActor>(args[0]);
		actor = dynamic_cast<IActor*>(object);	
	}
	
	return ScriptObject(self->SetReceiver(actor));	
}

ScriptObject EventBridge::receiver(IEvent* self, const ScriptArray& args)
{	
	return wrapExistingNativeObject(self->Receiver());	
}

ScriptObject EventBridge::setEventType(IEvent* self, const ScriptArray& args)
{
	std::string eventName;

	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isString())  
		{
			eventName = args[0].asString();
		}
	}
	
	self->SetEventType(eventName.c_str());
	//printf("Function EventBridge::%s, setEventType,arg is %d\n", __FUNCTION__, args);

	return ScriptObject();
}

ScriptObject EventBridge::isEventType(IEvent* self, const ScriptArray& args)
{
	std::string eventName;

	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isString())  
		{
			eventName = args[0].asString();
		}
	}

	return ScriptObject(self->IsEventType(eventName.c_str()));
}

ScriptObject EventBridge::putInt(IEvent* self, const ScriptArray& args)
{
	std::string key;
	double value = 0;

	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isString()) {key = args[0].asString();}
		if(args.has(1) && args[1].isNumber()) {value = args[1].asNumber();}
	}

	return ScriptObject(self->PutInt(key.c_str(), (int)value));
}

ScriptObject EventBridge::putDouble(IEvent* self, const ScriptArray& args)
{
	std::string key;
	double value = 0;

	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isString()) {key = args[0].asString();}
		if(args.has(1) && args[1].isNumber()) {value = args[1].asNumber();}
	}

	return ScriptObject(self->PutDouble(key.c_str(), value));
}

ScriptObject EventBridge::putFloat(IEvent* self, const ScriptArray& args)
{
	std::string key;
	double value = 0;

	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isString()) {key = args[0].asString();}
		if(args.has(1) && args[1].isNumber()) {value = args[1].asNumber();}
	}

	return ScriptObject(self->PutFloat(key.c_str(), (float)value));
}

ScriptObject EventBridge::putChar(IEvent* self, const ScriptArray& args)
{
	std::string key, value;

	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isString()) {key = args[0].asString();}
		if(args.has(1) && args[1].isString()) {value = args[1].asString();}
	}

	const char *val = value.c_str();

	return ScriptObject(self->PutChar(key.c_str(), *val));
}

ScriptObject EventBridge::putString(IEvent* self, const ScriptArray& args)
{
	std::string key, value;

	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isString()) {key = args[0].asString();}
		if(args.has(1) && args[1].isString()) {value = args[1].asString();}
	}

	return ScriptObject(self->PutString(key.c_str(), value.c_str()));
}

ScriptObject EventBridge::putPointor(IEvent* self, const ScriptArray& args)
{
	std::string key;
	void *pointor = NULL;

	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isString()) {key = args[0].asString();}
		if(args.has(0) && args[0].isNumber()) {pointor= 
		(void*)(long)args[0].asNumber();}
	}

	return ScriptObject(self->PutPointor(key.c_str(), pointor));
}

ScriptObject EventBridge::getInt(IEvent* self, const ScriptArray& args)
{
	std::string key;
	int value = 0;

	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isString()) {key = args[0].asString();}
	}

	if (self->GetInt(key.c_str(), value))
	{
		return ScriptObject(value);
	}
	return ScriptObject();
}

ScriptObject EventBridge::getDouble(IEvent* self, const ScriptArray& args)
{
	std::string key;
	double value = 0.0;

	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isString()) {key = args[0].asString();}
	}

	if (self->GetDouble(key.c_str(), value))
	{
		return ScriptObject(value);
	}
	return ScriptObject();
}

ScriptObject EventBridge::getFloat(IEvent* self, const ScriptArray& args)
{
	std::string key;
	float value = 0.0f;

	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isString()) {key = args[0].asString();}
	}

	if (self->GetFloat(key.c_str(), value))
	{
		return ScriptObject(value);
	}
	return ScriptObject();
}

ScriptObject EventBridge::getChar(IEvent* self, const ScriptArray& args)
{
	std::string key;
	char value;

	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isString()) {key = args[0].asString();}
	}

	if (self->GetChar(key.c_str(), value))
	{
		return ScriptObject(value);
	}
	return ScriptObject();
}

ScriptObject EventBridge::getString(IEvent* self, const ScriptArray& args)
{
	std::string key;
	char* value = NULL;
	std::string stringValue;

	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isString()) {key = args[0].asString();}
	}
	
	if (self->GetString(key.c_str(), &value))
	{
		stringValue = value;
	}
	
	return ScriptObject(stringValue); 
}

ScriptObject EventBridge::getPointor(IEvent* self, const ScriptArray& args)
{
	std::string key;
	void* value;

	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isString()) {key = args[0].asString();} //the return value is void*.
	}

	if (self->GetPointor(key.c_str(), &value))
	{
		return ScriptObject(value);
	}
	return ScriptObject();
}

void MouseEventBridge::mapScriptInterface(ScriptContext& context)
{
	EventBridge::mapScriptInterface(context);

	context.captureMethodCall<IEvent, &getModifierType>("getModifierType");
	context.captureMethodCall<IEvent, &getX>("getX");
	context.captureMethodCall<IEvent, &getY>("getY");
	context.captureMethodCall<IEvent, &setModifierType>("setModifierType");
	context.captureMethodCall<IEvent, &setX>("setX");
	context.captureMethodCall<IEvent, &setY>("setY");
}

IEvent* MouseEventBridge::constructEvent(const ScriptArray& args)
{
	IMouseEvent *pEvent = nullptr;
	
	if (args.Length() > 0)
	{
		if (args[0].isNumber())
		{
			pEvent = (IMouseEvent*)((long)args[0].asNumber());
		}
		
	}
	else
	{
		pEvent = IMouseEvent::CreateInstance();
	}
	
	return pEvent; 
}

ScriptObject MouseEventBridge::getModifierType(IEvent* self, const ScriptArray& args)
{
	IMouseEvent *mouse = dynamic_cast<IMouseEvent*>(self);
	if (mouse)
		{return ScriptObject(mouse->GetModifierType());}
	else
		{return ScriptObject();}
}

ScriptObject MouseEventBridge::getX(IEvent* self, const ScriptArray& args)
{
	IMouseEvent *mouse = dynamic_cast<IMouseEvent*>(self);
	//printf("EventManagerBridge::sendEventLocal self,args length %f\n", mouse->GetX());
	if (mouse)
		{return ScriptObject(mouse->GetX());}
	else
		{return ScriptObject();}
}

ScriptObject MouseEventBridge::getY(IEvent* self, const ScriptArray& args)
{
	IMouseEvent *mouse = dynamic_cast<IMouseEvent*>(self);
	if (mouse)
		{return ScriptObject(mouse->GetY());}
	else
		{return ScriptObject();}
}

ScriptObject MouseEventBridge::setModifierType(IEvent* self, const ScriptArray& args)
{
	IMouseEvent *mouse = dynamic_cast<IMouseEvent*>(self);
	int type = 0;
	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) {type = args[0].asNumber();}
	}

	if (mouse)
		{mouse->SetModifierType(type);}

	return ScriptObject();
}

ScriptObject MouseEventBridge::setX(IEvent* self, const ScriptArray& args)
{
	IMouseEvent *mouse = dynamic_cast<IMouseEvent*>(self);
	float x = 0;
	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) {x = args[0].asNumber();}
	}

	if (mouse)
		{mouse->SetX(x);}

	//printf("MouseEventBridge::setX self,args length %f\n", x);

	return ScriptObject();
}

ScriptObject MouseEventBridge::setY(IEvent* self, const ScriptArray& args)
{
	IMouseEvent *mouse = dynamic_cast<IMouseEvent*>(self);
	float y = 0;
	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) {y = args[0].asNumber();}
	}

	if (mouse)
		{mouse->SetY(y);}

	return ScriptObject();
}

void KeyboardEventBridge::mapScriptInterface(ScriptContext& context)
{
	EventBridge::mapScriptInterface(context);

	context.captureMethodCall<IEvent, &getModifierType>("getModifierType");
	context.captureMethodCall<IEvent, &getKeyVal>("getKeyVal");
	context.captureMethodCall<IEvent, &getHardwareKeyCode>("getHardwareKeyCode");
	context.captureMethodCall<IEvent, &getUnicodeValue>("getUnicodeValue");
	context.captureMethodCall<IEvent, &setModifierType>("setModifierType");
	context.captureMethodCall<IEvent, &setKeyVal>("setKeyVal");
	context.captureMethodCall<IEvent, &setHardwareKeyCode>("setHardwareKeyCode");
	context.captureMethodCall<IEvent, &setUnicodeValue>("setUnicodeValue");
}

IEvent* KeyboardEventBridge::constructEvent(const ScriptArray& args)
{
	//printf("Function KeyboardEventBridge::%s, args length is %d\n", __FUNCTION__, args.Length());
	IKeyboardEvent *pEvent = nullptr;
	if (args.Length() > 0)
	{
		if (args[0].isNumber())
		{
			pEvent = (IKeyboardEvent*)((long)args[0].asNumber());
		}
	}
	else
	{
		pEvent = IKeyboardEvent::CreateInstance();
	}

	return pEvent; 
}

ScriptObject KeyboardEventBridge::getModifierType(IEvent* self, const ScriptArray& args)
{
	IKeyboardEvent *keyboardEvent = dynamic_cast<IKeyboardEvent*>(self);
	if (keyboardEvent)
		{return ScriptObject(keyboardEvent->GetModifierType());}
	else
		{return ScriptObject();}
}

ScriptObject KeyboardEventBridge::getKeyVal(IEvent* self, const ScriptArray& args)
{
	IKeyboardEvent *keyboardEvent = dynamic_cast<IKeyboardEvent*>(self);
	//printf("KeyboardEventBridge::getKeyVal self,args length %d\n", keyboardEvent->GetKeyVal());
	if (keyboardEvent)		
		{return ScriptObject(keyboardEvent->GetKeyVal());}
	else
		{return ScriptObject();}
}

ScriptObject KeyboardEventBridge::getHardwareKeyCode(IEvent* self, const ScriptArray& args)
{
	IKeyboardEvent *keyboardEvent = dynamic_cast<IKeyboardEvent*>(self);
	if (keyboardEvent)		
		{return ScriptObject(keyboardEvent->GetHardwareKeyCode());}
	else
		{return ScriptObject();}
}

ScriptObject KeyboardEventBridge::getUnicodeValue(IEvent* self, const ScriptArray& args)
{
	IKeyboardEvent *keyboardEvent = dynamic_cast<IKeyboardEvent*>(self);
	if (keyboardEvent)		
		{return ScriptObject(keyboardEvent->GetUnicodeValue());}
	else
		{return ScriptObject();}
}

ScriptObject KeyboardEventBridge::setModifierType(IEvent* self, const ScriptArray& args)
{
	IKeyboardEvent *keyboardEvent = dynamic_cast<IKeyboardEvent*>(self);
	int modifierType = 0;
	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) {modifierType = 
		args[0].asNumber();}
	}

	if (keyboardEvent)		
		{keyboardEvent->SetModifierType(modifierType);}

	return ScriptObject();
}

ScriptObject KeyboardEventBridge::setKeyVal(IEvent* self, const ScriptArray& args)
{
	IKeyboardEvent *keyboardEvent = dynamic_cast<IKeyboardEvent*>(self);
	int keyval = 0;
	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) {keyval = args[0].asNumber();}
	}

	if (keyboardEvent)		
		{keyboardEvent->SetKeyVal(keyval);}
	//printf("KeyboardEventBridge::sendEventLocal self,args length %d\n", keyval);

	return ScriptObject();
}

ScriptObject KeyboardEventBridge::setHardwareKeyCode(IEvent* self, const ScriptArray& args)
{
	IKeyboardEvent *keyboardEvent = dynamic_cast<IKeyboardEvent*>(self);
	short hardwareKeyCode = 0;
	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) {hardwareKeyCode = 
		args[0].asNumber();}
	}

	if (keyboardEvent)
		{keyboardEvent->SetHardwareKeyCode(hardwareKeyCode);}

	return ScriptObject();
}

ScriptObject KeyboardEventBridge::setUnicodeValue(IEvent* self, const ScriptArray& args)
{
	IKeyboardEvent *keyboardEvent = dynamic_cast<IKeyboardEvent*>(self);
	int unicodeValue = 0;
	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) {unicodeValue = 
		args[0].asNumber();}
	}

	if (keyboardEvent)
		{keyboardEvent->SetUnicodeValue(unicodeValue);}

	return ScriptObject();
}

void DragEventBridge::mapScriptInterface(ScriptContext& context)
{
	EventBridge::mapScriptInterface(context);

	context.captureMethodCall<IEvent, &dragSignalType>("dragSignalType");
	context.captureMethodCall<IEvent, &pressCoords>("pressCoords");
	context.captureMethodCall<IEvent, &motionCoords>("motionCoords");
	context.captureMethodCall<IEvent, &motionDelta>("motionDelta");
}


IEvent* DragEventBridge::constructEvent(const ScriptArray& args)
{
	IDragEvent *pEvent = nullptr;
	
	if (args.Length() > 0)
	{
		if (args[0].isNumber())
		{
			pEvent = (IDragEvent*)((long)args[0].asNumber());
		}
		
	}
	else
	{
		pEvent = IDragEvent::CreateInstance();
	}
	
	//printf("DragEventBridge::constructEvent self, args length %d\n", args.Length());
	return pEvent; 
}

ScriptObject DragEventBridge::dragSignalType(IEvent* self, const ScriptArray& args)
{
	IDragEvent *drag = dynamic_cast<IDragEvent*>(self);
	//printf("DragEventBridge::dragSignalType self, args length %d\n", args.Length());
	if (drag)
		{return serializeDragSignalType(drag->DragSignalType());}
	else
		{return ScriptObject();}
}

std::string DragEventBridge::serializeDragSignalType(EDragSignalType dragSignal)
{
    switch(dragSignal)
	{
	case EDragSignalType::DRAG_BEGIN: return "drag_begin";
	case EDragSignalType::DRAG_END: return "drag_end";
	case EDragSignalType::DRAG_MOTION: return "drag_motion";
	case EDragSignalType::DRAG_PROGRESS: return "drag_progress";
	default: return "drag_type_max";
	}
}

ScriptObject DragEventBridge::pressCoords(IEvent* self, const ScriptArray& args)
{
	IDragEvent *drag = dynamic_cast<IDragEvent*>(self);
	float press_x, press_y;

	if (drag)
	{
		drag->PressCoords(&press_x, &press_y);
		
		ScriptObject retval;

		retval.set("press_x", ScriptObject(press_x));
		retval.set("press_y", ScriptObject(press_y));

		return retval;
	}

	return ScriptObject();
}

ScriptObject DragEventBridge::motionCoords(IEvent* self, const ScriptArray& args)
{
	IDragEvent *drag = dynamic_cast<IDragEvent*>(self);
	float motion_x, motion_y;

	if (drag)
	{
		drag->MotionCoords(&motion_x, &motion_y);

		ScriptObject retval;

		retval.set("motion_x", ScriptObject(motion_x));
		retval.set("motion_y", ScriptObject(motion_y));

		return retval;
	}

	return ScriptObject();
}

ScriptObject DragEventBridge::motionDelta(IEvent* self, const ScriptArray& args)
{
	IDragEvent *drag = dynamic_cast<IDragEvent*>(self);
	float delta_x, delta_y;

	if (drag)
	{
		drag->MotionDelta(&delta_x, &delta_y);

		ScriptObject retval = ScriptObject();

		retval.set("delta_x", ScriptObject(delta_x));
		retval.set("delta_y", ScriptObject(delta_y));

		return retval;
	}

	return ScriptObject();
}

void GestureEventBridge::mapScriptInterface(ScriptContext& context)
{
	EventBridge::mapScriptInterface(context);

	context.captureMethodCall<IEvent, &gestureSignalType>("gestureSignalType");
	context.captureMethodCall<IEvent, &thresholdTriggerDistance>("thresholdTriggerDistance");
	context.captureMethodCall<IEvent, &touchPoints>("touchPoints");
	context.captureMethodCall<IEvent, &currentPoints>("currentPoints");
}

IEvent* GestureEventBridge::constructEvent(const ScriptArray& args)
{
	IGestureEvent *pEvent = nullptr;
	if (args.Length() > 0)
	{
		if (args[0].isNumber())
		{
			pEvent = (IGestureEvent*)((long)args[0].asNumber());
		}
	}
	else
	{
		pEvent = IGestureEvent::CreateInstance();
	}
	
	return pEvent; 
}

ScriptObject GestureEventBridge::gestureSignalType(IEvent* self, const ScriptArray& args)
{
	IGestureEvent *gesture = dynamic_cast<IGestureEvent*>(self);
	if (gesture)
		{return serializeGestureSignalType(gesture->GestureSignalType());}
	else
		{return ScriptObject();}
}

std::string GestureEventBridge::serializeGestureSignalType(EGestureSignalType gestureSignal)
{
    switch(gestureSignal)
	{
	case EGestureSignalType::GESTURE_BEGIN: return "gesture_begin";
	case EGestureSignalType::GESTURE_END: return "gesture_end";
	case EGestureSignalType::GESTURE_CANCEL: return "gesture_cancel";
	case EGestureSignalType::GESTURE_PROGRESS: return "gesture_progress";
	default: return "gesture_type_max";
	}
}

ScriptObject GestureEventBridge::thresholdTriggerDistance(IEvent* self, const ScriptArray& args)
{
	IGestureEvent *gesture = dynamic_cast<IGestureEvent*>(self);
	float x = 0.0, y = 0.0;

	if (gesture)
		{gesture->ThresholdTriggerDistance(&x, &y);}

	ScriptObject retval = ScriptObject();

	retval.set("x", ScriptObject(x));
	retval.set("y", ScriptObject(y));

	return retval;
}

ScriptObject GestureEventBridge::touchPoints(IEvent* self, const ScriptArray& args)
{
	IGestureEvent *gesture = dynamic_cast<IGestureEvent*>(self);
	//printf("GestureEventBridge::touchPoints self, args length %d\n", args.Length());
	if (gesture)		
		{return ScriptObject(gesture->TouchPoints());}
	else
		{return ScriptObject();}
}

ScriptObject GestureEventBridge::currentPoints(IEvent* self, const ScriptArray& args)
{
	IGestureEvent *gesture = dynamic_cast<IGestureEvent*>(self);
	if (gesture)	
		{return ScriptObject(gesture->CurrentPoints());}
	else
		{return ScriptObject();}
}

void SystemEventBridge::mapScriptInterface(ScriptContext& context)
{
	EventBridge::mapScriptInterface(context);
}

IEvent* SystemEventBridge::constructEvent(const ScriptArray& args)
{
	ISystemEvent *pEvent = nullptr;
	if (args.Length() > 0)
	{
		if (args[0].isNumber())
		{
			pEvent = (ISystemEvent*)((long)args[0].asNumber());
		}
	}
	else
	{
		pEvent = ISystemEvent::CreateInstance();
	}
	
	return pEvent;
}

void CustomEventBridge::mapScriptInterface(ScriptContext& context)
{
	EventBridge::mapScriptInterface(context);

	context.captureMethodCall<IEvent, &setEventType>("setEventType");
}

IEvent* CustomEventBridge::constructEvent(const ScriptArray& args)
{
	ICustomEvent *pEvent = nullptr;
	if (args.Length() > 0)
	{
		if (args[0].isNumber())
		{
			pEvent = (ICustomEvent*)((long)args[0].asNumber());
		}
	}
	else
	{
		pEvent = ICustomEvent::CreateInstance();
	}

	return pEvent;
}

ScriptObject CustomEventBridge::setEventType(IEvent* self, const ScriptArray& args)
{
	ICustomEvent *custom = dynamic_cast<ICustomEvent*>(self);
	std::string eventName;
	float eventType = 0;

	if (args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) {eventType = args[0].asNumber();}
		else if (args[0].isString()){ eventName = args[0].asString();}
	}

	//printf("CustomEventBridge::setEventType self, args length %f\n", eventType);

	if (custom)
	{
		if (eventType != 0)
		{
			custom->SetEventType(eventType);			
		}
		else
		{
			custom->SetEventType(eventName.c_str());
		}
	}
	
	return ScriptObject();
}

void RemoconEventBridge::mapScriptInterface(ScriptContext& context)
{
	EventBridge::mapScriptInterface(context);
}

IEvent* RemoconEventBridge::constructEvent(const ScriptArray& args)
{
	IRemoconEvent *pEvent = nullptr;
	if (args.Length() > 0)
	{
		if (args[0].isNumber())
		{
			pEvent = (IRemoconEvent*)((long)args[0].asNumber());
		}
	}
	else
	{
		pEvent = IRemoconEvent::CreateInstance();
	}

	return pEvent;
}

void MotionEventBridge::mapScriptInterface(ScriptContext& context)
{
	EventBridge::mapScriptInterface(context);
}

IEvent* MotionEventBridge::constructEvent(const ScriptArray& args)
{
	IMotionEvent *pEvent = nullptr;
	if (args.Length() > 0)
	{
		if (args[0].isNumber())
		{
			pEvent = (IMotionEvent*)((long)args[0].asNumber());
		}
	}
	else
	{
		pEvent = IMotionEvent::CreateInstance();
	}

	return pEvent;
}

void TouchEventBridge::mapScriptInterface(ScriptContext& context)
{
	EventBridge::mapScriptInterface(context);
}

IEvent* TouchEventBridge::constructEvent(const ScriptArray& args)
{
	ITouchEvent *pEvent = nullptr;
	if (args.Length() > 0)
	{
		if (args[0].isNumber())
		{
			pEvent = (ITouchEvent*)((long)args[0].asNumber());
		}
	}
	else
	{
		pEvent = ITouchEvent::CreateInstance();
	}

	return pEvent;
}

void RidgeEventBridge::mapScriptInterface(ScriptContext& context)
{
	EventBridge::mapScriptInterface(context);
}

IEvent* RidgeEventBridge::constructEvent(const ScriptArray& args)
{
	IRidgeEvent *pEvent = nullptr;
	if (args.Length() > 0)
	{
		if (args[0].isNumber())
		{
			pEvent = (IRidgeEvent*)((long)args[0].asNumber());
		}
	}
	else
	{
		pEvent = IRidgeEvent::CreateInstance();
	}

	return pEvent;
}

void CursorEventBridge::mapScriptInterface(ScriptContext& context)
{
	EventBridge::mapScriptInterface(context);
}

IEvent* CursorEventBridge::constructEvent(const ScriptArray& args)
{
	ICursorEvent *pEvent = nullptr;
	if (args.Length() > 0)
	{
		if (args[0].isNumber())
		{
			pEvent = (ICursorEvent*)((long)args[0].asNumber());
		}
	}
	else
	{
		pEvent = ICursorEvent::CreateInstance();
	}

	return pEvent;
}

void SensorEventBridge::mapScriptInterface(ScriptContext& context)
{
	EventBridge::mapScriptInterface(context);
}

IEvent* SensorEventBridge::constructEvent(const ScriptArray& args)
{
	ISensorEvent *pEvent = nullptr;
	if (args.Length() > 0)
	{
		if (args[0].isNumber())
		{
			pEvent = (ISensorEvent*)((long)args[0].asNumber());
		}
	}
	else
	{
		pEvent = ISensorEvent::CreateInstance();
	}

	return pEvent;
}

void ClickEventBridge::mapScriptInterface(ScriptContext& context)
{
	EventBridge::mapScriptInterface(context);
}

IEvent* ClickEventBridge::constructEvent(const ScriptArray& args)
{
	IClickEvent *pEvent = nullptr;
	if (args.Length() > 0)
	{
		if (args[0].isNumber())
		{
			pEvent = (IClickEvent*)((long)args[0].asNumber());
		}
	}
	else
	{
		pEvent = IClickEvent::CreateInstance();
	}

	return pEvent;
}

void LongPressEventBridge::mapScriptInterface(ScriptContext& context)
{
	EventBridge::mapScriptInterface(context);
}

IEvent* LongPressEventBridge::constructEvent(const ScriptArray& args)
{
	ILongPressEvent *pEvent = nullptr;
	if (args.Length() > 0)
	{
		if (args[0].isNumber())
		{
			pEvent = (ILongPressEvent*)((long)args[0].asNumber());
		}
	}
	else
	{
		pEvent = ILongPressEvent::CreateInstance();
	}

	return pEvent;
}

void FocusEventBridge::mapScriptInterface(ScriptContext& context)
{
	EventBridge::mapScriptInterface(context);
}

IEvent* FocusEventBridge::constructEvent(const ScriptArray& args)
{
	IFocusEvent *pEvent = nullptr;
	if (args.Length() > 0)
	{
		if (args[0].isNumber())
		{
			pEvent = (IFocusEvent*)((long)args[0].asNumber());
		}
	}
	else
	{
		pEvent = IFocusEvent::CreateInstance();
	}

	return pEvent;
}
