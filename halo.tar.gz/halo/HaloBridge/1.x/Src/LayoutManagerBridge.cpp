#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void LayoutManagerBridge::mapScriptInterface(ScriptContext& context)
{
	context.captureMethodCall<ILayout, &SetActorXAlign>("setActorXAlign");
	context.captureMethodCall<ILayout, &ActorXAlign>("getActorXAlign");
	context.captureMethodCall<ILayout, &SetActorYAlign>("setActorYAlign");
	context.captureMethodCall<ILayout, &ActorYAlign>("getActorYAlign");
	context.captureMethodCall<ILayout, &CopyMargin>("copyMargin");
	context.captureMethodCall<ILayout, &SetMargin>("setMargin");
	context.captureMethodCall<ILayout, &GetMargin>("getMargin");
	context.captureMethodCall<ILayout, &SetMarginTop>("setMarginTop");
	context.captureMethodCall<ILayout, &MarginTop>("getMarginTop");
	context.captureMethodCall<ILayout, &SetMarginRight>("setMarginRight");
	context.captureMethodCall<ILayout, &MarginRight>("getMarginRight");
	context.captureMethodCall<ILayout, &SetMarginBottom>("setMarginBottom");
	context.captureMethodCall<ILayout, &MarginBottom>("getMarginBottom");
	context.captureMethodCall<ILayout, &SetMarginLeft>("setMarginLeft");
	context.captureMethodCall<ILayout, &MarginLeft>("getMarginLeft");
	context.captureMethodCall<ILayout, &SetXExpandFlag>("setXExpandFlag");
	context.captureMethodCall<ILayout, &FlagXExpand>("getXExpandFlag");
	context.captureMethodCall<ILayout, &SetYExpandFlag>("setYExpandFlag");
	context.captureMethodCall<ILayout, &FlagYExpand>("getYExpandFlag");
}


void* LayoutManagerBridge::constructFromScript(const ScriptArray& args)
{
	ILayout *layout = constructWidget(args);
	return layout;
}

ScriptObject LayoutManagerBridge::SetActorXAlign(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 1 && args[1].isString())
	{
		/*CLUTTER_ACTOR_ALIGN_FILL,
		  CLUTTER_ACTOR_ALIGN_START,
		  CLUTTER_ACTOR_ALIGN_CENTER,
		  CLUTTER_ACTOR_ALIGN_END*/
		CActor* mActor = unwrapNativeObject<CActor>(args[0]);
		if (mActor != NULL)
		{
			std::string align;
			align = args[1].asString();
			if (align.compare("FILL") == 0) { self->SetActorXAlign(mActor, CLUTTER_ACTOR_ALIGN_FILL); }
			if (align.compare("START") == 0) { self->SetActorXAlign(mActor, CLUTTER_ACTOR_ALIGN_START); }
			if (align.compare("CENTER") == 0) { self->SetActorXAlign(mActor, CLUTTER_ACTOR_ALIGN_CENTER); }
			if (align.compare("END") == 0) { self->SetActorXAlign(mActor, CLUTTER_ACTOR_ALIGN_END); }
		}
	}
	return ScriptObject();
}

ScriptObject LayoutManagerBridge::ActorXAlign(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		/*CLUTTER_ACTOR_ALIGN_FILL,
		CLUTTER_ACTOR_ALIGN_START,
		CLUTTER_ACTOR_ALIGN_CENTER,
		CLUTTER_ACTOR_ALIGN_END*/
		CActor* mActor = unwrapNativeObject<CActor>(args[0]);
		if (mActor != NULL)
		{
			std::string align;
			if (self->ActorXAlign(mActor) == CLUTTER_ACTOR_ALIGN_FILL) { align = "FILL"; }
			if (self->ActorXAlign(mActor) == CLUTTER_ACTOR_ALIGN_START) { align = "START"; }
			if (self->ActorXAlign(mActor) == CLUTTER_ACTOR_ALIGN_CENTER) { align = "CENTER"; }
			if (self->ActorXAlign(mActor) == CLUTTER_ACTOR_ALIGN_END) { align = "END"; }
			return ScriptObject(align);
		}
	}
	return ScriptObject();
}

ScriptObject LayoutManagerBridge::SetActorYAlign(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 1 && args[1].isString())
	{
		/*CLUTTER_ACTOR_ALIGN_FILL,
		CLUTTER_ACTOR_ALIGN_START,
		CLUTTER_ACTOR_ALIGN_CENTER,
		CLUTTER_ACTOR_ALIGN_END*/
		CActor* mActor = unwrapNativeObject<CActor>(args[0]);
		if (mActor != NULL)
		{
			std::string align;
			align = args[1].asString();
			if (align.compare("FILL") == 0) { self->SetActorYAlign(mActor, CLUTTER_ACTOR_ALIGN_FILL); }
			if (align.compare("START") == 0) { self->SetActorYAlign(mActor, CLUTTER_ACTOR_ALIGN_START); }
			if (align.compare("CENTER") == 0) { self->SetActorYAlign(mActor, CLUTTER_ACTOR_ALIGN_CENTER); }
			if (align.compare("END") == 0) { self->SetActorYAlign(mActor, CLUTTER_ACTOR_ALIGN_END); }
		}
	}
	return ScriptObject();
}

ScriptObject LayoutManagerBridge::ActorYAlign(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		/*CLUTTER_ACTOR_ALIGN_FILL,
		CLUTTER_ACTOR_ALIGN_START,
		CLUTTER_ACTOR_ALIGN_CENTER,
		CLUTTER_ACTOR_ALIGN_END*/
		CActor* mActor = unwrapNativeObject<CActor>(args[0]);
		if (mActor != NULL)
		{
			std::string align;
			if (self->ActorYAlign(mActor) == CLUTTER_ACTOR_ALIGN_FILL) { align = "FILL"; }
			if (self->ActorYAlign(mActor) == CLUTTER_ACTOR_ALIGN_START) { align = "START"; }
			if (self->ActorYAlign(mActor) == CLUTTER_ACTOR_ALIGN_CENTER) { align = "CENTER"; }
			if (self->ActorYAlign(mActor) == CLUTTER_ACTOR_ALIGN_END) { align = "END"; }
			return ScriptObject(align);
		}
	}
	return ScriptObject();
}

ScriptObject LayoutManagerBridge::CopyMargin(ILayout* self, const ScriptArray& args)
{	
	if (args.Length() > 0)
	{
		ClutterMargin* mMargin = unwrapNativeObject<ClutterMargin>(args[0]);
		if (mMargin != NULL)
		{
			self->CopyMargin(mMargin);
		}
	}
	return ScriptObject();
}

ScriptObject LayoutManagerBridge::SetMargin(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		CActor* mActor = unwrapNativeObject<CActor>(args[0]);
		ClutterMargin* mMargin = unwrapNativeObject<ClutterMargin>(args[1]);
		if (mActor != NULL && mMargin != NULL)
		{
			self->SetMargin(mActor, mMargin);
		}
	}
	return ScriptObject();
}

ScriptObject LayoutManagerBridge::GetMargin(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		CActor* mActor = unwrapNativeObject<CActor>(args[0]);
		ClutterMargin* mMargin = unwrapNativeObject<ClutterMargin>(args[1]);
		if (mActor != NULL && mMargin != NULL)
		{
			self->GetMargin(mActor, mMargin);
		}
	}
	return ScriptObject();
}

ScriptObject LayoutManagerBridge::SetMarginTop(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 1 && args[1].isNumber())
	{
		CActor* mActor = unwrapNativeObject<CActor>(args[0]);
		if (mActor != NULL)
		{
			float marginValue = args[1].asNumber();
			self->SetMarginTop(mActor, marginValue);
		}
	}
	return ScriptObject();
}

ScriptObject LayoutManagerBridge::MarginTop(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		CActor* mActor = unwrapNativeObject<CActor>(args[0]);
		if (mActor != NULL)
		{
			float marginValue = self->MarginTop(mActor);
			return ScriptObject(marginValue);
		}
	}
	return ScriptObject();
}

ScriptObject LayoutManagerBridge::SetMarginRight(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 1 && args[1].isNumber())
	{
		CActor* mActor = unwrapNativeObject<CActor>(args[0]);
		if (mActor != NULL)
		{
			float marginValue = args[1].asNumber();
			self->SetMarginRight(mActor, marginValue);
		}
	}
	return ScriptObject();
}

ScriptObject LayoutManagerBridge::MarginRight(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		CActor* mActor = unwrapNativeObject<CActor>(args[0]);
		if (mActor != NULL)
		{
			float marginValue = self->MarginRight(mActor);
			return ScriptObject(marginValue);
		}
	}
	return ScriptObject();
}

ScriptObject LayoutManagerBridge::SetMarginBottom(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 1 && args[1].isNumber())
	{
		CActor* mActor = unwrapNativeObject<CActor>(args[0]);
		if (mActor != NULL)
		{
			float marginValue = args[1].asNumber();
			self->SetMarginBottom(mActor, marginValue);
		}
	}
	return ScriptObject();
}

ScriptObject LayoutManagerBridge::MarginBottom(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		CActor* mActor = unwrapNativeObject<CActor>(args[0]);
		if (mActor != NULL)
		{
			float marginValue = self->MarginBottom(mActor);
			return ScriptObject(marginValue);
		}
	}
	return ScriptObject();
}

ScriptObject LayoutManagerBridge::SetMarginLeft(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 1 && args[1].isNumber())
	{
		CActor* mActor = unwrapNativeObject<CActor>(args[0]);
		if (mActor != NULL)
		{
			float marginValue = args[1].asNumber();
			self->SetMarginLeft(mActor, marginValue);
		}
	}
	return ScriptObject();
}

ScriptObject LayoutManagerBridge::MarginLeft(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		CActor* mActor = unwrapNativeObject<CActor>(args[0]);
		if (mActor != NULL)
		{
			float marginValue = self->MarginLeft(mActor);
			return ScriptObject(marginValue);
		}
	}
	return ScriptObject();
}

ScriptObject LayoutManagerBridge::SetXExpandFlag(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 1 && args[1].isBool())
	{
		CActor* mActor = unwrapNativeObject<CActor>(args[0]);
		if (mActor != NULL)
		{
			bool flag = args[1].asBool();
			self->SetXExpandFlag(mActor, flag);
		}
	}
	return ScriptObject();
}

ScriptObject LayoutManagerBridge::FlagXExpand(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		CActor* mActor = unwrapNativeObject<CActor>(args[0]);
		if (mActor != NULL)
		{
			bool flag = self->FlagXExpand(mActor);
			return ScriptObject(flag);
		}
	}
	return ScriptObject();
}

ScriptObject LayoutManagerBridge::SetYExpandFlag(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 1 && args[1].isBool())
	{
		CActor* mActor = unwrapNativeObject<CActor>(args[0]);
		if (mActor != NULL)
		{
			bool flag = args[1].asBool();
			self->SetYExpandFlag(mActor, flag);
		}
	}
	return ScriptObject();
}

ScriptObject LayoutManagerBridge::FlagYExpand(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		CActor* mActor = unwrapNativeObject<CActor>(args[0]);
		if (mActor != NULL)
		{
			bool flag = self->FlagYExpand(mActor);
			return ScriptObject(flag);
		}
	}
	return ScriptObject();
}
