#include "HaloBridgeAll.h"
#include "HaloBridge.h"
#include "ScriptEngine.h"

extern ClutterActor* GetMainStage();
extern void RegisterPluginBridge(Bridge::ScriptBridge*);

void RegisterVoltBridges()
{
	//Single instance
	HALO::IEventManager *eventManger = HALO::IEventManager::GetInstance();
	HALO::IDeviceManager *devieManger = HALO::IDeviceManager::GetInstance();
	HALO::IUtility *utility = HALO::IUtility::GetInstance();
	//HALO::IStage *stage = HALO::IStage::GetInstance();

	RegisterPluginBridge(new Bridge::UtilityBridge());
	RegisterPluginBridge(new Bridge::TransitionBridge());
	//RegisterPluginBridge(new Bridge::StageBridge(stage));
	RegisterPluginBridge(new Bridge::DimWindowBridge());
	RegisterPluginBridge(new Bridge::ActorBridge());
	RegisterPluginBridge(new Bridge::ThumbnailBridge());
	RegisterPluginBridge(new Bridge::ThumbnailListenerBridge());
	RegisterPluginBridge(new Bridge::ButtonListenerBridge());
	RegisterPluginBridge(new Bridge::ButtonBridge());
	RegisterPluginBridge(new Bridge::ActorListenerBridge());
	RegisterPluginBridge(new Bridge::SingleLineListListenerBridge());
	RegisterPluginBridge(new Bridge::SingleLineListBridge());
	RegisterPluginBridge(new Bridge::GridLayoutListListenerBridge());
	RegisterPluginBridge(new Bridge::GridLayoutListBridge());
	RegisterPluginBridge(new Bridge::FirstScreenControlBridge());
	RegisterPluginBridge(new Bridge::RendererProviderBridge());
	RegisterPluginBridge(new Bridge::DataBridge());
	RegisterPluginBridge(new Bridge::RendererBridge());
	RegisterPluginBridge(new Bridge::TextBridge());
	RegisterPluginBridge(new Bridge::RichTextBridge());
	RegisterPluginBridge(new Bridge::ImageBufferBridge());
	RegisterPluginBridge(new Bridge::HaloImageBridge());
	RegisterPluginBridge(new Bridge::CompositeImageBridge());
	RegisterPluginBridge(new Bridge::RectangleBridge());
	RegisterPluginBridge(new Bridge::LabelBridge());
	RegisterPluginBridge(new Bridge::PageControlBridge());
	RegisterPluginBridge(new Bridge::ProgressBridge());
	RegisterPluginBridge(new Bridge::ProgressListenerBridge());
	RegisterPluginBridge(new Bridge::SliderBridge());
	RegisterPluginBridge(new Bridge::ScrollBridge());
	RegisterPluginBridge(new Bridge::ScrollListenerBridge());
	RegisterPluginBridge(new Bridge::FixedLayoutBridge());
	RegisterPluginBridge(new Bridge::BinLayoutBridge());
	RegisterPluginBridge(new Bridge::BoxLayoutBridge());
	RegisterPluginBridge(new Bridge::FlowLayoutBridge());
	RegisterPluginBridge(new Bridge::GridLayoutBridge());
	RegisterPluginBridge(new Bridge::ThreadPoolBridge());
	RegisterPluginBridge(new Bridge::AsyncTaskBridge());
	RegisterPluginBridge(new Bridge::TaskListenerBridge());
	RegisterPluginBridge(new Bridge::DeviceBridge());
	RegisterPluginBridge(new Bridge::MouseDeviceBridge());
	RegisterPluginBridge(new Bridge::KeyboardDeviceBridge());
	RegisterPluginBridge(new Bridge::DeviceManagerBridge(devieManger));
	RegisterPluginBridge(new Bridge::EventBridge());
	RegisterPluginBridge(new Bridge::EventManagerBridge(eventManger));
	RegisterPluginBridge(new Bridge::FocusListenerBridge());
	RegisterPluginBridge(new Bridge::MouseListenerBridge());
	RegisterPluginBridge(new Bridge::TouchListenerBridge());
	RegisterPluginBridge(new Bridge::KeyboardListenerBridge());
	RegisterPluginBridge(new Bridge::MotionListenerBridge());
	RegisterPluginBridge(new Bridge::RemoteControlListenerBridge());
	RegisterPluginBridge(new Bridge::RidgeListenerBridge());
	RegisterPluginBridge(new Bridge::CursorListenerBridge());
	RegisterPluginBridge(new Bridge::SensorListenerBridge());
	RegisterPluginBridge(new Bridge::ClickListenerBridge());
	RegisterPluginBridge(new Bridge::SemanticEventListenerBridge());
	RegisterPluginBridge(new Bridge::SystemEventListenerBridge());
	RegisterPluginBridge(new Bridge::CustomEventListenerBridge());
	RegisterPluginBridge(new Bridge::DragListenerBridge());
	RegisterPluginBridge(new Bridge::GestureListenerBridge());
	RegisterPluginBridge(new Bridge::KeyLongPressListenerBridge());
	RegisterPluginBridge(new Bridge::KeyCombinationListenerBridge());
	RegisterPluginBridge(new Bridge::ClickActionBridge());
	RegisterPluginBridge(new Bridge::DragActionBridge());
	RegisterPluginBridge(new Bridge::GestureActionBridge());
	RegisterPluginBridge(new Bridge::KeyLongPressActionBridge());
	RegisterPluginBridge(new Bridge::KeyCombinationActionBridge());

	RegisterPluginBridge(new Bridge::MouseEventBridge());
	RegisterPluginBridge(new Bridge::KeyboardEventBridge());
	RegisterPluginBridge(new Bridge::DragEventBridge());
	RegisterPluginBridge(new Bridge::GestureEventBridge());
	RegisterPluginBridge(new Bridge::SystemEventBridge());
	RegisterPluginBridge(new Bridge::CustomEventBridge());
	RegisterPluginBridge(new Bridge::RemoconEventBridge());
	RegisterPluginBridge(new Bridge::MotionEventBridge());
	RegisterPluginBridge(new Bridge::TouchEventBridge());
	RegisterPluginBridge(new Bridge::RidgeEventBridge());
	RegisterPluginBridge(new Bridge::CursorEventBridge());
	RegisterPluginBridge(new Bridge::SensorEventBridge());
	RegisterPluginBridge(new Bridge::ClickEventBridge());
	RegisterPluginBridge(new Bridge::LongPressEventBridge());
	RegisterPluginBridge(new Bridge::FocusEventBridge());
	RegisterPluginBridge(new Bridge::ToggleButtonBridge());
	RegisterPluginBridge(new Bridge::CheckBoxGroupBridge());
	RegisterPluginBridge(new Bridge::CheckBoxGroupListenerBridge());
	RegisterPluginBridge(new Bridge::RadioButtonGroupBridge());
	RegisterPluginBridge(new Bridge::LoadingBridge());
	RegisterPluginBridge(new Bridge::MessageBoxBridge());
	RegisterPluginBridge(new Bridge::MessageBoxListenerBridge());
	RegisterPluginBridge(new Bridge::CategoryTabListenerBridge());
	RegisterPluginBridge(new Bridge::CategoryTabBridge());
	RegisterPluginBridge(new Bridge::RadioButtonGroupListenerBridge());
	RegisterPluginBridge(new Bridge::SelectButtonBridge());
	RegisterPluginBridge(new Bridge::HaloUtilBridge(utility));
	RegisterPluginBridge(new Bridge::ToolTipBridge());
	RegisterPluginBridge(new Bridge::PopupRatingBridge());
	RegisterPluginBridge(new Bridge::PopupRatingListenerBridge());
	RegisterPluginBridge(new Bridge::PinPopupBridge());
	RegisterPluginBridge(new Bridge::PinPopupListenerBridge());

	RegisterPluginBridge(new Bridge::InputBoxBridge());
#ifndef WIN32
	RegisterPluginBridge(new Bridge::VideoActorBridge());
	RegisterPluginBridge(new Bridge::TTSEngineBridge());
#endif
}

void RunHalo()
{
	HALO::Initialize();
	HALO::IStage* haloStage = HALO::IStage::GetInstance();

	ClutterActor* stage = GetMainStage();
	haloStage->UseExternalStage(stage);

	RegisterVoltBridges();
}

void ExitHalo()
{
	HALO::Finalize();
}

void HALO_PreInitialize(void)
{
	HALO::PreInitialize();

	RegisterVoltBridges();
}

void HALO_Initialize(void)
{
	HALO::Initialize();
	HALO::IStage* haloStage = HALO::IStage::GetInstance();

	ClutterActor* stage = GetMainStage();
	haloStage->UseExternalStage(stage);
}

void HALO_Finalize(void)
{
	HALO::Finalize();
}
