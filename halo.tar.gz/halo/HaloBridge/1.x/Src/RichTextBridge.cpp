#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void RichTextBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.captureMethodCall<CRichText, &enableMultline>("enableMultiline");
	context.captureMethodCall<CRichText, &setTextColor>("setTextColor");
	context.captureMethodCall<CRichText, &setBackgroundColor>("setBackgroundColor");
	context.captureMethodCall<CRichText, &setCursorColor>("setCursorColor");
	context.captureMethodCall<CRichText, &setSelectionColor>("setSelectionColor");
	context.captureMethodCall<CRichText, &setHighLightColor>("setHighlightColor");
	context.captureMethodCall<CRichText, &setText>("setText");
	context.captureMethodCall<CRichText, &text>("text");
	context.captureMethodCall<CRichText, &setFont>("setFont");
	context.captureMethodCall<CRichText, &setFontSize>("setFontSize");
	context.captureMethodCall<CRichText, &insertText>("inserttext");
	context.captureMethodCall<CRichText, &deleteText>("deletetext");
	context.captureMethodCall<CRichText, &enableHighLightMove>("enableHighlightMove");
	context.captureMethodCall<CRichText, &moveHighLight>("moveHighlight");
	context.captureMethodCall<CRichText, &moveCursor>("moveCursor");
	context.captureMethodCall<CRichText, &copy>("copy");
	context.captureMethodCall<CRichText, &cut>("cut");
	context.captureMethodCall<CRichText, &paste>("paste");
	context.captureMethodCall<CRichText, &setCharFormat>("setCharFormat");
	context.captureMethodCall<CRichText, &setParagraphFormat>("setParagraphFormat");
	context.captureMethodCall<CRichText, &setCursorBlinkInterval>("setCursorBlinkInterval");
	context.captureMethodCall<CRichText, &setSelection>("setSelection");
	context.captureMethodCall<CRichText, &enableEditable>("enableEditable");
	context.captureMethodCall<CRichText, &enableSelectable>("enableSelectable");
#ifdef HAVE_ECORE_IMF
	context.captureMethodCall<CRichText, &GetIMEData>("GetIMEData");
	context.captureMethodCall<CRichText, &SetIMEData>("SetIMEData");
	context.captureMethodCall<CRichText, &EnableIMFOnFocus>("EnableIMFOnFocus");
	context.captureMethodCall<CRichText, &ShowIMFContext>("ShowIMFContext");
	context.captureMethodCall<CRichText, &HideIMFContext>("HideIMFContext");
	context.captureMethodCall<CRichText, &FocusInIMFContext>("FocusInIMFContext");
	context.captureMethodCall<CRichText, &FocusOutIMFContext>("FocusOutIMFContext");
#endif
}

IActor* RichTextBridge::constructWidget(IActor* parent, float width, float height, const ScriptObject& argObject)
{
	std::string text, font;
	ScriptArray arg;

	if (width == -1)
	{
		width = 0;
	}
	if (height == -1)
	{
		height = 0;
	}

	IText* iText;	
	iText = IText::CreateInstance(parent, width, height);

	/*if(argObject.has("font")) 
	{
		font = argObject.get("font").asString();
		iText->SetFont(font.c_str());
	}

	if(argObject.has("text")) 
	{
		text = argObject.get("text").asString();
		iText->SetText(text.c_str());
	}*/

	return iText;
}

Widget* RichTextBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	ScriptObject argObject = args[0];

	std::string text, font;
	ScriptArray arg;

	if (width == -1)
	{
		width = 0;
	}
	if (height == -1)
	{
		height = 0;
	}

	CRichText *cRichText = dynamic_cast<CRichText*>(IRichText::CreateInstance(parent, width, height));
	return cRichText;
}

ScriptObject RichTextBridge::setText(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	std::string text;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString())
		{
			text = args[0].asString();
		}
	}
	if (iRichText != NULL)
	{
		iRichText->SetText(text.c_str());
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::text(CRichText* self, const ScriptArray& args)
{
	std::string buf = self->Text();
	return ScriptObject(buf);
}

ScriptObject RichTextBridge::setTextColor(CRichText* self, const ScriptArray& args)
{ 
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			r = (guint8)args[0].asNumber();
		}
		if (args.has(1) && args[1].isNumber())
		{
			g = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber()) 
		{
			b = (guint8)args[2].asNumber(); 
		}
		if (args.has(3) && args[3].isNumber())
		{
			a = (guint8)args[3].asNumber();
		}
	}
	ClutterColor c = { r, g, b, a};
	if (iRichText != NULL)
	{
		iRichText->SetTextColor(c);
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::setBackgroundColor(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			r = (guint8)args[0].asNumber();
		}
		if (args.has(1) && args[1].isNumber())
		{
			g = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			b = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			a = (guint8)args[3].asNumber();
		}
	}
	ClutterColor c = { r, g, b, a };
	if (iRichText != NULL)
	{
		iRichText->SetBackgroundColor(c);
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::setCursorColor(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			r = (guint8)args[0].asNumber();
		}
		if (args.has(1) && args[1].isNumber())
		{
			g = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			b = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			a = (guint8)args[3].asNumber();
		}
	}
	ClutterColor c = { r, g, b, a };
	if (iRichText != NULL)
	{
		iRichText->SetCursorColor(c);
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::setSelectionColor(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) 
		{
			r = (guint8)args[0].asNumber(); 
		}
		if (args.has(1) && args[1].isNumber())
		{
			g = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			b = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			a = (guint8)args[3].asNumber();
		}
	}
	ClutterColor c = { r, g, b, a };
	if (iRichText != NULL)
	{
		iRichText->SetSelectionColor(c);
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::setHighLightColor(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			r = (guint8)args[0].asNumber();
		}
		if (args.has(1) && args[1].isNumber())
		{
			g = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			b = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			a = (guint8)args[3].asNumber();
		}
	}
	ClutterColor c = { r, g, b, a };
	if (iRichText != NULL)
	{
		iRichText->SetHighlightMoveBgColor(c);
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::enableMultline(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	bool flag = false;
	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isBool())
		{
			flag = args[0].asBool();
		}
	}
	if (iRichText != NULL)
	{
		iRichText->EnableMultiLine(flag);
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::setFont(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	std::string font;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString())
		{
			font = args[0].asString();
		}
	}
	if (iRichText != NULL)
	{
		iRichText->SetFont(font.c_str());
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::setFontSize(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	int size = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			size = (int)args[0].asNumber();
		}
	}
	if (iRichText != NULL)
	{
		iRichText->SetFontSize(size);
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::insertText(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	std::string text;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString())
		{
			text = args[0].asString();
		}
	}
	if (iRichText != NULL)
	{
		iRichText->InsertText((char*)text.c_str());
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::deleteText(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	if (iRichText != NULL)
	{
		iRichText->DeleteText();
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::enableHighLightMove(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	bool flag = false;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isBool())
		{
			flag = args[0].asBool();
		}
	}
	if (iRichText != NULL)
	{
		iRichText->EnableHighlightMove(flag);
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::moveHighLight(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	int dir = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			dir = (guint8)args[0].asNumber();
		}
	}

	if (iRichText != NULL)
	{
		iRichText->MoveHighlight((EDirection)dir);
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::moveCursor(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	int dir = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			dir = (guint8)args[0].asNumber();
		}
	}

	if (iRichText != NULL)
	{
		iRichText->MoveCursor((EDirection)dir);
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::copy(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	if (iRichText != NULL)
	{
		iRichText->Copy();
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::cut(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	if (iRichText != NULL)
	{
		iRichText->Cut();
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::paste(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	if (iRichText != NULL)
	{
		iRichText->Paste();
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::setCharFormat(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	int style = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			style = (int)args[0].asNumber();
		}
	}
	
	if (iRichText != NULL)
	{
		IRichText::ITCharFormat cf;
		if (style == IRichText::STYLE_ITALIC)
		{
			cf.style |= IRichText::STYLE_ITALIC;
		}
		else if (style == IRichText::STYLE_BOLD)
		{
			cf.style |= IRichText::STYLE_BOLD;
		}
		else if (style == IRichText::STYLE_UNDERLINE)
		{
			cf.style |= IRichText::STYLE_UNDERLINE;
		}
		iRichText->SetCharFormat(cf);
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::setParagraphFormat(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	int alignment = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			alignment = (int)args[0].asNumber();
		}
	}

	if (iRichText != NULL)
	{
		IRichText::ITParaFormat pf;
		pf.alignment = (EHAlignment)alignment;
		iRichText->SetParagraphFormat(pf);
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::setCursorBlinkInterval(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	int interval = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			interval = (int)args[0].asNumber();
		}
	}

	if (iRichText != NULL)
	{
		iRichText->SetCursorBlinkInterval(interval);
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::setSelection(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	int start = 0;
	int end = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			start = (int)args[0].asNumber();
		}
		if (args.has(1) && args[1].isNumber())
		{
			end = (int)args[1].asNumber();
		}
	}

	if (iRichText != NULL)
	{
		iRichText->SetSelection(start, end);
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::enableEditable(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	bool flag = false;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isBool())
		{
			flag = args[0].asBool();
		}
	}

	if (iRichText != NULL)
	{
		iRichText->EnableEditable(flag);
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::enableSelectable(CRichText* self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText*>(self);
	bool flag = false;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isBool())
		{
			flag = args[0].asBool();
		}
	}

	if (iRichText != NULL)
	{
		iRichText->EnableSelectable(flag);
	}
	return ScriptObject();
}

#ifdef HAVE_ECORE_IMF
ScriptObject RichTextBridge::GetIMEData(CRichText *self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText *>(self);
	void *pointor = NULL;
	void *len = NULL;
	if (args.Length() > 0)
	{
		if (args.has(0) & args[0].isNumber())
		{
			pointor = (void *)(long)args[0].asNumber();
		}
		if (args.has(1) & args[1].isNumber()) 
		{
			len = (void *)(long)args[1].asNumber();
		}
	}
	if (iRichText != NULL)
	{
		iRichText->GetIMEData(pointor, len);
	}
	return ScriptObject();
}

ScriptObject RichTextBridge::SetIMEData(CRichText *self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText *>(self);
	
	std::string imdata;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString()) 
		{
			imdata = args[0].asString();
		}
	}
	if (iRichText != NULL)
	{
		iRichText->SetIMEData((char*)imdata.c_str());
	}
	return ScriptObject();	
}

ScriptObject RichTextBridge::EnableIMFOnFocus(CRichText *self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText *>(self);

	bool flag = false;
	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isBool()) 
		{
			flag = args[0].asBool();
		}
	}
	if (iRichText != NULL)
	{
		iRichText->EnableIMFOnFocus(flag);
	}
	return ScriptObject();	
}

ScriptObject RichTextBridge::ShowIMFContext(CRichText *self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText *>(self);
	if (iRichText != NULL)
	{
		iRichText->ShowIMFContext();
	}
	return ScriptObject();	
}


ScriptObject RichTextBridge::HideIMFContext(CRichText *self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText *>(self);
	if (iRichText != NULL)
	{
		iRichText->HideIMFContext();
	}
	return ScriptObject();	
}

ScriptObject RichTextBridge::FocusInIMFContext(CRichText *self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText *>(self);
	if (iRichText != NULL)
	{
		iRichText->FocusInIMFContext();
	}
	return ScriptObject();	
}


ScriptObject RichTextBridge::FocusOutIMFContext(CRichText *self, const ScriptArray& args)
{
	IRichText *iRichText = dynamic_cast<IRichText *>(self);
	if (iRichText != NULL)
	{
		iRichText->FocusOutIMFContext();
	}
	return ScriptObject();	
}
#endif
