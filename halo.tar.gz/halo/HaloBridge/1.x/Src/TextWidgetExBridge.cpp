#include "HaloBridgeAll.h"

using namespace HALO;

//void ActorListenerBridge::mapScriptInterface(ScriptContext& context)
//{
//	context.bindFunction<InternalActorListener, &InternalActorListener::GetFirstFocusInCallBack, &InternalActorListener::SetFirstFocusInCallBack>("onFirstShown");
//}
//
//void* ActorListenerBridge::constructFromScript(const ScriptArray& args)
//{
//	return new InternalActorListener;
//}
//
//void ActorListenerBridge::destroyFromScript(void* pointerToDestroyedObject)
//{
//	InternalActorListener *listener = (InternalActorListener*)(pointerToDestroyedObject);
//	delete listener;
//}
//
//bool InternalActorListener::OnFirstFocusIn(class IActor* actor)
//{
//	if (true == FirstFocusInCb.flagExist)
//	{
//		ScriptArray args;
//		args.set(0, TextWidgetExBridge::wrapNativeObjectToJS(dynamic_cast<CTextWidgetEx*>(actor)));
//		FirstFocusInCb.function.invoke(args);
//	}
//	return true;
//}
namespace Bridge
{

void TextWidgetExBridge::mapScriptInterface(ScriptContext& context)
{
	TextWidgetBridge::mapScriptInterface(context);
	
	context.bindNumber<CTextWidgetEx, float, &CTextWidgetEx::getX, &CTextWidgetEx::setX>("x");
	context.bindNumber<CTextWidgetEx, float, &CTextWidgetEx::getY, &CTextWidgetEx::setY>("y");
	context.bindNumber<CTextWidgetEx, float, &CTextWidgetEx::getWidth, &CTextWidgetEx::setWidth>("width");
	context.bindNumber<CTextWidgetEx, float, &CTextWidgetEx::getHeight, &CTextWidgetEx::setHeight>("height");
	context.bindNativeReference<CTextWidgetEx, Widget, &CTextWidgetEx::getParent, &CTextWidgetEx::setParent>("parent");
	context.captureMethodCall<CTextWidgetEx, &handleDestroy>("destroy");
	context.capturePropertyAccess<CTextWidgetEx, &getAlignment, &setAlignment>("horizontalAlignment"); //support both for backwards compatibility
	//context.capturePropertyAccess<CTextWidgetEx, &getShadow, &setShadow>("textShadow");
	//context.bindBoolean<CWidgetExtension, &CWidgetExtension::IsReversible, &CWidgetExtension::EnableReverse>("reversible");
	context.captureMethodCall<CTextWidgetEx, &isReversible>("isReversible");
	context.captureMethodCall<CTextWidgetEx, &enableReverse>("enableReverse");
	context.capturePropertyAccess<CTextWidgetEx, &m_isReversible, &m_enableReverse>("reversible");

	//context.captureMethodCall<CTextWidgetEx, &setParent>("setParent");
	//context.captureMethodCall<CTextWidgetEx, &setBackgroundColor>("setBackgroundColor");
	//context.captureMethodCall<CTextWidgetEx, &setSize>("setSize");
	//context.captureMethodCall<CTextWidgetEx, &setPositon>("setPosition");

	//context.captureMethodCall<CTextWidgetEx, &setLayout>("setLayout");
	context.captureMethodCall<CTextWidgetEx, &setOrientation>("setOrientation");

	//context.captureMethodCall<CTextWidgetEx, &show>("show");
	//context.captureMethodCall<CTextWidgetEx, &hide>("hide");

	//context.captureMethodCall<CTextWidgetEx, &setClipArea>("setClipArea");
	//context.captureMethodCall<CTextWidgetEx, &removeClipArea>("removeClipArea");
	//context.captureMethodCall<CTextWidgetEx, &setAlpha>("setAlpha");
	//context.captureMethodCall<CTextWidgetEx, &setPivotPoint>("setPivotPoint");
	//context.captureMethodCall<CTextWidgetEx, &setRotation>("setRotation");
	//context.captureMethodCall<CTextWidgetEx, &setScale>("setScale");
	//context.captureMethodCall<CTextWidgetEx, &setSize>("setSize");
	//context.captureMethodCall<CTextWidgetEx, &addChild>("addChild");
	//context.captureMethodCall<CTextWidgetEx, &numOfChildren>("numOfChildren");
	//context.captureMethodCall<CTextWidgetEx, &destroyAllChildren>("destroyAllChildren");
	//context.captureMethodCall<CTextWidgetEx, &raise>("raise");
	//context.captureMethodCall<CTextWidgetEx, &lower>("lower");
	context.captureMethodCall<CTextWidgetEx, &enable>("enable");
	context.captureMethodCall<CTextWidgetEx, &enableFocus>("enableFocus");
	context.captureMethodCall<CTextWidgetEx, &enablePointerFocus>("enablePointerFocus");
	context.captureMethodCall<CTextWidgetEx, &setFocus>("setFocus");
	context.captureMethodCall<CTextWidgetEx, &killFocus>("killFocus");
	context.captureMethodCall<CTextWidgetEx, &isFocused>("isFocused");
	context.captureMethodCall<CTextWidgetEx, &setTabWindow>("setTabWindow");
	context.captureMethodCall<CTextWidgetEx, &moveTab>("moveTab");

	context.captureMethodCall<CTextWidgetEx, &addMouseListener>("addMouseListener");
	context.captureMethodCall<CTextWidgetEx, &addKeyboardListener>("addKeyboardListener");
	context.captureMethodCall<CTextWidgetEx, &addClickListener>("addClickListener");
	context.captureMethodCall<CTextWidgetEx, &addKeyLongPressListener>("addKeyLongPressListener");
	context.captureMethodCall<CTextWidgetEx, &addFocusListener>("addFocusListener");
	context.captureMethodCall<CTextWidgetEx, &addDragListener>("addDragListener");
	context.captureMethodCall<CTextWidgetEx, &addActorListener>("addFirstShownListener");
	context.captureMethodCall<CTextWidgetEx, &addCursorListener>("addCursorListener");
	
	context.captureMethodCall<CTextWidgetEx, &addAction>("addAction");
	context.captureMethodCall<CTextWidgetEx, &removeMouseListener>("removeMouseListener");
	context.captureMethodCall<CTextWidgetEx, &removeKeyboardListener>("removeKeyboardListener");
	context.captureMethodCall<CTextWidgetEx, &removeClickListener>("removeClickListener");
	context.captureMethodCall<CTextWidgetEx, &removeKeyLongPressListener>("removeKeyLongPressListener");
	context.captureMethodCall<CTextWidgetEx, &removeFocusListener>("removeFocusListener");
	context.captureMethodCall<CTextWidgetEx, &removeDragListener>("removeDragListener");
	context.captureMethodCall<CTextWidgetEx, &removeActorListener>("removeFirstShownListener");
	context.captureMethodCall<CTextWidgetEx, &removeCursorListener>("removeCursorListener");
	context.captureMethodCall<CTextWidgetEx, &removeAction>("removeAction");

	//context.captureMethodCall<CTextWidgetEx, &bindTransition>("bindTransition");

	context.capturePropertyAccess<CTextWidgetEx, &m_getOrientation, &m_setOrientation>("orientation");
}

Widget* TextWidgetExBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	std::string text, font;
	bool justify = false, ellipsize = false, singleLineMode = false;
	LayoutAlignment align = LayoutAlignment::Left;
	VerticalLayoutAlignment valign = VerticalLayoutAlignment::Top;
	Color color = Color::White();
	int lineSpacing = 0;
	int maxLines = 0;
	bool maxLinesSpecified = false;

	if (args.Length() > 0)
	{
		//Get available arguments, either by options arguments or ordered, but not both.

		ScriptObject options = args[0];

		if (options.has("text") || options.has("font") || options.has("textColor") || options.has("horizontalAlignment") || options.has("verticalAlignment") ||
			options.has("ellipsize") || options.has("justify") || options.has("singleLineMode") ||
			options.has("lineSpacing"))
		{
			//options arguments
			if (options.has("text"))
			{
				text = options.get("text").asString();
			}

			if (options.has("font"))
			{
				font = options.get("font").asString();
			}

			if (options.has("textColor"))
			{
				color = ScriptToColor(options.get("textColor"));
			}

			if (options.has("ellipsize"))
			{
				ellipsize = options.get("ellipsize").asBool();
			}

			if (options.has("justify"))
			{
				justify = options.get("justify").asBool();
			}

			if (options.has("singleLineMode"))
			{
				singleLineMode = options.get("singleLineMode").asBool();
			}

			if (options.has("horizontalAlignment"))
			{
				align = deserializeLayoutAlignment(options.get("horizontalAlignment").asString(), Left);
			}

			if (options.has("verticalAlignment"))
			{
				valign = deserializeVerticalAlignment(options.get("verticalAlignment").asString());
			}

			if (options.has("lineSpacing"))
			{
				lineSpacing = options.get("lineSpacing").asNumber();
			}

			if (options.has("maxLines"))
			{
				maxLines = options.get("maxLines").asNumber();
				maxLinesSpecified = true;
			}
		}
		else //regular arguments
		{
			//Special case where only text is specified
			if (args[0].isString())
			{
				text = args[0].asString();
			}
		}
	}

	CTextWidgetEx* textWidget = new CTextWidgetEx(x, y, text, font, parent);
	textWidget->setLineSpacing(lineSpacing);

	if (width != -1)
	{
		textWidget->setWidth(width);
	}

	if (height != -1 && !maxLinesSpecified)
	{
		textWidget->setHeight(height);
	}

	if (maxLinesSpecified)
	{
		textWidget->setHeightInLines(maxLines);
	}

	textWidget->setTextColor(color);
	textWidget->setHorizontalAlignment(align);
	textWidget->setVerticalAlignment(valign);
	textWidget->setJustifyText(justify);
	textWidget->setUseEllipses(ellipsize);
	textWidget->setSingleLineMode(singleLineMode);

	if (args.Length() > 0)
	{
		ScriptObject options = args[0];

		if (options.has("textShadow"))
		{
			setShadow(textWidget, options.get("textShadow"));
		}
	}

	return (Widget*)textWidget;
}

void TextWidgetExBridge::destroyFromScript(void* destroyedObject)
{
  volt::graphics::Widget* widget = reinterpret_cast<volt::graphics::Widget*>(destroyedObject);
  delete widget;
  if (IEventManager::GetInstance())
  {
	  IEventManager::GetInstance()->RemoveAsyncReleaseTarget(widget);
  }
}

ScriptObject TextWidgetExBridge::handleDestroy(CTextWidgetEx* self, const ScriptArray& args)
{
	delete self;
	if (IEventManager::GetInstance())
	{
		IEventManager::GetInstance()->RemoveAsyncReleaseTarget(self);
	}
	return ScriptObject();
}
//
//ScriptObject TextWidgetExBridge::setBackgroundColor(CTextWidgetEx* self, const ScriptArray& args)
//{
//	guint8 r = 0, g = 0, b = 0, a = 0;
//
//	if(args.Length() > 0)
//	{
//		if(args.has(0) && args[0].isNumber()) {r = args[0].asNumber();}
//		if(args.has(1) && args[1].isNumber()) {g = args[1].asNumber();}
//		if(args.has(2) && args[2].isNumber()) {b = args[2].asNumber();}
//		if(args.has(3) && args[3].isNumber()) {a = args[3].asNumber();}
//	}
//	ClutterColor c = {r, g, b, a};
//
//	self->SetBackgroundColor(c);
//	
//	return ScriptObject();
//}
//
//ScriptObject Bridge::TextWidgetExBridge::setParent(CTextWidgetEx* self, const ScriptArray& args)
//{
//	if (args.Length() > 0)
//	{
//		CTextWidgetEx* parent = unwrapNativeObject<CTextWidgetEx>(args[0]);
//		self->SetParent(parent);
//	}
//
//	return ScriptObject();
//}
//
//ScriptObject Bridge::TextWidgetExBridge::setSize(CTextWidgetEx* self, const ScriptArray& args)
//{
//	float width = -1, height = -1;
//
//	if (args.Length() > 0)
//	{
//		if (args.has(0) && args[0].isNumber())
//		{
//			width = args[0].asNumber();
//		}
//		if (args.has(1) && args[1].isNumber())
//		{
//			height = args[1].asNumber();
//		}
//	}
//	self->Resize(width, height);
//
//	return ScriptObject();
//}
//
//ScriptObject TextWidgetExBridge::setPositon(CTextWidgetEx* self, const ScriptArray& args)
//{
//	float x = 0, y = 0;
//
//	if (args.Length() > 0)
//	{
//		if (args.has(0) && args[0].isNumber())
//		{
//			x = args[0].asNumber();
//		}
//		if (args.has(1) && args[1].isNumber())
//		{
//			y = args[1].asNumber();
//		}
//	}
//	self->SetPosition(x, y);
//
//	return ScriptObject();
//}
//
//ScriptObject Bridge::TextWidgetExBridge::setLayout(CTextWidgetEx* self, const ScriptArray& args)
//{
//	if (args.Length() > 0)
//	{
//		ILayout* layout = unwrapNativeObject<ILayout>(args[0]);
//		self->SetLayout(layout);
//	}
//
//	return ScriptObject();
//}

ScriptObject TextWidgetExBridge::isReversible(CTextWidgetEx* self, const ScriptArray& args)
{
	return ScriptObject(self->IsReversible());
}

ScriptObject TextWidgetExBridge::enableReverse(CTextWidgetEx* self, const ScriptArray& args)
{
	bool flagEnable = true;

	if (args.Length() > 0)
	{
		if (args[0].isBool())
		{
			flagEnable = args[0].asBool();
		}
	}
	self->EnableReverse(flagEnable);

	return ScriptObject();
}

ScriptObject TextWidgetExBridge::setOrientation(CTextWidgetEx* self, const ScriptArray& args)
{
	HALO_ASSERT(1 == args.Length() && true == args[0].isString());

	std::string orientationStr = args[0].asString();
	EOrientation orientationValue;

	if ("left-to-right" == orientationStr)
	{
		orientationValue = ORIENTATION_LEFT_TO_RIGHT;
	}
	else if ("right-to-left" == orientationStr)
	{
		orientationValue = ORIENTATION_RIGHT_TO_LEFT;
	}
	else if ("refer-to-parent" == orientationStr)
	{
		orientationValue = ORIENTATION_REFER_TO_PARENT;
	}
	else
	{
		HALO_EXCEPTION(false,  "orientation value is not correct\n");
	}

	self->SetOrientation(orientationValue);

	return ScriptObject();
}

//ScriptObject TextWidgetExBridge::show(CTextWidgetEx* self, const ScriptArray& args)
//{
//	self->Show();
//	return ScriptObject();
//}
//
//ScriptObject Bridge::TextWidgetExBridge::hide(CTextWidgetEx* self, const ScriptArray& args)
//{
//	self->Hide();
//	return ScriptObject();
//}
//
//ScriptObject Bridge::TextWidgetExBridge::setClipArea(CTextWidgetEx* self, const ScriptArray& args)
//{
//	float x = 0, y = 0, width = 0, height = 0;
//	if (args.Length() >= 4)
//	{
//		if (args[0].isNumber())
//		{
//			x = args[0].asNumber();
//		}
//		if (args[1].isNumber())
//		{
//			y = args[1].asNumber();
//		}
//		if (args[2].isNumber())
//		{
//			width = args[2].asNumber();
//		}
//		if (args[3].isNumber())
//		{
//			height = args[3].asNumber();
//		}
//	}
//
//	self->SetClipArea(x, y, width, height);
//
//	return ScriptObject();
//}
//
//ScriptObject Bridge::TextWidgetExBridge::removeClipArea(CTextWidgetEx* self, const ScriptArray& args)
//{
//	self->RemoveClipArea();
//	return ScriptObject();
//}
//
//ScriptObject Bridge::TextWidgetExBridge::setAlpha(CTextWidgetEx* self, const ScriptArray& args)
//{
//	return ScriptObject();
//}
//
//ScriptObject Bridge::TextWidgetExBridge::setPivotPoint(CTextWidgetEx* self, const ScriptArray& args)
//{
//	return ScriptObject();
//}
//
//ScriptObject Bridge::TextWidgetExBridge::setRotation(CTextWidgetEx* self, const ScriptArray& args)
//{
//	return ScriptObject();
//}
//
//ScriptObject Bridge::TextWidgetExBridge::setScale(CTextWidgetEx* self, const ScriptArray& args)
//{
//	return ScriptObject();
//}
//
//ScriptObject Bridge::TextWidgetExBridge::addChild(CTextWidgetEx* self, const ScriptArray& args)
//{
//	if (args.Length() > 0)
//	{
//		ClutterActor* child = unwrapNativeObject<ClutterActor>(args[0]);
//		if (child != nullptr)
//		{
//			self->AddChild(child);
//		}
//	}
//	return ScriptObject();
//}
//
//ScriptObject Bridge::TextWidgetExBridge::numOfChildren(CTextWidgetEx* self, const ScriptArray& args)
//{
//	int num = self->NumOfChildren();
//	return ScriptObject(num);
//}
//
//ScriptObject Bridge::TextWidgetExBridge::destroyAllChildren(CTextWidgetEx* self, const ScriptArray& args)
//{
//	self->DestroyAllChildren();
//	return ScriptObject();
//}
//
//ScriptObject Bridge::TextWidgetExBridge::raise(CTextWidgetEx* self, const ScriptArray& args)
//{
//	if (args.Length() > 0)
//	{
//		CTextWidgetEx* sibling = unwrapNativeObject<CTextWidgetEx>(args[0]);
//		self->Raise(sibling);
//	}
//	return ScriptObject();
//}
//
//ScriptObject Bridge::TextWidgetExBridge::lower(CTextWidgetEx* self, const ScriptArray& args)
//{
//	if (args.Length() > 0)
//	{
//		CTextWidgetEx* sibling = unwrapNativeObject<CTextWidgetEx>(args[0]);
//		self->Lower(sibling);
//	}
//	return ScriptObject();
//}

ScriptObject TextWidgetExBridge::enable(CTextWidgetEx* self, const ScriptArray& args)
{
	bool flagEnable = true;

	if (args.Length() > 0)
	{
		if (args[0].isBool())
		{
			flagEnable = args[0].asBool();
		}
	}
	self->Enable(flagEnable);

	return ScriptObject();
}

ScriptObject TextWidgetExBridge::enableFocus(CTextWidgetEx* self, const ScriptArray& args)
{
	bool flagEnable = true;

	if (args.Length() > 0)
	{
		if (args[0].isBool())
		{
			flagEnable = args[0].asBool();
		}
	}
	self->EnableFocus(flagEnable);

	return ScriptObject();
}

ScriptObject TextWidgetExBridge::enablePointerFocus(CTextWidgetEx* self, const ScriptArray& args)
{
	bool flagEnable = true;

	if (args.Length() > 0)
	{
		if (args[0].isBool())
		{
			flagEnable = args[0].asBool();
		}
	}
	self->EnablePointerFocus(flagEnable);

	return ScriptObject();
}

ScriptObject TextWidgetExBridge::setFocus(CTextWidgetEx* self, const ScriptArray& args)
{
	self->SetFocus();
	return ScriptObject();
}

ScriptObject TextWidgetExBridge::killFocus(CTextWidgetEx* self, const ScriptArray& args)
{
	self->KillFocus();
	return ScriptObject();
}

ScriptObject TextWidgetExBridge::isFocused(CTextWidgetEx* self, const ScriptArray& args)
{
	return ScriptObject(self->IsFocused());
}

ScriptObject TextWidgetExBridge::setTabWindow(CTextWidgetEx* self, const ScriptArray& args)
{
	std::string direction = args[0].asString();

	EDirection eDir = DIRECTION_MAX;
	if (direction == "left")
	{
		eDir = DIRECTION_LEFT;
	}
	else if (direction == "right")
	{
		eDir = DIRECTION_RIGHT;
	}
	else if (direction == "up")
	{
		eDir = DIRECTION_UP;
	}
	else if (direction == "down")
	{
		eDir = DIRECTION_DOWN;
	}
	else
	{
		HALO_EXCEPTION(false,  "Wrong direction!");
	}
	
	CTextWidgetEx *tabWindow = unwrapNativeObject<CTextWidgetEx>(args[0]);

	self->SetTabWindow(eDir, tabWindow);
	
	return ScriptObject();
}

ScriptObject TextWidgetExBridge::moveTab(CTextWidgetEx* self, const ScriptArray& args)
{
	return ScriptObject();
}

ScriptObject TextWidgetExBridge::addMouseListener(CTextWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IMouseListener* listener = unwrapNativeObject<IMouseListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddMouseListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject TextWidgetExBridge::addKeyboardListener(CTextWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IKeyboardListener* listener = unwrapNativeObject<IKeyboardListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddKeyboardListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject TextWidgetExBridge::addClickListener(CTextWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IClickListener* listener = unwrapNativeObject<IClickListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddClickListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject TextWidgetExBridge::addKeyLongPressListener(CTextWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IKeyLongPressListener* listener = unwrapNativeObject<IKeyLongPressListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddKeyLongPressListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject TextWidgetExBridge::addFocusListener(CTextWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IFocusListener* listener = unwrapNativeObject<IFocusListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddFocusListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject TextWidgetExBridge::addDragListener(CTextWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IDragListener* listener = unwrapNativeObject<IDragListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddDragListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject TextWidgetExBridge::addCursorListener(CTextWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			ICursorListener* listener = unwrapNativeObject<ICursorListener>(args[0]);
			if (listener != nullptr)
			{
				self->AddCursorListener(listener);
			}
		}
		return ScriptObject();
	}
ScriptObject TextWidgetExBridge::addActorListener(CTextWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		InternalActorListener* listener = unwrapNativeObject<InternalActorListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddActorListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject TextWidgetExBridge::removeActorListener(CTextWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			InternalActorListener* listener = unwrapNativeObject<InternalActorListener>(args[0]);
			if (listener != nullptr)
			{
				self->RemoveActorListener(listener);
			}
		}
		return ScriptObject();
	}
ScriptObject TextWidgetExBridge::addAction(CTextWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IAction* action = unwrapNativeObject<IAction>(args[0]);
		if (action != nullptr)
		{
			self->AddAction(action);
		}
	}
	return ScriptObject();
}

ScriptObject TextWidgetExBridge::removeMouseListener(CTextWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IMouseListener* listener = unwrapNativeObject<IMouseListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveMouseListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject TextWidgetExBridge::removeKeyboardListener(CTextWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IKeyboardListener* listener = unwrapNativeObject<IKeyboardListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveKeyboardListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject TextWidgetExBridge::removeClickListener(CTextWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IClickListener* listener = unwrapNativeObject<IClickListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveClickListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject TextWidgetExBridge::removeKeyLongPressListener(CTextWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IKeyLongPressListener* listener = unwrapNativeObject<IKeyLongPressListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveKeyLongPressListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject TextWidgetExBridge::removeFocusListener(CTextWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IFocusListener* listener = unwrapNativeObject<IFocusListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveFocusListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject TextWidgetExBridge::removeDragListener(CTextWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IDragListener* listener = unwrapNativeObject<IDragListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveDragListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject TextWidgetExBridge::removeCursorListener(CTextWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			ICursorListener* listener = unwrapNativeObject<ICursorListener>(args[0]);
			if (listener != nullptr)
			{
				self->RemoveCursorListener(listener);
			}
		}
		return ScriptObject();
	}
ScriptObject TextWidgetExBridge::removeAction(CTextWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IAction* listener = unwrapNativeObject<IAction>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveAction(listener);
		}
	}
	return ScriptObject();
}

//ScriptObject Bridge::TextWidgetExBridge::bindTransition(CTextWidgetEx* self, const ScriptArray& args)
//{
//	HALO_ASSERT(NULL != self);
//	HALO_ASSERT(2 == args.Length() && true == args[1].isNumber());
//
//	ITransition *trans = unwrapNativeObject<ITransition>(args[0]);
//	int animationType = (int)args[1].asNumber();
//
//	self->BindTransition(trans, animationType);
//
//	return ScriptObject();
//}

ScriptObject TextWidgetExBridge::m_getOrientation(CTextWidgetEx* self)
{
	EOrientation ori = self->Orientation(true);
	switch (ori)
	{
	case HALO::ORIENTATION_RIGHT_TO_LEFT:
		return ScriptObject("right-to-left");
	case HALO::ORIENTATION_REFER_TO_PARENT:
		return ScriptObject("refer-to-parent");
	default:
		return ScriptObject("left-to-right");
	}
}

void TextWidgetExBridge::m_setOrientation(CTextWidgetEx* self, ScriptObject value)
{
	std::string orientationStr = value.asString();
	EOrientation orientationValue = ORIENTATION_REFER_TO_PARENT;

	if ("left-to-right" == orientationStr)
	{
		orientationValue = ORIENTATION_LEFT_TO_RIGHT;
	}
	else if ("right-to-left" == orientationStr)
	{
		orientationValue = ORIENTATION_RIGHT_TO_LEFT;
	}
	else if ("refer-to-parent" == orientationStr)
	{
		orientationValue = ORIENTATION_REFER_TO_PARENT;
	}
	else
	{
		HALO_EXCEPTION(false,  "orientation value is not correct\n");
	}

	self->SetOrientation(orientationValue);
}

void TextWidgetExBridge::setShadow(CTextWidgetEx* self, ScriptObject val)
{
  if(val.isNull())
  {
    self->setHasShadow(false);
  }
  else
  {
    float xOffset = val["xOffset"].asNumber();
    float yOffset = val["yOffset"].asNumber();

    if(val.has("color"))
    {
      Color color = ScriptToColor(val["color"]);
      self->setShadowColor(color);
    }

    self->setShadowXOffset(xOffset);
    self->setShadowYOffset(yOffset);
    self->setHasShadow(true);
  }
}

VerticalLayoutAlignment TextWidgetExBridge::deserializeVerticalAlignment(std::string stringValign)
{
  if(compareStrChar(stringValign, "center"))
  {
    return VerticalLayoutAlignment::Middle;
  }
  else if(compareStrChar(stringValign, "bottom"))
  {
    return VerticalLayoutAlignment::Bottom;
  }
  else
  {
    return VerticalLayoutAlignment::Top;
  }
}

std::string TextWidgetExBridge::serializeVerticalAlignment(VerticalLayoutAlignment valign)
{
  switch(valign)
  {
  case VerticalLayoutAlignment::Middle:
    return "center";
  case VerticalLayoutAlignment::Bottom:
    return "bottom";
  default:
    return "top";
  }
}

ScriptObject TextWidgetExBridge::getAlignment(CTextWidgetEx* self)
{
	return serializeLayoutAlignment(self->getHorizontalAlignment());
}

void TextWidgetExBridge::setAlignment(CTextWidgetEx* self, ScriptObject value)
{
	self->setHorizontalAlignment(deserializeLayoutAlignment(value.asString(), Left));
}

ScriptObject TextWidgetExBridge::m_isReversible(CTextWidgetEx* self)
{
	bool reversibleFlag = self->IsReversible();
	return ScriptObject(reversibleFlag);
}

void TextWidgetExBridge::m_enableReverse(CTextWidgetEx* self, ScriptObject value)
{
	bool reverseFlag = value.asBool();
	self->EnableReverse(reverseFlag);
}
}