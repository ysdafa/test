#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void Bridge::CheckBoxGroupBridge::mapScriptInterface( ScriptContext& context )
{
	ActorBridge::mapScriptInterface(context);
	context.captureMethodCall<CCheckBoxGroup, &addButton>("addButton");
	context.captureMethodCall<CCheckBoxGroup, &removeButton>("removeButton");
	context.captureMethodCall<CCheckBoxGroup, &getItemById>("getItemById");
	context.captureMethodCall<CCheckBoxGroup, &setDefaultFocus>("setDefaultFocus");
	context.captureMethodCall<CCheckBoxGroup, &numofItem>("numofItem");
	context.captureMethodCall<CCheckBoxGroup, &addlistener>("addlistener");
	context.captureMethodCall<CCheckBoxGroup, &getSelectedItemIndexes>("getSelectedItemIndexes");
	context.captureMethodCall<CCheckBoxGroup, &setDefaultSelectedItem>("setDefaultSelectedItem");
	context.captureMethodCall<CCheckBoxGroup, &removeListener>("removeListener");
}

Bridge::ScriptObject Bridge::CheckBoxGroupBridge::addButton( CCheckBoxGroup* self, const ScriptArray& args )
{
	if (args.Length() > 0)
	{
		ISelectButton* button = unwrapNativeObject<CSelectButton>(args[0]);
		if (button != nullptr)
		{
			self->AddButton(button);
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CheckBoxGroupBridge::getItemById( CCheckBoxGroup* self, const ScriptArray& args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	int id = object.get("id").asNumber();
	return ScriptObject(self->GetItemById(id));
}

Bridge::ScriptObject Bridge::CheckBoxGroupBridge::setDefaultFocus( CCheckBoxGroup* self, const ScriptArray& args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	int itemid = object.get("itemid").asNumber();
	self->SetDefaultFocus(itemid);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CheckBoxGroupBridge::numofItem( CCheckBoxGroup* self, const ScriptArray& args )
{
	return ScriptObject( self->NumofItem());	
}


Bridge::ScriptObject Bridge::CheckBoxGroupBridge::addlistener( CCheckBoxGroup* self, const ScriptArray& args )
{
	if (args.Length() > 0)
	{
		OnCheckedChangedListener* listener = unwrapNativeObject<OnCheckedChangedListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddListener(listener);
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CheckBoxGroupBridge::getSelectedItemIndexes( CCheckBoxGroup* self, const ScriptArray& args )
{
	std::vector<int> resultVector = self->GetSelectedItemIndexes();

	ScriptArray result;

	for (int i = 0; i < (int)resultVector.size(); i++)
	{
		result.set(i, ScriptObject(resultVector[i]));
	}

	return ScriptObject(result);
}

Bridge::ScriptObject Bridge::CheckBoxGroupBridge::setDefaultSelectedItem( CCheckBoxGroup* self, const ScriptArray& args )
{
	ScriptObject object = args[0];
	int id = (int)object.get("id").asNumber();
	self->SetDefaultSelectedItem(id);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::CheckBoxGroupBridge::removeListener( CCheckBoxGroup* self, const ScriptArray& args )
{
	if (args.Length() > 0)
	{
		OnCheckedChangedListener* listener = unwrapNativeObject<OnCheckedChangedListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveListener(listener);
		}
	}
	return ScriptObject();
}

Widget* Bridge::CheckBoxGroupBridge::constructWidget( float x, float y, float width, float height, Widget* parent, const ScriptArray& args )
{
	CCheckBoxGroup *group = dynamic_cast<CCheckBoxGroup *>(ICheckBoxGroup::CreateInstance());
	return (Widget*)group;
}

Bridge::ScriptObject Bridge::CheckBoxGroupBridge::removeButton( CCheckBoxGroup* self, const ScriptArray& args )
{
	if (args.Length() > 0)
	{
		ISelectButton* button = unwrapNativeObject<CSelectButton>(args[0]);
		if (button != nullptr)
		{
			self->RemoveButton(button);
		}
	}
	return ScriptObject();
}

void Bridge::CheckBoxGroupListenerBridge::mapScriptInterface( ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	context.bindFunction<InternalCheckBoxGroupListener, &InternalCheckBoxGroupListener::GetCheckedChangedCallBack, &InternalCheckBoxGroupListener::SetCheckedChangedCallBack>("onCheckedChanged");
}

void* Bridge::CheckBoxGroupListenerBridge::constructFromScript( const ScriptArray& args )
{
	return new InternalCheckBoxGroupListener;
}

bool Bridge::InternalCheckBoxGroupListener::OnCheckChanged( class ISelectButtonGroup* list , int index , bool ischecked ,ISelectButton* checkcontrol)
{
	if (true == CheckedChangedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CCheckBoxGroup*>(list)));
		args.set(1, index);
		args.set(2, ischecked);
		args.set(3, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CSelectButton*>(checkcontrol)));
		CheckedChangedCb.function.invoke(args);
	}
	return true;
}

