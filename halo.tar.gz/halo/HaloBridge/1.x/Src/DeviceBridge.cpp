#include "HaloBridgeAll.h"

using namespace HALO;
using namespace	Bridge;

// Device
void DeviceBridge::mapScriptInterface(ScriptContext& context)
{
	//printf("DeviceBridge::Function %s, context 0x%x\n", __FUNCTION__, &context);
	context.captureMethodCall<IDevice, &getDeviceType>("getDeviceType");
	context.captureMethodCall<IDevice, &getDeviceID>("getDeviceID");
	context.captureMethodCall<IDevice, &getDeviceName>("getDeviceName");
}

void* DeviceBridge::constructFromScript(const ScriptArray& args)
{
	long ptr = 0;
	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber())
		{
			ptr = (long)args[0].asNumber();
		}
	}
	
	IDevice *device = (IDevice*)(ptr);

	return device;
}

ScriptObject DeviceBridge::getDeviceType(IDevice* self, const ScriptArray& args)
{
	return ScriptObject(self->DeviceType());
}

ScriptObject DeviceBridge::getDeviceID(IDevice* self, const ScriptArray& args)
{
	return ScriptObject(self->DeviceId());
}

ScriptObject DeviceBridge::getDeviceName(IDevice* self, const ScriptArray& args)
{
	return wrapExistingNativeObject(self->DeviceName());
}

// Mouse
void MouseDeviceBridge::mapScriptInterface(ScriptContext& context)
{
	DeviceBridge::mapScriptInterface(context);
	
	context.captureMethodCall<IMouseDevice, &setPointerSensibility>("setPointerSensibility");
	context.captureMethodCall<IMouseDevice, &getPointerSensibility>("getPointerSensibility");
	context.captureMethodCall<IMouseDevice, &setMouseOption>("setMouseOption");
	context.captureMethodCall<IMouseDevice, &getMouseOption>("getMouseOption");
}
void* MouseDeviceBridge::constructFromScript(const ScriptArray& args)
{
	long ptr = 0;
	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) 
		{
			ptr = (long)args[0].asNumber();
		}
	}
	IDevice *temp = (IDevice*)(ptr);
	IMouseDevice *device = dynamic_cast<IMouseDevice *>(temp);
	return device;
}

ScriptObject MouseDeviceBridge::setPointerSensibility(IMouseDevice* self, const ScriptArray& args)
{
	guint8 level = 0;
	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) 
		{
			level = args[0].asNumber();
			self->SetPointerSensibility(level);
		}
	}

	return ScriptObject();
}

ScriptObject MouseDeviceBridge::getPointerSensibility(IMouseDevice* self, const ScriptArray& args)
{
	return ScriptObject(self->PointerSensibility());
}

ScriptObject MouseDeviceBridge::setMouseOption(IMouseDevice* self, const ScriptArray& args)
{
	int optionType = IMouseDevice::MOUSE_OPTION_MAX;
	int optionValue = 0;

	if(args.Length() > 0)
	{
		if (args.Length() == 2 && args[0].isNumber() && args[1].isNumber())
		{
			optionType = args[0].asNumber();
			optionValue = args[1].asNumber();
			self->SetMouseOption((IMouseDevice::EMouseOption)optionType, optionValue);
		}
	}

	return ScriptObject();
}

ScriptObject MouseDeviceBridge::getMouseOption(IMouseDevice* self, const ScriptArray& args)
{
	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) 
		{
			return ScriptObject(self->MouseOption(args[0].asNumber()));
		}
	}

	return ScriptObject();
}

// Keyboard
void KeyboardDeviceBridge::mapScriptInterface(ScriptContext& context)
{
	DeviceBridge::mapScriptInterface(context);
	
	context.captureMethodCall<IKeyboardDevice, &setKeyboardOption>("setKeyboardOption");
	context.captureMethodCall<IKeyboardDevice, &getKeyboardOption>("getKeyboardOption");
}

void* KeyboardDeviceBridge::constructFromScript(const ScriptArray& args)
{
	long ptr = 0;
	
	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) 
		{
			ptr = (long)args[0].asNumber();
		}
	}
	
	IDevice *temp = (IDevice*)(ptr);
	IKeyboardDevice *device = dynamic_cast<IKeyboardDevice *>(temp);
	
	return device;
}


ScriptObject KeyboardDeviceBridge::setKeyboardOption(IKeyboardDevice* self, const ScriptArray& args)
{
	int optionType = IKeyboardDevice::KEYBOARD_OPTION_MAX;
	int optionValue = 0;

	if(args.Length() > 0)
	{
		if (args.Length() == 2 && args[0].isNumber() && args[1].isNumber())
		{
			optionType = args[0].asNumber();
			optionValue = args[1].asNumber();
			self->SetKeyboardOption((IKeyboardDevice::EKeyboardOption)optionType, optionValue);
		}
	}

	return ScriptObject();
}

ScriptObject KeyboardDeviceBridge::getKeyboardOption(IKeyboardDevice* self, const ScriptArray& args)
{
	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) 
		{
			return ScriptObject(self->KeyboardOption(args[0].asNumber()));
		}
	}

	return ScriptObject();
}



