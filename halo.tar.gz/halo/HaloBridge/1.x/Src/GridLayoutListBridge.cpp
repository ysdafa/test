#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

bool InternalGridListener::OnItemLoaded(class IGridListControl* list, int groupIndex, int itemIndex)
{
	if (true == ItemLoadedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CGridListControl*>(list)));
		args.set(1, ScriptObject(groupIndex));
		args.set(2, ScriptObject(itemIndex));
		ItemLoadedCb.function.invoke(args);
	}
	return true;
}

bool InternalGridListener::OnItemUnloaded(class IGridListControl* list, int groupIndex, int itemIndex)
{
	if (true == ItemUnloadedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CGridListControl*>(list)));
		args.set(1, ScriptObject(groupIndex));
		args.set(2, ScriptObject(itemIndex));
		ItemUnloadedCb.function.invoke(args);
	}
	return true;
}

bool InternalGridListener::OnAsyncItemLoad(class IGridListControl *list, int groupIndex, int itemIndex)
{
	if (true == AsyncItemLoadCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CGridListControl*>(list)));
		args.set(1, ScriptObject(groupIndex));
		args.set(2, ScriptObject(itemIndex));
		AsyncItemLoadCb.function.invoke(args);
	}
	return true;
}

bool InternalGridListener::OnFocusChanged(class IGridListControl *list, int fromGroupIndex, int fromItemIndex, int toGroupIndex, int toItemIndex)
{
	if (true == FocusChangedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CGridListControl*>(list)));
		args.set(1, ScriptObject(fromGroupIndex));
		args.set(2, ScriptObject(fromItemIndex));
		args.set(3, ScriptObject(toGroupIndex));
		args.set(4, ScriptObject(toItemIndex));
		FocusChangedCb.function.invoke(args);
	}
	return true;
}

bool InternalGridListener::OnFocusChangeMotionStart(class IGridListControl* list, int fromGroupIndex, int fromItemIndex, int toGroupIndex, int toItemIndex)
{
	if (true == FocusChangeMotionStartCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CGridListControl*>(list)));
		args.set(1, ScriptObject(fromGroupIndex));
		args.set(2, ScriptObject(fromItemIndex));
		args.set(3, ScriptObject(toGroupIndex));
		args.set(4, ScriptObject(toItemIndex));
		FocusChangeMotionStartCb.function.invoke(args);
	}
	return true;
}

bool InternalGridListener::OnMoveOut(class IGridListControl* list, EDirection direction, int fromGroupIndex, int fromItemIndex)
{
	if (true == MoveOutCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CGridListControl*>(list)));

		std::string directionString;

		ScriptObject exArgs;

		switch (direction)
		{
		case DIRECTION_UP:
			directionString = "Up";
			break;

		case DIRECTION_DOWN:
			directionString = "Down";
			break;

		case DIRECTION_LEFT:
			directionString = "Left";
			break;

		case DIRECTION_RIGHT:
			directionString = "Right";
			break;

		default:
			break;
		}

		args.set(1, directionString);
		args.set(2, fromGroupIndex);
		args.set(3, fromItemIndex);

		MoveOutCb.function.invoke(args);
	}

	return true;
}

bool InternalGridListener::OnItemIndexChanged(class IGridListControl* list, int fromGroupIndex, int fromItemIndex, int toGroupIndex, int toItemIndex)
{
	if (true == ItemIndexChangedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CGridListControl*>(list)));
		args.set(1, ScriptObject(fromGroupIndex));
		args.set(2, ScriptObject(fromItemIndex));
		args.set(3, ScriptObject(toGroupIndex));
		args.set(4, ScriptObject(toItemIndex));
		ItemIndexChangedCb.function.invoke(args);
	}
	return true;
}

bool InternalGridListener::OnItemClicked(class IGridListControl* list, int groupIndex, int itemIndex)
{
	if (true == ItemClickedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CGridListControl*>(list)));
		args.set(1, ScriptObject(groupIndex));
		args.set(2, ScriptObject(itemIndex));
		ItemClickedCb.function.invoke(args);
	}
	return true;
}

bool Bridge::InternalGridListener::OnEnterKeyLongPressed(class IGridListControl *list, int groupIndex, int itemIndex)
{
	if (true == EnterKeyLongPressedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CGridListControl*>(list)));
		args.set(1, ScriptObject(groupIndex));
		args.set(2, ScriptObject(itemIndex));
		EnterKeyLongPressedCb.function.invoke(args);
	}
	return true;
}

void GridLayoutListListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	context.bindFunction<InternalGridListener, &InternalGridListener::GetItemLoadedCallBack, &InternalGridListener::SetItemLoadedCallBack>("onItemLoaded");
	context.bindFunction<InternalGridListener, &InternalGridListener::GetItemUnloadedCallBack, &InternalGridListener::SetItemUnloadedCallBack>("onItemUnloaded");
	context.bindFunction<InternalGridListener, &InternalGridListener::GetAsyncItemLoadCallBack, &InternalGridListener::SetAsyncItemLoadCallBack>("onAsyncItemLoad");
	context.bindFunction<InternalGridListener, &InternalGridListener::GetFocusChangedCallBack, &InternalGridListener::SetFocusChangedCallBack>("onFocusChanged");
	context.bindFunction<InternalGridListener, &InternalGridListener::GetFocusChangeMotionStartCallBack, &InternalGridListener::SetFocusChangeMotionStartCallBack>("onFocusChangeStart");
	context.bindFunction<InternalGridListener, &InternalGridListener::GetMoveOutCallBack, &InternalGridListener::SetMoveOutCallBack>("onMoveOut");
	context.bindFunction<InternalGridListener, &InternalGridListener::GetItemIndexChangedCallBack, &InternalGridListener::SetItemIndexChangedCallBack>("onItemIndexChanged");

	context.bindFunction<InternalGridListener, &InternalGridListener::GetItemClickedCallBack, &InternalGridListener::SetItemClickedCallBack>("onItemClicked");
	context.bindFunction<InternalGridListener, &InternalGridListener::GetEnterKeyLongPressedCallBack, &InternalGridListener::SetEnterKeyLongPressedCallBack>("onEnterKeyLongPressed");
}

void* GridLayoutListListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalGridListener;
}

void GridLayoutListBridge::mapScriptInterface(ScriptContext& context)
{
	DataListBridge::mapScriptInterface(context);
 	context.captureMethodCall<CGridListControl, &m_AddGroup>("addGroup");
 	context.captureMethodCall<CGridListControl, &m_AddStyle>("addStyle");
 	context.captureMethodCall<CGridListControl, &m_AddColumn>("addColumn");
 	context.captureMethodCall<CGridListControl, &m_AddRowToColumn>("addRowToColumn");
 	context.captureMethodCall<CGridListControl, &m_AddRowToAllColumn>("addRowToAllColumn");
	context.captureMethodCall<CGridListControl, &m_MergeCells>("mergeCells");
	context.captureMethodCall<CGridListControl, &m_SetStyle>("setStyle");
	context.captureMethodCall<CGridListControl, &m_TransformStyle>("transformStyle");
	context.captureMethodCall<CGridListControl, &m_EnlargeFocusItem>("enlargeFocusItem");
	context.captureMethodCall<CGridListControl, &m_SetFocusItemIndex>("setFocusItemIndex");
	context.captureMethodCall<CGridListControl, &m_GetFocusItemIndex>("getFocusItemIndex");
	context.captureMethodCall<CGridListControl, &m_SetAnimationDuration>("setAnimationDuration");

	context.captureMethodCall<CGridListControl, &m_AddDataGroup>("addDataGroup");
	context.captureMethodCall<CGridListControl, &m_AddData>("addData");
	context.captureMethodCall<CGridListControl, &m_GetData>("getData");
	context.captureMethodCall<CGridListControl, &m_InsertData>("insertData");
	context.captureMethodCall<CGridListControl, &m_RemoveData>("removeData");
	context.captureMethodCall<CGridListControl, &m_AttachGroupTitle>("attachGroupTitle");

	context.captureMethodCall<CGridListControl, &m_AddListListener>("addListListener");

	context.captureMethodCall<CGridListControl, &columnCount>("columnCount");
	context.captureMethodCall<CGridListControl, &updateItem>("updateItem");
	context.captureMethodCall<CGridListControl, &updateAllItems>("updateAllItems");
	context.captureMethodCall<CGridListControl, &clearDataSource>("clearDataSource");

	context.bindBoolean<CGridListControl, &CGridListControl::IsEditEnabled, &CGridListControl::EnableEdit>("editFlag");

	context.bindBoolean<CGridListControl, &CGridListControl::IsSetMarginWhenFocusEdgeItem, &CGridListControl::EnableMarginWhenFocusEdgeItem>("useMarginWhenFocusEdgeItem");
	context.bindBoolean<CGridListControl, &CGridListControl::IsStraightPathOnFocusMovingEnabled, &CGridListControl::EnableStraightPathOnFocusMoving>("straightPath");
	context.bindBoolean<CGridListControl, &CGridListControl::IsRolloverEffectEnabled, &CGridListControl::EnableRolloverEffect>("rolloverEffect");

	context.captureMethodCall<CGridListControl, &addRegularGrid>("addRegularGrid");

	context.captureMethodCall<CGridListControl, &setBufferColumnSize>("setBufferColumnSize");	

	context.captureMethodCall<CGridListControl, &renderer>("renderer");

	context.captureMethodCall<CGridListControl, &getOnScreenRange>("getOnScreenRange");

	context.captureMethodCall<CGridListControl, &itemCount>("itemCount");

	context.captureMethodCall<CGridListControl, &enableItem>("enableItem");

	context.captureMethodCall<CGridListControl, &isItemEnabled>("isItemEnabled");

	context.captureMethodCall<CGridListControl, &m_IsThumbStyleOfItemEnable>("isThumbStyleEnable");

	context.captureMethodCall<CGridListControl, &m_GetThumbnailStyle>("getThumbnailStyle");

	context.captureMethodCall<CGridListControl, &m_SetCheckToThumbnailOfGroup>("setCheckToGroup");
	context.captureMethodCall<CGridListControl, &m_SetCheckToThumbnailOfItem>("setCheckToItem");

	context.captureMethodCall<CGridListControl, &m_EnableThumbnailStyleOfGroup>("enableThumbnailStyleOfGroup");
	context.captureMethodCall<CGridListControl, &m_EnableThumbnailStyleOfItem>("enableThumbnailStyleOfItem");

	context.captureMethodCall<CGridListControl, &m_StartScrollPlayer>("startScrollTimer");

	context.captureMethodCall<CGridListControl, &m_StopScrollPlayer>("stopScrollTimer");

	context.bindNumber<CGridListControl, int, &CGridListControl::TimerInterval, &CGridListControl::SetTimerInterval>("scrollTimerInterval");

}

CDataListControl* GridLayoutListBridge::constructSubWidget(Widget* parent, float width, float height, const ScriptObject& argObject)
{
	ARG_IS_VALID(argObject, "titleSpace", isNumber);
	ARG_IS_VALID(argObject, "groupSpace", isNumber);
	ARG_IS_VALID(argObject, "cellSpace", isNumber);
	ARG_IS_VALID(argObject, "focusRangeStartOffset", isNumber);
	ARG_IS_VALID(argObject, "focusRangeEndOffset", isNumber);

	IGridListControl::TGridListControlAttr attr(width, height);
	
	attr.titleSpace = (float)(argObject.get("titleSpace").asNumber());
	attr.groupSpace = (float)argObject.get("groupSpace").asNumber();
	attr.cellSpace = (float)argObject.get("cellSpace").asNumber();
	attr.focusRangeOffset[0] = (float)argObject.get("focusRangeStartOffset").asNumber();
	attr.focusRangeOffset[1] = (float)argObject.get("focusRangeEndOffset").asNumber();

	float scaleRatio = 1.0f;

	if (argObject.has("isVertical"))
	{
		bool flagIsVertical = argObject.get("isVertical").asBool();

		if (true == flagIsVertical)
		{
			attr.directionType = TYPE_VERTICAL;
		}
		else
		{
			attr.directionType = TYPE_HORIZONTAL;
		}
	}

	if (TYPE_VERTICAL == attr.directionType)
	{
		scaleRatio = t_ScaleRatioWidth();
	}
	else
	{
		scaleRatio = t_ScaleRatioHeight();
	}
	
	attr.titleSpace *= scaleRatio;
	attr.groupSpace *= scaleRatio;
	attr.cellSpace *= scaleRatio;
	attr.focusRangeOffset[0] *= scaleRatio;
	attr.focusRangeOffset[1] *= scaleRatio;

	CGridListControl *control = dynamic_cast<CGridListControl*>(IGridListControl::CreateInstance(parent, attr));
	control->EnableRolloverEffect(false);

	//control->AddListListener(this);
	
	return control;
}

ScriptObject GridLayoutListBridge::m_AddGroup(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(args.has(0) && true == args[0].isNumber());

	int numberOfGroup = (int)args[0].asNumber();
	self->AddGroup(numberOfGroup);
	
	return ScriptObject();
}

ScriptObject GridLayoutListBridge::m_AddStyle(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length() && true == args[0].isNumber());

	int numOfStyle = (int)args[0].asNumber();
	bool ret = self->AddStyleToAllGroup(numOfStyle);
	return ScriptObject(ret);
}

ScriptObject GridLayoutListBridge::m_AddColumn(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length());

	ScriptObject object = args[0];
	ARG_IS_VALID(object, "groupIndex", isNumber);
	ARG_IS_VALID(object, "styleIndex", isNumber);
	ARG_IS_VALID(object, "columnWidth", isNumber);
	
	int groupIndex = (int)object.get("groupIndex").asNumber();
	int styleIndex = (int)object.get("styleIndex").asNumber();
	float columnWidth = (float)object.get("columnWidth").asNumber();

	if (TYPE_VERTICAL == self->ScrollDirection())
	{
		columnWidth *= t_ScaleRatioHeight();
	}
	else
	{
		columnWidth *= t_ScaleRatioWidth();
	}

	return ScriptObject(self->AddColumn(groupIndex, styleIndex, columnWidth));
}

ScriptObject GridLayoutListBridge::m_AddRowToColumn(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length());

	ScriptObject object = args[0];
	ARG_IS_VALID(object, "groupIndex", isNumber);
	ARG_IS_VALID(object, "styleIndex", isNumber);
	ARG_IS_VALID(object, "columnIndex", isNumber);
	ARG_IS_VALID(object, "rowHeight", isNumber);

	int groupIndex = (int)object.get("groupIndex").asNumber();
	int styleIndex = (int)object.get("styleIndex").asNumber();
	int columnIndex = (int)object.get("columnIndex").asNumber();
	float rowHeight = (float)object.get("rowHeight").asNumber();

	if (TYPE_VERTICAL == self->ScrollDirection())
	{
		rowHeight *= t_ScaleRatioWidth();
	}
	else
	{
		rowHeight *= t_ScaleRatioHeight();
	}

	return ScriptObject(self->AddRowToColumn(groupIndex, styleIndex, columnIndex, rowHeight));
}

ScriptObject GridLayoutListBridge::m_AddRowToAllColumn(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length());

	ScriptObject object = args[0];
	ARG_IS_VALID(object, "groupIndex", isNumber);
	ARG_IS_VALID(object, "styleIndex", isNumber);
	ARG_IS_VALID(object, "rowHeight", isNumber);

	int groupIndex = (int)object.get("groupIndex").asNumber();
	int styleIndex = (int)object.get("styleIndex").asNumber();
	float rowHeight = (float)object.get("rowHeight").asNumber();

	if (TYPE_VERTICAL == self->ScrollDirection())
	{
		rowHeight *= t_ScaleRatioWidth();
	}
	else
	{
		rowHeight *= t_ScaleRatioHeight();
	}

	return ScriptObject(self->AddRowToAllColumn(groupIndex, styleIndex, rowHeight));
}

ScriptObject GridLayoutListBridge::m_MergeCells(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length());

	ScriptObject object = args[0];
	ARG_IS_VALID(object, "groupIndex", isNumber);
	ARG_IS_VALID(object, "styleIndex", isNumber);
	ARG_IS_VALID(object, "startRow", isNumber);
	ARG_IS_VALID(object, "startCol", isNumber);
	ARG_IS_VALID(object, "endRow", isNumber);
	ARG_IS_VALID(object, "endCol", isNumber);

	int groupIndex = (int)object.get("groupIndex").asNumber();
	int styleIndex = (int)object.get("styleIndex").asNumber();
	int startRow = (int)object.get("startRow").asNumber();
	int startCol = (int)object.get("startCol").asNumber();
	int endRow = (int)object.get("endRow").asNumber();
	int endCol = (int)object.get("endCol").asNumber();

	return ScriptObject(self->MergeCells(groupIndex, styleIndex, startRow, startCol, endRow, endCol));
}

ScriptObject GridLayoutListBridge::m_SetStyle(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length() && true == args[0].isNumber());

	int styleIndex = (int)args[0].asNumber();
	return ScriptObject(self->SetStyle(styleIndex));
}

ScriptObject GridLayoutListBridge::m_TransformStyle(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length() && true == args[0].isNumber()) ;

	int styleIndex = (int)args[0].asNumber();

	self->TransformStyle(styleIndex);

	return ScriptObject();
}

ScriptObject GridLayoutListBridge::m_EnlargeFocusItem(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(2 == args.Length() && true == args[0].isNumber() && true == args[1].isNumber());

	float enlargeWidth = (float)args[0].asNumber();
	float enlargeHeight = (float)args[1].asNumber();

	enlargeWidth *= t_ScaleRatioWidth();
	enlargeHeight *= t_ScaleRatioHeight();

	self->EnlargeFocusedItem(enlargeWidth, enlargeHeight);
	return ScriptObject();
}

ScriptObject GridLayoutListBridge::m_SetFocusItemIndex(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(2 == args.Length() && true == args[0].isNumber() && true == args[1].isNumber());

	int groupIndex = (int)args[0].asNumber();
	int itemIndex = (int)args[1].asNumber();

	self->SetFocusItemIndex(groupIndex, itemIndex);

	return ScriptObject();
}

ScriptObject GridLayoutListBridge::m_GetFocusItemIndex(CGridListControl* self, const ScriptArray& args)
{
	int groupIndex, itemIndex;
	self->GetFocusItemIndex(groupIndex, itemIndex);

	ScriptObject focusItem;
	focusItem.set("groupIndex", ScriptObject(groupIndex));
	focusItem.set("itemIndex", ScriptObject(itemIndex));

	return focusItem;
}

ScriptObject GridLayoutListBridge::m_SetAnimationDuration(CGridListControl* self, const ScriptArray& args)
{
	int duration = 0;

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber())
		{
			duration = (int)args[0].asNumber();
		}
	}

	self->SetAnimationDuration(IGridListControl::ANITYPE_FOCUS_MOVE, duration);
	self->SetAnimationMode(IGridListControl::ANITYPE_FOCUS_MOVE, CLUTTER_EASE_IN_OUT);

	return ScriptObject();
}

ScriptObject GridLayoutListBridge::m_AttachGroupTitle(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(2 == args.Length() && true == args[0].isNumber());

	if (NULL == unwrapNativeObject<Widget>(args[1]))
	{
		CText *title = unwrapNativeObject<CText>(args[1]);
		self->AttachGroupTitle((int)args[0].asNumber(), dynamic_cast<IText*>(title));
	}
	else
	{
		Widget *title = unwrapNativeObject<Widget>(args[1]);
		ASSERT(NULL != title);

		self->AttachGroupTitle((int)args[0].asNumber(), title);
	}

	return ScriptObject();
}

ScriptObject GridLayoutListBridge::m_AddListListener(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length());

	InternalGridListener *listener = unwrapNativeObject<InternalGridListener>(args[0]);
	self->AddListListener(listener);

	return ScriptObject();
}

ScriptObject GridLayoutListBridge::m_AddDataGroup(CGridListControl* self, const ScriptArray& args)
{
	IGridDataSource* dataSource= self->DataSource();
	
	if (args.Length() > 0)
	{
		int groupIndex = -1;
		if(args.has(0) && args[0].isNumber())
		{
			groupIndex = (int)args[0].asNumber();
		}

		dataSource->AddGroup(groupIndex);
	}

	return ScriptObject();
}

ScriptObject GridLayoutListBridge::m_AddData(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length());

	ScriptObject object = args[0];
	ARG_IS_VALID(object, "groupIndex", isNumber);
	ARG_HAS_STRING(object, "data");

	IGridDataSource* dataSource = self->DataSource();
	
	int groupIndex = (int)object.get("groupIndex").asNumber();

	IData* data = unwrapNativeObject<IData>(object.get("data"));
	ASSERT(NULL != data);
		
	dataSource->AddData(groupIndex, data);
	if (object.has("needUpdate") && object.get("needUpdate").asBool() == true)
	{
		self->LoadData();
		//self->UpdateItem(groupIndex, dataSource->NumOfData(groupIndex) - 1);
	}

	return ScriptObject();
}

ScriptObject GridLayoutListBridge::m_GetData(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(2 == args.Length() && true == args[0].isNumber() && true == args[1].isNumber());

	int groupIndex = (int)args[0].asNumber();
	int itemIndex = (int)args[1].asNumber();

	return wrapExistingNativeObject(self->DataSource()->GetData(groupIndex, itemIndex));
}

ScriptObject GridLayoutListBridge::columnCount(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(2 == args.Length() && args[0].isNumber() && args[1].isNumber());

	int groupIndex = (int)args[0].asNumber();
	int styleIndex = (int)args[1].asNumber();

	return ScriptObject(self->ColumnCount(groupIndex, styleIndex));
}

Bridge::ScriptObject Bridge::GridLayoutListBridge::updateItem(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(2 == args.Length() && true == args[0].isNumber() && true == args[1].isNumber());

	int groupIndex = (int)args[0].asNumber();
	int itemIndex = (int)args[1].asNumber();

	self->UpdateItem(groupIndex, itemIndex);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::GridLayoutListBridge::updateAllItems(CGridListControl* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		ASSERT(1 == args.Length() && true == args[0].isNumber());
		int groupIndex = (int)args[0].asNumber();

		self->UpdateAllItems(groupIndex);
	}
	else
	{
		for (int i = 0; i < self->GroupCount(); i++)
		{
			self->UpdateAllItems(i);
		}	
	}
		
	return ScriptObject();
}

Bridge::ScriptObject Bridge::GridLayoutListBridge::clearDataSource(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length() && true == args[0].isNumber());

	int groupIndex = (int)args[0].asNumber();
	self->ClearDataSource(groupIndex);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::GridLayoutListBridge::addRegularGrid(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length());

	ScriptObject object = args[0];
	ARG_IS_VALID(object, "groupIndex", isNumber);
	ARG_IS_VALID(object, "styleIndex", isNumber);
	ARG_IS_VALID(object, "columnNumber", isNumber);
	ARG_IS_VALID(object, "rowNumber", isNumber);
	ARG_IS_VALID(object, "columnWidth", isNumber);
	ARG_IS_VALID(object, "rowHeight", isNumber);

	int groupIndex = (int)object.get("groupIndex").asNumber();
	int styleIndex = (int)object.get("styleIndex").asNumber();
	int columnNum = (int)object.get("columnNumber").asNumber();
	int rowNum = (int)object.get("rowNumber").asNumber();
	float columnWidth = (float)object.get("columnWidth").asNumber();
	float rowHeight = (float)object.get("rowHeight").asNumber();

	if (TYPE_VERTICAL == self->ScrollDirection())
	{
		columnWidth *= t_ScaleRatioHeight();
		rowHeight *= t_ScaleRatioWidth();
	} 
	else
	{
		columnWidth *= t_ScaleRatioWidth();
		rowHeight *= t_ScaleRatioHeight();
	}
	
	for (int i = 0; i < columnNum; i++)
	{
		self->AddColumn(groupIndex, styleIndex, columnWidth);
		for (int j = 0; j < rowNum; j++)
		{
			self->AddRowToColumn(groupIndex, styleIndex, i, rowHeight);
		}
	}

	return ScriptObject();
}

Bridge::ScriptObject Bridge::GridLayoutListBridge::setBufferColumnSize(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length());

	ScriptObject object = args[0];
	ARG_IS_VALID(object, "left", isNumber);
	ARG_IS_VALID(object, "right", isNumber);

	int leftSize = (int)object.get("left").asNumber();
	int rightSize = (int)object.get("right").asNumber();

	self->SetBufferColumnSize(leftSize, rightSize);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::GridLayoutListBridge::renderer(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(2 == args.Length() && true == args[0].isNumber() && true == args[1].isNumber());

	int groupIndex = (int)args[0].asNumber();
	int itemIndex = (int)args[1].asNumber();

	IRenderer* renderer = self->Renderer(groupIndex, itemIndex);

	return ActorBridge::wrapNativeObjectToJS(renderer);
}

Bridge::ScriptObject Bridge::GridLayoutListBridge::getOnScreenRange(CGridListControl* self, const ScriptArray& args)
{
	int startGroupIndex = 0, startItemIndex = 0, endGroupIndex = 0, endItemIndex = 0;
	self->GetOnScreenRange(startGroupIndex, startItemIndex, endGroupIndex, endItemIndex);

	ScriptObject onScreenRange;
	onScreenRange.set("startGroupIndex", ScriptObject(startGroupIndex));
	onScreenRange.set("startItemIndex", ScriptObject(startItemIndex));
	onScreenRange.set("endGroupIndex", ScriptObject(endGroupIndex));
	onScreenRange.set("endItemIndex", ScriptObject(endItemIndex));

	return onScreenRange;
}

Bridge::ScriptObject Bridge::GridLayoutListBridge::itemCount(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length() && args[0].isNumber() );

	int groupIndex = (int)args[0].asNumber();

	return ScriptObject(self->ItemCount(groupIndex));
}

Bridge::ScriptObject Bridge::GridLayoutListBridge::enableItem(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(3 == args.Length() && true == args[0].isNumber() && true == args[1].isNumber() && true == args[2].isBool());

	int groupIndex = (int)args[0].asNumber();
	int itemIndex = (int)args[1].asNumber();
	bool enableFlag = args[2].asBool();

	self->EnableItem(groupIndex, itemIndex, enableFlag);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::GridLayoutListBridge::isItemEnabled(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(2 == args.Length() && true == args[0].isNumber() && true == args[1].isNumber());

	int groupIndex = (int)args[0].asNumber();
	int itemIndex = (int)args[1].asNumber();

	return ScriptObject(self->IsItemEnabled(groupIndex, itemIndex));
}

Bridge::ScriptObject Bridge::GridLayoutListBridge::m_InsertData(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length());

	ScriptObject object = args[0];
	ARG_IS_VALID(object, "groupIndex", isNumber);
	ARG_IS_VALID(object, "itemIndex", isNumber);
	ARG_HAS_STRING(object, "data");

	IGridDataSource* dataSource = self->DataSource();

	int groupIndex = (int)object.get("groupIndex").asNumber();
	int itemIndex = (int)object.get("itemIndex").asNumber();
	IData* data = unwrapNativeObject<IData>(object.get("data"));
	ASSERT(NULL != data);

	dataSource->InsertData(data, groupIndex, itemIndex);

	if (object.has("needUpdate") && object.get("needUpdate").asBool() == true)
	{
		self->LoadData();
		for (int i = itemIndex; i < dataSource->NumOfData(groupIndex); i++)
		{
			if (i < self->ItemCount(groupIndex))
			{
				self->UpdateItem(groupIndex, i);
			}
		}
	}

	return ScriptObject();
}

Bridge::ScriptObject Bridge::GridLayoutListBridge::m_RemoveData(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(1 == args.Length());

	ScriptObject object = args[0];
	ARG_IS_VALID(object, "groupIndex", isNumber);
	ARG_IS_VALID(object, "fromItemIndex", isNumber);
	ARG_IS_VALID(object, "toItemIndex", isNumber);

	IGridDataSource* dataSource = self->DataSource();

	int groupIndex = (int)object.get("groupIndex").asNumber();
	int from = 0, to = 0;
	from = (int)object.get("fromItemIndex").asNumber();
	to = (int)object.get("toItemIndex").asNumber();

	for (int i = from; i <= to; i++)
	{
		dataSource->DeleteData(groupIndex, from);
	}

	if (object.has("needUpdate") && object.get("needUpdate").asBool() == true)
	{
		self->LoadData();
		for (int i = from; i < dataSource->NumOfData(groupIndex); i++)
		{
			if (i < self->ItemCount(groupIndex))
			{
				self->UpdateItem(groupIndex, i);
			}
		}
	}

	return ScriptObject();
}

Bridge::ScriptObject Bridge::GridLayoutListBridge::m_StartScrollPlayer(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(self != NULL);
	self->StartScrollTimer();

	return ScriptObject();
}

Bridge::ScriptObject Bridge::GridLayoutListBridge::m_StopScrollPlayer(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(self != NULL);
	self->StopScrollTimer();

	return ScriptObject();
}



ScriptObject GridLayoutListBridge::m_IsThumbStyleOfItemEnable(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(NULL != self);
	ASSERT(1 == args.Length());

	ScriptObject object = args[0];
	ARG_IS_VALID(object, "groupIndex", isNumber);
	ARG_IS_VALID(object, "itemIndex", isNumber);
	ARG_IS_VALID(object, "style", isNumber);

	int groupIndex = (int)object.get("groupIndex").asNumber();
	int itemIndex = (int)object.get("itemIndex").asNumber();
	int style = (int)object.get("style").asNumber();

	bool ret = self->IsThumbnailStyleEnabled(groupIndex, itemIndex, IThumbnail::EThumbnailStyle(style));
	return ScriptObject(ret);
}

ScriptObject GridLayoutListBridge::m_GetThumbnailStyle(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(NULL != self);
	ASSERT(1 == args.Length());

	ScriptObject object = args[0];
	ARG_IS_VALID(object, "groupIndex", isNumber);
	ARG_IS_VALID(object, "itemIndex", isNumber);

	int groupIndex = (int)object.get("groupIndex").asNumber();
	int itemIndex = (int)object.get("itemIndex").asNumber();

	return ScriptObject(self->GetThumbnailStyleOfItem(groupIndex, itemIndex));
}

ScriptObject GridLayoutListBridge::m_SetCheckToThumbnailOfGroup(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(NULL != self);
	ASSERT(1 == args.Length());

	ScriptObject object = args[0];
	ARG_IS_VALID(object, "groupIndex", isNumber);
	ARG_IS_VALID(object, "isChecked", isBool);

	int groupIndex = (int)object.get("groupIndex").asNumber();
	bool isChecked = object.get("isChecked").asBool();

	self->SetCheckToThumbnailOfGroup(groupIndex, isChecked);
	return ScriptObject();
}

ScriptObject GridLayoutListBridge::m_SetCheckToThumbnailOfItem(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(NULL != self);
	ASSERT(1 == args.Length());

	ScriptObject object = args[0];
	ARG_IS_VALID(object, "groupIndex", isNumber);
	ARG_IS_VALID(object, "itemIndex", isNumber);
	ARG_IS_VALID(object, "isChecked", isBool);

	int groupIndex = (int)object.get("groupIndex").asNumber();
	int itemIndex = (int)object.get("itemIndex").asNumber();
	bool isChecked = object.get("isChecked").asBool();

	self->SetCheckToThumbnailOfItem(groupIndex, itemIndex, isChecked);
	return ScriptObject();
}

ScriptObject GridLayoutListBridge::m_EnableThumbnailStyleOfGroup(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(NULL != self);
	ASSERT(1 == args.Length());

	ScriptObject object = args[0];
	ARG_IS_VALID(object, "groupIndex", isNumber);
	ARG_IS_VALID(object, "thumbStyle", isNumber);
	ARG_IS_VALID(object, "enable", isBool);
	ARG_IS_VALID(object, "withAni", isBool);

	int groupIndex = (int)object.get("groupIndex").asNumber();
	IThumbnail::EThumbnailStyle style = (IThumbnail::EThumbnailStyle)((int)object.get("thumbStyle").asNumber());
	bool enable = object.get("enable").asBool();
	bool flagAni = object.get("withAni").asBool();

	self->EnableThumbnailStyleOfGroup(groupIndex, style, enable, flagAni);
	return ScriptObject();
}

ScriptObject GridLayoutListBridge::m_EnableThumbnailStyleOfItem(CGridListControl* self, const ScriptArray& args)
{
	ASSERT(NULL != self);
	ASSERT(1 == args.Length());

	ScriptObject object = args[0];
	ARG_IS_VALID(object, "groupIndex", isNumber);
	ARG_IS_VALID(object, "itemIndex", isNumber);
	ARG_IS_VALID(object, "thumbStyle", isNumber);
	ARG_IS_VALID(object, "enable", isBool);
	ARG_IS_VALID(object, "withAni", isBool);

	int groupIndex = (int)object.get("groupIndex").asNumber();
	int itemIndex =  (int)object.get("itemIndex").asNumber();

	IThumbnail::EThumbnailStyle style = (IThumbnail::EThumbnailStyle)((int)object.get("thumbStyle").asNumber());

	bool enable = object.get("enable").asBool();
	bool flagAni = object.get("withAni").asBool();

	self->EnableThumbnailStyleOfItem(groupIndex, itemIndex, style, enable, flagAni);
	return ScriptObject();
}





