#include "HaloBridgeAll.h"

using namespace HALO;
using namespace Bridge;

void PopupRatingListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	context.bindFunction<InternalPopupRatingListener, &InternalPopupRatingListener::GetButtonEventCallBack, &InternalPopupRatingListener::SetButtonEventCallBack>("OnButtonEvent");	
	context.bindFunction<InternalPopupRatingListener, &InternalPopupRatingListener::GetStarIconEventCallBack, &InternalPopupRatingListener::SetStarIconEventCallBack>("OnStarIconEvent");	
	context.bindFunction<InternalPopupRatingListener, &InternalPopupRatingListener::GetTimeOutCallBack, &InternalPopupRatingListener::SetTimeOutCallBack>("OnTimeOut");
}

void* PopupRatingListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalPopupRatingListener;
}

std::string InternalPopupRatingListener::deserializeState(IPopupRatingListener::EEventTypes eventType)
{
	if ( IPopupRatingListener::BUTTON_FOCUS_IN == eventType)
	{
		return "button_focus_in";
	}
	else if (IPopupRatingListener::BUTTON_FOCUS_OUT == eventType)
	{
		return "button_focus_out";
	}
	else if (IPopupRatingListener::BUTTON_CLICKED == eventType)
	{
		return "button_clicked";
	}
	else
	{
		return "";
	}
}

std::string InternalPopupRatingListener::deserializeButtonState(IPopupRating::EPopupRatingButtons buttonType)
{
	if (IPopupRating::BUTTON_1 == buttonType)
	{
		return "button_1";
	}
	else if (IPopupRating::BUTTON_2 == buttonType)
	{
		return "button_2";
	}
	else if (IPopupRating::BUTTON_ALL == buttonType)
	{
		return "button_all";
	}
	else
	{
		return "";
	}
}

bool InternalPopupRatingListener::OnButtonEvent(class IPopupRating* popupRating, const int nButtonIndex, IPopupRatingListener::EEventTypes eventType)
{
	if (true == ButtonEventCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CPopupRating*>(popupRating)));
		args.set(1, ScriptObject(deserializeButtonState(nButtonIndex)));
		args.set(2, ScriptObject(deserializeState(eventType)));
		ButtonEventCb.function.invoke(args);
	}
	return true;
}

bool InternalPopupRatingListener::OnStarIconEvent(class IPopupRating* popupRating, IPopupRatingListener::EEventTypes eventType)
{
	if (true == StarIconEventCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CPopupRating*>(popupRating)));
		args.set(1, ScriptObject(deserializeState(eventType)));
		StarIconEventCb.function.invoke(args);
	}
	return true;
}

bool InternalPopupRatingListener::OnTimeOut(class IPopupRating* popupRating)
{
	if (true == TimeOutCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CPopupRating*>(popupRating)));
		TimeOutCb.function.invoke(args);
	}
	return true;
}

//PopupRatingBridge
void PopupRatingBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.captureMethodCall<CPopupRating, &setBGColor>("setBGColor");
	context.captureMethodCall<CPopupRating, &setTitleRect>("setTitleRect");
	context.captureMethodCall<CPopupRating, &setTitleTextColor>("setTitleTextColor");
	context.captureMethodCall<CPopupRating, &setTitleLineRect>("setTitleLineRect");
	context.captureMethodCall<CPopupRating, &setTitleLineColor>("setTitleLineColor");
	context.captureMethodCall<CPopupRating, &setTitleTextAlignment>("setTitleTextAlignment");
	context.captureMethodCall<CPopupRating, &setContentRect>("setContentRect");
	context.captureMethodCall<CPopupRating, &setContentTextColor>("setContentTextColor");
	context.captureMethodCall<CPopupRating, &setContentTextAlignment>("setContentTextAlignment");
	context.captureMethodCall<CPopupRating, &setStarIconRect>("setStarIconRect");
	context.captureMethodCall<CPopupRating, &setStarIconsBGRect>("setStarIconsBGRect");
	context.captureMethodCall<CPopupRating, &setStarIconsBGColor>("setStarIconsBGColor");
	context.captureMethodCall<CPopupRating, &setArrowButtonRect>("setArrowButtonRect");
	context.captureMethodCall<CPopupRating, &setArrowButtonImage>("setArrowButtonImage");
	context.captureMethodCall<CPopupRating, &setButtonRect>("setButtonRect");
	context.captureMethodCall<CPopupRating, &setButtonImage>("setButtonImage");
	context.captureMethodCall<CPopupRating, &setButtonBackgroundColor>("setButtonBackgroundColor");
	context.captureMethodCall<CPopupRating, &setButtonText>("setButtonText");
	context.captureMethodCall<CPopupRating, &setButtonTextColor>("setButtonTextColor");
	context.captureMethodCall<CPopupRating, &setButtonTextFontSize>("setButtonTextFontSize");
	context.captureMethodCall<CPopupRating, &setButtonBorderColor>("setButtonBorderColor");
	context.captureMethodCall<CPopupRating, &setButtonBorderWidth>("setButtonBorderWidth");
	context.captureMethodCall<CPopupRating, &addListener>("addListener");
	context.captureMethodCall<CPopupRating, &removeListener>("removeListener");

	// TODO: do not use these Apis, they will be deprecated later
	context.captureMethodCall<CPopupRating, &setTitleText>("setTitleText");
	context.captureMethodCall<CPopupRating, &setTitleTextFont>("setTitleTextFont");
	context.captureMethodCall<CPopupRating, &setContentText>("setContentText");
	context.captureMethodCall<CPopupRating, &setContentTextFont>("setContentTextFont");
	context.captureMethodCall<CPopupRating, &setStarIconUnmarkedImage>("setStarIconUnmarkedImage");
	context.captureMethodCall<CPopupRating, &setStarIconMarkedImage>("setStarIconMarkedImage");
	context.captureMethodCall<CPopupRating, &setDefaultFocus>("setDefaultFocus");
	context.captureMethodCall<CPopupRating, &defaultFocus>("defaultFocus");
	context.captureMethodCall<CPopupRating, &setMarkedStarIconNumber>("setMarkedStarIconNumber");
	context.captureMethodCall<CPopupRating, &markedStarIconNumber>("markedStarIconNumber");
	context.captureMethodCall<CPopupRating, &supportTTS>("supportTTS");	
	/////////////////

	context.bindString<CPopupRating, &CPopupRating::TitleText, &CPopupRating::SetTitleText>("titleText");
	context.bindString<CPopupRating, &CPopupRating::TitleTextFont, &CPopupRating::SetTitleTextFont>("titleTextFont");
	context.bindString<CPopupRating, &CPopupRating::ContentText, &CPopupRating::SetContentText>("contentText");
	context.bindString<CPopupRating, &CPopupRating::ContentTextFont, &CPopupRating::SetContentTextFont>("contentTextFont");
	context.bindString<CPopupRating, &CPopupRating::StarIconUnmarkedImage, &CPopupRating::SetStarIconUnmarkedImage>("starIconUnmarkedImagePath");
	context.bindString<CPopupRating, &CPopupRating::StarIconMarkedImage, &CPopupRating::SetStarIconMarkedImage>("starIconMarkedImagePath");
	context.bindString<CPopupRating, &CPopupRating::StarIconHalfMarkedImage, &CPopupRating::SetStarIconHalfMarkedImage>("starIconHalfMarkedImagePath");
	context.bindNumber<CPopupRating, int, &CPopupRating::DefaultFocus, &CPopupRating::SetDefaultFocus>("defaultFocusIndex");
	context.bindNumber<CPopupRating, int, &CPopupRating::MarkedStarIconNumber, &CPopupRating::SetMarkedStarIconNumber>("markedStarIconNumber");
	context.bindBoolean<CPopupRating, &CPopupRating::SupportTTS, &CPopupRating::SetSupportTTS>("supportTTSFlag");
	context.bindNumber<CPopupRating, guint, &CPopupRating::ShowTime, &CPopupRating::SetShowTime>("showTime");
}

Widget* PopupRatingBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	CPopupRating::TPopupRatingAttr attr;
	ScriptObject options;
	int argsLen = args.Length();
	if (argsLen > 0)
	{
		options = args[0];
		parsePopupRatingParams(options, attr);
	}

	CPopupRating *popupRating = dynamic_cast<CPopupRating *>(IPopupRating::CreateInstance(parent, attr));
	if (popupRating == NULL)
	{
		return NULL;
	}
	
	if (options.has("starIconUnmarkedImagePath"))
	{
		std::string StarIconUnmarkedImagePath = options.get("starIconUnmarkedImagePath").asString();
		popupRating->SetStarIconUnmarkedImage(StarIconUnmarkedImagePath);
	}
	if (options.has("starIconMarkedImagePath"))
	{
		std::string starIconMarkedImagePath = options.get("starIconMarkedImagePath").asString();
		popupRating->SetStarIconMarkedImage(starIconMarkedImagePath);
	}
	if (options.has("starIconHalfMarkedImagePath"))
	{
		std::string starIconHalfMarkedImagePath = options.get("starIconHalfMarkedImagePath").asString();
		popupRating->SetStarIconHalfMarkedImage(starIconHalfMarkedImagePath);
	}

	if(CPopupRating::BASE_LABEL_WITH_POPUP == attr.nPopupRatingType)
	{
		if (options.has("focusLeftArrowButtonImagePath"))
		{
			std::string focusLeftArrowButtonImagePath = options.get("focusLeftArrowButtonImagePath").asString();
			popupRating->SetArrowButtonImage(CPopupRating::ARROW_BUTTON_1, IButton::STATE_ALL, focusLeftArrowButtonImagePath);
		}

		if (options.has("normalLeftArrowButtonImagePath"))
		{
			std::string normalLeftArrowButtonImagePath = options.get("normalLeftArrowButtonImagePath").asString();
			popupRating->SetArrowButtonImage(CPopupRating::ARROW_BUTTON_1, IButton::STATE_NORMAL, normalLeftArrowButtonImagePath);
		}

		if (options.has("disabledLeftArrowButtonImagePath"))
		{
			std::string disabledLeftArrowButtonImagePath = options.get("disabledLeftArrowButtonImagePath").asString();
			popupRating->SetArrowButtonImage(CPopupRating::ARROW_BUTTON_1, IButton::STATE_DISABLED, disabledLeftArrowButtonImagePath);
			popupRating->SetArrowButtonImage(CPopupRating::ARROW_BUTTON_1, IButton::STATE_DISABLED_FOCUSED, disabledLeftArrowButtonImagePath);
		}

		if (options.has("focusRightArrowButtonImagePath"))
		{
			std::string focusRightArrowButtonImagePath = options.get("focusRightArrowButtonImagePath").asString();
			popupRating->SetArrowButtonImage(CPopupRating::ARROW_BUTTON_2, IButton::STATE_ALL, focusRightArrowButtonImagePath);
		}

		if (options.has("normalRightArrowButtonImagePath"))
		{
			std::string normalRightArrowButtonImagePath = options.get("normalRightArrowButtonImagePath").asString();
			popupRating->SetArrowButtonImage(CPopupRating::ARROW_BUTTON_2, IButton::STATE_NORMAL, normalRightArrowButtonImagePath);
		}

		if (options.has("disabledRightArrowButtonImagePath"))
		{
			std::string disabledRightArrowButtonImagePath = options.get("disabledRightArrowButtonImagePath").asString();
			popupRating->SetArrowButtonImage(CPopupRating::ARROW_BUTTON_2, IButton::STATE_DISABLED, disabledRightArrowButtonImagePath);
			popupRating->SetArrowButtonImage(CPopupRating::ARROW_BUTTON_2, IButton::STATE_DISABLED_FOCUSED, disabledRightArrowButtonImagePath);
		}

		if (options.has("titleTextFont"))
		{
			std::string titleTextFont = options.get("titleTextFont").asString();
			popupRating->SetTitleTextFont(titleTextFont);
		}

		if (options.has("titleText"))
		{
			std::string titleText = options.get("titleText").asString();
			popupRating->SetTitleText(titleText);
		}

		if (options.has("contentTextFont"))
		{
			std::string contentTextFont = options.get("contentTextFont").asString();
			popupRating->SetContentTextFont(contentTextFont);
		}

		if (options.has("contentText"))
		{
			std::string contentText = options.get("contentText").asString();
			popupRating->SetContentText(contentText);
		}

		if (options.has("button_1_Text"))
		{
			std::string button_1_Text = options.get("button_1_Text").asString();
			popupRating->SetButtonText(CPopupRating::BUTTON_1, IButton::STATE_ALL, button_1_Text);
		}

		if (options.has("button_2_Text"))
		{
			std::string button_2_Text = options.get("button_2_Text").asString();
			popupRating->SetButtonText(CPopupRating::BUTTON_2, IButton::STATE_ALL, button_2_Text);
		}

		if (options.has("normalButtonImagePath"))
		{
			std::string normalButtonImagePath = options.get("normalButtonImagePath").asString();
			popupRating->SetButtonImage(CPopupRating::BUTTON_ALL, IButton::STATE_ALL, normalButtonImagePath);
		}

		if (options.has("focusButtonImagePath"))
		{
			std::string focusButtonImagePath = options.get("focusButtonImagePath").asString();
			popupRating->SetButtonImage(CPopupRating::BUTTON_ALL, IButton::STATE_FOCUSED, focusButtonImagePath);
			popupRating->SetButtonImage(CPopupRating::BUTTON_ALL, IButton::STATE_ROLL_OVER, focusButtonImagePath);
			popupRating->SetButtonImage(CPopupRating::BUTTON_ALL, IButton::STATE_SELECTED, focusButtonImagePath);
			popupRating->SetButtonImage(CPopupRating::BUTTON_ALL, IButton::STATE_FOCUSED_ROLL_OVER, focusButtonImagePath);
		}

		if (options.has("buttonTextNormalSize"))
		{
			int buttonTextNormalSize = (int)options.get("buttonTextNormalSize").asNumber();
			popupRating->SetButtonTextFontSize(CPopupRating::BUTTON_ALL, IButton::STATE_ALL, buttonTextNormalSize); 
		}

		if (options.has("buttonTextFocusSize"))
		{
			int buttonTextFocusSize = (int)options.get("buttonTextFocusSize").asNumber();
			popupRating->SetButtonTextFontSize(CPopupRating::BUTTON_ALL, IButton::STATE_FOCUSED, buttonTextFocusSize);
			popupRating->SetButtonTextFontSize(CPopupRating::BUTTON_ALL, IButton::STATE_ROLL_OVER, buttonTextFocusSize); 
			popupRating->SetButtonTextFontSize(CPopupRating::BUTTON_ALL, IButton::STATE_SELECTED, buttonTextFocusSize); 
			popupRating->SetButtonTextFontSize(CPopupRating::BUTTON_ALL, IButton::STATE_FOCUSED_ROLL_OVER, buttonTextFocusSize); 
		}

		if (options.has("buttonNormalBorderColor"))
		{
			ScriptObject buttonNormalBorderColor = options.get("buttonNormalBorderColor");
			guint8 r = 0, g = 0, b = 0, a = 0;
			if (buttonNormalBorderColor.has("r")) { r = (guint8)buttonNormalBorderColor.get("r").asNumber(); }
			if (buttonNormalBorderColor.has("g")) { g = (guint8)buttonNormalBorderColor.get("g").asNumber(); }
			if (buttonNormalBorderColor.has("b")) { b = (guint8)buttonNormalBorderColor.get("b").asNumber(); }
			if (buttonNormalBorderColor.has("a")) { a = (guint8)buttonNormalBorderColor.get("a").asNumber(); }
			ClutterColor borderNormalColor = {r, g, b, a};
			popupRating->SetButtonBorderColor(CPopupRating::BUTTON_ALL, IButton::STATE_ALL, borderNormalColor); 
		}

		if (options.has("buttonFocusedBorderColor"))
		{
			ScriptObject buttonFocusedBorderColor = options.get("buttonFocusedBorderColor");
			guint8 r = 0, g = 0, b = 0, a = 0;
			if (buttonFocusedBorderColor.has("r")) { r = (guint8)buttonFocusedBorderColor.get("r").asNumber(); }
			if (buttonFocusedBorderColor.has("g")) { g = (guint8)buttonFocusedBorderColor.get("g").asNumber(); }
			if (buttonFocusedBorderColor.has("b")) { b = (guint8)buttonFocusedBorderColor.get("b").asNumber(); }
			if (buttonFocusedBorderColor.has("a")) { a = (guint8)buttonFocusedBorderColor.get("a").asNumber(); }
			ClutterColor borderFocusedColor = {r, g, b, a};
			popupRating->SetButtonBorderColor(CPopupRating::BUTTON_ALL, IButton::STATE_FOCUSED, borderFocusedColor); 
			popupRating->SetButtonBorderColor(CPopupRating::BUTTON_ALL, IButton::STATE_ROLL_OVER, borderFocusedColor); 
			popupRating->SetButtonBorderColor(CPopupRating::BUTTON_ALL, IButton::STATE_SELECTED, borderFocusedColor); 
			popupRating->SetButtonBorderColor(CPopupRating::BUTTON_ALL, IButton::STATE_FOCUSED_ROLL_OVER, borderFocusedColor); 
		}

		if (options.has("buttonNormalBorderWidth"))
		{
			float buttonNormalBorderWidth = (float)options.get("buttonNormalBorderWidth").asNumber();
			popupRating->SetButtonBorderWidth(CPopupRating::BUTTON_ALL, IButton::STATE_ALL, buttonNormalBorderWidth); 
		}

		if (options.has("buttonFocusedBorderWidth"))
		{
			float buttonFocusedBorderWidth = (float)options.get("buttonFocusedBorderWidth").asNumber();
			popupRating->SetButtonBorderWidth(CPopupRating::BUTTON_ALL, IButton::STATE_FOCUSED, buttonFocusedBorderWidth);
			popupRating->SetButtonBorderWidth(CPopupRating::BUTTON_ALL, IButton::STATE_ROLL_OVER, buttonFocusedBorderWidth); 
			popupRating->SetButtonBorderWidth(CPopupRating::BUTTON_ALL, IButton::STATE_SELECTED, buttonFocusedBorderWidth); 
			popupRating->SetButtonBorderWidth(CPopupRating::BUTTON_ALL, IButton::STATE_FOCUSED_ROLL_OVER, buttonFocusedBorderWidth); 
		}
	}

	return dynamic_cast<CPopupRating*>(popupRating);
}

Bridge::ScriptObject PopupRatingBridge::setBGColor(CPopupRating* self, const ScriptArray &args)
{
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {r = (guint8)args[0].asNumber();}
		if (args.has(1) && args[1].isNumber()) {g = (guint8)args[1].asNumber();}
		if (args.has(2) && args[2].isNumber()) {b = (guint8)args[2].asNumber();}
		if (args.has(3) && args[3].isNumber()) {a = (guint8)args[3].asNumber();}
	}
	ClutterColor c = {r, g, b, a};
	if (self != NULL)
	{
		self->SetBGColor(c);
	}
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setTitleRect(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	float x = 0.0;
	float y = 0.0;
	float width = 1920;
	float height = 1080;
	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {x = static_cast<float>(args[0].asNumber());}
		if (args.has(1) && args[1].isNumber()) {y = static_cast<float>(args[1].asNumber());}
		if (args.has(2) && args[2].isNumber()) {width = static_cast<float>(args[2].asNumber());}
		if (args.has(3) && args[3].isNumber()) {height = static_cast<float>(args[3].asNumber());}
	}
	self->SetTitleRect(x, y, width, height);
	
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setTitleText(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	std::string titleText = "";
	if (args.has(0) && args[0].isString()) {titleText = args[0].asString();}
	self->SetTitleText(titleText);
	
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setTitleTextColor(CPopupRating* self, const ScriptArray &args)
{
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {r = (guint8)args[0].asNumber();}
		if (args.has(1) && args[1].isNumber()) {g = (guint8)args[1].asNumber();}
		if (args.has(2) && args[2].isNumber()) {b = (guint8)args[2].asNumber();}
		if (args.has(3) && args[3].isNumber()) {a = (guint8)args[3].asNumber();}
	}
	ClutterColor c = {r, g, b, a};
	if (self != NULL)
	{
		self->SetTitleTextColor(c);
	}
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setTitleTextFont(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	std::string titleFont = "";
	if (args.has(0) && args[0].isString()) {titleFont = args[0].asString();}
	self->SetTitleTextFont(titleFont);
	
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setTitleTextAlignment(CPopupRating* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);

	int h = 0; 
	int v = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString()) {h = deserializeAlignment(args[0].asString());}
		if (args.has(1) && args[1].isString()) {v = deserializeAlignment(args[1].asString());}
	}
	if (self != NULL)
	{
		self->SetTitleTextAlignment((EHAlignment)h, (EVAlignment)v);
	}
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setTitleLineRect(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	float x = 0.0;
	float y = 0.0;
	float width = 1920;
	float height = 1080;
	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {x = static_cast<float>(args[0].asNumber());}
		if (args.has(1) && args[1].isNumber()) {y = static_cast<float>(args[1].asNumber());}
		if (args.has(2) && args[2].isNumber()) {width = static_cast<float>(args[2].asNumber());}
		if (args.has(3) && args[3].isNumber()) {height = static_cast<float>(args[3].asNumber());}
	}
	self->SetTitleLineRect(x, y, width, height);
	
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setTitleLineColor(CPopupRating* self, const ScriptArray &args)
{
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {r = (guint8)args[0].asNumber();}
		if (args.has(1) && args[1].isNumber()) {g = (guint8)args[1].asNumber();}
		if (args.has(2) && args[2].isNumber()) {b = (guint8)args[2].asNumber();}
		if (args.has(3) && args[3].isNumber()) {a = (guint8)args[3].asNumber();}
	}
	ClutterColor c = {r, g, b, a};
	if (self != NULL)
	{
		self->SetTitleLineColor(c);
	}
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setContentRect(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);
	HALO_ASSERT(4 == args.Length());

	float x = 0.0;
	float y = 0.0;
	float width = 0;
	float height = 0;
	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {x = static_cast<float>(args[0].asNumber());}
		if (args.has(1) && args[1].isNumber()) {y = static_cast<float>(args[1].asNumber());}
		if (args.has(2) && args[2].isNumber()) {width = static_cast<float>(args[2].asNumber());}
		if (args.has(3) && args[3].isNumber()) {height = static_cast<float>(args[3].asNumber());}
	}
	self->SetContentRect(x, y, width, height);

	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setContentText(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	std::string contentText = "";
	if (args.has(0) && args[0].isString()) {contentText = args[0].asString();}
	self->SetContentText(contentText);
	
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setContentTextColor(CPopupRating* self, const ScriptArray &args)
{
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {r = (guint8)args[0].asNumber();}
		if (args.has(1) && args[1].isNumber()) {g = (guint8)args[1].asNumber();}
		if (args.has(2) && args[2].isNumber()) {b = (guint8)args[2].asNumber();}
		if (args.has(3) && args[3].isNumber()) {a = (guint8)args[3].asNumber();}
	}
	ClutterColor c = {r, g, b, a};
	if (self != NULL)
	{
		self->SetContentTextColor(c);
	}
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setContentTextFont(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	std::string contentTextFont = "";
	if (args.has(0) && args[0].isString()) {contentTextFont = args[0].asString();}
	self->SetContentTextFont(contentTextFont);
	
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setContentTextAlignment(CPopupRating* self, const ScriptArray& args)
{
	int h = 0; 
	int v = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString()) {h = deserializeAlignment(args[0].asString());}
		if (args.has(1) && args[1].isString()) {v = deserializeAlignment(args[1].asString());}
	}
	if (self != NULL)
	{
		self->SetContentTextAlignment((EHAlignment)h, (EVAlignment)v);
	}
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setStarIconRect(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	CPopupRating::EPopupRatingStarIcons buttonType = CPopupRating::STAR_ICON_ALL;
	if(args.has(0) && args[0].isString()) { buttonType = deserializeStarIconState(args[0].asString(), CPopupRating::STAR_ICON_ALL); }
	float x = 0.0;
	float y = 0.0;
	float width = 0;
	float height = 0;
	if(args.Length() > 0)
	{
		if (args.has(1) && args[1].isNumber()) {x = static_cast<float>(args[1].asNumber());}
		if (args.has(2) && args[2].isNumber()) {y = static_cast<float>(args[2].asNumber());}
		if (args.has(3) && args[3].isNumber()) {width = static_cast<float>(args[3].asNumber());}
		if (args.has(4) && args[4].isNumber()) {height = static_cast<float>(args[4].asNumber());}
	}
	self->SetStarIconRect(buttonType, x, y, width, height);

	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setStarIconsBGRect(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	float x = 0.0;
	float y = 0.0;
	float width = 0;
	float height = 0;
	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {x = static_cast<float>(args[0].asNumber());}
		if (args.has(1) && args[1].isNumber()) {y = static_cast<float>(args[1].asNumber());}
		if (args.has(2) && args[2].isNumber()) {width = static_cast<float>(args[2].asNumber());}
		if (args.has(3) && args[3].isNumber()) {height = static_cast<float>(args[3].asNumber());}
	}
	self->SetStarIconsBGRect( x, y, width, height);

	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setStarIconsBGColor(CPopupRating* self, const ScriptArray &args)
{
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {r = (guint8)args[0].asNumber();}
		if (args.has(1) && args[1].isNumber()) {g = (guint8)args[1].asNumber();}
		if (args.has(2) && args[2].isNumber()) {b = (guint8)args[2].asNumber();}
		if (args.has(3) && args[3].isNumber()) {a = (guint8)args[3].asNumber();}
	}
	ClutterColor c = {r, g, b, a};
	if (self != NULL)
	{
		self->SetStarIconsBGColor(c);
	}
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setStarIconUnmarkedImage(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	if (args.Length() > 0)
	{
		std::string buttonImagePath = "";
		if(args.has(0) && args[0].isString()) { buttonImagePath = args[0].asString(); }

		self->SetStarIconUnmarkedImage(buttonImagePath);
		return ScriptObject();
	}
	
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setStarIconMarkedImage(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	if (args.Length() > 0)
	{
		std::string buttonImagePath = "";
		if(args.has(0) && args[0].isString()) { buttonImagePath = args[0].asString(); }

		self->SetStarIconMarkedImage(buttonImagePath);
		return ScriptObject();
	}
	
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setArrowButtonRect(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	CPopupRating::EPopupRatingArrowButtons buttonType = CPopupRating::ARROW_BUTTON_ALL;
	if(args.has(0) && args[0].isString()) { buttonType = deserializeArrowButtonState(args[0].asString(), CPopupRating::ARROW_BUTTON_ALL); }
	float x = 0.0;
	float y = 0.0;
	float width = 0;
	float height = 0;
	if(args.Length() > 0)
	{
		if (args.has(1) && args[1].isNumber()) {x = static_cast<float>(args[1].asNumber());}
		if (args.has(2) && args[2].isNumber()) {y = static_cast<float>(args[2].asNumber());}
		if (args.has(3) && args[3].isNumber()) {width = static_cast<float>(args[3].asNumber());}
		if (args.has(4) && args[4].isNumber()) {height = static_cast<float>(args[4].asNumber());}
	}
	self->SetArrowButtonRect(buttonType, x, y, width, height);

	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setArrowButtonImage(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	if (args.Length() > 0)
	{
		CPopupRating::EPopupRatingArrowButtons buttonIndex = CPopupRating::ARROW_BUTTON_ALL;
		if(args.has(0) && args[0].isString()) { buttonIndex = deserializeArrowButtonState(args[0].asString(), CPopupRating::ARROW_BUTTON_ALL); }
		std::string state = "all";
		if(args.has(1) && args[1].isString()) { state = args[1].asString(); }
		std::string buttonImagePath = "";
		if(args.has(2) && args[2].isString()) { buttonImagePath = args[2].asString(); }

		self->SetArrowButtonImage(buttonIndex, ButtonBridge::deserializeState(state, IButton::STATE_NORMAL), buttonImagePath);
		return ScriptObject();
	}
	
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setButtonRect(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	CPopupRating::EPopupRatingButtons buttonType = CPopupRating::BUTTON_ALL;
	if(args.has(0) && args[0].isString()) { buttonType = deserializeButtonState(args[0].asString(), CPopupRating::BUTTON_ALL); }
	float x = 0.0;
	float y = 0.0;
	float width = 0;
	float height = 0;
	if(args.Length() > 0)
	{
		if (args.has(1) && args[1].isNumber()) {x = static_cast<float>(args[1].asNumber());}
		if (args.has(2) && args[2].isNumber()) {y = static_cast<float>(args[2].asNumber());}
		if (args.has(3) && args[3].isNumber()) {width = static_cast<float>(args[3].asNumber());}
		if (args.has(4) && args[4].isNumber()) {height = static_cast<float>(args[4].asNumber());}
	}
	self->SetButtonRect(buttonType, x, y, width, height);

	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setButtonImage(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	if (args.Length() > 0)
	{
		CPopupRating::EPopupRatingButtons buttonIndex = CPopupRating::BUTTON_ALL;
		if(args.has(0) && args[0].isString()) { buttonIndex = deserializeButtonState(args[0].asString(), CPopupRating::BUTTON_ALL); }
		std::string state = "all";
		if(args.has(1) && args[1].isString()) { state = args[1].asString(); }
		std::string buttonImagePath = "";
		if(args.has(2) && args[2].isString()) { buttonImagePath = args[2].asString(); }

		self->SetButtonImage(buttonIndex, ButtonBridge::deserializeState(state, IButton::STATE_NORMAL), buttonImagePath);
		return ScriptObject();
	}
	
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setButtonBackgroundColor(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	CPopupRating::EPopupRatingButtons buttonIndex = CPopupRating::BUTTON_ALL;
	if(args.has(0) && args[0].isString()) { buttonIndex = deserializeButtonState(args[0].asString(), CPopupRating::BUTTON_ALL); }
	std::string state = "all";
	if(args.has(1) && args[1].isString()) { state = args[1].asString(); }
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if(args.Length() > 2)
	{
		if (args.has(2) && args[2].isNumber()) {r = (guint8)args[2].asNumber();}
		if (args.has(3) && args[3].isNumber()) {g = (guint8)args[3].asNumber();}
		if (args.has(4) && args[4].isNumber()) {b = (guint8)args[4].asNumber();}
		if (args.has(5) && args[5].isNumber()) {a = (guint8)args[5].asNumber();}
	}
	ClutterColor c = {r, g, b, a};
	self->SetButtonBackgroundColor(buttonIndex, ButtonBridge::deserializeState(state, IButton::STATE_NORMAL), c);

	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setButtonText(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	CPopupRating::EPopupRatingButtons buttonIndex = CPopupRating::BUTTON_ALL;
	std::string state = "all";
	std::string buttonText = "";
	if(args[0].isString()) { buttonIndex = deserializeButtonState(args[0].asString(), CPopupRating::BUTTON_ALL); }
	if(args[1].isString()) { state = args[1].asString(); }
	if(args[2].isString()) { buttonText = args[2].asString(); }
	
	self->SetButtonText(buttonIndex, ButtonBridge::deserializeState(state, IButton::STATE_NORMAL), buttonText);
	
	return ScriptObject();

}

Bridge::ScriptObject PopupRatingBridge::setButtonTextColor(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	CPopupRating::EPopupRatingButtons buttonIndex = CPopupRating::BUTTON_ALL;
	if(args.has(0) && args[0].isString()) { buttonIndex = deserializeButtonState(args[0].asString(), CPopupRating::BUTTON_ALL); }
	std::string state = "all";
	if(args.has(1) && args[1].isString()) { state = args[1].asString(); }
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if(args.Length() > 2)
	{
		if (args.has(2) && args[2].isNumber()) {r = (guint8)args[2].asNumber();}
		if (args.has(3) && args[3].isNumber()) {g = (guint8)args[3].asNumber();}
		if (args.has(4) && args[4].isNumber()) {b = (guint8)args[4].asNumber();}
		if (args.has(5) && args[5].isNumber()) {a = (guint8)args[5].asNumber();}
	}
	ClutterColor c = {r, g, b, a};
	self->SetButtonTextColor(buttonIndex, ButtonBridge::deserializeState(state, IButton::STATE_NORMAL), c);

	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setButtonTextFontSize(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	int buttonTextFontSize = 32;
	CPopupRating::EPopupRatingButtons buttonIndex = CPopupRating::BUTTON_ALL;
	std::string state = "all";
	std::string buttonText = "";
	if(args.has(0) && args[0].isString()) { buttonIndex = deserializeButtonState(args[0].asString(), CPopupRating::BUTTON_ALL); }
	if(args.has(1) && args[1].isString()) { state = args[1].asString(); }
	if(args.has(2) && args[2].isNumber()) { buttonTextFontSize = (int)args[2].asNumber(); }

	self->SetButtonTextFontSize(buttonIndex, ButtonBridge::deserializeState(state, IButton::STATE_NORMAL), buttonTextFontSize);
	
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setButtonBorderColor(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	CPopupRating::EPopupRatingButtons buttonIndex = CPopupRating::BUTTON_ALL;
	std::string state = "all";
	std::string buttonText = "";
	if(args.has(0) && args[0].isString()) { buttonIndex = deserializeButtonState(args[0].asString(), CPopupRating::BUTTON_ALL); }
	if(args.has(1) && args[1].isString()) { state = args[1].asString(); }
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if(args.Length() > 2)
	{
		if (args.has(2) && args[2].isNumber()) {r = (guint8)args[2].asNumber();}
		if (args.has(3) && args[3].isNumber()) {g = (guint8)args[3].asNumber();}
		if (args.has(4) && args[4].isNumber()) {b = (guint8)args[4].asNumber();}
		if (args.has(5) && args[5].isNumber()) {a = (guint8)args[5].asNumber();}
	}
	ClutterColor c = {r, g, b, a};
	self->SetButtonBorderColor(buttonIndex, ButtonBridge::deserializeState(state, IButton::STATE_NORMAL), c);
	
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setButtonBorderWidth(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	CPopupRating::EPopupRatingButtons buttonIndex = CPopupRating::BUTTON_ALL;
	std::string state = "all";
	float buttonBorderWidth = 0.0;
	if(args.has(0) && args[0].isString()) { buttonIndex = deserializeButtonState(args[0].asString(), CPopupRating::BUTTON_ALL); }
	if(args.has(1) && args[1].isString()) { state = args[1].asString(); }
	if(args.has(2) && args[2].isNumber()) { buttonBorderWidth = (float)args[2].asNumber(); }

	self->SetButtonBorderWidth(buttonIndex, ButtonBridge::deserializeState(state, IButton::STATE_NORMAL), buttonBorderWidth);
	
	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::setDefaultFocus(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	CPopupRating::EPopupRatingButtons buttonIndex = CPopupRating::BUTTON_1;
	if(args.has(0) && args[0].isString()) { buttonIndex = deserializeButtonState(args[0].asString(), CPopupRating::BUTTON_1); }

	self->SetDefaultFocus(buttonIndex);

	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::defaultFocus(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	return self->DefaultFocus();
}

Bridge::ScriptObject PopupRatingBridge::setMarkedStarIconNumber(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	int nMarkedStarIconNumber = 3;
	if(args.has(0) && args[0].isNumber()) { nMarkedStarIconNumber =(int)args[0].asNumber(); }

	self->SetMarkedStarIconNumber(nMarkedStarIconNumber);

	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::markedStarIconNumber(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	int nMarkedStarIconNumber = self->MarkedStarIconNumber();
	return nMarkedStarIconNumber;
}

Bridge::ScriptObject PopupRatingBridge::addListener(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	if (args.Length() > 0)
	{
		IPopupRatingListener* listener = unwrapNativeObject<IPopupRatingListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddListener(listener);
		}
	}

	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::removeListener(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	if (args.Length() > 0)
	{
		IPopupRatingListener* listener = unwrapNativeObject<IPopupRatingListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveListener(listener);
		}
	}

	return ScriptObject();
}

Bridge::ScriptObject PopupRatingBridge::supportTTS(CPopupRating* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	bool bSupportTTS = false;
	if(args.has(0) && args[0].isBool()) { bSupportTTS = args[0].asBool();}
	self->SetSupportTTS(bSupportTTS);
	
	return ScriptObject();
}

CPopupRating::EPopupRatingStarIcons PopupRatingBridge::deserializeStarIconState(std::string stateStr, CPopupRating::EPopupRatingStarIcons theDefault)
{
	if (compareStrChar(stateStr, "star_icon_1"))
	{
		return CPopupRating::STAR_ICON_1;
	}
	else if (compareStrChar(stateStr, "star_icon_2"))
	{
		return CPopupRating::STAR_ICON_2;
	}
	else if (compareStrChar(stateStr, "star_icon_3"))
	{
		return CPopupRating::STAR_ICON_3;
	}
	else if (compareStrChar(stateStr, "star_icon_4"))
	{
		return CPopupRating::STAR_ICON_4;
	}
	else if (compareStrChar(stateStr, "star_icon_5"))
	{
		return CPopupRating::STAR_ICON_5;
	}
	else if (compareStrChar(stateStr, "star_icon_all"))
	{
		return CPopupRating::STAR_ICON_ALL;
	}
	else
	{
		return theDefault;
	}
}

CPopupRating::EPopupRatingArrowButtons PopupRatingBridge::deserializeArrowButtonState(std::string stateStr, CPopupRating::EPopupRatingArrowButtons theDefault)
{
	if (compareStrChar(stateStr, "arrow_button_1"))
	{
		return CPopupRating::ARROW_BUTTON_1;
	}
	else if (compareStrChar(stateStr, "arrow_button_2"))
	{
		return CPopupRating::ARROW_BUTTON_2;
	}
	else if (compareStrChar(stateStr, "arrow_button_all"))
	{
		return CPopupRating::ARROW_BUTTON_ALL;
	}
	else
	{
		return theDefault;
	}
}

CPopupRating::EPopupRatingButtons PopupRatingBridge::deserializeButtonState(std::string stateStr, CPopupRating::EPopupRatingButtons theDefault)
{
	if (compareStrChar(stateStr, "button_1"))
	{
		return CPopupRating::BUTTON_1;
	}
	else if (compareStrChar(stateStr, "button_2"))
	{
		return CPopupRating::BUTTON_2;
	}
	else if (compareStrChar(stateStr, "button_all"))
	{
		return CPopupRating::BUTTON_ALL;
	}
	else
	{
		return theDefault;
	}
}

CPopupRating::EPopupRatingTypes PopupRatingBridge::deserializeState(std::string stateStr, CPopupRating::EPopupRatingTypes theDefault)
{
	if (compareStrChar(stateStr, "base_label_type"))
	{
		return CPopupRating::BASE_LABEL_ONLY;
	}
	else if (compareStrChar(stateStr, "base_label_with_popup_type"))
	{
		return CPopupRating::BASE_LABEL_WITH_POPUP;
	}
	else
	{
		return theDefault;
	}
}

int PopupRatingBridge::deserializeAlignment(std::string alignMent)
{
	if (compareStrChar(alignMent, "horizontal_align_left"))
	{
		return HALIGN_LEFT;
	}
	else if (compareStrChar(alignMent, "horizontal_align_center"))
	{
		return HALIGN_CENTER;
	}
	else if (compareStrChar(alignMent, "horizontal_align_right"))
	{
		return HALIGN_RIGHT;
	}
	else if (compareStrChar(alignMent, "vertical_align_top"))
	{
		return VALIGN_TOP;
	}
	else if (compareStrChar(alignMent, "vertical_align_middle"))
	{
		return VALIGN_MIDDLE;
	}
	else if (compareStrChar(alignMent, "vertical_align_bottom"))
	{
		return VALIGN_BOTTOM;
	}
	else
	{
		return 0;
	}
}

void PopupRatingBridge::parsePopupRatingParams(const ScriptObject& options, CPopupRating::TPopupRatingAttr& attr)
{
	if (options.has("x"))
	{
		attr.x = static_cast<float>(options.get("x").asNumber());
	}
	if (options.has("y"))
	{
		attr.y = static_cast<float>(options.get("y").asNumber());
	}
	if (options.has("width"))
	{
		attr.w = static_cast<float>(options.get("width").asNumber());
	}
	if (options.has("height"))
	{
		attr.h = static_cast<float>(options.get("height").asNumber());
	}
	if (options.has("nPopupRatingType"))
	{
		attr.nPopupRatingType = deserializeState(options.get("nPopupRatingType").asString(), CPopupRating::BASE_LABEL_WITH_POPUP);
	}
	if (options.has("bHasHalfMarkedStar"))
	{
		attr.bHasHalfMarkedStar = options.get("bHasHalfMarkedStar").asBool();
	}
	if (options.has("bAutoFlag"))
	{
		attr.bAutoFlag = options.get("bAutoFlag").asBool();
	}
}
