#include "HaloBridgeAll.h"

using namespace HALO;

//void ActorListenerBridge::mapScriptInterface(ScriptContext& context)
//{
//	context.bindFunction<InternalActorListener, &InternalActorListener::GetFirstFocusInCallBack, &InternalActorListener::SetFirstFocusInCallBack>("onFirstShown");
//}
//
//void* ActorListenerBridge::constructFromScript(const ScriptArray& args)
//{
//	return new InternalActorListener;
//}
//
//void ActorListenerBridge::destroyFromScript(void* pointerToDestroyedObject)
//{
//	InternalActorListener *listener = (InternalActorListener*)(pointerToDestroyedObject);
//	delete listener;
//}
//
//bool InternalActorListener::OnFirstFocusIn(class IActor* actor)
//{
//	if (true == FirstFocusInCb.flagExist)
//	{
//		ScriptArray args;
//		args.set(0, ImageWidgetExBridge::wrapNativeObjectToJS(dynamic_cast<CImageWidgetEx*>(actor)));
//		FirstFocusInCb.function.invoke(args);
//	}
//	return true;
//}
namespace Bridge
{

void ImageWidgetExBridge::mapScriptInterface(ScriptContext& context)
{
	ImageWidgetBridge::mapScriptInterface(context);
	
	context.bindNumber<CImageWidgetEx, float, &CImageWidgetEx::getX, &CImageWidgetEx::setX>("x");
	context.bindNumber<CImageWidgetEx, float, &CImageWidgetEx::getY, &CImageWidgetEx::setY>("y");
	context.bindNumber<CImageWidgetEx, float, &CImageWidgetEx::getWidth, &CImageWidgetEx::setWidth>("width");
	context.bindNumber<CImageWidgetEx, float, &CImageWidgetEx::getHeight, &CImageWidgetEx::setHeight>("height");
	context.bindNativeReference<CImageWidgetEx, Widget, &CImageWidgetEx::getParent, &CImageWidgetEx::setParent>("parent");
	context.captureMethodCall<CImageWidgetEx, &handleDestroy>("destroy");
	//context.bindBoolean<CWidgetExtension, &CWidgetExtension::IsReversible, &CWidgetExtension::EnableReverse>("reversible");
	context.captureMethodCall<CImageWidgetEx, &isReversible>("isReversible");
	context.captureMethodCall<CImageWidgetEx, &enableReverse>("enableReverse");
	context.capturePropertyAccess<CImageWidgetEx, &m_isReversible, &m_enableReverse>("reversible");

	//context.captureMethodCall<CImageWidgetEx, &setParent>("setParent");
	//context.captureMethodCall<CImageWidgetEx, &setBackgroundColor>("setBackgroundColor");
	//context.captureMethodCall<CImageWidgetEx, &setSize>("setSize");
	//context.captureMethodCall<CImageWidgetEx, &setPositon>("setPosition");

	//context.captureMethodCall<CImageWidgetEx, &setLayout>("setLayout");
	context.captureMethodCall<CImageWidgetEx, &setOrientation>("setOrientation");

	//context.captureMethodCall<CImageWidgetEx, &show>("show");
	//context.captureMethodCall<CImageWidgetEx, &hide>("hide");

	//context.captureMethodCall<CImageWidgetEx, &setClipArea>("setClipArea");
	//context.captureMethodCall<CImageWidgetEx, &removeClipArea>("removeClipArea");
	//context.captureMethodCall<CImageWidgetEx, &setAlpha>("setAlpha");
	//context.captureMethodCall<CImageWidgetEx, &setPivotPoint>("setPivotPoint");
	//context.captureMethodCall<CImageWidgetEx, &setRotation>("setRotation");
	//context.captureMethodCall<CImageWidgetEx, &setScale>("setScale");
	//context.captureMethodCall<CImageWidgetEx, &setSize>("setSize");
	//context.captureMethodCall<CImageWidgetEx, &addChild>("addChild");
	//context.captureMethodCall<CImageWidgetEx, &numOfChildren>("numOfChildren");
	//context.captureMethodCall<CImageWidgetEx, &destroyAllChildren>("destroyAllChildren");
	//context.captureMethodCall<CImageWidgetEx, &raise>("raise");
	//context.captureMethodCall<CImageWidgetEx, &lower>("lower");
	context.captureMethodCall<CImageWidgetEx, &enable>("enable");
	context.captureMethodCall<CImageWidgetEx, &enableFocus>("enableFocus");
	context.captureMethodCall<CImageWidgetEx, &enablePointerFocus>("enablePointerFocus");
	context.captureMethodCall<CImageWidgetEx, &setFocus>("setFocus");
	context.captureMethodCall<CImageWidgetEx, &killFocus>("killFocus");
	context.captureMethodCall<CImageWidgetEx, &isFocused>("isFocused");
	context.captureMethodCall<CImageWidgetEx, &setTabWindow>("setTabWindow");
	context.captureMethodCall<CImageWidgetEx, &moveTab>("moveTab");

	context.captureMethodCall<CImageWidgetEx, &addMouseListener>("addMouseListener");
	context.captureMethodCall<CImageWidgetEx, &addKeyboardListener>("addKeyboardListener");
	context.captureMethodCall<CImageWidgetEx, &addClickListener>("addClickListener");
	context.captureMethodCall<CImageWidgetEx, &addKeyLongPressListener>("addKeyLongPressListener");
	context.captureMethodCall<CImageWidgetEx, &addFocusListener>("addFocusListener");
	context.captureMethodCall<CImageWidgetEx, &addDragListener>("addDragListener");
	context.captureMethodCall<CImageWidgetEx, &addActorListener>("addFirstShownListener");
	context.captureMethodCall<CImageWidgetEx, &addCursorListener>("addCursorListener");
	
	context.captureMethodCall<CImageWidgetEx, &addAction>("addAction");
	context.captureMethodCall<CImageWidgetEx, &removeMouseListener>("removeMouseListener");
	context.captureMethodCall<CImageWidgetEx, &removeKeyboardListener>("removeKeyboardListener");
	context.captureMethodCall<CImageWidgetEx, &removeClickListener>("removeClickListener");
	context.captureMethodCall<CImageWidgetEx, &removeKeyLongPressListener>("removeKeyLongPressListener");
	context.captureMethodCall<CImageWidgetEx, &removeFocusListener>("removeFocusListener");
	context.captureMethodCall<CImageWidgetEx, &removeDragListener>("removeDragListener");
	context.captureMethodCall<CImageWidgetEx, &removeActorListener>("removeFirstShownListener");
	context.captureMethodCall<CImageWidgetEx, &removeCursorListener>("removeCursorListener");
	context.captureMethodCall<CImageWidgetEx, &removeAction>("removeAction");

	//context.captureMethodCall<CImageWidgetEx, &bindTransition>("bindTransition");

	context.capturePropertyAccess<CImageWidgetEx, &m_getOrientation, &m_setOrientation>("orientation");
}

ImageWidget* ImageWidgetExBridge::constructImageWidget(float x, float y, float width, float height, volt::graphics::Widget* parent, const ScriptArray& args)
{
	if (width == -1 && height == -1)
	{
		return new CImageWidgetEx(x, y, parent);
	}
	else
	{
		return new CImageWidgetEx(x, y, (width == -1) ? 0 : width, (height == -1) ? 0 : height, parent);
	}
}

void ImageWidgetExBridge::destroyFromScript(void* destroyedObject)
{
  volt::graphics::Widget* widget = reinterpret_cast<volt::graphics::Widget*>(destroyedObject);
  delete widget;
  if (IEventManager::GetInstance())
  {
	  IEventManager::GetInstance()->RemoveAsyncReleaseTarget(widget);
  }
}

ScriptObject ImageWidgetExBridge::handleDestroy(CImageWidgetEx* self, const ScriptArray& args)
{
	delete self;
	if (IEventManager::GetInstance())
	{
		IEventManager::GetInstance()->RemoveAsyncReleaseTarget(self);
	}
	return ScriptObject();
}

//
//ScriptObject ImageWidgetExBridge::setBackgroundColor(CImageWidgetEx* self, const ScriptArray& args)
//{
//	guint8 r = 0, g = 0, b = 0, a = 0;
//
//	if(args.Length() > 0)
//	{
//		if(args.has(0) && args[0].isNumber()) {r = args[0].asNumber();}
//		if(args.has(1) && args[1].isNumber()) {g = args[1].asNumber();}
//		if(args.has(2) && args[2].isNumber()) {b = args[2].asNumber();}
//		if(args.has(3) && args[3].isNumber()) {a = args[3].asNumber();}
//	}
//	ClutterColor c = {r, g, b, a};
//
//	self->SetBackgroundColor(c);
//	
//	return ScriptObject();
//}
//
//ScriptObject Bridge::ImageWidgetExBridge::setParent(CImageWidgetEx* self, const ScriptArray& args)
//{
//	if (args.Length() > 0)
//	{
//		CImageWidgetEx* parent = unwrapNativeObject<CImageWidgetEx>(args[0]);
//		self->SetParent(parent);
//	}
//
//	return ScriptObject();
//}
//
//ScriptObject Bridge::ImageWidgetExBridge::setSize(CImageWidgetEx* self, const ScriptArray& args)
//{
//	float width = -1, height = -1;
//
//	if (args.Length() > 0)
//	{
//		if (args.has(0) && args[0].isNumber())
//		{
//			width = args[0].asNumber();
//		}
//		if (args.has(1) && args[1].isNumber())
//		{
//			height = args[1].asNumber();
//		}
//	}
//	self->Resize(width, height);
//
//	return ScriptObject();
//}
//
//ScriptObject ImageWidgetExBridge::setPositon(CImageWidgetEx* self, const ScriptArray& args)
//{
//	float x = 0, y = 0;
//
//	if (args.Length() > 0)
//	{
//		if (args.has(0) && args[0].isNumber())
//		{
//			x = args[0].asNumber();
//		}
//		if (args.has(1) && args[1].isNumber())
//		{
//			y = args[1].asNumber();
//		}
//	}
//	self->SetPosition(x, y);
//
//	return ScriptObject();
//}
//
//ScriptObject Bridge::ImageWidgetExBridge::setLayout(CImageWidgetEx* self, const ScriptArray& args)
//{
//	if (args.Length() > 0)
//	{
//		ILayout* layout = unwrapNativeObject<ILayout>(args[0]);
//		self->SetLayout(layout);
//	}
//
//	return ScriptObject();
//}

ScriptObject ImageWidgetExBridge::isReversible(CImageWidgetEx* self, const ScriptArray& args)
{
	return ScriptObject(self->IsReversible());
}

ScriptObject ImageWidgetExBridge::enableReverse(CImageWidgetEx* self, const ScriptArray& args)
{
	bool flagEnable = true;

	if (args.Length() > 0)
	{
		if (args[0].isBool())
		{
			flagEnable = args[0].asBool();
		}
	}
	self->EnableReverse(flagEnable);

	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::setOrientation(CImageWidgetEx* self, const ScriptArray& args)
{
	HALO_ASSERT(1 == args.Length() && true == args[0].isString());

	std::string orientationStr = args[0].asString();
	EOrientation orientationValue;

	if ("left-to-right" == orientationStr)
	{
		orientationValue = ORIENTATION_LEFT_TO_RIGHT;
	}
	else if ("right-to-left" == orientationStr)
	{
		orientationValue = ORIENTATION_RIGHT_TO_LEFT;
	}
	else if ("refer-to-parent" == orientationStr)
	{
		orientationValue = ORIENTATION_REFER_TO_PARENT;
	}
	else
	{
		HALO_EXCEPTION(false,  "orientation value is not correct\n");
	}

	self->SetOrientation(orientationValue);

	return ScriptObject();
}

//ScriptObject ImageWidgetExBridge::show(CImageWidgetEx* self, const ScriptArray& args)
//{
//	self->Show();
//	return ScriptObject();
//}
//
//ScriptObject Bridge::ImageWidgetExBridge::hide(CImageWidgetEx* self, const ScriptArray& args)
//{
//	self->Hide();
//	return ScriptObject();
//}
//
//ScriptObject Bridge::ImageWidgetExBridge::setClipArea(CImageWidgetEx* self, const ScriptArray& args)
//{
//	float x = 0, y = 0, width = 0, height = 0;
//	if (args.Length() >= 4)
//	{
//		if (args[0].isNumber())
//		{
//			x = args[0].asNumber();
//		}
//		if (args[1].isNumber())
//		{
//			y = args[1].asNumber();
//		}
//		if (args[2].isNumber())
//		{
//			width = args[2].asNumber();
//		}
//		if (args[3].isNumber())
//		{
//			height = args[3].asNumber();
//		}
//	}
//
//	self->SetClipArea(x, y, width, height);
//
//	return ScriptObject();
//}
//
//ScriptObject Bridge::ImageWidgetExBridge::removeClipArea(CImageWidgetEx* self, const ScriptArray& args)
//{
//	self->RemoveClipArea();
//	return ScriptObject();
//}
//
//ScriptObject Bridge::ImageWidgetExBridge::setAlpha(CImageWidgetEx* self, const ScriptArray& args)
//{
//	return ScriptObject();
//}
//
//ScriptObject Bridge::ImageWidgetExBridge::setPivotPoint(CImageWidgetEx* self, const ScriptArray& args)
//{
//	return ScriptObject();
//}
//
//ScriptObject Bridge::ImageWidgetExBridge::setRotation(CImageWidgetEx* self, const ScriptArray& args)
//{
//	return ScriptObject();
//}
//
//ScriptObject Bridge::ImageWidgetExBridge::setScale(CImageWidgetEx* self, const ScriptArray& args)
//{
//	return ScriptObject();
//}
//
//ScriptObject Bridge::ImageWidgetExBridge::addChild(CImageWidgetEx* self, const ScriptArray& args)
//{
//	if (args.Length() > 0)
//	{
//		ClutterActor* child = unwrapNativeObject<ClutterActor>(args[0]);
//		if (child != nullptr)
//		{
//			self->AddChild(child);
//		}
//	}
//	return ScriptObject();
//}
//
//ScriptObject Bridge::ImageWidgetExBridge::numOfChildren(CImageWidgetEx* self, const ScriptArray& args)
//{
//	int num = self->NumOfChildren();
//	return ScriptObject(num);
//}
//
//ScriptObject Bridge::ImageWidgetExBridge::destroyAllChildren(CImageWidgetEx* self, const ScriptArray& args)
//{
//	self->DestroyAllChildren();
//	return ScriptObject();
//}
//
//ScriptObject Bridge::ImageWidgetExBridge::raise(CImageWidgetEx* self, const ScriptArray& args)
//{
//	if (args.Length() > 0)
//	{
//		CImageWidgetEx* sibling = unwrapNativeObject<CImageWidgetEx>(args[0]);
//		self->Raise(sibling);
//	}
//	return ScriptObject();
//}
//
//ScriptObject Bridge::ImageWidgetExBridge::lower(CImageWidgetEx* self, const ScriptArray& args)
//{
//	if (args.Length() > 0)
//	{
//		CImageWidgetEx* sibling = unwrapNativeObject<CImageWidgetEx>(args[0]);
//		self->Lower(sibling);
//	}
//	return ScriptObject();
//}

ScriptObject ImageWidgetExBridge::enable(CImageWidgetEx* self, const ScriptArray& args)
{
	bool flagEnable = true;

	if (args.Length() > 0)
	{
		if (args[0].isBool())
		{
			flagEnable = args[0].asBool();
		}
	}
	self->Enable(flagEnable);

	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::enableFocus(CImageWidgetEx* self, const ScriptArray& args)
{
	bool flagEnable = true;

	if (args.Length() > 0)
	{
		if (args[0].isBool())
		{
			flagEnable = args[0].asBool();
		}
	}
	self->EnableFocus(flagEnable);

	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::enablePointerFocus(CImageWidgetEx* self, const ScriptArray& args)
{
	bool flagEnable = true;

	if (args.Length() > 0)
	{
		if (args[0].isBool())
		{
			flagEnable = args[0].asBool();
		}
	}
	self->EnablePointerFocus(flagEnable);

	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::setFocus(CImageWidgetEx* self, const ScriptArray& args)
{
	self->SetFocus();
	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::killFocus(CImageWidgetEx* self, const ScriptArray& args)
{
	self->KillFocus();
	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::isFocused(CImageWidgetEx* self, const ScriptArray& args)
{
	return ScriptObject(self->IsFocused());
}

ScriptObject ImageWidgetExBridge::setTabWindow(CImageWidgetEx* self, const ScriptArray& args)
{
	std::string direction = args[0].asString();

	EDirection eDir = DIRECTION_MAX;
	if (direction == "left")
	{
		eDir = DIRECTION_LEFT;
	}
	else if (direction == "right")
	{
		eDir = DIRECTION_RIGHT;
	}
	else if (direction == "up")
	{
		eDir = DIRECTION_UP;
	}
	else if (direction == "down")
	{
		eDir = DIRECTION_DOWN;
	}
	else
	{
		HALO_EXCEPTION(false,  "Wrong direction!");
	}
	
	CImageWidgetEx *tabWindow = unwrapNativeObject<CImageWidgetEx>(args[0]);

	self->SetTabWindow(eDir, tabWindow);
	
	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::moveTab(CImageWidgetEx* self, const ScriptArray& args)
{
	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::addMouseListener(CImageWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IMouseListener* listener = unwrapNativeObject<IMouseListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddMouseListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::addKeyboardListener(CImageWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IKeyboardListener* listener = unwrapNativeObject<IKeyboardListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddKeyboardListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::addClickListener(CImageWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IClickListener* listener = unwrapNativeObject<IClickListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddClickListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::addKeyLongPressListener(CImageWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IKeyLongPressListener* listener = unwrapNativeObject<IKeyLongPressListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddKeyLongPressListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::addFocusListener(CImageWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IFocusListener* listener = unwrapNativeObject<IFocusListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddFocusListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::addDragListener(CImageWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IDragListener* listener = unwrapNativeObject<IDragListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddDragListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::addCursorListener(CImageWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			ICursorListener* listener = unwrapNativeObject<ICursorListener>(args[0]);
			if (listener != nullptr)
			{
				self->AddCursorListener(listener);
			}
		}
		return ScriptObject();
	}
ScriptObject ImageWidgetExBridge::addActorListener(CImageWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		InternalActorListener* listener = unwrapNativeObject<InternalActorListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddActorListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::removeActorListener(CImageWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			InternalActorListener* listener = unwrapNativeObject<InternalActorListener>(args[0]);
			if (listener != nullptr)
			{
				self->RemoveActorListener(listener);
			}
		}
		return ScriptObject();
	}
ScriptObject ImageWidgetExBridge::addAction(CImageWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IAction* action = unwrapNativeObject<IAction>(args[0]);
		if (action != nullptr)
		{
			self->AddAction(action);
		}
	}
	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::removeMouseListener(CImageWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IMouseListener* listener = unwrapNativeObject<IMouseListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveMouseListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::removeKeyboardListener(CImageWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IKeyboardListener* listener = unwrapNativeObject<IKeyboardListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveKeyboardListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::removeClickListener(CImageWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IClickListener* listener = unwrapNativeObject<IClickListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveClickListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::removeKeyLongPressListener(CImageWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IKeyLongPressListener* listener = unwrapNativeObject<IKeyLongPressListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveKeyLongPressListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::removeFocusListener(CImageWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IFocusListener* listener = unwrapNativeObject<IFocusListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveFocusListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::removeDragListener(CImageWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IDragListener* listener = unwrapNativeObject<IDragListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveDragListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject ImageWidgetExBridge::removeCursorListener(CImageWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			ICursorListener* listener = unwrapNativeObject<ICursorListener>(args[0]);
			if (listener != nullptr)
			{
				self->RemoveCursorListener(listener);
			}
		}
		return ScriptObject();
	}
ScriptObject ImageWidgetExBridge::removeAction(CImageWidgetEx* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IAction* listener = unwrapNativeObject<IAction>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveAction(listener);
		}
	}
	return ScriptObject();
}

//ScriptObject Bridge::ImageWidgetExBridge::bindTransition(CImageWidgetEx* self, const ScriptArray& args)
//{
//	HALO_ASSERT(NULL != self);
//	HALO_ASSERT(2 == args.Length() && true == args[1].isNumber());
//
//	ITransition *trans = unwrapNativeObject<ITransition>(args[0]);
//	int animationType = (int)args[1].asNumber();
//
//	self->BindTransition(trans, animationType);
//
//	return ScriptObject();
//}

ScriptObject ImageWidgetExBridge::m_getOrientation(CImageWidgetEx* self)
{
	EOrientation ori = self->Orientation(true);
	switch (ori)
	{
	case HALO::ORIENTATION_RIGHT_TO_LEFT:
		return ScriptObject("right-to-left");
	case HALO::ORIENTATION_REFER_TO_PARENT:
		return ScriptObject("refer-to-parent");
	default:
		return ScriptObject("left-to-right");
	}
}

void ImageWidgetExBridge::m_setOrientation(CImageWidgetEx* self, ScriptObject value)
{
	std::string orientationStr = value.asString();
	EOrientation orientationValue = ORIENTATION_REFER_TO_PARENT;

	if ("left-to-right" == orientationStr)
	{
		orientationValue = ORIENTATION_LEFT_TO_RIGHT;
	}
	else if ("right-to-left" == orientationStr)
	{
		orientationValue = ORIENTATION_RIGHT_TO_LEFT;
	}
	else if ("refer-to-parent" == orientationStr)
	{
		orientationValue = ORIENTATION_REFER_TO_PARENT;
	}
	else
	{
		HALO_EXCEPTION(false,  "orientation value is not correct\n");
	}

	self->SetOrientation(orientationValue);
}

ScriptObject ImageWidgetExBridge::m_isReversible(CImageWidgetEx* self)
{
	bool reversibleFlag = self->IsReversible();
	return ScriptObject(reversibleFlag);
}

void ImageWidgetExBridge::m_enableReverse(CImageWidgetEx* self, ScriptObject value)
{
	bool reverseFlag = value.asBool();
	self->EnableReverse(reverseFlag);
}
}