#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

#define INVALID 0xffff

#define SAVETY_ASSIGNMENT(obj, key, type, val) if(obj.has(key)) {ScriptObject tmp = obj.get(key); ASSERT(true == tmp.is##type); val = tmp.as##type;}
//#define SAVETY_ASSIGNMENT(obj, key, type, val, valType) if(obj.has(key)) {ScriptObject tmp = obj.get(key); ASSERT(true == tmp.is##type); val = (valType)tmp.as##type;}

// ThumbnailListenerBridge
void Bridge::ThumbnailListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	context.bindFunction<InternalThumbListener, &InternalThumbListener::GetIconClickedCallBack, &InternalThumbListener::SetIconClickedCallBack>("onAttachIconClicked");
	context.bindFunction<InternalThumbListener, &InternalThumbListener::GetImageReadyCallBack, &InternalThumbListener::SetImageReadyCallBack>("onImageReady");
}

void* Bridge::ThumbnailListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalThumbListener;
}

// InternalThumbListener
bool Bridge::InternalThumbListener::OnImageReady(class IThumbnail *thumbnail, int index, bool success)
{
	if (true == ImageReadyCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CThumbnail*>(thumbnail)));
		char buf[7];
		SNPRINTF(buf, 7, "image%d", index);
		args.set(1, ScriptObject(buf));
		args.set(2, ScriptObject(success));

		ImageReadyCb.function.invoke(args);
	}
	return true;
}

bool Bridge::InternalThumbListener::OnIconClicked(class IThumbnail *thumbnail, int index)
{
	if (true == IconClickedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CThumbnail*>(thumbnail)));
		char buf[7];
		SNPRINTF(buf, 7, "icon%d", index);
		args.set(1, ScriptObject(buf));
		
		IconClickedCb.function.invoke(args);
	}
	return true;
}

// ThumbnailBridge
void ThumbnailBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.captureMethodCall<CThumbnail, &setThumbnailStyle>("setThumbnailStyle");

	context.captureMethodCall<CThumbnail, &setContentImage>("setContentImage");
	context.captureMethodCall<CThumbnail, &setInformationText>("setInformationText");
	context.captureMethodCall<CThumbnail, &setInformationTextColor>("setInformationTextColor");
	context.captureMethodCall<CThumbnail, &setInformationTextFont>("setInformationTextFont");
	context.captureMethodCall<CThumbnail, &setInformationIcon>("setInformationIcon");
	context.captureMethodCall<CThumbnail, &setAttachIcon>("setAttachIcon");
	context.captureMethodCall<CThumbnail, &setAttachText>("setAttachText");
	context.captureMethodCall<CThumbnail, &setAttachTextColor>("setAttachTextColor");
	context.captureMethodCall<CThumbnail, &setAttachTextFont>("setAttachTextFont");
	context.captureMethodCall<CThumbnail, &setProgressRange>("setProgressRange");
	context.captureMethodCall<CThumbnail, &setProgressValue>("setProgressValue");

	context.captureMethodCall<CThumbnail, &visualizeThumbnailStyle>("visualizeThumbnailStyle");
	context.captureMethodCall<CThumbnail, &visualizeAttachIcon>("visualizeAttachIcon");
	context.captureMethodCall<CThumbnail, &visualizeInformationIcon>("visualizeInformationIcon");
	context.captureMethodCall<CThumbnail, &visualizeInformationText>("visualizeInformationText");

	context.captureMethodCall<CThumbnail, &enableAttachTextEllipsize>("enableAttachTextEllipsize");
	context.captureMethodCall<CThumbnail, &setAttachTextScrollAttribute>("setAttachTextScrollAttribute");
	context.captureMethodCall<CThumbnail, &enableAttachTextAutoScroll>("enableAttachTextAutoScroll");
	context.captureMethodCall<CThumbnail, &enableInformationTextEllipsize>("enableInformationTextEllipsize");
	context.captureMethodCall<CThumbnail, &setInformationTextScrollAttribute>("setInformationTextScrollAttribute");
	context.captureMethodCall<CThumbnail, &enableInformationTextAutoScroll>("enableInformationTextAutoScroll");
	context.captureMethodCall<CThumbnail, &setAttachTextColorPickingRange>("setAttachTextColorPickingRange");
	context.captureMethodCall<CThumbnail, &setInformationColorPickingRange>("setInformationColorPickingRange");
	context.captureMethodCall<CThumbnail, &getInformationColorPicking>("getInformationColorPicking");
	context.captureMethodCall<CThumbnail, &getInformationExtractColor>("getInformationExtractColor");
	context.captureMethodCall<CThumbnail, &getImageColorPicking>("getImageColorPicking");
	context.captureMethodCall<CThumbnail, &setInformationRatingValue>("setInformationRatingValue");

	context.captureMethodCall<CThumbnail, &setScaleAnimation>("setScaleAnimation");
	context.captureMethodCall<CThumbnail, &setStyleTransAnimation>("setStyleTransAnimation");

	context.captureMethodCall<CThumbnail, &thumbnailStyle>("styles");
	context.captureMethodCall<CThumbnail, &visibleThumbnailStyle>("visibleStyles");

	context.captureMethodCall<CThumbnail, &addThumbnailListener>("addThumbnailListener");

	context.captureMethodCall<CThumbnail, &scaleElement>("scaleElement");
	context.captureMethodCall<CThumbnail, &enableFontScale>("enableFontScale");


	context.captureMethodCall<CThumbnail, &SetTTSText>("setTTSText");
	
	context.captureMethodCall<CThumbnail, &getElementAllocation>("getElementAllocation");
	context.captureMethodCall<CThumbnail, &setElementAllocation>("setElementAllocation");
	context.captureMethodCall<CThumbnail, &setElementOpacity>("setElementOpacity");

	context.captureMethodCall<CThumbnail, &setDimBackgroundColor>("setDimBackgroundColor");
	context.captureMethodCall<CThumbnail, &setDimImage>("setDimImage");
	context.captureMethodCall<CThumbnail, &dim>("dim");
	context.captureMethodCall<CThumbnail, &raiseElement>("raiseElement");
	context.captureMethodCall<CThumbnail, &setScrollPlayerImages>("setScrollPlayerImage");
#ifndef WIN32
	context.captureMethodCall<CThumbnail, &setVideoActorAttr>("setVideoActorAttr");
	context.captureMethodCall<CThumbnail, &play>("play");
	context.captureMethodCall<CThumbnail, &stop>("stop");
	context.captureMethodCall<CThumbnail, &pause>("pause");
#endif
}


//void* ThumbnailBridge::constructFromScript(const ScriptArray& args)
//{
//	Widget *cWidget = (Widget*)WidgetBridge::constructFromScript(args);
//	cWidget->setColor(Color(0, 0, 0, 0));
//
//	return cWidget;
//}


CThumbnail* Bridge::ThumbnailBridge::constructThumbnail(Widget* parent, float width, float height, const ScriptArray& args)
{
	IThumbnail::EThumbnailStyles styles = 0;
	IThumbnail::EThumbnailStyles visibleStyles = 0;
	IThumbnail::TThumbnailAttr attr;
	ScriptObject options;
	int argsLen = args.Length();
	if (argsLen > 0)
	{
		options = args[0];

		parseThumbnailParams(options, styles, visibleStyles, attr);
	}

	IThumbnail *thumbnail = IThumbnail::CreateInstance(parent, width, height, styles, visibleStyles, attr);
	return dynamic_cast<CThumbnail*>(thumbnail);
}

Widget* ThumbnailBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	CThumbnail *cThumbnail = constructThumbnail(parent, width, height, args);
	cThumbnail->SetPosition(x, y);
	return cThumbnail;
}

EHAlignment ThumbnailBridge::deserializeHorizontalTextAlignment(std::string alignmentStr, EHAlignment theDefault)
{
	if (compareStrChar(alignmentStr, "left")) { return HALIGN_LEFT; }
	else if (compareStrChar(alignmentStr, "center")) { return HALIGN_CENTER; }
	else if (compareStrChar(alignmentStr, "right")) { return HALIGN_RIGHT; }
	else { return theDefault; }
}

EVAlignment ThumbnailBridge::deserializeVerticalTextAlignment(std::string alignmentStr, EVAlignment theDefault)
{
	if (compareStrChar(alignmentStr, "top")) { return VALIGN_TOP; }
	else if (compareStrChar(alignmentStr, "middle")) { return VALIGN_MIDDLE; }
	else if (compareStrChar(alignmentStr, "bottom")) { return VALIGN_BOTTOM; }
	else { return theDefault; }
}

ClutterTimelineDirection ThumbnailBridge::deserializeTextScrollDirection(std::string directionStr, ClutterTimelineDirection theDefault)
{
	if (compareStrChar(directionStr, "forward")) { return CLUTTER_TIMELINE_FORWARD; }
	else if (compareStrChar(directionStr, "backward")) { return CLUTTER_TIMELINE_BACKWARD; }
	else { return theDefault; }
}

ClutterTextScrollType ThumbnailBridge::deserializeTextScrollType(std::string typeStr, ClutterTextScrollType theDefault)
{
	if (compareStrChar(typeStr, "start_outside_stop_outside")) { return CLUTTER_TEXT_SCROLL_START_OUTSIDE_STOP_OUTSIDE; }
	else if (compareStrChar(typeStr, "start_outside_stop_inside")) { return CLUTTER_TEXT_SCROLL_START_OUTSIDE_STOP_INSIDE; }
	else if (compareStrChar(typeStr, "start_inside_stop_outside")) { return CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_OUTSIDE; }
	else if (compareStrChar(typeStr, "start_inside_stop_inside")) { return CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_INSIDE; }
	else if (compareStrChar(typeStr, "continuous_scroll")) { return CLUTTER_TEXT_SCROLL_CONTINUOUS_SCROLL; }
	else { return theDefault; }
}

TweenMode ThumbnailBridge::deserializeTransitionMode(std::string tweenStr)
{
	if (compareStrChar(tweenStr, "QUADRATIC")) return TweenMode::QUADRATIC;
	if (compareStrChar(tweenStr, "QUADRATIC-in")) return TweenMode::QUADRATIC_IN;
	if (compareStrChar(tweenStr, "QUADRATIC-out")) return TweenMode::QUADRATIC_OUT;

	if (compareStrChar(tweenStr, "CUBIC")) return TweenMode::CUBIC;
	if (compareStrChar(tweenStr, "CUBIC-in")) return TweenMode::CUBIC_IN;
	if (compareStrChar(tweenStr, "CUBIC-out")) return TweenMode::CUBIC_OUT;

	if (compareStrChar(tweenStr, "QUARTIC")) return TweenMode::QUARTIC;
	if (compareStrChar(tweenStr, "QUARTIC-in")) return TweenMode::QUARTIC_IN;
	if (compareStrChar(tweenStr, "QUARTIC-out")) return TweenMode::QUARTIC_OUT;

	if (compareStrChar(tweenStr, "QUINTIC")) return TweenMode::QUINTIC;
	if (compareStrChar(tweenStr, "QUINTIC-in")) return TweenMode::QUINTIC_IN;
	if (compareStrChar(tweenStr, "QUINTIC-out")) return TweenMode::QUINTIC_OUT;

	if (compareStrChar(tweenStr, "SINE")) return TweenMode::SINE;
	if (compareStrChar(tweenStr, "SINE-in")) return TweenMode::SINE_IN;
	if (compareStrChar(tweenStr, "SINE-out")) return TweenMode::SINE_OUT;

	if (compareStrChar(tweenStr, "EXPONENTIAL")) return TweenMode::EXPONENTIAL;
	if (compareStrChar(tweenStr, "EXPONENTIAL-in")) return TweenMode::EXPONENTIAL_IN;
	if (compareStrChar(tweenStr, "EXPONENTIAL-out")) return TweenMode::EXPONENTIAL_OUT;

	if (compareStrChar(tweenStr, "CIRCULAR")) return TweenMode::CIRCULAR;
	if (compareStrChar(tweenStr, "CIRCULAR-in")) return TweenMode::CIRCULAR_IN;
	if (compareStrChar(tweenStr, "CIRCULAR-out")) return TweenMode::CIRCULAR_OUT;

	if (compareStrChar(tweenStr, "ELASTIC")) return TweenMode::ELASTIC;
	if (compareStrChar(tweenStr, "ELASTIC-in")) return TweenMode::ELASTIC_IN;
	if (compareStrChar(tweenStr, "ELASTIC-out")) return TweenMode::ELASTIC_OUT;

	if (compareStrChar(tweenStr, "OVERSHOOT")) return TweenMode::OVERSHOOT;
	if (compareStrChar(tweenStr, "OVERSHOOT-in")) return TweenMode::OVERSHOOT_IN;
	if (compareStrChar(tweenStr, "OVERSHOOT-out")) return TweenMode::OVERSHOOT_OUT;

	if (compareStrChar(tweenStr, "BOUNCE")) return TweenMode::BOUNCE;
	if (compareStrChar(tweenStr, "BOUNCE-in")) return TweenMode::BOUNCE_IN;
	if (compareStrChar(tweenStr, "BOUNCE-out")) return TweenMode::BOUNCE_OUT;

	return TweenMode::LINEAR;
}

ImageWidget::FillMode ThumbnailBridge::deserializeFillMode(const std::string& alignment)
{
	if (compareStrChar(alignment, "stretch")) return ImageWidget::FillMode::Stretch;
	else if (compareStrChar(alignment, "fit")) return ImageWidget::FillMode::Fit;
	else if (compareStrChar(alignment, "top")) return ImageWidget::FillMode::Top;
	else if (compareStrChar(alignment, "top-left")) return ImageWidget::FillMode::Top_Left;
	else if (compareStrChar(alignment, "top-right")) return ImageWidget::FillMode::Top_Right;
	else if (compareStrChar(alignment, "left")) return ImageWidget::FillMode::Left;
	else if (compareStrChar(alignment, "right")) return ImageWidget::FillMode::Right;
	else if (compareStrChar(alignment, "center")) return ImageWidget::FillMode::Center;
	else if (compareStrChar(alignment, "bottom-left")) return ImageWidget::FillMode::Bottom_Left;
	else if (compareStrChar(alignment, "bottom")) return ImageWidget::FillMode::Bottom;
	else if (compareStrChar(alignment, "bottom-right")) return ImageWidget::FillMode::Bottom_Right;
	else return ImageWidget::FillMode::Stretch;
}

std::string ThumbnailBridge::serializeFillMode(const ImageWidget::FillMode alignment)
{
	switch (alignment)
	{
	case ImageWidget::FillMode::Stretch:      return "stretch";
	case ImageWidget::FillMode::Fit:          return "fit";
	case ImageWidget::FillMode::Top:          return "top";
	case ImageWidget::FillMode::Top_Left:     return "top-left";
	case ImageWidget::FillMode::Top_Right:    return "top-right";
	case ImageWidget::FillMode::Left:         return "left";
	case ImageWidget::FillMode::Right:        return "right";
	case ImageWidget::FillMode::Center:       return "center";
	case ImageWidget::FillMode::Bottom_Left:  return "bottom-left";
	case ImageWidget::FillMode::Bottom:       return "bottom";
	case ImageWidget::FillMode::Bottom_Right: return "bottom-right";

	default: return "stretch";
	}
}

TRegion ThumbnailBridge::ScriptToRange(const ScriptObject& val)
{
	TRegion retval;
	if (val.has("l") || val.has("r") || val.has("t") || val.has("b"))
	{
		retval.l = (val.has("l")) ? val["l"].asNumber() : 0;
		retval.r = (val.has("r")) ? val["r"].asNumber() : 100;
		retval.t = (val.has("t")) ? val["t"].asNumber() : 90;
		retval.b = (val.has("b")) ? val["b"].asNumber() : 100;
		return retval;
	}
	throw VoltJsRuntimeException("Bad Type: Range object expected for range value.");
}

void Bridge::ThumbnailBridge::parseThumbnailParams(const ScriptObject& options, IThumbnail::EThumbnailStyles& styles, IThumbnail::EThumbnailStyles& visibleStyles, IThumbnail::TThumbnailAttr& attr)
{
	if (options.has("visibleStyles") && true == options.get("visibleStyles").isNumber())
	{
		visibleStyles = (int)options.get("visibleStyles").asNumber();
	}
	if (options.has("image"))
	{
		ScriptObject contentObj = options.get("image");
		if (contentObj.has("src")) { attr.imageInfo.src = contentObj.get("src").asString(); }
		if (contentObj.has("defaultSrc")) { attr.imageInfo.defaultSrc = contentObj.get("defaultSrc").asString(); }
		if (contentObj.has("async")) { attr.imageInfo.async = contentObj.get("async").asBool(); }
		if (contentObj.has("x")) { attr.imageInfo.alloc.x = contentObj.get("x").asNumber(); }
		if (contentObj.has("y")) { attr.imageInfo.alloc.y = contentObj.get("y").asNumber(); }
		if (contentObj.has("width")) { attr.imageInfo.alloc.w = contentObj.get("width").asNumber(); }
		if (contentObj.has("height")) { attr.imageInfo.alloc.h = contentObj.get("height").asNumber(); }
		if (contentObj.has("fillMode")) { attr.imageInfo.fillMode = deserializeFillMode(contentObj.get("fillMode").asString()); }

		styles |= IThumbnail::THUMB_STYLE_IMAGE;
	}
	if (options.has("information"))
	{
		ScriptObject infoObj = options.get("information");
		if (infoObj.has("x")) { attr.info.alloc.x = infoObj.get("x").asNumber(); }
		if (infoObj.has("y")) { attr.info.alloc.y = infoObj.get("y").asNumber(); }
		if (infoObj.has("width")) { attr.info.alloc.w = infoObj.get("width").asNumber(); }
		if (infoObj.has("height")) { attr.info.alloc.h = infoObj.get("height").asNumber(); }
		if (infoObj.has("colorPickingRange")) { attr.info.colorPickingRange = ScriptToRange(infoObj.get("colorPickingRange")); }
		if (infoObj.has("color")) { attr.info.backgroundColor = ScriptToColor(infoObj.get("color"));  attr.info.useRefereceColor = false; }
		
		for (int i = 1;; i++)
		{
			char buf[7];
			SNPRINTF(buf, 7, "text%d", i);
			if (!infoObj.has(buf))
			{
				break;
			}

			ScriptObject textObj = infoObj.get(buf);
			parseInformationTexts(textObj, attr);
		}
		for (int i = 1;; i++)
		{
			char buf[7];
			SNPRINTF(buf, 7, "icon%d", i);
			if (!infoObj.has(buf))
			{
				break;
			}

			ScriptObject textObj = infoObj.get(buf);
			parseInformationIcons(textObj, attr);
		}
		if (infoObj.has("rating"))
		{
			ScriptObject ratingObj = infoObj.get("rating");
			if (ratingObj.has("x")) { attr.info.ratingInfo.alloc.x = ratingObj.get("x").asNumber(); }
			if (ratingObj.has("y")) { attr.info.ratingInfo.alloc.y = ratingObj.get("y").asNumber(); }
			if (ratingObj.has("width")) { attr.info.ratingInfo.alloc.w = ratingObj.get("width").asNumber(); }
			if (ratingObj.has("height")) { attr.info.ratingInfo.alloc.h = ratingObj.get("height").asNumber(); }
			if (ratingObj.has("onSrc")) { attr.info.ratingInfo.onName = ratingObj.get("onSrc").asString(); }
			if (ratingObj.has("halfSrc")) { attr.info.ratingInfo.halfName = ratingObj.get("halfSrc").asString(); }
			if (ratingObj.has("offSrc")) { attr.info.ratingInfo.offName = ratingObj.get("offSrc").asString(); }
			if (ratingObj.has("iconWidth")) { attr.info.ratingInfo.iconSize.val[0] = ratingObj.get("iconWidth").asNumber(); }
			if (ratingObj.has("iconHeight")) { attr.info.ratingInfo.iconSize.val[1] = ratingObj.get("iconHeight").asNumber(); }
			if (ratingObj.has("opacity")) { attr.info.ratingInfo.opacity = ratingObj.get("opacity").asNumber(); }
			if (ratingObj.has("value")) { attr.info.ratingInfo.value = ratingObj.get("value").asNumber(); }
			if (ratingObj.has("gap")) { attr.info.ratingInfo.gap = ratingObj.get("gap").asNumber(); }

			attr.infoStyle |= IThumbnail::THUMB_INFO_STYLE_RATING;
		}
		

		styles |= IThumbnail::THUMB_STYLE_INFO;
	}
	// Attach icons
	for (int i = 1;; i++)
	{
		char buf[7];
		SNPRINTF(buf, 7, "icon%d", i);
		if (!options.has(buf))
		{
			break;
		}
		ScriptObject iconObj = options.get(buf);
		parseAttachIconParams(iconObj, attr);
		styles |= IThumbnail::THUMB_STYLE_ICON;
	}
	// Attach text
	if (options.has("text"))
	{
		ScriptObject textObj = options.get("text");
		if (textObj.has("x")) { attr.attachTextInfo.textInfo.alloc.x = textObj.get("x").asNumber(); }
		if (textObj.has("y")) { attr.attachTextInfo.textInfo.alloc.y = textObj.get("y").asNumber(); }
		if (textObj.has("width")) { attr.attachTextInfo.textInfo.alloc.w = textObj.get("width").asNumber(); }
		if (textObj.has("height")) { attr.attachTextInfo.textInfo.alloc.h = textObj.get("height").asNumber(); }
		if (textObj.has("font")) { attr.attachTextInfo.textInfo.fontName = textObj.get("font").asString(); }
		//if (textObj.has("fontSize")) { attr.attachTextInfo.fontSize = textObj.get("fontSize").asNumber(); }
		if (textObj.has("horizontalAlignment")) { attr.attachTextInfo.textInfo.hAlign = deserializeHorizontalTextAlignment(textObj.get("horizontalAlignment").asString(), HALIGN_LEFT); }
		if (textObj.has("verticalAlignment")) { attr.attachTextInfo.textInfo.vAlign = deserializeVerticalTextAlignment(textObj.get("verticalAlignment").asString(), VALIGN_MIDDLE); }
		if (textObj.has("ellipsize")) { attr.attachTextInfo.textInfo.ellipsize = textObj.get("ellipsize").asBool(); }
		if (textObj.has("bold")) { attr.attachTextInfo.textInfo.bold = textObj.get("bold").asBool(); }
		if (textObj.has("italic")) { attr.attachTextInfo.textInfo.italic = textObj.get("italic").asBool(); }
		if (textObj.has("opacity")) { attr.attachTextInfo.textInfo.opacity = textObj.get("opacity").asNumber(); }
		if (textObj.has("text")) { attr.attachTextInfo.textInfo.text = textObj.get("text").asString(); }
		if (textObj.has("colorPickingRange")) { attr.attachTextInfo.colorPickingRange = ScriptToRange(textObj.get("colorPickingRange")); }
		if (textObj.has("color")) { attr.attachTextInfo.backgroundColor = ScriptToColor(textObj.get("color")); attr.attachTextInfo.useRefereceColor = false; }
		if (textObj.has("textColor")) { attr.attachTextInfo.textInfo.textColor = ScriptToColor(textObj.get("textColor")); }
		

		styles |= IThumbnail::THUMB_STYLE_TEXT;
	}
	if (options.has("progressBar"))
	{
		ScriptObject progressObj = options.get("progressBar");
		if (progressObj.has("x")) { attr.progressBar.alloc.x = progressObj.get("x").asNumber(); }
		if (progressObj.has("y")) { attr.progressBar.alloc.y = progressObj.get("y").asNumber(); }
		if (progressObj.has("width")) { attr.progressBar.alloc.w = progressObj.get("width").asNumber(); }
		if (progressObj.has("height")) { attr.progressBar.alloc.h = progressObj.get("height").asNumber(); }
		if (progressObj.has("backgroundColor")) { attr.progressBar.backgroundColor = ScriptToColor(progressObj.get("backgroundColor")); }
		if (progressObj.has("progressColor")) { attr.progressBar.progressColor = ScriptToColor(progressObj.get("progressColor")); }
		if (progressObj.has("normalThumbSrc")) { attr.progressBar.normalThumb = progressObj.get("normalThumbSrc").asString(); }
		if (progressObj.has("focusThumbSrc")) { attr.progressBar.focusThumb = progressObj.get("focusThumbSrc").asString(); }
		TValue2f thumbSize;
		if (progressObj.has("thumbWidth")) { thumbSize.val[0] = progressObj.get("thumbWidth").asNumber(); }
		if (progressObj.has("thumbHeight")) { thumbSize.val[1] = progressObj.get("thumbHeight").asNumber(); }
		attr.progressBar.thumbSize = thumbSize;
		if (progressObj.has("slidable")) { attr.progressBar.slidable = progressObj.get("slidable").asBool(); }

		styles |= IThumbnail::THUMB_STYLE_PROGRESSBAR;
	}
	if (options.has("checkBox"))
	{
		ScriptObject checkObj = options.get("checkBox");
		if (checkObj.has("x")) { attr.checkBox.alloc.x = checkObj.get("x").asNumber(); }
		if (checkObj.has("y")) { attr.checkBox.alloc.y = checkObj.get("y").asNumber(); }
		if (checkObj.has("width")) { attr.checkBox.alloc.w = checkObj.get("width").asNumber(); }
		if (checkObj.has("height")) { attr.checkBox.alloc.h = checkObj.get("height").asNumber(); }
		if (checkObj.has("uncheckSrc")) { attr.checkBox.uncheckName = checkObj.get("uncheckSrc").asString(); }
		if (checkObj.has("checkedSrc")) { attr.checkBox.checkedName = checkObj.get("checkedSrc").asString(); }

		styles |= IThumbnail::THUMB_STYLE_CHECKBOX;
	}
	if (options.has("scrollPlayer"))
	{
		ScriptObject scrollPlayerObj = options.get("scrollPlayer");
		if (scrollPlayerObj.has("x")) { attr.scrollPlayerInfo.alloc.x = scrollPlayerObj.get("x").asNumber(); }
		if (scrollPlayerObj.has("y")) { attr.scrollPlayerInfo.alloc.y = scrollPlayerObj.get("y").asNumber(); }
		if (scrollPlayerObj.has("width")) { attr.scrollPlayerInfo.alloc.w = scrollPlayerObj.get("width").asNumber(); }
		if (scrollPlayerObj.has("height")) { attr.scrollPlayerInfo.alloc.h = scrollPlayerObj.get("height").asNumber(); }
		if (scrollPlayerObj.has("itemNumber")) { attr.scrollPlayerInfo.itemNumber = scrollPlayerObj.get("itemNumber").asNumber(); }
		if (scrollPlayerObj.has("duration")) { attr.scrollPlayerInfo.aniDuration = scrollPlayerObj.get("duration").asNumber(); }
		if (scrollPlayerObj.has("mode")) { attr.scrollPlayerInfo.aniMode = (ClutterAnimationMode)deserializeTransitionMode(scrollPlayerObj.get("mode").asString()); }
		if (scrollPlayerObj.has("async")) { attr.scrollPlayerInfo.async = scrollPlayerObj.get("async").asBool(); }

		for (int i = 1;; i++)
		{
			char buf[7] = {0};
			SNPRINTF(buf, 7, "src%d", i);
			if (!scrollPlayerObj.has(buf))
			{
				break;
			}
			std::string src = scrollPlayerObj.get(buf).asString();
			attr.scrollPlayerInfo.srcList.push_back(src);
		}

		styles &= ~IThumbnail::THUMB_STYLE_IMAGE;
		styles |= IThumbnail::THUMB_STYLE_SCROLLPLAYER;
	}
#ifndef WIN32
	if (options.has("video"))
	{
		ScriptObject contentObj = options.get("video");
		if (contentObj.has("type")) 
		{ 
			attr.videoActorInfo.type = VideoActorBridge::deserializeType(contentObj.get("type").asString()); 
		}
		if (contentObj.has("x")) 
		{ 
			attr.videoActorInfo.alloc.x = contentObj.get("x").asNumber(); 
		}
		if (contentObj.has("y")) 
		{
			attr.videoActorInfo.alloc.y = contentObj.get("y").asNumber(); 
		}
		if (contentObj.has("width")) 
		{ 
			attr.videoActorInfo.alloc.w = contentObj.get("width").asNumber(); 
		}
		if (contentObj.has("height")) 
		{ 
			attr.videoActorInfo.alloc.h = contentObj.get("height").asNumber(); 
		}
		if (contentObj.has("uri")) 
		{ 
			attr.videoActorInfo.uri = contentObj.get("uri").asString(); 
		}
		

		styles |= IThumbnail::THUMB_STYLE_VIDEO;
	}
#endif
}

void Bridge::ThumbnailBridge::parseInformationTexts(const ScriptObject& textObj, IThumbnail::TThumbnailAttr& attr)
{
	IThumbnail::TTextInfo textInfo;
	if (textObj.has("x")) { textInfo.alloc.x = textObj.get("x").asNumber(); }
	if (textObj.has("y")) { textInfo.alloc.y = textObj.get("y").asNumber(); }
	if (textObj.has("width")) { textInfo.alloc.w = textObj.get("width").asNumber(); }
	if (textObj.has("height")) { textInfo.alloc.h = textObj.get("height").asNumber(); }
	if (textObj.has("font")) { textInfo.fontName = textObj.get("font").asString(); }
	//if (textObj.has("fontSize")) { textInfo.fontSize = textObj.get("fontSize").asNumber(); }
	if (textObj.has("horizontalAlignment")) { textInfo.hAlign = deserializeHorizontalTextAlignment(textObj.get("horizontalAlignment").asString(), HALIGN_LEFT); }
	if (textObj.has("verticalAlignment")) { textInfo.vAlign = deserializeVerticalTextAlignment(textObj.get("verticalAlignment").asString(), VALIGN_MIDDLE); }
	if (textObj.has("ellipsize")) { textInfo.ellipsize = textObj.get("ellipsize").asBool(); }
	if (textObj.has("bold")) { textInfo.bold = textObj.get("bold").asBool(); }
	if (textObj.has("italic")) { textInfo.italic = textObj.get("italic").asBool(); }
	if (textObj.has("singleLineMode")) { textInfo.singleLineMode = textObj.get("singleLineMode").asBool(); }
	if (textObj.has("text")) { textInfo.text = textObj.get("text").asString(); }
	if (textObj.has("opacity")) { textInfo.opacity = textObj.get("opacity").asNumber(); }
	if (textObj.has("textColor")) { textInfo.textColor = ScriptToColor(textObj.get("textColor")); }

	attr.info.textInfos.push_back(textInfo);

	attr.infoStyle |= IThumbnail::THUMB_INFO_STYLE_TEXT;
}

void Bridge::ThumbnailBridge::parseInformationIcons(const ScriptObject& iconObj, IThumbnail::TThumbnailAttr& attr)
{
	IThumbnail::TIconInfo iconInfo;
	if (iconObj.has("x")) { iconInfo.alloc.x = iconObj.get("x").asNumber(); }
	if (iconObj.has("y")) { iconInfo.alloc.y = iconObj.get("y").asNumber(); }
	if (iconObj.has("width")) { iconInfo.alloc.w = iconObj.get("width").asNumber(); }
	if (iconObj.has("height")) { iconInfo.alloc.h = iconObj.get("height").asNumber(); }
	if (iconObj.has("src")) { iconInfo.unpressName = iconObj.get("src").asString(); }
	if (iconObj.has("async")) { iconInfo.async = iconObj.get("async").asBool(); }
	if (iconObj.has("opacity")) { iconInfo.opacity = iconObj.get("opacity").asNumber(); }

	attr.info.iconInfos.push_back(iconInfo);

	attr.infoStyle |= IThumbnail::THUMB_INFO_STYLE_ICON;
}

void Bridge::ThumbnailBridge::parseAttachIconParams(const ScriptObject& iconObj, IThumbnail::TThumbnailAttr& attr)
{
	IThumbnail::TIconInfo iconInfo;
	if (iconObj.has("x")) { iconInfo.alloc.x = iconObj.get("x").asNumber(); }
	if (iconObj.has("y")) { iconInfo.alloc.y = iconObj.get("y").asNumber(); }
	if (iconObj.has("width")) { iconInfo.alloc.w = iconObj.get("width").asNumber(); }
	if (iconObj.has("height")) { iconInfo.alloc.h = iconObj.get("height").asNumber(); }
	if (iconObj.has("unpressSrc")) { iconInfo.unpressName = iconObj.get("unpressSrc").asString(); }
	if (iconObj.has("pressedSrc")) { iconInfo.pressedName = iconObj.get("pressedSrc").asString(); }
	if (iconObj.has("async")) { iconInfo.async = iconObj.get("async").asBool(); }
	if (iconObj.has("clickable")) { iconInfo.clickable = iconObj.get("clickable").asBool(); }
	if (iconObj.has("opacity")) { iconInfo.opacity = iconObj.get("opacity").asNumber(); }

	attr.attachIconInfos.push_back(iconInfo);
}

ScriptObject ThumbnailBridge::setThumbnailStyle(CThumbnail* self, const ScriptArray& args)
{
	IThumbnail::EThumbnailStyles styles = 0;
	IThumbnail::EThumbnailStyles visibleStyles = 0;
	IThumbnail::TThumbnailAttr attr;
	bool flagAni = false;
	ScriptObject options;
	int argsLen = args.Length();
	if (argsLen > 0)
	{
		options = args[0];
		parseThumbnailParams(options, styles, visibleStyles, attr);
		if (args.has(1) && args[1].isBool()) { flagAni = args[1].asBool(); }

		self->SetThumbnailStyle(styles, visibleStyles, attr, flagAni);
	}
	return ScriptObject();
}

ScriptObject ThumbnailBridge::setContentImage(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		self->SetImage(args[0].asString().c_str());
	}
	return ScriptObject();
}

ScriptObject ThumbnailBridge::setInformationText(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		int infoTextNum = self->InformationTextNumber();
		std::string titleType = args[0].asString();
		for (int i = 0; i < infoTextNum; i++)
		{
			char buf[7];
			SNPRINTF(buf, 7, "text%d", i+1);
			if (0 == titleType.compare(buf))
			{
				self->SetInformationText(i, args[1].asString().c_str());
				break;
			}
		}
	}
	return ScriptObject();
}

ScriptObject ThumbnailBridge::setInformationTextColor(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		int infoTextNum = self->InformationTextNumber();
		std::string titleType = args[0].asString();
		for (int i = 0; i < infoTextNum; i++)
		{
			char buf[7];
			SNPRINTF(buf, 7, "text%d", i + 1);
			if (0 == titleType.compare(buf))
			{
				self->SetInformationTextColor(i, ScriptToColor(args[1]));
				break;
			}
		}
	}
	return ScriptObject();
}

ScriptObject ThumbnailBridge::setInformationTextFont(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		int infoTextNum = self->InformationTextNumber();
		std::string titleType = args[0].asString();
		for (int i = 0; i < infoTextNum; i++)
		{
			char buf[7];
			SNPRINTF(buf, 7, "text%d", i + 1);
			if (0 == titleType.compare(buf))
			{
				self->SetInformationTextFont(i, args[1].asString().c_str());
				break;
			}
		}
	}
	return ScriptObject();
}

ScriptObject ThumbnailBridge::setInformationIcon(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		int infoIconNum = self->InformationIconNumber();
		std::string titleType = args[0].asString();
		for (int i = 0; i < infoIconNum; i++)
		{
			char buf[7];
			SNPRINTF(buf, 7, "icon%d", i + 1);
			if (0 == titleType.compare(buf))
			{
				self->SetInformationIconImage(i, args[1].asString().c_str());
				break;
			}
		}
	}
	return ScriptObject();
}


ScriptObject ThumbnailBridge::setAttachIcon(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		int attachIconNum = self->AttachedIconNumber();
		std::string titleType = args[0].asString();
		for (int i = 0; i < attachIconNum; i++)
		{
			char buf[7];
			SNPRINTF(buf, 7, "icon%d", i + 1);
			if (0 == titleType.compare(buf))
			{
				self->SetAttachIconImage(i, args[1].asString().c_str());
				break;
			}
		}
	}
	return ScriptObject();
}

ScriptObject ThumbnailBridge::setAttachText(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args[0].isString())
		{
			self->SetAttachText(args[0].asString().c_str());
		}
	}
	return ScriptObject();
}

ScriptObject ThumbnailBridge::setAttachTextColor(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		self->SetAttachTextColor(ScriptToColor(args[0]));
	}
	
	return ScriptObject();
}

ScriptObject ThumbnailBridge::setAttachTextFont(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args[0].isString())
		{
			self->SetAttachTextFont(args[0].asString().c_str());
		}
	}
	return ScriptObject();
}

ScriptObject ThumbnailBridge::enableAttachTextEllipsize(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		bool enable = true;
		if (args[0].isBool()) { enable = args[0].asBool(); }
		self->EnableAttachTextEllipsize(enable);
	}

	return ScriptObject();
}

ScriptObject ThumbnailBridge::setAttachTextScrollAttribute(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		ScriptObject scrollObj = args[0];
		int duration = scrollObj.has("duration") ? scrollObj.get("duration").asNumber() : 5000;
		int delay = scrollObj.has("delay") ? scrollObj.get("delay").asNumber() : 0;
		int repeat = scrollObj.has("repeat") ? scrollObj.get("repeat").asNumber() : -1;
		int continueGap = scrollObj.has("continueGap") ? scrollObj.get("continueGap").asNumber() : 0;
		ClutterTimelineDirection direction = scrollObj.has("direction") ?
			deserializeTextScrollDirection(scrollObj.get("direction").asString(), CLUTTER_TIMELINE_BACKWARD) : CLUTTER_TIMELINE_BACKWARD;
		ClutterTextScrollType scrollType = scrollObj.has("scrollType") ?
			deserializeTextScrollType(scrollObj.get("scrollType").asString(), CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_OUTSIDE) : CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_OUTSIDE;
		self->SetAttachTextScrollAttribute(duration, delay, repeat, scrollType, direction, continueGap);
	}
	
	return ScriptObject();
}

ScriptObject ThumbnailBridge::enableAttachTextAutoScroll(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		bool enable = true;
		if (args[0].isBool()) { enable = args[0].asBool(); }
		self->EnableAttachTextAutoScroll(enable);
	}

	return ScriptObject();
}

ScriptObject ThumbnailBridge::enableInformationTextEllipsize(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		int infoTextNum = self->InformationTextNumber();
		std::string titleType = args[0].asString();
		for (int i = 0; i < infoTextNum; i++)
		{
			char buf[7];
			SNPRINTF(buf, 7, "text%d", i + 1);
			if (0 == titleType.compare(buf))
			{
				bool enable = true;
				if (args[1].isBool()) { enable = args[1].asBool(); }
				self->EnableInformationTextEllipsize(i, enable);
				break;
			}
		}
	}

	return ScriptObject();
}

ScriptObject ThumbnailBridge::setInformationTextScrollAttribute(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		int infoTextNum = self->InformationTextNumber();
		std::string titleType = args[0].asString();
		for (int i = 0; i < infoTextNum; i++)
		{
			char buf[7];
			SNPRINTF(buf, 7, "text%d", i + 1);
			if (0 == titleType.compare(buf))
			{
				ScriptObject scrollObj = args[1];
				int duration = scrollObj.has("duration") ? scrollObj.get("duration").asNumber() : 5000;
				int delay = scrollObj.has("delay") ? scrollObj.get("delay").asNumber() : 0;
				int repeat = scrollObj.has("repeat") ? scrollObj.get("repeat").asNumber() : -1;
				int continueGap = scrollObj.has("continueGap") ? scrollObj.get("continueGap").asNumber() : 0;
				ClutterTimelineDirection direction = scrollObj.has("direction") ?
					deserializeTextScrollDirection(scrollObj.get("direction").asString(), CLUTTER_TIMELINE_BACKWARD) : CLUTTER_TIMELINE_BACKWARD;
				ClutterTextScrollType scrollType = scrollObj.has("scrollType") ?
					deserializeTextScrollType(scrollObj.get("scrollType").asString(), CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_OUTSIDE) : CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_OUTSIDE;
				self->SetInformationTextScrollAttribute(i, duration, delay, repeat, scrollType, direction, continueGap);
				break;
			}
		}
	}

	return ScriptObject();
}

ScriptObject ThumbnailBridge::enableInformationTextAutoScroll(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		int infoTextNum = self->InformationTextNumber();
		std::string titleType = args[0].asString();
		for (int i = 0; i < infoTextNum; i++)
		{
			char buf[7];
			SNPRINTF(buf, 7, "text%d", i + 1);
			if (0 == titleType.compare(buf))
			{
				bool enable = true;
				if (args[1].isBool()) { enable = args[1].asBool(); }
				self->EnableInformationTextAutoScroll(i, enable);
				break;
			}
		}
	}

	return ScriptObject();
}

ScriptObject ThumbnailBridge::setAttachTextColorPickingRange(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		TRegion range = ScriptToRange(args[0]);
		self->SetAttachTextColorPickingRange(range.l, range.r, range.t, range.b);
	}
	
	return ScriptObject();
}

ScriptObject ThumbnailBridge::setInformationColorPickingRange(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		TRegion range = ScriptToRange(args[0]);
		self->SetInformationColorPickingRange(range.l, range.r, range.t, range.b);
	}

	return ScriptObject();
}

ScriptObject ThumbnailBridge::getInformationColorPicking(CThumbnail* self, const ScriptArray& args)
{
	Color color;
	self->GetInformationColorPicking(color);

	return ColorToScript(color);
}

ScriptObject ThumbnailBridge::getInformationExtractColor(CThumbnail* self, const ScriptArray& args)
{
	Color color;
	self->GetInformationExtractColor(color);

	return ColorToScript(color);
}

ScriptObject ThumbnailBridge::getImageColorPicking(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		TRegion range = ScriptToRange(args[0]);
		Color color;
		self->GetColorPicking(range.l, range.r, range.t, range.b, color);
		return ColorToScript(color);
	}

	return ScriptObject();
}

ScriptObject ThumbnailBridge::setInformationRatingValue(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args[0].asNumber())
		{
			self->SetInformationRatingValue(args[0].asNumber());
		}
	}

	return ScriptObject();
}

ScriptObject ThumbnailBridge::setProgressRange(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		int min = 0, max = 0;
		if (args[0].isNumber()) { min = args[0].asNumber(); }
		if (args[1].isNumber()) { max = args[1].asNumber(); }
		self->SetProgressBarRange(min, max);
	}
	return ScriptObject();
}

ScriptObject ThumbnailBridge::setProgressValue(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		int value = 0;
		if (args[0].isNumber()) { value = args[0].asNumber(); }
		self->SetProgressBarValue(value);
	}
	return ScriptObject();
}

ScriptObject ThumbnailBridge::visualizeThumbnailStyle(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		bool enalbe = true;
		IThumbnail::EThumbnailStyles styles = 0;
		if (args[0].isBool()) { enalbe = args[0].asBool(); }
		if (args[1].isNumber()) { styles = args[1].asNumber(); }
		self->EnableThumbnailStyles(enalbe, styles, false);
	}
	
	return ScriptObject();
}

ScriptObject ThumbnailBridge::visualizeAttachIcon(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		bool enalbe = true;
		if (args[0].isBool()) { enalbe = args[0].asBool(); }

		int attachIconNum = self->AttachedIconNumber();
		std::string titleType = args[1].asString();
		for (int i = 0; i < attachIconNum; i++)
		{
			char buf[7];
			SNPRINTF(buf, 7, "icon%d", i + 1);
			if (0 == titleType.compare(buf))
			{
				self->EnableAttachIcon(enalbe, i, false);
				break;
			}
		}
	}
	return ScriptObject();
}

ScriptObject ThumbnailBridge::visualizeInformationIcon(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		bool enalbe = true;
		if (args[0].isBool()) { enalbe = args[0].asBool(); }

		int infoIconNum = self->InformationIconNumber();
		std::string titleType = args[1].asString();
		for (int i = 0; i < infoIconNum; i++)
		{
			char buf[7];
			SNPRINTF(buf, 7, "icon%d", i + 1);
			if (0 == titleType.compare(buf))
			{
				self->EnableInformationIcon(enalbe, i, false);
				break;
			}
		}
	}
	return ScriptObject();
}

ScriptObject ThumbnailBridge::visualizeInformationText(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		bool enalbe = true;
		if (args[0].isBool()) { enalbe = args[0].asBool(); }

		int infoTextNum = self->InformationTextNumber();
		std::string titleType = args[1].asString();
		for (int i = 0; i < infoTextNum; i++)
		{
			char buf[7];
			SNPRINTF(buf, 7, "text%d", i + 1);
			if (0 == titleType.compare(buf))
			{
				self->EnableInformationText(enalbe, i, false);
				break;
			}
		}
	}
	return ScriptObject();
}

ScriptObject ThumbnailBridge::setScaleAnimation(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		int duration = args[0].asNumber();
		TweenMode mode = TweenMode::LINEAR;
		if (args.has(1)) { mode = deserializeTransitionMode(args[1].asString()); }
		self->SetScaleAnimation(duration, (ClutterAnimationMode)mode);
	}
	return ScriptObject();
}

ScriptObject ThumbnailBridge::setStyleTransAnimation(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		int duration = args[0].asNumber();
		TweenMode mode = TweenMode::LINEAR;
		if (args.has(1)) { mode = deserializeTransitionMode(args[1].asString()); }
		self->SetStyleTransAnimation(duration, (ClutterAnimationMode)mode);
	}
	return ScriptObject();
}

ScriptObject ThumbnailBridge::thumbnailStyle(CThumbnail* self, const ScriptArray& args)
{
	int styles = self->ThumbnailStyle();
	return ScriptObject(styles);
}

ScriptObject ThumbnailBridge::visibleThumbnailStyle(CThumbnail* self, const ScriptArray& args)
{
	int visibleStyles = self->VisibleThumbnailStyles();
	return ScriptObject(visibleStyles);
}


Bridge::ScriptObject Bridge::ThumbnailBridge::addThumbnailListener(CThumbnail* self, const ScriptArray& args)
{
	IThumbnailListener *listener = unwrapNativeObject<IThumbnailListener>(args[0]);

	if (listener) { self->AddThumbnailListener(listener); }

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ThumbnailBridge::setScrollPlayerImages(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		ScriptObject option = args[0];
		std::vector<std::string> srcList;

		for (int i = 1;; i++)
		{
			char srcN[7];
			SNPRINTF(srcN, 7, "src%d", i);
			if (!option.has(srcN))
			{
				break;
			}
			std::string src = option.get(srcN).asString();
			srcList.push_back(src);
		}
				
		self->SetScrollPlayerImages(srcList);
	}
	return ScriptObject();
}

#ifndef WIN32
Bridge::ScriptObject Bridge::ThumbnailBridge::setVideoActorAttr(CThumbnail* self, const ScriptArray& args)
{
	CVideoActor* videoActor = self->VideoActor();
	if (videoActor == NULL)
	{
		throw VoltJsRuntimeException("This thumbnail has no video type!");
	}
	else 
	{
		if (args.Length() > 0)
		{	
			ScriptObject options = args[0];
			if (options.has("x"))
			{
				float x = (float)options.get("x").asNumber();
				videoActor->setX(x);
			}
			if (options.has("y"))
			{
				float y = (float)options.get("y").asNumber();
				videoActor->setY(y);
			}
			if (options.has("width"))
			{
				float width = (float)options.get("width").asNumber();
				videoActor->setWidth(width);
			}
			if (options.has("height"))
			{
				float height = (float)options.get("height").asNumber();
				videoActor->setHeight(height);
			}
			if (options.has("type"))
			{
				std::string typeStr = options.get("type").asString();
				videoActor->SetVideoType(VideoActorBridge::deserializeType(typeStr));
			}
			if (options.has("uri"))
			{
				std::string uriStr = options.get("uri").asString();
				videoActor->SetUri(uriStr);
			}
		}
	}
	
	return ScriptObject();
}
ScriptObject ThumbnailBridge::play(CThumbnail* self, const ScriptArray &args)
{
	CVideoActor* videoActor = self->VideoActor();
	if (videoActor == NULL)
	{
		throw VoltJsRuntimeException("This thumbnail has no video type!");
	}
	else
	{
	    return ScriptObject(videoActor->Play());
	}
	return ScriptObject();
}
ScriptObject ThumbnailBridge::stop(CThumbnail* self, const ScriptArray &args)
{
	CVideoActor* videoActor = self->VideoActor();
	if (videoActor == NULL)
	{
		throw VoltJsRuntimeException("This thumbnail has no video type!");
	}
	else
	{
	    return ScriptObject(videoActor->Stop());
	}
	return ScriptObject();
}
ScriptObject ThumbnailBridge::pause(CThumbnail* self, const ScriptArray &args)
{		
	CVideoActor* videoActor = self->VideoActor();
	if (videoActor == NULL)
	{
		throw VoltJsRuntimeException("This thumbnail has no video type!");
	}
	else
	{
	    return ScriptObject(videoActor->Pause());
	}
	return ScriptObject();
}
#endif

ScriptObject ThumbnailBridge::scaleElement(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		if (args.has(2))
		{
			self->Scale(TValue2f(args[0].asNumber(), args[1].asNumber()), args[2].asNumber(), true);
		}
		else
		{
			self->Scale(TValue2f(args[0].asNumber(), args[1].asNumber()), true);
		}
	}

	return ScriptObject();
}

ScriptObject ThumbnailBridge::enableFontScale(CThumbnail* self, const ScriptArray& args)
{
	bool enable = true;
	if (args.Length() > 0)
	{
		if (args[0].isBool()) { enable = args[0].asBool(); }
	}
	self->enableFontScale(enable);

	return ScriptObject();
}

ScriptObject ThumbnailBridge::SetTTSText(CThumbnail* self, const ScriptArray& args)
{

	std::string ttsText;
	if (args.Length() > 0)
	{
		ScriptObject object = args[0];
		ARG_IS_VALID(object, "text", isString);
		ttsText = object.get("text").asString();

		self->SetTTSText(ttsText.c_str());
	}
				
	return ScriptObject();
}		

ScriptObject ThumbnailBridge::getElementAllocation(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args[0].isString())
		{
			TRect alloc;
			std::string eleId = args[0].asString();
			if (0 == eleId.compare("image"))
			{
				self->GetImagePosition(alloc.x, alloc.y);
				self->GetImageSize(alloc.w, alloc.h);
			}
			else if (0 == eleId.substr(0, 4).compare("icon"))
			{
				char buf[7];
				int attachIconNum = self->AttachedIconNumber();
				for (int i = 0; i < attachIconNum; i++)
				{
					SNPRINTF(buf, 7, "icon%d", i + 1);
					if (0 == eleId.compare(buf))
					{
						self->GetAttachIconPosition(i, alloc.x, alloc.y);
						self->GetAttachIconSize(i, alloc.x, alloc.y);
						break;
					}
				}
			}
			else if (0 == eleId.compare("text"))
			{
				self->GetAttachTextPosition(alloc.x, alloc.y);
				self->GetAttachTextSize(alloc.w, alloc.h);
			}
			else if (0 == eleId.compare("checkBox"))
			{
				self->GetCheckBoxPosition(alloc.x, alloc.y);
				self->GetCheckBoxSize(alloc.w, alloc.h);
			}
			else if (0 == eleId.compare("progressBar"))
			{
				self->GetProgressBarPosition(alloc.x, alloc.y);
				self->GetProgressBarSize(alloc.w, alloc.h);
			}
			else if (0 == eleId.compare("information"))
			{
				self->GetInformationPosition(alloc.x, alloc.y);
				self->GetInformationSize(alloc.w, alloc.h);
			}
			else if (0 == eleId.substr(0, 16).compare("information-icon"))
			{
				std::string iconId = eleId.substr(12, 6);
				char buf[7];
				int infoIconNum = self->InformationIconNumber();
				for (int i = 0; i < infoIconNum; i++)
				{
					SNPRINTF(buf, 7, "icon%d", i + 1);
					if (0 == iconId.compare(buf))
					{
						self->GetInformationIconPosition(i, alloc.x, alloc.y);
						self->GetInformationIconSize(i, alloc.x, alloc.y);
						break;
					}
				}
			}
			else if (0 == eleId.substr(0, 16).compare("information-text"))
			{
				std::string textId = eleId.substr(12, 6);
				char buf[7];
				int infoTextNum = self->InformationTextNumber();
				for (int i = 0; i < infoTextNum; i++)
				{
					SNPRINTF(buf, 7, "text%d", i + 1);
					if (0 == textId.compare(buf))
					{
						self->GetInformationTextPosition(i, alloc.x, alloc.y);
						self->GetInformationTextSize(i, alloc.x, alloc.y);
						break;
					}
				}
			}
			
			ScriptObject allocObj = ScriptObject();
			allocObj.set("x", alloc.x);
			allocObj.set("y", alloc.y);
			allocObj.set("width", alloc.w);
			allocObj.set("height", alloc.h);
			return allocObj;
		}
	}
	return ScriptObject();
}

ScriptObject ThumbnailBridge::setElementAllocation(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		if (args[0].isString())
		{
			ScriptObject allocObj = args[1];
			TRect reqAlloc;
			reqAlloc.x = allocObj.has("x") ? allocObj.get("x").asNumber() : INVALID;
			reqAlloc.y = allocObj.has("y") ? allocObj.get("y").asNumber() : INVALID;
			reqAlloc.w = allocObj.has("width") ? allocObj.get("width").asNumber() : INVALID;
			reqAlloc.h = allocObj.has("height") ? allocObj.get("height").asNumber() : INVALID;
			
			TRect alloc;
			std::string eleId = args[0].asString();
			if (0 == eleId.compare("image"))
			{
				self->GetImagePosition(alloc.x, alloc.y);
				self->GetImageSize(alloc.w, alloc.h);
				reqAlloc.x = (reqAlloc.x == INVALID ? alloc.x : reqAlloc.x);
				reqAlloc.y = (reqAlloc.y == INVALID ? alloc.y : reqAlloc.y);
				reqAlloc.w = (reqAlloc.w == INVALID ? alloc.w : reqAlloc.w);
				reqAlloc.h = (reqAlloc.h == INVALID ? alloc.h : reqAlloc.h);
				self->SetImagePosition(reqAlloc.x, reqAlloc.y);
				self->ResizeImage(reqAlloc.w, reqAlloc.h);
			}
			else if (0 == eleId.substr(0, 4).compare("icon"))
			{
				char buf[7];
				int attachIconNum = self->AttachedIconNumber();
				for (int i = 0; i < attachIconNum; i++)
				{
					SNPRINTF(buf, 7, "icon%d", i + 1);
					if (0 == eleId.compare(buf))
					{
						self->GetAttachIconPosition(i, alloc.x, alloc.y);
						self->GetAttachIconSize(i, alloc.w, alloc.h);
						reqAlloc.x = (reqAlloc.x == INVALID ? alloc.x : reqAlloc.x);
						reqAlloc.y = (reqAlloc.y == INVALID ? alloc.y : reqAlloc.y);
						reqAlloc.w = (reqAlloc.w == INVALID ? alloc.w : reqAlloc.w);
						reqAlloc.h = (reqAlloc.h == INVALID ? alloc.h : reqAlloc.h);
						self->SetAttachIconPosition(i, reqAlloc.x, reqAlloc.y);
						self->ResizeAttachIcon(i, reqAlloc.w, reqAlloc.h);
						break;
					}
				}
			}
			else if (0 == eleId.compare("text"))
			{
				self->GetAttachTextPosition(alloc.x, alloc.y);
				self->GetAttachTextSize(alloc.w, alloc.h);
				reqAlloc.x = (reqAlloc.x == INVALID ? alloc.x : reqAlloc.x);
				reqAlloc.y = (reqAlloc.y == INVALID ? alloc.y : reqAlloc.y);
				reqAlloc.w = (reqAlloc.w == INVALID ? alloc.w : reqAlloc.w);
				reqAlloc.h = (reqAlloc.h == INVALID ? alloc.h : reqAlloc.h);
				self->SetAttachTextPosition(reqAlloc.x, reqAlloc.y);
				self->ResizeAttachText(reqAlloc.w, reqAlloc.h);
			}
			else if (0 == eleId.compare("checkBox"))
			{
				self->GetCheckBoxPosition(alloc.x, alloc.y);
				self->GetCheckBoxSize(alloc.w, alloc.h);
				reqAlloc.x = (reqAlloc.x == INVALID ? alloc.x : reqAlloc.x);
				reqAlloc.y = (reqAlloc.y == INVALID ? alloc.y : reqAlloc.y);
				reqAlloc.w = (reqAlloc.w == INVALID ? alloc.w : reqAlloc.w);
				reqAlloc.h = (reqAlloc.h == INVALID ? alloc.h : reqAlloc.h);
				self->SetCheckBoxPosition(reqAlloc.x, reqAlloc.y);
				self->ResizeCheckBox(reqAlloc.w, reqAlloc.h);
			}
			else if (0 == eleId.compare("progressBar"))
			{
				self->GetProgressBarPosition(alloc.x, alloc.y);
				self->GetProgressBarSize(alloc.w, alloc.h);
				reqAlloc.x = (reqAlloc.x == INVALID ? alloc.x : reqAlloc.x);
				reqAlloc.y = (reqAlloc.y == INVALID ? alloc.y : reqAlloc.y);
				reqAlloc.w = (reqAlloc.w == INVALID ? alloc.w : reqAlloc.w);
				reqAlloc.h = (reqAlloc.h == INVALID ? alloc.h : reqAlloc.h);
				self->SetProgressBarPosition(reqAlloc.x, reqAlloc.y);
				self->ResizeProgressBar(reqAlloc.w, reqAlloc.h);
			}
			else if (0 == eleId.compare("information"))
			{
				self->GetInformationPosition(alloc.x, alloc.y);
				self->GetInformationSize(alloc.w, alloc.h);
				reqAlloc.x = (reqAlloc.x == INVALID ? alloc.x : reqAlloc.x);
				reqAlloc.y = (reqAlloc.y == INVALID ? alloc.y : reqAlloc.y);
				reqAlloc.w = (reqAlloc.w == INVALID ? alloc.w : reqAlloc.w);
				reqAlloc.h = (reqAlloc.h == INVALID ? alloc.h : reqAlloc.h);
				self->SetInformationPosition(reqAlloc.x, reqAlloc.y);
				self->ResizeInformation(reqAlloc.w, reqAlloc.h);
			}
			else if (0 == eleId.substr(0, 16).compare("information-icon"))
			{
				std::string iconId = eleId.substr(12, 6);
				char buf[7];
				int infoIconNum = self->InformationIconNumber();
				for (int i = 0; i < infoIconNum; i++)
				{
					SNPRINTF(buf, 7, "icon%d", i + 1);
					if (0 == iconId.compare(buf))
					{
						self->GetInformationIconPosition(i, alloc.x, alloc.y);
						self->GetInformationIconSize(i, alloc.w, alloc.h);
						reqAlloc.x = (reqAlloc.x == INVALID ? alloc.x : reqAlloc.x);
						reqAlloc.y = (reqAlloc.y == INVALID ? alloc.y : reqAlloc.y);
						reqAlloc.w = (reqAlloc.w == INVALID ? alloc.w : reqAlloc.w);
						reqAlloc.h = (reqAlloc.h == INVALID ? alloc.h : reqAlloc.h);
						self->SetInformationIconPosition(i, reqAlloc.x, reqAlloc.y);
						self->ResizeInformationIcon(i, reqAlloc.w, reqAlloc.h);
						break;
					}
				}
			}
			else if (0 == eleId.substr(0, 16).compare("information-text"))
			{
				std::string textId = eleId.substr(12, 6);
				char buf[7];
				int infoTextNum = self->InformationTextNumber();
				for (int i = 0; i < infoTextNum; i++)
				{
					SNPRINTF(buf, 7, "text%d", i + 1);
					if (0 == textId.compare(buf))
					{
						self->GetInformationTextPosition(i, alloc.x, alloc.y);
						self->GetInformationTextSize(i, alloc.w, alloc.h);
						reqAlloc.x = (reqAlloc.x == INVALID ? alloc.x : reqAlloc.x);
						reqAlloc.y = (reqAlloc.y == INVALID ? alloc.y : reqAlloc.y);
						reqAlloc.w = (reqAlloc.w == INVALID ? alloc.w : reqAlloc.w);
						reqAlloc.h = (reqAlloc.h == INVALID ? alloc.h : reqAlloc.h);
						self->SetInformationTextPosition(i, reqAlloc.x, reqAlloc.y);
						self->ResizeInformationText(i, reqAlloc.w, reqAlloc.h);
						break;
					}
				}
			}
		}
	}
	return ScriptObject();
}

ScriptObject ThumbnailBridge::setElementOpacity(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		if (args[0].isString())
		{
			std::string eleId = args[0].asString();
			if (0 == eleId.substr(0, 4).compare("icon"))
			{
				char buf[7];
				int attachIconNum = self->AttachedIconNumber();
				for (int i = 0; i < attachIconNum; i++)
				{
					SNPRINTF(buf, 7, "icon%d", i + 1);
					if (0 == eleId.compare(buf))
					{
						self->SetAttachIconOpacity(i, args[1].asNumber());
						break;
					}
				}
			}
			else if (0 == eleId.compare("text"))
			{
				self->SetAttachTextOpacity(args[1].asNumber());
			}
			else if (0 == eleId.substr(0, 16).compare("information-icon"))
			{
				std::string iconId = eleId.substr(12, 6);
				char buf[7];
				int infoIconNum = self->InformationIconNumber();
				for (int i = 0; i < infoIconNum; i++)
				{
					SNPRINTF(buf, 7, "icon%d", i + 1);
					if (0 == iconId.compare(buf))
					{
						self->SetInformationIconOpacity(i, args[1].asNumber());
						break;
					}
				}
			}
		}
	}
	return ScriptObject();
}

ScriptObject ThumbnailBridge::setDimBackgroundColor(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		Color color = ScriptToColor(args[0]);
		self->SetDimBackgroundColor(color);
	}

	return ScriptObject();
}

ScriptObject ThumbnailBridge::setDimImage(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		std::string dimImage = args[0].asString();
		int opacity = (args.has(1) && args[1].isNumber()) ? args[1].asNumber() : 255;

		self->SetDimImage(dimImage.c_str(), opacity);
	}

	return ScriptObject();
}

ScriptObject ThumbnailBridge::dim(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args[0].isBool())
		{
			self->Dim(args[0].asBool());
		}
	}

	return ScriptObject();
}

ScriptObject ThumbnailBridge::raiseElement(CThumbnail* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args[0].isString())
		{
			std::string eleId = args[0].asString();
			if (0 == eleId.compare("image"))
			{
				self->RaiseImage();
			}
			else if (0 == eleId.substr(0, 4).compare("icon"))
			{
				char buf[7];
				int attachIconNum = self->AttachedIconNumber();
				for (int i = 0; i < attachIconNum; i++)
				{
					SNPRINTF(buf, 7, "icon%d", i + 1);
					if (0 == eleId.compare(buf))
					{
						self->RaiseAttachIcon(i);
						break;
					}
				}
			}
			else if (0 == eleId.compare("text"))
			{
				self->RaiseAttachText();
			}
			else if (0 == eleId.compare("progressBar"))
			{
				self->RaiseProgressBar();
			}
			else if (0 == eleId.compare("checkBox"))
			{
				self->RaiseCheckBox();
			}
			else if (0 == eleId.compare("information"))
			{
				self->RaiseInformation();
			}
		}
	}
	return ScriptObject();
}