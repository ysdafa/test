#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void ProgressBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.captureMethodCall<CProgress, &setProgressColor>("setProgressColor");
	context.captureMethodCall<CProgress, &setBackgroundColor>("setBackgroundColor");
	context.captureMethodCall<CProgress, &setThumbSize>("setThumbSize");
	context.captureMethodCall<CProgress, &addListener>("addListener");
	context.captureMethodCall<CProgress, &removeListener>("removeListener");

	context.bindNumber<CProgress, int, &CProgress::MinValue, &CProgress::SetMinValue>("minValue");
	context.bindNumber<CProgress, int, &CProgress::Value, &CProgress::SetValue>("value");
	context.bindNumber<CProgress, int, &CProgress::MaxValue, &CProgress::SetMaxValue>("maxValue");
	context.bindBoolean<CProgress, &CProgress::FlagReverse, &CProgress::SetReverse>("reverse");
	context.bindBoolean<CProgress, &CProgress::FlagActive, &CProgress::SetActive>("active");
	context.bindString<CProgress, &CProgress::NormalThumbImage, &CProgress::SetNormalThumbImage>("normalThumbImage");
	context.bindString<CProgress, &CProgress::FocusThumbImage, &CProgress::SetFocusThumbImage>("focusThumbImage");

	context.captureMethodCall<CProgress, &setProgressImage>("setProgressImage");
	context.captureMethodCall<CProgress, &setBackgroundImage>("setBackgroundImage");
	context.captureMethodCall<CProgress, &setMinMaxValue>("setMinMaxValue");
	context.captureMethodCall<CProgress, &setValue>("setValue");
	context.captureMethodCall<CProgress, &setReverse>("setReverse");
}

Widget* ProgressBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	ScriptObject options = args[0];
	EDirectionType direction = TYPE_HORIZONTAL;
	if (options.has("direction"))
	{
		std::string directionStr = options.get("direction").asString();
		if (directionStr == "horizontal")
		{
			direction = TYPE_HORIZONTAL;
		}
		else if (directionStr == "vertical")
		{
			direction = TYPE_VERTICAL;
		}
		else
		{
			ASSERT(!"direction should be 'horizontal' or 'vertical'");
		}
	}

	CProgress* progress = dynamic_cast<CProgress *>(IProgress::CreateInstance(parent, width, height, direction));
	if (progress == NULL)
	{
		return NULL;
	}
	progress->setX(x);
	progress->setY(y);
	
	// widget.color property will do the job
	//if (options.has("backgroundColor"))
	//{
	//	ScriptObject val = options.get("backgroundColor");
	//	ClutterColor bgColor;
	//	memset(&bgColor, 0, sizeof(bgColor));
	//	if (val.has("r") || val.has("g") || val.has("b") || val.has("a"))
	//	{
	//		bgColor.red = (val.has("r")) ? val["r"].asNumber() : 0;
	//		bgColor.green = (val.has("g")) ? val["g"].asNumber() : 0;
	//		bgColor.blue = (val.has("b")) ? val["b"].asNumber() : 0;
	//		bgColor.alpha = (val.has("a")) ? val["a"].asNumber() : 255;
	//	}

	//	progress->SetBackgroundColor(bgColor);
	//}

	// progress property
	if (options.has("progressColor"))
	{
		ScriptObject val = options.get("progressColor");
		ClutterColor color;
		memset(&color, 0, sizeof(color));
		if (val.has("r") || val.has("g") || val.has("b") || val.has("a"))
		{
			color.red = (val.has("r")) ? val["r"].asNumber() : 0;
			color.green = (val.has("g")) ? val["g"].asNumber() : 0;
			color.blue = (val.has("b")) ? val["b"].asNumber() : 0;
			color.alpha = (val.has("a")) ? val["a"].asNumber() : 255;
		}

		progress->SetProgressColor(color);
	}

	if (options.has("minValue"))
	{
		int minValue = static_cast<int>(options.get("minValue").asNumber());
		progress->SetMinValue(minValue);
	}

	if (options.has("value"))
	{
		int value = static_cast<int>(options.get("value").asNumber());
		progress->SetValue(value);
	}

	if (options.has("maxValue"))
	{
		int maxValue = static_cast<int>(options.get("maxValue").asNumber());
		progress->SetMaxValue(maxValue);
	}

	if (options.has("reverse"))
	{
		bool reverseFlag = options.get("reverse").asBool();
		progress->SetReverse(reverseFlag);
	}

	if (options.has("active"))
	{
		bool activeFlag = options.get("active").asBool();
		progress->SetActive(activeFlag);
	}

	if (options.has("normalThumbImage"))
	{
		std::string pointingFocusThumbImagePath = options.get("normalThumbImage").asString();
		progress->SetNormalThumbImage(pointingFocusThumbImagePath);
	}

	if (options.has("focusThumbImage"))
	{
		std::string pointingFocusThumbImagePath = options.get("focusThumbImage").asString();
		progress->SetFocusThumbImage(pointingFocusThumbImagePath);
	}

	float thumbWidth = 0;
	float thumbHeight = 0;
	if (options.has("thumbWidth"))
	{
		thumbWidth = static_cast<float>(options.get("thumbWidth").asNumber());
	}
	if (options.has("thumbHeight"))
	{
		thumbHeight = static_cast<float>(options.get("thumbHeight").asNumber());
	}
	progress->SetThumbSize(thumbWidth, thumbHeight);
	
	return progress;
}

ScriptObject ProgressBridge::setProgressColor(CProgress* self, const ScriptArray& args)
{
	guint8 r = 0, g = 0, b = 0, a = 0;

	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) { r = args[0].asNumber(); }
		if (args.has(1) && args[1].isNumber()) { g = args[1].asNumber(); }
		if (args.has(2) && args[2].isNumber()) { b = args[2].asNumber(); }
		if (args.has(3) && args[3].isNumber()) { a = args[3].asNumber(); }
	}
	ClutterColor color = { r, g, b, a };

	self->SetProgressColor(color);

	return ScriptObject();
}

ScriptObject ProgressBridge::setBackgroundColor(CProgress* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 4);
	guint8 r = 0, g = 0, b = 0, a = 0;

	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) { r = args[0].asNumber(); }
		if (args.has(1) && args[1].isNumber()) { g = args[1].asNumber(); }
		if (args.has(2) && args[2].isNumber()) { b = args[2].asNumber(); }
		if (args.has(3) && args[3].isNumber()) { a = args[3].asNumber(); }
	}
	ClutterColor color = { r, g, b, a };

	self->SetBackgroundColor(color);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ProgressBridge::setThumbSize(CProgress* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 2);


	float width = static_cast<float>(args[0].asNumber());
	float height = static_cast<float>(args[1].asNumber());

	self->SetThumbSize(width, height);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ProgressBridge::addListener(CProgress* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IProgressListener* listener = unwrapNativeObject<IProgressListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddListener(listener);
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ProgressBridge::removeListener(CProgress* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IProgressListener* listener = unwrapNativeObject<IProgressListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveListener(listener);
		}
	}
	return ScriptObject();
}

void Bridge::ProgressListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	context.bindFunction<InternalProgressListener, &InternalProgressListener::GetValueChangedCallBack, &InternalProgressListener::SetValueChangedCallBack>("onValueChanged");
}

void* Bridge::ProgressListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalProgressListener;
}

bool Bridge::InternalProgressListener::OnValueChanged(class IProgress* progress)
{
	if (true == ValueChangedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CProgress*>(progress)));
		ValueChangedCb.function.invoke(args);
	}

	return true;

}


ScriptObject ProgressBridge::setProgressImage(CProgress* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);

	IImageBuffer *imageBuffer = unwrapNativeObject<IImageBuffer>(args[0]);
	self->SetProgressImage(imageBuffer);

	return ScriptObject();
}

ScriptObject ProgressBridge::setBackgroundImage(CProgress* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);

	IImageBuffer *imageBuffer = unwrapNativeObject<IImageBuffer>(args[0]);
	self->SetBackgroundImage(imageBuffer);

	return ScriptObject();
}

ScriptObject ProgressBridge::setMinMaxValue(CProgress* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 2);

	int minValue = static_cast<int>(args[0].asNumber());
	self->SetMinValue(minValue);
	int maxValue = static_cast<int>(args[1].asNumber());
	self->SetMaxValue(maxValue);

	return ScriptObject();
}

ScriptObject ProgressBridge::setValue(CProgress* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);

	int value = args[0].asNumber();
	self->SetValue(value);

	return ScriptObject();
}

ScriptObject ProgressBridge::setReverse(CProgress* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);

	bool flag = args[0].asBool();
	self->SetReverse(flag);

	return ScriptObject();
}
