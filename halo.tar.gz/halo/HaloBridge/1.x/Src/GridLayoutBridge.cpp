#include "HaloBridgeAll.h"
#include <string.h>

using namespace Bridge;
using namespace HALO;

void GridLayoutBridge::mapScriptInterface(ScriptContext& context)
{
	LayoutManagerBridge::mapScriptInterface(context);
	context.captureMethodCall<ILayout, &Attach>("attach");
	context.captureMethodCall<ILayout, &ChildAt>("getChildAt");
	context.captureMethodCall<ILayout, &InsertColumn>("insertColumn");
	context.captureMethodCall<ILayout, &InsertRow>("insertRow");
	context.captureMethodCall<ILayout, &InsertNextTo>("insertNextTo");
	context.captureMethodCall<ILayout, &SetDirection>("setDirection");
	context.captureMethodCall<ILayout, &Direction>("getDirection");
	context.captureMethodCall<ILayout, &EnableColumnHomogeneous>("setColumnHomogeneous");
	context.captureMethodCall<ILayout, &IsColumnHomogeneousEnable>("getColumnHomogeneous");
	context.captureMethodCall<ILayout, &EnableRowHomogeneous>("setRowHomogeneous");
	context.captureMethodCall<ILayout, &IsRowHomogeneousEnable>("getRowHomogeneous");
	context.captureMethodCall<ILayout, &SetColumnSpacing>("setColumnSpacing");
	context.captureMethodCall<ILayout, &ColumnSpacing>("getColumnSpacing");
	context.captureMethodCall<ILayout, &SetRowSpacing>("setRowSpacing");
	context.captureMethodCall<ILayout, &RowSpacing>("getRowSpacing");
}

ILayout* GridLayoutBridge::constructWidget(const ScriptArray& args)
{
	IGridLayout *gridlayout = IGridLayout::CreateInstance();
	return gridlayout;
}

ScriptObject GridLayoutBridge::ChildAt(ILayout* self, const ScriptArray& args)
{
	IActor* m_actor = NULL;
	if (args.Length() > 2 && args[1].isNumber() && args[2].isNumber())
	{
		IGridLayout *iLayout = dynamic_cast<IGridLayout*>(self);
		if (iLayout != NULL)
		{
			int left = args[0].asNumber();
			int top = args[1].asNumber();
			m_actor = iLayout->ChildAt(left, top);
		}
	}
	return ScriptObject(m_actor);
}

ScriptObject GridLayoutBridge::Attach(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 4 && args[1].isNumber() && args[2].isNumber() && args[3].isNumber() && args[4].isNumber())
	{
		IGridLayout *iLayout = dynamic_cast<IGridLayout*>(self);
		if (iLayout != NULL)
		{
			CActor* addActor = unwrapNativeObject<CActor>(args[0]);
			if (addActor != NULL)
			{
				iLayout->Attach(addActor, args[1].asNumber(), args[2].asNumber(), args[3].asNumber(), args[4].asNumber());
			}
		}
	}
	return ScriptObject();
}

ScriptObject GridLayoutBridge::InsertColumn(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 0 && args[0].isNumber())
	{
		IGridLayout *iLayout = dynamic_cast<IGridLayout*>(self);
		if (iLayout != NULL)
		{
			iLayout->InsertColumn(args[0].asNumber());
		}
	}
	return ScriptObject();
}

ScriptObject GridLayoutBridge::InsertRow(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 0 && args[0].isNumber())
	{
		IGridLayout *iLayout = dynamic_cast<IGridLayout*>(self);
		if (iLayout != NULL)
		{
			iLayout->InsertRow(args[0].asNumber());
		}
	}
	return ScriptObject();
}

ScriptObject GridLayoutBridge::InsertNextTo(ILayout* self, const ScriptArray& args)
{
	if (args.Length() > 1 && args[1].isString())
	{
		std::string position;
		position = args[1].asString();
		CActor* sibling = unwrapNativeObject<CActor>(args[0]);
		IGridLayout *iLayout = dynamic_cast<IGridLayout*>(self);
		if (iLayout != NULL && sibling != NULL)
		{
			if (position.compare("LEFT") == 0) { iLayout->InsertNextTo(sibling, CLUTTER_GRID_POSITION_LEFT); }
			if (position.compare("RIGHT") == 0) { iLayout->InsertNextTo(sibling, CLUTTER_GRID_POSITION_RIGHT); }
			if (position.compare("TOP") == 0) { iLayout->InsertNextTo(sibling, CLUTTER_GRID_POSITION_TOP); }
			if (position.compare("BOTTOM") == 0) { iLayout->InsertNextTo(sibling, CLUTTER_GRID_POSITION_BOTTOM); }
		}
	}
	return ScriptObject();
}

ScriptObject GridLayoutBridge::SetDirection(ILayout* self, const ScriptArray& args)
{
	IGridLayout *iLayout = dynamic_cast<IGridLayout*>(self);
	if (iLayout != NULL && args.Length() > 0 && args[0].isString())
	{
		/*CLUTTER_ORIENTATION_HORIZONTAL,
		 CLUTTER_ORIENTATION_VERTICAL*/
		std::string orientation;
		orientation = args[0].asString();
		if (orientation.compare("HORIZONTAL") == 0)
		{
			iLayout->SetDirection(CLUTTER_ORIENTATION_HORIZONTAL);
		}
		else if (orientation.compare("VERTICAL") == 0)
		{
			iLayout->SetDirection(CLUTTER_ORIENTATION_VERTICAL);
		}
	}
	return ScriptObject();
}

ScriptObject GridLayoutBridge::Direction(ILayout* self, const ScriptArray& args)
{
	IGridLayout *iLayout = dynamic_cast<IGridLayout*>(self);
	std::string orientation = "";
	if (iLayout != NULL)
	{
		if (iLayout->Direction() == CLUTTER_ORIENTATION_HORIZONTAL)
		{
			orientation = "HORIZONTAL";
		}
		else if (iLayout->Direction() == CLUTTER_ORIENTATION_VERTICAL)
		{
			orientation = "VERTICAL";
		}
	}
	return ScriptObject(orientation);
}

ScriptObject GridLayoutBridge::EnableColumnHomogeneous(ILayout* self, const ScriptArray& args)
{
	IGridLayout *iLayout = dynamic_cast<IGridLayout*>(self);
	if (iLayout != NULL && args.Length() > 0 && args[0].isBool())
	{
		iLayout->EnableColumnHomogeneous(args[0].asBool());
	}
	return ScriptObject();
}

ScriptObject GridLayoutBridge::IsColumnHomogeneousEnable(ILayout* self, const ScriptArray& args)
{
	IGridLayout *iLayout = dynamic_cast<IGridLayout*>(self);
	bool flag = false;
	if (iLayout != NULL)
	{
		flag = iLayout->IsColumnHomogeneousEnable();
	}
	return ScriptObject(flag);
}

ScriptObject GridLayoutBridge::EnableRowHomogeneous(ILayout* self, const ScriptArray& args)
{
	IGridLayout *iLayout = dynamic_cast<IGridLayout*>(self);
	if (iLayout != NULL && args.Length() > 0 && args[0].isBool())
	{
		iLayout->EnableRowHomogeneous(args[0].asBool());
	}
	return ScriptObject();
}

ScriptObject GridLayoutBridge::IsRowHomogeneousEnable(ILayout* self, const ScriptArray& args)
{
	IGridLayout *iLayout = dynamic_cast<IGridLayout*>(self);
	bool flag = false;
	if (iLayout != NULL)
	{
		flag = iLayout->IsRowHomogeneousEnable();
	}
	return ScriptObject(flag);
}

ScriptObject GridLayoutBridge::SetColumnSpacing(ILayout* self, const ScriptArray& args)
{
	IGridLayout *iLayout = dynamic_cast<IGridLayout*>(self);
	if (iLayout != NULL && args.Length() > 0 && args[0].isNumber())
	{
		iLayout->SetColumnSpacing(args[0].asNumber());
	}
	return ScriptObject();
}

ScriptObject GridLayoutBridge::ColumnSpacing(ILayout* self, const ScriptArray& args)
{
	IGridLayout *iLayout = dynamic_cast<IGridLayout*>(self);
	int spacing = -1;
	if (iLayout != NULL)
	{
		spacing = iLayout->ColumnSpacing();
	}
	return ScriptObject(spacing);
}

ScriptObject GridLayoutBridge::SetRowSpacing(ILayout* self, const ScriptArray& args)
{
	IGridLayout *iLayout = dynamic_cast<IGridLayout*>(self);
	if (iLayout != NULL && args.Length() > 0 && args[0].isNumber())
	{
		iLayout->SetRowSpacing(args[0].asNumber());
	}
	return ScriptObject();
}

ScriptObject GridLayoutBridge::RowSpacing(ILayout* self, const ScriptArray& args)
{
	IGridLayout *iLayout = dynamic_cast<IGridLayout*>(self);
	int spacing = -1;
	if (iLayout != NULL)
	{
		spacing = iLayout->RowSpacing();
	}
	return ScriptObject(spacing);
}
