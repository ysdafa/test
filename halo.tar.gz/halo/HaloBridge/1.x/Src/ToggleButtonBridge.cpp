#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void Bridge::ToggleButtonBridge::mapScriptInterface( ScriptContext& context )
{
	ActorBridge::mapScriptInterface(context);
	context.captureMethodCall<CToggleButton, &setCheckImage>("setCheckImage");
	context.captureMethodCall<CToggleButton, &setImage>("setImage");
	context.captureMethodCall<CToggleButton, &setText>("setText");
	context.captureMethodCall<CToggleButton, &setTextFontSize>("setTextFontSize");
	context.captureMethodCall<CToggleButton, &setCheck>("setCheck");
	context.captureMethodCall<CToggleButton, &enableChecked>("enableChecked");
	context.captureMethodCall<CToggleButton, &isChecked>("isChecked");
}

IActor* Bridge::ToggleButtonBridge::constructWidget(IActor* parent, float width, float height ,const ScriptObject& argObject)
{

	ARG_IS_VALID(argObject, "xPos", isNumber);
	ARG_IS_VALID(argObject, "yPos", isNumber);
	ARG_IS_VALID(argObject, "listListenerCallback", isFunction);

	IToggleButton* toggleButton;
	IToggleButton::TToggleButtonAttr attr;
	float xPos = 0 ,yPos = 0;
	xPos = (float)(argObject.get("xPos").asNumber());
	yPos = (float)(argObject.get("yPos").asNumber());
	attr.xPos = xPos;
	attr.yPos = yPos;
	attr.width = width;
	attr.height = height;
	toggleButton =  IToggleButton::CreateInstance(parent, attr);
	if(toggleButton)
	{
		toggleButton->AddListener(this);
	}
	m_listListenerCallback = argObject.get("listListenerCallback").asFunction();
	return toggleButton;
}

Bridge::ScriptObject Bridge::ToggleButtonBridge::setCheckImage( CToggleButton* self, const ScriptArray& args )
{
	if (args.Length() > 0)
	{
		ScriptObject object = args[0];
		ARG_IS_VALID(object, "state", isString);
		ARG_IS_VALID(object, "width", isNumber);
		ARG_IS_VALID(object, "height", isNumber);
		std::string state = object.get("state").asString();
		float width =  object.get("width").asNumber();
		float height =  object.get("height").asNumber();

		if (true == object.has("imageBuffer"))
		{
			IImageBuffer* imageBuffer = unwrapNativeObject<IImageBuffer>(object.get("imageBuffer"));
			if (imageBuffer != nullptr)
			{
				self->SetCheckImage(deserializeCheckState(state, IToggleButton::E_STATE_OFF), imageBuffer, width, height);
				return ScriptObject();
			}
			else
			{
				return ScriptException("Non-imageBuffer passed as argument to Button.setImage");
			}
		}
		else
		{
			return ScriptException("Arguments to Button.setImage need a member named imageBuffer");
		}
	}
	return ScriptException("Button.setImage expects a parameter");
}

Bridge::ScriptObject Bridge::ToggleButtonBridge::setImage( CToggleButton* self, const ScriptArray& args )
{
	if (args.Length() > 0)
	{
		ScriptObject object = args[0];
		ARG_IS_VALID(object, "state", isString);
		std::string state = object.get("state").asString();

		if (true == object.has("imageBuffer"))
		{
			IImageBuffer* imageBuffer = unwrapNativeObject<IImageBuffer>(object.get("imageBuffer"));
			if (imageBuffer != nullptr)
			{
				self->SetImage(deserializeItemState(state, IToggleButton::E_STATE_NORMAL), imageBuffer);
				return ScriptObject();
			}
			else
			{
				return ScriptException("Non-imageBuffer passed as argument to Button.setImage");
			}
		}
		else
		{
			return ScriptException("Arguments to Button.setImage need a member named imageBuffer");
		}
	}
	return ScriptException("Button.setImage expects a parameter");
}

Bridge::ScriptObject Bridge::ToggleButtonBridge::setText( CToggleButton* self, const ScriptArray& args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	ARG_IS_VALID(object, "state", isString);
	ARG_IS_VALID(object, "text", isString);
	std::string state = object.get("state").asString();
	std::string textContent = object.get("text").asString();
	self->SetText(deserializeCheckState(state, IToggleButton::E_STATE_OFF), textContent.c_str());
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToggleButtonBridge::setTextFontSize( CToggleButton* self, const ScriptArray& args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	ARG_IS_VALID(object, "state", isString);
	ARG_IS_VALID(object, "fontsize", isNumber);
	std::string state = object.get("state").asString();
	int fontsize = object.get("fontsize").asNumber();
	self->SetTextFontSize(deserializeCheckState(state, IToggleButton::E_STATE_OFF), fontsize);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToggleButtonBridge::setCheck( CToggleButton* self, const ScriptArray& args )
{
	ScriptObject object = args[0];
	ARG_IS_VALID(object, "ischecked", isBool);
	bool ischecked = object.get("ischecked").asBool();
	self->SetCheck(ischecked);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToggleButtonBridge::enableChecked( CToggleButton* self, const ScriptArray& args )
{
	ScriptObject object = args[0];
	ARG_IS_VALID(object, "isEnableChecked", isBool);
	bool isEnableChecked = object.get("isEnableChecked").asBool();
	self->EnableChecked(isEnableChecked);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToggleButtonBridge::isChecked( CToggleButton* self, const ScriptArray& args )
{

	return ScriptObject(self->IsChecked());
}

void Bridge::ToggleButtonBridge::OnToggleOn( class IToggleButton *togglebutton )
{
	ScriptArray args;
	args.set(0, ScriptObject((int)TOGGLE_ON));
	args.set(1, wrapExistingNativeObject(togglebutton));
	m_listListenerCallback.invoke(args);
}

void Bridge::ToggleButtonBridge::OnToggleOff( class IToggleButton *togglebutton )
{
	ScriptArray args;
	args.set(0, ScriptObject((int)TOGGLE_OFF));
	args.set(1, wrapExistingNativeObject(togglebutton));
	m_listListenerCallback.invoke(args);
}

IToggleButton::EItemState Bridge::ToggleButtonBridge::deserializeItemState( std::string stateStr, IToggleButton::EItemState theDefault )
{
	if (compareStrChar(stateStr, "all")) 
	{
		return IToggleButton::E_STATE_ALL;
	}
	if (compareStrChar(stateStr, "disable"))
	{
		return IToggleButton::E_STATE_DISABLED;
	}
	if (compareStrChar(stateStr, "focus"))
	{
		return IToggleButton::E_STATE_FOCUSED;
	}
	if (compareStrChar(stateStr, "highlighted"))
	{
		return IToggleButton::E_STATE_HIGHLIGHTED;
	}
	if (compareStrChar(stateStr, "normal"))
	{
		return IToggleButton::E_STATE_NORMAL;
	}
	else 
	{
		return theDefault;
	}
}

IToggleButton::ECheckState Bridge::ToggleButtonBridge::deserializeCheckState( std::string stateStr, IToggleButton::ECheckState theDefault )
{
	if (compareStrChar(stateStr, "on"))
	{
		return IToggleButton::E_STATE_ON;
	}
	if (compareStrChar(stateStr, "off"))
	{
		return IToggleButton::E_STATE_OFF;
	}
	else 
	{
		return theDefault;
	}
}

Bridge::ScriptObject Bridge::ToggleButtonBridge::addlistener( CToggleButton* self, const ScriptArray& args )
{
	if (args.Length() > 0)
	{
		ToggleButtonListener* listener = unwrapNativeObject<ToggleButtonListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddListener(listener);
		}
	}
	return ScriptObject();
}
