#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void PageControlBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.captureMethodCall<CPageControl, &setCurrentPage>("setCurrentPage");
	context.captureMethodCall<CPageControl, &setNumberOfPages>("setNumberOfPages");
	context.captureMethodCall<CPageControl, &setPageIndicatorImage>("setPageIndicatorImage");
	context.captureMethodCall<CPageControl, &setHighlightPageIndicatorImage>("setHighlightPageIndicatorImage");
	context.captureMethodCall<CPageControl, &setPageIndicatorGap>("setPageIndicatorGap");
	context.captureMethodCall<CPageControl, &setHideForSinglePageFlag>("setHideForSinglePageFlag");
	context.captureMethodCall<CPageControl, &setPageIndicatorImageSize>("setPageIndicatorImageSize");
}

Widget* PageControlBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	CPageControl* pageControl = dynamic_cast<CPageControl *>(IPageControl::CreateInstance(parent, width, height));
	return pageControl;
}

ScriptObject PageControlBridge::setCurrentPage(CPageControl* self, const ScriptArray& args)
{
	int curPage = static_cast<int>(args[0].asNumber());
	self->SetCurrentPage(curPage);

	return ScriptObject();
}

ScriptObject PageControlBridge::setNumberOfPages(CPageControl* self, const ScriptArray& args)
{
	int numberOfPages = static_cast<int>(args[0].asNumber());
	self->SetNumberOfPages(numberOfPages);

	return ScriptObject();
}

//ScriptObject PageControlBridge::setPageIndicatorTintColor(CPageControl* self, const ScriptArray& args)
//{
//	guint8 r, g, b, a;
//	r = g = b = a = 0;
//
//	if (args.Length() > 0)
//	{
//		if (args.has(0) && args[0].isNumber())
//		{
//			r = static_cast<guint8>(args[0].asNumber());
//		}
//		if (args.has(1) && args[1].isNumber())
//		{
//			g = static_cast<guint8>(args[1].asNumber());
//		}
//		if (args.has(2) && args[2].isNumber())
//		{
//			b = static_cast<guint8>(args[2].asNumber());
//		}
//		if (args.has(3) && args[3].isNumber())
//		{
//			a = static_cast<guint8>(args[3].asNumber());
//		}
//	}
//	ClutterColor c = { r, g, b, a };
//
//	IPageControl *pageControl = dynamic_cast<IPageControl*>(self);
//	if (pageControl != NULL)
//	{
//		//pageControl->SetPageIndicatorTintColor(c);
//	}
//
//	return ScriptObject();
//}
//
//ScriptObject PageControlBridge::setCurrentPageIndicatorTintColor(CPageControl* self, const ScriptArray& args)
//{
//	guint8 r, g, b, a;
//	r = g = b = a = 0;
//
//	if (args.Length() > 0)
//	{
//		if (args.has(0) && args[0].isNumber()) 
//		{
//			r = static_cast<guint8>(args[0].asNumber());
//		}
//		if (args.has(1) && args[1].isNumber())
//		{
//			g = static_cast<guint8>(args[1].asNumber());
//		}
//		if (args.has(2) && args[2].isNumber()) 
//		{
//			b = static_cast<guint8>(args[2].asNumber());
//		}
//		if (args.has(3) && args[3].isNumber()) 
//		{
//			a = static_cast<guint8>(args[3].asNumber());
//		}
//	}
//	ClutterColor c = { r, g, b, a };
//
//	IPageControl *pageControl = dynamic_cast<IPageControl*>(self);
//	if (pageControl != NULL)
//	{
//		//pageControl->SetCurrentPageIndicatorTintColor(c);
//	}
//
//	return ScriptObject();
//}

ScriptObject PageControlBridge::setHideForSinglePageFlag(CPageControl* self, const ScriptArray& args)
{
	bool hideFlag = args[0].asBool();
	self->SetHideForSinglePageFlag(hideFlag);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::PageControlBridge::setPageIndicatorImage(CPageControl* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IImageBuffer* buffer = unwrapNativeObject<IImageBuffer>(args[0]);
		self->SetPageIndicatorImage(buffer);
	}

	return ScriptObject();
}

Bridge::ScriptObject Bridge::PageControlBridge::setHighlightPageIndicatorImage(CPageControl* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		IImageBuffer* buffer = unwrapNativeObject<IImageBuffer>(args[0]);
		self->SetHighlightPageIndicatorImage(buffer);
	}

	return ScriptObject();
}

Bridge::ScriptObject Bridge::PageControlBridge::setPageIndicatorGap(CPageControl* self, const ScriptArray& args)
{
	double gap = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) { gap = (int)args[0].asNumber(); }
	}
	self->SetPageIndicatorGap(static_cast<float>(gap));

	return ScriptObject();
}

Bridge::ScriptObject Bridge::PageControlBridge::setPageIndicatorImageSize(CPageControl* self, const ScriptArray& args)
{
	double width = 0;
	double height = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) { width = (int)args[0].asNumber(); }
		if (args.has(1) && args[1].isNumber()) { height = (int)args[1].asNumber(); }
	}
	self->SetPageIndicatorImageSize(static_cast<float>(width), static_cast<float>(height));

	return ScriptObject();
}

