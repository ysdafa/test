#include "HaloBridgeAll.h"

using namespace HALO;
using namespace Bridge;



void Bridge::SelectButtonBridge::mapScriptInterface( ScriptContext& context )
{
	ActorBridge::mapScriptInterface(context);
	context.bindBoolean<CSelectButton, &CSelectButton::AsyncLoading, &CSelectButton::SetAsyncLoading>("asyncLoading");
	context.captureMethodCall<CSelectButton, &setItemText>("setItemText");
	context.captureMethodCall<CSelectButton, &itemText>("itemText");
	context.captureMethodCall<CSelectButton, &setItemTextFontSize>("setItemTextFontSize");
	context.captureMethodCall<CSelectButton, &setItemTextColor>("setItemTextColor");
	context.captureMethodCall<CSelectButton, &setTextFont>("setTextFont");
	context.captureMethodCall<CSelectButton, &textFont>("textFont");
	context.captureMethodCall<CSelectButton, &setBoxBackGroudImage>("setBoxBackGroudImage");
	context.captureMethodCall<CSelectButton, &setCheckImage>("setCheckImage");
	context.captureMethodCall<CSelectButton, &updateImageAttr>("updateImageAttr");
	context.captureMethodCall<CSelectButton, &setId>("setId");
	context.captureMethodCall<CSelectButton, &getId>("getId");

	context.captureMethodCall<CSelectButton, &setTextAlignment>("setTextAlignment");
	context.captureMethodCall<CSelectButton, &show>("show");
	context.captureMethodCall<CSelectButton, &setCheck>("setCheck");
	context.captureMethodCall<CSelectButton, &isChecked>("isChecked");
	context.captureMethodCall<CSelectButton, &enableChecked>("enableChecked");
	context.captureMethodCall<CSelectButton, &setBoxBackGroudImageOpacity>("setBoxBackGroudImageOpacity");
	context.captureMethodCall<CSelectButton, &setCheckImageOpacity>("setCheckImageOpacity");
	context.captureMethodCall<CSelectButton, &setAttachText>("setAttachText");
	context.captureMethodCall<CSelectButton, &reSize>("reSize");
	context.captureMethodCall<CSelectButton, &setFocusState>("setFocusState");
	
}

Widget* SelectButtonBridge::constructWidget( float x, float y, float width, float height, Widget* parent, const ScriptArray& args )
{
	if (width < 0)
	{
		width = 0;
	}
	if (height < 0) 
	{ 
		height = 0; 
	}
	int argsLen = args.Length();
	ScriptObject options;
	if (argsLen > 0)
	{
		options = args[0];
	}
	CSelectButton* button = new CSelectButton;
	if (options.has("isAutoFocus"))
	{
		bool isAutoFocus = options.get("isAutoFocus").asBool();
		button->SetAutoFocusFlag(isAutoFocus);
	}
	button->Initialize(parent, width, height);
	button->SetPosition(x, y);
	
	return button;
}

CSelectButton::EItemState SelectButtonBridge::deserializeState( std::string stateStr, CSelectButton::EItemState theDefault )
{
	if (compareStrChar(stateStr, "normal"))
	{
		return CSelectButton::E_STATE_NORMAL;
	}
	else if (compareStrChar(stateStr, "focused"))
	{
		return CSelectButton::E_STATE_FOCUSED;
	}
	else if (compareStrChar(stateStr, "selected"))
	{
		return CSelectButton::E_STATE_SELECTED;
	}
	else if (compareStrChar(stateStr, "disabled"))
	{
		return CSelectButton::E_STATE_DISABLED;
	}
	else if (compareStrChar(stateStr, "all"))
	{
		return CSelectButton::E_STATE_ALL;
	}
	else
	{
		ASSERT(false && "The state string is invalid!");
		return theDefault;
	}
}

Bridge::ScriptObject SelectButtonBridge::setItemText( CSelectButton* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string state = object.get("state").asString();
	std::string textContent = object.get("text").asString();
	const char* text =  textContent.c_str();
	self->SetItemText(deserializeState(state, CSelectButton::E_STATE_NORMAL), text);
	return ScriptObject();
}

Bridge::ScriptObject SelectButtonBridge::itemText( CSelectButton* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string state = object.get("state").asString();
	return ScriptObject(self->ItemText(deserializeState(state, CSelectButton::E_STATE_NORMAL)));
}

Bridge::ScriptObject SelectButtonBridge::setItemTextFontSize( CSelectButton* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string state = object.get("state").asString();
	int fontSize = (int)object.get("fontSize").asNumber();
	self->SetItemTextFontSize(deserializeState(state, CSelectButton::E_STATE_NORMAL), fontSize);
	return ScriptObject();
}

Bridge::ScriptObject SelectButtonBridge::setItemTextColor( CSelectButton* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string state = object.get("state").asString();
	ScriptObject colorObj = object.get("color");
	Color color = ScriptToColor(colorObj);
	self->SetItemTextColor(deserializeState(state, CSelectButton::E_STATE_NORMAL), *(color.toClutterColor()));
	return ScriptObject();
}

Bridge::ScriptObject SelectButtonBridge::setTextFont( CSelectButton* self, const ScriptArray &args )
{


	return ScriptObject();
}

Bridge::ScriptObject SelectButtonBridge::textFont( CSelectButton* self, const ScriptArray &args )
{


	return ScriptObject();
}

Bridge::ScriptObject SelectButtonBridge::setBoxBackGroudImage( CSelectButton* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string state = object.get("state").asString();
	std::string imagePath = object.get("imageSrc").asString();
	self->SetBoxBackGroudImage(deserializeState(state, ISelectButton::E_STATE_NORMAL), imagePath);
	return ScriptObject();
}

Bridge::ScriptObject SelectButtonBridge::setCheckImage( CSelectButton* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string state = object.get("state").asString();
	std::string imagePath = object.get("imageSrc").asString();
	self->SetCheckImage(deserializeState(state, ISelectButton::E_STATE_NORMAL), imagePath);
	return ScriptObject();
}

Bridge::ScriptObject SelectButtonBridge::updateImageAttr( CSelectButton* self, const ScriptArray &args )
{
	ScriptObject options = args[0];
	float x , y, w ,h;
	x = y = w = h = 0.0;
	
	if (options.has("x"))
	{
		x = (float)options.get("x").asNumber();	
	}
	if (options.has("y"))
	{
		y = (float)options.get("y").asNumber();	
	}
	if (options.has("width")) 
	{
		w = (float)options.get("width").asNumber();	
	}
	if (options.has("height"))
	{
		h = (float)options.get("height").asNumber();
	}
	self->UpdateImageAttr(x , y , w , h);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::SelectButtonBridge::setAttachText( CSelectButton* self, const ScriptArray &args )
{
	ScriptObject options = args[0];
	float x , y, w ,h;
	x = y = w = h = 0.0;
	
	if (options.has("x"))
	{
		x = (float)options.get("x").asNumber();	
	}
	if (options.has("y"))
	{
		y = (float)options.get("y").asNumber();	
	}
	if (options.has("width")) 
	{
		w = (float)options.get("width").asNumber();	
	}
	if (options.has("height"))
	{
		h = (float)options.get("height").asNumber();
	}
	self->SetAttachText(x , y , w , h);
	return ScriptObject();
}



Bridge::ScriptObject SelectButtonBridge::setId( CSelectButton* self, const ScriptArray &args )
{
	ScriptObject object = args[0];
	int id = object.get("id").asNumber();
	self->SetId(id);
	return ScriptObject();
}

Bridge::ScriptObject SelectButtonBridge::getId( CSelectButton* self, const ScriptArray &args )
{
	return ScriptObject(self->GetId());
}

Bridge::ScriptObject SelectButtonBridge::setTextAlignment( CSelectButton* self, const ScriptArray &args )
{
	return ScriptObject();
}

Bridge::ScriptObject SelectButtonBridge::show( CSelectButton* self, const ScriptArray &args )
{
	self->Show();
	return ScriptObject();
}

Bridge::ScriptObject SelectButtonBridge::setCheck( CSelectButton* self, const ScriptArray &args )
{
	ScriptObject object = args[0];
	bool ischecked = object.get("ischecked").asBool();
	self->SetCheck(ischecked);
	return ScriptObject();
}

Bridge::ScriptObject SelectButtonBridge::isChecked( CSelectButton* self, const ScriptArray &args )
{
	return ScriptObject(self->IsChecked());
}

Bridge::ScriptObject SelectButtonBridge::enableChecked( CSelectButton* self, const ScriptArray &args )
{
	ScriptObject object = args[0];
	bool isenablechecked = object.get("isenablechecked").asBool();
	self->EnableChecked(isenablechecked);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::SelectButtonBridge::setBoxBackGroudImageOpacity( CSelectButton* self, const ScriptArray &args )
{
	ScriptObject object = args[0];
	std::string state = object.get("state").asString();
	int opacitty = object.get("opacity").asNumber();
	self->SetBoxBackGroudImageOpacity(deserializeState(state, CSelectButton::E_STATE_NORMAL), opacitty);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::SelectButtonBridge::setCheckImageOpacity( CSelectButton* self, const ScriptArray &args )
{
	ScriptObject object = args[0];
	std::string state = object.get("state").asString();
	int opacitty = object.get("opacity").asNumber();
	self->SetCheckImageOpacity(deserializeState(state, CSelectButton::E_STATE_NORMAL), opacitty);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::SelectButtonBridge::setFocusState( CSelectButton* self, const ScriptArray &args )
{
	ScriptObject object = args[0];
	bool isFocused= object.get("isFocused").asBool();
	self->SetFocusState(isFocused);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::SelectButtonBridge::reSize( CSelectButton* self, const ScriptArray &args )
{
	ScriptObject object = args[0];
	float w = object.get("w").asNumber();
	float h = object.get("h").asNumber();
	self->Resize(w , h);
	return ScriptObject();
}
