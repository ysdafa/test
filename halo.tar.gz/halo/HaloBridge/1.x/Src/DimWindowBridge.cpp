#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void DimWindowBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.captureMethodCall<CDimWindow, &addTransparentArea>("addTransparentArea");
	context.captureMethodCall<CDimWindow, &clearTransparentArea>("clearTransparentArea");
}

void* DimWindowBridge::constructFromScript(const ScriptArray& args)
{
	Widget *cWidget = (Widget*)WidgetBridge::constructFromScript(args);
	CDimWindow *dimWin = dynamic_cast<CDimWindow*>(cWidget);
	if (dimWin)
	{
		dimWin->SetBackgroundColor(*dimWin->getColor().toClutterColor());
		dimWin->setColor(Color(0, 0, 0, 0));
	}

	return cWidget;
}

Widget* DimWindowBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	IDimWindow* dimWin = IDimWindow::CreateInstance(parent, width, height);
	if (dimWin)
	{
		dimWin->SetPosition(x, y);
	}

	CDimWindow* cDimWin = dynamic_cast<CDimWindow*>(dimWin);

	return cDimWin;
}

ScriptObject DimWindowBridge::addTransparentArea(CDimWindow* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		ScriptObject obj = args[0];
		int x = obj.has("x") ? obj.get("x").asNumber() : 0;
		int y = obj.has("y") ? obj.get("y").asNumber() : 0;
		int width = obj.has("width") ? obj.get("width").asNumber() : 0;
		int height = obj.has("height") ? obj.get("height").asNumber() : 0;
		
		self->AddTransparentArea(x, y, width, height);
	}
	
	return ScriptObject();
}

ScriptObject DimWindowBridge::clearTransparentArea(CDimWindow* self, const ScriptArray& args)
{
	self->ClearTransparentArea();

	return ScriptObject();
}
