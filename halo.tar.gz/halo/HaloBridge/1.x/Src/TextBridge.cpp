#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void TextBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.captureMethodCall<CText, &enableMultline>("enableMultline");
	context.captureMethodCall<CText, &setTextColor>("setTextColor");
	context.captureMethodCall<CText, &setText>("setText");
	context.captureMethodCall<CText, &setFont>("setFont");
	context.captureMethodCall<CText, &setTextAlignment>("setTextAlignment");
	context.captureMethodCall<CText, &setRowGap>("setRowGap");
	context.captureMethodCall<CText, &setMaxTextCount>("setMaxTextCount");
	context.captureMethodCall<CText, &setFontSize>("setFontSize");
	context.captureMethodCall<CText, &enableShadow>("enableShadow");
	context.captureMethodCall<CText, &setShadowPosition>("setShadowPosition");
	context.captureMethodCall<CText, &setShadowColor>("setShadowColor");
	context.captureMethodCall<CText, &enableEllipsis>("enableEllipsis");
	context.captureMethodCall<CText, &setScrollAttribute>("setScrollAttribute");
	context.captureMethodCall<CText, &startScroll>("startScroll");
	context.captureMethodCall<CText, &stopScroll>("stopScroll");
	//context.captureMethodCall<CText, &reSize>("reSize");
}

IActor* TextBridge::constructWidget(IActor* parent, float width, float height, const ScriptObject& argObject)
{
	std::string text, font;
	ScriptArray arg;

	if(width == -1) 
	{
		width = 0;
	}
	if(height == -1) 
	{
		height = 0;
	}

	IText* iText;	
	iText = IText::CreateInstance(parent, width, height);

	if(iText != NULL)
	{
		if(argObject.has("font")) 
		{
			font = argObject.get("font").asString();
			iText->SetFont(font.c_str());
		}

		if(argObject.has("text")) 
		{
			text = argObject.get("text").asString();
			iText->SetText(text.c_str());
		}
	}
	return iText;
}

Widget* TextBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	ScriptObject argObject = args[0];

	std::string text, font;
	ScriptArray arg;

	if(width == -1) 
	{
		width = 0;
	}
	if(height == -1)
	{
		height = 0;
	}

	CText *cText = dynamic_cast<CText*>(IText::CreateInstance(parent, width, height));

	if(cText != NULL)
	{
		if(argObject.has("font")) 
		{
			font = argObject.get("font").asString();
			cText->SetFont(font.c_str());
		}

		if(argObject.has("text")) 
		{
			text = argObject.get("text").asString();
			cText->SetText(text.c_str());
		}
	}
	return cText;
}

ScriptObject TextBridge::setTextColor(CText* self, const ScriptArray& args)
{ 
	IText *iText = dynamic_cast<IText*>(self);
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber()) {r = (guint8)args[0].asNumber();}
		if (args.has(1) && args[1].isNumber()) {g = (guint8)args[1].asNumber();}
		if (args.has(2) && args[2].isNumber()) {b = (guint8)args[2].asNumber();}
		if (args.has(3) && args[3].isNumber()) {a = (guint8)args[3].asNumber();}
	}
	ClutterColor c = {r, g, b, a};
	if (iText != NULL)
	{
		iText->SetTextColor(c);
	}
	return ScriptObject();
}

ScriptObject TextBridge::enableMultline(CText* self, const ScriptArray& args)
{
	IText *iText = dynamic_cast<IText*>(self);
	bool flag = false;
	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isBool()) 
		{
			flag = args[0].asBool();
		}
	}
	if (iText != NULL)
	{
		iText->EnableMultiLine(flag);
	}
	return ScriptObject();
}

ScriptObject TextBridge::setText(CText* self, const ScriptArray& args)
{
	IText *iText = dynamic_cast<IText*>(self);
	std::string text;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString()) 
		{
			text = args[0].asString();
		}
	}
	if (iText != NULL)
	{
		iText->SetText(text.c_str());
	}
	return ScriptObject();
}

ScriptObject TextBridge::setFont(CText* self, const ScriptArray& args)
{
	IText *iText = dynamic_cast<IText*>(self);
	std::string font;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString()) 
		{
			font = args[0].asString();
		}
	}

	if (iText != NULL)
	{
		iText->SetFont(font.c_str());
	}
	return ScriptObject();
}

ScriptObject TextBridge::setTextAlignment(CText* self, const ScriptArray& args)
{
	IText *iText = dynamic_cast<IText*>(self);
	int h = 0; 
	int v = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {h = (int)args[0].asNumber();}
		if (args.has(1) && args[1].isNumber()) {v = (int)args[1].asNumber();}
	}
	if (iText != NULL)
	{
		iText->SetTextAlignment((EHAlignment)h, (EVAlignment)v);
	}
	return ScriptObject();
}

ScriptObject TextBridge::setRowGap(CText* self, const ScriptArray& args)
{
	IText *iText = dynamic_cast<IText*>(self);
	int gap = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {gap = (int)args[0].asNumber();}
	}
	if (iText != NULL)
	{
		iText->SetRowGap(gap);
	}
	return ScriptObject();
}

ScriptObject TextBridge::setMaxTextCount(CText* self, const ScriptArray& args)
{
	IText *iText = dynamic_cast<IText*>(self);
	int count = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {count = (int)args[0].asNumber();}
	}
	if (iText != NULL)
	{
		iText->SetMaxTextCount(count);
	}
	return ScriptObject();
}

ScriptObject TextBridge::setFontSize(CText* self, const ScriptArray& args)
{
	IText *iText = dynamic_cast<IText*>(self);
	int size = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {size = (int)args[0].asNumber();}
	}
	if (iText != NULL)
	{
		iText->SetFontSize(size);
	}
	return ScriptObject();
}

ScriptObject TextBridge::enableShadow(CText* self, const ScriptArray& args)
{
	IText *iText = dynamic_cast<IText*>(self);
	bool flag = false;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isBool()) {flag = args[0].asBool();}
	}
	if (iText != NULL)
	{
		iText->EnableShadow(flag);
	}
	return ScriptObject();
}

ScriptObject TextBridge::setShadowPosition(CText* self, const ScriptArray& args)
{
	IText *iText = dynamic_cast<IText*>(self);
	int x = 0, y = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {x = (int)args[0].asNumber();}
		if (args.has(1) && args[1].isNumber()) {y = (int)args[1].asNumber();}
	}
	if (iText != NULL)
	{
		iText->SetShadowPosition(x, y);
	}
	return ScriptObject();
}

ScriptObject TextBridge::setShadowColor(CText* self, const ScriptArray& args)
{
	IText *iText = dynamic_cast<IText*>(self);
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 255;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {r = (guint8)args[0].asNumber();}
		if (args.has(1) && args[1].isNumber()) {g = (guint8)args[1].asNumber();}
		if (args.has(2) && args[2].isNumber()) {b = (guint8)args[2].asNumber();}
		if (args.has(3) && args[3].isNumber()) {a = (guint8)args[3].asNumber();}
	}
	ClutterColor c = { r, g, b, a };
	if (iText != NULL)
	{
		iText->SetShadowColor(c);
	}
	return ScriptObject();
}

ScriptObject TextBridge::enableEllipsis(CText* self, const ScriptArray& args)
{
	IText *iText = dynamic_cast<IText*>(self);
	bool flag = false;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isBool())
		{
			flag = args[0].asBool();
		}
	}
	if (iText != NULL)
	{
		iText->EnableEllipsize(flag);
	}
	return ScriptObject();
}

int TextBridge::deserializeScrollType(std::string type)
{
	if (compareStrChar(type, "start_outside_stop_outside"))
	{
		return CLUTTER_TEXT_SCROLL_START_OUTSIDE_STOP_OUTSIDE;
	}
	else if (compareStrChar(type, "start_outside_stop_inside"))
	{
		return CLUTTER_TEXT_SCROLL_START_OUTSIDE_STOP_INSIDE;
	}
	else if (compareStrChar(type, "start_inside_stop_outside"))
	{
		return CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_OUTSIDE;
	}
	else if (compareStrChar(type, "start_inside_stop_inside"))
	{
		return CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_INSIDE;
	}
	else if (compareStrChar(type, "continue_scroll"))
	{
		return CLUTTER_TEXT_SCROLL_CONTINUOUS_SCROLL;
	}
	else
	{
		return CLUTTER_TEXT_SCROLL_START_OUTSIDE_STOP_OUTSIDE;
	}
}

int TextBridge::deserializeScrollDirection(std::string direction)
{
	if (compareStrChar(direction, "forward"))
	{
		return CLUTTER_TIMELINE_FORWARD;
	}
	else if (compareStrChar(direction, "backward"))
	{
		return CLUTTER_TIMELINE_BACKWARD;
	}
	else
	{
		return 0;
	}
}

ScriptObject TextBridge::setScrollAttribute(CText* self, const ScriptArray& args)
{
	IText *iText = dynamic_cast<IText*>(self);
	int duration = 0;
	float speed = 0;
	int delay = 0;
	int repeat = 0;
	int type = 0;
	int direction = 0;
	int continueGap = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) { duration = args[0].asNumber(); }
		if (args.has(1) && args[1].isNumber()) { speed = args[1].asNumber(); }
		if (args.has(2) && args[2].isNumber()) { delay = args[2].asNumber(); }
		if (args.has(3) && args[3].isNumber()) { repeat = args[3].asNumber(); }
		if (args.has(4) && args[4].isString()) { type = deserializeScrollType(args[4].asString()); }
		if (args.has(5) && args[5].isString()) { direction = deserializeScrollDirection(args[5].asString()); }
		if (args.has(6) && args[6].isNumber()) { continueGap = args[6].asNumber(); }
	}
	if (iText != NULL)
	{
		iText->SetScrollAttribute(duration, speed, delay, repeat, (ClutterTextScrollType)type, (ClutterTimelineDirection)direction, continueGap);
	}
	return ScriptObject();
}

ScriptObject TextBridge::startScroll(CText* self, const ScriptArray& args)
{
	IText *iText = dynamic_cast<IText*>(self);
	
	if (iText != NULL)
	{
		iText->StartScrollText();
	}
	return ScriptObject();
}

ScriptObject TextBridge::stopScroll(CText* self, const ScriptArray& args)
{
	IText *iText = dynamic_cast<IText*>(self);

	if (iText != NULL)
	{
		iText->StopScrollText();
	}
	return ScriptObject();
}

//ScriptObject TextBridge::reSize(CText* self, const ScriptArray& args)
//{
//	IText *iText = dynamic_cast<IText*>(self);
//	int x = 0;
//	int y = 0;
//	if (args.Length() > 0)
//	{
//		if (args.has(0) && args[0].isNumber()) { x = (int)args[0].asNumber(); }
//		if (args.has(1) && args[1].isNumber()) { y = (int)args[1].asNumber(); }
//	}
//	if (iText != NULL)
//	{
//		iText->Resize((float)x, (float)y);
//	}
//	return ScriptObject();
//}