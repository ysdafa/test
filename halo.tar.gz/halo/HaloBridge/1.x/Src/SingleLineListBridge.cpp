#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

bool InternalSingleLineListener::OnItemLoaded(class ISingleLineListControl* list, IData *data, int itemIndex)
{
	if (true == ItemLoadedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CSingleLineListControl*>(list)));
		args.set(1, ScriptObject(itemIndex));
		args.set(2, ActorBridge::wrapNativeObjectToJS(data));
		ItemLoadedCb.function.invoke(args);
	}
	return true;
}

bool InternalSingleLineListener::OnItemUnloaded(class ISingleLineListControl* list, IData *data, int itemIndex)
{
	if (true == ItemUnloadedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CSingleLineListControl*>(list)));
		args.set(1, ScriptObject(itemIndex));
		ItemUnloadedCb.function.invoke(args);
	}
	return true;
}

bool InternalSingleLineListener::OnAsyncItemLoad(class ISingleLineListControl *list, IData *data, int itemIndex)
{
	if (true == AsyncItemLoadCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CSingleLineListControl*>(list)));
		args.set(1, ScriptObject(itemIndex));
		AsyncItemLoadCb.function.invoke(args);
	}
	return true;
}

bool InternalSingleLineListener::OnFocusChanged(class ISingleLineListControl *list, int fromItemIndex, int toItemIndex)
{
	if (true == FocusChangedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CSingleLineListControl*>(list)));
		args.set(1, ScriptObject(fromItemIndex));
		args.set(2, ScriptObject(toItemIndex));
		FocusChangedCb.function.invoke(args);
	}
	return true;
}

bool InternalSingleLineListener::OnFocusChangeMotionStart(class ISingleLineListControl* list, int fromItemIndex, int toItemIndex)
{
	if (true == FocusChangeMotionStartCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CSingleLineListControl*>(list)));
		args.set(1, ScriptObject(fromItemIndex));
		args.set(2, ScriptObject(toItemIndex));
		FocusChangeMotionStartCb.function.invoke(args);
	}
	return true;
}

bool InternalSingleLineListener::OnMoveOut(class ISingleLineListControl* list, EDirection direction, int fromItemIndex)
{
	if (true == MoveOutCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CSingleLineListControl*>(list)));

		std::string directionString;

		ScriptObject exArgs;

		switch (direction)
		{
		case DIRECTION_UP:
			directionString = "Up";
			break;

		case DIRECTION_DOWN:
			directionString = "Down";
			break;

		case DIRECTION_LEFT:
			directionString = "Left";
			break;

		case DIRECTION_RIGHT:
			directionString = "Right";
			break;

		default:
			break;
		}

		args.set(1, directionString);
		args.set(2, fromItemIndex);

		MoveOutCb.function.invoke(args);
	}

	return true;
}

bool InternalSingleLineListener::OnItemClicked(class ISingleLineListControl* list, int itemIndex)
{
	if (true == ItemClickedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CSingleLineListControl*>(list)));
		args.set(1, ScriptObject(itemIndex));
		ItemClickedCb.function.invoke(args);
	}
	return true;
}

bool InternalSingleLineListener::OnEnterKeyLongPressed(class ISingleLineListControl *list, int itemIndex)
{
	if (true == EnterKeyLongPressedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CSingleLineListControl*>(list)));
		args.set(1, ScriptObject(itemIndex));
		EnterKeyLongPressedCb.function.invoke(args);
	}
	return true;
}

void SingleLineListListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	context.bindFunction<InternalSingleLineListener, &InternalSingleLineListener::GetItemLoadedCallBack, &InternalSingleLineListener::SetItemLoadedCallBack>("onItemLoaded");
	context.bindFunction<InternalSingleLineListener, &InternalSingleLineListener::GetItemUnloadedCallBack, &InternalSingleLineListener::SetItemUnloadedCallBack>("onItemUnloaded");
	context.bindFunction<InternalSingleLineListener, &InternalSingleLineListener::GetAsyncItemLoadCallBack, &InternalSingleLineListener::SetAsyncItemLoadCallBack>("onAsyncItemLoad");
	context.bindFunction<InternalSingleLineListener, &InternalSingleLineListener::GetFocusChangedCallBack, &InternalSingleLineListener::SetFocusChangedCallBack>("onFocusChanged");
	context.bindFunction<InternalSingleLineListener, &InternalSingleLineListener::GetFocusChangeMotionStartCallBack, &InternalSingleLineListener::SetFocusChangeMotionStartCallBack>("onFocusChangeStart");
	context.bindFunction<InternalSingleLineListener, &InternalSingleLineListener::GetMoveOutCallBack, &InternalSingleLineListener::SetMoveOutCallBack>("onMoveOut");
	context.bindFunction<InternalSingleLineListener, &InternalSingleLineListener::GetItemClickedCallBack, &InternalSingleLineListener::SetItemClickedCallBack>("onItemClicked");
	context.bindFunction<InternalSingleLineListener, &InternalSingleLineListener::GetEnterKeyLongPressedCallBack, &InternalSingleLineListener::SetEnterKeyLongPressedCallBack>("onEnterKeyLongPressed");
}

void* SingleLineListListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalSingleLineListener;
}

void SingleLineListBridge::mapScriptInterface(ScriptContext& context)
{
	DataListBridge::mapScriptInterface(context);

	context.bindNumber<CSingleLineListControl, int, &CSingleLineListControl::FocusItemIndex, &CSingleLineListControl::SetFocusItemIndex>("focusItemIndex");
	context.captureMethodCall<CSingleLineListControl, &m_AddData>("addData");
	context.captureMethodCall<CSingleLineListControl, &m_GetData>("getData");
	context.captureMethodCall<CSingleLineListControl, &m_ClearDataSource>("clearDataSource");
	context.captureMethodCall<CSingleLineListControl, &m_AddItem>("addItem");
	context.captureMethodCall<CSingleLineListControl, &m_InsertItem>("insertItem");
	context.captureMethodCall<CSingleLineListControl, &m_DeleteItem>("deleteItem");
	context.captureMethodCall<CSingleLineListControl, &m_SetItemSpace>("setItemSpcae");
	context.captureMethodCall<CSingleLineListControl, &m_NumofItem>("numOfItem");
	context.captureMethodCall<CSingleLineListControl, &m_UpdateItem>("updateItem");
	context.captureMethodCall<CSingleLineListControl, &m_UpdateAllItem>("updateAllItems");
	context.captureMethodCall<CSingleLineListControl, &m_SetAnimationDuration>("setAnimationDuration");
	context.captureMethodCall<CSingleLineListControl, &m_AddListListener>("addListListener");
	context.captureMethodCall<CSingleLineListControl, &m_Renderer>("renderer");
	context.captureMethodCall<CSingleLineListControl, &m_GetStartItemInWindow>("windowStartIndex");
	context.bindBoolean<CSingleLineListControl, &CSingleLineListControl::IsSetMarginWhenFocusEdgeItem, &CSingleLineListControl::EnableMarginWhenFocusEdgeItem>("useMarginWhenFocusEdgeItem");
}

CDataListControl* SingleLineListBridge::constructSubWidget(Widget* parent, float width, float height, const ScriptObject& argObject)
{
	std::string typeString = argObject.get("scrollType").asString();
	EDirectionType type;
	if ("Vertical" == typeString)
	{
		type = TYPE_VERTICAL;
	}
	else if ("Horizontal" == typeString)
	{
		type = TYPE_HORIZONTAL;
	}

	ISingleLineListControl::TSingleLineListControlAttr attr(width, height, type);
	CSingleLineListControl *control = dynamic_cast<CSingleLineListControl*>(ISingleLineListControl::CreateInstance(parent, attr));

	return control;
}

ScriptObject SingleLineListBridge::m_AddData(CSingleLineListControl* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);

	IData* data = unwrapNativeObject<IData>(args[0]);
	HALO_EXCEPTION(NULL != data, "Data can't be null");

	ISingleLineDataSource *dataSource = self->GetDataSource();
	dataSource->AddData(data);

	return ScriptObject();
}

ScriptObject SingleLineListBridge::m_GetData(CSingleLineListControl* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);

	IData *data = self->GetDataSource()->GetData((int)args[0].asNumber());
	return wrapExistingNativeObject(data);
}

ScriptObject SingleLineListBridge::m_ClearDataSource(CSingleLineListControl* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);

	self->GetDataSource()->DeleteAll();
	return ScriptObject();
}

ScriptObject SingleLineListBridge::m_AddItem(CSingleLineListControl* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);
	ScriptObject argObject = args[0];

	int itemNum = (int)argObject.get("itemNum").asNumber();
	
	if (0 < itemNum)
	{
		float itemGap = 0.0f;

		if (argObject.has("itemGap"))
		{
			ScriptObject itemGapObject = argObject.get("itemGap");

			itemGap = (float)itemGapObject.asNumber();
		}

		ScriptObject itemSpaceObject = argObject.get("itemSpace");

		if (true == itemSpaceObject.isNumber())
		{
			float itemSpace = (float)itemSpaceObject.asNumber();
			self->AddItem(itemNum, itemSpace, itemGap);
		}
		else if (true == itemSpaceObject.isArray())
		{
			ScriptArray spaceArray = itemSpaceObject.asArray();

			HALO_EXCEPTION(spaceArray.Length() == itemNum, "Space num is not equal to item num");

			float *itemSpaceArray = new float[itemNum];
			HALO_ASSERT(NULL != itemSpaceArray);

			for (int i = 0; i < itemNum; i++)
			{
				ScriptObject itemSpaceObj = spaceArray[i];
				HALO_EXCEPTION(true == itemSpaceObj.isNumber(), "Item space must be a number");

				float itemSpace = (float)itemSpaceObj.asNumber();

				itemSpaceArray[i] = itemSpace;
			}

			self->AddItem(itemNum, itemSpaceArray, itemGap);
		}
	}

	return ScriptObject();
}

ScriptObject SingleLineListBridge::m_InsertItem(CSingleLineListControl* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);
	ScriptObject argObject = args[0];

	int insertPos = (int)argObject.get("insertPosition").asNumber();
	int itemNum = (int)argObject.get("itemNum").asNumber();

	if (0 < itemNum)
	{
		ScriptObject itemSpaceObject = argObject.get("itemSpace");

		if (true == itemSpaceObject.isNumber())
		{
			float itemSpace = (float)itemSpaceObject.asNumber();
			self->InsertItem(insertPos, itemNum, itemSpace);
		}
		else if (true == itemSpaceObject.isArray())
		{
			ScriptArray spaceArray = itemSpaceObject.asArray();

			HALO_EXCEPTION(spaceArray.Length() == itemNum, "Space num is not equal to item");

			float *itemSpaceArray = new float[itemNum];
			HALO_ASSERT(NULL != itemSpaceArray);

			for (int i = 0; i < itemNum; i++)
			{
				ScriptObject itemSpaceObj = spaceArray[i];

				float itemSpace = (float)itemSpaceObj.asNumber();
				itemSpaceArray[i] = itemSpace;
			}

			self->InsertItem(insertPos, itemNum, itemSpaceArray);
		}
	}

	return ScriptObject();
}

ScriptObject SingleLineListBridge::m_SetItemSpace(CSingleLineListControl* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);
	ScriptObject argObject = args[0];

	if (argObject.has("ItemNum"))
	{
	}
	else
	{
		int itemIndex = (int)argObject.get("itemIndex").asNumber();
		float itemSpace = (float)argObject.get("itemSpace").asNumber();

		self->SetItemSpace(itemIndex, itemSpace);
	}

	return ScriptObject();
}

ScriptObject SingleLineListBridge::m_DeleteItem(CSingleLineListControl* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);
	ScriptObject argObject = args[0];

	int fromItem = (int)argObject.get("fromItem").asNumber();
	int itemNumber = (int)argObject.get("itemNum").asNumber();

	self->DeleteItem(fromItem, itemNumber);

	return ScriptObject();
}

ScriptObject SingleLineListBridge::m_NumofItem(CSingleLineListControl* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);

	int numOfItem = self->NumofItem();
	return ScriptObject(numOfItem);
}

ScriptObject SingleLineListBridge::m_UpdateItem(CSingleLineListControl* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);

	int itemIndex = (int)args[0].asNumber();

	self->UpdateItem(itemIndex);

	return ScriptObject();
}

ScriptObject SingleLineListBridge::m_UpdateAllItem(CSingleLineListControl* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);

	self->UpdateAllItems();
	return ScriptObject();
}

ScriptObject SingleLineListBridge::m_SetAnimationDuration(CSingleLineListControl* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);

	std::string type = args[0].asString();
	int duration = (int)args[1].asNumber();

	if ("focusMove" == type)
	{
		self->SetAnimationDuration(ISingleLineListControl::ANITYPE_FOCUS_MOVE, duration);
	}
	else if ("loop" == type)
	{
		self->SetAnimationDuration(ISingleLineListControl::ANITYPE_LOOP, duration);
	}

	return ScriptObject();
}

ScriptObject SingleLineListBridge::m_AddListListener(CSingleLineListControl* self, const ScriptArray& args)
{
	InternalSingleLineListener *listener = unwrapNativeObject<InternalSingleLineListener>(args[0]);
	self->AddListListener(listener);

	return ScriptObject();
}

ScriptObject SingleLineListBridge::m_Renderer(CSingleLineListControl* self, const ScriptArray& args)
{
	int itemIndex = (int)args[0].asNumber();

	IRenderer* renderer = self->Renderer(itemIndex);

	return ActorBridge::wrapNativeObjectToJS(renderer);
}

ScriptObject SingleLineListBridge::m_GetStartItemInWindow(CSingleLineListControl* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);

	int start = 0, end = 0;
	self->GetWindowItemRange(start, end);

	return ScriptObject(start);
}