#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void RectangleBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.captureMethodCall<CRectangle, &setBorderThickness>("setBorderThickness");
	context.captureMethodCall<CRectangle, &setBorderColor>("setBorderColor");
}

Widget* RectangleBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	CRectangle* rectangle = dynamic_cast<CRectangle *>(IRectangle::CreateInstance(parent, width, height));
	return rectangle;
}

ScriptObject RectangleBridge::setBorderColor(CRectangle* self, const ScriptArray& args)
{
	guint8 r, g, b, a;
	r = g = b = a = 0;

	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			r = static_cast<guint8>(args[0].asNumber());
		}
		if (args.has(1) && args[1].isNumber())
		{
			g = static_cast<guint8>(args[1].asNumber());
		}
		if (args.has(2) && args[2].isNumber())
		{
			b = static_cast<guint8>(args[2].asNumber());
		}
		if (args.has(3) && args[3].isNumber())
		{
			a = static_cast<guint8>(args[3].asNumber());
		}
	}
	ClutterColor c = { r, g, b, a };

	IRectangle *rectangle = dynamic_cast<IRectangle*>(self);
	rectangle->SetBorderColor(c);

	return ScriptObject();
}

ScriptObject RectangleBridge::setBorderThickness(CRectangle* self, const ScriptArray& args)
{
	double topBorderThickness = 0;
	double leftBorderThickness = 0;
	double bottomtBorderThickness = 0;
	double rightBorderThickness = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) 
		{
			topBorderThickness = args[0].asNumber();
		}

		if (args.has(1) && args[1].isNumber())
		{
			leftBorderThickness = args[1].asNumber();
		}

		if (args.has(2) && args[2].isNumber())
		{
			bottomtBorderThickness = args[2].asNumber();
		}

		if (args.has(3) && args[3].isNumber())
		{
			rightBorderThickness = args[3].asNumber();
		}
	}

	IRectangle *rectangle = dynamic_cast<IRectangle*>(self);
	rectangle->SetBorderThickness(static_cast<float>(topBorderThickness),
		static_cast<float>(leftBorderThickness),
		static_cast<float>(bottomtBorderThickness),
		static_cast<float>(rightBorderThickness)
		);

	return ScriptObject();
}
