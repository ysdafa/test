#include "HaloBridgeAll.h"

using namespace HALO;
using namespace Bridge;

void InputBoxBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.captureMethodCall<CInputBox, &setText>("setText");
	context.captureMethodCall<CInputBox, &setImage>("setImage");
	context.captureMethodCall<CInputBox, &setTextColor>("setTextColor");
	context.captureMethodCall<CInputBox, &setTextBGColor>("setTextBGColor");
	context.captureMethodCall<CInputBox, &setSelectionColor>("setSelectionColor");
	context.captureMethodCall<CInputBox, &setCursorColor>("setCursorColor");
	context.captureMethodCall<CInputBox, &setFont>("setFont");
	context.captureMethodCall<CInputBox, &setFontSize>("setFontSize");
	context.captureMethodCall<CInputBox, &setTextMaxCount>("setTextMaxCount");
	context.captureMethodCall<CInputBox, &setTexHAlignment>("setTextHAlignment");
	context.captureMethodCall<CInputBox, &insertText>("insertText");

#ifdef HAVE_ECORE_IMF
	context.captureMethodCall<CInputBox, &enableIME>("enableIME");
#endif
}

Widget* InputBoxBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	CInputBox::TInputBoxAttr attr;
	ScriptObject options;
	int argsLen = args.Length();
	if (argsLen > 0)
	{
		options = args[0];
		parseMessageBoxParams(options, attr);
	}

	CInputBox *inputBox = dynamic_cast<CInputBox *>(IInputBox::CreateInstance(parent, width, height, attr));
	if (inputBox == NULL)
	{
		return NULL;
	}
	
	inputBox->SetText("InputBox");
	return dynamic_cast<CInputBox*>(inputBox);
}

void InputBoxBridge::parseMessageBoxParams(const ScriptObject& options, CInputBox::TInputBoxAttr& attr)
{
	/*if (options.has("image_x"))
	{
		attr.x_Image = static_cast<float>(options.get("image_x").asNumber());
	}
	if (options.has("image_y"))
	{
		attr.y_Image = static_cast<float>(options.get("image_y").asNumber());
	}

	if (options.has("image_width"))
	{
		attr.width_Image = static_cast<float>(options.get("image_width").asNumber());
	}
	if (options.has("image_height"))
	{
		attr.height_Image = static_cast<float>(options.get("image_height").asNumber());
	}*/

	if (options.has("margin_h"))
	{
		attr.margin_h = static_cast<float>(options.get("margin_h").asNumber());
	}
	if (options.has("margin_v"))
	{
		attr.margin_v = static_cast<float>(options.get("margin_v").asNumber());
	}
}

Bridge::ScriptObject InputBoxBridge::setText(CInputBox* self, const ScriptArray &args)
{
	std::string text = "";
	if (args.has(0) && args[0].isString()) 
	{
		text = args[0].asString();
	}
	self->SetText(text);
	
	return ScriptObject();
}

Bridge::ScriptObject InputBoxBridge::setImage(CInputBox* self, const ScriptArray &args)
{
	if (args.Length() > 0)
	{
		std::string strState = "";
		if (args.has(0) && args[0].isString()) { strState = args[0].asString(); }

		std::string imagePath = "";
		if(args.has(1) && args[1].isString()) { imagePath = args[1].asString(); }
		self->SetImage(deserializeState(strState, IInputBox::T_INPUTBOX_STATE::INPUTBOX_STATE_NORMAL), imagePath);
	}
	
	return ScriptObject();
}

Bridge::ScriptObject InputBoxBridge::setTextBGColor(CInputBox* self, const ScriptArray &args)
{
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) { r = (guint8)args[0].asNumber(); }
		if (args.has(1) && args[1].isNumber()) { g = (guint8)args[1].asNumber(); }
		if (args.has(2) && args[2].isNumber()) { b = (guint8)args[2].asNumber(); }
		if (args.has(3) && args[3].isNumber()) { a = (guint8)args[3].asNumber(); }
	}
	ClutterColor c = { r, g, b, a };
	if (self != NULL)
	{
		self->SetTextBGColor(c);
	}

	return ScriptObject();
}

Bridge::ScriptObject InputBoxBridge::setTextColor(CInputBox* self, const ScriptArray &args)
{
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	std::string strState = "";
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString()) { strState = args[0].asString(); }

		if (args.has(1) && args[1].isNumber()) { r = (guint8)args[1].asNumber(); }
		if (args.has(2) && args[2].isNumber()) { g = (guint8)args[2].asNumber(); }
		if (args.has(3) && args[3].isNumber()) { b = (guint8)args[3].asNumber(); }
		if (args.has(4) && args[4].isNumber()) { a = (guint8)args[4].asNumber(); }	

		ClutterColor c = { r, g, b, a };
		if (self != NULL)
		{
			self->SetTextColor(deserializeState(strState, IInputBox::T_INPUTBOX_STATE::INPUTBOX_STATE_NORMAL), c);
		}
	}

	return ScriptObject();
}

Bridge::ScriptObject InputBoxBridge::setSelectionColor(CInputBox* self, const ScriptArray &args)
{
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) { r = (guint8)args[0].asNumber(); }
		if (args.has(1) && args[1].isNumber()) { g = (guint8)args[1].asNumber(); }
		if (args.has(2) && args[2].isNumber()) { b = (guint8)args[2].asNumber(); }
		if (args.has(3) && args[3].isNumber()) { a = (guint8)args[3].asNumber(); }
	}
	ClutterColor c = { r, g, b, a };
	if (self != NULL)
	{
		self->SetTextSelectionColor(c);
	}

	return ScriptObject();
}

Bridge::ScriptObject InputBoxBridge::setCursorColor(CInputBox* self, const ScriptArray &args)
{
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) { r = (guint8)args[0].asNumber(); }
		if (args.has(1) && args[1].isNumber()) { g = (guint8)args[1].asNumber(); }
		if (args.has(2) && args[2].isNumber()) { b = (guint8)args[2].asNumber(); }
		if (args.has(3) && args[3].isNumber()) { a = (guint8)args[3].asNumber(); }
	}
	ClutterColor c = { r, g, b, a };
	if (self != NULL)
	{
		self->SetTextCursorColor(c);
	}

	return ScriptObject();
}

Bridge::ScriptObject InputBoxBridge::setFont(CInputBox* self, const ScriptArray &args)
{
	std::string fontName = "";
	if (args.has(0) && args[0].isString())
	{
		fontName = args[0].asString();
	}
	self->SetFont(fontName);

	return ScriptObject();
}

Bridge::ScriptObject InputBoxBridge::setFontSize(CInputBox* self, const ScriptArray &args)
{
	int size = 0;
	if (args.has(0) && args[0].isNumber())
	{
		size = args[0].asNumber();
	}
	self->SetFontSize(size);

	return ScriptObject();
}

Bridge::ScriptObject InputBoxBridge::setTextMaxCount(CInputBox* self, const ScriptArray &args)
{
	int count = 0;
	if (args.has(0) && args[0].isNumber())
	{
		count = args[0].asNumber();
	}
	self->SetTextMaxCount(count);

	return ScriptObject();
}

Bridge::ScriptObject InputBoxBridge::setTexHAlignment(CInputBox* self, const ScriptArray &args)
{
	int hAlign = 0;
	if (args.has(0) && args[0].isString())
	{
		if (args.has(0) && args[0].isString()) { hAlign = deserializeAlignment(args[0].asString()); }
	}
	self->SetTextHAlignment((EHAlignment)hAlign);

	return ScriptObject();
}

int InputBoxBridge::deserializeAlignment(std::string alignMent)
{
	if (compareStrChar(alignMent, "left"))
	{
		return HALIGN_LEFT;
	}
	else if (compareStrChar(alignMent, "center"))
	{
		return HALIGN_CENTER;
	}
	else
	{
		return 0;
	}
}

IInputBox::T_INPUTBOX_STATE InputBoxBridge::deserializeState(std::string stateStr, IInputBox::T_INPUTBOX_STATE state)
{
	if (compareStrChar(stateStr, "normal"))
	{
		return IInputBox::T_INPUTBOX_STATE::INPUTBOX_STATE_NORMAL;
	}
	else if (compareStrChar(stateStr, "focus"))
	{
		return IInputBox::T_INPUTBOX_STATE::INPUTBOX_STATE_FOCUS;
	}
	else
	{
		return state;
	}
}

Bridge::ScriptObject InputBoxBridge::insertText(CInputBox* self, const ScriptArray &args)
{
	std::string text = "";
	if (args.has(0) && args[0].isString())
	{
		text = args[0].asString();
	}
	self->InsertText(text.c_str());

	return ScriptObject();
}

#ifdef HAVE_ECORE_IMF
Bridge::ScriptObject InputBoxBridge::enableIME(CInputBox* self, const ScriptArray &args)
{
	bool flag = false;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isBool())
		{
			flag = args[0].asBool();
		}
	}

	self->EnableIME(flag);

	return ScriptObject();
}
#endif