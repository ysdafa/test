#include "HaloBridgeAll.h"
#include <string.h>

using namespace Bridge;
using namespace HALO;

void BoxLayoutBridge::mapScriptInterface(ScriptContext& context)
{
	LayoutManagerBridge::mapScriptInterface(context);
	context.captureMethodCall<ILayout, &SetPackStartFlag>("setPackStartFlag");
	context.captureMethodCall<ILayout, &FlagPackStart>("getPackStartFlag");
	context.captureMethodCall<ILayout, &SetSpacing>("setSpacing");
	context.captureMethodCall<ILayout, &Spacing>("getSpacing");
	context.captureMethodCall<ILayout, &EnableHomogeneous>("setHomogeneous");
	context.captureMethodCall<ILayout, &IsHomogeneousEnable>("getHomogeneous");
	context.captureMethodCall<ILayout, &SetDirection>("setDirection");
	context.captureMethodCall<ILayout, &Direction>("getDirection");
	
}

ILayout* BoxLayoutBridge::constructWidget(const ScriptArray& args)
{
	IBoxLayout *boxlayout = IBoxLayout::CreateInstance();
	return boxlayout;
}

ScriptObject BoxLayoutBridge::SetPackStartFlag(ILayout* self, const ScriptArray& args)
{
	IBoxLayout *iLayout = dynamic_cast<IBoxLayout*>(self);
	if (iLayout != NULL && args.Length() > 0 && args[0].isBool())
	{
		iLayout->SetPackStartFlag(args[0].asBool());
	}
	return ScriptObject();
}

ScriptObject BoxLayoutBridge::FlagPackStart(ILayout* self, const ScriptArray& args)
{
	IBoxLayout *iLayout = dynamic_cast<IBoxLayout*>(self);
	bool flag = true;
	if (iLayout != NULL)
	{
		flag = iLayout->FlagPackStart();
	}
	return ScriptObject(flag);
}

ScriptObject BoxLayoutBridge::SetSpacing(ILayout* self, const ScriptArray& args)
{
	IBoxLayout *iLayout = dynamic_cast<IBoxLayout*>(self);
	if (iLayout != NULL && args.Length() > 0 && args[0].isNumber())
	{
		iLayout->SetSpacing(args[0].asNumber());
	}
	return ScriptObject();
}

ScriptObject BoxLayoutBridge::Spacing(ILayout* self, const ScriptArray& args)
{
	IBoxLayout *iLayout = dynamic_cast<IBoxLayout*>(self);
	int spacing = -1;
	if (iLayout != NULL)
	{
		spacing = iLayout->Spacing();
	}
	return ScriptObject(spacing);
}

ScriptObject BoxLayoutBridge::EnableHomogeneous(ILayout* self, const ScriptArray& args)
{
	IBoxLayout *iLayout = dynamic_cast<IBoxLayout*>(self);
	if (iLayout != NULL && args.Length() > 0 && args[0].isBool())
	{
		iLayout->EnableHomogeneous(args[0].asBool());
	}
	return ScriptObject();
}

ScriptObject BoxLayoutBridge::IsHomogeneousEnable(ILayout* self, const ScriptArray& args)
{
	IBoxLayout *iLayout = dynamic_cast<IBoxLayout*>(self);
	bool flag = false;
	if (iLayout != NULL)
	{
		iLayout->IsHomogeneousEnable();
	}
	return ScriptObject(flag);
}

ScriptObject BoxLayoutBridge::SetDirection(ILayout* self, const ScriptArray& args)
{
	IBoxLayout *iLayout = dynamic_cast<IBoxLayout*>(self);
	if (iLayout != NULL && args.Length() > 0 && args[0].isString())
	{
		/* CLUTTER_ORIENTATION_HORIZONTAL,
		CLUTTER_ORIENTATION_VERTICAL*/
		std::string orientation;
		orientation = args[0].asString();
		if (orientation.compare("HORIZONTAL") == 0)
		{
			iLayout->SetDirection(CLUTTER_ORIENTATION_HORIZONTAL);
		}
		else if (orientation.compare("VERTICAL") == 0)
		{
			iLayout->SetDirection(CLUTTER_ORIENTATION_VERTICAL);
		}	
	}
	return ScriptObject();
}

ScriptObject BoxLayoutBridge::Direction(ILayout* self, const ScriptArray& args)
{
	IBoxLayout *iLayout = dynamic_cast<IBoxLayout*>(self);
	std::string orientation = "";
	if (iLayout != NULL)
	{
		if (iLayout->Direction() == CLUTTER_ORIENTATION_HORIZONTAL)
		{
			orientation = "HORIZONTAL";
		}
		else if (iLayout->Direction() == CLUTTER_ORIENTATION_VERTICAL)
		{
			orientation = "VERTICAL";
		}		
	}
	return ScriptObject(orientation);
}