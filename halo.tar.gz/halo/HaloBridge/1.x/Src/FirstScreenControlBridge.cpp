#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

#define ASSERT_RETURN_NULL(x) ASSERT(x); if(false == (x)) {return ScriptObject();}
#define ASSERT_RETURN(x, val) ASSERT(x); if(false == (x)) {return ScriptObject(val);}

void FirstScreenControlBridge::mapScriptInterface(ScriptContext& context)
{
	DataListBridge::mapScriptInterface(context);
	context.captureMethodCall<IAnimatable, &m_AddMainMenuItem>("addMainMenuItem");

	context.captureMethodCall<IAnimatable, &m_AddSubItem>("addSubItem");
	context.captureMethodCall<IAnimatable, &m_SetScrollItemNumber>("setScrollItemNumber");
	context.captureMethodCall<IAnimatable, &m_ExpandMainMenu>("expandMainMenu");
	context.captureMethodCall<IAnimatable, &m_ShrinkMainMenu>("shrinkMainMenu");
	context.captureMethodCall<IAnimatable, &m_SetMaxMargin>("setMaxMargin");
	context.captureMethodCall<IAnimatable, &m_SetExpandAnimationDuration>("setExpandAnimationDuration");
	context.captureMethodCall<IAnimatable, &m_SetScrollSpeed>("setScrollSpeed");

	context.captureMethodCall<IAnimatable, &m_AddMainMenuData>("addMainMenuData");
	context.captureMethodCall<IAnimatable, &m_AddSubMenuData>("addSubMenuData");
	context.captureMethodCall<IAnimatable, &m_AddScrollMenuData>("addScrollDataInMainMenu");

	context.captureMethodCall<IAnimatable, &m_MainMenuData>("mainMenuData");
	context.captureMethodCall<IAnimatable, &m_SubMenuData>("subMenuData");
	context.captureMethodCall<IAnimatable, &m_ScrollMenuData>("scrollDataInMenu");

	context.captureMethodCall<IAnimatable, &m_SetFocusRange>("setFocusRange");
}

CDataListControl* FirstScreenControlBridge::constructSubWidget(Widget* parent, float width, float height, const ScriptObject& argObject)
{
	ARG_IS_VALID(argObject, "mainTitleWidth", isNumber);
	ARG_IS_VALID(argObject, "mainTitleHeight", isNumber);
	ARG_IS_VALID(argObject, "mainTitleSpace", isNumber);
	ARG_IS_VALID(argObject, "subTitleWidth", isNumber);
	ARG_IS_VALID(argObject, "subTitleHeight", isNumber);
	ARG_IS_VALID(argObject, "subTitleSpace", isNumber);

	float mainTitleWidth = (float)argObject.get("mainTitleWidth").asNumber();
	float mainTitleHeight = (float)argObject.get("mainTitleHeight").asNumber();
	float mainTitleSpace = (float)argObject.get("mainTitleSpace").asNumber();
	float subTitleWidth = (float)argObject.get("subTitleWidth").asNumber();
	float subTitleHeight = (float)argObject.get("subTitleHeight").asNumber();
	float subTitleSpace = (float)argObject.get("subTitleSpace").asNumber();

	IFirstScreenListControl::TFirstScreenListControlAttr attr(width, height, mainTitleWidth, mainTitleHeight, mainTitleSpace, subTitleWidth, subTitleHeight, subTitleSpace);
	CFirstScreenListControl *control = dynamic_cast<CFirstScreenListControl*>(IFirstScreenListControl::CreateInstance(parent, attr));
	control->AddListListener(this);
	return control;
}

bool FirstScreenControlBridge::OnMainMenuItemLoaded(class IFirstScreenListControl* list, int mainMenuIndex)
{
	ScriptArray args;

	args.set(0, ScriptObject((int)MAIN_ITEM_LOAD));
	args.set(1, wrapExistingNativeObject(list));
	args.set(2, ScriptObject(mainMenuIndex));

//	t_listListenerCallback.invoke(args);
	return true;
}

bool FirstScreenControlBridge::OnScrollListItemLoaded(class IFirstScreenListControl* list, int mainMenuIndex, int scrollDataIndex)
{
	ScriptArray args;

	args.set(0, ScriptObject((int)SCROLL_ITEM_LOAD));
	args.set(1, wrapExistingNativeObject(list));
	args.set(2, ScriptObject(mainMenuIndex));
	args.set(3, ScriptObject(scrollDataIndex));

//	t_listListenerCallback.invoke(args);

	return true;
}

bool FirstScreenControlBridge::OnSubMenuItemLoaded(class IFirstScreenListControl* list, int mainMenuIndex, int subMenuIndex)
{
	ScriptArray args;

	args.set(0, ScriptObject((int)SUB_ITEM_LOAD));
	args.set(1, wrapExistingNativeObject(list));
	args.set(2, ScriptObject(mainMenuIndex));
	args.set(3, ScriptObject(subMenuIndex));

//	t_listListenerCallback.invoke(args);

	return true;
}

ScriptObject FirstScreenControlBridge::m_AddMainMenuItem(IAnimatable* self, const ScriptArray& args)
{
	ASSERT_RETURN_NULL(4 == args.Length());

	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT_RETURN_NULL(NULL != control);

	ASSERT_RETURN_NULL(true == args[0].isNumber());
	ASSERT_RETURN_NULL(true == args[2].isNumber());
	ASSERT_RETURN_NULL(true == args[3].isArray());
	ASSERT_RETURN_NULL(true == args[1].isArray() || true == args[1].isNumber());

	int itemNum = (int)args[0].asNumber();

	ScriptArray titleArray = args[3].asArray();

	ASSERT_RETURN_NULL(itemNum == titleArray.Length());

	float spaceBetweenItem = (float)args[2].asNumber();
	
	char **itemTitles = new char*[itemNum];

	for (int i = 0; i < itemNum; i++)
	{
		ASSERT_RETURN_NULL(true == titleArray[i].isString());
		std::string title = titleArray[i].asString();

		itemTitles[i] = new char[title.length() + 1];
		strncpy(itemTitles[i], title.c_str(), title.length() + 1);
	}

	if (args[1].isArray())
	{
		ScriptArray sizeArray = args[1].asArray();
		ASSERT_RETURN_NULL(itemNum == sizeArray.Length());

		float *itemSize = new float[itemNum];

		for (int i = 0; i < itemNum; i++)
		{
			ASSERT_RETURN_NULL(true == sizeArray[i].isNumber());
			itemSize[i] = (float)sizeArray[i].asNumber();
		}

		control->AddMainMenuItem(itemNum, itemSize, spaceBetweenItem, itemTitles);

		delete[] itemSize;
	}
	else if (args[1].isNumber())
	{
		float itemSize = (float)args[1].asNumber();
		control->AddMainMenuItem(itemNum, itemSize, spaceBetweenItem, itemTitles);
	}

	for (int i = 0; i < itemNum; i++)
	{
		delete[] itemTitles[i];
	}

	delete[] itemTitles;

	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_AddSubItem(IAnimatable* self, const ScriptArray& args)
{
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT_RETURN_NULL(NULL != control);

	ASSERT_RETURN_NULL(5 == args.Length());
	ASSERT_RETURN_NULL(true == args[0].isNumber());
	ASSERT_RETURN_NULL(true == args[1].isNumber());
	ASSERT_RETURN_NULL(true == args[2].isNumber());
	ASSERT_RETURN_NULL(true == args[3].isNumber());
	ASSERT_RETURN_NULL(true == args[4].isString());

	int mainMenuIndex = (int)args[0].asNumber();
	float itemSize = (float)args[1].asNumber();
	float spaceBetweenItem = (float)args[2].asNumber();
	float enlargeFocusItemSize = (float)args[3].asNumber();
	std::string title = args[4].asString();

	control->AddSubItem(mainMenuIndex, itemSize, spaceBetweenItem, enlargeFocusItemSize, title.c_str());

	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_SetScrollItemNumber(IAnimatable* self, const ScriptArray& args)
{
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT_RETURN_NULL(NULL != control);

	ASSERT_RETURN_NULL(2 == args.Length());
	ASSERT_RETURN_NULL(true == args[0].isNumber());
	ASSERT_RETURN_NULL(true == args[1].isNumber());

	int mainMenuIndex = (int)args[0].asNumber();
	int itemNumber = (int)args[1].asNumber();

	control->SetScrollItemNumber(mainMenuIndex, itemNumber);

	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_ExpandMainMenu(IAnimatable* self, const ScriptArray& args)
{
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT_RETURN_NULL(NULL != control);

	ASSERT_RETURN_NULL(1 == args.Length());
	ASSERT_RETURN_NULL(true == args[0].isNumber());

	int mainMenuIndex = (int)args[0].asNumber();

	control->ExpandMainMenu(mainMenuIndex);

	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_ShrinkMainMenu(IAnimatable* self, const ScriptArray& args)
{
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT_RETURN_NULL(NULL != control);

	ASSERT_RETURN_NULL(1 == args.Length());
	ASSERT_RETURN_NULL(true == args[0].isNumber());

	int mainMenuIndex = (int)args[0].asNumber();

	control->ShrinkMainMenu(mainMenuIndex);

	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_SetMaxMargin(IAnimatable* self, const ScriptArray& args)
{
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT_RETURN_NULL(NULL != control);

	ASSERT_RETURN_NULL(2 == args.Length());
	ASSERT_RETURN_NULL(true == args[0].isNumber());
	ASSERT_RETURN_NULL(true == args[1].isNumber());

	float startMargin = (float)args[0].asNumber();
	float endMargin = (float)args[1].asNumber();

	control->SetMaxMargin(startMargin, endMargin);

	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_SetExpandAnimationDuration(IAnimatable* self, const ScriptArray& args)
{
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT_RETURN_NULL(NULL != control);

	ASSERT_RETURN_NULL(1 == args.Length());
	ASSERT_RETURN_NULL(true == args[0].isNumber());

	int duration = (int)args[0].asNumber();

	control->SetExpandAnimationDuration(duration);

	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_SetScrollSpeed(IAnimatable* self, const ScriptArray& args)
{
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT_RETURN_NULL(NULL != control);

	ASSERT_RETURN_NULL(1 == args.Length());
	ASSERT_RETURN_NULL(true == args[0].isNumber());

	int duration = (int)args[0].asNumber();

	control->SetExpandAnimationDuration(duration);

	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_AddMainMenuData(IAnimatable* self, const ScriptArray& args)
{
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT_RETURN_NULL(NULL != control);
	
	if (NULL != control)
	{
		ASSERT_RETURN_NULL(1 == args.Length());

		IData *data = unwrapNativeObject<IData>(args[0]);
		ASSERT_RETURN_NULL(NULL != data);
		control->DataSource()->AddMainMenuData(data);
	}
	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_AddSubMenuData(IAnimatable* self, const ScriptArray& args)
{
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT_RETURN_NULL(NULL != control);
	ASSERT_RETURN_NULL(2 == args.Length() && true == args[1].isNumber());

	IData *data = unwrapNativeObject<IData>(args[0]);
	int mainMenuIndex = (int)args[1].asNumber();

	control->DataSource()->AddSubMenuData(data, mainMenuIndex);

	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_AddScrollMenuData(IAnimatable* self, const ScriptArray& args)
{
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT_RETURN_NULL(NULL != control);
	ASSERT_RETURN_NULL(2 == args.Length() && true == args[1].isNumber());

	IData *data = unwrapNativeObject<IData>(args[0]);
	int mainMenuIndex = (int)args[1].asNumber();

	control->DataSource()->AddScrollDataInMainMenu(data, mainMenuIndex);

	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_MainMenuData(IAnimatable* self, const ScriptArray& args)
{
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT_RETURN_NULL(NULL != control);
	ASSERT_RETURN_NULL(1 == args.Length() && true == args[0].isNumber());

	int mainMenuIndex = (int)args[0].asNumber();
	IData *data = control->DataSource()->MainMenuData(mainMenuIndex);

	return ScriptObject(wrapExistingNativeObject(data));
}

ScriptObject FirstScreenControlBridge::m_SubMenuData(IAnimatable* self, const ScriptArray& args)
{
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT_RETURN_NULL(NULL != control);
	ASSERT_RETURN_NULL(2 == args.Length() && true == args[0].isNumber() && true == args[1].isNumber());

	int mainMenuIndex = (int)args[0].asNumber();
	int subMenuIndex = (int)args[1].asNumber();
	IData *data = control->DataSource()->SubMenuData(mainMenuIndex, subMenuIndex);

	return ScriptObject(wrapExistingNativeObject(data));
}

ScriptObject FirstScreenControlBridge::m_ScrollMenuData(IAnimatable* self, const ScriptArray& args)
{
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT_RETURN_NULL(NULL != control);
	ASSERT_RETURN_NULL(2 == args.Length() && true == args[0].isNumber() && true == args[1].isNumber());

	int mainMenuIndex = (int)args[0].asNumber();
	int scrollIndex = (int)args[1].asNumber();
	IData *data = control->DataSource()->ScrollData(mainMenuIndex, scrollIndex);

	return ScriptObject(wrapExistingNativeObject(data));
}

ScriptObject FirstScreenControlBridge::m_SetFocusRange(IAnimatable* self, const ScriptArray& args)
{
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT_RETURN_NULL(NULL != control);
	ASSERT_RETURN_NULL(2 == args.Length() && true == args[0].isNumber() && true == args[1].isNumber());

	TMargin margin;
	margin.Set(0, 0, (int)args[0].asNumber(), (int)args[1].asNumber());
	control->SetFocusMargin(margin);

	return ScriptObject();
}
