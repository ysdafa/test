#include "HaloBridgeAll.h"

#define STR(s) #s
#define BIND_FUNCTION(e, x) \
	context.bindFunction<Internal##e##Listener, &Internal##e##Listener::Get##x##CallBack, &Internal##e##Listener::Set##x##CallBack>(STR(on##x));

using namespace Bridge;
using namespace HALO;

// BaseListener
void BaseListenerBridge::mapScriptInterface(ScriptContext& context)
{
	context.captureMethodCall<IListener, &handleDestroy>("destroy");
}

ScriptObject BaseListenerBridge::handleDestroy(IListener* self, const ScriptArray& args)
{
	delete self;
	return ScriptObject();
}

void BaseListenerBridge::destroyFromScript(void* destroyedObject)
{
	/*IListener* listener = reinterpret_cast<IListener*>(destroyedObject);
	delete listener;*/
}

// FocusListenerBridge
void FocusListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	context.bindFunction<InternalFocusListener, &InternalFocusListener::GetFocusInCallBack, &InternalFocusListener::SetFocusInCallBack>("onFocusIn");
	context.bindFunction<InternalFocusListener, &InternalFocusListener::GetFocusOutCallBack, &InternalFocusListener::SetFocusOutCallBack>("onFocusOut");
}

void* FocusListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalFocusListener(this);
}

// InternalFocusListener
bool InternalFocusListener::OnFocusIn(IActor* pWindow)
{
	if (true == FocusInCb.flagExist)
	{
		ScriptArray args;
		args.set(0, t_owner->WrapNativeObjectToJS(dynamic_cast<CActor*>(pWindow)));
		FocusInCb.function.invoke(args);
	}
	return true;
}

bool InternalFocusListener::OnFocusOut(IActor* pWindow)
{
	if (true == FocusOutCb.flagExist)
	{
		ScriptArray args;
		args.set(0, t_owner->WrapNativeObjectToJS(dynamic_cast<CActor*>(pWindow)));
		FocusOutCb.function.invoke(args);
	}
	return true;
}

// MouseListenerBridge
void MouseListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);

	BIND_FUNCTION(Mouse, MouseButtonPressed);
	BIND_FUNCTION(Mouse, MouseButtonReleased);
	BIND_FUNCTION(Mouse, MouseMoved);
	BIND_FUNCTION(Mouse, MouseWheel);
	BIND_FUNCTION(Mouse, MouseClicked);
	BIND_FUNCTION(Mouse, MousePointerIn);
	BIND_FUNCTION(Mouse, MousePointerOut);
	BIND_FUNCTION(Mouse, CapturedMouseButtonPressed);
	BIND_FUNCTION(Mouse, CapturedMouseButtonReleased);
	BIND_FUNCTION(Mouse, CapturedMouseMoved);
	BIND_FUNCTION(Mouse, CapturedMouseWheel);
	BIND_FUNCTION(Mouse, CapturedMouseClicked);
	BIND_FUNCTION(Mouse, CapturedMousePointerIn);
	BIND_FUNCTION(Mouse, CapturedMousePointerOut);
}

void* MouseListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalMouseListener(this);
}

// TouchListenerBridge
void TouchListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	BIND_FUNCTION(Touch, TouchPressed);
	BIND_FUNCTION(Touch, TouchReleased);
	BIND_FUNCTION(Touch, TouchMoved);
	BIND_FUNCTION(Touch, TouchTap);
	BIND_FUNCTION(Touch, TouchFlicked);
	BIND_FUNCTION(Touch, TouchPinched);
	BIND_FUNCTION(Touch, TouchStretched);
	BIND_FUNCTION(Touch, TouchLongPressed);
}

void* TouchListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalTouchListener(this);
}

// KeyboardListenerBridge
void KeyboardListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	BIND_FUNCTION(Keyboard, KeyPressed);
	BIND_FUNCTION(Keyboard, KeyReleased);
	BIND_FUNCTION(Keyboard, CapturedKeyPressed);
	BIND_FUNCTION(Keyboard, CapturedKeyReleased);
}

void* KeyboardListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalKeyboardListener(this);
}

// MotionListenerBridge
void MotionListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	BIND_FUNCTION(Motion, MotionTilt);
	BIND_FUNCTION(Motion, MotionRoll);
	BIND_FUNCTION(Motion, MotionPanning);
	BIND_FUNCTION(Motion, MotionSnap);
}

void* MotionListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalMotionListener(this);
}

// RemoteControlListenerBridge
void RemoteControlListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	BIND_FUNCTION(RemoteControl, KeyPressed);
	BIND_FUNCTION(RemoteControl, KeyReleased);
	BIND_FUNCTION(RemoteControl, KeyLongPressed);
}

void* RemoteControlListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalRemoteControlListener(this);
}

// RidgeListenerBridge
void RidgeListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	BIND_FUNCTION(Ridge, RidgeOn);
	BIND_FUNCTION(Ridge, RidgeOff);
	BIND_FUNCTION(Ridge, RidgeMove);
	BIND_FUNCTION(Ridge, RidgeFlick);
}

void* RidgeListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalRidgeListener(this);
}

// CursorListenerBridge
void CursorListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	BIND_FUNCTION(Cursor, Shown);
	BIND_FUNCTION(Cursor, Hidden);
	BIND_FUNCTION(Cursor, DeviceTypeChanged);
}

void* CursorListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalCursorListener(this);
}

// SensorListenerBridge
void* SensorListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalSensorListener(this);
}

void SensorListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	BIND_FUNCTION(Sensor, SensorStart);
	BIND_FUNCTION(Sensor, SensorMoved);
	BIND_FUNCTION(Sensor, SensorEnd);
}

// ClickListenerBridge
void ClickListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	BIND_FUNCTION(Click, Clicked);
	BIND_FUNCTION(Click, LongPress);
}

void* ClickListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalClickListener(this);
}

// SemanticEventListenerBridge
void SemanticEventListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	BIND_FUNCTION(SemanticEvent, SemanticEvent);
}

void* SemanticEventListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalSemanticEventListener(this);
}

// SystemEventListenerBridge
void SystemEventListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	BIND_FUNCTION(SystemEvent, SystemQuit);
	BIND_FUNCTION(SystemEvent, CursorVisible);
	BIND_FUNCTION(SystemEvent, CursorHidden);
}

void* SystemEventListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalSystemEventListener(this);
}

// CustomEventListenerBridge
void CustomEventListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	BIND_FUNCTION(CustomEvent, CustomEvent);
}

void* CustomEventListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalCustomEventListener(this);
}

// DragListenerBridge
void DragListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	BIND_FUNCTION(Drag, DragBegin);
	BIND_FUNCTION(Drag, DragEnd);
	BIND_FUNCTION(Drag, DragMotion);
	BIND_FUNCTION(Drag, DragHold);
}

void* DragListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalDragListener(this);
}

// GestureListenerBridge
void GestureListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	BIND_FUNCTION(Gesture, GestureBegin);
	BIND_FUNCTION(Gesture, GestureEnd);
	BIND_FUNCTION(Gesture, GestureCancel);
	BIND_FUNCTION(Gesture, GestureProgress);
}

void* GestureListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalGestureListener(this);
}

// KeyLongPressListenerBridge
void KeyLongPressListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	BIND_FUNCTION(KeyLongPress, KeyLongPress);
}

void* KeyLongPressListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalKeyLongPressListener(this);
}

// KeyCombinationListenerBridge
void KeyCombinationListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	BIND_FUNCTION(KeyCombination, KeyCombination);
}

void* KeyCombinationListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalKeyCombinationListener(this);
}




