#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void AnimatableBridge::mapScriptInterface(ScriptContext& context)
{
	context.captureMethodCall<IAnimatable, &m_BindTransition>("bindTransition");
}

ScriptObject AnimatableBridge::m_BindTransition(IAnimatable* self, const ScriptArray& args)
{
	ASSERT(NULL != self);
	ASSERT(2 == args.Length() && true == args[1].isNumber());

	ITransition *trans = unwrapNativeObject<ITransition>(args[0]);
	int animationType = (int)args[1].asNumber();

	self->BindTransition(trans, animationType);

	return ScriptObject();
}

void TransitionBridge::mapScriptInterface(ScriptContext& context)
{
	context.captureMethodCall<ITransition, &m_SetDuration>("setDuration");
	context.captureMethodCall<ITransition, &m_SetDestination>("setDestination");
	context.captureMethodCall<ITransition, &m_Play>("play");
}

void* TransitionBridge::constructFromScript(const ScriptArray& args)
{
	ITransition *trans;
	trans = ITransition::CreateInstance();
	return trans;
}

ScriptObject TransitionBridge::m_SetDuration(ITransition* self, const ScriptArray& args)
{
	ASSERT(NULL != self);
	ASSERT(1 == args.Length() && true == args[0].isNumber());

	self->SetDuration((int)args[0].asNumber());

	return ScriptObject();
}

ScriptObject TransitionBridge::m_SetDestination(ITransition* self, const ScriptArray& args)
{
	ASSERT(NULL != self);
	ASSERT(0 < args.Length());

	int argsLength = args.Length();

	switch (argsLength)
	{
	case 1:
		self->SetDestination((float)(args[0].asNumber()));
		break;

	case 2:
		self->SetDestination((float)(args[0].asNumber()), (float)(args[1].asNumber()));
		break;

	default:
		break;
	}

	return ScriptObject();
}

ScriptObject TransitionBridge::m_Play(ITransition* self, const ScriptArray& args)
{
	ASSERT(NULL != self);
	self->Play();

	return ScriptObject();
}

