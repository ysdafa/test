#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void Bridge::RadioButtonGroupBridge::mapScriptInterface( ScriptContext& context )
{
	ActorBridge::mapScriptInterface(context);
	context.captureMethodCall<CRadioButtonGroup, &addButton>("addButton");
	context.captureMethodCall<CRadioButtonGroup, &getItemById>("getItemById");
	context.captureMethodCall<CRadioButtonGroup, &setDefaultFocus>("setDefaultFocus");
	context.captureMethodCall<CRadioButtonGroup, &numofItem>("numofItem");
	context.captureMethodCall<CRadioButtonGroup, &addlistener>("addlistener");
	context.captureMethodCall<CRadioButtonGroup, &setDefaultSelectedItem>("setDefaultSelectedItem");
	context.captureMethodCall<CRadioButtonGroup, &removeListener>("removeListener");
	context.captureMethodCall<CRadioButtonGroup, &getSelectedItemIndex>("getSelectedItemIndex");
	
}

Bridge::ScriptObject Bridge::RadioButtonGroupBridge::addButton( CRadioButtonGroup* self, const ScriptArray& args )
{
	if (args.Length() > 0)
	{
		ISelectButton* button = unwrapNativeObject<CSelectButton>(args[0]);
		if (button != nullptr)
		{
			self->AddButton(button);
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::RadioButtonGroupBridge::getItemById( CRadioButtonGroup* self, const ScriptArray& args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	ARG_IS_VALID(object, "id", isNumber);
	int id = object.get("id").asNumber();
	return ScriptObject(self->GetItemById(id));
}

Bridge::ScriptObject Bridge::RadioButtonGroupBridge::setDefaultFocus( CRadioButtonGroup* self, const ScriptArray& args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	ARG_IS_VALID(object, "itemid", isNumber);
	int itemid = object.get("itemid").asNumber();
	self->SetDefaultFocus(itemid);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::RadioButtonGroupBridge::numofItem( CRadioButtonGroup* self, const ScriptArray& args )
{
	return ScriptObject( self->NumofItem());
}


Bridge::ScriptObject Bridge::RadioButtonGroupBridge::addlistener( CRadioButtonGroup* self, const ScriptArray& args )
{
	if (args.Length() > 0)
	{
		OnCheckedChangedListener* listener = unwrapNativeObject<OnCheckedChangedListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddListener(listener);
		}
	}
	return ScriptObject();
}


Bridge::ScriptObject Bridge::RadioButtonGroupBridge::setDefaultSelectedItem( CRadioButtonGroup* self, const ScriptArray& args )
{
	ScriptObject object = args[0];
	ARG_IS_VALID(object, "id", isNumber);

	int id = (int)object.get("id").asNumber();
	self->SetDefaultSelectedItem(id);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::RadioButtonGroupBridge::removeListener( CRadioButtonGroup* self, const ScriptArray& args )
{
	if (args.Length() > 0)
	{
		OnCheckedChangedListener* listener = unwrapNativeObject<OnCheckedChangedListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveListener(listener);
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::RadioButtonGroupBridge::getSelectedItemIndex( CRadioButtonGroup* self, const ScriptArray& args )
{
	return ScriptObject(self->GetSelectedItemIndex());
}

Widget* Bridge::RadioButtonGroupBridge::constructWidget( float x, float y, float width, float height, Widget* parent, const ScriptArray& args )
{
	CRadioButtonGroup *group = dynamic_cast<CRadioButtonGroup *>(IRadioButtonGroup::CreateInstance());
	return (Widget*)group;
}

void Bridge::RadioButtonGroupListenerBridge::mapScriptInterface( ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	context.bindFunction<InternalRadioButtonGroupListener, &InternalRadioButtonGroupListener::GetSelectedChangedCallBack, &InternalRadioButtonGroupListener::SetSelectedChangedCallBack>("onSelectedChanged");
}

void* Bridge::RadioButtonGroupListenerBridge::constructFromScript( const ScriptArray& args )
{
	return new InternalRadioButtonGroupListener;
}

bool Bridge::InternalRadioButtonGroupListener::OnCheckChanged(class ISelectButtonGroup* list , int index , bool ischecked ,ISelectButton* checkcontrol)
{
	if (true == SelectedChangedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CRadioButtonGroup*>(list)));
		args.set(1, index);
		args.set(2, ischecked);
		args.set(3, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CSelectButton*>(checkcontrol)));
		SelectedChangedCb.function.invoke(args);
	}
	return true;
}
