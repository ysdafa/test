#if !defined(WIN32) && !defined(LINUX_BUILD)
#include "HaloBridgeAll.h"

#include "TTSEngine.h"

using namespace HALO;
using namespace Bridge;

static HALO::util::Logger LOGGER("TTSEngineBridge");


Bridge::TTSEngineBridge::TTSEngineBridge(): ScriptInstanceBridge(this)
{
}

Bridge::TTSEngineBridge::~TTSEngineBridge()
{
}

void Bridge::TTSEngineBridge::mapScriptInterface(ScriptContext& context)
{
	context.captureMethodCall<TTSEngineBridge, &SetText>("setText");
	context.captureMethodCall<TTSEngineBridge, &PlayText>("play");
	context.captureMethodCall<TTSEngineBridge, &QueueText>("queuingPlay");
	context.captureMethodCall<TTSEngineBridge, &StopText>("stop");
}

Bridge::ScriptObject Bridge::TTSEngineBridge::SetText(TTSEngineBridge *self, const ScriptArray &args)
{
	H_LOG_TRACE(LOGGER, "TTSEngineBridge::SetText");
	if (args.Length() > 0)
	{
		std::string text = args[0].asString();
		H_LOG_TRACE(LOGGER, "tts text:"<<text);
		TTSEngine::Instance().SetText(text);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::TTSEngineBridge::PlayText(TTSEngineBridge *self, const ScriptArray &args)
{
	H_LOG_TRACE(LOGGER, "TTSEngineBridge::PlayText");
	TTSEngine::Instance().StopAndPlay();
	
	return ScriptObject();
}

Bridge::ScriptObject Bridge::TTSEngineBridge::QueueText(TTSEngineBridge *self, const ScriptArray &args)
{
	H_LOG_TRACE(LOGGER, "TTSEngineBridge::QueueText");
	if (args.Length() > 0)
	{
		std::string text = args[0].asString();
		H_LOG_TRACE(LOGGER, "tts text:"<<text);
		TTSEngine::Instance().SetText(text);
		TTSEngine::Instance().Play();
	}

	return ScriptObject();
}

Bridge::ScriptObject Bridge::TTSEngineBridge::StopText(TTSEngineBridge *self, const ScriptArray &args)
{
	H_LOG_TRACE(LOGGER, "TTSEngineBridge::StopText");
	TTSEngine::Instance().Stop();

	return ScriptObject();
}

#endif
