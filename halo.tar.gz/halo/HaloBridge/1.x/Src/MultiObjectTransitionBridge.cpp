#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

bool InternalTransListener::OnStarted(class ITimeLine *animation, void *data)
{
	if (true == StartedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CMultiObjectTransition*>(animation)));
		StartedCb.function.invoke(args);
	}
	
	return true;
}

bool InternalTransListener::OnVia(class ITimeLine *animation, void *data)
{
	if (true == ViaCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CMultiObjectTransition*>(animation)));
		ViaCb.function.invoke(args);
	}

	return true;
}

bool InternalTransListener::OnStoped(class ITimeLine *animation, bool flagFinished, void *data)
{
	if (true == StopedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CMultiObjectTransition*>(animation)));
		args.set(1, ScriptObject(flagFinished));
		StopedCb.function.invoke(args);
	}

	return true;
}

void* TransListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalTransListener;
}

void TransListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);

	context.bindFunction<InternalTransListener, &InternalTransListener::GetStartedCallBack, &InternalTransListener::SetStartedCallBack>("onStarted");
	context.bindFunction<InternalTransListener, &InternalTransListener::GetViaCallBack, &InternalTransListener::SetViaCallBack>("onVia");
	context.bindFunction<InternalTransListener, &InternalTransListener::GetStopedCallBack, &InternalTransListener::SetStopedCallBack>("onStoped");
}

void* MultiObjectTransitionBridge::constructFromScript(const ScriptArray& args)
{
	CMultiObjectTransition *trans = new CMultiObjectTransition;
	trans->Initialize();
	return trans;
}

void MultiObjectTransitionBridge::destroyFromScript(void* destroyedObject)
{
	delete destroyedObject;
}

void MultiObjectTransitionBridge::mapScriptInterface(ScriptContext& context)
{
	context.captureMethodCall<CMultiObjectTransition, &m_SetDuration>("setDuration");
	context.captureMethodCall<CMultiObjectTransition, &m_AddObjectDestination>("AddObjectDestination");
	context.captureMethodCall<CMultiObjectTransition, &m_Play>("play");
	context.captureMethodCall<CMultiObjectTransition, &m_Stop>("stop");
	context.captureMethodCall<CMultiObjectTransition, &m_AddListener>("addListener");
}

IWidgetExtension::EAnimatableValue MultiObjectTransitionBridge::m_AniType(const ScriptObject &jsStringObject)
{
	IWidgetExtension::EAnimatableValue aniType = IWidgetExtension::ANI_MAX;
	std::string type = jsStringObject.asString();

	if ("position" == type)
	{
		aniType = IWidgetExtension::ACTOR_ANI_POSITION;
	}
	else if ("x" == type)
	{
		aniType = IWidgetExtension::ACTOR_ANI_POSITION_X;
	}
	else if ("y" == type)
	{
		aniType = IWidgetExtension::ACTOR_ANI_POSITION_Y;
	} 
/*	else if ("z" == type)
	{
		aniType = IWidgetExtension::ACTOR_ANI_POSITION_Z;
	}*/
	else if ("size" == type)
	{
		aniType = IWidgetExtension::ACTOR_ANI_SIZE;
	}
	else if ("alpha" == type)
	{
		aniType = IWidgetExtension::ACTOR_ANI_ALPHA;
	}
	else if ("scale-x" == type)
	{
		aniType = IWidgetExtension::ACTOR_ANI_SCALE_X;
	}
	else if ("scale-y" == type)
	{
		aniType = IWidgetExtension::ACTOR_ANI_SCALE_Y;
	}
	/*else if ("scale-z" == type)
	{
		aniType = IWidgetExtension::ACTOR_ANI_SCALE_Z;
	}*/

	HALO_EXCEPTION(IWidgetExtension::ANI_MAX != aniType, "The animation type is error");

	return aniType;
}

void MultiObjectTransitionBridge::m_SetDestination(CMultiObjectTransition* self, const ScriptArray& args)
{
	CAnimatable *aniObj = dynamic_cast<CAnimatable*>(unwrapNativeObject<Widget>(args[0]));
	HALO_EXCEPTION(NULL != aniObj, "First param must be widgetEx or imageWidgetEx or textWidgetEx");

	IWidgetExtension::EAnimatableValue aniType = m_AniType(args[1]);
	ScriptObject destVal = args[2];

	self->AddAnimatableObject(aniObj, aniType);

	switch (aniType)
	{
	case IWidgetExtension::ACTOR_ANI_POSITION:
		{
			TValue2f dest(destVal.get("x").asNumber(), destVal.get("y").asNumber());
			self->SetDestination(aniObj, aniType, &dest);
		}
		break;

	case IWidgetExtension::ACTOR_ANI_POSITION_X:
		{
			TValue1f dest(destVal.asNumber());
			self->SetDestination(aniObj, aniType, &dest);
		}
		break;

	case IWidgetExtension::ACTOR_ANI_POSITION_Y:
		{
			TValue1f dest(destVal.asNumber());
			self->SetDestination(aniObj, aniType, &dest);
		}
		break;

	case IWidgetExtension::ACTOR_ANI_SIZE:
		{
			TValue2f dest(destVal.get("w").asNumber(), destVal.get("h").asNumber());
			self->SetDestination(aniObj, aniType, &dest);
		}
		break;

	case IWidgetExtension::ACTOR_ANI_ALPHA:
		{
			TValue1i dest(destVal.asNumber());
			self->SetDestination(aniObj, aniType, &dest);
		}
		break;

	case IWidgetExtension::ACTOR_ANI_SCALE_X:
		{
			TValue1f dest(destVal.asNumber());
			self->SetDestination(aniObj, aniType, &dest);
		}
		break;

	case IWidgetExtension::ACTOR_ANI_SCALE_Y:
		{
			TValue1f dest(destVal.asNumber());
			self->SetDestination(aniObj, aniType, &dest);
		}
		break;

	default:
		break;
	}
}

ScriptObject MultiObjectTransitionBridge::m_SetDuration(CMultiObjectTransition* self, const ScriptArray& args)
{
	self->SetDuration((int)args[0].asNumber());
	return ScriptObject();
}

ScriptObject MultiObjectTransitionBridge::m_AddObjectDestination(CMultiObjectTransition* self, const ScriptArray& args)
{
	m_SetDestination(self, args);
	return ScriptObject();
}

ScriptObject MultiObjectTransitionBridge::m_Play(CMultiObjectTransition* self, const ScriptArray& args)
{
	if (0 == args.Length())
	{
		self->Play();
	}
	else
	{
		if (true == args[0].asBool())
		{
			self->Play();
		}
		else
		{
			self->JumpToDestination();
		}
	}
	
	return ScriptObject();
}

ScriptObject MultiObjectTransitionBridge::m_Stop(CMultiObjectTransition* self, const ScriptArray& args)
{
	if (0 == args.Length())
	{
		self->Stop();
	}
	else
	{
		if (true == args[0].asBool())
		{
			self->Stop();
		}
		else
		{
			self->StopAndJump(true);
		}
	}

	return ScriptObject();
}

ScriptObject MultiObjectTransitionBridge::m_AddListener(CMultiObjectTransition* self, const ScriptArray& args)
{
	InternalTransListener *listener = unwrapNativeObject<InternalTransListener>(args[0]);
	self->AddListener(listener, NULL);

	return ScriptObject();
}
