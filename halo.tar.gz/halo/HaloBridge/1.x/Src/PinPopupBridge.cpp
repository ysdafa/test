#include "HaloBridgeAll.h"

using namespace HALO;
using namespace Bridge;


void Bridge::PinPopupListenerBridge::mapScriptInterface( ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	context.bindFunction<InternalPinPopupListener, &InternalPinPopupListener::GetPinButtonEventCallBack, &InternalPinPopupListener::SetPinButtonEventCallBack>("onPinButtonEvent");	
	context.bindFunction<InternalPinPopupListener, &InternalPinPopupListener::GetValidConfirmCallBack, &InternalPinPopupListener::SetValidConfirmCallBack>("onValidConfirm");
	context.bindFunction<InternalPinPopupListener, &InternalPinPopupListener::GetCompareConfirmCallBack, &InternalPinPopupListener::SetCompareConfirmCallBack>("onCompareConfirm");
}

void* Bridge::PinPopupListenerBridge::constructFromScript( const ScriptArray& args )
{
	return new InternalPinPopupListener;
}

void Bridge::PinPopupBridge::mapScriptInterface( ScriptContext& context )
{
	ActorBridge::mapScriptInterface(context);
	context.bindString<CPinPopup, &CPinPopup::ContentText, &CPinPopup::SetContentText>("contentText");
	context.bindString<CPinPopup, &CPinPopup::ContentTextFont, &CPinPopup::SetContentTextFont>("contentTextFont");
	context.bindNumber<CPinPopup, int ,&CPinPopup::ContentTextFontSize, &CPinPopup::SetContentTextFontSize>("contentTextFontSize");
	
	context.bindNumber<CPinPopup, int, &CPinPopup::PinBoxItemDigitFontSize, &CPinPopup::SetPinBoxItemDigitFontSize>("pinBoxItemDigitFontSize");
	context.bindString<CPinPopup,&CPinPopup::PinBoxItemDigitFont, &CPinPopup::SetPinBoxItemDigitFont>("pinBoxItemDigitFont");

	context.captureMethodCall<CPinPopup, &setTitletText>("setTitletText");
	context.captureMethodCall<CPinPopup, &setTitletTextFontSize>("setTitletTextFontSize");
	context.captureMethodCall<CPinPopup, &setTitletTextColor>("setTitletTextColor");
	
	context.captureMethodCall<CPinPopup, &setContentText>("setContentText");
	context.captureMethodCall<CPinPopup, &setContentTextFont>("setContentTextFont");
	context.captureMethodCall<CPinPopup, &setContentTextFontSize>("setContentTextFontSize");
	context.captureMethodCall<CPinPopup, &setContentTextFontColor>("setContentTextFontColor");
	context.captureMethodCall<CPinPopup, &setPinBoxItemImage>("setPinBoxItemImage");
	context.captureMethodCall<CPinPopup, &setPinBoxBackGroundImage>("setPinBoxBackGroundImage");
	context.captureMethodCall<CPinPopup, &setPinBoxDescriptionText>("setPinBoxDescriptionText");

	context.captureMethodCall<CPinPopup, &setPinBoxDescriptionTextFontSize>("setPinBoxDescriptionTextFontSize");
	context.captureMethodCall<CPinPopup, &setPinBoxDescriptionTextColor>("setPinBoxDescriptionTextColor");

	context.captureMethodCall<CPinPopup, &setPinBoxItemDigitFontSize>("setPinBoxItemDigitFontSize");
	context.captureMethodCall<CPinPopup, &setPinBoxItemDigitColor>("setPinBoxItemDigitColor");
	context.captureMethodCall<CPinPopup, &setPinBoxItemDigitFont>("setPinBoxItemDigitFont");

	context.captureMethodCall<CPinPopup, &setPinBoxFocus>("setPinBoxFocus");
	context.captureMethodCall<CPinPopup, &setButtonRect>("setButtonRect");
	context.captureMethodCall<CPinPopup, &setButtonImage>("setButtonImage");
	context.captureMethodCall<CPinPopup, &setButtonText>("setButtonText");
	context.captureMethodCall<CPinPopup, &setButtonTextColor>("setButtonTextColor");
	context.captureMethodCall<CPinPopup, &setButtonTextFontSize>("setButtonTextFontSize");
	context.captureMethodCall<CPinPopup, &setButtonBackgroundColor>("setButtonBackgroundColor");
	
	context.captureMethodCall<CPinPopup, &setTitleSize>("setTitleSize");
	context.captureMethodCall<CPinPopup, &setTitlePosition>("setTitlePosition");
	context.captureMethodCall<CPinPopup, &setContentRect>("setContentRect");
	context.captureMethodCall<CPinPopup, &setPinBoxDescriptionRect>("setPinBoxDescriptionSize");
	context.captureMethodCall<CPinPopup, &setPinBoxRect>("setPinBoxRect");
	context.captureMethodCall<CPinPopup, &setTitleLineRect>("setTitleLineRect");
	context.captureMethodCall<CPinPopup, &setDigitTextSize>("setDigitTextSize");
	context.captureMethodCall<CPinPopup, &setDigitGap>("setDigitGap");
	context.captureMethodCall<CPinPopup, &setInputItemsGap>("setInputItemsGap");
	context.captureMethodCall<CPinPopup, &setInputBoxItemSize>("setInputBoxItemSize");
	context.captureMethodCall<CPinPopup, &resetPassWord>("resetPassWord");
	context.captureMethodCall<CPinPopup, &addListener>("addListener");
	context.captureMethodCall<CPinPopup, &removeListener>("removeListener");
	context.captureMethodCall<CPinPopup, &setButtonPosition>("setButtonPosition");
	context.captureMethodCall<CPinPopup, &setButtonSize>("setButtonSize");
}

Widget* Bridge::PinPopupBridge::constructWidget( float x, float y, float width, float height, Widget* parent, const ScriptArray& args )
{
	CPinPopup::TPinPopupAttr attr;
	ScriptObject options;
	int argsLen = args.Length();
	if (argsLen > 0)
	{
		options = args[0];
		parsePinPopupParams(options, attr);
	}
	CPinPopup *pinpopup = dynamic_cast<CPinPopup *>(IPinPopup::CreateInstance(parent, attr));
	if (NULL == pinpopup)
	{
		return NULL;
	}
	ClutterColor c2 = { 255, 255, 255, 255 };
	pinpopup->SetTitleTextColor(c2);
	pinpopup->SetTitleTextFontSize(44);
	if (options.has("title"))
	{
		std::string title = options.get("title").asString();
		pinpopup->SetTitle(title.c_str());
	}
	if (options.has("contenttext"))
	{
		std::string contenttext = options.get("contenttext").asString();
		pinpopup->SetContentText(contenttext.c_str());
	}
	if (options.has("isContent"))
	{
		bool iscontent = options.get("isContent").asBool();
		if (iscontent)
		{
			pinpopup->SetContentTextFont("Sans 34px");
			pinpopup->SetContentTextFontColor(c2);
		}
	}
	return pinpopup;
}

Bridge::ScriptObject Bridge::PinPopupBridge::setContentText( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string text = object.get("text").asString();
	self->SetContentText(text.c_str());
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setContentTextFont( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string font = object.get("font").asString();
	self->SetContentTextFont( font.c_str());
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setContentTextFontSize( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	int fontsize = object.get("fontsize").asNumber();
	self->SetContentTextFontSize( fontsize);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setContentTextFontColor( CPinPopup* self, const ScriptArray &args )
{	
	ScriptObject object = args[0];
	ScriptObject colorObj = object.get("color");
	Color color = ScriptToColor(colorObj);
	self->SetContentTextFontColor( *(color.toClutterColor()));
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setPinBoxBackGroundImage( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string state = object.get("state").asString();
	std::string imagePath = object.get("src").asString();
	self->SetPinBoxBackGroundImage(deserializeState(state, CPinPopup::E_STATE_NORMAL), imagePath);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setPinBoxItemImage( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string state = object.get("state").asString();
	std::string imagePath = object.get("src").asString();

	self->SetPinBoxItemImage(deserializeState(state, CPinPopup::E_STATE_NOINPUT), imagePath);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setPinBoxDescriptionText( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string pintype = object.get("pintype").asString();
	std::string text = object.get("text").asString();
	self->SetPinBoxDescriptionText(deserializeState(pintype, CPinPopup::E_PINNUMBER_ONE), text.c_str());
	return ScriptObject();
}


Bridge::ScriptObject Bridge::PinPopupBridge::setPinBoxDescriptionTextFontSize( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string pintype = object.get("pintype").asString();
	int fontsize = object.get("fontsize").asNumber();
	self->SetPinBoxDescriptionTextFontSize(deserializeState(pintype, CPinPopup::E_PINNUMBER_ONE), fontsize);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setPinBoxDescriptionTextColor( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string pintype = object.get("pintype").asString();
	ScriptObject colorObj = object.get("color");
	Color color = ScriptToColor(colorObj);
	self->SetPinBoxDescriptionTextColor(deserializeState(pintype, CPinPopup::E_PINNUMBER_ONE), *(color.toClutterColor()));
	return ScriptObject();
}



Bridge::ScriptObject Bridge::PinPopupBridge::resetPassWord( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string pintype = object.get("pintype").asString();
	self->ResetPassWord(deserializeState(pintype, CPinPopup::E_PINNUMBER_ONE));
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::addListener( CPinPopup* self, const ScriptArray &args )
{
	if (args.Length() > 0)
	{
		IPinPopupListener* listener = unwrapNativeObject<IPinPopupListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddListener(listener);
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::removeListener( CPinPopup* self, const ScriptArray &args )
{
	if (args.Length() > 0)
	{
		IPinPopupListener* listener = unwrapNativeObject<IPinPopupListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveListener(listener);
		}
	}
	return ScriptObject();
}

CPinPopup::EInputBoxState Bridge::PinPopupBridge::deserializeState( std::string stateStr, CPinPopup::EInputBoxState theDefault )
{
	if (compareStrChar(stateStr, "focus_state"))
	{
		return CPinPopup::E_STATE_FOCUSED;
	}
	else if (compareStrChar(stateStr, "normal_state"))
	{
		return CPinPopup::E_STATE_NORMAL;
	}
	else
	{
		return theDefault;
	}
}

CPinPopup::EInputItemsState Bridge::PinPopupBridge::deserializeState( std::string stateStr, CPinPopup::EInputItemsState theDefault )
{
	if (compareStrChar(stateStr, "no_input_type"))
	{
		return CPinPopup::E_STATE_NOINPUT;
	}
	else if (compareStrChar(stateStr, "finish_input_type"))
	{
		return CPinPopup::E_STATE_FINISHINPUT;
	}
	else if (compareStrChar(stateStr, "all_input_type"))
	{
		return CPinPopup::E_STATE_INPUT_ALL;
	}
	else
	{
		return theDefault;
	}
}

CPinPopup::E_PINNUMBER_TYPE Bridge::PinPopupBridge::deserializeState( std::string stateStr, CPinPopup::E_PINNUMBER_TYPE theDefault )
{
	if (compareStrChar(stateStr, "pinbox_one"))
	{
		return CPinPopup::E_PINNUMBER_ONE;
	}
	else if (compareStrChar(stateStr, "pinbox_two"))
	{
		return CPinPopup::E_PINNUMBER_TWO;
	}
	else if (compareStrChar(stateStr, "pinbox_all"))
	{
		return CPinPopup::E_PINNUMBER_ALL;
	}
	else
	{
		return theDefault;
	}
}

void Bridge::PinPopupBridge::parsePinPopupParams( const ScriptObject& options, CPinPopup::TPinPopupAttr& attr )
{
	if (options.has("x"))
	{
		attr.x = static_cast<float>(options.get("x").asNumber());
	}
	if (options.has("y"))
	{
		attr.y = static_cast<float>(options.get("y").asNumber());
	}
	if (options.has("width"))
	{
		attr.w = static_cast<float>(options.get("width").asNumber());
	}
	if (options.has("height"))
	{
		attr.h = static_cast<float>(options.get("height").asNumber());
	}
	if (options.has("pinType"))
	{
		attr.pinType = deserializeState(options.get("pinType").asString(), CPinPopup::E_PINNUMBER_ONE);
	}
	if (options.has("isTitle"))
	{
		attr.isTitle = static_cast<float>(options.get("isTitle").asBool());
	}	
	if (options.has("isContent"))
	{
		attr.isContent = static_cast<float>(options.get("isContent").asBool());
	}
	if (options.has("buttonNum"))
	{
		attr.buttonNum = static_cast<float>(options.get("buttonNum").asNumber());
	}
	if (options.has("autoArrange"))
	{
		attr.isAutoArrange = static_cast<float>(options.get("autoArrange").asBool());
	}
}

Bridge::ScriptObject Bridge::PinPopupBridge::setTitletText( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string text = object.get("text").asString();
	self->SetTitle(text.c_str());
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setTitletTextFontSize( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	int fontsize = object.get("fontsize").asNumber();
	self->SetTitleTextFontSize(fontsize);
	return ScriptObject();

}

Bridge::ScriptObject Bridge::PinPopupBridge::setTitletTextColor( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	ScriptObject colorObj = object.get("color");
	Color color = ScriptToColor(colorObj);
	self->SetTitleTextColor(*(color.toClutterColor()));
	return ScriptObject();

}

Bridge::ScriptObject Bridge::PinPopupBridge::setPinBoxItemDigitFontSize( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	int fontsize = object.get("fontsize").asNumber();
	self->SetPinBoxItemDigitFontSize(fontsize);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setPinBoxItemDigitColor( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	ScriptObject colorObj = object.get("color");
	Color color = ScriptToColor(colorObj);
	self->SetPinBoxItemDigitColor(*(color.toClutterColor()));
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setPinBoxItemDigitFont( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string font = object.get("font").asString();
	self->SetPinBoxItemDigitFont(font.c_str());
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setPinBoxFocus( CPinPopup* self, const ScriptArray &args )
{
	ScriptObject object = args[0];
	std::string pintype = object.get("pintype").asString();
	self->SetPinBoxFocus(deserializeState(pintype, CPinPopup::E_PINNUMBER_ONE));
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setButtonRect( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string buttonIndex = object.get("buttonIndex").asString();
	float x = object.get("x").asNumber();
	float y = object.get("y").asNumber();
	float w = object.get("w").asNumber();
	float h = object.get("h").asNumber();
	self->SetButtonRect(deserializeButtonState(buttonIndex , IPinPopup::BUTTON_ALL), x, y , w, h);
	return ScriptObject();
}


Bridge::ScriptObject Bridge::PinPopupBridge::setButtonImage( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string buttonIndex = object.get("buttonIndex").asString();
	std::string state = object.get("state").asString();
	std::string imagePath = object.get("src").asString();
	self->SetButtonImage(deserializeButtonState(buttonIndex , IPinPopup::BUTTON_ALL), ButtonBridge::deserializeState(state, IButton::STATE_NORMAL), imagePath);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setButtonText( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string buttonIndex = object.get("buttonIndex").asString();
	std::string state = object.get("state").asString();
	std::string text = object.get("text").asString();
	self->SetButtonText(deserializeButtonState(buttonIndex , IPinPopup::BUTTON_ALL), ButtonBridge::deserializeState(state, IButton::STATE_NORMAL), text);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setButtonTextColor( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	ScriptObject colorObj = object.get("color");
	Color color = ScriptToColor(colorObj);
	std::string buttonIndex = object.get("buttonIndex").asString();
	std::string state = object.get("state").asString();
	self->SetButtonTextColor(deserializeButtonState(buttonIndex , IPinPopup::BUTTON_ALL), ButtonBridge::deserializeState(state, IButton::STATE_NORMAL),*(color.toClutterColor()));
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setButtonTextFontSize( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string buttonIndex = object.get("buttonIndex").asString();
	std::string state = object.get("state").asString();
	int fontSize = object.get("fontSize").asNumber();
	self->SetButtonTextFontSize(deserializeButtonState(buttonIndex , IPinPopup::BUTTON_ALL), ButtonBridge::deserializeState(state, IButton::STATE_NORMAL), fontSize);
	return ScriptObject();
}

CPinPopup::EPinPopupButtons Bridge::PinPopupBridge::deserializeButtonState( std::string stateStr, CPinPopup::EPinPopupButtons theDefault )
{
	if (compareStrChar(stateStr, "button_1"))
	{
		return CPinPopup::BUTTON_1;
	}
	else if (compareStrChar(stateStr, "button_2"))
	{
		return CPinPopup::BUTTON_2;
	}
	else if (compareStrChar(stateStr, "button_all"))
	{
		return CPinPopup::BUTTON_ALL;
	}
	else
	{
		return theDefault;
	}
}


Bridge::ScriptObject Bridge::PinPopupBridge::setTitleSize( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	float w = object.get("w").asNumber();
	float h = object.get("h").asNumber();
	self->UpdateTitleSize(w, h);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setTitlePosition( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	float x = object.get("x").asNumber();
	float y = object.get("y").asNumber();
	self->UpdateTitlePosition(x, y);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setPinBoxDescriptionRect( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	float x = object.get("x").asNumber();
	float y = object.get("y").asNumber();
	float w = object.get("w").asNumber();
	float h = object.get("h").asNumber();
	std::string pintype = object.get("pintype").asString();
	self->SetPinBoxDescriptionRect(deserializeState(pintype, CPinPopup::E_PINNUMBER_ONE),x, y , w, h);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setContentRect( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	float x = object.get("x").asNumber();
	float y = object.get("y").asNumber();
	float w = object.get("w").asNumber();
	float h = object.get("h").asNumber();
	self->SetContentRect(x, y , w, h);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setButtonBackgroundColor( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	ARG_HAS_STRING(object, "color");
	ScriptObject colorObj = object.get("color");
	Color color = ScriptToColor(colorObj);
	std::string buttonIndex = object.get("buttonIndex").asString();
	std::string state = object.get("state").asString();
	self->SetButtonBackgroundColor(deserializeButtonState(buttonIndex , IPinPopup::BUTTON_ALL), ButtonBridge::deserializeState(state, IButton::STATE_NORMAL), *(color.toClutterColor()));
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setPinBoxRect( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string pintype = object.get("pintype").asString();
	float x = object.get("x").asNumber();
	float y = object.get("y").asNumber();
	float w = object.get("w").asNumber();
	float h = object.get("h").asNumber();
	self->SetPinBoxRect(deserializeState(pintype, CPinPopup::E_PINNUMBER_ONE) , x, y , w, h);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setTitleLineRect( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	float x = object.get("x").asNumber();
	float y = object.get("y").asNumber();
	float w = object.get("w").asNumber();
	float h = object.get("h").asNumber();
	self->SetTitleLineRect(x , y, w, h);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setDigitTextSize( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	float w = object.get("w").asNumber();
	float h = object.get("h").asNumber();
	self->SetDigitTextSize(w , h);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setInputBoxItemSize( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	float w = object.get("w").asNumber();
	float h = object.get("h").asNumber();
	std::string type = object.get("type").asString();
	if (!type.empty())
	{
		self->SetInputBoxItemSize(deserializeState(type, CPinPopup::E_STATE_NOINPUT), w , h);
	}
	else
	{
		self->SetInputBoxItemSize(IPinPopup::E_STATE_INPUT_ALL, w , h);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setButtonPosition( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string buttonIndex = object.get("buttonIndex").asString();
	float x = object.get("x").asNumber();
	float y = object.get("y").asNumber();
	self->SetButtonPosition(deserializeButtonState(buttonIndex , IPinPopup::BUTTON_ALL), x, y);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setButtonSize( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	std::string buttonIndex = object.get("buttonIndex").asString();
	float w = object.get("w").asNumber();
	float h = object.get("h").asNumber();
	self->SetButtonSize(deserializeButtonState(buttonIndex , IPinPopup::BUTTON_ALL), w, h);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setDigitGap( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	float gap = object.get("gap").asNumber();
	self->SetDigitGap(gap);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::PinPopupBridge::setInputItemsGap( CPinPopup* self, const ScriptArray &args )
{
	ASSERT(1 == args.Length());
	ScriptObject object = args[0];
	float gap = object.get("gap").asNumber();
	std::string type = object.get("type").asString();
	if (!type.empty())
	{
		self->SetInputItemsGap(deserializeState(type, CPinPopup::E_STATE_NOINPUT), gap);
	}
	else
	{
		self->SetInputItemsGap(IPinPopup::E_STATE_INPUT_ALL , gap);
		
	}
	return ScriptObject();
}

bool Bridge::InternalPinPopupListener::OnValidConfirm( class IPinPopup* list , bool isPassWordRight )
{
	if (true == ValidConfirmCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<IPinPopup*>(list)));
		args.set(1, isPassWordRight);
		ValidConfirmCb.function.invoke(args);
	}
	return true;
}

bool Bridge::InternalPinPopupListener::OnCompareConfirm( class IPinPopup* list , bool isPassWordRight , const char* pin1Pwd , const char* pin2Pwd )
{
	if (true == CompareConfirmCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<IPinPopup*>(list)));
		args.set(1, isPassWordRight);
		args.set(2, pin1Pwd);
		args.set(3, pin2Pwd);
		CompareConfirmCb.function.invoke(args);
	}
	return true;
}

bool Bridge::InternalPinPopupListener::OnButtonEvent( class IPinPopup* pinpopup, const int nButtonIndex, EEventTypes eventType )
{
	if (true == PinButtonEventCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CPopupRating*>(pinpopup)));
		args.set(1, ScriptObject(deserializeButtonState(nButtonIndex)));
		args.set(2, ScriptObject(deserializeState(eventType)));
		PinButtonEventCb.function.invoke(args);
	}
	return true;
}

std::string Bridge::InternalPinPopupListener::deserializeState( IPinPopupListener::EEventTypes eventType )
{
	if ( IPinPopupListener::BUTTON_FOCUS_IN == eventType)
	{
		return "button_focus_in";
	}
	else if (IPinPopupListener::BUTTON_FOCUS_OUT == eventType)
	{
		return "button_focus_out";
	}
	else if (IPinPopupListener::BUTTON_CLICKED == eventType)
	{
		return "button_clicked";
	}
	else if (IPinPopupListener::BUTTON_PRESSED == eventType)
	{
		return "button_pressed";
	}
	else
	{
		return "";
	}
}

std::string Bridge::InternalPinPopupListener::deserializeButtonState( CPinPopup::EPinPopupButtons buttonType )
{
	if (IPinPopup::BUTTON_1 == buttonType)
	{
		return "button_1";
	}
	else if (IPinPopup::BUTTON_2 == buttonType)
	{
		return "button_2";
	}
	else if (IPinPopup::BUTTON_ALL == buttonType)
	{
		return "button_all";
	}
	else
	{
		return "";
	}
}
