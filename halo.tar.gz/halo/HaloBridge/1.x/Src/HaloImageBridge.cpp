#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void HaloImageBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.captureMethodCall<CImage, &setImage>("setImage");
}

Widget* HaloImageBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	CImage* cimage = dynamic_cast<CImage*>(IImage::CreateInstance(parent, width, height));

	return cimage;
}

ScriptObject HaloImageBridge::setImage(CImage* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args[0].isString())
		{
			self->SetImage(args[0].asString().data());
		}
		else
		{
			IImageBuffer* buffer = unwrapNativeObject<IImageBuffer>(args[0]);
			self->SetImage(buffer);
		}
	}

	return ScriptObject();
}
