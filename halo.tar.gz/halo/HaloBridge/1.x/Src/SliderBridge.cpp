#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void SliderBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.captureMethodCall<CSlider, &setMinMaxValue>("setMinMaxValue");
	context.captureMethodCall<CSlider, &setValue>("setValue");
	context.captureMethodCall<CSlider, &setThumbImage>("setThumbImage");
	context.captureMethodCall<CSlider, &setThumbSize>("setThumbSize");
	context.captureMethodCall<CSlider, &setFillImage>("setFillImage");
	context.captureMethodCall<CSlider, &setBackgroundImage>("setBackgroundImage");
	context.captureMethodCall<CSlider, &addListener>("addListener");
	context.captureMethodCall<CSlider, &removeListener>("removeListener");
}

Widget* Bridge::SliderBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	ScriptObject argObject = args[0];
	EDirectionType direction = TYPE_HORIZONTAL;
	if (argObject.has("direction"))
	{
		std::string directionStr = argObject.get("direction").asString();
		if (directionStr == "horizontal")
		{
			direction = TYPE_HORIZONTAL;
		}
		else
		{
			direction = TYPE_VERTICAL;
		}
	}

	CSlider* slider = dynamic_cast<CSlider *>(ISlider::CreateInstance(parent, width, height, direction));
	return slider;
}

Bridge::ScriptObject Bridge::SliderBridge::setMinMaxValue(CSlider* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 2);

	int minValue = static_cast<int>(args[0].asNumber());
	int maxValue = static_cast<int>(args[1].asNumber());
	self->SetMinMaxValue(minValue, maxValue);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::SliderBridge::setValue(CSlider* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);

	int value = static_cast<int>(args[0].asNumber());
	self->SetValue(value);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::SliderBridge::setThumbImage(CSlider* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 2);

	std::string stateStr = args[0].asString();
	IButton::EButtonState state;

	if (stateStr == "state_all")
	{
		state = IButton::STATE_ALL;
	}
	else
	{
		state = IButton::STATE_SELECTED;
	}

	std::string imagePath = args[1].asString();

	//self->SetThumbImage(state, imagePath);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::SliderBridge::setThumbSize(CSlider* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 2);

	float width = static_cast<float>(args[0].asNumber());
	float height = static_cast<float>(args[1].asNumber());

	self->SetThumbSize(width, height);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::SliderBridge::setFillImage(CSlider* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);

	IImageBuffer *imageBuffer = unwrapNativeObject<IImageBuffer>(args[0]);
	self->SetFillImage(imageBuffer);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::SliderBridge::setBackgroundImage(CSlider* self, const ScriptArray& args)
{
	IImageBuffer *imageBuffer = unwrapNativeObject<IImageBuffer>(args[0]);
	self->SetBackgroundImage(imageBuffer);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::SliderBridge::addListener(CSlider* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);

	ISliderListener* listener = unwrapNativeObject<ISliderListener>(args[0]);
	ASSERT(listener != NULL);
	self->AddListener(listener);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::SliderBridge::removeListener(CSlider* self, const ScriptArray& args)
{
	ASSERT(args.Length() == 1);

	ISliderListener* listener = unwrapNativeObject<ISliderListener>(args[0]);
	ASSERT(listener != NULL);

	self->RemoveListener(listener);

	return ScriptObject();
}
