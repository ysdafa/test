#include "HaloBridgeAll.h"

using namespace HALO;
using namespace Bridge;

void SubListListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	context.bindFunction<InternalSubListListener, &InternalSubListListener::GetItemClickedCallBack, &InternalSubListListener::SetItemClickedCallBack>("OnItemClicked");
	context.bindFunction<InternalSubListListener, &InternalSubListListener::GetFocusChangedCallBack, &InternalSubListListener::SetFocusChangedCallBack>("OnFocusChanged");
	context.bindFunction<InternalSubListListener, &InternalSubListListener::GetEnterKeyLongPressedCallBack, &InternalSubListListener::SetEnterKeyLongPressedCallBack>("OnEnterKeyLongPressed");
	context.bindFunction<InternalSubListListener, &InternalSubListListener::GetTimeOutCallBack, &InternalSubListListener::SetTimeOutCallBack>("OnTimeOut");
}

void* SubListListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalSubListListener;
}

bool InternalSubListListener::OnItemClicked(class ISubList* subList, int itemIndex)
{
	if (true == ItemClickedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CSubList*>(subList)));
		args.set(1, ScriptObject(itemIndex));
		ItemClickedCb.function.invoke(args);
	}
	return true;
}

bool InternalSubListListener::OnFocusChanged(class ISubList* subList, int fromItemIndex, int toItemIndex)
{
	if (true == FocusChangedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CSubList*>(subList)));
		args.set(1, ScriptObject(fromItemIndex));
		args.set(2, ScriptObject(toItemIndex));
		FocusChangedCb.function.invoke(args);
	}
	return true;
}

bool InternalSubListListener::OnEnterKeyLongPressed(class ISubList* subList, int itemIndex)
{
	if (true == EnterKeyLongPressedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CSubList*>(subList)));
		args.set(1, ScriptObject(itemIndex));
		EnterKeyLongPressedCb.function.invoke(args);
	}
	return true;
}

bool InternalSubListListener::OnTimeOut(class ISubList* subList)
{
	if (true == TimeOutCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CSubList*>(subList)));
		TimeOutCb.function.invoke(args);
	}
	return true;
}
//SubListBridge
void SubListBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.captureMethodCall<CSubList, &setFirstLayerBGColor>("setFirstLayerBGColor");
	context.captureMethodCall<CSubList, &setSecondLayerBGColor>("setSecondLayerBGColor");
	context.captureMethodCall<CSubList, &setThirdLayerBGBorderWidth>("setThirdLayerBGBorderWidth");
	context.captureMethodCall<CSubList, &setThirdLayerBGBorderColor>("setThirdLayerBGBorderColor");
	context.captureMethodCall<CSubList, &setFourthLayerBGImage>("setFourthLayerBGImage");
	context.captureMethodCall<CSubList, &addItem>("addItem");
	context.captureMethodCall<CSubList, &addData>("addData");
	context.captureMethodCall<CSubList, &updateItem>("updateItem");
	context.captureMethodCall<CSubList, &deleteItem>("deleteItem");
	context.captureMethodCall<CSubList, &updateAllItems>("updateAllItems");
	context.captureMethodCall<CSubList, &setDataSource>("setDataSource");
	context.captureMethodCall<CSubList, &setSingleLineListPosition>("setSingleLineListPosition");
	context.captureMethodCall<CSubList, &setArrowImageAttr>("setArrowImageAttr");
	context.captureMethodCall<CSubList, &setButtonAttr>("setButtonAttr");
	context.captureMethodCall<CSubList, &numofItem>("numofItem");
	context.captureMethodCall<CSubList, &setDim>("setDim");
	context.captureMethodCall<CSubList, &ifDim>("ifDim");
	context.captureMethodCall<CSubList, &showFocus>("showFocus");
	context.captureMethodCall<CSubList, &hideFocus>("hideFocus");
	context.captureMethodCall<CSubList, &setFocus>("setFocus");
	context.captureMethodCall<CSubList, &killFocus>("killFocus");
	context.captureMethodCall<CSubList, &text>("text");
	context.captureMethodCall<CSubList, &text2>("text2");
	context.captureMethodCall<CSubList, &setAnimationDuration>("setAnimationDuration");

	context.captureMethodCall<CSubList, &addListener>("addListener");
	context.captureMethodCall<CSubList, &removeListener>("removeListener");

	context.bindNumber<CSubList, int, &CSubList::FocusItemIndex, &CSubList::SetFocusItemIndex>("focusItemIndex");
	context.bindNumber<CSubList, int, &CSubList::CheckItemIndex, &CSubList::SetCheckItemIndex>("checkItemIndex");
	context.bindNumber<CSubList, guint, &CSubList::ShowTime, &CSubList::SetShowTime>("showTime");
}

Widget* SubListBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	CSubList::TSubListAttr attr;
	ScriptObject options;
	int argsLen = args.Length();
	if (argsLen > 0)
	{
		options = args[0];
		parseSubListParams(options, attr);
	}

	CSubList *SubList = dynamic_cast<CSubList *>(ISubList::CreateInstance(parent, attr));
	if (SubList == NULL)
	{
		return NULL;
	}

	if (options.has("firstLayerBGColor"))
	{
		guint8 r = 0, g = 0, b = 0, a = 0;
		ScriptObject firstLayerBGColor = options.get("firstLayerBGColor");
		if (firstLayerBGColor.has("r")) { r = (guint8)firstLayerBGColor.get("r").asNumber(); }
		if (firstLayerBGColor.has("g")) { g = (guint8)firstLayerBGColor.get("g").asNumber(); }
		if (firstLayerBGColor.has("b")) { b = (guint8)firstLayerBGColor.get("b").asNumber(); }
		if (firstLayerBGColor.has("a")) { a = (guint8)firstLayerBGColor.get("a").asNumber(); }
		ClutterColor firstLayerColor = {r, g, b, a};
		SubList->SetFirstLayerBGColor(firstLayerColor);
	}

	if (options.has("fourthLayerBGImage"))
	{
		std::string imagePath = "";
		imagePath = options.get("fourthLayerBGImage").asString();
		SubList->SetFourthLayerBGImage(imagePath);
	}	

	return dynamic_cast<CSubList*>(SubList);
}

Bridge::ScriptObject SubListBridge::setFirstLayerBGColor(CSubList* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	ScriptObject options;
	int argsLen = args.Length();
	if (argsLen > 0)
	{
		options = args[0];
		guint8 r = 0, g = 0, b = 0, a = 0;

		if (options.has("firstLayerBGColor"))
		{
			ScriptObject firstLayerBGColor = options.get("firstLayerBGColor");
			if (firstLayerBGColor.has("r")) { r = (guint8)firstLayerBGColor.get("r").asNumber(); }
			if (firstLayerBGColor.has("g")) { g = (guint8)firstLayerBGColor.get("g").asNumber(); }
			if (firstLayerBGColor.has("b")) { b = (guint8)firstLayerBGColor.get("b").asNumber(); }
			if (firstLayerBGColor.has("a")) { a = (guint8)firstLayerBGColor.get("a").asNumber(); }
		}
		ClutterColor firstLayerColor = {r, g, b, a};
		self->SetFirstLayerBGColor(firstLayerColor);
	}
	return ScriptObject();
}

Bridge::ScriptObject SubListBridge::setSecondLayerBGColor(CSubList* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	ScriptObject options;
	int argsLen = args.Length();
	if (argsLen > 0)
	{
		options = args[0];
		guint8 r = 0, g = 0, b = 0, a = 0;

		if (options.has("secondLayerBGColor"))
		{
			ScriptObject secondLayerBGColor = options.get("secondLayerBGColor");
			if (secondLayerBGColor.has("r")) { r = (guint8)secondLayerBGColor.get("r").asNumber(); }
			if (secondLayerBGColor.has("g")) { g = (guint8)secondLayerBGColor.get("g").asNumber(); }
			if (secondLayerBGColor.has("b")) { b = (guint8)secondLayerBGColor.get("b").asNumber(); }
			if (secondLayerBGColor.has("a")) { a = (guint8)secondLayerBGColor.get("a").asNumber(); }
		}
		ClutterColor secondLayerColor = {r, g, b, a};
		self->SetSecondLayerBGColor(secondLayerColor);
	}
	return ScriptObject();
}

Bridge::ScriptObject SubListBridge::setThirdLayerBGBorderWidth(CSubList* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	float borderWidth = 0.0;
	if(args.has(0) && args[0].isNumber()) { borderWidth = (float)args[0].asNumber(); }

	self->SetThirdLayerBGBorderWidth(borderWidth);
	
	return ScriptObject();
}

Bridge::ScriptObject SubListBridge::setThirdLayerBGBorderColor(CSubList* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	ScriptObject options;
	int argsLen = args.Length();
	if (argsLen > 0)
	{
		options = args[0];
		guint8 r = 0, g = 0, b = 0, a = 0;

		if (options.has("thirdLayerBGBorderColor"))
		{
			ScriptObject thirdLayerBGBorderColor = options.get("thirdLayerBGBorderColor");
			if (thirdLayerBGBorderColor.has("r")) { r = (guint8)thirdLayerBGBorderColor.get("r").asNumber(); }
			if (thirdLayerBGBorderColor.has("g")) { g = (guint8)thirdLayerBGBorderColor.get("g").asNumber(); }
			if (thirdLayerBGBorderColor.has("b")) { b = (guint8)thirdLayerBGBorderColor.get("b").asNumber(); }
			if (thirdLayerBGBorderColor.has("a")) { a = (guint8)thirdLayerBGBorderColor.get("a").asNumber(); }
		}
		ClutterColor thirdLayerBorderColor = {r, g, b, a};
		self->SetThirdLayerBGBorderColor(thirdLayerBorderColor);
	}
	return ScriptObject();
}

Bridge::ScriptObject SubListBridge::setFourthLayerBGImage(CSubList* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	ScriptObject options;
	int argsLen = args.Length();
	if (argsLen > 0)
	{
		options = args[0];
		std::string imagePath = "";

		if (options.has("fourthLayerBGImage"))
		{
			imagePath = options.get("fourthLayerBGImage").asString();
			self->SetFourthLayerBGImage(imagePath);
		}
	}
	
	return ScriptObject();
}

Bridge::ScriptObject SubListBridge::addItem(CSubList* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	ScriptObject options;
	int argsLen = args.Length();
	if (argsLen > 0)
	{
		int itemNum = 0;
		float itemSpace = 150, itemGap = 0;
		options = args[0];
		if(options.has("itemNum"))
		{ 
			itemNum = (int)options.get("itemNum").asNumber();
		}
		if(options.has("itemSpace"))
		{ 
			itemSpace = (float)options.get("itemSpace").asNumber();
		}
		if(options.has("itemGap"))
		{ 
			itemGap = (float)options.get("itemGap").asNumber();
		}
		self->AddItem(itemNum, itemSpace, itemGap);
	}
	return ScriptObject();
}

Bridge::ScriptObject SubListBridge::addData(CSubList* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	ScriptObject options;
	int argsLen = args.Length();
	if (argsLen > 0)
	{
		options = args[0];
		int index = 0;
		CSubList::TItemDataInfo itemDataInfo;
		guint8 r = 0, g = 0, b = 0, a = 255;
		if (options.has("index") && options.get("index").isNumber())
		{
			index = options.get("index").asNumber();
		}
		else
		{
			return ScriptObject();
		}

		if (options.has("image"))
		{
			ScriptObject imageObj = options.get("image");
			if (imageObj.has("x")) { itemDataInfo.imageInfo.imageAlloc.x = imageObj.get("x").asNumber(); }
			if (imageObj.has("y")) { itemDataInfo.imageInfo.imageAlloc.y = imageObj.get("y").asNumber(); }
			if (imageObj.has("width")) { itemDataInfo.imageInfo.imageAlloc.w = imageObj.get("width").asNumber(); }
			if (imageObj.has("height")) { itemDataInfo.imageInfo.imageAlloc.h = imageObj.get("height").asNumber(); }
			if (imageObj.has("normalImagePath")) { itemDataInfo.imageInfo.normalImagePath = imageObj.get("normalImagePath").asString(); }
			if (imageObj.has("focusedImagePath")) { itemDataInfo.imageInfo.focusedImagePath = imageObj.get("focusedImagePath").asString(); }
			if (imageObj.has("dimImagePath")) { itemDataInfo.imageInfo.dimImagePath = imageObj.get("dimImagePath").asString(); }
			if (imageObj.has("normalAlpha"))	{ itemDataInfo.imageInfo.normalAlpha = (int)imageObj.get("normalAlpha").asNumber(); }
			if (imageObj.has("focusAlpha"))	{ itemDataInfo.imageInfo.focusAlpha = (int)imageObj.get("focusAlpha").asNumber(); }
			if (imageObj.has("dimAlpha")) { itemDataInfo.imageInfo.dimAlpha = (int)imageObj.get("dimAlpha").asNumber(); }
		}
		if (options.has("image2"))
		{
			ScriptObject imageObj = options.get("image2");
			if (imageObj.has("x")) { itemDataInfo.image2Info.imageAlloc.x = imageObj.get("x").asNumber(); }
			if (imageObj.has("y")) { itemDataInfo.image2Info.imageAlloc.y = imageObj.get("y").asNumber(); }
			if (imageObj.has("width")) { itemDataInfo.image2Info.imageAlloc.w = imageObj.get("width").asNumber(); }
			if (imageObj.has("height")) { itemDataInfo.image2Info.imageAlloc.h = imageObj.get("height").asNumber(); }
			if (imageObj.has("normalImagePath")) { itemDataInfo.image2Info.normalImagePath = imageObj.get("normalImagePath").asString(); }
			if (imageObj.has("focusedImagePath")) { itemDataInfo.image2Info.focusedImagePath = imageObj.get("focusedImagePath").asString(); }
			if (imageObj.has("dimImagePath")) { itemDataInfo.image2Info.dimImagePath = imageObj.get("dimImagePath").asString(); }
			if (imageObj.has("normalAlpha"))	{ itemDataInfo.image2Info.normalAlpha = (int)imageObj.get("normalAlpha").asNumber(); }
			if (imageObj.has("focusAlpha"))	{ itemDataInfo.image2Info.focusAlpha = (int)imageObj.get("focusAlpha").asNumber(); }
			if (imageObj.has("dimAlpha")) { itemDataInfo.image2Info.dimAlpha = (int)imageObj.get("dimAlpha").asNumber(); }
		}
		if (options.has("text"))
		{
			ScriptObject textObj = options.get("text");
			if (textObj.has("x")) { itemDataInfo.textInfo.textAlloc.x = textObj.get("x").asNumber(); }
			if (textObj.has("y")) { itemDataInfo.textInfo.textAlloc.y = textObj.get("y").asNumber(); }
			if (textObj.has("width")) { itemDataInfo.textInfo.textAlloc.w = textObj.get("width").asNumber(); }
			if (textObj.has("height")) { itemDataInfo.textInfo.textAlloc.h = textObj.get("height").asNumber(); }
			if (textObj.has("itemTextString")) { itemDataInfo.textInfo.itemTextString = textObj.get("itemTextString").asString(); }
			if (textObj.has("itemTextNormalFont")) { itemDataInfo.textInfo.itemTextFont[0] = textObj.get("itemTextNormalFont").asString(); }
			if (textObj.has("itemTextFocusedFont")) { itemDataInfo.textInfo.itemTextFont[1] = textObj.get("itemTextFocusedFont").asString(); }
			if (textObj.has("itemTextDimFont")) { itemDataInfo.textInfo.itemTextFont[2] = textObj.get("itemTextDimFont").asString(); }
			if (textObj.has("hAlign")) { itemDataInfo.textInfo.hAlign = (EHAlignment)deserializeAlignment(textObj.get("hAlign").asString()); }
			if (textObj.has("vAlign")) { itemDataInfo.textInfo.vAlign = (EVAlignment)deserializeAlignment(textObj.get("vAlign").asString()); }

			if (textObj.has("itemTextNormalColor"))
			{
				ScriptObject itemTextNormalColor = textObj.get("itemTextNormalColor");
				if (itemTextNormalColor.has("r")) { r = (guint8)itemTextNormalColor.get("r").asNumber(); }
				if (itemTextNormalColor.has("g")) { g = (guint8)itemTextNormalColor.get("g").asNumber(); }
				if (itemTextNormalColor.has("b")) { b = (guint8)itemTextNormalColor.get("b").asNumber(); }
				if (itemTextNormalColor.has("a")) { a = (guint8)itemTextNormalColor.get("a").asNumber(); }
			}
			ClutterColor textNormalColor = {r, g, b, a};
			itemDataInfo.textInfo.itemTextColor[0] = textNormalColor;
			if (textObj.has("itemTextFocusedColor"))
			{
				ScriptObject itemTextFocusedColor = textObj.get("itemTextFocusedColor");
				if (itemTextFocusedColor.has("r")) { r = (guint8)itemTextFocusedColor.get("r").asNumber(); }
				if (itemTextFocusedColor.has("g")) { g = (guint8)itemTextFocusedColor.get("g").asNumber(); }
				if (itemTextFocusedColor.has("b")) { b = (guint8)itemTextFocusedColor.get("b").asNumber(); }
				if (itemTextFocusedColor.has("a")) { a = (guint8)itemTextFocusedColor.get("a").asNumber(); }	
			}
			ClutterColor textFocusedColor = {r, g, b, a};
			itemDataInfo.textInfo.itemTextColor[1] = textFocusedColor;
			if (textObj.has("itemTextDimColor"))
			{
				ScriptObject itemTextDimColor = textObj.get("itemTextDimColor");
				if (itemTextDimColor.has("r")) { r = (guint8)itemTextDimColor.get("r").asNumber(); }
				if (itemTextDimColor.has("g")) { g = (guint8)itemTextDimColor.get("g").asNumber(); }
				if (itemTextDimColor.has("b")) { b = (guint8)itemTextDimColor.get("b").asNumber(); }
				if (itemTextDimColor.has("a")) { a = (guint8)itemTextDimColor.get("a").asNumber(); }
			}
			ClutterColor textDimColor = {r, g, b, a};
			itemDataInfo.textInfo.itemTextColor[2] = textDimColor;
		}

		if (options.has("text2"))
		{
			ScriptObject textObj = options.get("text2");
			if (textObj.has("x")) { itemDataInfo.text2Info.textAlloc.x = textObj.get("x").asNumber(); }
			if (textObj.has("y")) { itemDataInfo.text2Info.textAlloc.y = textObj.get("y").asNumber(); }
			if (textObj.has("width")) { itemDataInfo.text2Info.textAlloc.w = textObj.get("width").asNumber(); }
			if (textObj.has("height")) { itemDataInfo.text2Info.textAlloc.h = textObj.get("height").asNumber(); }
			if (textObj.has("itemTextString")) { itemDataInfo.text2Info.itemTextString = textObj.get("itemTextString").asString(); }
			if (textObj.has("itemTextNormalFont")) { itemDataInfo.text2Info.itemTextFont[0] = textObj.get("itemTextNormalFont").asString(); }
			if (textObj.has("itemTextFocusedFont")) { itemDataInfo.text2Info.itemTextFont[1] = textObj.get("itemTextFocusedFont").asString(); }
			if (textObj.has("itemTextDimFont")) { itemDataInfo.text2Info.itemTextFont[2] = textObj.get("itemTextDimFont").asString(); }
			if (textObj.has("hAlign")) { itemDataInfo.text2Info.hAlign = (EHAlignment)deserializeAlignment(textObj.get("hAlign").asString()); }
			if (textObj.has("vAlign")) { itemDataInfo.text2Info.vAlign = (EVAlignment)deserializeAlignment(textObj.get("vAlign").asString()); }

			if (textObj.has("itemTextNormalColor"))
			{
				ScriptObject itemTextNormalColor = textObj.get("itemTextNormalColor");
				if (itemTextNormalColor.has("r")) { r = (guint8)itemTextNormalColor.get("r").asNumber(); }
				if (itemTextNormalColor.has("g")) { g = (guint8)itemTextNormalColor.get("g").asNumber(); }
				if (itemTextNormalColor.has("b")) { b = (guint8)itemTextNormalColor.get("b").asNumber(); }
				if (itemTextNormalColor.has("a")) { a = (guint8)itemTextNormalColor.get("a").asNumber(); }
			}
			ClutterColor textNormalColor = {r, g, b, a};
			itemDataInfo.text2Info.itemTextColor[0] = textNormalColor;
			if (textObj.has("itemTextFocusedColor"))
			{
				ScriptObject itemTextFocusedColor = textObj.get("itemTextFocusedColor");
				if (itemTextFocusedColor.has("r")) { r = (guint8)itemTextFocusedColor.get("r").asNumber(); }
				if (itemTextFocusedColor.has("g")) { g = (guint8)itemTextFocusedColor.get("g").asNumber(); }
				if (itemTextFocusedColor.has("b")) { b = (guint8)itemTextFocusedColor.get("b").asNumber(); }
				if (itemTextFocusedColor.has("a")) { a = (guint8)itemTextFocusedColor.get("a").asNumber(); }	
			}
			ClutterColor textFocusedColor = {r, g, b, a};
			itemDataInfo.text2Info.itemTextColor[1] = textFocusedColor;
			if (textObj.has("itemTextDimColor"))
			{
				ScriptObject itemTextDimColor = textObj.get("itemTextDimColor");
				if (itemTextDimColor.has("r")) { r = (guint8)itemTextDimColor.get("r").asNumber(); }
				if (itemTextDimColor.has("g")) { g = (guint8)itemTextDimColor.get("g").asNumber(); }
				if (itemTextDimColor.has("b")) { b = (guint8)itemTextDimColor.get("b").asNumber(); }
				if (itemTextDimColor.has("a")) { a = (guint8)itemTextDimColor.get("a").asNumber(); }
			}
			ClutterColor textDimColor = {r, g, b, a};
			itemDataInfo.text2Info.itemTextColor[2] = textDimColor;
		}

		if (options.has("textScrollAttr"))
		{
			ScriptObject textScrollAttr = options.get("textScrollAttr");
			if (textScrollAttr.has("duration")) { itemDataInfo.itemTextScrollInfo.duration = (guint)textScrollAttr.get("duration").asNumber(); }
			if (textScrollAttr.has("speed")) { itemDataInfo.itemTextScrollInfo.speed = (gfloat)textScrollAttr.get("speed").asNumber(); }
			if (textScrollAttr.has("delay")) { itemDataInfo.itemTextScrollInfo.delay = (guint)textScrollAttr.get("delay").asNumber(); }
			if (textScrollAttr.has("repeat")) { itemDataInfo.itemTextScrollInfo.repeat = (int)textScrollAttr.get("repeat").asNumber(); }
			if (textScrollAttr.has("type")) { itemDataInfo.itemTextScrollInfo.type = (ClutterTextScrollType)deserializeScrollType(textScrollAttr.get("type").asString()); }
			if (textScrollAttr.has("direction")) { itemDataInfo.itemTextScrollInfo.direction = (ClutterTimelineDirection)deserializeScrollDirection(textScrollAttr.get("direction").asString()); }
			if (textScrollAttr.has("continueGap")) { itemDataInfo.itemTextScrollInfo.continueGap = (guint)textScrollAttr.get("continueGap").asNumber(); }
		}

		if (options.has("itemBGNormalColor"))
		{
			ScriptObject itemBGNormalColor = options.get("itemBGNormalColor");
			if (itemBGNormalColor.has("r")) { r = (guint8)itemBGNormalColor.get("r").asNumber(); }
			if (itemBGNormalColor.has("g")) { g = (guint8)itemBGNormalColor.get("g").asNumber(); }
			if (itemBGNormalColor.has("b")) { b = (guint8)itemBGNormalColor.get("b").asNumber(); }
			if (itemBGNormalColor.has("a")) { a = (guint8)itemBGNormalColor.get("a").asNumber(); }	
		}
		ClutterColor normalColor = {r, g, b, a};
		itemDataInfo.itemBGNormalColor = normalColor;
		if (options.has("itemBGFocusedColor"))
		{
			ScriptObject itemBGFocusedColor = options.get("itemBGFocusedColor");
			if (itemBGFocusedColor.has("r")) { r = (guint8)itemBGFocusedColor.get("r").asNumber(); }
			if (itemBGFocusedColor.has("g")) { g = (guint8)itemBGFocusedColor.get("g").asNumber(); }
			if (itemBGFocusedColor.has("b")) { b = (guint8)itemBGFocusedColor.get("b").asNumber(); }
			if (itemBGFocusedColor.has("a")) { a = (guint8)itemBGFocusedColor.get("a").asNumber(); }
			
		}
		ClutterColor focusedColor = {r, g, b, a};
		itemDataInfo.itemBGFocusedColor = focusedColor;
		if (options.has("itemBGDimColor"))
		{
			ScriptObject itemBGDimColor = options.get("itemBGDimColor");
			if (itemBGDimColor.has("r")) { r = (guint8)itemBGDimColor.get("r").asNumber(); }
			if (itemBGDimColor.has("g")) { g = (guint8)itemBGDimColor.get("g").asNumber(); }
			if (itemBGDimColor.has("b")) { b = (guint8)itemBGDimColor.get("b").asNumber(); }
			if (itemBGDimColor.has("a")) { a = (guint8)itemBGDimColor.get("a").asNumber(); }
		}
		ClutterColor dimColor = {r, g, b, a};
		itemDataInfo.itemBGDimColor = dimColor;
		self->AddItemData(index, itemDataInfo);
	}
	
	return ScriptObject();
}

ScriptObject SubListBridge::updateItem(CSubList* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);

	ScriptObject options;
	int argsLen = args.Length();
	if (argsLen > 0)
	{
		options = args[0];
		int index = 0;
		if (options.has("index") && options.get("index").isNumber())
		{
			index = options.get("index").asNumber();
		}
		else
		{
			return ScriptObject();
		}
		guint8 r = 0, g = 0, b = 0, a = 0;
		CSublistItem* sublistItem = dynamic_cast<CSublistItem*>(self->GetDataSource()->GetData(index));
		if (options.has("image"))
		{
			ScriptObject imageObj = options.get("image");
			if (imageObj.has("x")) { sublistItem->imageInfo[0].imageAlloc.x = imageObj.get("x").asNumber(); }
			if (imageObj.has("y")) { sublistItem->imageInfo[0].imageAlloc.y = imageObj.get("y").asNumber(); }
			if (imageObj.has("width")) { sublistItem->imageInfo[0].imageAlloc.w = imageObj.get("width").asNumber(); }
			if (imageObj.has("height")) { sublistItem->imageInfo[0].imageAlloc.h = imageObj.get("height").asNumber(); }
			if (imageObj.has("normalImagePath")) { sublistItem->imageInfo[0].normalImagePath = imageObj.get("normalImagePath").asString(); }
			if (imageObj.has("focusedImagePath")) { sublistItem->imageInfo[0].focusedImagePath = imageObj.get("focusedImagePath").asString(); }
			if (imageObj.has("dimImagePath")) { sublistItem->imageInfo[0].dimImagePath = imageObj.get("dimImagePath").asString(); }
			if (imageObj.has("normalAlpha"))	{ sublistItem->imageInfo[0].normalAlpha = (int)imageObj.get("normalAlpha").asNumber(); }
			if (imageObj.has("focusAlpha"))	{ sublistItem->imageInfo[0].focusAlpha = (int)imageObj.get("focusAlpha").asNumber(); }
			if (imageObj.has("dimAlpha")) { sublistItem->imageInfo[0].dimAlpha = (int)imageObj.get("dimAlpha").asNumber(); }
		}
		if (options.has("image2"))
		{
			ScriptObject imageObj = options.get("image2");
			if (imageObj.has("x")) { sublistItem->imageInfo[1].imageAlloc.x = imageObj.get("x").asNumber(); }
			if (imageObj.has("y")) { sublistItem->imageInfo[1].imageAlloc.y = imageObj.get("y").asNumber(); }
			if (imageObj.has("width")) { sublistItem->imageInfo[1].imageAlloc.w = imageObj.get("width").asNumber(); }
			if (imageObj.has("height")) { sublistItem->imageInfo[1].imageAlloc.h = imageObj.get("height").asNumber(); }
			if (imageObj.has("normalImagePath")) { sublistItem->imageInfo[1].normalImagePath = imageObj.get("normalImagePath").asString(); }
			if (imageObj.has("focusedImagePath")) { sublistItem->imageInfo[1].focusedImagePath = imageObj.get("focusedImagePath").asString(); }
			if (imageObj.has("dimImagePath")) { sublistItem->imageInfo[1].dimImagePath = imageObj.get("dimImagePath").asString(); }
			if (imageObj.has("normalAlpha"))	{ sublistItem->imageInfo[1].normalAlpha = (int)imageObj.get("normalAlpha").asNumber(); }
			if (imageObj.has("focusAlpha"))	{ sublistItem->imageInfo[1].focusAlpha = (int)imageObj.get("focusAlpha").asNumber(); }
			if (imageObj.has("dimAlpha")) { sublistItem->imageInfo[1].dimAlpha = (int)imageObj.get("dimAlpha").asNumber(); }
		}
		if (options.has("text"))
		{
			ScriptObject textObj = options.get("text");
			if (textObj.has("x")) { sublistItem->itemTextInfo[0].textAlloc.x = textObj.get("x").asNumber(); }
			if (textObj.has("y")) { sublistItem->itemTextInfo[0].textAlloc.y = textObj.get("y").asNumber(); }
			if (textObj.has("width")) { sublistItem->itemTextInfo[0].textAlloc.w = textObj.get("width").asNumber(); }
			if (textObj.has("height")) { sublistItem->itemTextInfo[0].textAlloc.h = textObj.get("height").asNumber(); }
			if (textObj.has("itemTextString")) { sublistItem->itemTextInfo[0].itemTextString = textObj.get("itemTextString").asString(); }
			if (textObj.has("itemTextNormalFont")) { sublistItem->itemTextInfo[0].itemTextFont[0] = textObj.get("itemTextNormalFont").asString(); }
			if (textObj.has("itemTextFocusedFont")) { sublistItem->itemTextInfo[0].itemTextFont[1] = textObj.get("itemTextFocusedFont").asString(); }
			if (textObj.has("itemTextDimFont")) { sublistItem->itemTextInfo[0].itemTextFont[2] = textObj.get("itemTextDimFont").asString(); }
			if (textObj.has("hAlign")) { sublistItem->itemTextInfo[0].hAlign = (EHAlignment)deserializeAlignment(textObj.get("hAlign").asString()); }
			if (textObj.has("vAlign")) { sublistItem->itemTextInfo[0].vAlign = (EVAlignment)deserializeAlignment(textObj.get("vAlign").asString()); }

			if (textObj.has("itemTextNormalColor"))
			{
				ScriptObject itemTextNormalColor = textObj.get("itemTextNormalColor");
				if (itemTextNormalColor.has("r")) { r = (guint8)itemTextNormalColor.get("r").asNumber(); }
				if (itemTextNormalColor.has("g")) { g = (guint8)itemTextNormalColor.get("g").asNumber(); }
				if (itemTextNormalColor.has("b")) { b = (guint8)itemTextNormalColor.get("b").asNumber(); }
				if (itemTextNormalColor.has("a")) { a = (guint8)itemTextNormalColor.get("a").asNumber(); }
				ClutterColor textNormalColor = {r, g, b, a};
				sublistItem->itemTextInfo[0].itemTextColor[0] = textNormalColor;
			}
			if (textObj.has("itemTextFocusedColor"))
			{
				ScriptObject itemTextFocusedColor = textObj.get("itemTextFocusedColor");
				if (itemTextFocusedColor.has("r")) { r = (guint8)itemTextFocusedColor.get("r").asNumber(); }
				if (itemTextFocusedColor.has("g")) { g = (guint8)itemTextFocusedColor.get("g").asNumber(); }
				if (itemTextFocusedColor.has("b")) { b = (guint8)itemTextFocusedColor.get("b").asNumber(); }
				if (itemTextFocusedColor.has("a")) { a = (guint8)itemTextFocusedColor.get("a").asNumber(); }
				ClutterColor textFocusedColor = {r, g, b, a};
				sublistItem->itemTextInfo[0].itemTextColor[1] = textFocusedColor;
			}
			if (textObj.has("itemTextDimColor"))
			{
				ScriptObject itemTextDimColor = textObj.get("itemTextDimColor");
				if (itemTextDimColor.has("r")) { r = (guint8)itemTextDimColor.get("r").asNumber(); }
				if (itemTextDimColor.has("g")) { g = (guint8)itemTextDimColor.get("g").asNumber(); }
				if (itemTextDimColor.has("b")) { b = (guint8)itemTextDimColor.get("b").asNumber(); }
				if (itemTextDimColor.has("a")) { a = (guint8)itemTextDimColor.get("a").asNumber(); }
				ClutterColor textDimColor = {r, g, b, a};
				sublistItem->itemTextInfo[0].itemTextColor[2] = textDimColor;
			}
		}
		
		if (options.has("text2"))
		{
			ScriptObject textObj = options.get("text2");
			if (textObj.has("x")) { sublistItem->itemTextInfo[1].textAlloc.x = textObj.get("x").asNumber(); }
			if (textObj.has("y")) { sublistItem->itemTextInfo[1].textAlloc.y = textObj.get("y").asNumber(); }
			if (textObj.has("width")) { sublistItem->itemTextInfo[1].textAlloc.w = textObj.get("width").asNumber(); }
			if (textObj.has("height")) { sublistItem->itemTextInfo[1].textAlloc.h = textObj.get("height").asNumber(); }
			if (textObj.has("itemTextString")) { sublistItem->itemTextInfo[1].itemTextString = textObj.get("itemTextString").asString(); }
			if (textObj.has("itemTextNormalFont")) { sublistItem->itemTextInfo[1].itemTextFont[0] = textObj.get("itemTextNormalFont").asString(); }
			if (textObj.has("itemTextFocusedFont")) { sublistItem->itemTextInfo[1].itemTextFont[1] = textObj.get("itemTextFocusedFont").asString(); }
			if (textObj.has("itemTextDimFont")) { sublistItem->itemTextInfo[1].itemTextFont[2] = textObj.get("itemTextDimFont").asString(); }
			if (textObj.has("hAlign")) { sublistItem->itemTextInfo[1].hAlign = (EHAlignment)deserializeAlignment(textObj.get("hAlign").asString()); }
			if (textObj.has("vAlign")) { sublistItem->itemTextInfo[1].vAlign = (EVAlignment)deserializeAlignment(textObj.get("vAlign").asString()); }

			if (textObj.has("itemTextNormalColor"))
			{
				ScriptObject itemTextNormalColor = textObj.get("itemTextNormalColor");
				if (itemTextNormalColor.has("r")) { r = (guint8)itemTextNormalColor.get("r").asNumber(); }
				if (itemTextNormalColor.has("g")) { g = (guint8)itemTextNormalColor.get("g").asNumber(); }
				if (itemTextNormalColor.has("b")) { b = (guint8)itemTextNormalColor.get("b").asNumber(); }
				if (itemTextNormalColor.has("a")) { a = (guint8)itemTextNormalColor.get("a").asNumber(); }
				ClutterColor textNormalColor = {r, g, b, a};
				sublistItem->itemTextInfo[1].itemTextColor[0] = textNormalColor;
			}
			if (textObj.has("itemTextFocusedColor"))
			{
				ScriptObject itemTextFocusedColor = textObj.get("itemTextFocusedColor");
				if (itemTextFocusedColor.has("r")) { r = (guint8)itemTextFocusedColor.get("r").asNumber(); }
				if (itemTextFocusedColor.has("g")) { g = (guint8)itemTextFocusedColor.get("g").asNumber(); }
				if (itemTextFocusedColor.has("b")) { b = (guint8)itemTextFocusedColor.get("b").asNumber(); }
				if (itemTextFocusedColor.has("a")) { a = (guint8)itemTextFocusedColor.get("a").asNumber(); }
				ClutterColor textFocusedColor = {r, g, b, a};
				sublistItem->itemTextInfo[1].itemTextColor[1] = textFocusedColor;
			}
			if (textObj.has("itemTextDimColor"))
			{
				ScriptObject itemTextDimColor = textObj.get("itemTextDimColor");
				if (itemTextDimColor.has("r")) { r = (guint8)itemTextDimColor.get("r").asNumber(); }
				if (itemTextDimColor.has("g")) { g = (guint8)itemTextDimColor.get("g").asNumber(); }
				if (itemTextDimColor.has("b")) { b = (guint8)itemTextDimColor.get("b").asNumber(); }
				if (itemTextDimColor.has("a")) { a = (guint8)itemTextDimColor.get("a").asNumber(); }
				ClutterColor textDimColor = {r, g, b, a};
				sublistItem->itemTextInfo[1].itemTextColor[2] = textDimColor;
			}
		}

		if (options.has("itemBGNormalColor"))
		{
			ClutterColor BGNormalColor = {r, g, b, a};
			ScriptObject itemBGNormalColor = options.get("itemBGNormalColor");
			if (itemBGNormalColor.has("r")) { r = (guint8)itemBGNormalColor.get("r").asNumber(); }
			if (itemBGNormalColor.has("g")) { g = (guint8)itemBGNormalColor.get("g").asNumber(); }
			if (itemBGNormalColor.has("b")) { b = (guint8)itemBGNormalColor.get("b").asNumber(); }
			if (itemBGNormalColor.has("a")) { a = (guint8)itemBGNormalColor.get("a").asNumber(); }
			sublistItem->ItemBGNormalColor = BGNormalColor;
		}
		if (options.has("itemBGFocusedColor"))
		{
			ClutterColor BGFocusedColor = {r, g, b, a};
			ScriptObject itemBGFocusedColor = options.get("itemBGFocusedColor");
			if (itemBGFocusedColor.has("r")) { r = (guint8)itemBGFocusedColor.get("r").asNumber(); }
			if (itemBGFocusedColor.has("g")) { g = (guint8)itemBGFocusedColor.get("g").asNumber(); }
			if (itemBGFocusedColor.has("b")) { b = (guint8)itemBGFocusedColor.get("b").asNumber(); }
			if (itemBGFocusedColor.has("a")) { a = (guint8)itemBGFocusedColor.get("a").asNumber(); }
			sublistItem->ItemBGFocusedColor = BGFocusedColor;
		}
		if (options.has("itemBGDimColor"))
		{
			ClutterColor BGDimColor = {r, g, b, a};
			ScriptObject itemBGDimColor = options.get("itemBGDimColor");
			if (itemBGDimColor.has("r")) { r = (guint8)itemBGDimColor.get("r").asNumber(); }
			if (itemBGDimColor.has("g")) { g = (guint8)itemBGDimColor.get("g").asNumber(); }
			if (itemBGDimColor.has("b")) { b = (guint8)itemBGDimColor.get("b").asNumber(); }
			if (itemBGDimColor.has("a")) { a = (guint8)itemBGDimColor.get("a").asNumber(); }
			sublistItem->ItemBGDimColor = BGDimColor;
		}

		self->UpdateItem(index);
	}

	return ScriptObject();
}

ScriptObject SubListBridge::deleteItem(CSubList* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);
	HALO_ASSERT(1 == args.Length());

	ScriptObject argObject = args[0];

	ARG_IS_VALID(argObject, "fromItem", isNumber);
	ARG_IS_VALID(argObject, "itemNum", isNumber);

	int fromItem = (int)argObject.get("fromItem").asNumber();
	int itemNumber = (int)argObject.get("itemNum").asNumber();

	self->DeleteItem(fromItem, itemNumber);

	return ScriptObject();
}

ScriptObject SubListBridge::updateAllItems(CSubList* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);
	HALO_ASSERT(0 == args.Length());

	self->UpdateAllItems();
	return ScriptObject();
}

Bridge::ScriptObject SubListBridge::setDataSource(CSubList* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	self->SetDataSource();
	return ScriptObject();
}

Bridge::ScriptObject SubListBridge::setSingleLineListPosition(CSubList* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	ScriptObject options;
	int argsLen = args.Length();
	float x = 0.0, y = 0.0;
	if (argsLen > 0)
	{
		options = args[0];
		if(options.has("x"))
		{ 
			x = (float)options.get("x").asNumber();
		}
		if(options.has("y"))
		{ 
			y = (float)options.get("y").asNumber();
		}
	}
	self->SetSingleLineListPosition(x, y);
	return ScriptObject();
}

Bridge::ScriptObject SubListBridge::setArrowImageAttr(CSubList* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	ScriptObject options;
	int argsLen = args.Length();
	float x = 0.0, y = 0.0;
	if (argsLen > 0)
	{
		options = args[0];
		CSubList::TArrowAttr arrowAttr;
		CSubList::EArrowDirections arrowDirection;
		if(options.has("ArrowDirection"))
		{
			if ("upArrow" == options.get("ArrowDirection").asString())
			{
				arrowDirection = CSubList::UP_ARROW;
			}
			else if ("downArrow" == options.get("ArrowDirection").asString())
			{
				arrowDirection = CSubList::DOWN_ARROW;
			}
			else if("leftArrow" == options.get("ArrowDirection").asString())
			{
				arrowDirection = CSubList::LEFT_ARROW;
			}
			else if("rightArrow" == options.get("ArrowDirection").asString())
			{
				arrowDirection = CSubList::RIGHT_ARROW;
			}
			else
			{
				return ScriptObject();
			}
		}

		if(options.has("x")) { arrowAttr.x = (float)options.get("x").asNumber(); }
		if(options.has("y")) { arrowAttr.y = (float)options.get("y").asNumber(); }
		if (options.has("width")) {	arrowAttr.w = (float)(options.get("width").asNumber());	}
		if (options.has("height")) { arrowAttr.h = (float)(options.get("height").asNumber()); }
		if (options.has("arrowNormalImagePath")) { arrowAttr.arrowNormalImagePath = options.get("arrowNormalImagePath").asString(); }
		if (options.has("arrowFocusedImagePath")) { arrowAttr.arrowFocusedImagePath = options.get("arrowFocusedImagePath").asString(); }
		if (options.has("arrowDimImagePath")) { arrowAttr.arrowDimImagePath = options.get("arrowDimImagePath").asString(); }
		if (options.has("normalAlpha"))	{ arrowAttr.normalAlpha = (int)options.get("normalAlpha").asNumber(); }
		if (options.has("focusAlpha")) { arrowAttr.focusAlpha = (int)options.get("focusAlpha").asNumber(); }
		if (options.has("dimAlpha")) { arrowAttr.dimAlpha = (int)options.get("dimAlpha").asNumber(); }

		self->SetArrowImageAttr(arrowDirection, arrowAttr);
	}
	
	return ScriptObject();
}

Bridge::ScriptObject SubListBridge::setButtonAttr(CSubList* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	ScriptObject options;
	int argsLen = args.Length();
	float x = 0.0, y = 0.0;
	if (argsLen > 0)
	{
		options = args[0];
		TRect rect;
		std::string buttonNormalImagePath = "", buttonFocusedImagePath = "", buttonDimImagePath = "";
		if(options.has("x")) { rect.x = (float)options.get("x").asNumber();	}
		if(options.has("y")) { rect.y = (float)options.get("y").asNumber();	}
		if (options.has("width")) {	rect.w = (float)(options.get("width").asNumber()); }
		if (options.has("height")) { rect.h = (float)(options.get("height").asNumber()); }
		if (options.has("buttonNormalImagePath")) {	buttonNormalImagePath = options.get("buttonNormalImagePath").asString(); }
		if (options.has("buttonFocusedImagePath")) { buttonFocusedImagePath = options.get("buttonFocusedImagePath").asString(); }
		if (options.has("buttonDimImagePath")) { buttonDimImagePath = options.get("buttonDimImagePath").asString(); }

		self->SetButtonAttr(rect, buttonNormalImagePath, buttonFocusedImagePath, buttonDimImagePath);
	}
	
	return ScriptObject();
}

Bridge::ScriptObject SubListBridge::numofItem(CSubList* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);
	HALO_ASSERT(0 == args.Length());

	int numOfItem = self->NumofItem();
	return ScriptObject(numOfItem);
}

Bridge::ScriptObject SubListBridge::setDim(CSubList* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	ScriptObject options;
	int argsLen = args.Length();
	if (argsLen > 0)
	{
		options = args[0];
		int index = 0;
		bool ifDim = false;
		if (options.has("index") && options.get("index").isNumber())
		{
			index = (int)options.get("index").asNumber();
		}
		else
		{
			return ScriptObject();
		}
		if (options.has("ifDim") && options.get("ifDim").isBool()){ifDim = options.get("ifDim").asBool();}
		self->SetDimItem(index, ifDim);
	}

	return ScriptObject();
}

Bridge::ScriptObject SubListBridge::ifDim(CSubList* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	ScriptObject options;
	int argsLen = args.Length();
	int index = -1;
	if (argsLen > 0)
	{
		options = args[0];
		if (options.has("index") && options.get("index").isNumber())
		{
			index = (int)options.get("index").asNumber();
			return ScriptObject(self->IfDim(index));
		}
		else
		{
			return ScriptObject(index);
		}
	}

	return ScriptObject(index);
}

Bridge::ScriptObject SubListBridge::showFocus(CSubList* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);
	ASSERT(1 == args.Length() && true == args[0].isString());

	bool ret;

	if ("true" == args[0].asString())
	{
		ret = self->ShowFocus(true);
	}
	else
	{
		ret = self->ShowFocus(false);
	}
	
	return ScriptObject(ret);
}

Bridge::ScriptObject SubListBridge::hideFocus(CSubList* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);
	ASSERT(1 == args.Length() && true == args[0].isString());

	bool ret;

	if ("true" == args[0].asString())
	{
		ret = self->HideFocus(true);
	}
	else
	{
		ret = self->HideFocus(false);
	}

	return ScriptObject(ret);
}

Bridge::ScriptObject SubListBridge::setFocus(CSubList* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);

	 self->SetFocus();
	 return ScriptObject();
}

Bridge::ScriptObject SubListBridge::killFocus(CSubList* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);

	self->KillFocus();
	return ScriptObject();
}

Bridge::ScriptObject SubListBridge::text(CSubList* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);

	ScriptObject options;
	int argsLen = args.Length();
	int index = -1;
	if (argsLen > 0)
	{
		options = args[0];
		if (options.has("index") && options.get("index").isNumber())
		{
			index = (int)options.get("index").asNumber();
			return ScriptObject(self->Text(index));
		}
		else
		{
			return ScriptObject("");
		}
	}
	return ScriptObject("");
}

Bridge::ScriptObject SubListBridge::text2(CSubList* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);

	ScriptObject options;
	int argsLen = args.Length();
	int index = -1;
	if (argsLen > 0)
	{
		options = args[0];
		if (options.has("index") && options.get("index").isNumber())
		{
			index = (int)options.get("index").asNumber();
			return ScriptObject(self->Text2(index));
		}
		else
		{
			return ScriptObject("");
		}
	}
	return ScriptObject("");
}

Bridge::ScriptObject SubListBridge::setAnimationDuration(CSubList* self, const ScriptArray& args)
{
	ASSERT(NULL != self);
	ASSERT(2 == args.Length());
	ASSERT(true == args[0].isString() && true == args[1].isNumber());

	std::string type = args[0].asString();
	int duration = (int)args[1].asNumber();

	if ("focusMove" == type)
	{
		self->SetAnimationDuration(ISingleLineListControl::ANITYPE_FOCUS_MOVE, duration);
	}
	else if ("loop" == type)
	{
		self->SetAnimationDuration(ISingleLineListControl::ANITYPE_LOOP, duration);
	}

	return ScriptObject();
}

Bridge::ScriptObject SubListBridge::addListener(CSubList* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	if (args.Length() > 0)
	{
		ISubListListener* listener = unwrapNativeObject<ISubListListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddListener(listener);
		}
	}

	return ScriptObject();
}

Bridge::ScriptObject SubListBridge::removeListener(CSubList* self, const ScriptArray &args)
{
	HALO_ASSERT(NULL != self);

	if (args.Length() > 0)
	{
		ISubListListener* listener = unwrapNativeObject<ISubListListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveListener(listener);
		}
	}

	return ScriptObject();
}

void SubListBridge::parseSubListParams(const ScriptObject& options, CSubList::TSubListAttr& attr)
{
	if (options.has("x"))
	{
		attr.x = static_cast<float>(options.get("x").asNumber());
	}
	if (options.has("y"))
	{
		attr.y = static_cast<float>(options.get("y").asNumber());
	}
	if (options.has("width"))
	{
		attr.w = static_cast<float>(options.get("width").asNumber());
	}
	if (options.has("height"))
	{
		attr.h = static_cast<float>(options.get("height").asNumber());
	}
	if (options.has("nTotalItemNumber"))
	{
		attr.nTotalItemNumber = static_cast<int>(options.get("nTotalItemNumber").asNumber());
	}
	if (options.has("nItemNumberOnWindow"))
	{
		attr.nItemNumberOnWindow = static_cast<int>(options.get("nItemNumberOnWindow").asNumber());
	}

	if (options.has("singleLineListWidth"))
	{
		attr.singleLineListWidth = static_cast<float>(options.get("singleLineListWidth").asNumber());
	}
	if (options.has("singleLineListHeight"))
	{
		attr.singleLineListHeight = static_cast<float>(options.get("singleLineListHeight").asNumber());
	}
	if (options.has("singleLineListDirectionType"))
	{
		EDirectionType type;
		if ("Vertical" == options.get("singleLineListDirectionType").asString())
		{
			type = TYPE_VERTICAL;
		}
		else if ("Horizontal" == options.get("singleLineListDirectionType").asString())
		{
			type = TYPE_HORIZONTAL;
		}
		attr.singleLineListType = type;
	}
}

int SubListBridge::deserializeAlignment(std::string alignMent)
{
	if (compareStrChar(alignMent, "horizontal_align_left"))
	{
		return HALIGN_LEFT;
	}
	else if (compareStrChar(alignMent, "horizontal_align_center"))
	{
		return HALIGN_CENTER;
	}
	else if (compareStrChar(alignMent, "horizontal_align_right"))
	{
		return HALIGN_RIGHT;
	}
	else if (compareStrChar(alignMent, "vertical_align_top"))
	{
		return VALIGN_TOP;
	}
	else if (compareStrChar(alignMent, "vertical_align_middle"))
	{
		return VALIGN_MIDDLE;
	}
	else if (compareStrChar(alignMent, "vertical_align_bottom"))
	{
		return VALIGN_BOTTOM;
	}
	else
	{
		return 0;
	}
}

int SubListBridge::deserializeScrollType(std::string type)
{
	if (compareStrChar(type, "start_outside_stop_outside"))
	{
		return CLUTTER_TEXT_SCROLL_START_OUTSIDE_STOP_OUTSIDE;
	}
	else if (compareStrChar(type, "start_outside_stop_inside"))
	{
		return CLUTTER_TEXT_SCROLL_START_OUTSIDE_STOP_INSIDE;
	}
	else if (compareStrChar(type, "start_inside_stop_outside"))
	{
		return CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_OUTSIDE;
	}
	else if (compareStrChar(type, "start_inside_stop_inside"))
	{
		return CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_INSIDE;
	}
	else if (compareStrChar(type, "continue_scroll"))
	{
		return CLUTTER_TEXT_SCROLL_CONTINUOUS_SCROLL;
	}
	else
	{
		return CLUTTER_TEXT_SCROLL_START_OUTSIDE_STOP_OUTSIDE;
	}
}

int SubListBridge::deserializeScrollDirection(std::string direction)
{
	if (compareStrChar(direction, "forward"))
	{
		return CLUTTER_TIMELINE_FORWARD;
	}
	else if (compareStrChar(direction, "backward"))
	{
		return CLUTTER_TIMELINE_BACKWARD;
	}
	else
	{
		return 0;
	}
}