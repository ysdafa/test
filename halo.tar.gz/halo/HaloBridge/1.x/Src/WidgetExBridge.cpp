#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

namespace Bridge
{
	void WidgetExListenerBridge::mapScriptInterface(ScriptContext& context)
	{
		BaseListenerBridge::mapScriptInterface(context);
		context.bindFunction<InternalWidgetExListener, &InternalWidgetExListener::GetHighContrastChangedCallBack, &InternalWidgetExListener::SetHighContrastChangedCallBack>("onHighContrastChanged");
		context.bindFunction<InternalWidgetExListener, &InternalWidgetExListener::GetEnlargeChangedCallBack, &InternalWidgetExListener::SetEnlargeChangedCallBack>("onEnlargeChanged");
	}

	void* WidgetExListenerBridge::constructFromScript(const ScriptArray& args)
	{
		return new InternalWidgetExListener(this);
	}

	bool InternalWidgetExListener::OnHighContrastChanged(class IWidgetExtension *pWindow, bool flagHighContrast)
	{
		if (true == HighContrastChangedCb.flagExist)
		{
			ScriptArray args;
			CWidgetEx* pWidgetEx = NULL;
			CActor* pActor = NULL;
			CImageWidgetEx* pImageWidgetEx = NULL;
			CTextWidgetEx* pTextWidgetEx = NULL;
			if (pActor = dynamic_cast<CActor*>(pWindow))
			{
				args.set(0, t_owner->WrapActorToJS(pActor));
			}
			else if (pTextWidgetEx = dynamic_cast<CTextWidgetEx*>(pWindow))
			{
				args.set(0, t_owner->WrapTextWidgetExToJS(pTextWidgetEx));
			}
			else if (pImageWidgetEx = dynamic_cast<CImageWidgetEx*>(pWindow))
			{
				args.set(0, t_owner->WrapImageWidgetExToJS(pImageWidgetEx));
			}
			else if (pWidgetEx = dynamic_cast<CWidgetEx*>(pWindow))
			{
				args.set(0, t_owner->WrapWidgetExToJS(pWidgetEx));
			}

			args.set(1, ScriptObject(flagHighContrast));
			HighContrastChangedCb.function.invoke(args);
		}
		return true;
	}

	bool InternalWidgetExListener::OnEnlargeChanged(class IWidgetExtension *pWindow, bool flagEnlarge)
	{
		if (true == EnlargeChangedCb.flagExist)
		{
			ScriptArray args;
			CWidgetEx* pWidgetEx = NULL;
			CActor* pActor = NULL;
			CImageWidgetEx* pImageWidgetEx = NULL;
			CTextWidgetEx* pTextWidgetEx = NULL;
			if (pActor = dynamic_cast<CActor*>(pWindow))
			{
				args.set(0, t_owner->WrapActorToJS(pActor));
			}
			else if (pTextWidgetEx = dynamic_cast<CTextWidgetEx*>(pWindow))
			{
				args.set(0, t_owner->WrapTextWidgetExToJS(pTextWidgetEx));
			}
			else if (pImageWidgetEx = dynamic_cast<CImageWidgetEx*>(pWindow))
			{
				args.set(0, t_owner->WrapImageWidgetExToJS(pImageWidgetEx));
			}
			else if (pWidgetEx = dynamic_cast<CWidgetEx*>(pWindow))
			{
				args.set(0, t_owner->WrapWidgetExToJS(pWidgetEx));
			}

			args.set(1, ScriptObject(flagEnlarge));
			EnlargeChangedCb.function.invoke(args);
		}
		return true;
	}

	void WidgetExBridge::mapScriptInterface(ScriptContext& context)
	{
		WidgetBridge::mapScriptInterface(context);

		context.bindNumber<CWidgetEx, float, &CWidgetEx::getX, &CWidgetEx::setX>("x");
		context.bindNumber<CWidgetEx, float, &CWidgetEx::getY, &CWidgetEx::setY>("y");
		context.bindNumber<CWidgetEx, float, &CWidgetEx::getWidth, &CWidgetEx::setWidth>("width");
		context.bindNumber<CWidgetEx, float, &CWidgetEx::getHeight, &CWidgetEx::setHeight>("height");
		context.bindNativeReference<CWidgetEx, Widget, &CWidgetEx::getParent, &CWidgetEx::setParent>("parent");
		context.captureMethodCall<CWidgetEx, &handleDestroy>("destroy");
		//context.bindBoolean<CWidgetExtension, &CWidgetExtension::IsReversible, &CWidgetExtension::EnableReverse>("reversible");
		context.captureMethodCall<CWidgetEx, &isReversible>("isReversible");
		context.captureMethodCall<CWidgetEx, &enableReverse>("enableReverse");
		context.capturePropertyAccess<CWidgetEx, &m_isReversible, &m_enableReverse>("reversible");

		//context.captureMethodCall<CWidgetEx, &setParent>("setParent");
		//context.captureMethodCall<CWidgetEx, &setBackgroundColor>("setBackgroundColor");
		//context.captureMethodCall<CWidgetEx, &setSize>("setSize");
		//context.captureMethodCall<CWidgetEx, &setPositon>("setPosition");

		//context.captureMethodCall<CWidgetEx, &setLayout>("setLayout");
		context.captureMethodCall<CWidgetEx, &setOrientation>("setOrientation");

		//context.captureMethodCall<CWidgetEx, &show>("show");
		//context.captureMethodCall<CWidgetEx, &hide>("hide");

		//context.captureMethodCall<CWidgetEx, &setClipArea>("setClipArea");
		//context.captureMethodCall<CWidgetEx, &removeClipArea>("removeClipArea");
		//context.captureMethodCall<CWidgetEx, &setAlpha>("setAlpha");
		//context.captureMethodCall<CWidgetEx, &setPivotPoint>("setPivotPoint");
		//context.captureMethodCall<CWidgetEx, &setRotation>("setRotation");
		//context.captureMethodCall<CWidgetEx, &setScale>("setScale");
		//context.captureMethodCall<CWidgetEx, &setSize>("setSize");
		//context.captureMethodCall<CWidgetEx, &addChild>("addChild");
		//context.captureMethodCall<CWidgetEx, &numOfChildren>("numOfChildren");
		//context.captureMethodCall<CWidgetEx, &destroyAllChildren>("destroyAllChildren");
		//context.captureMethodCall<CWidgetEx, &raise>("raise");
		//context.captureMethodCall<CWidgetEx, &lower>("lower");
		context.captureMethodCall<CWidgetEx, &enable>("enable");
		context.captureMethodCall<CWidgetEx, &enableFocus>("enableFocus");
		context.captureMethodCall<CWidgetEx, &enablePointerFocus>("enablePointerFocus");
		context.captureMethodCall<CWidgetEx, &setFocus>("setFocus");
		context.captureMethodCall<CWidgetEx, &killFocus>("killFocus");
		context.captureMethodCall<CWidgetEx, &isFocused>("isFocused");
		context.captureMethodCall<CWidgetEx, &setTabWindow>("setTabWindow");
		context.captureMethodCall<CWidgetEx, &moveTab>("moveTab");

		context.captureMethodCall<CWidgetEx, &addMouseListener>("addMouseListener");
		context.captureMethodCall<CWidgetEx, &addKeyboardListener>("addKeyboardListener");
		context.captureMethodCall<CWidgetEx, &addClickListener>("addClickListener");
		context.captureMethodCall<CWidgetEx, &addKeyLongPressListener>("addKeyLongPressListener");
		context.captureMethodCall<CWidgetEx, &addFocusListener>("addFocusListener");
		context.captureMethodCall<CWidgetEx, &addDragListener>("addDragListener");
		context.captureMethodCall<CWidgetEx, &addFirstShownListener>("addFirstShownListener");
		context.captureMethodCall<CWidgetEx, &addActorListener>("addWidgetExListener");
		context.captureMethodCall<CWidgetEx, &addCursorListener>("addCursorListener");

		context.captureMethodCall<CWidgetEx, &addAction>("addAction");
		context.captureMethodCall<CWidgetEx, &removeMouseListener>("removeMouseListener");
		context.captureMethodCall<CWidgetEx, &removeKeyboardListener>("removeKeyboardListener");
		context.captureMethodCall<CWidgetEx, &removeClickListener>("removeClickListener");
		context.captureMethodCall<CWidgetEx, &removeKeyLongPressListener>("removeKeyLongPressListener");
		context.captureMethodCall<CWidgetEx, &removeFocusListener>("removeFocusListener");
		context.captureMethodCall<CWidgetEx, &removeDragListener>("removeDragListener");
		context.captureMethodCall<CWidgetEx, &removeFirstShownListener>("removeFirstShownListener");
		context.captureMethodCall<CWidgetEx, &removeActorListener>("removeWidgetExListener");
		context.captureMethodCall<CWidgetEx, &removeCursorListener>("removeCursorListener");
		context.captureMethodCall<CWidgetEx, &removeAction>("removeAction");

		//context.captureMethodCall<CWidgetEx, &bindTransition>("bindTransition");

		context.capturePropertyAccess<CWidgetEx, &m_getOrientation, &m_setOrientation>("orientation");
	}

	Widget* Bridge::WidgetExBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
	{
		if (width == -1)
		{
			width = 0;
		}
		if (height == -1)
		{
			height = 0;
		}

		CWidgetEx* cWidgetEx = new CWidgetEx(x, y, width, height, parent);
		return (Widget*)cWidgetEx;
	}

	void Bridge::WidgetExBridge::destroyFromScript(void* destroyedObject)
    {
      volt::graphics::Widget* widget = reinterpret_cast<volt::graphics::Widget*>(destroyedObject);
      delete widget;
	  if (IEventManager::GetInstance())
	  {
		  IEventManager::GetInstance()->RemoveAsyncReleaseTarget(widget);
	  }
    }
	
	ScriptObject WidgetExBridge::handleDestroy(CWidgetEx* self, const ScriptArray& args)
	{
	  delete self;
	  if (IEventManager::GetInstance())
	  {
		  IEventManager::GetInstance()->RemoveAsyncReleaseTarget(self);
	  }
	  return ScriptObject();
	}
	//
	//ScriptObject WidgetExBridge::setBackgroundColor(CWidgetEx* self, const ScriptArray& args)
	//{
	//	guint8 r = 0, g = 0, b = 0, a = 0;
	//
	//	if(args.Length() > 0)
	//	{
	//		if(args.has(0) && args[0].isNumber()) {r = args[0].asNumber();}
	//		if(args.has(1) && args[1].isNumber()) {g = args[1].asNumber();}
	//		if(args.has(2) && args[2].isNumber()) {b = args[2].asNumber();}
	//		if(args.has(3) && args[3].isNumber()) {a = args[3].asNumber();}
	//	}
	//	ClutterColor c = {r, g, b, a};
	//
	//	self->SetBackgroundColor(c);
	//	
	//	return ScriptObject();
	//}
	//
	//ScriptObject Bridge::WidgetExBridge::setParent(CWidgetEx* self, const ScriptArray& args)
	//{
	//	if (args.Length() > 0)
	//	{
	//		CWidgetEx* parent = unwrapNativeObject<CWidgetEx>(args[0]);
	//		self->SetParent(parent);
	//	}
	//
	//	return ScriptObject();
	//}
	//
	//ScriptObject Bridge::WidgetExBridge::setSize(CWidgetEx* self, const ScriptArray& args)
	//{
	//	float width = -1, height = -1;
	//
	//	if (args.Length() > 0)
	//	{
	//		if (args.has(0) && args[0].isNumber())
	//		{
	//			width = args[0].asNumber();
	//		}
	//		if (args.has(1) && args[1].isNumber())
	//		{
	//			height = args[1].asNumber();
	//		}
	//	}
	//	self->Resize(width, height);
	//
	//	return ScriptObject();
	//}
	//
	//ScriptObject WidgetExBridge::setPositon(CWidgetEx* self, const ScriptArray& args)
	//{
	//	float x = 0, y = 0;
	//
	//	if (args.Length() > 0)
	//	{
	//		if (args.has(0) && args[0].isNumber())
	//		{
	//			x = args[0].asNumber();
	//		}
	//		if (args.has(1) && args[1].isNumber())
	//		{
	//			y = args[1].asNumber();
	//		}
	//	}
	//	self->SetPosition(x, y);
	//
	//	return ScriptObject();
	//}
	//
	//ScriptObject Bridge::WidgetExBridge::setLayout(CWidgetEx* self, const ScriptArray& args)
	//{
	//	if (args.Length() > 0)
	//	{
	//		ILayout* layout = unwrapNativeObject<ILayout>(args[0]);
	//		self->SetLayout(layout);
	//	}
	//
	//	return ScriptObject();
	//}
	ScriptObject Bridge::WidgetExBridge::isReversible(CWidgetEx* self, const ScriptArray& args)
	{
		return ScriptObject(self->IsReversible());
	}

	ScriptObject Bridge::WidgetExBridge::enableReverse(CWidgetEx* self, const ScriptArray& args)
	{
		bool flagEnable = true;

		if (args.Length() > 0)
		{
			if (args[0].isBool())
			{
				flagEnable = args[0].asBool();
			}
		}
		self->EnableReverse(flagEnable);

		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::setOrientation(CWidgetEx* self, const ScriptArray& args)
	{
		HALO_ASSERT(1 == args.Length() && true == args[0].isString());

		std::string orientationStr = args[0].asString();
		EOrientation orientationValue;

		if ("left-to-right" == orientationStr)
		{
			orientationValue = ORIENTATION_LEFT_TO_RIGHT;
		}
		else if ("right-to-left" == orientationStr)
		{
			orientationValue = ORIENTATION_RIGHT_TO_LEFT;
		}
		else if ("refer-to-parent" == orientationStr)
		{
			orientationValue = ORIENTATION_REFER_TO_PARENT;
		}
		else
		{
			HALO_EXCEPTION(false,  "orientation value is not correct\n");
		}

		self->SetOrientation(orientationValue);

		return ScriptObject();
	}

	//ScriptObject WidgetExBridge::show(CWidgetEx* self, const ScriptArray& args)
	//{
	//	self->Show();
	//	return ScriptObject();
	//}
	//
	//ScriptObject Bridge::WidgetExBridge::hide(CWidgetEx* self, const ScriptArray& args)
	//{
	//	self->Hide();
	//	return ScriptObject();
	//}
	//
	//ScriptObject Bridge::WidgetExBridge::setClipArea(CWidgetEx* self, const ScriptArray& args)
	//{
	//	float x = 0, y = 0, width = 0, height = 0;
	//	if (args.Length() >= 4)
	//	{
	//		if (args[0].isNumber())
	//		{
	//			x = args[0].asNumber();
	//		}
	//		if (args[1].isNumber())
	//		{
	//			y = args[1].asNumber();
	//		}
	//		if (args[2].isNumber())
	//		{
	//			width = args[2].asNumber();
	//		}
	//		if (args[3].isNumber())
	//		{
	//			height = args[3].asNumber();
	//		}
	//	}
	//
	//	self->SetClipArea(x, y, width, height);
	//
	//	return ScriptObject();
	//}
	//
	//ScriptObject Bridge::WidgetExBridge::removeClipArea(CWidgetEx* self, const ScriptArray& args)
	//{
	//	self->RemoveClipArea();
	//	return ScriptObject();
	//}
	//
	//ScriptObject Bridge::WidgetExBridge::setAlpha(CWidgetEx* self, const ScriptArray& args)
	//{
	//	return ScriptObject();
	//}
	//
	//ScriptObject Bridge::WidgetExBridge::setPivotPoint(CWidgetEx* self, const ScriptArray& args)
	//{
	//	return ScriptObject();
	//}
	//
	//ScriptObject Bridge::WidgetExBridge::setRotation(CWidgetEx* self, const ScriptArray& args)
	//{
	//	return ScriptObject();
	//}
	//
	//ScriptObject Bridge::WidgetExBridge::setScale(CWidgetEx* self, const ScriptArray& args)
	//{
	//	return ScriptObject();
	//}
	//
	//ScriptObject Bridge::WidgetExBridge::addChild(CWidgetEx* self, const ScriptArray& args)
	//{
	//	if (args.Length() > 0)
	//	{
	//		ClutterActor* child = unwrapNativeObject<ClutterActor>(args[0]);
	//		if (child != nullptr)
	//		{
	//			self->AddChild(child);
	//		}
	//	}
	//	return ScriptObject();
	//}
	//
	//ScriptObject Bridge::WidgetExBridge::numOfChildren(CWidgetEx* self, const ScriptArray& args)
	//{
	//	int num = self->NumOfChildren();
	//	return ScriptObject(num);
	//}
	//
	//ScriptObject Bridge::WidgetExBridge::destroyAllChildren(CWidgetEx* self, const ScriptArray& args)
	//{
	//	self->DestroyAllChildren();
	//	return ScriptObject();
	//}
	//
	//ScriptObject Bridge::WidgetExBridge::raise(CWidgetEx* self, const ScriptArray& args)
	//{
	//	if (args.Length() > 0)
	//	{
	//		CWidgetEx* sibling = unwrapNativeObject<CWidgetEx>(args[0]);
	//		self->Raise(sibling);
	//	}
	//	return ScriptObject();
	//}
	//
	//ScriptObject Bridge::WidgetExBridge::lower(CWidgetEx* self, const ScriptArray& args)
	//{
	//	if (args.Length() > 0)
	//	{
	//		CWidgetEx* sibling = unwrapNativeObject<CWidgetEx>(args[0]);
	//		self->Lower(sibling);
	//	}
	//	return ScriptObject();
	//}

	ScriptObject Bridge::WidgetExBridge::enable(CWidgetEx* self, const ScriptArray& args)
	{
		bool flagEnable = true;

		if (args.Length() > 0)
		{
			if (args[0].isBool())
			{
				flagEnable = args[0].asBool();
			}
		}
		self->Enable(flagEnable);

		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::enableFocus(CWidgetEx* self, const ScriptArray& args)
	{
		bool flagEnable = true;

		if (args.Length() > 0)
		{
			if (args[0].isBool())
			{
				flagEnable = args[0].asBool();
			}
		}
		self->EnableFocus(flagEnable);

		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::enablePointerFocus(CWidgetEx* self, const ScriptArray& args)
	{
		bool flagEnable = true;

		if (args.Length() > 0)
		{
			if (args[0].isBool())
			{
				flagEnable = args[0].asBool();
			}
		}
		self->EnablePointerFocus(flagEnable);

		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::setFocus(CWidgetEx* self, const ScriptArray& args)
	{
		self->SetFocus();
		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::killFocus(CWidgetEx* self, const ScriptArray& args)
	{
		bool flagEnable = true;

		if (args.Length() > 0)
		{
			if (args[0].isBool())
			{
				flagEnable = args[0].asBool();
			}
		}
		self->KillFocus(flagEnable);

		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::isFocused(CWidgetEx* self, const ScriptArray& args)
	{
		return ScriptObject(self->IsFocused());
	}

	ScriptObject Bridge::WidgetExBridge::setTabWindow(CWidgetEx* self, const ScriptArray& args)
	{
		std::string direction = args[0].asString();

		EDirection eDir = DIRECTION_MAX;
		if (direction == "left")
		{
			eDir = DIRECTION_LEFT;
		}
		else if (direction == "right")
		{
			eDir = DIRECTION_RIGHT;
		}
		else if (direction == "up")
		{
			eDir = DIRECTION_UP;
		}
		else if (direction == "down")
		{
			eDir = DIRECTION_DOWN;
		}
		else
		{
			HALO_EXCEPTION(false,  "Wrong direction!");
		}

		CWidgetEx *tabWindow = unwrapNativeObject<CWidgetEx>(args[0]);

		self->SetTabWindow(eDir, tabWindow);

		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::moveTab(CWidgetEx* self, const ScriptArray& args)
	{
		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::addMouseListener(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			IMouseListener* listener = unwrapNativeObject<IMouseListener>(args[0]);
			if (listener != nullptr)
			{
				self->AddMouseListener(listener);
			}
		}
		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::addKeyboardListener(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			IKeyboardListener* listener = unwrapNativeObject<IKeyboardListener>(args[0]);
			if (listener != nullptr)
			{
				self->AddKeyboardListener(listener);
			}
		}
		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::addClickListener(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			IClickListener* listener = unwrapNativeObject<IClickListener>(args[0]);
			if (listener != nullptr)
			{
				self->AddClickListener(listener);
			}
		}
		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::addKeyLongPressListener(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			IKeyLongPressListener* listener = unwrapNativeObject<IKeyLongPressListener>(args[0]);
			if (listener != nullptr)
			{
				self->AddKeyLongPressListener(listener);
			}
		}
		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::addFocusListener(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			IFocusListener* listener = unwrapNativeObject<IFocusListener>(args[0]);
			if (listener != nullptr)
			{
				self->AddFocusListener(listener);
			}
		}
		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::addDragListener(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			IDragListener* listener = unwrapNativeObject<IDragListener>(args[0]);
			if (listener != nullptr)
			{
				self->AddDragListener(listener);
			}
		}
		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::addCursorListener(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			ICursorListener* listener = unwrapNativeObject<ICursorListener>(args[0]);
			if (listener != nullptr)
			{
				self->AddCursorListener(listener);
			}
		}
		return ScriptObject();
	}

	ScriptObject WidgetExBridge::addFirstShownListener(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			InternalActorListener* listener = unwrapNativeObject<InternalActorListener>(args[0]);
			if (listener != nullptr)
			{
				self->AddActorListener(listener);
			}
		}
		return ScriptObject();
	}

	ScriptObject WidgetExBridge::removeFirstShownListener(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			InternalActorListener* listener = unwrapNativeObject<InternalActorListener>(args[0]);
			if (listener != nullptr)
			{
				self->RemoveActorListener(listener);
			}
		}
		return ScriptObject();
	}

	ScriptObject WidgetExBridge::addActorListener(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			InternalActorListener* listener = unwrapNativeObject<InternalActorListener>(args[0]);
			if (listener != nullptr)
			{
				self->AddActorListener(listener);
			}
		}
		return ScriptObject();
	}

	ScriptObject WidgetExBridge::removeActorListener(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			InternalActorListener* listener = unwrapNativeObject<InternalActorListener>(args[0]);
			if (listener != nullptr)
			{
				self->RemoveActorListener(listener);
			}
		}
		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::addAction(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			IAction* action = unwrapNativeObject<IAction>(args[0]);
			if (action != nullptr)
			{
				self->AddAction(action);
			}
		}
		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::removeMouseListener(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			IMouseListener* listener = unwrapNativeObject<IMouseListener>(args[0]);
			if (listener != nullptr)
			{
				self->RemoveMouseListener(listener);
			}
		}
		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::removeKeyboardListener(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			IKeyboardListener* listener = unwrapNativeObject<IKeyboardListener>(args[0]);
			if (listener != nullptr)
			{
				self->RemoveKeyboardListener(listener);
			}
		}
		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::removeClickListener(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			IClickListener* listener = unwrapNativeObject<IClickListener>(args[0]);
			if (listener != nullptr)
			{
				self->RemoveClickListener(listener);
			}
		}
		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::removeKeyLongPressListener(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			IKeyLongPressListener* listener = unwrapNativeObject<IKeyLongPressListener>(args[0]);
			if (listener != nullptr)
			{
				self->RemoveKeyLongPressListener(listener);
			}
		}
		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::removeFocusListener(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			IFocusListener* listener = unwrapNativeObject<IFocusListener>(args[0]);
			if (listener != nullptr)
			{
				self->RemoveFocusListener(listener);
			}
		}
		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::removeDragListener(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			IDragListener* listener = unwrapNativeObject<IDragListener>(args[0]);
			if (listener != nullptr)
			{
				self->RemoveDragListener(listener);
			}
		}
		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::removeCursorListener(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			ICursorListener* listener = unwrapNativeObject<ICursorListener>(args[0]);
			if (listener != nullptr)
			{
				self->RemoveCursorListener(listener);
			}
		}
		return ScriptObject();
	}

	ScriptObject Bridge::WidgetExBridge::removeAction(CWidgetEx* self, const ScriptArray& args)
	{
		if (args.Length() > 0)
		{
			IAction* listener = unwrapNativeObject<IAction>(args[0]);
			if (listener != nullptr)
			{
				self->RemoveAction(listener);
			}
		}
		return ScriptObject();
	}

	//ScriptObject Bridge::WidgetExBridge::bindTransition(CWidgetEx* self, const ScriptArray& args)
	//{
	//	HALO_ASSERT(NULL != self);
	//	HALO_ASSERT(2 == args.Length() && true == args[1].isNumber());
	//
	//	ITransition *trans = unwrapNativeObject<ITransition>(args[0]);
	//	int animationType = (int)args[1].asNumber();
	//
	//	self->BindTransition(trans, animationType);
	//
	//	return ScriptObject();
	//}

	ScriptObject WidgetExBridge::m_getOrientation(CWidgetEx* self)
	{
		EOrientation ori = self->Orientation(true);
		switch (ori)
		{
		case HALO::ORIENTATION_RIGHT_TO_LEFT:
			return ScriptObject("right-to-left");
		case HALO::ORIENTATION_REFER_TO_PARENT:
			return ScriptObject("refer-to-parent");
		default:
			return ScriptObject("left-to-right");
		}
	}

	void WidgetExBridge::m_setOrientation(CWidgetEx* self, ScriptObject value)
	{
		std::string orientationStr = value.asString();
		EOrientation orientationValue = ORIENTATION_REFER_TO_PARENT;

		if ("left-to-right" == orientationStr)
		{
			orientationValue = ORIENTATION_LEFT_TO_RIGHT;
		}
		else if ("right-to-left" == orientationStr)
		{
			orientationValue = ORIENTATION_RIGHT_TO_LEFT;
		}
		else if ("refer-to-parent" == orientationStr)
		{
			orientationValue = ORIENTATION_REFER_TO_PARENT;
		}
		else
		{
			HALO_EXCEPTION(false,  "orientation value is not correct\n");
		}

		self->SetOrientation(orientationValue);
	}

	ScriptObject WidgetExBridge::m_isReversible(CWidgetEx* self)
	{
		bool reversibleFlag = self->IsReversible();
		return ScriptObject(reversibleFlag);
	}

	void WidgetExBridge::m_enableReverse(CWidgetEx* self, ScriptObject value)
	{
		bool reverseFlag = value.asBool();
		self->EnableReverse(reverseFlag);
	}
}
