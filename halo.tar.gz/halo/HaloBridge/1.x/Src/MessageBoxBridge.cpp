#include "HaloBridgeAll.h"

using namespace HALO;
using namespace Bridge;

void MessageBoxListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	context.bindFunction<InternalMessageBoxListener, &InternalMessageBoxListener::GetButtonEventCallBack, &InternalMessageBoxListener::SetButtonEventCallBack>("OnButtonEvent");	
}

void* MessageBoxListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalMessageBoxListener;
}

std::string InternalMessageBoxListener::deserializeState(IMessageBoxListener::EEventTypes eventType)
{
	if ( IMessageBoxListener::BUTTON_FOCUS_IN == eventType)
	{
		return "button_focus_in";
	}
	else if (IMessageBoxListener::BUTTON_FOCUS_OUT == eventType)
	{
		return "button_focus_out";
	}
	else if (IMessageBoxListener::BUTTON_CLICKED == eventType)
	{
		return "button_clicked";
	}
	else
	{
		return "";
	}
}

std::string InternalMessageBoxListener::deserializeButtonState(IMessageBox::EMessageButtons buttonType)
{
	if ( IMessageBox::NO_BUTTON == buttonType)
	{
		return "no_button";
	}
	else if (IMessageBox::BUTTON_1 == buttonType)
	{
		return "button_1";
	}
	else if (IMessageBox::BUTTON_2 == buttonType)
	{
		return "button_2";
	}
	else if (IMessageBox::BUTTON_3 == buttonType)
	{
		return "button_3";
	}
	else if (IMessageBox::BUTTON_ALL == buttonType)
	{
		return "button_all";
	}
	else
	{
		return "";
	}
}

bool InternalMessageBoxListener::OnButtonEvent(class IMessageBox* messagebox, const int nButtonIndex, IMessageBoxListener::EEventTypes eventType)
{
	if (true == ButtonEventCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CMessageBox*>(messagebox)));
		args.set(1, ScriptObject(deserializeButtonState(nButtonIndex)));
		args.set(2, ScriptObject(deserializeState(eventType)));
		ButtonEventCb.function.invoke(args);
	}
	return true;
}

//MessageBoxBridge
void MessageBoxBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.captureMethodCall<CMessageBox, &setBGColor>("setBGColor");
	context.captureMethodCall<CMessageBox, &setTitleRect>("setTitleRect");
	context.captureMethodCall<CMessageBox, &setTitleTextColor>("setTitleTextColor");
	context.captureMethodCall<CMessageBox, &setTitleTextAlignment>("setTitleTextAlignment");
	context.captureMethodCall<CMessageBox, &titleTextLineCount>("titleTextLineCount");
	context.captureMethodCall<CMessageBox, &setTitleLineRect>("setTitleLineRect");
	context.captureMethodCall<CMessageBox, &setTitleLineColor>("setTitleLineColor");
	context.captureMethodCall<CMessageBox, &setContentRect>("setContentRect");
	context.captureMethodCall<CMessageBox, &setContentTextColor>("setContentTextColor");
	context.captureMethodCall<CMessageBox, &setContentTextAlignment>("setContentTextAlignment");
	context.captureMethodCall<CMessageBox, &contentTextLineCount>("contentTextLineCount");
	context.captureMethodCall<CMessageBox, &setContent2Rect>("setContent2Rect");
	context.captureMethodCall<CMessageBox, &setContentText2Color>("setContentText2Color");
	context.captureMethodCall<CMessageBox, &setContentText2Alignment>("setContentText2Alignment");
	context.captureMethodCall<CMessageBox, &contentText2LineCount>("contentText2LineCount");
	context.captureMethodCall<CMessageBox, &setButtonRect>("setButtonRect");
	context.captureMethodCall<CMessageBox, &setButtonImage>("setButtonImage");
	context.captureMethodCall<CMessageBox, &setButtonBackgroundColor>("setButtonBackgroundColor");
	context.captureMethodCall<CMessageBox, &setButtonText>("setButtonText");
	context.captureMethodCall<CMessageBox, &setButtonTextColor>("setButtonTextColor");
	context.captureMethodCall<CMessageBox, &setButtonTextFontSize>("setButtonTextFontSize");
	context.captureMethodCall<CMessageBox, &addListener>("addListener");
	context.captureMethodCall<CMessageBox, &removeListener>("removeListener");
	context.captureMethodCall<CMessageBox, &setLoadingAttr>("setLoadingAttr");

	// TODO: do not use these Apis, they will be deprecated later
	context.captureMethodCall<CMessageBox, &setTitleText>("setTitleText");
	context.captureMethodCall<CMessageBox, &setTitleTextFont>("setTitleTextFont");
	context.captureMethodCall<CMessageBox, &setContentText>("setContentText");
	context.captureMethodCall<CMessageBox, &setContentTextFont>("setContentTextFont");
	context.captureMethodCall<CMessageBox, &setContentText2>("setContentText2");
	context.captureMethodCall<CMessageBox, &setContentText2Font>("setContentText2Font");
	context.captureMethodCall<CMessageBox, &setDefaultFocus>("setDefaultFocus");
	context.captureMethodCall<CMessageBox, &supportTTS>("supportTTS");	
	/////////////////

	context.bindString<CMessageBox, &CMessageBox::TitleText, &CMessageBox::SetTitleText>("titleText");
	context.bindString<CMessageBox, &CMessageBox::TitleTextFont, &CMessageBox::SetTitleTextFont>("titleTextFont");
	context.bindString<CMessageBox, &CMessageBox::ContentText, &CMessageBox::SetContentText>("contentText");
	context.bindString<CMessageBox, &CMessageBox::ContentTextFont, &CMessageBox::SetContentTextFont>("contentTextFont");
	context.bindNumber<CMessageBox, int, &CMessageBox::ContentTextRowGap, &CMessageBox::SetContentTextRowGap>("contentTextRowGap");
	context.bindString<CMessageBox, &CMessageBox::ContentText2, &CMessageBox::SetContentText2>("contentText2");
	context.bindString<CMessageBox, &CMessageBox::ContentText2Font, &CMessageBox::SetContentText2Font>("contentText2Font");
	context.bindNumber<CMessageBox, int, &CMessageBox::DefaultFocus, &CMessageBox::SetDefaultFocus>("defaultFocusIndex");
	context.bindBoolean<CMessageBox, &CMessageBox::SupportTTS, &CMessageBox::SetSupportTTS>("supportTTSFlag");
	context.bindNumber<CMessageBox, guint, &CMessageBox::ShowTime, &CMessageBox::SetShowTime>("showTime");
}

Widget* MessageBoxBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	CMessageBox::TMessageBoxAttr attr;
	ScriptObject options;
	int argsLen = args.Length();
	if (argsLen > 0)
	{
		options = args[0];
		parseMessageBoxParams(options, attr);
	}

	CMessageBox *messageBox = dynamic_cast<CMessageBox *>(IMessageBox::CreateInstance(parent, attr));
	if (messageBox == NULL)
	{
		return NULL;
	}
	
	if (attr.bTitle && options.has("titleTextFont"))
	{
		std::string titleTextFont = options.get("titleTextFont").asString();
		messageBox->SetTitleTextFont(titleTextFont);
	}

	if (attr.bTitle && options.has("titleText"))
	{
		std::string titleText = options.get("titleText").asString();
		messageBox->SetTitleText(titleText);
	}

	if (options.has("contentTextFont"))
	{
		std::string contentTextFont = options.get("contentTextFont").asString();
		messageBox->SetContentTextFont(contentTextFont);
	}

	if (options.has("contentText"))
	{
		std::string contentText = options.get("contentText").asString();
		messageBox->SetContentText(contentText);
	}

	if (options.has("contentText2Font"))
	{
		std::string contentText2Font = options.get("contentText2Font").asString();
		messageBox->SetContentText2Font(contentText2Font);
	}

	if (options.has("contentText2"))
	{
		std::string contentText2 = options.get("contentText2").asString();
		messageBox->SetContentText2(contentText2);
	}

	if (options.has("button_1_Text"))
	{
		std::string button_1_Text = options.get("button_1_Text").asString();
		messageBox->SetButtonText(CMessageBox::BUTTON_1, IButton::STATE_ALL, button_1_Text);
	}

	if (options.has("button_2_Text"))
	{
		std::string button_2_Text = options.get("button_2_Text").asString();
		messageBox->SetButtonText(CMessageBox::BUTTON_2, IButton::STATE_ALL, button_2_Text);
	}

	if (options.has("button_3_Text"))
	{
		std::string button_3_Text = options.get("button_3_Text").asString();
		messageBox->SetButtonText(CMessageBox::BUTTON_3, IButton::STATE_ALL, button_3_Text);
	}

	if (options.has("normalButtonImagePath"))
	{
		std::string normalButtonImagePath = options.get("normalButtonImagePath").asString();
		messageBox->SetButtonImage(CMessageBox::BUTTON_ALL, IButton::STATE_ALL, normalButtonImagePath);
	}

	if (options.has("focusButtonImagePath"))
	{
		std::string focusButtonImagePath = options.get("focusButtonImagePath").asString();
		messageBox->SetButtonImage(CMessageBox::BUTTON_ALL, IButton::STATE_FOCUSED, focusButtonImagePath);
		messageBox->SetButtonImage(CMessageBox::BUTTON_ALL, IButton::STATE_ROLL_OVER, focusButtonImagePath);
		messageBox->SetButtonImage(CMessageBox::BUTTON_ALL, IButton::STATE_SELECTED, focusButtonImagePath);
		messageBox->SetButtonImage(CMessageBox::BUTTON_ALL, IButton::STATE_FOCUSED_ROLL_OVER, focusButtonImagePath);
	}

	if (options.has("buttonTextNormalSize"))
	{
		int buttonTextNormalSize = (int)options.get("buttonTextNormalSize").asNumber();
		messageBox->SetButtonTextFontSize(CMessageBox::BUTTON_ALL, IButton::STATE_ALL, buttonTextNormalSize); 
	}

	if (options.has("buttonTextFocusSize"))
	{
		int buttonTextFocusSize = (int)options.get("buttonTextFocusSize").asNumber();
		messageBox->SetButtonTextFontSize(CMessageBox::BUTTON_ALL, IButton::STATE_FOCUSED, buttonTextFocusSize); 
	}
	return dynamic_cast<CMessageBox*>(messageBox);
}

Bridge::ScriptObject MessageBoxBridge::setBGColor(CMessageBox* self, const ScriptArray &args)
{
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {r = (guint8)args[0].asNumber();}
		if (args.has(1) && args[1].isNumber()) {g = (guint8)args[1].asNumber();}
		if (args.has(2) && args[2].isNumber()) {b = (guint8)args[2].asNumber();}
		if (args.has(3) && args[3].isNumber()) {a = (guint8)args[3].asNumber();}
	}
	ClutterColor c = {r, g, b, a};
	if (self != NULL)
	{
		self->SetBGColor(c);
	}
	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setTitleRect(CMessageBox* self, const ScriptArray &args)
{
	float x = 0.0;
	float y = 0.0;
	float width = 1920;
	float height = 1080;
	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {x = static_cast<float>(args[0].asNumber());}
		if (args.has(1) && args[1].isNumber()) {y = static_cast<float>(args[1].asNumber());}
		if (args.has(2) && args[2].isNumber()) {width = static_cast<float>(args[2].asNumber());}
		if (args.has(3) && args[3].isNumber()) {height = static_cast<float>(args[3].asNumber());}
	}
	self->SetTitleRect(x, y, width, height);
	
	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setTitleLineRect(CMessageBox* self, const ScriptArray &args)
{
	float x = 0.0;
	float y = 0.0;
	float width = 1920;
	float height = 1080;
	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {x = static_cast<float>(args[0].asNumber());}
		if (args.has(1) && args[1].isNumber()) {y = static_cast<float>(args[1].asNumber());}
		if (args.has(2) && args[2].isNumber()) {width = static_cast<float>(args[2].asNumber());}
		if (args.has(3) && args[3].isNumber()) {height = static_cast<float>(args[3].asNumber());}
	}
	self->SetTitleLineRect(x, y, width, height);
	
	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setTitleText(CMessageBox* self, const ScriptArray &args)
{
	std::string titleText = "";
	if (args.has(0) && args[0].isString()) {titleText = args[0].asString();}
	self->SetTitleText(titleText);
	
	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setTitleTextColor(CMessageBox* self, const ScriptArray &args)
{
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {r = (guint8)args[0].asNumber();}
		if (args.has(1) && args[1].isNumber()) {g = (guint8)args[1].asNumber();}
		if (args.has(2) && args[2].isNumber()) {b = (guint8)args[2].asNumber();}
		if (args.has(3) && args[3].isNumber()) {a = (guint8)args[3].asNumber();}
	}
	ClutterColor c = {r, g, b, a};
	if (self != NULL)
	{
		self->SetTitleTextColor(c);
	}
	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setTitleTextFont(CMessageBox* self, const ScriptArray &args)
{
	std::string titleFont = "";
	if (args.has(0) && args[0].isString()) {titleFont = args[0].asString();}
	self->SetTitleTextFont(titleFont);
	
	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setTitleLineColor(CMessageBox* self, const ScriptArray &args)
{
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {r = (guint8)args[0].asNumber();}
		if (args.has(1) && args[1].isNumber()) {g = (guint8)args[1].asNumber();}
		if (args.has(2) && args[2].isNumber()) {b = (guint8)args[2].asNumber();}
		if (args.has(3) && args[3].isNumber()) {a = (guint8)args[3].asNumber();}
	}
	ClutterColor c = {r, g, b, a};
	if (self != NULL)
	{
		self->SetTitleLineColor(c);
	}
	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setTitleTextAlignment(CMessageBox* self, const ScriptArray& args)
{
	int h = 0; 
	int v = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString()) {h = deserializeAlignment(args[0].asString());}
		if (args.has(1) && args[1].isString()) {v = deserializeAlignment(args[1].asString());}
	}
	if (self != NULL)
	{
		self->SetTitleTextAlignment((EHAlignment)h, (EVAlignment)v);
	}
	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::titleTextLineCount(CMessageBox* self, const ScriptArray& args)
{
	return self->TitleTextLineCount();
}

Bridge::ScriptObject MessageBoxBridge::setContentRect(CMessageBox* self, const ScriptArray &args)
{
	ASSERT(4 == args.Length());

	float x = 0.0;
	float y = 0.0;
	float width = 0;
	float height = 0;
	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {x = static_cast<float>(args[0].asNumber());}
		if (args.has(1) && args[1].isNumber()) {y = static_cast<float>(args[1].asNumber());}
		if (args.has(2) && args[2].isNumber()) {width = static_cast<float>(args[2].asNumber());}
		if (args.has(3) && args[3].isNumber()) {height = static_cast<float>(args[3].asNumber());}
	}
	self->SetContentRect(x, y, width, height);

	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setContentText(CMessageBox* self, const ScriptArray &args)
{
	std::string contentText = "";
	if (args.has(0) && args[0].isString()) {contentText = args[0].asString();}
	self->SetContentText(contentText);
	
	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setContentTextColor(CMessageBox* self, const ScriptArray &args)
{
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {r = (guint8)args[0].asNumber();}
		if (args.has(1) && args[1].isNumber()) {g = (guint8)args[1].asNumber();}
		if (args.has(2) && args[2].isNumber()) {b = (guint8)args[2].asNumber();}
		if (args.has(3) && args[3].isNumber()) {a = (guint8)args[3].asNumber();}
	}
	ClutterColor c = {r, g, b, a};
	if (self != NULL)
	{
		self->SetContentTextColor(c);
	}
	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setContentTextFont(CMessageBox* self, const ScriptArray &args)
{
	std::string contentTextFont = "";
	if (args.has(0) && args[0].isString()) {contentTextFont = args[0].asString();}
	self->SetContentTextFont(contentTextFont);
	
	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setContentTextAlignment(CMessageBox* self, const ScriptArray& args)
{
	int h = 0; 
	int v = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString()) {h = deserializeAlignment(args[0].asString());}
		if (args.has(1) && args[1].isString()) {v = deserializeAlignment(args[1].asString());}
	}
	if (self != NULL)
	{
		self->SetContentTextAlignment((EHAlignment)h, (EVAlignment)v);
	}
	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::contentTextLineCount(CMessageBox* self, const ScriptArray& args)
{
	return self->ContentTextLineCount();
}

Bridge::ScriptObject MessageBoxBridge::setContent2Rect(CMessageBox* self, const ScriptArray &args)
{
	float x = 0.0;
	float y = 0.0;
	float width = 0;
	float height = 0;
	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {x = static_cast<float>(args[0].asNumber());}
		if (args.has(1) && args[1].isNumber()) {y = static_cast<float>(args[1].asNumber());}
		if (args.has(2) && args[2].isNumber()) {width = static_cast<float>(args[2].asNumber());}
		if (args.has(3) && args[3].isNumber()) {height = static_cast<float>(args[3].asNumber());}
	}
	self->SetContent2Rect(x, y, width, height);

	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setContentText2(CMessageBox* self, const ScriptArray &args)
{
	std::string contentText2 = "";
	if (args.has(0) && args[0].isString()) {contentText2 = args[0].asString();}
	self->SetContentText2(contentText2);
	
	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setContentText2Color(CMessageBox* self, const ScriptArray &args)
{
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if(args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {r = (guint8)args[0].asNumber();}
		if (args.has(1) && args[1].isNumber()) {g = (guint8)args[1].asNumber();}
		if (args.has(2) && args[2].isNumber()) {b = (guint8)args[2].asNumber();}
		if (args.has(3) && args[3].isNumber()) {a = (guint8)args[3].asNumber();}
	}
	ClutterColor c = {r, g, b, a};
	if (self != NULL)
	{
		self->SetContentText2Color(c);
	}
	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setContentText2Font(CMessageBox* self, const ScriptArray &args)
{
	std::string contentText2Font = "";
	if (args.has(0) && args[0].isString()) {contentText2Font = args[0].asString();}
	self->SetContentText2Font(contentText2Font);
	
	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setContentText2Alignment(CMessageBox* self, const ScriptArray& args)
{
	int h = 0; 
	int v = 0;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isString()) {h = deserializeAlignment(args[0].asString());}
		if (args.has(1) && args[1].isString()) {v = deserializeAlignment(args[1].asString());}
	}
	if (self != NULL)
	{
		self->SetContentText2Alignment((EHAlignment)h, (EVAlignment)v);
	}
	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::contentText2LineCount(CMessageBox* self, const ScriptArray& args)
{
	return self->ContentText2LineCount();
}

Bridge::ScriptObject MessageBoxBridge::setButtonRect(CMessageBox* self, const ScriptArray &args)
{
	CMessageBox::EMessageButtons buttonType = CMessageBox::BUTTON_ALL;
	if(args.has(0) && args[0].isString()) { buttonType = deserializeButtonState(args[0].asString(), CMessageBox::BUTTON_ALL); }
	float x = 0.0;
	float y = 0.0;
	float width = 0;
	float height = 0;
	if(args.Length() > 0)
	{
		if (args.has(1) && args[1].isNumber()) {x = static_cast<float>(args[1].asNumber());}
		if (args.has(2) && args[2].isNumber()) {y = static_cast<float>(args[2].asNumber());}
		if (args.has(3) && args[3].isNumber()) {width = static_cast<float>(args[3].asNumber());}
		if (args.has(4) && args[4].isNumber()) {height = static_cast<float>(args[4].asNumber());}
	}
	self->SetButtonRect(buttonType, x, y, width, height);

	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setButtonImage(CMessageBox* self, const ScriptArray &args)
{
	if (args.Length() > 0)
	{
		CMessageBox::EMessageButtons buttonIndex = CMessageBox::BUTTON_ALL;
		if(args.has(0) && args[0].isString()) { buttonIndex = deserializeButtonState(args[0].asString(), CMessageBox::BUTTON_ALL); }
		std::string state = "all";
		if(args.has(1) && args[1].isString()) { state = args[1].asString(); }
		std::string buttonImagePath = "";
		if(args.has(2) && args[2].isString()) { buttonImagePath = args[2].asString(); }

		self->SetButtonImage(buttonIndex, ButtonBridge::deserializeState(state, IButton::STATE_NORMAL), buttonImagePath);
		return ScriptObject();
	}
	
	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setButtonBackgroundColor(CMessageBox* self, const ScriptArray &args)
{
	CMessageBox::EMessageButtons buttonIndex = CMessageBox::BUTTON_ALL;
	if(args.has(0) && args[0].isString()) { buttonIndex = deserializeButtonState(args[0].asString(), CMessageBox::BUTTON_ALL); }
	std::string state = "all";
	if(args.has(1) && args[1].isString()) { state = args[1].asString(); }
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if(args.Length() > 2)
	{
		if (args.has(2) && args[2].isNumber()) {r = (guint8)args[2].asNumber();}
		if (args.has(3) && args[3].isNumber()) {g = (guint8)args[3].asNumber();}
		if (args.has(4) && args[4].isNumber()) {b = (guint8)args[4].asNumber();}
		if (args.has(5) && args[5].isNumber()) {a = (guint8)args[5].asNumber();}
	}
	ClutterColor c = {r, g, b, a};
	self->SetButtonBackgroundColor(buttonIndex, ButtonBridge::deserializeState(state, IButton::STATE_NORMAL), c);

	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setButtonText(CMessageBox* self, const ScriptArray &args)
{
	CMessageBox::EMessageButtons buttonIndex = CMessageBox::BUTTON_ALL;
	std::string state = "all";
	std::string buttonText = "";
	if(args[0].isString()) { buttonIndex = deserializeButtonState(args[0].asString(), CMessageBox::BUTTON_ALL); }
	if(args[1].isString()) { state = args[1].asString(); }
	if(args[2].isString()) { buttonText = args[2].asString(); }
	
	self->SetButtonText(buttonIndex, ButtonBridge::deserializeState(state, IButton::STATE_NORMAL), buttonText);
	
	return ScriptObject();

}

Bridge::ScriptObject MessageBoxBridge::setButtonTextColor(CMessageBox* self, const ScriptArray &args)
{
	CMessageBox::EMessageButtons buttonIndex = CMessageBox::BUTTON_ALL;
	if(args.has(0) && args[0].isString()) { buttonIndex = deserializeButtonState(args[0].asString(), CMessageBox::BUTTON_ALL); }
	std::string state = "all";
	if(args.has(1) && args[1].isString()) { state = args[1].asString(); }
	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 0;

	if(args.Length() > 2)
	{
		if (args.has(2) && args[2].isNumber()) {r = (guint8)args[2].asNumber();}
		if (args.has(3) && args[3].isNumber()) {g = (guint8)args[3].asNumber();}
		if (args.has(4) && args[4].isNumber()) {b = (guint8)args[4].asNumber();}
		if (args.has(5) && args[5].isNumber()) {a = (guint8)args[5].asNumber();}
	}
	ClutterColor c = {r, g, b, a};
	self->SetButtonTextColor(buttonIndex, ButtonBridge::deserializeState(state, IButton::STATE_NORMAL), c);

	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setButtonTextFontSize(CMessageBox* self, const ScriptArray &args)
{
	int buttonTextFontSize = 32;
	CMessageBox::EMessageButtons buttonIndex = CMessageBox::BUTTON_ALL;
	std::string state = "all";
	std::string buttonText = "";
	if(args.has(0) && args[0].isString()) { buttonIndex = deserializeButtonState(args[0].asString(), CMessageBox::BUTTON_ALL); }
	if(args.has(1) && args[1].isString()) { state = args[1].asString(); }
	if(args.has(2) && args[2].isNumber()) { buttonTextFontSize = (int)args[2].asNumber(); }

	self->SetButtonTextFontSize(buttonIndex, ButtonBridge::deserializeState(state, IButton::STATE_NORMAL), buttonTextFontSize);
	
	return ScriptObject();

}

Bridge::ScriptObject MessageBoxBridge::setDefaultFocus(CMessageBox* self, const ScriptArray &args)
{
	CMessageBox::EMessageButtons buttonIndex = CMessageBox::BUTTON_1;
	if(args.has(0) && args[0].isString()) { buttonIndex = deserializeButtonState(args[0].asString(), CMessageBox::BUTTON_1); }

	self->SetDefaultFocus(buttonIndex);

	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::addListener(CMessageBox* self, const ScriptArray &args)
{
	if (args.Length() > 0)
	{
		IMessageBoxListener* listener = unwrapNativeObject<IMessageBoxListener>(args[0]);
		if (listener != nullptr)
		{
			self->AddListener(listener);
		}
	}

	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::removeListener(CMessageBox* self, const ScriptArray &args)
{
	if (args.Length() > 0)
	{
		IMessageBoxListener* listener = unwrapNativeObject<IMessageBoxListener>(args[0]);
		if (listener != nullptr)
		{
			self->RemoveListener(listener);
		}
	}

	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::setLoadingAttr(CMessageBox* self, const ScriptArray &args)
{
	int argsLen = args.Length();
	ScriptObject options;
	ILoading::TLoadingAttr attr;	
	ScriptObject pathObj;
	ScriptObject nameObj;
	std::string pathStr;
	std::string nameStr;
	ScriptArray nameArray;
	if(argsLen > 0)
	{
		options = args[0];
		if (options.has("imageNum") || options.has("x") || options.has("y") || options.has("width") || options.has("height") ||
			options.has("imageFps") || options.has("gap") || options.has("imagePath") || options.has("imageName"))
		{
			if(options.has("imageNum")) attr.imageNum = (int)options.get("imageNum").asNumber();
			if(options.has("x")) attr.x = (float)options.get("x").asNumber();
			if(options.has("y")) attr.y = (float)options.get("y").asNumber();
			if(options.has("imageWidth")) attr.imageWidth = (float)options.get("imageWidth").asNumber();
			if(options.has("imageHeight")) attr.imageHeight = (float)options.get("imageHeight").asNumber();
			if(options.has("imageFps")) attr.fps = (int)options.get("imageFps").asNumber();
			if(options.has("gap")) attr.gap = (int)options.get("gap").asNumber();
			if(options.has("imagePath"))
			{
				pathObj = options.get("imagePath");
				ASSERT(true == pathObj.isString());
				pathStr = pathObj.asString();

				attr.path = pathStr.c_str();
			}
			if(options.has("imageName"))
			{
				nameObj = options.get("imageName");
				ASSERT(true == nameObj.isArray());

				nameArray = nameObj.asArray();

				attr.name = new char*[nameArray.Length()];

				for (int i = 0; i < nameArray.Length(); i++)
				{
					ScriptObject nameObj = nameArray[i];
					ASSERT(true == nameObj.isString());

					std::string nameStr = nameObj.asString();

					attr.name[i] = new char[nameStr.length()+1];
					strncpy(attr.name[i], nameStr.c_str(), nameStr.length()+1);
				}
			}
		}
	}
	self->SetLoadingAttr(attr);
	return ScriptObject();
}

Bridge::ScriptObject MessageBoxBridge::supportTTS(CMessageBox* self, const ScriptArray &args)
{
	bool bSupportTTS = false;
	if(args.has(0) && args[0].isBool()) { bSupportTTS = args[0].asBool();}
	self->SetSupportTTS(bSupportTTS);
	
	return ScriptObject();
}

CMessageBox::EMessageButtons MessageBoxBridge::deserializeButtonState(std::string stateStr, CMessageBox::EMessageButton theDefault)
{
	if (compareStrChar(stateStr, "no_button"))
	{
		return CMessageBox::NO_BUTTON;
	}
	else if (compareStrChar(stateStr, "button_1"))
	{
		return CMessageBox::BUTTON_1;
	}
	else if (compareStrChar(stateStr, "button_2"))
	{
		return CMessageBox::BUTTON_2;
	}
	else if (compareStrChar(stateStr, "button_3"))
	{
		return CMessageBox::BUTTON_3;
	}
	else if (compareStrChar(stateStr, "button_all"))
	{
		return CMessageBox::BUTTON_ALL;
	}
	else
	{
		return theDefault;
	}
}

CMessageBox::EMessageContents MessageBoxBridge::deserializeState(std::string stateStr, CMessageBox::EMessageContent theDefault)
{
	if (compareStrChar(stateStr, "single_line_content_type"))
	{
		return CMessageBox::SINGLE_LINE_CONTENT;
	}
	else if (compareStrChar(stateStr, "multi_line_content_type"))
	{
		return CMessageBox::MULTI_LINE_CONTENT;
	}
	else if (compareStrChar(stateStr, "multi_line_with_single_line_content_type"))
	{
		return CMessageBox::MULTI_LINE_CONTENT_WITH_SINGLE_LINE_CONTENT;
	}
	else if (compareStrChar(stateStr, "single_line_content_with_loading_type"))
	{
		return CMessageBox::SINGLE_LINE_CONTENT_WITH_LOADING;
	}
	else if (compareStrChar(stateStr, "multi_line_content_with_loading_type"))
	{
		return CMessageBox::MULTI_LINE_CONTENT_WITH_LOADING;
	}
	else
	{
		return theDefault;
	}
}

int MessageBoxBridge::deserializeAlignment(std::string alignMent)
{
	if (compareStrChar(alignMent, "horizontal_align_left"))
	{
		return HALIGN_LEFT;
	}
	else if (compareStrChar(alignMent, "horizontal_align_center"))
	{
		return HALIGN_CENTER;
	}
	else if (compareStrChar(alignMent, "horizontal_align_right"))
	{
		return HALIGN_RIGHT;
	}
	else if (compareStrChar(alignMent, "vertical_align_top"))
	{
		return VALIGN_TOP;
	}
	else if (compareStrChar(alignMent, "vertical_align_middle"))
	{
		return VALIGN_MIDDLE;
	}
	else if (compareStrChar(alignMent, "vertical_align_bottom"))
	{
		return VALIGN_BOTTOM;
	}
	else
	{
		return 0;
	}
}

void MessageBoxBridge::parseMessageBoxParams(const ScriptObject& options, CMessageBox::TMessageBoxAttr& attr)
{
	if (options.has("x"))
	{
		attr.x = static_cast<float>(options.get("x").asNumber());
	}
	if (options.has("y"))
	{
		attr.y = static_cast<float>(options.get("y").asNumber());
	}
	if (options.has("width"))
	{
		attr.w = static_cast<float>(options.get("width").asNumber());
	}
	if (options.has("height"))
	{
		attr.h = static_cast<float>(options.get("height").asNumber());
	}
	if (options.has("buttonType"))
	{
		attr.nButtonType = deserializeButtonState(options.get("buttonType").asString(), CMessageBox::NO_BUTTON);
	}
	if (options.has("contentType"))
	{
		attr.nContentType = deserializeState(options.get("contentType").asString(), CMessageBox::SINGLE_LINE_CONTENT);
	}
	if (options.has("bTitle"))
	{
		attr.bTitle = options.get("bTitle").asBool();
	}
	if (options.has("bAutoFlag"))
	{
		attr.bAutoFlag = options.get("bAutoFlag").asBool();
	}
}
