#include "HaloBridgeAll.h"

using namespace Bridge;
using namespace HALO;

void LoadingBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.bindNumber<CLoading, int, &CLoading::FPS, &CLoading::SetFPS>("imageFPS");
	context.bindNumber<CLoading, int, &CLoading::FontSize, &CLoading::SetFontSize>("fontSize");
	context.bindNumber<CLoading, int, &CLoading::Gap, &CLoading::SetGap>("gap");
	context.bindString<CLoading, &CLoading::Text, &CLoading::SetText>("text");
	context.bindString<CLoading, &CLoading::TextFont, &CLoading::SetTextFont>("textFont");
	
	context.captureMethodCall<CLoading, &m_Play>("play");
	context.captureMethodCall<CLoading, &m_Pause>("pause");
	context.captureMethodCall<CLoading, &m_Stop>("stop");
	context.captureMethodCall<CLoading, &m_SetTextColor>("setTextColor");
}

void* LoadingBridge::constructFromScript(const ScriptArray& args)
{
	Widget *cWidget = (Widget*)WidgetBridge::constructFromScript(args);
	cWidget->setColor(Color(0, 0, 0, 0));

	return cWidget;
}

Widget* LoadingBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	int argsLen = args.Length();
	ScriptObject options;

	ILoading::TLoadingAttr attr;	
	//Widget* parent = nullptr;

	ScriptObject textObj;
	ScriptObject pathObj;
	ScriptObject nameObj;
	ScriptObject fontObj;
	std::string textStr;
	std::string pathStr;
	std::string nameStr;
	std::string fontStr;
	ScriptArray nameArray;

	if(argsLen > 0)
	{
		options = args[0];
		if (options.has("imageNum") || options.has("x") || options.has("y") || options.has("width") || options.has("height") ||
			options.has("imageFPS") || options.has("fontSize") || options.has("gap") || options.has("text") || options.has("imagePath") ||
			options.has("imageName") || options.has("fontName") || options.has("color") || options.has("parent"))
		{
			if(options.has("imageNum")) attr.imageNum = options.get("imageNum").asNumber();
			if(options.has("x")) attr.x = options.get("x").asNumber();
			if(options.has("y")) attr.y = options.get("y").asNumber();
			if(options.has("width")) attr.imageWidth = options.get("width").asNumber();
			if(options.has("height")) attr.imageHeight = options.get("height").asNumber();
			if(options.has("imageWidth")) attr.imageWidth = options.get("imageWidth").asNumber();
			if(options.has("imageHeight")) attr.imageHeight = options.get("imageHeight").asNumber();
			if(options.has("textWidth")) attr.textWidth = options.get("textWidth").asNumber();
			if(options.has("textHeight")) attr.textHeight = options.get("textHeight").asNumber();			
			if(options.has("imageFPS")) attr.fps = options.get("imageFPS").asNumber();
			if(options.has("fontSize")) attr.fontSize = options.get("fontSize").asNumber();
			if(options.has("gap")) attr.gap = options.get("gap").asNumber();
			if(options.has("text")) 
			{
				textObj = options.get("text");
				HALO_ASSERT(true == textObj.isString());
				textStr = textObj.asString();

				attr.text = textStr.c_str();
			}
			if(options.has("imagePath"))
			{
				pathObj = options.get("imagePath");
				HALO_ASSERT(true == pathObj.isString());
				pathStr = pathObj.asString();

				attr.path = pathStr.c_str();
			}
			if(options.has("imageName"))
			{
				nameObj = options.get("imageName");
				HALO_ASSERT(true == nameObj.isArray());

				nameArray = nameObj.asArray();

				attr.name = new char*[nameArray.Length()];

				for (int i = 0; i < nameArray.Length(); i++)
				{
					ScriptObject nameObj = nameArray[i];
					HALO_ASSERT(true == nameObj.isString());

					std::string nameStr = nameObj.asString();

					attr.name[i] = new char[nameStr.length()+1];
					strncpy(attr.name[i], nameStr.c_str(), nameStr.length()+1);
				}
			}

			if(options.has("fontName")) 
			{
				fontObj = options.get("fontName");
				HALO_ASSERT(true == fontObj.isString());
				fontStr = fontObj.asString();
				
				attr.fontName = fontStr.c_str();
			}
			//if(options.has("parent")) parent = unwrapNativeObject<Widget>(options.get("parent")); 
			if(options.has("textColor"))
			{	
				ScriptObject val = options.get("textColor");

				if (true == val.has("r"))
				{
					ScriptObject obj = val.get("r");
					HALO_ASSERT(true == obj.isNumber());

					attr.color.red = (guint8)(obj.asNumber());
				}
				else
				{
					attr.color.red = 0;
				}
				
				if (true == val.has("g"))
				{
					ScriptObject obj = val.get("g");
					HALO_ASSERT(true == obj.isNumber());

					attr.color.green = (guint8)(obj.asNumber());
				}
				else
				{
					attr.color.green = 0;
				}

				if (true == val.has("b"))
				{
					ScriptObject obj = val.get("b");
					HALO_ASSERT(true == obj.isNumber());

					attr.color.blue = (guint8)(obj.asNumber());
				}
				else
				{
					attr.color.blue = 0;
				}

				if (true == val.has("a"))
				{
					ScriptObject obj = val.get("a");
					HALO_ASSERT(true == obj.isNumber());

					attr.color.alpha = (guint8)(obj.asNumber());
				}
				else
				{
					attr.color.alpha = 0;
				}
			}
		}
	}

	CLoading *loading = dynamic_cast<CLoading *>(ILoading::CreateInstance(parent, attr));

	//! Release
	for (int i = 0; i < nameArray.Length(); ++i)
	{
		if (attr.name[i] != NULL)
		{
			delete [] attr.name[i];
		}
	}
	delete [] attr.name;

	return loading;
}

ScriptObject LoadingBridge::m_SetTextColor(CLoading* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);
	HALO_ASSERT(args.Length() > 0);

	guint8 r = 0;
	guint8 g = 0;
	guint8 b = 0;
	guint8 a = 255;
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) {r = (guint8)args[0].asNumber();}
		if (args.has(1) && args[1].isNumber()) {g = (guint8)args[1].asNumber();}
		if (args.has(2) && args[2].isNumber()) {b = (guint8)args[2].asNumber();}
		if (args.has(3) && args[3].isNumber()) {a = (guint8)args[3].asNumber();}
	}
	ClutterColor c = { r, g, b, a };
	if (self != NULL)
	{
		self->SetTextColor(c);
	}

	return ScriptObject();
}

ScriptObject LoadingBridge::m_Play(CLoading* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);
	self->Play();

	return ScriptObject();
}

ScriptObject LoadingBridge::m_Pause(CLoading* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);
	self->Pause();

	return ScriptObject();
}

ScriptObject LoadingBridge::m_Stop(CLoading* self, const ScriptArray& args)
{
	HALO_ASSERT(NULL != self);
	self->Stop();

	return ScriptObject();
}
