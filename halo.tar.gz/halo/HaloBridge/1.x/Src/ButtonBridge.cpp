#include "HaloBridgeAll.h"

using namespace HALO;
using namespace Bridge;


void Bridge::ButtonBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);
	context.captureMethodCall<CButton, &backgroundColor>("backgroundColor");
	context.captureMethodCall<CButton, &setBackgroundColor>("setBackgroundColor");
	context.captureMethodCall<CButton, &backgroundImage>("backgroundImage");
	context.captureMethodCall<CButton, &setBackgroudImage>("setBackgroundImage");
	context.captureMethodCall<CButton, &text>("text");
	context.captureMethodCall<CButton, &setText>("setText");
	context.captureMethodCall<CButton, &fontSize>("fontSize");
	context.captureMethodCall<CButton, &setFontSize>("setFontSize");
	context.captureMethodCall<CButton, &textColor>("textColor");
	context.captureMethodCall<CButton, &setTextColor>("setTextColor");
	context.captureMethodCall<CButton, &iconImage>("iconImage");
	context.captureMethodCall<CButton, &setIconImage>("setIconImage");
	context.captureMethodCall<CButton, &iconAlpha>("iconAlpha");
	context.captureMethodCall<CButton, &setIconAlpha>("setIconAlpha");

	context.captureMethodCall<CButton, &setBackgroundImageAttr>("setBackgroundImageAttr");
	context.captureMethodCall<CButton, &setIconAttr>("setIconAttr");
	context.captureMethodCall<CButton, &setTextAttr>("setTextAttr");

	context.captureMethodCall<CButton, &addListener>("addListener");
	context.captureMethodCall<CButton, &removeListener>("removeListener");

	context.captureMethodCall<CButton, &setBorder>("setBorder");

	context.capturePropertyAccess<CButton, &getDefaultBorder, &setDefaultBorder>("border");
}

Widget* Bridge::ButtonBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	if (width < 0)
	{
		width = 0;
	}
	if (height < 0) 
	{ 
		height = 0; 
	}
	CButton* button = new CButton;
	button->Initialize(parent, width, height);
	button->SetPosition(x, y);

	ScriptObject options = args[0];
	Color bgColor = Color(255, 255, 255, 255);
	if (options.has("color"))
	{
		bgColor = ScriptToColor(options.get("color"));

	}
	button->SetBackgroundColor(IButton::STATE_ALL, *bgColor.toClutterColor());
	if (options.has("border"))
	{
		ScriptObject borderAttr = options.get("border");
		float borderWidth;
		Color borderColor;
		if (borderAttr.has("width"))
		{
			borderWidth = borderAttr["width"].asNumber();

			button->SetBorderWidth(IButton::STATE_ALL, borderWidth);
		}
		if (borderAttr.has("color"))
		{
			borderColor = ScriptToColor(borderAttr["color"]);
			button->SetBorderColor(IButton::STATE_ALL, *(borderColor.toClutterColor()));
		}
	}
	if (options.has("text"))
	{
		ScriptObject textAttr = options.get("text");
		if (textAttr.has("text"))
		{
			std::string textContent = textAttr.get("text").asString();
			button->SetText(IButton::STATE_ALL, textContent);
			CText* textActor = dynamic_cast<CText*>(button->TextActor());
			if (textActor == NULL)
			{
				return NULL;
			}
			if (textAttr.has("color"))
			{
				Color textColor = ScriptToColor(textAttr.get("color"));
				button->SetTextColor(IButton::STATE_ALL, *textColor.toClutterColor());
			}
			if (textAttr.has("x"))
			{
				float x = (float)textAttr.get("x").asNumber();
				textActor->setX(x);
			}
			if (textAttr.has("y"))
			{
				float y = (float)textAttr.get("y").asNumber();
				textActor->setY(y);
			}
			if (textAttr.has("width"))
			{
				float width = (float)textAttr.get("width").asNumber();
				textActor->setWidth(width);
			}
			if (textAttr.has("height"))
			{
				float height = (float)textAttr.get("height").asNumber();
				textActor->setHeight(height);
			}
			if (textAttr.has("font"))
			{
				std::string font = textAttr.get("font").asString();
				textActor->SetFont(font.c_str());
			}
			std::string hAlignment;
			std::string vAlignment;
			bool flagSetAlign = false;
			if (textAttr.has("hAlign"))
			{
				hAlignment = textAttr.get("hAlign").asString();		
				flagSetAlign = true;
			}
			if (textAttr.has("vAlign"))
			{
				vAlignment = textAttr.get("vAlign").asString();
				flagSetAlign = true;
			}
			if (flagSetAlign)
			{
				textActor->SetTextAlignment(deserializeHAlignment(hAlignment, HALO::HALIGN_CENTER), deserializeVAlignment(vAlignment, HALO::VALIGN_MIDDLE));
			}
		}
	}
	if (options.has("icon"))
	{
		ScriptObject iconAttr = options.get("icon");
		if (iconAttr.has("src"))
		{
			std::string imageSrc = iconAttr.get("src").asString();
			button->SetIconImage(IButton::STATE_ALL, imageSrc);
			CImage* iconActor = dynamic_cast<CImage*>(button->IconActor());
			if (iconActor == NULL)
			{
				return NULL;
			}

			if (iconAttr.has("x"))
			{
				float x = (float)iconAttr.get("x").asNumber();
				iconActor->setX(x);
			}
			if (iconAttr.has("y"))
			{
				float y = (float)iconAttr.get("y").asNumber();
				iconActor->setY(y);
			}
			if (iconAttr.has("width"))
			{
				float width = (float)iconAttr.get("width").asNumber();
				iconActor->setWidth(width);
			}
			if (iconAttr.has("height"))
			{
				float height = (float)iconAttr.get("height").asNumber();
				iconActor->setHeight(height);
			}
		}
	}
	if (options.has("backgroundImage"))
	{
		ScriptObject bgImageAttr = options.get("backgroundImage");
		if (bgImageAttr.has("src"))
		{
			std::string imageSrc = bgImageAttr.get("src").asString();
			button->SetBackgroundImage(IButton::STATE_ALL, imageSrc);
			CCompositeImage* backgroundImageActor = dynamic_cast<CCompositeImage*>(button->BackGroundImageActor());
			if (backgroundImageActor == NULL)
			{
				return NULL;
			}

			if (bgImageAttr.has("x"))
			{
				float x = (float)bgImageAttr.get("x").asNumber();
				backgroundImageActor->setX(x);
			}
			if (bgImageAttr.has("y"))
			{
				float y = (float)bgImageAttr.get("y").asNumber();
				backgroundImageActor->setY(y);
			}
			if (bgImageAttr.has("width"))
			{
				float width = (float)bgImageAttr.get("width").asNumber();
				backgroundImageActor->setWidth(width);
			}
			if (bgImageAttr.has("height"))
			{
				float height = (float)bgImageAttr.get("height").asNumber();
				backgroundImageActor->setHeight(height);
			}
		}
	}

	return button;
}

Bridge::ScriptObject Bridge::ButtonBridge::backgroundImage(CButton* self, const ScriptArray &args)
{
	std::string state;
	ScriptObject object = args[0];
	state = object.get("state").asString();
	return ScriptObject(self->BackgroundImage(deserializeState(state, CButton::STATE_NORMAL)));
}

Bridge::ScriptObject Bridge::ButtonBridge::setBackgroudImage(CButton* self, const ScriptArray &args)
{
	ScriptObject object = args[0];
	std::string state = object.get("state").asString();
	std::string imagePath = object.get("src").asString();

	self->SetBackgroundImage(deserializeState(state, CButton::STATE_NORMAL), imagePath);

	return ScriptObject();
}

CButton::EButtonState Bridge::ButtonBridge::deserializeState(std::string stateStr, CButton::EButtonState theDefault)
{
	if (compareStrChar(stateStr, "normal"))
	{
		return CButton::STATE_NORMAL;
	}
	else if (compareStrChar(stateStr, "focused"))
	{
		return CButton::STATE_FOCUSED;
	}
	else if (compareStrChar(stateStr, "selected"))
	{
		return CButton::STATE_SELECTED;
	}
	else if (compareStrChar(stateStr, "roll-over"))
	{
		return CButton::STATE_ROLL_OVER;
	}
	else if (compareStrChar(stateStr, "focused-roll-over"))
	{
		return CButton::STATE_FOCUSED_ROLL_OVER;
	}
	else if (compareStrChar(stateStr, "disabled"))
	{
		return CButton::STATE_DISABLED;
	}
	else if (compareStrChar(stateStr, "disabled-focused"))
	{
		return CButton::STATE_DISABLED_FOCUSED;
	}
	else if (compareStrChar(stateStr, "all"))
	{
		return CButton::STATE_ALL;
	}
	else
	{
		HALO_EXCEPTION(false, "The state string is invalid: " << stateStr);
		return theDefault;
	}
}

EHAlignment Bridge::ButtonBridge::deserializeHAlignment(std::string alignStr, EHAlignment theDefault)
{
	if (compareStrChar(alignStr, "left"))
	{
		return HALIGN_LEFT;
	}
	else if (compareStrChar(alignStr, "center"))
	{
		return HALIGN_CENTER;
	}
	else if (compareStrChar(alignStr, "right"))
	{
		return HALIGN_RIGHT;
	}
	else
	{
		HALO_EXCEPTION(false, "The align string is invalid: " << alignStr);
		return HALIGN_CENTER;
	}
}

Bridge::ScriptObject Bridge::ButtonBridge::text(CButton* self, const ScriptArray &args)
{
	if (args.Length() > 0)
	{
		ScriptObject object = args[0];

		std::string state = object.get("state").asString();

		return ScriptObject(self->Text(deserializeState(state, CButton::STATE_NORMAL)));
	}
	else
	{
		return ScriptObject(self->Text(self->CurrentState()));
	}
}

Bridge::ScriptObject Bridge::ButtonBridge::setText(CButton* self, const ScriptArray &args)
{
	ScriptObject object = args[0];

	std::string state = object.get("state").asString();
	std::string textContent = object.get("text").asString();

	self->SetText(deserializeState(state, CButton::STATE_NORMAL), textContent);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ButtonBridge::textColor(CButton* self, const ScriptArray &args)
{
	ScriptObject object = args[0];
	std::string state = object.get("state").asString();
	ClutterColor color = self->TextColor(deserializeState(state, CButton::STATE_NORMAL));
	return wrapExistingNativeObject(&color);
}

Bridge::ScriptObject Bridge::ButtonBridge::setTextColor(CButton* self, const ScriptArray &args)
{
	ScriptObject object = args[0];
	std::string state = object.get("state").asString();
	ScriptObject colorObj = object.get("color");

	Color color = ScriptToColor(colorObj);

	self->SetTextColor(deserializeState(state, CButton::STATE_NORMAL), *(color.toClutterColor()));
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ButtonBridge::fontSize(CButton* self, const ScriptArray &args)
{
	ScriptObject object = args[0];
	std::string state = object.get("state").asString();
	return ScriptObject(self->FontSize(deserializeState(state, CButton::STATE_NORMAL)));
}

Bridge::ScriptObject Bridge::ButtonBridge::setFontSize(CButton* self, const ScriptArray &args)
{
	ScriptObject object = args[0];

	std::string state = object.get("state").asString();
	int fontSize = (int)object.get("size").asNumber();

	self->SetFontSize(deserializeState(state, CButton::STATE_NORMAL), fontSize);
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ButtonBridge::backgroundColor(CButton* self, const ScriptArray &args)
{
	ScriptObject object = args[0];
	std::string state = object.get("state").asString();
	ClutterColor color = self->BackgroundColor(deserializeState(state, CButton::STATE_NORMAL));
	return wrapExistingNativeObject(&color);
}

Bridge::ScriptObject Bridge::ButtonBridge::setBackgroundColor(CButton* self, const ScriptArray &args)
{
	ScriptObject object = args[0];
	std::string state = object.get("state").asString();
	ScriptObject colorObj = object.get("color");

	Color color = ScriptToColor(colorObj);

	self->SetBackgroundColor(deserializeState(state, CButton::STATE_NORMAL), *(color.toClutterColor()));
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ButtonBridge::setBackgroundImageAttr(CButton* self, const ScriptArray &args)
{
	CCompositeImage* backgroundImageActor = dynamic_cast<CCompositeImage*>(self->BackGroundImageActor());

	HALO_EXCEPTION(backgroundImageActor != NULL, "API setBackgroundImage should be called before setBackgroundImageAttr!");
	if (backgroundImageActor == NULL)
	{
		return ScriptObject();
	}

	ScriptObject options = args[0];

	if (options.has("x"))
	{
		float x = (float)options.get("x").asNumber();
		backgroundImageActor->setX(x);
	}
	if (options.has("y"))
	{
		float y = (float)options.get("y").asNumber();
		backgroundImageActor->setY(y);
	}
	if (options.has("width"))
	{
		float width = (float)options.get("width").asNumber();
		backgroundImageActor->setWidth(width);
	}
	if (options.has("height"))
	{
		float height = (float)options.get("height").asNumber();
		backgroundImageActor->setHeight(height);
	}
	if (options.has("opacity"))
	{
		int opacity = (int)options.get("opacity").asNumber();
		backgroundImageActor->setOpacity(opacity);
	}

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ButtonBridge::setIconAttr(CButton* self, const ScriptArray &args)
{
	CImage* iconActor = dynamic_cast<CImage*>(self->IconActor());

	HALO_EXCEPTION(iconActor != NULL, "API setIconImage should be called before setIconImageAttr!");
	if (iconActor == NULL)
	{
		return ScriptObject();
	}

	ScriptObject options = args[0];

	if (options.has("x"))
	{
		float x = (float)options.get("x").asNumber();
		iconActor->setX(x);
	}
	if (options.has("y"))
	{
		float y = (float)options.get("y").asNumber();
		iconActor->setY(y);
	}
	if (options.has("width"))
	{
		float width = (float)options.get("width").asNumber();
		iconActor->setWidth(width);
	}
	if (options.has("height"))
	{
		float height = (float)options.get("height").asNumber();
		iconActor->setHeight(height);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ButtonBridge::setTextAttr(CButton* self, const ScriptArray &args)
{
	CText* textActor = dynamic_cast<CText*>(self->TextActor());

	HALO_EXCEPTION(textActor != NULL, "API setText should be called before textActor!");
	if (textActor == NULL)
	{
		return ScriptObject();
	}

	ScriptObject options = args[0];

	if (options.has("x"))
	{
		float x = (float)options.get("x").asNumber();
		textActor->setX(x);
	}
	if (options.has("y"))
	{
		float y = (float)options.get("y").asNumber();
		textActor->setY(y);
	}
	if (options.has("width")) 
	{
		float width = (float)options.get("width").asNumber();
		textActor->setWidth(width);
	}
	if (options.has("height"))
	{
		float height = (float)options.get("height").asNumber();
		textActor->setHeight(height);
	}
	if (options.has("font"))
	{
		std::string font = options.get("font").asString();
		textActor->SetFont(font.c_str());
	}
	std::string hAlignment;
	std::string vAlignment;
	bool flagSetAlign = false;
	if (options.has("hAlign"))
	{
		hAlignment = options.get("hAlign").asString();		
		flagSetAlign = true;
	}
	if (options.has("vAlign"))
	{
		vAlignment = options.get("vAlign").asString();
		flagSetAlign = true;
	}
	if (flagSetAlign)
	{
		textActor->SetTextAlignment(deserializeHAlignment(hAlignment, HALO::HALIGN_CENTER), deserializeVAlignment(vAlignment, HALO::VALIGN_MIDDLE));
	}

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ButtonBridge::iconImage(CButton* self, const ScriptArray &args)
{
	std::string state;

	ScriptObject object = args[0];
	state = object.get("state").asString();
	return ScriptObject(self->IconImage(deserializeState(state, CButton::STATE_NORMAL)));
}

Bridge::ScriptObject Bridge::ButtonBridge::setIconImage(CButton* self, const ScriptArray &args)
{
	ScriptObject object = args[0];
	std::string state = object.get("state").asString();
	std::string imagePath = object.get("src").asString();

	self->SetIconImage(deserializeState(state, CButton::STATE_NORMAL), imagePath);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ButtonBridge::iconAlpha(CButton* self, const ScriptArray &args)
{
	std::string state;

	ScriptObject object = args[0];
	state = object.get("state").asString();
	return ScriptObject(self->IconAlpha(deserializeState(state, CButton::STATE_NORMAL)));
}

Bridge::ScriptObject Bridge::ButtonBridge::setIconAlpha(CButton* self, const ScriptArray &args)
{
	ScriptObject object = args[0];
	std::string state = object.get("state").asString();
	int alpha = (int)object.get("alpha").asNumber();

	self->SetIconAlpha(deserializeState(state, CButton::STATE_NORMAL), alpha);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ButtonBridge::addListener(CButton* self, const ScriptArray &args)
{
	InternalButtonListener *listener = unwrapNativeObject<InternalButtonListener>(args[0]);
	self->AddListener(listener);

	return ScriptObject();
}

Bridge::ScriptObject Bridge::ButtonBridge::removeListener(CButton* self, const ScriptArray &args)
{
	InternalButtonListener *listener = unwrapNativeObject<InternalButtonListener>(args[0]);
	self->RemoveListener(listener);

	return ScriptObject();
}

HALO::EVAlignment Bridge::ButtonBridge::deserializeVAlignment(std::string alignStr, EVAlignment theDefault)
{
	if (compareStrChar(alignStr, "top"))
	{
		return VALIGN_TOP;
	}
	else if (compareStrChar(alignStr, "middle"))
	{
		return VALIGN_MIDDLE;
	}
	else if (compareStrChar(alignStr, "bottom"))
	{
		return VALIGN_BOTTOM;
	}
	else
	{
		HALO_EXCEPTION(false ,"The align string is invalid: " << alignStr);
		return theDefault;
	}
}

Bridge::ScriptObject Bridge::ButtonBridge::setBorder(CButton* self, const ScriptArray &args)
{
	if (!args.isNull())
	{
		ScriptObject options = args[0];
		std::string state;
		CButton::EButtonState stateEnum = self->CurrentState();
		ScriptObject borderAttr;
		float width = 0.0f;
		Color color = Color::Transparent();
		if (options.has("state"))
		{
			state = options.get("state").asString();
			stateEnum = deserializeState(state, CButton::STATE_NORMAL);
		}
		if (options.has("border"))
		{
			borderAttr = options.get("border");
			if (borderAttr.has("width"))
			{
				width = borderAttr["width"].asNumber();
			}
			if (borderAttr.has("color"))
			{
				color = ScriptToColor(borderAttr["color"]);
			}
			
			self->SetBorderWidth(stateEnum, width);
			self->SetBorderColor(stateEnum, *(color.toClutterColor()));
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ButtonBridge::getDefaultBorder(CButton* self)
{
	const std::string name = "border";

	if (hasPropertyProxy(self, name))
	{
		return getPropertyProxy(self, name);
	}

	ScriptObject border = ScriptObject();
	//border.SetAccessor<Widget, getColor<Widget, &Widget::getBorderColor, &Widget::setBorderColor>,
	//	setColor<Widget, &Widget::setBorderColor> >("color", self);
	//border.SetAccessor<Widget,
	//	numberGetter<Widget, float, &Widget::getBorderWidth>,
	//	numberSetter<Widget, float, &Widget::setBorderWidth> >("width", self);

	//addPropertyProxy(self, name, border);
	return border;
}

void Bridge::ButtonBridge::setDefaultBorder(CButton* self, ScriptObject value)
{
	if (value.isNull())
	{
		self->SetBorderColor(CButton::STATE_ALL, *Color::Transparent().toClutterColor());
	}
	else
	{
		float width = value["width"].asNumber();
		Color color = ScriptToColor(value["color"]);
		self->SetBorderColor(CButton::STATE_ALL, *color.toClutterColor());
		self->SetBorderWidth(CButton::STATE_ALL, width);
	}
}


bool Bridge::InternalButtonListener::OnButtonClicked(class IButton* button, EButtonClickType type)
{
	if (true == ButtonClickedCb.flagExist)
	{
		ScriptArray args;
		args.set(0, ActorBridge::wrapNativeObjectToJS(dynamic_cast<CButton*>(button)));
		if (type == IButtonListener::TYPE_MOUSE)
		{
			args.set(1, ScriptObject("mouse"));
		}
		else if (type == IButtonListener::TYPE_RETRUN_KEY)
		{
			args.set(1, ScriptObject("keyboard"));
		}

		ButtonClickedCb.function.invoke(args);
	}
	return true;
}

void Bridge::ButtonListenerBridge::mapScriptInterface(ScriptContext& context)
{
	BaseListenerBridge::mapScriptInterface(context);
	
	context.bindFunction<InternalButtonListener, &InternalButtonListener::GetButtonClickedCallBack, &InternalButtonListener::SetButtonClickedCallBack>("onButtonClicked");
}

void* Bridge::ButtonListenerBridge::constructFromScript(const ScriptArray& args)
{
	return new InternalButtonListener;
}