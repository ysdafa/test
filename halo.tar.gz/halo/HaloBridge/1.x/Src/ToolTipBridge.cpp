#include "HaloBridgeAll.h"

using namespace HALO;
using namespace Bridge;

void Bridge::ToolTipBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);
	context.captureMethodCall<CToolTip, &resize>("resize");
	context.captureMethodCall<CToolTip, &setPopupImage>("setPopupImage");
	context.captureMethodCall<CToolTip, &setTailImage>("setTailImage");
	context.captureMethodCall<CToolTip, &setTailPosition>("setTailPosition");
	context.captureMethodCall<CToolTip, &setTailSize>("setTailSize");
	context.captureMethodCall<CToolTip, &setTailOffset>("setTailOffset");
	context.captureMethodCall<CToolTip, &setText>("setText");
	context.captureMethodCall<CToolTip, &setFont>("setFont");
	context.captureMethodCall<CToolTip, &setFont>("setFontName");
	context.captureMethodCall<CToolTip, &setFontSize>("setFontSize");
	context.captureMethodCall<CToolTip, &setTextColor>("setTextColor");
	context.captureMethodCall<CToolTip, &setTextBackgroundColor>("setTextBackgroundColor");
	context.captureMethodCall<CToolTip, &setFrameWidth>("setFrameWidth");
	context.captureMethodCall<CToolTip, &setFrameColor>("setFrameColor");
	context.captureMethodCall<CToolTip, &setUpTailImage>("setUpTailImage");
	context.captureMethodCall<CToolTip, &setDownTailImage>("setDownTailImage");
	context.captureMethodCall<CToolTip, &setLeftTailImage>("setLeftTailImage");
	context.captureMethodCall<CToolTip, &setRightTailImage>("setRightTailImage");
	context.captureMethodCall<CToolTip, &setShowTime>("setShowTime");

	context.bindNumber<CToolTip, float, &CToolTip::TailOffset, &CToolTip::SetTailOffset>("tailOffset");
	context.bindNumber<CToolTip, int, &CToolTip::FontSize, &CToolTip::SetFontSize>("fontSize");
	context.bindString<CToolTip, &CToolTip::PopupImage, &CToolTip::SetPopupImage>("popupImage");
	context.bindString<CToolTip, &CToolTip::TailImage, &CToolTip::SetTailImage>("tailImage");
	context.bindString<CToolTip, &CToolTip::Text, &CToolTip::SetText>("text");
	context.bindString<CToolTip, &CToolTip::Font, &CToolTip::SetFont>("fontName");
	context.bindString<CToolTip, &CToolTip::UpTailImage, &CToolTip::SetUpTailImage>("upTailImage");
	context.bindString<CToolTip, &CToolTip::DownTailImage, &CToolTip::SetDownTailImage>("downTailImage");
	context.bindString<CToolTip, &CToolTip::LeftTailImage, &CToolTip::SetLeftTailImage>("leftTailImage");
	context.bindString<CToolTip, &CToolTip::RightTailImage, &CToolTip::SetRightTailImage>("rightTailImage");
	context.bindNumber<CToolTip, float, &CToolTip::FrameWidth, &CToolTip::SetFrameWidth>("frameWidth");
	context.bindNumber<CToolTip, guint, &CToolTip::ShowTime, &CToolTip::SetShowTime>("showTime");
}

Widget* Bridge::ToolTipBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	if (width < 0)
	{
		width = 0;
	}
	if (height < 0)
	{
		height = 0;
	}
	CToolTip* tip = dynamic_cast<CToolTip *>(IToolTip::CreateInstance(parent, width, height));
	if (tip == NULL)
	{
		return NULL;
	}
	tip->SetPosition(x, y);
	
	ScriptObject options = args[0];
	Color bgColor = Color(255, 0, 0, 0);
	if (options.has("color"))
	{
		bgColor = ScriptToColor(options.get("color"));
	}
	tip->SetBackgroundColor(*bgColor.toClutterColor());

	if (options.has("popupImage"))
	{
		tip->SetPopupImage(options.get("popupImage").asString().data());
	}
	if (options.has("tailImage"))
	{
		tip->SetTailImage(options.get("tailImage").asString().data());
	}
	if (options.has("upTailImage"))
	{
		tip->SetUpTailImage(options.get("upTailImage").asString().data());
	}
	if (options.has("downTailImage"))
	{
		tip->SetDownTailImage(options.get("downTailImage").asString().data());
	}
	if (options.has("leftTailImage"))
	{
		tip->SetLeftTailImage(options.get("leftTailImage").asString().data());
	}
	if (options.has("rightTailImage"))
	{
		tip->SetRightTailImage(options.get("rightTailImage").asString().data());
	}
	if (options.has("tailWidth"))
	{
		if (options.has("tailHeight"))
		{
			tip->SetTailSize(static_cast<float>(options.get("tailWidth").asNumber()), static_cast<float>(options.get("tailHeight").asNumber()));
		}
	}
	if (options.has("tailSide"))
	{
		if (options.has("tailDistance"))
		{
			if (options.has("tailOffset"))
			{
				tip->SetTailPosition(deserializeSide(options.get("tailSide").asString(), CToolTip::SIDE_DOWN), static_cast<float>(options.get("tailDistance").asNumber()), static_cast<float>(options.get("tailOffset").asNumber()));
			}
			else
			{
				tip->SetTailPosition(deserializeSide(options.get("tailSide").asString(), CToolTip::SIDE_DOWN), static_cast<float>(options.get("tailDistance").asNumber()));
			}
			
		}
		else if (options.has("tailPosition"))
		{
			if (options.has("tailOffset"))
			{
				tip->SetTailPosition(deserializeSide(options.get("tailSide").asString(), CToolTip::SIDE_DOWN), deserializePosition(options.get("tailPosition").asString(), CToolTip::POSITION_START), static_cast<float>(options.get("tailOffset").asNumber()));
			}
			else
			{
				tip->SetTailPosition(deserializeSide(options.get("tailSide").asString(), CToolTip::SIDE_DOWN), deserializePosition(options.get("tailPosition").asString(), CToolTip::POSITION_START));
			}
		}
	}
	if (options.has("text"))
	{
		tip->SetText(options.get("text").asString().data());
	}
	if (options.has("font"))
	{
		tip->SetFont(options.get("font").asString().data());
	}
	if (options.has("fontSize"))
	{
		tip->SetFontSize(static_cast<int>(options.get("fontSize").asNumber()));
	}
	if (options.has("textBackgroundColor"))
	{
		bgColor = ScriptToColor(options.get("textBackgroundColor"));
		tip->SetTextBackgroundColor(*bgColor.toClutterColor());
	}	
	if (options.has("textColor"))
	{
		bgColor = ScriptToColor(options.get("textColor"));
		tip->SetTextColor(*bgColor.toClutterColor());
	}
	if (options.has("frameColor"))
	{
		bgColor = ScriptToColor(options.get("frameColor"));
		tip->SetFrameColor(*bgColor.toClutterColor());
	}
	if (options.has("frameWidth"))
	{
		tip->SetFrameWidth(static_cast<float>(options.get("frameWidth").asNumber()));
	}
	if (options.has("showTime"))
	{
		tip->SetShowTime(static_cast<guint>(options.get("showTime").asNumber()));
	}
	return tip;
}

CToolTip::EToolTipTailPosition Bridge::ToolTipBridge::deserializePosition(std::string stateStr, CToolTip::EToolTipTailPosition theDefault)
{
	if (compareStrChar(stateStr, "start"))
	{
		return CToolTip::POSITION_START;
	}
	else if (compareStrChar(stateStr, "center"))
	{
		return CToolTip::POSITION_CENTER;
	}
	else if (compareStrChar(stateStr, "end"))
	{
		return CToolTip::POSITION_END;
	}
	else
	{
		ASSERT(false && "The state string is invalid!");
		return theDefault;
	}
}

CToolTip::EToolTipTailSide Bridge::ToolTipBridge::deserializeSide(std::string stateStr, CToolTip::EToolTipTailSide theDefault)
{
	if (compareStrChar(stateStr, "up"))
	{
		return CToolTip::SIDE_UP;
	}
	else if (compareStrChar(stateStr, "down"))
	{
		return CToolTip::SIDE_DOWN;
	}
	else if (compareStrChar(stateStr, "left"))
	{
		return CToolTip::SIDE_LEFT;
	}
	else if (compareStrChar(stateStr, "right"))
	{
		return CToolTip::SIDE_RIGHT;
	}
	else
	{
		ASSERT(false && "The state string is invalid!");
		return theDefault;
	}
}

Bridge::ScriptObject Bridge::ToolTipBridge::resize(CToolTip* self, const ScriptArray& args)
{
	if (args.Length() == 2)
	{
		float width = 0, height = 0;
		if (args.has(0) && args[0].isNumber())
		{
			width = static_cast<float>(args[0].asNumber());
		}
		if (args.has(1) && args[1].isNumber())
		{
			height = static_cast<float>(args[1].asNumber());
		}
		self->Resize(width, height);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToolTipBridge::setPopupImage(CToolTip* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		std::string image;
		if (args.has(0) && args[0].isString())
		{
			image = args[0].asString();
		}
		self->SetPopupImage(image.c_str());
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToolTipBridge::setTailImage(CToolTip* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		std::string image;
		if (args.has(0) && args[0].isString())
		{
			image = args[0].asString();
		}
		self->SetTailImage(image.c_str());
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToolTipBridge::setUpTailImage(CToolTip* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		std::string image;
		if (args.has(0) && args[0].isString())
		{
			image = args[0].asString();
		}
		self->SetUpTailImage(image.c_str());
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToolTipBridge::setDownTailImage(CToolTip* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		std::string image;
		if (args.has(0) && args[0].isString())
		{
			image = args[0].asString();
		}
		self->SetDownTailImage(image.c_str());
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToolTipBridge::setLeftTailImage(CToolTip* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		std::string image;
		if (args.has(0) && args[0].isString())
		{
			image = args[0].asString();
		}
		self->SetLeftTailImage(image.c_str());
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToolTipBridge::setRightTailImage(CToolTip* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		std::string image;
		if (args.has(0) && args[0].isString())
		{
			image = args[0].asString();
		}
		self->SetRightTailImage(image.c_str());
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToolTipBridge::setTailPosition(CToolTip* self, const ScriptArray& args)
{
	std::string side;
	std::string position;
	if (args.Length() == 2)
	{
		if (args.has(0) && args[0].isString() && args.has(1) && args[1].isString())
		{
			side = args[0].asString();
			position = args[1].asString();
			self->SetTailPosition(deserializeSide(side, CToolTip::SIDE_DOWN), deserializePosition(position, CToolTip::POSITION_START));
		}
		else if (args.has(0) && args[0].isString() && args.has(1) && args[1].isNumber())
		{
			side = args[0].asString();
			self->SetTailPosition(deserializeSide(side, CToolTip::SIDE_DOWN), static_cast<float>(args[1].asNumber()));
		}
	}
	else if (args.Length() > 2)
	{
		if (args.has(0) && args[0].isString() && args.has(1) && args[1].isString() && args.has(2) && args[2].isNumber())
		{
			side = args[0].asString();
			position = args[1].asString();
			self->SetTailPosition(deserializeSide(side, CToolTip::SIDE_DOWN), deserializePosition(position, CToolTip::POSITION_START), static_cast<float>(args[2].asNumber()));
		}
		else if (args.has(0) && args[0].isString() && args.has(1) && args[1].isNumber() && args.has(2) && args[2].isNumber())
		{
			side = args[0].asString();
			self->SetTailPosition(deserializeSide(side, CToolTip::SIDE_DOWN), static_cast<float>(args[1].asNumber()), static_cast<float>(args[2].asNumber()));
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToolTipBridge::setTailSize(CToolTip* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		if (args.has(0) && args[0].isNumber() && args.has(1) && args[1].isNumber())
		{
			self->SetTailSize(static_cast<float>(args[0].asNumber()), static_cast<float>(args[1].asNumber()));
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToolTipBridge::setTailOffset(CToolTip* self, const ScriptArray& args)
{
	if (args.Length() > 1)
	{
		if (args.has(0) && args[0].isNumber())
		{
			self->SetTailOffset(static_cast<float>(args[0].asNumber()));
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToolTipBridge::setText(CToolTip* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		std::string text;
		if (args.has(0) && args[0].isString())
		{
			text = args[0].asString();
		}
		self->SetText(text.c_str());
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToolTipBridge::setFont(CToolTip* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		std::string font;
		if (args.has(0) && args[0].isString())
		{
			font = args[0].asString();
		}
		self->SetFont(font.c_str());
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToolTipBridge::setFontSize(CToolTip* self, const ScriptArray& args)
{

	if (args.Length() == 1)
	{
		if (args.has(0) && args[0].isNumber())
		{
			self->SetFontSize(static_cast<int>(args[0].asNumber()));
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToolTipBridge::setTextColor(CToolTip* self, const ScriptArray& args)
{
	if (args.Length() == 4)
	{
		guint8 r = 0;
		guint8 g = 0;
		guint8 b = 0;
		guint8 a = 0;

		if (args.has(0) && args[0].isNumber())
		{
			r = (guint8)args[0].asNumber();
		}
		if (args.has(1) && args[1].isNumber())
		{
			g = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			b = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			a = (guint8)args[3].asNumber();
		}
		ClutterColor c = { r, g, b, a };
		self->SetTextColor(c);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToolTipBridge::setTextBackgroundColor(CToolTip* self, const ScriptArray& args)
{
	if (args.Length() == 4)
	{
		guint8 r = 0;
		guint8 g = 0;
		guint8 b = 0;
		guint8 a = 0;

		if (args.has(0) && args[0].isNumber())
		{
			r = (guint8)args[0].asNumber();
		}
		if (args.has(1) && args[1].isNumber())
		{
			g = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			b = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			a = (guint8)args[3].asNumber();
		}
		ClutterColor c = { r, g, b, a };
		self->SetTextBackgroundColor(c);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToolTipBridge::setFrameWidth(CToolTip* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			self->SetFrameWidth(static_cast<float>(args[0].asNumber()));
		}
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToolTipBridge::setFrameColor(CToolTip* self, const ScriptArray& args)
{
	if (args.Length() == 4)
	{
		guint8 r = 0;
		guint8 g = 0;
		guint8 b = 0;
		guint8 a = 0;

		if (args.has(0) && args[0].isNumber())
		{
			r = (guint8)args[0].asNumber();
		}
		if (args.has(1) && args[1].isNumber())
		{
			g = (guint8)args[1].asNumber();
		}
		if (args.has(2) && args[2].isNumber())
		{
			b = (guint8)args[2].asNumber();
		}
		if (args.has(3) && args[3].isNumber())
		{
			a = (guint8)args[3].asNumber();
		}
		ClutterColor c = { r, g, b, a };
		self->SetFrameColor(c);
	}
	return ScriptObject();
}

Bridge::ScriptObject Bridge::ToolTipBridge::setShowTime(CToolTip* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber())
		{
			self->SetShowTime(static_cast<guint>(args[0].asNumber()));
		}
	}
	return ScriptObject();
}