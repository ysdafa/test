#ifndef _GRIDLAYOUT_BRIDGE_H
#define _GRIDLAYOUT_BRIDGE_H

#include <clutter/clutter.h>
#include "ScriptBridge.h"
#include "DataListBridge.h"
#include "Halo.h"

#define DEBUG_TEST		1

using namespace HALO;

namespace Bridge
{
	class GridLayoutListBridge : public virtual DataListBridge, public IGridListControlListener
	#if 1 == DEBUG_TEST
		, public IKeyboardListener
	#endif
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "GridLayoutList";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual IDataListControl* constructSubWidget(IActor* parent, float width, float height, const ScriptArray& args);

		virtual void destroyFromScript(void* destroyedObject);

	public:
		enum E_LISTENER_TYPE
		{
			ITEM_LOAD = 0,
			ITEM_UNLOAD,
			ITEM_ASYNC_LOAD,
			FOCUS_CHANGE_START,
			FOCUS_CHANGE,
			MOVE_OUT,
			ITEM_INDEX_CHANGE
		};
	#if 1 == DEBUG_TEST
		virtual bool OnKeyPressed(IActor* pThis, IKeyboardEvent* event);
	#endif

		virtual bool OnItemLoaded(class IGridListControl* list, int groupIndex, int itemIndex);
		virtual bool OnItemUnloaded(class IGridListControl* list, int groupIndex, int itemIndex);
		virtual bool OnAsyncItemLoad(class IGridListControl *list, int groupIndex, int itemIndex);
		virtual bool OnFocusChanged(class IGridListControl *list, int fromGroupIndex, int fromItemIndex, int toGroupIndex, int toItemIndex);
		virtual bool OnFocusChangeMotionStart(class IGridListControl* list, int fromGroupIndex, int fromItemIndex, int toGroupIndex, int toItemIndex);
		virtual bool OnMoveOut(class IGridListControl* list, EDirection direction, int fromGroupIndex, int fromItemIndex);
		virtual bool OnItemIndexChanged(class IGridListControl* list, int fromGroupIndex, int fromItemIndex, int toGroupIndex, int toItemIndex);

	private:
		// Methods
		static ScriptObject addGroup(IActor* self, const ScriptArray& args);
		static ScriptObject addStyle(IActor* self, const ScriptArray& args);
		static ScriptObject addColumn(IActor* self, const ScriptArray& args);
		static ScriptObject addRowToColumn(IActor* self, const ScriptArray& args);
		static ScriptObject addRowToAllColumn(IActor* self, const ScriptArray& args);
		static ScriptObject mergeCells(IActor* self, const ScriptArray& args);
		static ScriptObject setGroupStyle(IActor* self, const ScriptArray& args);
		static ScriptObject transformStyle(IActor* self, const ScriptArray& args);
		static ScriptObject transformAllGroupStyle(IActor* self, const ScriptArray& args);
		static ScriptObject m_EnlargeFocusItem(IActor* self, const ScriptArray& args);
		static ScriptObject setFocusItemIndex(IActor* self, const ScriptArray& args);
		static ScriptObject setAnimationDuration(IActor* self, const ScriptArray& args);

		static ScriptObject addDataGroup(IActor* self, const ScriptArray& args);
		static ScriptObject addData(IActor* self, const ScriptArray& args);
		static ScriptObject getData(IActor* self, const ScriptArray& args);

		static ScriptObject moveFocus(IActor* self, const ScriptArray& args);
	};
}

#endif