#ifndef _ACTORPROXY_H_
#define _ACTORPROXY_H_

#include "Widget.h"
//#include "ActorMessages.h"

using namespace HALO;

class ActorProxy :virtual public IActor
{
protected:
	RemotePtr<ActorGraphics> graphics;
public:
	ActorProxy();
//	virtual bool Initialize(ActorProxy* parent, float width, float height);

	virtual bool Initialize(IActor* parent, float width, float height);

	virtual bool Initialize(IActor* parent, TWindowAttr *attr);

	virtual bool Initialize(void);

	virtual void SetBackgroundColor(guint8 r, guint8 g, guint8 b, guint8 a);
	virtual void Show(void);
	virtual void Hide(void);
	void SetPosition(float x, float y, float z);

	virtual void SetPosition(float x, float y);

	virtual bool Raise(IActor* sibling);

	virtual bool Lower(IActor* sibling);

	void Enable(bool flagEnable);
	void EnableFocus(bool flagFocusable);
	void EnablePointerFocus(bool enable);
	bool SetFocus(void);

	virtual void SetParent(IActor* parent);

	virtual IActor* Parent(void) const;

	virtual void SetBackgroundColor(const ClutterColor &color);

	virtual void Resize(float width, float height);

	virtual void GetSize(float &width, float &height);

	virtual void GetPosition(float &x, float &y, float &z);

	virtual void GetPosition(float &x, float &y);

	virtual bool SetLayout(ILayout* layout);

	virtual ILayout* Layout(void);

	virtual void SetOrientation(EOrientation orientation);

	virtual EOrientation Orientation(bool flagReferParent);

	virtual bool FlagShow(void);

	virtual void SetClipArea(float x, float y, float width, float height);

	virtual void GetClipArea(float &x, float &y, float &width, float &height);

	virtual void RemoveClipArea(void);

	virtual bool FlagClip(void);

	virtual void SetAlpha(int alpha);

	virtual int Alpha(void);

	virtual void SetPivotPoint(float xPivot, float yPivot, float zPivot);

	virtual void GetPivotPoint(float &xPivot, float &yPivot, float &zPivot);

	virtual void SetRotation(double xAngle, double yAngle, double zAngle);

	virtual void GetRotation(double &xAngle, double &yAngle, double &zAngle);

	virtual void SetScale(double xFactor, double yFactor, double zFactor);

	virtual void GetScale(double &xFactor, double &yFactor, double &zFactor);

	virtual void AddEffect(IEffect* effect);

	virtual void RemoveEffect(IEffect* effect);

	virtual void ClearEffects(void);

	virtual void AddChild(ClutterActor *actor);

	virtual void AddChild(Widget* widget);
	virtual int NumOfChildren(void);

	virtual IActor* GetChild(int index);

	virtual void DestroyAllChildren(void);

	virtual bool IsEnabled(void);

	virtual bool IsPointerFocusEnabled(void);

	virtual bool IsFocusEnabled(void);

	virtual bool KillFocus(bool autoFocus = true);

	virtual bool IsFocused(void);

	virtual void SetTabWindow(EDirection dir, IActor* tabWindow);

	virtual IActor* TabWindow(EDirection dir);

	virtual bool MoveTab(EDirection dir);

	virtual void EnableDragDrop(bool flagEnable);

	virtual bool FlagDragDrop(void);

	virtual void GrabDeviceEvent(IDevice* device);

	virtual void UnGrabDeviceEvent(IDevice* device);

	virtual bool FlagAcceptInput(void);

	virtual bool AddFocusListener(IFocusListener* pListener);

	virtual bool RemoveFocusListener(IFocusListener* pListener);

	virtual bool AddMouseListener(IMouseListener* pAddListener);

	virtual bool RemoveMouseListener(IMouseListener* pRemoveListener);

	virtual bool AddTouchListener(ITouchListener* pAddListener);

	virtual bool RemoveTouchListener(ITouchListener* pRemoveListener);

	virtual bool AddKeyboardListener(IKeyboardListener* pAddListener);

	virtual bool RemoveKeyboardListener(IKeyboardListener* pRemoveListener);

	virtual bool AddAudioListener(IAudioListener* pAddListener);

	virtual bool RemoveAudioListener(IAudioListener* pRemoveListener);

	virtual bool AddRemoteControlListener(IRemoteControlListener* pAddListener);

	virtual bool RemoveRemoteControlListener(IRemoteControlListener* pRemoveListener);

	virtual bool AddRidgeListener(IRidgeListener* pAddListener);

	virtual bool RemoveRidgeListener(IRidgeListener* pRemoveListener);

	virtual bool AddCursorStateChangeListener(ICursorListener* pAddListener);

	virtual bool RemoveCursorStateChangeListener(ICursorListener* pRemoveListener);

	virtual bool AddClickListener(IClickListener* pAddListener);

	virtual bool RemoveClickListener(IClickListener* pRemoveListener);

	virtual bool AddSemanticEventListener(ISemanticEventListener* pAddListener);

	virtual bool RemoveSemanticEventListener(ISemanticEventListener* pRemoveListener);

	virtual bool AddAction(IAction* pAction);

	virtual bool RemoveAction(IAction* pAction);

	virtual bool AddDragListener(IDragListener* pAddListener);

	virtual bool RemoveDragListener(IDragListener* pRemoveListener);

	virtual bool AddGestureListener(IGestureListener* pAddListener);

	virtual bool RemoveGestureListener(IGestureListener* pRemoveListener);

	virtual bool AddKeyLongPressListener(IKeyLongPressListener* pAddListener);

	virtual bool RemoveKeyLongPressListener(IKeyLongPressListener* pRemoveListener);

	virtual bool AddKeyCombinationListener(IKeyCombinationListener* pAddListener);

	virtual bool RemoveKeyCombinationListener(IKeyCombinationListener* pRemoveListener);

	virtual bool BindTransition(ITransition *transition, int animationType);

	virtual bool IsInitialized(void) const;

	virtual ClutterActor* Actor(void) { ASSERT("GetActor in ActorProxy NOT SUPPORT!"); return NULL;}
private:

};

#endif //_ACTORPROXY_H_
