#ifndef _TRANSITIONLISTENER_STUB_H_
#define _TRANSITIONLISTENER_STUB_H_

using namespace HALO;

DEFINE_MSG_TYPE_BEGIN(TransitionListenerMsg); //TODO: Something is wrong with the group sorting.
ADD_MSG_TYPE(TransitionListenerMsg, M_Create, Groups::CTransitionListener(), 1);
ADD_MSG_TYPE(TransitionListenerMsg, M_OnNewFrame, Groups::CTransitionListener(), 2);
ADD_MSG_TYPE(TransitionListenerMsg, M_OnStarted, Groups::CTransitionListener(), 3);
ADD_MSG_TYPE(TransitionListenerMsg, M_OnPaused, Groups::CTransitionListener(), 4);
ADD_MSG_TYPE(TransitionListenerMsg, M_OnCompleted, Groups::CTransitionListener(), 5);
ADD_MSG_TYPE(TransitionListenerMsg, M_OnStoped, Groups::CTransitionListener(), 6);
DEFINE_MSG_TYPE_END(TransitionListenerMsg);

class TransitionListenerMessages : VoltMessageReceiver
{
public:
	static TransitionListenerMessages& getInstance() { return s_transListenerInst; }
	virtual void registerMessages();

private:
	static TransitionListenerMessages s_transListenerInst;
};

class TransitionListenerProxy : public ITimeLineListener
{
public:
	virtual void OnNewFrame1(RemotePtr<ITimeLine> animation, double currentProgress, int data);

	virtual void OnStarted1(RemotePtr<ITimeLine> animation, int data);

	virtual void OnPaused1(RemotePtr<ITimeLine> animation, int data);

	virtual void OnCompleted1(RemotePtr<ITimeLine> animation, int data);

	virtual void OnStoped1(RemotePtr<ITimeLine> animation, bool flagFinished, int data);
};

#endif //_TRANSITIONLISTENER_STUB_H_
