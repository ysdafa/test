#ifndef _ACTORMESSAGES_H_
#define _ACTORMESSAGES_H_

#include "WidgetGraphics.h"
//#include "TestActorGraphics.h"


DEFINE_MSG_TYPE_BEGIN(ActorMsg); //TODO: Something is wrong with the group sorting.
ADD_MSG_TYPE(ActorMsg, M_Create, Groups::CActor(), 1);
ADD_MSG_TYPE(ActorMsg, M_Initialize, Groups::CActor(), 2);
ADD_MSG_TYPE(ActorMsg, M_SetBackground, Groups::CActor(), 3);
ADD_MSG_TYPE(ActorMsg, M_Show, Groups::CActor(), 4);
ADD_MSG_TYPE(ActorMsg, M_Hide, Groups::CActor(), 5);
ADD_MSG_TYPE(ActorMsg, M_SetPosition, Groups::CActor(), 6);
ADD_MSG_TYPE(ActorMsg, M_GetPosition, Groups::CActor(), 7);
//ADD_MSG_TYPE(ActorMsg, M_AddChild, Groups::CActor(), 8);
ADD_MSG_TYPE(ActorMsg, M_Raise, Groups::CActor(), 9);
ADD_MSG_TYPE(ActorMsg, M_Lower, Groups::CActor(), 10);
ADD_MSG_TYPE(ActorMsg, M_Enable, Groups::CActor(), 11);
ADD_MSG_TYPE(ActorMsg, M_EnableFocus, Groups::CActor(), 12);
ADD_MSG_TYPE(ActorMsg, M_EenablePointerFocus, Groups::CActor(), 13);
ADD_MSG_TYPE(ActorMsg, M_SetFocus, Groups::CActor(), 14);
ADD_MSG_TYPE(ActorMsg, M_SetClipArea, Groups::CActor(), 15);
ADD_MSG_TYPE(ActorMsg, M_SetScale, Groups::CActor(), 16);
ADD_MSG_TYPE(ActorMsg, M_SetRotation, Groups::CActor(), 17);
ADD_MSG_TYPE(ActorMsg, M_AddChild, Groups::CActor(), 18);
ADD_MSG_TYPE(ActorMsg, M_IsInitialized, Groups::CActor(), 19);
ADD_MSG_TYPE(ActorMsg, M_BindTransition, Groups::CActor(), 20);
ADD_MSG_TYPE(ActorMsg, M_SetSize, Groups::CActor(), 21);
ADD_MSG_TYPE(ActorMsg, M_SetPivotPoint, Groups::CActor(), 22);
ADD_MSG_TYPE(ActorMsg, M_GetSize, Groups::CActor(), 23);
ADD_MSG_TYPE(ActorMsg, M_SetAlpha, Groups::CActor(), 24);
ADD_MSG_TYPE(ActorMsg, M_GetAlpha, Groups::CActor(), 25);
ADD_MSG_TYPE(ActorMsg, M_FlagShow, Groups::CActor(), 26);
ADD_MSG_TYPE(ActorMsg, M_SetOrientation, Groups::CActor(), 27);
ADD_MSG_TYPE(ActorMsg, M_GetOrientation, Groups::CActor(), 28);
ADD_MSG_TYPE(ActorMsg, M_SetParent, Groups::CActor(), 29);


//ADD_MSG_DEF_TYPE(ActorMsg, End, 3);
DEFINE_MSG_TYPE_END(ActorMsg);

class ActorMessages : VoltMessageReceiver
{
public:
	static ActorMessages& getInstance() { return s_wgm; }
	virtual void registerMessages();

private:
	static ActorMessages s_wgm;

};

#endif //_ACTORMESSAGES_H_
