#ifndef _DATALIST_BRIDGE_H
#define _DATALIST_BRIDGE_H

#include <clutter/clutter.h>
#include "ScriptBridge.h"
#include "ActorBridge.h"
#include "Halo.h"

using namespace HALO;

namespace Bridge
{
	class DataListBridge : public virtual ActorBridge, public IRendererProvider
	{
	protected:
		ScriptFunction t_listListenerCallback;

		IRenderer* GetRenderer(IData *data, IActor* parent);

		virtual void mapScriptInterface(ScriptContext& context);

		virtual IActor* constructWidget(IActor* parent, float width, float height, const ScriptArray& args);

		virtual IDataListControl* constructSubWidget(IActor* parent, float width, float height, const ScriptArray& args) = 0;

	public:

	private:
		ScriptFunction m_renderCallback;

		// Methods
		static ScriptObject loadData(IActor* self, const ScriptArray& args);

		static ScriptObject enlargeFocusedItem(IActor* self, const ScriptArray& args);
		
		static ScriptObject moveFocus(IActor* self, const ScriptArray& args);

		static ScriptObject showFocus(IActor* self, const ScriptArray& args);

		static ScriptObject hideFocus(IActor* self, const ScriptArray& args);

		static ScriptObject setRenderWidget(IActor* self, const ScriptArray& args);
		static ScriptObject setRenderActor(IActor* self, const ScriptArray& args);
	};
}

#endif