#ifndef _ACTORBRIDGE_H
#define _ACTORBRIDGE_H

#include <clutter/clutter.h>
#include "ScriptBridge.h"
//#include "Halo.h"
#include "ActorProxy.h"
using namespace HALO;

namespace Bridge
{
	class ActorBridge : public virtual ScriptBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "Actor";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);
		//virtual ActorProxy* constructSubAnimatable(const ScriptArray& args);

		virtual inline void destroyFromScript(void* destroyedObject)
		{
		}

		virtual IActor* constructWidget(IActor* parent, float width, float height, const ScriptArray& args);

	public:
		ActorBridge()
		{
			allowGarbageCollection = false;
		}

	private:

		// Methods
		static ScriptObject setParent(IActor* self, const ScriptArray& args);
		static ScriptObject setBackgroundColor(IActor* self, const ScriptArray& args);
		static ScriptObject setSize(IActor* self, const ScriptArray& args);
		static ScriptObject setPositon(IActor* self, const ScriptArray& args);
		static ScriptObject setLayout(IActor* self, const ScriptArray& args);
		static ScriptObject setOrientation(IActor* self, const ScriptArray& args);
		

		static ScriptObject show(IActor* self, const ScriptArray& args);
		static ScriptObject hide(IActor* self, const ScriptArray& args);

		static ScriptObject setClipArea(IActor* self, const ScriptArray& args);
		static ScriptObject removeClipArea(IActor* self, const ScriptArray& args);
		static ScriptObject setAlpha(IActor* self, const ScriptArray& args);
		static ScriptObject setPivotPoint(IActor* self, const ScriptArray& args);
		static ScriptObject setRotation(IActor* self, const ScriptArray& args);
		static ScriptObject setScale(IActor* self, const ScriptArray& args);
		static ScriptObject addChild(IActor* self, const ScriptArray& args);
		static ScriptObject numOfChildren(IActor* self, const ScriptArray& args);
		static ScriptObject destroyAllChildren(IActor* self, const ScriptArray& args);
		static ScriptObject raise(IActor* self, const ScriptArray& args);
		static ScriptObject lower(IActor* self, const ScriptArray& args);
		static ScriptObject enable(IActor* self, const ScriptArray& args);
		static ScriptObject enableFocus(IActor* self, const ScriptArray& args);
		static ScriptObject enablePointerFocus(IActor* self, const ScriptArray& args);
		static ScriptObject setFocus(IActor* self, const ScriptArray& args);
		static ScriptObject setTabWindow(IActor* self, const ScriptArray& args);
		static ScriptObject moveTab(IActor* self, const ScriptArray& args);
		
		
		static ScriptObject addMouseListener(IActor* self, const ScriptArray& args);
		static ScriptObject addKeyboardListener(IActor* self, const ScriptArray& args);
		static ScriptObject addClickListener(IActor* self, const ScriptArray& args);
		static ScriptObject addKeyLongPressListener(IActor* self, const ScriptArray& args);
		static ScriptObject addFocusListener(IActor* self, const ScriptArray& args);

		static ScriptObject bindTransition(IActor* self, const ScriptArray& args);
	};
}

#endif