#ifndef _HALOIMAGEBRIDGE_H
#define _HALOIMAGEBRIDGE_H

//#include <iostream>
#include "ScriptTypes.h"
#include "ActorBridge.h"
#include "IImage.h"

namespace Bridge
{
	class HaloImageBridge : public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "HaloImage";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual HALO::IActor* constructWidget(HALO::IActor* parent, float width, float height, const ScriptArray& args);
	private:
		static ScriptObject setImage(IActor* self, const ScriptArray& args);
	};
}

#endif