#ifndef _TRANSITIONPROXY_H_
#define _TRANSITIONPROXY_H_

#include "Widget.h"
#include "TransitionMessages.h"

using namespace HALO;

class TransitionProxy : virtual public ITransition
{
protected:
	RemotePtr<TransitionGraphics> graphics;
public:
	TransitionProxy();
	virtual bool Initialize(bool flagCustomAnimation);

	virtual bool Initialize(void);

	virtual void SetDuration(int duration);

	int Duration(void);

	virtual void SetMode(ClutterAnimationMode animationMode);

	virtual void Play(void);

	virtual void SetDestination_New(int destValue);

	virtual void SetDestination_New(float destValue);

	virtual void SetDestination_New(float destValue1, float destValue2);

	virtual void AddListener(ITimeLineListener *listener, void *userData);

	virtual void RemoveListener(ITimeLineListener *listener, void* &userData);

	virtual void Stop(void);

	virtual void Pause(void);

	virtual bool IsInitialized(void) const;

	RemotePtr<TransitionGraphics> GetGraphics() {return graphics;}

	virtual bool IsPlaying(void);

private:

};

class Transition1iProxy : virtual public ITransition1i, public TransitionProxy
{
protected:
	RemotePtr<Transition1iGraphics> trans1iGraphics;
public:
	Transition1iProxy();

	void SetDestination(int destValue);
};

class Transition1fProxy : virtual public ITransition1f, public TransitionProxy
{
protected:
	RemotePtr<Transition1fGraphics> trans1fGraphics;
public:
	Transition1fProxy();

	void SetDestination(float destValue);
};

class Transition2fProxy : virtual public ITransition2f, public TransitionProxy
{
protected:
	RemotePtr<Transition2fGraphics> trans2fGraphics;
public:
	Transition2fProxy();

	void SetDestination(float destValue, float destValue2);
};

#endif //_TRANSITIONPROXY_H_
