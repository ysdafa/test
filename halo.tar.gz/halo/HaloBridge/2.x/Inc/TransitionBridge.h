#ifndef _TRANSITION_BRIDGE_H
#define _TRANSITION_BRIDGE_H

#include <clutter/clutter.h>
#include "ScriptBridge.h"
#include "Halo.h"
using namespace HALO;

namespace Bridge
{
	class TransitionBridge : public ScriptBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "Transition";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);

		virtual inline void destroyFromScript(void* destroyedObject)
		{
			ITransition* trans = reinterpret_cast<ITransition*>(destroyedObject);
			delete trans;
		}

	public:

	private:
		static ScriptObject m_SetDuration(ITransition* self, const ScriptArray& args);
		static ScriptObject m_SetDestination(ITransition* self, const ScriptArray& args);
		static ScriptObject m_Play(ITransition* self, const ScriptArray& args);
	};
}

#endif