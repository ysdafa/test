#ifndef _TRANSITION_GRAPHICS_H_
#define _TRANSITION_GRAPHICS_H_

class TransitionGraphics : virtual public ITransition, public ITimeLineListener
{
	friend class ActorGraphics;
public:
	TransitionGraphics(void);
	~TransitionGraphics(void);

	virtual bool Initialize(bool flagCustomAnimation);

	virtual bool Initialize(void);

	virtual void SetDuration(int duration);

	virtual int Duration(void);

	virtual void SetMode(ClutterAnimationMode animationMode);

	virtual void AddListener(ITimeLineListener *listener, void *userData);
	virtual void AddListener(RemotePtr<TransitionListenerProxy> listener, int userData);

	virtual void RemoveListener(ITimeLineListener *listener, void* &userData);
	virtual int RemoveListener(RemotePtr<TransitionListenerProxy> listener);


	virtual bool IsPlaying(void);

	virtual void Play(void);

	virtual void Stop(void);

	virtual void Pause(void);

	virtual bool IsInitialized(void) const;

	virtual void SetDestination_New(int destValue);

	virtual void SetDestination_New(float destValue);

	virtual void SetDestination_New(float destValue1, float destValue2);

	virtual bool OnNewFrame(class ITimeLine *animation, double currentProgress, void *data);

	virtual bool OnStarted(class ITimeLine *animation, void *data);

	virtual bool OnPaused(class ITimeLine *animation, void *data);

	virtual bool OnCompleted(class ITimeLine *animation, void *data);

	virtual bool OnStoped(class ITimeLine *animation, bool flagFinished, void *data);

protected:
	CTransitionBase* t_realTransition;

private:
	struct TListenerProxyData
	{
		RemotePtr<TransitionListenerProxy> p;
		int data;
	};

	std::list<TListenerProxyData> m_listenerProxyMap;


	enum ETimeLineListenerType
	{
		EVENT_COMPLETED = 0,
		EVENT_STARTED,
		EVENT_PAUSED,
		EVENT_STOPPED,
		EVENT_NEWFRAME,
		EVENT_MARKER_REACHED
	};
	void m_CallListener(ETimeLineListenerType type, void *data = NULL);
};

class Transition1iGraphics : virtual public ITransition1i, public TransitionGraphics
{
public:
	Transition1iGraphics(void)
	{
		if (t_realTransition != NULL)
		{
			delete t_realTransition;
		}
		t_realTransition = new CTransition1i;
	}

	~Transition1iGraphics(void)
	{
	}

	virtual void SetDestination(int destValue);
};
class Transition1fGraphics : virtual public ITransition1f, public TransitionGraphics
{
public:
	Transition1fGraphics(void)
	{
		if (t_realTransition != NULL)
		{
			delete t_realTransition;
		}
		t_realTransition = new CTransition1f;
	}

	~Transition1fGraphics(void)
	{
	}

	virtual void SetDestination(float destValue);

};
class Transition2fGraphics : virtual public ITransition2f, public TransitionGraphics
{
public:
	Transition2fGraphics(void)
	{
		if (t_realTransition != NULL)
		{
			delete t_realTransition;
		}
		t_realTransition = new CTransition2f;
	}

	~Transition2fGraphics(void)
	{
	}

	virtual void SetDestination(float destValue1, float destValue2);

};

#endif //_TRANSITION_GRAPHICS_H_
