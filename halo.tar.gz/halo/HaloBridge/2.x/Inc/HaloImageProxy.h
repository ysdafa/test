#ifndef _HALOIMAGEPROXY_H_
#define _HALOIMAGEPROXY_H_

//using namespace HALO;

class HaloImageProxy : virtual public IImage, public ActorProxy
{
protected:
	RemotePtr<HaloImageGraphics> imageGraphics;
public:
	HaloImageProxy();

	virtual void SetImage(const char *imagePath);

	virtual void SetImage(IImageBuffer *buffer);

	virtual IImageBuffer* ImageBuffer(void);

	virtual void SetGravity(ClutterContentGravity gravity);

	virtual ClutterContentGravity Gravity(void);

private:

};

#endif //_IMAGEPROXY_H_