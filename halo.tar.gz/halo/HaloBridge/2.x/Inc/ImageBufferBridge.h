#ifndef _IMAGEBUFFERBRIDGE_H
#define _IMAGEBUFFERBRIDGE_H

#include "ScriptBridge.h"
#include "Halo.h"
using namespace HALO;

namespace Bridge
{
	class ImageBufferBridge : public virtual ScriptBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "ImageBuffer";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);

		virtual inline void destroyFromScript(void* destroyedObject)
		{
			IImageBuffer* buffer = reinterpret_cast<IImageBuffer*>(destroyedObject);
			delete buffer;
		}

		virtual IImageBuffer* constructWidget(const ScriptArray& args);

	public:
		ImageBufferBridge()
		{
			allowGarbageCollection = false;
		}

	private:

		// Methods
		static ScriptObject Initialize(IImageBuffer* self, const ScriptArray& args);
		static ScriptObject clone(IImageBuffer* self, const ScriptArray& args);
	};
}

#endif
