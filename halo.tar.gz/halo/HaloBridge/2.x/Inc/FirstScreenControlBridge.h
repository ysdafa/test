#ifndef _FIRSTSCRENNLISTCONTROL_H
#define _FIRSTSCRENNLISTCONTROL_H

#include <clutter/clutter.h>
#include "ScriptBridge.h"
#include "DataListBridge.h"
#include "IFirstScreenControl.h"
#include "Halo.h"

using namespace HALO;

namespace Bridge
{
	class FirstScreenControlBridge : public virtual DataListBridge, public IFirstScreenListListener
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "FirstScreenControl";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void destroyFromScript(void* destroyedObject);

		virtual IDataListControl* constructSubWidget(IActor* parent, float width, float height, const ScriptArray& args);

		//Listener call back from control.
		virtual bool OnMainMenuItemLoaded(class IFirstScreenListControl* list, int mainMenuIndex);
		virtual bool OnScrollListItemLoaded(class IFirstScreenListControl* list, int mainMenuIndex, int scrollDataIndex);
		virtual bool OnSubMenuItemLoaded(class IFirstScreenListControl* list, int mainMenuIndex, int subMenuIndex);

	public:
		FirstScreenControlBridge()
		{
		}

		enum E_LISTENER_TYPE
		{
			MAIN_ITEM_LOAD = 0,
			MAIN_ITEM_UNLOAD,
			MAIN_ITEM_ASYNC_LOAD,
			SUB_ITEM_LOAD,
			SUB_ITEM_UNLOAD,
			SUB_ITEM_ASYNC_LOAD,
			SCROLL_ITEM_LOAD,
			SCROLL_ITEM_UNLOAD,
			SCROLL_ITEM_ASYNC_LOAD,
			FOCUS_CHANGE_START,
			FOCUS_CHANGE,
			MOVE_OUT,
			ITEM_INDEX_CHANGE
		};

	private:

		// Methods
		static ScriptObject m_AddMainMenuItem(IActor* self, const ScriptArray& args);

		static ScriptObject m_AddSubItem(IActor* self, const ScriptArray& args);
		static ScriptObject m_SetScrollItemNumber(IActor* self, const ScriptArray& args);

		static ScriptObject m_ExpandMainMenu(IActor* self, const ScriptArray& args);
		static ScriptObject m_ShrinkMainMenu(IActor* self, const ScriptArray& args);

		static ScriptObject m_SetMaxMargin(IActor* self, const ScriptArray& args);

		static ScriptObject m_SetExpandAnimationDuration(IActor* self, const ScriptArray& args);

		static ScriptObject m_SetScrollSpeed(IActor* self, const ScriptArray& args);

		static ScriptObject m_AddMainMenuData(IActor* self, const ScriptArray& args);
		static ScriptObject m_AddSubMenuData(IActor* self, const ScriptArray& args);
		static ScriptObject m_AddScrollMenuData(IActor* self, const ScriptArray& args);

		static ScriptObject m_MainMenuData(IActor* self, const ScriptArray& args);
		static ScriptObject m_SubMenuData(IActor* self, const ScriptArray& args);
		static ScriptObject m_ScrollMenuData(IActor* self, const ScriptArray& args);

		static ScriptObject m_SetFocusRange(IActor* self, const ScriptArray& args);
	};
}

#endif