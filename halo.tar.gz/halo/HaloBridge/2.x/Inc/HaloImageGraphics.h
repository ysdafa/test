#ifndef _HALO_IMAGE_GRAPHICS_H_
#define _HALO_IMAGE_GRAPHICS_H_


DEFINE_MSG_TYPE_BEGIN(HaloImageMsg); //TODO: Something is wrong with the group sorting.
ADD_MSG_TYPE(HaloImageMsg, M_Create, Groups::CImage(), 1);
ADD_MSG_TYPE(HaloImageMsg, M_SetImage, Groups::CImage(), 2);
ADD_MSG_TYPE(HaloImageMsg, M_GetImageBuf, Groups::CImage(), 3);

DEFINE_MSG_TYPE_END(HaloImageMsg);

class HaloImageMessages : VoltMessageReceiver
{
public:
	static HaloImageMessages& getInstance() { return s_wgm; }
	virtual void registerMessages();

private:
	static HaloImageMessages s_wgm;

};


class HaloImageGraphics : virtual public IImage, public ActorGraphics
{
public:
	HaloImageGraphics(void);
	~HaloImageGraphics(void);

	virtual void SetImage(const char *imagePath);

	virtual void SetImage(IImageBuffer *buffer);

	virtual void SetImage(RemotePtr<CImageBuffer> buffer);

	virtual IImageBuffer* ImageBuffer(void);

	//virtual RemotePtr<IImageBuffer> ImageBuffer(void);

	virtual void SetGravity(ClutterContentGravity gravity);

	virtual ClutterContentGravity Gravity(void);

protected:
	CImage* t_realImage;
};

#endif //_HALO_IMAGE_GRAPHICS_H_