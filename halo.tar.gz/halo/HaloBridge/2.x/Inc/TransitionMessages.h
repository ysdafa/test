#ifndef _TRANSITIONMESSAGES_H_
#define _TRANSITIONMESSAGES_H_

#include "Halo1_0.h"
#include "WidgetGraphics.h"


DEFINE_MSG_TYPE_BEGIN(TransitionMsg); //TODO: Something is wrong with the group sorting.
ADD_MSG_TYPE(TransitionMsg, M_Create, Groups::CTransitionBase(), 1);
ADD_MSG_TYPE(TransitionMsg, M_Initialize, Groups::CTransitionBase(), 2);
ADD_MSG_TYPE(TransitionMsg, M_SetDuration, Groups::CTransitionBase(), 3);
ADD_MSG_TYPE(TransitionMsg, M_SetMode, Groups::CTransitionBase(), 4);
ADD_MSG_TYPE(TransitionMsg, M_Play, Groups::CTransitionBase(), 5);
ADD_MSG_TYPE(TransitionMsg, M_AddListener, Groups::CTransitionBase(), 6);
ADD_MSG_TYPE(TransitionMsg, M_RemoveListener, Groups::CTransitionBase(), 7);
ADD_MSG_TYPE(TransitionMsg, M_GetDuration, Groups::CTransitionBase(), 8);
ADD_MSG_TYPE(TransitionMsg, M_SetDurationNew1i, Groups::CTransitionBase(), 9);
ADD_MSG_TYPE(TransitionMsg, M_SetDurationNew1f, Groups::CTransitionBase(), 10);
ADD_MSG_TYPE(TransitionMsg, M_SetDurationNew2f, Groups::CTransitionBase(), 11);
ADD_MSG_TYPE(TransitionMsg, M_IsPlaying, Groups::CTransitionBase(), 12);

DEFINE_MSG_TYPE_END(TransitionMsg);

DEFINE_MSG_TYPE_BEGIN(Trans1iMsg); //TODO: Something is wrong with the group sorting.
ADD_MSG_TYPE(Trans1iMsg, M_Create, Groups::CTransition1i(), 1);
ADD_MSG_TYPE(Trans1iMsg, M_SetDestination, Groups::CTransition1i(), 2);
DEFINE_MSG_TYPE_END(Trans1iMsg);

DEFINE_MSG_TYPE_BEGIN(Trans1fMsg); //TODO: Something is wrong with the group sorting.
ADD_MSG_TYPE(Trans1fMsg, M_Create, Groups::CTransition1f(), 1);
ADD_MSG_TYPE(Trans1fMsg, M_SetDestination, Groups::CTransition1f(), 2);
DEFINE_MSG_TYPE_END(Trans1fMsg);

DEFINE_MSG_TYPE_BEGIN(Trans2fMsg); //TODO: Something is wrong with the group sorting.
ADD_MSG_TYPE(Trans2fMsg, M_Create, Groups::CTransition2f(), 1);
ADD_MSG_TYPE(Trans2fMsg, M_SetDestination, Groups::CTransition2f(), 2);
DEFINE_MSG_TYPE_END(Trans2fMsg);

#if 0
DEFINE_MSG_TYPE_BEGIN(AnimatableMsg); //TODO: Something is wrong with the group sorting.
//ADD_MSG_TYPE(AnimatableMsg, M_Create, Groups::CAnimatable(), 1);
ADD_MSG_TYPE(AnimatableMsg, M_BindTransition, Groups::CAnimatable(), 2);
DEFINE_MSG_TYPE_END(AnimatableMsg);
#endif

class TransitionMessages : VoltMessageReceiver
{
public:
	static TransitionMessages& getInstance() { return s_transInst; }
	virtual void registerMessages();

private:
	static TransitionMessages s_transInst;
};

class CTransition1iMessages : VoltMessageReceiver
{
public:
	static CTransition1iMessages& getInstance() { return s_trans1iInst; }
	virtual void registerMessages();

private:
	static CTransition1iMessages s_trans1iInst;
};

class CTransition1fMessages : VoltMessageReceiver
{
public:
	static CTransition1fMessages& getInstance() { return s_trans1fInst; }
	virtual void registerMessages();

private:
	static CTransition1fMessages s_trans1fInst;
};

class CTransition2fMessages : VoltMessageReceiver
{
public:
	static CTransition2fMessages& getInstance() { return s_trans2fInst; }
	virtual void registerMessages();

private:
	static CTransition2fMessages s_trans2fInst;
};

#if 0
class AnimatableMessages : VoltMessageReceiver
{
public:
	static AnimatableMessages& getInstance() { return s_aniInst; }
	virtual void registerMessages();

private:
	static AnimatableMessages s_aniInst;

};
#endif

#endif //_TRANSITIONMESSAGES_H_
