#ifndef _RENDER_BRIDGE_H
#define _RENDER_BRIDGE_H

#include "ScriptBridge.h"
#include "Halo.h"

using namespace HALO;

namespace Bridge
{
	enum E_CALLBACK_TYPE
	{
		DRAW_CALLBACK = 0,
		UPDATE_CALLBACK,
		RESIZE_CALLBACK
	};

	class InternalRender : public IRenderer
	{
	public:
		InternalRender(class RenderBridge *owner) : m_owner(owner) {};
		virtual void Draw(IData *data, IActor* parent, E_DRAW_TYPE drawType);
		virtual void Update(IData *data, IActor* parent);
		virtual void Resize(IData *data, IActor* parent, ClutterSize destSize, bool flagAni, int animationDuration);

	private:
		class RenderBridge *m_owner;
	};

	class RenderBridge : public virtual ScriptBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "Render";}
		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);

		virtual inline void destroyFromScript(void* destroyedObject)
		{
		}

	public:
		void DrawCallback(IRenderer *render, IData *data, IActor* parent, IRenderer::E_DRAW_TYPE drawType);
		void ResizeCallback(IRenderer *render, IData *data, IActor* parent, ClutterSize destSize, bool flagAni, int animationDuration);

	private:
		ScriptFunction m_callback;
	};
}

#endif