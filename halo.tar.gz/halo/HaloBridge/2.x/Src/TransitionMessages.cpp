#include "TransitionMessages.h"
//#include "Halo.h"
//#include "Halo1_0.h"

using namespace HALO;

TransitionMessages TransitionMessages::s_transInst;
CTransition1iMessages CTransition1iMessages::s_trans1iInst;
CTransition1fMessages CTransition1fMessages::s_trans1fInst;
CTransition2fMessages CTransition2fMessages::s_trans2fInst;
//AnimatableMessages AnimatableMessages::s_aniInst;

DEF_SERIALIZE_REMOTE_CTOR(TransitionGraphics, TransitionX)
DEF_SERIALIZE_REMOTE_METHOD(TransitionGraphics, TransitionA)
DEF_SERIALIZE_REMOTE_METHOD(TransitionGraphics, TransitionB, int)
DEF_SERIALIZE_REMOTE_METHOD(TransitionGraphics, TransitionC, ClutterAnimationMode)
DEF_SERIALIZE_REMOTE_METHOD(TransitionGraphics, TransitionD, bool)
DEF_SERIALIZE_REMOTE_METHOD(TransitionGraphics, TransitionE, RemotePtr<TransitionListenerProxy>, int)
DEF_SERIALIZE_REMOTE_METHOD(TransitionGraphics, TransitionF, RemotePtr<TransitionListenerProxy>)
DEF_SERIALIZE_REMOTE_METHOD(TransitionGraphics, TransitionG, float)
DEF_SERIALIZE_REMOTE_METHOD(TransitionGraphics, TransitionH, float, float)

DEF_SERIALIZE_REMOTE_CTOR(Transition1iGraphics, Trans1iX)
DEF_SERIALIZE_REMOTE_METHOD(Transition1iGraphics, Trans1iB, int)

DEF_SERIALIZE_REMOTE_CTOR(Transition1fGraphics, Trans1fX)
DEF_SERIALIZE_REMOTE_METHOD(Transition1fGraphics, Trans1fB, float)

DEF_SERIALIZE_REMOTE_CTOR(Transition2fGraphics, Trans2fX)
DEF_SERIALIZE_REMOTE_METHOD(Transition2fGraphics, Trans2fB, float, float)

//DEF_SERIALIZE_REMOTE_METHOD(CAnimatable, AnimatableA, RemotePtr<CActor>, int)
void TransitionMessages::registerMessages()
{
	registerConstructor < TransitionGraphics >(TransitionMsg::M_Create());

	registerReturningMethod<TransitionGraphics, bool, bool>(TransitionMsg::M_Initialize(), &TransitionGraphics::Initialize);
	registerMethod(TransitionMsg::M_SetMode(), &TransitionGraphics::SetMode);
	registerMethod(TransitionMsg::M_SetDuration(), &TransitionGraphics::SetDuration);
	registerMethod(TransitionMsg::M_Play(), &TransitionGraphics::Play);
	registerMethod<TransitionGraphics, RemotePtr<TransitionListenerProxy>, int>(TransitionMsg::M_AddListener(), &TransitionGraphics::AddListener);
	registerReturningMethod<TransitionGraphics, int, RemotePtr<TransitionListenerProxy>>(TransitionMsg::M_RemoveListener(), &TransitionGraphics::RemoveListener);
	registerReturningMethod<TransitionGraphics, int>(TransitionMsg::M_GetDuration(), &TransitionGraphics::Duration);
	registerMethod<TransitionGraphics, int>(TransitionMsg::M_SetDurationNew1i(), &TransitionGraphics::SetDestination_New);
	registerMethod<TransitionGraphics, float>(TransitionMsg::M_SetDurationNew1f(), &TransitionGraphics::SetDestination_New);
	registerMethod<TransitionGraphics, float, float>(TransitionMsg::M_SetDurationNew2f(), &TransitionGraphics::SetDestination_New);
	registerReturningMethod<TransitionGraphics, bool>(TransitionMsg::M_IsPlaying(), &TransitionGraphics::IsPlaying);
}

void CTransition1iMessages::registerMessages()
{
	registerConstructor < Transition1iGraphics >(Trans1iMsg::M_Create());

	registerMethod(Trans1iMsg::M_SetDestination(), &Transition1iGraphics::SetDestination);
}

void CTransition1fMessages::registerMessages()
{
	registerConstructor < Transition1fGraphics >(Trans1fMsg::M_Create());

	registerMethod(Trans1fMsg::M_SetDestination(), &Transition1fGraphics::SetDestination);
}

void CTransition2fMessages::registerMessages()
{
	registerConstructor < Transition2fGraphics >(Trans2fMsg::M_Create());

	registerMethod(Trans2fMsg::M_SetDestination(), &Transition2fGraphics::SetDestination);
}

//void AnimatableMessages::registerMessages()
//{
//	//registerConstructor < CAnimatable >(AnimatableMsg::M_Create());
//
//	registerReturningMethod<CAnimatable, bool, RemotePtr<CActor>, int>(AnimatableMsg::M_BindTransition(), &CAnimatable::BindTransition);
//}
