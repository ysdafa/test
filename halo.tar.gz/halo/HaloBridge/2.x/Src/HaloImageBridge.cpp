#include "Halo1_0.h"
#include "HaloImageBridge.h"

using namespace Bridge;
using namespace HALO;

void HaloImageBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);

	context.captureMethodCall<IActor, &setImage>("setImage");
}

IActor* HaloImageBridge::constructWidget(IActor* parent, float width, float height, const ScriptArray& args)
{
	std::string text, font;
	ScriptArray arg;

	if(width == -1) width = 0;
	if(height == -1) height = 0;

	//IImage* cimage;
	//IImage::CreateInstance(&cimage);
	HaloImageProxy *cimage = new HaloImageProxy();
	cimage->Initialize(parent, width, height);
	
	return cimage;
}

ScriptObject HaloImageBridge::setImage(IActor* self, const ScriptArray& args)
{
	IImage *image = dynamic_cast<IImage*>(self);
	if (args.Length() > 0)
	{
		if (args[0].isString())
		{
			image->SetImage(args[0].asString().data());
		}
		else
		{
			IImageBuffer* buffer = unwrapNativeObject<IImageBuffer>(args[0]);
			image->SetImage(buffer);
		}
	}

	return ScriptObject();
}
