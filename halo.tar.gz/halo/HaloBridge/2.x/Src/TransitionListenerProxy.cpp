#include "Halo1_0.h"
#include "TransitionListenerProxy.h"

TransitionListenerMessages TransitionListenerMessages::s_transListenerInst;

DEF_SERIALIZE_REMOTE_CTOR(TransitionListenerProxy, TransitionListenerStubX)
DEF_SERIALIZE_REMOTE_METHOD(TransitionListenerProxy, TransitionListenerStubA, RemotePtr<ITimeLine>, double, int)
DEF_SERIALIZE_REMOTE_METHOD(TransitionListenerProxy, TransitionListenerStubB, RemotePtr<ITimeLine>, int)
DEF_SERIALIZE_REMOTE_METHOD(TransitionListenerProxy, TransitionListenerStubC, RemotePtr<ITimeLine>, bool, int)

void TransitionListenerMessages::registerMessages()
{
	registerConstructor <TransitionListenerProxy>(TransitionListenerMsg::M_Create());

	registerMethod(TransitionListenerMsg::M_OnNewFrame(), &TransitionListenerProxy::OnNewFrame1);
	registerMethod(TransitionListenerMsg::M_OnStarted(), &TransitionListenerProxy::OnStarted1);
	registerMethod(TransitionListenerMsg::M_OnPaused(), &TransitionListenerProxy::OnPaused1);
	registerMethod(TransitionListenerMsg::M_OnCompleted(), &TransitionListenerProxy::OnCompleted1);
	registerMethod(TransitionListenerMsg::M_OnStoped(), &TransitionListenerProxy::OnStoped1);

}

void TransitionListenerProxy::OnNewFrame1(RemotePtr<ITimeLine> animation, double currentProgress, int data)
{
	
	PRINT("TransitionListenerProxy::%s\n", __FUNCTION__);
	OnNewFrame(animation.getPtr(), currentProgress, (void*)data);
}

void TransitionListenerProxy::OnStarted1(RemotePtr<ITimeLine> animation, int data)
{
	PRINT("TransitionListenerProxy::%s\n", __FUNCTION__);
	OnStarted(animation.getPtr(), (void*)data);
}

void TransitionListenerProxy::OnPaused1(RemotePtr<ITimeLine> animation, int data)
{
	PRINT("TransitionListenerProxy::%s\n", __FUNCTION__);
	OnPaused(animation.getPtr(), (void*)data);
}

void TransitionListenerProxy::OnCompleted1(RemotePtr<ITimeLine> animation, int data)
{
	PRINT("TransitionListenerProxy::%s\n", __FUNCTION__);
	OnCompleted(animation.getPtr(), (void*)data);
}

void TransitionListenerProxy::OnStoped1(RemotePtr<ITimeLine> animation, bool flagFinished, int data)
{
	PRINT("TransitionListenerProxy::%s\n", __FUNCTION__);
	OnStoped(animation.getPtr(), flagFinished, (void*)data);
}

