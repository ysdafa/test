#include "RenderBridge.h"

using namespace Bridge;
using namespace HALO;

void RenderBridge::mapScriptInterface(ScriptContext& context)
{
	
}

void* RenderBridge::constructFromScript(const ScriptArray& args)
{
	ASSERT(1 == args.Length() && true == args[0].isFunction());

	m_callback = args[0].asFunction();

	return new InternalRender(this);
}

void InternalRender::Draw(IData *data, IActor* parent, E_DRAW_TYPE drawType)
{
	PRINT("InternalRender::%s\n", __FUNCTION__);

	m_owner->DrawCallback(this, data, parent, drawType);
	PRINT("InternalRender::%s %d\n", __FUNCTION__, __LINE__);
}

void InternalRender::Update(IData *data, IActor* parent)
{
	
}

void InternalRender::Resize(IData *data, IActor* parent, ClutterSize destSize, bool flagAni, int animationDuration)
{
	m_owner->ResizeCallback(this, data, parent, destSize, flagAni, animationDuration);
}

void RenderBridge::DrawCallback(IRenderer *render, IData *data, IActor* parent, IRenderer::E_DRAW_TYPE drawType)
{
	float w, h;
	parent->GetSize(w, h);

	if (IRenderer::UNLOAD_DATA_DRAW == drawType)
	{
		parent->Hide();
	}
	else
	{
		parent->Show();
	}

	ScriptArray args;
	args.set(0, ScriptObject((int)DRAW_CALLBACK));
	args.set(1, wrapExistingNativeObject(render));
	args.set(2, ScriptObject(int(parent)));
	args.set(3, wrapExistingNativeObject(data));
	args.set(4, ScriptObject(drawType));

	m_callback.invoke(args);
}

void RenderBridge::ResizeCallback(IRenderer *render, IData *data, IActor* parent, ClutterSize destSize, bool flagAni, int animationDuration)
{
	ScriptArray args;
	args.set(0, ScriptObject((int)RESIZE_CALLBACK));
	args.set(1, wrapExistingNativeObject(render));
	args.set(2, ScriptObject(destSize.width));
	args.set(3, ScriptObject(destSize.height));

	m_callback.invoke(args);
}
