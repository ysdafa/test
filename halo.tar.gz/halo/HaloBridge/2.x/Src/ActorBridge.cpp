#include "Halo1_0.h"
#include "ActorBridge.h"

using namespace Bridge;
using namespace HALO;

void ActorBridge::mapScriptInterface(ScriptContext& context)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	context.captureMethodCall<IActor, &setParent>("setParent");
	context.captureMethodCall<IActor, &setBackgroundColor>("setBackgroundColor");
	context.captureMethodCall<IActor, &setSize>("setSize");
	context.captureMethodCall<IActor, &setPositon>("setPosition");

	context.captureMethodCall<IActor, &setLayout>("setLayout");
	context.captureMethodCall<IActor, &setOrientation>("setOrientation");
	context.captureMethodCall<IActor, &show>("show");
	context.captureMethodCall<IActor, &hide>("hide");

	context.captureMethodCall<IActor, &setClipArea>("setClipArea");
	context.captureMethodCall<IActor, &removeClipArea>("removeClipArea");
	context.captureMethodCall<IActor, &setAlpha>("setAlpha");
	context.captureMethodCall<IActor, &setPivotPoint>("setPivotPoint");
	context.captureMethodCall<IActor, &setRotation>("setRotation");
	context.captureMethodCall<IActor, &setScale>("setScale");
	context.captureMethodCall<IActor, &setSize>("setSize");
	context.captureMethodCall<IActor, &addChild>("addChild");
	context.captureMethodCall<IActor, &numOfChildren>("numOfChildren");
	context.captureMethodCall<IActor, &destroyAllChildren>("destroyAllChildren");
	context.captureMethodCall<IActor, &raise>("raise");
	context.captureMethodCall<IActor, &lower>("lower");
	context.captureMethodCall<IActor, &enable>("enable");
	context.captureMethodCall<IActor, &enableFocus>("enableFocus");
	context.captureMethodCall<IActor, &enablePointerFocus>("enablePointerFocus");
	context.captureMethodCall<IActor, &setFocus>("setFocus");
	context.captureMethodCall<IActor, &setTabWindow>("setTabWindow");
	context.captureMethodCall<IActor, &moveTab>("moveTab");

	context.captureMethodCall<IActor, &addMouseListener>("addMouseListener");
	context.captureMethodCall<IActor, &addKeyboardListener>("addKeyboardListener");
	context.captureMethodCall<IActor, &addClickListener>("addClickListener");
	context.captureMethodCall<IActor, &addKeyLongPressListener>("addKeyLongPressListener");
	context.captureMethodCall<IActor, &addFocusListener>("addFocusListener");

	context.captureMethodCall<IActor, &bindTransition>("bindTransition");
}

IActor* ActorBridge::constructWidget(IActor* parent, float width, float height, const ScriptArray& args)
{
	PRINT("Function ActorBridge::%s, args length is %d\n", __FUNCTION__, args.Length());
	if(width == -1) width = 0;
	if(height == -1) height = 0;

	ActorProxy* cActor = new ActorProxy();
	//ActorProxy::CreateInstance(&cActor);
	cActor->Initialize(parent, width, height);

	return cActor;
}

void* ActorBridge::constructFromScript(const ScriptArray& args)
{
	PRINT("Function ActorBridge::%s, args length is %d\n", __FUNCTION__, args.Length());
	float width, height;
	width = height = -1;
	ActorProxy* parent = nullptr;

	ScriptObject options;

	if (args.Length() > 0)
	{
		parent = unwrapNativeObject<ActorProxy>(args[0]);
		if (args.has(1) && args[1].isNumber()) width = args[1].asNumber();
		if (args.has(2) && args[2].isNumber()) height = args[2].asNumber();
	}
	PRINT("ActorBridge::constructFromScript parent = 0x%x\n", parent);

// 	if (nullptr == parent)
// 	{
// 		IStage *stage;
// 		IStage::GetInstance(&stage);
// 		parent = stage->RootActor();
// 	}
	ScriptArray newArg;
	for (int i = 3; i < args.Length(); i++)
	{
		newArg.set(i - 3, args[i]);
	}


	IActor *actor = constructWidget(parent, width, height, newArg);
	PRINT("Function ActorBridge::constructFromScript, contruct actor is 0x%x\n", actor);
	return actor;
}

/*
ActorProxy* ActorBridge::constructSubAnimatable(const ScriptArray& args)
{
	return actor;
}
*/

ScriptObject ActorBridge::setBackgroundColor(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	guint8 r, g, b, a;

	if (args.Length() > 0)
	{
		if (args.has(0) && args[0].isNumber()) r = args[0].asNumber();
		if (args.has(1) && args[1].isNumber()) g = args[1].asNumber();
		if (args.has(2) && args[2].isNumber()) b = args[2].asNumber();
		if (args.has(3) && args[3].isNumber()) a = args[3].asNumber();
	}


	ActorProxy *p = dynamic_cast<ActorProxy*>(self);
	p->SetBackgroundColor(r, g, b, a);
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::setParent(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	if (args.Length() > 0)
	{
		IActor* parent = unwrapNativeObject<IActor>(args[0]);
		actor->SetParent(parent);
	}

	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::setSize(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	float width, height;

	if (args.Length() >= 2)
	{
		if (args[0].isNumber()) 
			width = args[0].asNumber();
		if (args[1].isNumber()) 
			height = args[1].asNumber();
	}
	actor->Resize(width, height);

	return ScriptObject();
}

ScriptObject ActorBridge::setPositon(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	float x, y, z;

	if (args.Length() >= 2)
	{
		if (args[0].isNumber()) 
			x = args[0].asNumber();
		if (args[1].isNumber()) 
			y = args[1].asNumber();

	}
	if (args.has(2) && args[2].isNumber())
	{	
		z = args[2].asNumber();
		actor->SetPosition(x, y, z);
	}
	else
		actor->SetPosition(x, y);

	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::setLayout(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	if (args.Length() > 0)
	{
		ILayout* layout = unwrapNativeObject<ILayout>(args[0]);
		actor->SetLayout(layout);
	}

	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::setOrientation(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	return ScriptObject();
}

ScriptObject ActorBridge::show(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	ActorProxy *p = dynamic_cast<ActorProxy*>(self);
	p->Show();
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::hide(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	actor->Hide();
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::setClipArea(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	float x, y, width, height;

	if (args.Length() >= 4)
	{
		if (args[0].isNumber())
			x = args[0].asNumber();
		if (args[1].isNumber())
			y = args[1].asNumber();
		if (args[2].isNumber())
			width = args[0].asNumber();
		if (args[3].isNumber())
			height = args[1].asNumber();
	}
	actor->SetClipArea(x, y, width, height);

	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::removeClipArea(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	actor->RemoveClipArea();
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::setAlpha(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::setPivotPoint(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::setRotation(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::setScale(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::addChild(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	if (args.Length() > 0)
	{
		ClutterActor* child = unwrapNativeObject<ClutterActor>(args[0]);
		if (child != nullptr)
		{
			actor->AddChild(child);
		}
	}
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::numOfChildren(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	int num = actor->NumOfChildren();
	return ScriptObject(num);
}

ScriptObject Bridge::ActorBridge::destroyAllChildren(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	actor->DestroyAllChildren();
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::raise(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	if (args.Length() > 0)
	{
		IActor* sibling = unwrapNativeObject<IActor>(args[0]);
		actor->Raise(sibling);
	}
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::lower(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	if (args.Length() > 0)
	{
		IActor* sibling = unwrapNativeObject<IActor>(args[0]);
		actor->Lower(sibling);
	}
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::enable(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	bool flagEnable = true;

	if (args.Length() > 0)
	{
		if (args[0].isBool())
			flagEnable = args[0].asBool();
	}
	actor->Enable(flagEnable);

	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::enableFocus(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	bool flagEnable = true;

	if (args.Length() > 0)
	{
		if (args[0].isBool())
			flagEnable = args[0].asBool();
	}
	actor->EnableFocus(flagEnable);

	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::enablePointerFocus(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	bool flagEnable = true;

	if (args.Length() > 0)
	{
		if (args[0].isBool())
			flagEnable = args[0].asBool();
	}
	actor->EnablePointerFocus(flagEnable);

	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::setFocus(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	actor->SetFocus();
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::setTabWindow(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::moveTab(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::addMouseListener(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	if (args.Length() > 0)
	{
		IMouseListener* listener = unwrapNativeObject<IMouseListener>(args[0]);
		if (listener != nullptr)
		{
			actor->AddMouseListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::addKeyboardListener(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	if (args.Length() > 0)
	{
		IKeyboardListener* listener = unwrapNativeObject<IKeyboardListener>(args[0]);
		if (listener != nullptr)
		{
			actor->AddKeyboardListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::addClickListener(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	if (args.Length() > 0)
	{
		IClickListener* listener = unwrapNativeObject<IClickListener>(args[0]);
		if (listener != nullptr)
		{
			actor->AddClickListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::addKeyLongPressListener(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	if (args.Length() > 0)
	{
		IKeyLongPressListener* listener = unwrapNativeObject<IKeyLongPressListener>(args[0]);
		if (listener != nullptr)
		{
			actor->AddKeyLongPressListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::addFocusListener(IActor* self, const ScriptArray& args)
{
	PRINT("ActorBridge::%s\n", __FUNCTION__);
	IActor *actor = dynamic_cast<IActor*>(self);
	ASSERT(NULL != actor);

	if (args.Length() > 0)
	{
		IFocusListener* listener = unwrapNativeObject<IFocusListener>(args[0]);
		if (listener != nullptr)
		{
			actor->AddFocusListener(listener);
		}
	}
	return ScriptObject();
}

ScriptObject Bridge::ActorBridge::bindTransition(IActor* self, const ScriptArray& args)
{
	ASSERT(NULL != self);
	ASSERT(2 == args.Length() && true == args[1].isNumber());

	ITransition *trans = unwrapNativeObject<ITransition>(args[0]);
	int animationType = (int)args[1].asNumber();

	self->BindTransition(trans, animationType);

	return ScriptObject();
}

