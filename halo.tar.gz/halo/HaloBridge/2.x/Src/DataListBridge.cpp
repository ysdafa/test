#include "Halo1_0.h"
#include "DataListBridge.h"

using namespace Bridge;
using namespace HALO;

IRenderer* DataListBridge::GetRenderer(IData *data, IActor* parent)
{
	float w, h;
	parent->GetSize(w, h);

	ScriptArray args;
	args.set(0, ScriptObject((double)w));
	args.set(1, ScriptObject((double)h));
	args.set(2, wrapExistingNativeObject(data));

	ScriptObject result = m_renderCallback.invoke(args);
	IRenderer *render = unwrapNativeObject<IRenderer>(result);
	ASSERT(NULL != render);

	return render;
}

void DataListBridge::mapScriptInterface(ScriptContext& context)
{
	ActorBridge::mapScriptInterface(context);
	context.captureMethodCall<IActor, &loadData>("loadData");
	context.captureMethodCall<IActor, &enlargeFocusedItem>("enlargeFocusedItem");
	context.captureMethodCall<IActor, &moveFocus>("moveFocus");
	context.captureMethodCall<IActor, &showFocus>("showFocus");
	context.captureMethodCall<IActor, &hideFocus>("hideFocus");

	context.captureMethodCall<IActor, &setRenderWidget>("setRenderWidget");
	context.captureMethodCall<IActor, &setRenderActor>("setRenderActor");
}

IActor* DataListBridge::constructWidget(IActor* parent, float width, float height, const ScriptArray& args)
{
	ScriptArray newArgs;
	int length = args.Length();

	ASSERT(true == args[length - 2].isFunction() && true == args[length - 1].isFunction());

	m_renderCallback = args[length - 2].asFunction();
	t_listListenerCallback = args[length - 1].asFunction();

	for (int i = 0; i < length - 2; i++)
	{
		newArgs.set(i, args[i]);
	}

	IDataListControl *control = constructSubWidget(parent, width, height, newArgs);
	control->SetRendererProvider(this);
	control->EnableUnloadFunction(false);

	IActor *actor = dynamic_cast<IActor*>(control);
	return control;
}

ScriptObject DataListBridge::loadData(IActor* self, const ScriptArray& args)
{
	PRINT("Function DataListBridge::%s, args length is %d\n", __FUNCTION__, args.Length());
	IDataListControl *control = dynamic_cast<IDataListControl*>(self);
	control->LoadData();
	PRINT("DataListBridge::%s return \n", __FUNCTION__);
	return ScriptObject();
}

ScriptObject DataListBridge::enlargeFocusedItem(IActor* self, const ScriptArray& args)
{
	PRINT("Function DataListBridge::%s, args length is %d\n", __FUNCTION__, args.Length());
	IDataListControl *control = dynamic_cast<IDataListControl*>(self);
	int w, h;

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber())
		{
			w = args[0].asNumber();
		}

		if(args.has(1) && args[1].isNumber())
		{
			h = args[1].asNumber();
		}
	}

	control->EnlargeFocusedItem(w, h);

	PRINT("DataListBridge::%s return \n", __FUNCTION__);
	return ScriptObject();
}

ScriptObject DataListBridge::moveFocus(IActor* self, const ScriptArray& args)
{
	PRINT("Function DataListBridge::%s, args length is %d\n", __FUNCTION__, args.Length());
	IDataListControl *control = dynamic_cast<IDataListControl*>(self);
	int direction;

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber())
		{
			direction = args[0].asNumber();
		}
	}

	control->MoveFocus(EDirection(direction));

	PRINT("DataListBridge::%s return \n", __FUNCTION__);
	return ScriptObject();
}

ScriptObject DataListBridge::showFocus(IActor* self, const ScriptArray& args)
{
	PRINT("Function DataListBridge::%s, args length is %d\n", __FUNCTION__, args.Length());
	IDataListControl *control = dynamic_cast<IDataListControl*>(self);
	control->ShowFocus();
	PRINT("DataListBridge::%s return \n", __FUNCTION__);
	return ScriptObject();
}

ScriptObject DataListBridge::hideFocus(IActor* self, const ScriptArray& args)
{
	PRINT("Function DataListBridge::%s, args length is %d\n", __FUNCTION__, args.Length());
	IDataListControl *control = dynamic_cast<IDataListControl*>(self);
	control->HideFocus();
	return ScriptObject();
}

ScriptObject DataListBridge::setRenderWidget(IActor* self, const ScriptArray& args)
{
	IDataListControl *control = dynamic_cast<IDataListControl*>(self);
	ASSERT(1 < args.Length());

	IActor *parent = (IActor*)((int)args[0].asNumber());

	PRINT("DataListBridge::%s, ActorProxy *parent is 0x%x\n", __FUNCTION__, parent);
	for (int i = 1; i < args.Length(); i++)
	{
		Widget *widget = unwrapNativeObject<Widget>(args[i]);
		ASSERT(NULL != widget);

		PRINT("setRenderWidget widget = 0x%x\n", widget);

		ActorProxy* p = dynamic_cast<ActorProxy*>(parent);

		PRINT("ActorProxy pointer = 0x%x\n", p);
		if (NULL != p)
		{
			p->AddChild(widget);
		}
	}
	PRINT("DataListBridge::%s, End %d\n",__FUNCTION__, __LINE__);

	return ScriptObject();
}

ScriptObject DataListBridge::setRenderActor(IActor* self, const ScriptArray& args)
{
	PRINT("DataListBridge::%s, %d\n",__FUNCTION__, __LINE__);
	IDataListControl *control = dynamic_cast<IDataListControl*>(self);
	ASSERT(NULL != control);

	ASSERT(1 < args.Length());

	IActor *parent = (IActor*)((int)args[0].asNumber());

	for (int i = 1; i < args.Length(); i++)
	{
		IAnimatable *animatableObject = unwrapNativeObject<IAnimatable>(args[i]);
		ActorProxy *actor = dynamic_cast<ActorProxy*>(animatableObject);

		ASSERT(NULL != actor);
		actor->SetParent(parent);
	}
	PRINT("DataListBridge::%s, End %d\n",__FUNCTION__, __LINE__);

	return ScriptObject();
}
