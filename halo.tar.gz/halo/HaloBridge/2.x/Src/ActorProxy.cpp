#include "Halo1_0.h"
#include "ActorProxy.h"


using namespace HALO;

ActorProxy::ActorProxy()
{
	//Get the universal ID of the graphics process
	std::string targetProcess = VoltMessageCenter::Instance().GfxProcessID();
	//Remote ptr has a convience method for calling the remote constructors
	graphics = RemotePtr<ActorGraphics>::construct(targetProcess, ActorMsg::M_Create());
}

/*
bool ActorProxy::Initialize(ActorProxy* parent, float width, float height)
{
	if (parent)
	{
		return graphics.execute<bool>(ActorMsg::M_Initialize(), parent->graphics, width, height);
	}
	return graphics.execute<bool>(ActorMsg::M_Initialize(), RemotePtr<CActor>(nullptr), width, height);
}
*/

bool ActorProxy::Initialize(IActor* parent, float width, float height)
{

	ActorProxy* p = dynamic_cast<ActorProxy*>(parent);
	PRINT("~ActorProxy::%s start, p = %d, width = %d, height = %d\n",__FUNCTION__, (int)p, width, height);
	
	if (!p)
	{
		PRINT("ActorProxy::Initialize null parent \n");
		return graphics.execute<bool>(ActorMsg::M_Initialize(), RemotePtr<ActorGraphics>(nullptr), width, height);
	}
	else
	{
		PRINT("ActorProxy::Initialize non null parent \n");
		return graphics.execute<bool>(ActorMsg::M_Initialize(), p->graphics, width, height);
	}
}

bool ActorProxy::Initialize(IActor* parent, TWindowAttr *attr)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return false;
}

bool ActorProxy::Initialize(void)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return false;
}

void ActorProxy::Show(void)
{
	graphics.post(ActorMsg::M_Show());
}

void ActorProxy::SetBackgroundColor(guint8 r, guint8 g, guint8 b, guint8 a)
{
	graphics.post(ActorMsg::M_SetBackground(), r, g, b, a);
}

void ActorProxy::Hide(void)
{
PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
graphics.post(ActorMsg::M_Hide());
PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
}

void ActorProxy::SetPosition(float x, float y, float z)
{
	PRINT("%s ...%f, %f, %f\n",__FUNCTION__, x, y, z);

	graphics.post(ActorMsg::M_SetPosition(), x, y, z);
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
}

void ActorProxy::SetPosition(float x, float y)
{
	PRINT("%s ...%f, %f\n",__FUNCTION__, x, y);
	float z = 0.0f;
	graphics.post(ActorMsg::M_SetPosition(), x, y, z);
	
	PRINT("ActorProxy::%s ... END\n",__FUNCTION__);
}

bool ActorProxy::Raise(IActor* sibling)
{
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
	ActorProxy* p = dynamic_cast<ActorProxy*>(sibling);
	if(p == NULL)
		graphics.post(ActorMsg::M_Raise(), RemotePtr<ActorGraphics>(nullptr));
	else
		graphics.post(ActorMsg::M_Raise(), p->graphics);
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
	return true;
}

bool ActorProxy::Lower(IActor* sibling)
{
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
	ActorProxy* p = dynamic_cast<ActorProxy*>(sibling);
	if(p == NULL)
		graphics.post(ActorMsg::M_Lower(), RemotePtr<ActorGraphics>(nullptr));
	else
		graphics.post(ActorMsg::M_Lower(), p->graphics);
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
	return true;
}

void ActorProxy::Enable(bool flagEnable)
{
	graphics.post(ActorMsg::M_Enable(), flagEnable);
}

void ActorProxy::EnableFocus(bool flagFocusable)
{
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
	graphics.post(ActorMsg::M_EnableFocus(), flagFocusable);
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
}

void ActorProxy::EnablePointerFocus(bool enable)
{
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
	graphics.post(ActorMsg::M_EenablePointerFocus(), enable);
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
}

bool ActorProxy::SetFocus(void)
{
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
	graphics.post(ActorMsg::M_SetFocus());
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
	return true;
}

void ActorProxy::SetParent(IActor* parent)
{
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
	ActorProxy* p = dynamic_cast<ActorProxy*>(parent);
	if (p == NULL)
		graphics.post(ActorMsg::M_SetParent(), RemotePtr<ActorGraphics>(nullptr));
	else
		graphics.post(ActorMsg::M_SetParent(), p->graphics);
}

IActor* ActorProxy::Parent(void) const
{
	return NULL;
}

void ActorProxy::SetBackgroundColor(const ClutterColor &color)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
}

void ActorProxy::Resize(float width, float height)
{
	PRINT("ActorProxy::%s, %d w:%4.1f h:%4.1f\n",__FUNCTION__, __LINE__, width, height);
	graphics.post(ActorMsg::M_SetSize(), width, height);
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
}

void ActorProxy::GetSize(float &width, float &height)
{
	PRINT("%s ..implemented!\n",__FUNCTION__);
	Vector2 size = graphics.execute<Vector2>(ActorMsg::M_GetSize());
	width = size.x;
	height = size.y;
	PRINT("ActorProxy::%s, %d w:%4.1f h:%4.1f\n",__FUNCTION__, __LINE__, width, height);
}

void ActorProxy::GetPosition(float &x, float &y, float &z)
{
	PRINT("%s ...implemented!\n",__FUNCTION__);
	Vector3 pos = graphics.execute<Vector3>(ActorMsg::M_GetPosition());
	x = pos.x;
	y = pos.y;
	z = pos.z;
	PRINT("ActorProxy::%s, %d x:%4.1f y:%4.1f\n",__FUNCTION__, __LINE__, x, y);
}

void ActorProxy::GetPosition(float &x, float &y)
{
	PRINT("%s ..implemented!\n",__FUNCTION__);
	Vector3 pos = graphics.execute<Vector3>(ActorMsg::M_GetPosition());
	x = pos.x;
	y = pos.y;
	PRINT("ActorProxy::%s, %d x:%4.1f y:%4.1f\n",__FUNCTION__, __LINE__, x, y);
}

bool ActorProxy::SetLayout(ILayout* layout)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return false;
}

ILayout* ActorProxy::Layout(void)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return NULL;
}

void ActorProxy::SetOrientation(EOrientation orientation)
{
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
	graphics.post(ActorMsg::M_SetOrientation(), orientation);
}

HALO::EOrientation ActorProxy::Orientation(bool flagReferParent)
{
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
	return graphics.execute<EOrientation>(ActorMsg::M_GetOrientation(), flagReferParent);
}

bool ActorProxy::FlagShow(void)
{
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
	return graphics.execute<bool>(ActorMsg::M_FlagShow());
}

void ActorProxy::SetClipArea(float x, float y, float width, float height)
{
	PRINT("ActorProxy::%s called!\n",__FUNCTION__);

	graphics.post(ActorMsg::M_SetClipArea(), x, y, width, height);
}

void ActorProxy::GetClipArea(float &x, float &y, float &width, float &height)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
}

void ActorProxy::RemoveClipArea(void)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
}

bool ActorProxy::FlagClip(void)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return false;
}

void ActorProxy::SetAlpha(int alpha)
{
	PRINT("%s ...%d\n",__FUNCTION__, alpha);
	graphics.post(ActorMsg::M_SetAlpha(), alpha);
}

int ActorProxy::Alpha(void)
{
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
	return graphics.execute<int>(ActorMsg::M_GetAlpha());
}

void ActorProxy::SetPivotPoint(float xPivot, float yPivot, float zPivot)
{
	graphics.post(ActorMsg::M_SetPivotPoint(), xPivot, yPivot, zPivot);
}

void ActorProxy::GetPivotPoint(float &xPivot, float &yPivot, float &zPivot)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
}

void ActorProxy::SetRotation(double xAngle, double yAngle, double zAngle)
{
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
	graphics.post(ActorMsg::M_SetRotation(), xAngle, yAngle, zAngle);
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
}

void ActorProxy::GetRotation(double &xAngle, double &yAngle, double &zAngle)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
}

void ActorProxy::SetScale(double xFactor, double yFactor, double zFactor)
{
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
	graphics.post(ActorMsg::M_SetScale(), xFactor, yFactor, zFactor);
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
}

void ActorProxy::GetScale(double &xFactor, double &yFactor, double &zFactor)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
}

void ActorProxy::AddEffect(IEffect* effect)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
}

void ActorProxy::RemoveEffect(IEffect* effect)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
}

void ActorProxy::ClearEffects(void)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
}

void ActorProxy::AddChild(ClutterActor *actor)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
}

void ActorProxy::AddChild(Widget* widget)
{
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
	graphics.post(ActorMsg::M_AddChild(), widget->getWidgetGraphics());
	PRINT("ActorProxy::%s, %d\n",__FUNCTION__, __LINE__);
}

int ActorProxy::NumOfChildren(void)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return 0;
}

IActor* ActorProxy::GetChild(int index)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return NULL;
}

void ActorProxy::DestroyAllChildren(void)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
}

bool ActorProxy::IsEnabled(void)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::IsPointerFocusEnabled(void)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::IsFocusEnabled(void)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::KillFocus(bool autoFocus /*= true*/)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::IsFocused(void)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

void ActorProxy::SetTabWindow(EDirection dir, IActor* tabWindow)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
}

IActor* ActorProxy::TabWindow(EDirection dir)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return NULL;
}

bool ActorProxy::MoveTab(EDirection dir)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

void ActorProxy::EnableDragDrop(bool flagEnable)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
}

bool ActorProxy::FlagDragDrop(void)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

void ActorProxy::GrabDeviceEvent(IDevice* device)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
}

void ActorProxy::UnGrabDeviceEvent(IDevice* device)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
}

bool ActorProxy::FlagAcceptInput(void)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::AddFocusListener(IFocusListener* pListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::RemoveFocusListener(IFocusListener* pListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::AddMouseListener(IMouseListener* pAddListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::RemoveMouseListener(IMouseListener* pRemoveListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::AddTouchListener(ITouchListener* pAddListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::RemoveTouchListener(ITouchListener* pRemoveListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::AddKeyboardListener(IKeyboardListener* pAddListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::RemoveKeyboardListener(IKeyboardListener* pRemoveListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::AddAudioListener(IAudioListener* pAddListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::RemoveAudioListener(IAudioListener* pRemoveListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::AddRemoteControlListener(IRemoteControlListener* pAddListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::RemoveRemoteControlListener(IRemoteControlListener* pRemoveListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::AddRidgeListener(IRidgeListener* pAddListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::RemoveRidgeListener(IRidgeListener* pRemoveListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::AddCursorStateChangeListener(ICursorListener* pAddListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::RemoveCursorStateChangeListener(ICursorListener* pRemoveListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::AddClickListener(IClickListener* pAddListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::RemoveClickListener(IClickListener* pRemoveListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::AddSemanticEventListener(ISemanticEventListener* pAddListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::RemoveSemanticEventListener(ISemanticEventListener* pRemoveListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::AddAction(IAction* pAction)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::RemoveAction(IAction* pAction)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::AddDragListener(IDragListener* pAddListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::RemoveDragListener(IDragListener* pRemoveListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::AddGestureListener(IGestureListener* pAddListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::RemoveGestureListener(IGestureListener* pRemoveListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::AddKeyLongPressListener(IKeyLongPressListener* pAddListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::RemoveKeyLongPressListener(IKeyLongPressListener* pRemoveListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::AddKeyCombinationListener(IKeyCombinationListener* pAddListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::RemoveKeyCombinationListener(IKeyCombinationListener* pRemoveListener)
{
	printf("%s NOT implemented!\n",__FUNCTION__);
	return true;
}

bool ActorProxy::BindTransition(ITransition *transition, int animationType)
{
	PRINT("%s implemented!\n",__FUNCTION__);
	TransitionProxy* p = dynamic_cast<TransitionProxy*>(transition);
	PRINT("%s dynamic_cast<TransitionProxy*>(transition) = 0x%x\n",__FUNCTION__, (int)p);
	return graphics.execute<bool>(ActorMsg::M_BindTransition(), p->GetGraphics(), animationType);
}

bool ActorProxy::IsInitialized(void) const
{
	PRINT("ActorProxy::%s\n",__FUNCTION__);

	return graphics.execute<bool>(ActorMsg::M_IsInitialized());
}
