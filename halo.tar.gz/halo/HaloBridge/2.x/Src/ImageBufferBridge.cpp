#include "ImageBufferBridge.h"

using namespace Bridge;
using namespace HALO;

void ImageBufferBridge::mapScriptInterface(ScriptContext& context)
{
	context.captureMethodCall<IImageBuffer, &clone>("clone");
}

void* ImageBufferBridge::constructFromScript(const ScriptArray& args)
{
	IImageBuffer *cBuffer = constructWidget(args);
	if (args.Length() > 0)
	{
		if (args[0].isString() && args.has(1) && args[1].isNumber())
		{
			cBuffer->Initialize(args[0].asString().data(), args[1].asNumber());
		}
		else if (args[0].isString())
		{
			cBuffer->Initialize(args[0].asString().data());
		}
		else
		{
			cBuffer->Initialize(unwrapNativeObject<IImageBuffer>(args[0]));
		}
	}
	return cBuffer;
}

IImageBuffer* ImageBufferBridge::constructWidget(const ScriptArray& args)
{
	IImageBuffer *cBuffer;
	IImageBuffer::CreateInstance(&cBuffer);

	return cBuffer;
}

ScriptObject ImageBufferBridge::Initialize(IImageBuffer* self, const ScriptArray& args)
{
	if (args.Length() > 0)
	{
		if (args[0].isString() && args.has(1) && args[1].isNumber())
		{
			self->Initialize(args[0].asString().data(), args[1].asNumber());
		}
		else if (args[0].isString())
		{
			self->Initialize(args[0].asString().data());
		}
		else
		{
			self->Initialize(unwrapNativeObject<IImageBuffer>(args[0]));
		}
	}

	return ScriptObject();
}

ScriptObject ImageBufferBridge::clone(IImageBuffer* self, const ScriptArray& args)
{
	IImageBuffer *cBuffer;
	cBuffer = self->Clone();

	return wrapExistingNativeObject(cBuffer);
}
