#include "Halo1_0.h"
#include "TransitionGraphics.h"

TransitionGraphics::TransitionGraphics(void) : t_realTransition(NULL)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	t_realTransition = new CTransitionBase;
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
}

TransitionGraphics::~TransitionGraphics(void)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	m_listenerProxyMap.clear();

	delete t_realTransition;
	t_realTransition = NULL;
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
}

bool TransitionGraphics::Initialize(bool flagCustomAnimation)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	bool retVal = t_realTransition->Initialize(flagCustomAnimation);
	t_realTransition->AddListener(this, NULL);
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
	return retVal;
}

bool TransitionGraphics::Initialize(void)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	bool retVal = t_realTransition->Initialize(false);
	t_realTransition->AddListener(this, NULL);
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
	return retVal;
}

void TransitionGraphics::SetDuration(int duration)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	t_realTransition->SetDuration(duration);
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
}

void TransitionGraphics::SetMode(ClutterAnimationMode animationMode)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	t_realTransition->SetMode(animationMode);
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
}

int TransitionGraphics::Duration(void)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	int retVal = t_realTransition->Duration();
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
	return retVal;
}

void TransitionGraphics::AddListener(ITimeLineListener *listener, void *userData)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	t_realTransition->AddListener(listener, userData);
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
}

void TransitionGraphics::AddListener(RemotePtr<TransitionListenerProxy> listener, int userData)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	ASSERT(true == IsInitialized());
	TListenerProxyData data;
	data.p = listener;
	data.data = userData;
	m_listenerProxyMap.push_back(data);
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
}

void TransitionGraphics::RemoveListener(ITimeLineListener *listener, void* &userData)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	t_realTransition->RemoveListener(listener, userData);
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
}

int TransitionGraphics::RemoveListener(RemotePtr<TransitionListenerProxy> listener)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	ASSERT(true == IsInitialized());
	int userData = 0;
	for (std::list<TListenerProxyData>::iterator x = m_listenerProxyMap.begin(); x != m_listenerProxyMap.end(); ++x)
	{
		if ((*x).p.getPtr() == listener.getPtr())
		{
			userData = (*x).data;
			m_listenerProxyMap.erase(x);
			return userData;
		}
	}
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
	return userData;
}

bool TransitionGraphics::IsPlaying(void)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	bool retVal =  t_realTransition->IsPlaying();
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
	return retVal;
}

void TransitionGraphics::Play(void)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	t_realTransition->Play();
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
}

void TransitionGraphics::Stop(void)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	t_realTransition->Stop();
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
}

void TransitionGraphics::Pause(void)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	t_realTransition->Pause();
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
}

bool TransitionGraphics::IsInitialized(void) const
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	bool retVal =  t_realTransition->IsInitialized();
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
	return retVal;
}

void TransitionGraphics::SetDestination_New(int destValue)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	t_realTransition->SetDestination_New(destValue);
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
}

void TransitionGraphics::SetDestination_New(float destValue)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	t_realTransition->SetDestination_New(destValue);
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
}

void TransitionGraphics::SetDestination_New(float destValue1, float destValue2)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	t_realTransition->SetDestination_New(destValue1, destValue2);
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
}

bool TransitionGraphics::OnNewFrame(class ITimeLine *animation, double currentProgress, void *data)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	m_CallListener(EVENT_NEWFRAME, &currentProgress);
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
	return true;
}

bool TransitionGraphics::OnStarted(class ITimeLine *animation, void *data)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	m_CallListener(EVENT_STARTED);
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
	return true;
}

bool TransitionGraphics::OnPaused(class ITimeLine *animation, void *data)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	m_CallListener(EVENT_PAUSED);
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
	return true;
}

bool TransitionGraphics::OnCompleted(class ITimeLine *animation, void *data)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	m_CallListener(EVENT_COMPLETED);
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
	return true;
}

bool TransitionGraphics::OnStoped(class ITimeLine *animation, bool flagFinished, void *data)
{
	PRINT("TransitionGraphics::%s Start!\n",__FUNCTION__);
	m_CallListener(EVENT_STOPPED, &flagFinished);
	PRINT("TransitionGraphics::%s Done!\n",__FUNCTION__);
	return true;
}

void TransitionGraphics::m_CallListener(ETimeLineListenerType type, void *data /*= NULL*/)
{
	for (std::list<TListenerProxyData>::iterator x = m_listenerProxyMap.begin(); x != m_listenerProxyMap.end(); ++x)
	{
		RemotePtr<TransitionListenerProxy> listener = (*x).p;

		switch (type)
		{
		case EVENT_STARTED:
			listener.post(TransitionListenerMsg::M_OnStarted(), RemotePtr<ITimeLine>(this), (*x).data);
			break;

		case EVENT_COMPLETED:
			listener.post(TransitionListenerMsg::M_OnCompleted(), RemotePtr<ITimeLine>(this), (*x).data);
			break;

		case EVENT_PAUSED:
			listener.post(TransitionListenerMsg::M_OnPaused(), RemotePtr<ITimeLine>(this), (*x).data);
			break;

		case EVENT_STOPPED:
		{
			  bool *flagFinished = (bool*)data;
			  listener.post(TransitionListenerMsg::M_OnStoped(), RemotePtr<ITimeLine>(this), *flagFinished, (*x).data);
		}
			break;

		case EVENT_NEWFRAME:
		{
			   double *progress = (double*)data;
			   listener.post(TransitionListenerMsg::M_OnNewFrame(), RemotePtr<ITimeLine>(this), *progress, (*x).data);
		}
			break;
		}
	}
}


void Transition1iGraphics::SetDestination(int destValue)
{
	PRINT("Transition1iGraphics::%s Start!\n",__FUNCTION__);
	dynamic_cast<CTransition1i*>(t_realTransition)->SetDestination(destValue);
	PRINT("Transition1iGraphics::%s Done!\n",__FUNCTION__);
}

void Transition1fGraphics::SetDestination(float destValue)
{
	PRINT("Transition1fGraphics::%s Start!\n",__FUNCTION__);
	dynamic_cast<CTransition1f*>(t_realTransition)->SetDestination(destValue);
	PRINT("Transition1fGraphics::%s Done!\n",__FUNCTION__);
}

void Transition2fGraphics::SetDestination(float destValue1, float destValue2)
{
	PRINT("Transition2fGraphics::%s Start!\n",__FUNCTION__);
	dynamic_cast<CTransition2f*>(t_realTransition)->SetDestination(destValue1, destValue2);
	PRINT("Transition2fGraphics::%s Done!\n",__FUNCTION__);
}
