#include "Halo1_0.h"
#include "TransitionBridge.h"
#include "IAnimation.h"

using namespace Bridge;
using namespace HALO;

void TransitionBridge::mapScriptInterface(ScriptContext& context)
{
	context.captureMethodCall<ITransition, &m_SetDuration>("setDuration");
	context.captureMethodCall<ITransition, &m_SetDestination>("setDestination");
	context.captureMethodCall<ITransition, &m_Play>("play");
}

void* TransitionBridge::constructFromScript(const ScriptArray& args)
{
	TransitionProxy*trans;
	//ITransition::CreateInstance(&trans);

	trans = new TransitionProxy();
	trans->Initialize(false);
	return trans;
}

ScriptObject TransitionBridge::m_SetDuration(ITransition* self, const ScriptArray& args)
{
	ASSERT(NULL != self);
	ASSERT(1 == args.Length() && true == args[0].isNumber());

	self->SetDuration((int)args[0].asNumber());

	return ScriptObject();
}

ScriptObject TransitionBridge::m_SetDestination(ITransition* self, const ScriptArray& args)
{
	ASSERT(NULL != self);
	ASSERT(0 < args.Length());

	int argsLength = args.Length();

	switch (argsLength)
	{
	case 1:
		self->SetDestination_New((float)(args[0].asNumber()));
		break;

	case 2:
		self->SetDestination_New((float)(args[0].asNumber()), (float)(args[1].asNumber()));
		break;

	default:
		break;
	}

	return ScriptObject();
}

ScriptObject TransitionBridge::m_Play(ITransition* self, const ScriptArray& args)
{
	ASSERT(NULL != self);
	self->Play();

	return ScriptObject();
}

