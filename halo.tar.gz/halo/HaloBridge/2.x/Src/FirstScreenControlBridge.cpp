#include "Halo1_0.h"
#include "FirstScreenControlBridge.h"

using namespace Bridge;
using namespace HALO;

void FirstScreenControlBridge::mapScriptInterface(ScriptContext& context)
{
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	DataListBridge::mapScriptInterface(context);
	context.captureMethodCall<IActor, &m_AddMainMenuItem>("addMainMenuItem");

	context.captureMethodCall<IActor, &m_AddSubItem>("addSubItem");
	context.captureMethodCall<IActor, &m_SetScrollItemNumber>("setScrollItemNumber");
	context.captureMethodCall<IActor, &m_ExpandMainMenu>("expandMainMenu");
	context.captureMethodCall<IActor, &m_ShrinkMainMenu>("shrinkMainMenu");
	context.captureMethodCall<IActor, &m_SetMaxMargin>("setMaxMargin");
	context.captureMethodCall<IActor, &m_SetExpandAnimationDuration>("setExpandAnimationDuration");
	context.captureMethodCall<IActor, &m_SetScrollSpeed>("setScrollSpeed");

	context.captureMethodCall<IActor, &m_AddMainMenuData>("addMainMenuData");
	context.captureMethodCall<IActor, &m_AddSubMenuData>("addSubMenuData");
	context.captureMethodCall<IActor, &m_AddScrollMenuData>("addScrollDataInMainMenu");

	context.captureMethodCall<IActor, &m_MainMenuData>("mainMenuData");
	context.captureMethodCall<IActor, &m_SubMenuData>("subMenuData");
	context.captureMethodCall<IActor, &m_ScrollMenuData>("scrollDataInMenu");

	context.captureMethodCall<IActor, &m_SetFocusRange>("setFocusRange");
}

void FirstScreenControlBridge::destroyFromScript(void* destroyedObject)
{
	DataListBridge::destroyFromScript(destroyedObject);
}

IDataListControl* FirstScreenControlBridge::constructSubWidget(IActor* parent, float width, float height, const ScriptArray& args)
{
	PRINT("FirstScreenControlBridge::%s, %d argsNum=%d\n",__FUNCTION__, __LINE__, args.Length());
	IFirstScreenListControl *control;
	IFirstScreenListControl::CreateInstance(&control);

	ASSERT(6 == args.Length());
	ASSERT(true == args[0].isNumber() && true == args[1].isNumber() && true == args[1].isNumber() && true == args[2].isNumber() 
		&& 
		true == args[3].isNumber() && true == args[4].isNumber() && true == args[5].isNumber());

	float mainTitleWidth = (float)args[0].asNumber();
	float mainTitleHeight = (float)args[1].asNumber();
	float mainTitleSpace = (float)args[2].asNumber();
	float subTitleWidth = (float)args[3].asNumber();
	float subTitleHeight = (float)args[4].asNumber();
	float subTitleSpace = (float)args[5].asNumber();

	control->Initialize(parent, width, height, mainTitleWidth, mainTitleHeight, mainTitleSpace, subTitleWidth, subTitleHeight, subTitleSpace);
	control->AddListListener(this);
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return control;
}

bool FirstScreenControlBridge::OnMainMenuItemLoaded(class IFirstScreenListControl* list, int mainMenuIndex)
{
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	ScriptArray args;

	args.set(0, ScriptObject((int)MAIN_ITEM_LOAD));
	args.set(1, wrapExistingNativeObject(list));
	args.set(2, ScriptObject(mainMenuIndex));

	t_listListenerCallback.invoke(args);
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return true;
}

bool FirstScreenControlBridge::OnScrollListItemLoaded(class IFirstScreenListControl* list, int mainMenuIndex, int scrollDataIndex)
{
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	ScriptArray args;

	args.set(0, ScriptObject((int)SCROLL_ITEM_LOAD));
	args.set(1, wrapExistingNativeObject(list));
	args.set(2, ScriptObject(mainMenuIndex));
	args.set(3, ScriptObject(scrollDataIndex));

	t_listListenerCallback.invoke(args);

	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return true;
}

bool FirstScreenControlBridge::OnSubMenuItemLoaded(class IFirstScreenListControl* list, int mainMenuIndex, int subMenuIndex)
{
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	ScriptArray args;

	args.set(0, ScriptObject((int)SUB_ITEM_LOAD));
	args.set(1, wrapExistingNativeObject(list));
	args.set(2, ScriptObject(mainMenuIndex));
	args.set(3, ScriptObject(subMenuIndex));

	t_listListenerCallback.invoke(args);

	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return true;
}

ScriptObject FirstScreenControlBridge::m_AddMainMenuItem(IActor* self, const ScriptArray& args)
{
	ASSERT(4 == args.Length());

	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT(NULL != control);

	ASSERT(true == args[0].isNumber());
	ASSERT(true == args[2].isNumber());
	ASSERT(true == args[3].isArray());
	ASSERT(true == args[1].isArray() || true == args[1].isNumber());

	int itemNum = (int)args[0].asNumber();

	ScriptArray titleArray = args[3].asArray();

	ASSERT(itemNum == titleArray.Length());

	float spaceBetweenItem = (float)args[2].asNumber();
	
	char **itemTitles = new char*[itemNum];

	for (int i = 0; i < itemNum; i++)
	{
		ASSERT(true == titleArray[i].isString());
		std::string title = titleArray[i].asString();

		itemTitles[i] = new char[title.length() + 1];
		strcpy(itemTitles[i], title.c_str());
	}

	if (args[1].isArray())
	{
		ScriptArray sizeArray = args[1].asArray();
		ASSERT(itemNum == sizeArray.Length());

		float *itemSize = new float[itemNum];

		for (int i = 0; i < itemNum; i++)
		{
			ASSERT(true == sizeArray[i].isNumber());
			itemSize[i] = (float)sizeArray[i].asNumber();
		}

		control->AddMainMenuItem(itemNum, itemSize, spaceBetweenItem, itemTitles);

		delete[] itemSize;
	}
	else if (args[1].isNumber())
	{
		float itemSize = (float)args[1].asNumber();
		control->AddMainMenuItem(itemNum, itemSize, spaceBetweenItem, itemTitles);
	}

	for (int i = 0; i < itemNum; i++)
	{
		delete[] itemTitles[i];
	}

	delete[] itemTitles;

	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_AddSubItem(IActor* self, const ScriptArray& args)
{
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT(NULL != control);

	ASSERT(5 == args.Length());
	ASSERT(true == args[0].isNumber());
	ASSERT(true == args[1].isNumber());
	ASSERT(true == args[2].isNumber());
	ASSERT(true == args[3].isNumber());
	ASSERT(true == args[4].isString());

	int mainMenuIndex = (int)args[0].asNumber();
	float itemSize = (float)args[1].asNumber();
	float spaceBetweenItem = (float)args[2].asNumber();
	float enlargeFocusItemSize = (float)args[3].asNumber();
	std::string title = args[4].asString();

	control->AddSubItem(mainMenuIndex, itemSize, spaceBetweenItem, enlargeFocusItemSize, title.c_str());

	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_SetScrollItemNumber(IActor* self, const ScriptArray& args)
{
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT(NULL != control);

	ASSERT(2 == args.Length());
	ASSERT(true == args[0].isNumber());
	ASSERT(true == args[1].isNumber());

	int mainMenuIndex = (int)args[0].asNumber();
	int itemNumber = (int)args[1].asNumber();

	control->SetScrollItemNumber(mainMenuIndex, itemNumber);

	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_ExpandMainMenu(IActor* self, const ScriptArray& args)
{
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT(NULL != control);

	ASSERT(1 == args.Length());
	ASSERT(true == args[0].isNumber());

	int mainMenuIndex = (int)args[0].asNumber();

	control->ExpandMainMenu(mainMenuIndex);

	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_ShrinkMainMenu(IActor* self, const ScriptArray& args)
{
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT(NULL != control);

	ASSERT(1 == args.Length());
	ASSERT(true == args[0].isNumber());

	int mainMenuIndex = (int)args[0].asNumber();

	control->ShrinkMainMenu(mainMenuIndex);

	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_SetMaxMargin(IActor* self, const ScriptArray& args)
{
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT(NULL != control);

	ASSERT(2 == args.Length());
	ASSERT(true == args[0].isNumber());
	ASSERT(true == args[1].isNumber());

	float startMargin = (float)args[0].asNumber();
	float endMargin = (float)args[1].asNumber();

	control->SetMaxMargin(startMargin, endMargin);

	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_SetExpandAnimationDuration(IActor* self, const ScriptArray& args)
{
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT(NULL != control);

	ASSERT(1 == args.Length());
	ASSERT(true == args[0].isNumber());

	int duration = (int)args[0].asNumber();

	control->SetExpandAnimationDuration(duration);

	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_SetScrollSpeed(IActor* self, const ScriptArray& args)
{
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT(NULL != control);

	ASSERT(1 == args.Length());
	ASSERT(true == args[0].isNumber());

	int duration = (int)args[0].asNumber();

	control->SetExpandAnimationDuration(duration);

	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_AddMainMenuData(IActor* self, const ScriptArray& args)
{
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT(NULL != control);
	ASSERT(1 == args.Length());

	IData *data = unwrapNativeObject<IData>(args[0]);

	control->DataSource()->AddMainMenuData(data);

	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_AddSubMenuData(IActor* self, const ScriptArray& args)
{
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT(NULL != control);
	ASSERT(2 == args.Length() && true == args[1].isNumber());

	IData *data = unwrapNativeObject<IData>(args[0]);
	int mainMenuIndex = (int)args[1].asNumber();

	control->DataSource()->AddSubMenuData(data, mainMenuIndex);

	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_AddScrollMenuData(IActor* self, const ScriptArray& args)
{
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT(NULL != control);
	ASSERT(2 == args.Length() && true == args[1].isNumber());

	IData *data = unwrapNativeObject<IData>(args[0]);
	int mainMenuIndex = (int)args[1].asNumber();

	control->DataSource()->AddScrollDataInMainMenu(data, mainMenuIndex);

	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return ScriptObject();
}

ScriptObject FirstScreenControlBridge::m_MainMenuData(IActor* self, const ScriptArray& args)
{
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT(NULL != control);
	ASSERT(1 == args.Length() && true == args[0].isNumber());

	int mainMenuIndex = (int)args[0].asNumber();
	IData *data = control->DataSource()->MainMenuData(mainMenuIndex);

	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return ScriptObject(wrapExistingNativeObject(data));
}

ScriptObject FirstScreenControlBridge::m_SubMenuData(IActor* self, const ScriptArray& args)
{
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT(NULL != control);
	ASSERT(2 == args.Length() && true == args[0].isNumber() && true == args[1].isNumber());

	int mainMenuIndex = (int)args[0].asNumber();
	int subMenuIndex = (int)args[1].asNumber();
	IData *data = control->DataSource()->SubMenuData(mainMenuIndex, subMenuIndex);

	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return ScriptObject(wrapExistingNativeObject(data));
}

ScriptObject FirstScreenControlBridge::m_ScrollMenuData(IActor* self, const ScriptArray& args)
{
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT(NULL != control);
	ASSERT(2 == args.Length() && true == args[0].isNumber() && true == args[1].isNumber());

	int mainMenuIndex = (int)args[0].asNumber();
	int scrollIndex = (int)args[1].asNumber();
	IData *data = control->DataSource()->ScrollData(mainMenuIndex, scrollIndex);

	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return ScriptObject(wrapExistingNativeObject(data));
}

ScriptObject FirstScreenControlBridge::m_SetFocusRange(IActor* self, const ScriptArray& args)
{
	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	IFirstScreenListControl *control = dynamic_cast<IFirstScreenListControl*>(self);
	ASSERT(NULL != control);
	ASSERT(2 == args.Length() && true == args[0].isNumber() && true == args[1].isNumber());

	TMargin margin;
	margin.Set(0, 0, (float)args[0].asNumber(), (float)args[1].asNumber());
	control->SetFocusMargin(margin);

	PRINT("FirstScreenControlBridge::%s, %d\n",__FUNCTION__, __LINE__);
	return ScriptObject();
}
