#include "Halo1_0.h"
#include "ActorGraphics.h"

ActorGraphics::ActorGraphics()
{
	t_realActor = new CActor;
}

ActorGraphics::~ActorGraphics()
{
	delete t_realActor;
	t_realActor = NULL;
}

bool ActorGraphics::Initialize(IActor* parent, float width, float height)
{
	return t_realActor->Initialize(parent, width, height);
}

bool ActorGraphics::Initialize(IActor* parent, TWindowAttr *attr)
{
	return t_realActor->Initialize(parent, attr);
}

bool ActorGraphics::Initialize(void)
{
	return t_realActor->Initialize();
}

bool ActorGraphics::Initialize(RemotePtr<ActorGraphics> parent, float width, float height)
{
	ActorGraphics *p = parent.getPtr();
	if (p == NULL)
		return t_realActor->Initialize(NULL, width, height);
	else
		return t_realActor->Initialize(p->t_realActor, width, height);
}

void ActorGraphics::SetParent(IActor* parent)
{
	t_realActor->SetParent(parent);
}

void ActorGraphics::SetParent(RemotePtr<ActorGraphics> parent)
{
	ActorGraphics *p = parent.getPtr();
	if (p == NULL)
		t_realActor->SetParent(NULL);
	else
		t_realActor->SetParent(p->t_realActor);
}

IActor* ActorGraphics::Parent(void) const
{
	return t_realActor->Parent();
}

void ActorGraphics::SetBackgroundColor(const ClutterColor &color)
{
	t_realActor->SetBackgroundColor(color);
}

void ActorGraphics::SetBackgroundColor(guint8 r, guint8 g, guint8 b, guint8 a)
{
	ClutterColor c;
	clutter_color_init(&c, r, g, b, a);
	t_realActor->SetBackgroundColor(c);
}

void ActorGraphics::Resize(float width, float height)
{
	t_realActor->Resize(width, height);
}

void ActorGraphics::GetSize(float &width, float &height)
{
	t_realActor->GetSize(width, height);
}

Vector2 ActorGraphics::Size(void)
{
	float w, h;
	t_realActor->GetSize(w, h);
	return Vector2(w, h);
}

void ActorGraphics::SetPosition(float x, float y, float z)
{
	PRINT("%s ...%f, %f, %f\n",__FUNCTION__, x, y, z);
	t_realActor->SetPosition(x, y, z);
}

void ActorGraphics::SetPosition(float x, float y)
{
	PRINT("%s ...%f, %f\n",__FUNCTION__, x, y);
	t_realActor->SetPosition(x, y);
}

void ActorGraphics::GetPosition(float &x, float &y, float &z)
{
	t_realActor->GetPosition(x, y, z);
}

void ActorGraphics::GetPosition(float &x, float &y)
{
	t_realActor->GetPosition(x, y);
}

Vector3 ActorGraphics::Position(void)
{
	float x, y, z;
	t_realActor->GetPosition(x, y, z);

	return Vector3(x, y, z);
}

bool ActorGraphics::SetLayout(ILayout* layout)
{
	return t_realActor->SetLayout(layout);
}

ILayout* ActorGraphics::Layout(void)
{
	return t_realActor->Layout();
}

void ActorGraphics::SetOrientation(EOrientation orientation)
{
	t_realActor->SetOrientation(orientation);
}

HALO::EOrientation ActorGraphics::Orientation(bool flagReferParent)
{
	return t_realActor->Orientation(flagReferParent);
}

void ActorGraphics::Show(void)
{
	t_realActor->Show();
}

void ActorGraphics::Hide(void)
{
	t_realActor->Hide();
}

bool ActorGraphics::FlagShow(void)
{
	return t_realActor->FlagShow();
}

void ActorGraphics::SetClipArea(float x, float y, float width, float height)
{
	t_realActor->SetClipArea(x, y, width, height);
}

void ActorGraphics::GetClipArea(float &x, float &y, float &width, float &height)
{
	t_realActor->GetClipArea(x, y, width, height);
}

void ActorGraphics::RemoveClipArea(void)
{
	t_realActor->RemoveClipArea();
}

bool ActorGraphics::FlagClip(void)
{
	return t_realActor->FlagClip();
}

void ActorGraphics::SetAlpha(int alpha)
{
	t_realActor->SetAlpha(alpha);
}

int ActorGraphics::Alpha(void)
{
	return t_realActor->Alpha();
}

void ActorGraphics::SetPivotPoint(float xPivot, float yPivot, float zPivot)
{
	t_realActor->SetPivotPoint(xPivot, yPivot, zPivot);
}

void ActorGraphics::GetPivotPoint(float &xPivot, float &yPivot, float &zPivot)
{
	t_realActor->GetPivotPoint(xPivot, yPivot, zPivot);
}

void ActorGraphics::SetRotation(double xAngle, double yAngle, double zAngle)
{
	t_realActor->SetRotation(xAngle, yAngle, zAngle);
}

void ActorGraphics::GetRotation(double &xAngle, double &yAngle, double &zAngle)
{
	t_realActor->GetRotation(xAngle, yAngle, zAngle);
}

void ActorGraphics::SetScale(double xFactor, double yFactor, double zFactor)
{
	t_realActor->SetScale(xFactor, yFactor, zFactor);
}

void ActorGraphics::GetScale(double &xFactor, double &yFactor, double &zFactor)
{
	t_realActor->GetScale(xFactor, yFactor, zFactor);
}

void ActorGraphics::AddEffect(IEffect* effect)
{
	t_realActor->AddEffect(effect);
}

void ActorGraphics::RemoveEffect(IEffect* effect)
{
	t_realActor->RemoveEffect(effect);
}

void ActorGraphics::ClearEffects(void)
{
	t_realActor->ClearEffects();
}

void ActorGraphics::AddChild(ClutterActor *actor)
{
	t_realActor->AddChild(actor);
}

void ActorGraphics::AddChild(RemotePtr<WidgetGraphics> widget)
{
	ClutterActor* actor = widget->getAnimationActor();
	AddChild(actor);
}

int ActorGraphics::NumOfChildren(void)
{
	return t_realActor->NumOfChildren();
}

IActor* ActorGraphics::GetChild(int index)
{
	return t_realActor->GetChild(index);
}

void ActorGraphics::DestroyAllChildren(void)
{
	return t_realActor->DestroyAllChildren();
}

bool ActorGraphics::Raise(IActor* sibling)
{
	return t_realActor->Raise(sibling);
}

bool ActorGraphics::Raise(RemotePtr<ActorGraphics> sibling)
{
	return Raise(sibling.getPtr());
}

bool ActorGraphics::Lower(IActor* sibling)
{
	return t_realActor->Lower(sibling);
}

bool ActorGraphics::Lower(RemotePtr<ActorGraphics> sibling)
{
	return Lower(sibling.getPtr());
}

void ActorGraphics::Enable(bool flagEnable)
{
	t_realActor->Enable(flagEnable);
}

bool ActorGraphics::IsEnabled(void)
{
	return t_realActor->IsEnabled();
}

void ActorGraphics::EnablePointerFocus(bool enable)
{
	t_realActor->EnablePointerFocus(enable);
}

bool ActorGraphics::IsPointerFocusEnabled(void)
{
	return t_realActor->IsPointerFocusEnabled();
}

void ActorGraphics::EnableFocus(bool flagFocusable)
{
	t_realActor->EnableFocus(flagFocusable);
}

bool ActorGraphics::IsFocusEnabled(void)
{
	return t_realActor->IsFocusEnabled();
}

bool ActorGraphics::SetFocus(void)
{
	return t_realActor->SetFocus();
}

bool ActorGraphics::KillFocus(bool autoFocus /*= true*/)
{
	return t_realActor->KillFocus(autoFocus);
}

bool ActorGraphics::IsFocused(void)
{
	return t_realActor->IsFocused();
}

void ActorGraphics::SetTabWindow(EDirection dir, IActor* tabWindow)
{
	t_realActor->SetTabWindow(dir, tabWindow);
}

IActor* ActorGraphics::TabWindow(EDirection dir)
{
	return t_realActor->TabWindow(dir);
}

bool ActorGraphics::MoveTab(EDirection dir)
{
	return t_realActor->MoveTab(dir);
}

void ActorGraphics::EnableDragDrop(bool flagEnable)
{
	t_realActor->EnableDragDrop(flagEnable);
}

bool ActorGraphics::FlagDragDrop(void)
{
	return t_realActor->FlagDragDrop();
}

void ActorGraphics::GrabDeviceEvent(IDevice* device)
{
	return t_realActor->GrabDeviceEvent(device);
}

void ActorGraphics::UnGrabDeviceEvent(IDevice* device)
{
	return t_realActor->UnGrabDeviceEvent(device);
}

bool ActorGraphics::FlagAcceptInput(void)
{
	return t_realActor->FlagAcceptInput();
}

bool ActorGraphics::AddFocusListener(IFocusListener* pListener)
{
	return t_realActor->AddFocusListener(pListener);
}

bool ActorGraphics::RemoveFocusListener(IFocusListener* pListener)
{
	return t_realActor->RemoveFocusListener(pListener);
}

bool ActorGraphics::AddMouseListener(IMouseListener* pAddListener)
{
	return t_realActor->AddMouseListener(pAddListener);
}

bool ActorGraphics::RemoveMouseListener(IMouseListener* pRemoveListener)
{
	return t_realActor->RemoveMouseListener(pRemoveListener);
}

bool ActorGraphics::AddTouchListener(ITouchListener* pAddListener)
{
	return t_realActor->AddTouchListener(pAddListener);
}

bool ActorGraphics::RemoveTouchListener(ITouchListener* pRemoveListener)
{
	return t_realActor->RemoveTouchListener(pRemoveListener);
}

bool ActorGraphics::AddKeyboardListener(IKeyboardListener* pAddListener)
{
	return t_realActor->AddKeyboardListener(pAddListener);
}

bool ActorGraphics::RemoveKeyboardListener(IKeyboardListener* pRemoveListener)
{
	return t_realActor->RemoveKeyboardListener(pRemoveListener);
}

bool ActorGraphics::AddAudioListener(IAudioListener* pAddListener)
{
	return true;
}

bool ActorGraphics::RemoveAudioListener(IAudioListener* pRemoveListener)
{
	return true;
}

bool ActorGraphics::AddRemoteControlListener(IRemoteControlListener* pAddListener)
{
	return true;
}

bool ActorGraphics::RemoveRemoteControlListener(IRemoteControlListener* pRemoveListener)
{
	return true;
}

bool ActorGraphics::AddRidgeListener(IRidgeListener* pAddListener)
{
	return true;
}

bool ActorGraphics::RemoveRidgeListener(IRidgeListener* pRemoveListener)
{
	return true;
}

bool ActorGraphics::AddCursorStateChangeListener(ICursorListener* pAddListener)
{
	return true;
}

bool ActorGraphics::RemoveCursorStateChangeListener(ICursorListener* pRemoveListener)
{
	return true;
}

bool ActorGraphics::AddClickListener(IClickListener* pAddListener)
{
	return true;
}

bool ActorGraphics::RemoveClickListener(IClickListener* pRemoveListener)
{
	return true;
}

bool ActorGraphics::AddSemanticEventListener(ISemanticEventListener* pAddListener)
{
	return true;
}

bool ActorGraphics::RemoveSemanticEventListener(ISemanticEventListener* pRemoveListener)
{
	return true;
}

bool ActorGraphics::AddAction(IAction* pAction)
{
	return true;
}

bool ActorGraphics::RemoveAction(IAction* pAction)
{
	return true;
}

bool ActorGraphics::AddDragListener(IDragListener* pAddListener)
{
	return true;
}

bool ActorGraphics::RemoveDragListener(IDragListener* pRemoveListener)
{
	return true;
}

bool ActorGraphics::AddGestureListener(IGestureListener* pAddListener)
{
	return true;
}

bool ActorGraphics::RemoveGestureListener(IGestureListener* pRemoveListener)
{
	return true;
}

bool ActorGraphics::AddKeyLongPressListener(IKeyLongPressListener* pAddListener)
{
	return true;
}

bool ActorGraphics::RemoveKeyLongPressListener(IKeyLongPressListener* pRemoveListener)
{
	return true;
}

bool ActorGraphics::AddKeyCombinationListener(IKeyCombinationListener* pAddListener)
{
	return true;
}

bool ActorGraphics::RemoveKeyCombinationListener(IKeyCombinationListener* pRemoveListener)
{
	return true;
}

bool ActorGraphics::BindTransition(ITransition *transition, int animationType)
{
	PRINT("%s implemented!\n",__FUNCTION__);
	return t_realActor->BindTransition(transition, animationType);
}

bool ActorGraphics::BindTransition(RemotePtr<TransitionGraphics> transition, int animationType)
{
	PRINT("%s implemented!\n",__FUNCTION__);
	TransitionGraphics *p = transition.getPtr();
	return t_realActor->BindTransition(p->t_realTransition, animationType);
}

bool ActorGraphics::IsInitialized(void) const
{
	return t_realActor->IsInitialized();
}
