#include "Halo1_0.h"
#include "HaloImageProxy.h"

using namespace HALO;

HaloImageProxy::HaloImageProxy()
{
	//Get the universal ID of the graphics process
	std::string targetProcess = VoltMessageCenter::Instance().GfxProcessID();
	//Remote ptr has a convience method for calling the remote constructors
	imageGraphics = RemotePtr<HaloImageGraphics>::construct(targetProcess, HaloImageMsg::M_Create());

	graphics = imageGraphics;
}

void HaloImageProxy::SetImage(const char *imagePath)
{
	printf("%s NOT implemented!\n", __FUNCTION__);
}

void HaloImageProxy::SetImage(IImageBuffer *buffer)
{
	PRINT("HaloImageProxy::%s, %d\n",__FUNCTION__, __LINE__);
	CImageBuffer *buf = dynamic_cast<CImageBuffer*>(buffer);
	imageGraphics.post(HaloImageMsg::M_SetImage(), RemotePtr<CImageBuffer>(buf));
	PRINT("HaloImageProxy::%s, %d\n",__FUNCTION__, __LINE__);
}

IImageBuffer* HaloImageProxy::ImageBuffer(void)
{
	//return imageGraphics.execute<IImageBuffer*>(HaloImageMsg::M_GetImageBuf);
	printf("%s NOT implemented!\n", __FUNCTION__);
	return NULL;
}

void HaloImageProxy::SetGravity(ClutterContentGravity gravity)
{
	printf("%s NOT implemented!\n", __FUNCTION__);
}

ClutterContentGravity HaloImageProxy::Gravity(void)
{
	printf("%s NOT implemented!\n", __FUNCTION__);
}
