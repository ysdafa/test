#include "Halo1_0.h"
#include "HaloImageGraphics.h"

using namespace HALO;

HaloImageMessages HaloImageMessages::s_wgm;

DEF_SERIALIZE_REMOTE_CTOR(HaloImageGraphics, ImageX)
DEF_SERIALIZE_REMOTE_METHOD(HaloImageGraphics, ImageA, RemotePtr<CImageBuffer>)
DEF_SERIALIZE_REMOTE_METHOD(HaloImageGraphics, ImageB)


void HaloImageMessages::registerMessages()
{
  // Register constructor
	registerConstructor < HaloImageGraphics >(HaloImageMsg::M_Create());

	registerMethod<HaloImageGraphics, RemotePtr<CImageBuffer> >(HaloImageMsg::M_SetImage(), &HaloImageGraphics::SetImage);
	//registerReturningMethod<HaloImageGraphics, IImageBuffer* >(HaloImageMsg::M_GetImageBuf(), &HaloImageGraphics::ImageBuffer);
}

HaloImageGraphics::HaloImageGraphics(void)
{
	if (t_realActor != NULL)
		delete t_realActor;
	t_realImage= new CImage();

	t_realActor = t_realImage;
}

HaloImageGraphics::~HaloImageGraphics(void)
{
}

void HaloImageGraphics::SetImage(const char *imagePath)
{
	printf("HaloImageGraphics::%s NOT implemented!\n", __FUNCTION__);
}

void HaloImageGraphics::SetImage(IImageBuffer *buffer)
{
	printf("HaloImageGraphics::%s NOT implemented!\n", __FUNCTION__);
}

void HaloImageGraphics::SetImage(RemotePtr<CImageBuffer> buffer)
{
	t_realImage->SetImage(buffer.getPtr());
}

IImageBuffer* HaloImageGraphics::ImageBuffer(void)
{
	return t_realImage->ImageBuffer();
}

//RemotePtr<IImageBuffer> HaloImageGraphics::ImageBuffer(void)
//{
//	return RemotePtr<IImageBuffer>(t_realImage->ImageBuffer());
//}

void HaloImageGraphics::SetGravity(ClutterContentGravity gravity)
{
	t_realImage->SetGravity(gravity);
}

ClutterContentGravity HaloImageGraphics::Gravity(void)
{
	return t_realImage->Gravity();
}
