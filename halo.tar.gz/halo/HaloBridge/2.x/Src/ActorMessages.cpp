//#include "ActorMessages.h"
//#include "Halo.h"
#include "Halo1_0.h"

using namespace HALO;

ActorMessages ActorMessages::s_wgm;

DEF_SERIALIZE_REMOTE_CTOR(ActorGraphics, ActorX)
DEF_SERIALIZE_REMOTE_METHOD(ActorGraphics, ActorA, RemotePtr<ActorGraphics>, float, float)
DEF_SERIALIZE_REMOTE_METHOD(ActorGraphics, ActorC, guint8, guint8, guint8, guint8)
DEF_SERIALIZE_REMOTE_METHOD(ActorGraphics, ActorB)
DEF_SERIALIZE_REMOTE_METHOD(ActorGraphics, ActorD, float, float, float)
//DEF_SERIALIZE_REMOTE_METHOD(ActorGraphics, ActorF, float&, float&, float&)
DEF_SERIALIZE_REMOTE_METHOD(ActorGraphics, ActorE, bool)
DEF_SERIALIZE_REMOTE_METHOD(ActorGraphics, ActorG, RemotePtr<ActorGraphics>)
DEF_SERIALIZE_REMOTE_METHOD(ActorGraphics, ActorH, float, float, float, float)
DEF_SERIALIZE_REMOTE_METHOD(ActorGraphics, ActorI, double, double, double)
DEF_SERIALIZE_REMOTE_METHOD(ActorGraphics, ActorJ, RemotePtr<WidgetGraphics>)
DEF_SERIALIZE_REMOTE_METHOD(ActorGraphics, ActorK, RemotePtr<TransitionGraphics>, int)
DEF_SERIALIZE_REMOTE_METHOD(ActorGraphics, ActorL, float, float)
DEF_SERIALIZE_REMOTE_METHOD(ActorGraphics, ActorM, int)
DEF_SERIALIZE_REMOTE_METHOD(ActorGraphics, ActorN, EOrientation)


void ActorMessages::registerMessages()
{
  // Register constructor
	registerConstructor < ActorGraphics >(ActorMsg::M_Create());

	registerReturningMethod<ActorGraphics, bool, RemotePtr<ActorGraphics>, float, float>(ActorMsg::M_Initialize(), &ActorGraphics::Initialize);
	registerMethod<ActorGraphics, guint8, guint8, guint8, guint8>(ActorMsg::M_SetBackground(), &ActorGraphics::SetBackgroundColor);
	registerMethod(ActorMsg::M_Show(), &ActorGraphics::Show);
	registerMethod(ActorMsg::M_Hide(), &ActorGraphics::Hide);
	registerMethod<ActorGraphics, float, float, float>(ActorMsg::M_SetPosition(), &ActorGraphics::SetPosition);
	registerReturningMethod<ActorGraphics, Vector3>(ActorMsg::M_GetPosition(), &ActorGraphics::Position);
	registerReturningMethod<ActorGraphics, bool, RemotePtr<ActorGraphics> >(ActorMsg::M_Raise(), &ActorGraphics::Raise);
	registerReturningMethod<ActorGraphics, bool, RemotePtr<ActorGraphics> >(ActorMsg::M_Lower(), &ActorGraphics::Lower);
	registerMethod(ActorMsg::M_Enable(), &ActorGraphics::Enable);
	registerMethod(ActorMsg::M_EnableFocus(), &ActorGraphics::EnableFocus);
	registerMethod(ActorMsg::M_EenablePointerFocus(), &ActorGraphics::EnablePointerFocus);
	registerReturningMethod<ActorGraphics, bool>(ActorMsg::M_SetFocus(), &ActorGraphics::SetFocus);
	registerMethod(ActorMsg::M_SetClipArea(), &ActorGraphics::SetClipArea);
	registerMethod(ActorMsg::M_SetScale(), &ActorGraphics::SetScale);
	registerMethod(ActorMsg::M_SetRotation(), &ActorGraphics::SetRotation);
	registerMethod<ActorGraphics, RemotePtr<WidgetGraphics> >(ActorMsg::M_AddChild(), &ActorGraphics::AddChild);
	registerReturningConstMethod<ActorGraphics, bool>(ActorMsg::M_IsInitialized(), &ActorGraphics::IsInitialized);
	registerReturningMethod<ActorGraphics, bool, RemotePtr<TransitionGraphics>, int>(ActorMsg::M_BindTransition(), &ActorGraphics::BindTransition);
	registerMethod(ActorMsg::M_SetSize(), &ActorGraphics::Resize);
	registerMethod(ActorMsg::M_SetPivotPoint(), &ActorGraphics::SetPivotPoint);
	registerReturningMethod<ActorGraphics, Vector2>(ActorMsg::M_GetSize(), &ActorGraphics::Size);
	registerMethod(ActorMsg::M_SetAlpha(), &ActorGraphics::SetAlpha);
	registerReturningMethod<ActorGraphics, int>(ActorMsg::M_GetAlpha(), &ActorGraphics::Alpha);
	registerReturningMethod<ActorGraphics, bool>(ActorMsg::M_FlagShow(), &ActorGraphics::FlagShow);
	registerMethod(ActorMsg::M_SetOrientation(), &ActorGraphics::SetOrientation);
	registerReturningMethod<ActorGraphics, EOrientation>(ActorMsg::M_GetOrientation(), &ActorGraphics::Orientation);
	registerMethod<ActorGraphics, RemotePtr<ActorGraphics> >(ActorMsg::M_SetParent(), &ActorGraphics::SetParent);
}
