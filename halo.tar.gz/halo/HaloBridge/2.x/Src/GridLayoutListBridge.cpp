#include "Halo1_0.h"
#include "GridLayoutListBridge.h"
#include "ScriptBridge.h"
#include "ActorBridge.h"
#include "RenderBridge.h"
#include "Widget.h"

using namespace Bridge;
using namespace HALO;

#if 1 == DEBUG_TEST
#define KEY_LEFT	65361
#define KEY_RIGHT	65363
#define KEY_UP		65362
#define KEY_DOWN	65364
#define KEY_NUM_1   49
#define KEY_NUM_2   50
#define KEY_NUM_3   51

bool GridLayoutListBridge::OnKeyPressed(IActor* pThis, IKeyboardEvent* event)
{
	IGridListControl *control = dynamic_cast<IGridListControl*>(pThis);

	EDirection direction = DIRECTION_MAX;
	int keyVal = event->GetKeyVal();

	switch (keyVal)
	{
	case KEY_LEFT:
		direction = DIRECTION_LEFT;
		control->MoveFocus(direction);
		break;

	case KEY_UP:
		direction = DIRECTION_UP;
		control->MoveFocus(direction);
		break;

	case KEY_RIGHT:
		direction = DIRECTION_RIGHT;
		control->MoveFocus(direction);
		break;

	case KEY_DOWN:
		direction = DIRECTION_DOWN;
		control->MoveFocus(direction);
		break;

	case KEY_NUM_1:
		control->TransformStyle(0, 0);
		break;
	case KEY_NUM_2:
		control->TransformStyle(0, 1);
		break;
	case KEY_NUM_3:
		control->TransformStyle(0, 2);
		break;
	default:
		break;
	}

	return true;
}
#endif

bool GridLayoutListBridge::OnItemLoaded(class IGridListControl* list, int groupIndex, int itemIndex)
{
	ScriptArray args;

	args.set(0, ScriptObject((int)ITEM_LOAD));
	args.set(1, wrapExistingNativeObject(list));
	args.set(2, ScriptObject(groupIndex));
	args.set(3, ScriptObject(itemIndex));

	t_listListenerCallback.invoke(args);
	return true;
}

bool GridLayoutListBridge::OnItemUnloaded(class IGridListControl* list, int groupIndex, int itemIndex)
{
	ScriptArray args;
	args.set(0, ScriptObject((int)ITEM_UNLOAD));
	args.set(1, wrapExistingNativeObject(list));
	args.set(2, ScriptObject(groupIndex));
	args.set(3, ScriptObject(itemIndex));

	t_listListenerCallback.invoke(args);

	return true;
}

bool GridLayoutListBridge::OnAsyncItemLoad(class IGridListControl *list, int groupIndex, int itemIndex)
{
	ScriptArray args;
	args.set(0, ScriptObject((int)ITEM_ASYNC_LOAD));
	args.set(1, wrapExistingNativeObject(list));
	args.set(2, ScriptObject(groupIndex));
	args.set(3, ScriptObject(itemIndex));

	t_listListenerCallback.invoke(args);

	return true;
}

bool GridLayoutListBridge::OnFocusChanged(class IGridListControl *list, int fromGroupIndex, int fromItemIndex, int toGroupIndex, int toItemIndex)
{
	ScriptArray args;
	args.set(0, ScriptObject((int)FOCUS_CHANGE));
	args.set(1, wrapExistingNativeObject(list));
	args.set(2, ScriptObject(fromGroupIndex));
	args.set(3, ScriptObject(fromItemIndex));
	args.set(4, ScriptObject(toGroupIndex));
	args.set(5, ScriptObject(toItemIndex));

	t_listListenerCallback.invoke(args);

	return true;
}

bool GridLayoutListBridge::OnFocusChangeMotionStart(class IGridListControl* list, int fromGroupIndex, int fromItemIndex, int toGroupIndex, int toItemIndex)
{
	ScriptArray args;
	args.set(0, ScriptObject((int)FOCUS_CHANGE_START));
	args.set(1, wrapExistingNativeObject(list));
	args.set(2, ScriptObject(fromGroupIndex));
	args.set(3, ScriptObject(fromItemIndex));
	args.set(4, ScriptObject(toGroupIndex));
	args.set(5, ScriptObject(toItemIndex));

	t_listListenerCallback.invoke(args);

	return true;
}

bool GridLayoutListBridge::OnMoveOut(class IGridListControl* list, EDirection direction, int fromGroupIndex, int fromItemIndex)
{
	ScriptArray args;
	args.set(0, ScriptObject((int)MOVE_OUT));
	args.set(1, wrapExistingNativeObject(list));
	args.set(2, ScriptObject((int)direction));
	args.set(3, ScriptObject(fromItemIndex));
	args.set(4, ScriptObject(fromItemIndex));

	t_listListenerCallback.invoke(args);

	return true;
}

bool GridLayoutListBridge::OnItemIndexChanged(class IGridListControl* list, int fromGroupIndex, int fromItemIndex, int toGroupIndex, int toItemIndex)
{
	ScriptArray args;
	args.set(0, ScriptObject((int)ITEM_INDEX_CHANGE));
	args.set(1, wrapExistingNativeObject(list));
	args.set(2, ScriptObject(fromGroupIndex));
	args.set(3, ScriptObject(fromItemIndex));
	args.set(4, ScriptObject(toGroupIndex));
	args.set(5, ScriptObject(toItemIndex));

	t_listListenerCallback.invoke(args);

	return true;
}

void GridLayoutListBridge::mapScriptInterface(ScriptContext& context)
{
	PRINT("GridLayoutListBridge::Function %s, context 0x%x\n", __FUNCTION__, &context);
	DataListBridge::mapScriptInterface(context);
 	context.captureMethodCall<IActor, &addGroup>("addGroup");
 	context.captureMethodCall<IActor, &addStyle>("addStyle");
 	context.captureMethodCall<IActor, &addColumn>("addColumn");
 	context.captureMethodCall<IActor, &addRowToColumn>("addRowToColumn");
 	context.captureMethodCall<IActor, &addRowToAllColumn>("addRowToAllColumn");
	context.captureMethodCall<IActor, &mergeCells>("mergeCells");
	context.captureMethodCall<IActor, &setGroupStyle>("setGroupStyle");
	context.captureMethodCall<IActor, &transformStyle>("transformStyle");
	context.captureMethodCall<IActor, &transformAllGroupStyle>("transformAllGroupStyle");
	context.captureMethodCall<IActor, &m_EnlargeFocusItem>("enlargeFocusItem");
	context.captureMethodCall<IActor, &setFocusItemIndex>("setFocusItemIndex");
	context.captureMethodCall<IActor, &setAnimationDuration>("setAnimationDuration");

	context.captureMethodCall<IActor, &addDataGroup>("addDataGroup");
	context.captureMethodCall<IActor, &addData>("addData");
	context.captureMethodCall<IActor, &getData>("getData");

	context.captureMethodCall<IActor, &moveFocus>("moveFocus");
}

IDataListControl* GridLayoutListBridge::constructSubWidget(IActor* parent, float width, float height, const ScriptArray& args)
{
	PRINT("Function GridLayoutListBridge::%s, args length is %d, width %3.2f, height %3.2f\n", __FUNCTION__, args.Length(), width, height);

	IGridListControl::TGridListControlAttr attr(width, height);
	
	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber())
		{
			attr.titleHeight = args[0].asNumber();
		}
		
		if(args.has(1) && args[1].isNumber())
		{
			attr.titleSpace = args[1].asNumber();
		}
		
		if(args.has(2) && args[2].isNumber())
		{
			attr.groupSpace = args[2].asNumber();
		}
		
		if(args.has(3) && args[3].isNumber())
		{
			attr.cellSpace = args[3].asNumber();
		}
		
		if(args.has(4) && args[4].isNumber())
		{
			attr.focusRangeOffset[0] = args[4].asNumber();
		}
		
		if(args.has(5) && args[5].isNumber())
		{
			attr.focusRangeOffset[1] = args[5].asNumber();
		}
	}

	IGridListControl *control;
	IGridListControl::CreateInstance(&control);

	control->Initialize(parent, &attr);

	control->AddListListener(this);

#if 1 == DEBUG_TEST
	control->AddKeyboardListener(this);
#endif
	
	return control;
}

void GridLayoutListBridge::destroyFromScript(void* destroyedObject)
{
	DataListBridge::destroyFromScript(destroyedObject);
}

ScriptObject GridLayoutListBridge::addGroup(IActor* self, const ScriptArray& args)
{
	IGridListControl *control = dynamic_cast<IGridListControl*>(self);
	PRINT("GridLayoutListBridge::AddGroup self 0x%x, args length %d\n", self, args.Length());
	int numberOfGroup = 1;

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber())
		{
			numberOfGroup = args[0].asNumber();
		}
	}
	PRINT("numberOfGroup is %d\n", numberOfGroup);
	control->AddGroup(numberOfGroup);
	PRINT("Add Group finish\n");
	return ScriptObject();
}

ScriptObject GridLayoutListBridge::addStyle(IActor* self, const ScriptArray& args)
{
	IGridListControl *control = dynamic_cast<IGridListControl*>(self);
	PRINT("GridLayoutListBridge::AddStyle self 0x%x, args length %d\n", self, args.Length());
	int numOfStyle;

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber())
		{
			numOfStyle = args[0].asNumber();
		}
	}
	PRINT("numOfStyle is %d\n", numOfStyle);
	bool ret = control->AddStyle(numOfStyle);
	PRINT("Add Style finish\n");
	return ScriptObject(ret);
}

ScriptObject GridLayoutListBridge::addColumn(IActor* self, const ScriptArray& args)
{
	IGridListControl *control = dynamic_cast<IGridListControl*>(self);
	PRINT("GridLayoutListBridge::AddColumn, args length is %d, self is 0x%x\n", args.Length(), self);
	int groupIndex, styleIndex, columnWidth;

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber())
		{
			groupIndex = args[0].asNumber();
		}
		
		if(args.has(1) && args[1].isNumber())
		{
			styleIndex = args[1].asNumber();
		}
		
		if(args.has(2) && args[2].isNumber())
		{
			columnWidth = args[2].asNumber();
		}
	}

	return ScriptObject(control->AddColumn(groupIndex, styleIndex, columnWidth));
}

ScriptObject GridLayoutListBridge::addRowToColumn(IActor* self, const ScriptArray& args)
{
	IGridListControl *control = dynamic_cast<IGridListControl*>(self);
	PRINT("Function %s, args length is %d, self is 0x%x\n", __FUNCTION__, args.Length(), self);
	int groupIndex, styleIndex, columnIndex, rowHeight;

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber())
		{
			groupIndex = args[0].asNumber();
		}
		
		if(args.has(1) && args[1].isNumber())
		{
			styleIndex = args[1].asNumber();
		}
		
		if(args.has(2) && args[2].isNumber())
		{
			columnIndex = args[2].asNumber();
		}
		
		if(args.has(3) && args[3].isNumber())
		{
			rowHeight = args[3].asNumber();
		}
	}

	return ScriptObject(control->AddRowToColumn(groupIndex, styleIndex, columnIndex, rowHeight));
}

ScriptObject GridLayoutListBridge::addRowToAllColumn(IActor* self, const ScriptArray& args)
{
	PRINT("Function %s, args length is %d, self is 0x%x\n", __FUNCTION__, args.Length(), self);
	IGridListControl *control = dynamic_cast<IGridListControl*>(self);
	ASSERT(NULL != control);
	ASSERT(3 == args.Length());
	ASSERT(true == args[0].isNumber() && true == args[1].isNumber() && true == args[2].isNumber());

	int groupIndex = args[0].asNumber();
	int styleIndex = args[1].asNumber();
	int rowHeight = args[2].asNumber();

	return ScriptObject(control->AddRowToAllColumn(groupIndex, styleIndex, rowHeight));
}

ScriptObject GridLayoutListBridge::mergeCells(IActor* self, const ScriptArray& args)
{
	IGridListControl *control = dynamic_cast<IGridListControl*>(self);
	int groupIndex, styleIndex, startRow, startCol, endRow, endCol;
	PRINT("Function %s, args length is %d, self is 0x%x\n", __FUNCTION__, args.Length(), self);

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber())
		{
			groupIndex = args[0].asNumber();
		}
		
		if(args.has(1) && args[1].isNumber())
		{
			styleIndex = args[1].asNumber();
		}
		
		if(args.has(2) && args[2].isNumber())
		{
			startRow = args[2].asNumber();
		}
		
		if(args.has(3) && args[3].isNumber())
		{
			startCol = args[3].asNumber();
		}
		
		if(args.has(4) && args[4].isNumber())
		{
			endRow = args[4].asNumber();
		}
		
		if(args.has(5) && args[5].isNumber())
		{
			endCol = args[5].asNumber();
		}
	}

	return ScriptObject(control->MergeCells(groupIndex, styleIndex, startRow, startCol, endRow, endCol));
}

ScriptObject GridLayoutListBridge::setGroupStyle(IActor* self, const ScriptArray& args)
{
	PRINT("Function %s, args length is %d, self is 0x%x\n", __FUNCTION__, args.Length(), self);
	IGridListControl *control = dynamic_cast<IGridListControl*>(self);
	int groupIndex, styleIndex;

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber())
		{
			groupIndex = args[0].asNumber();
		}

		if(args.has(1) && args[1].isNumber())
		{
			styleIndex = args[1].asNumber();
		}
	}

	return ScriptObject(control->SetGroupStyle(groupIndex, styleIndex));
}

ScriptObject GridLayoutListBridge::transformStyle(IActor* self, const ScriptArray& args)
{
	PRINT("Function %s, args length is %d, self is 0x%x\n", __FUNCTION__, args.Length(), self);
	IGridListControl *control = dynamic_cast<IGridListControl*>(self);
	ASSERT(NULL != control);
	ASSERT(2 == args.Length() && true == args[0].isNumber() && true == args[1].isNumber());

	int groupIndex = (int)args[0].asNumber();
	int styleIndex = (int)args[1].asNumber();

	control->TransformStyle(groupIndex, styleIndex);

	return ScriptObject();
}

ScriptObject GridLayoutListBridge::transformAllGroupStyle(IActor* self, const ScriptArray& args)
{
	IGridListControl *control = dynamic_cast<IGridListControl*>(self);
	PRINT("Function %s, args length is %d, self is 0x%x\n", __FUNCTION__, args.Length(), self);
	int toStyleIndex;

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber())
		{
			toStyleIndex = args[0].asNumber();
		}
	}

	control->TransformAllGroupStyle(toStyleIndex);

	return ScriptObject();
}

ScriptObject GridLayoutListBridge::m_EnlargeFocusItem(IActor* self, const ScriptArray& args)
{
	IGridListControl *control = dynamic_cast<IGridListControl*>(self);
	ASSERT(NULL != control);
	ASSERT(2 == args.Length() && true == args[0].isNumber() && true == args[1].isNumber());

	float enlargeWidth = (float)args[0].asNumber();
	float enlargeHeight = (float)args[1].asNumber();

	control->EnlargeFocusedItem(enlargeWidth, enlargeHeight);
	return ScriptObject();
}

ScriptObject GridLayoutListBridge::setFocusItemIndex(IActor* self, const ScriptArray& args)
{
	IGridListControl *control = dynamic_cast<IGridListControl*>(self);
	PRINT("Function %s, args length is %d, self is 0x%x\n", __FUNCTION__, args.Length(), self);
	int groupIndex, itemIndex;

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber())
		{
			groupIndex = args[0].asNumber();
		}
		
		if(args.has(1) && args[1].isNumber())
		{
			itemIndex = args[1].asNumber();
		}
	}

	control->SetFocusItemIndex(groupIndex, itemIndex);

	return ScriptObject();
}

ScriptObject GridLayoutListBridge::setAnimationDuration(IActor* self, const ScriptArray& args)
{
	PRINT("Function %s, args length is %d, self is 0x%x\n", __FUNCTION__, args.Length(), self);
	IGridListControl *control = dynamic_cast<IGridListControl*>(self);
	int duration;

	if(args.Length() > 0)
	{
		if(args.has(0) && args[0].isNumber())
		{
			duration = args[0].asNumber();
		}
	}

	control->SetAnimationDuration(duration);

	return ScriptObject();
}

ScriptObject GridLayoutListBridge::moveFocus(IActor* self, const ScriptArray& args)
{
	PRINT("Function %s, args length is %d, self is 0x%x\n", __FUNCTION__, args.Length(), self);
	IGridListControl *control = dynamic_cast<IGridListControl*>(self);
	ASSERT(NULL != control);
	ASSERT(1 == args.Length() && true == args[0].isNumber());

	int direction = (int)args[0].asNumber();
	ASSERT(DIRECTION_MAX > direction);

	PRINT("moveFocus %s, direction is %d\n", __FUNCTION__, direction);
	return ScriptObject(control->MoveFocus(EDirection(direction)));
}

ScriptObject GridLayoutListBridge::addDataGroup(IActor* self, const ScriptArray& args)
{
	PRINT("Function %s, args length is %d, self is 0x%x\n", __FUNCTION__, args.Length(), self);
	IGridListControl *control = dynamic_cast<IGridListControl*>(self);
	IGridDataSource* dataSource= control->DataSource();
	
	if (args.Length() > 0)
	{
		int groupIndex = -1;
		if(args.has(0) && args[0].isNumber())
		{
			groupIndex = args[0].asNumber();
		}

		dataSource->AddGroup(groupIndex);
	}

	return ScriptObject();
}

ScriptObject GridLayoutListBridge::addData(IActor* self, const ScriptArray& args)
{
	PRINT("Function %s, args length is %d, self is 0x%x\n", __FUNCTION__, args.Length(), self);
	IGridListControl *control = dynamic_cast<IGridListControl*>(self);
	IGridDataSource* dataSource= control->DataSource();
	
	if (args.Length() > 0)
	{
		int groupIndex = -1;
		if(args.has(0) && args[0].isNumber())
		{
			groupIndex = args[0].asNumber();
		}

		IData* data = unwrapNativeObject<IData>(args[1]);
		ASSERT(NULL != data);
		
		dataSource->AddData(groupIndex, data);
	}

	return ScriptObject();
}

ScriptObject GridLayoutListBridge::getData(IActor* self, const ScriptArray& args)
{
	PRINT("Function %s, args length is %d, self is 0x%x\n", __FUNCTION__, args.Length(), self);
	IGridListControl *control = dynamic_cast<IGridListControl*>(self);
	ASSERT(NULL != control);
	ASSERT(2 == args.Length() && true == args[0].isNumber() && true == args[1].isNumber());

	IGridDataSource* dataSource= control->DataSource();

	int groupIndex = (int)args[0].asNumber();
	int itemIndex = (int)args[1].asNumber();

	return wrapExistingNativeObject(control->DataSource()->GetData(groupIndex, itemIndex));
}


