#include "Halo1_0.h"
#include "TransitionProxy.h"

using namespace HALO;

#define FUNCTION_START PRINT("TransitionProxy::%s Start!\n",__FUNCTION__);
#define FUNCTION_DONE PRINT("TransitionProxy::%s Done!\n",__FUNCTION__);

TransitionProxy::TransitionProxy()
{
	FUNCTION_START
	//Get the universal ID of the graphics process
	std::string targetProcess = VoltMessageCenter::Instance().GfxProcessID();

	PRINT("targetProcess got!\n");
	
	//Remote ptr has a convience method for calling the remote constructors
	graphics = RemotePtr<TransitionGraphics>::construct(targetProcess, TransitionMsg::M_Create());

	FUNCTION_DONE
}

bool TransitionProxy::Initialize(bool flagCustomAnimation)
{
	FUNCTION_START
	return graphics.execute<bool>(TransitionMsg::M_Initialize(), flagCustomAnimation);
	FUNCTION_DONE
}

bool TransitionProxy::Initialize(void)
{
	FUNCTION_START
	return graphics.execute<bool>(TransitionMsg::M_Initialize(), false);
	FUNCTION_DONE
}

void TransitionProxy::SetDuration(int duration)
{
	FUNCTION_START
	graphics.post(TransitionMsg::M_SetDuration(), duration);
	FUNCTION_DONE
}

int TransitionProxy::Duration(void)
{
	FUNCTION_START
	return graphics.execute<int>(TransitionMsg::M_GetDuration());
	FUNCTION_DONE
}


void TransitionProxy::SetMode(ClutterAnimationMode animationMode)
{
	FUNCTION_START

	graphics.post(TransitionMsg::M_SetMode(), animationMode);
	
	FUNCTION_DONE
}

void TransitionProxy::Play(void)
{
	FUNCTION_START

	graphics.post(TransitionMsg::M_Play());
	FUNCTION_DONE
}

void TransitionProxy::SetDestination_New(int destValue)
{
	FUNCTION_START
	graphics.post(TransitionMsg::M_SetDurationNew1i(), destValue);
	FUNCTION_DONE
}

void TransitionProxy::SetDestination_New(float destValue)
{
	FUNCTION_START
	graphics.post(TransitionMsg::M_SetDurationNew1f(), destValue);
	FUNCTION_DONE
}

void TransitionProxy::SetDestination_New(float destValue1, float destValue2)
{
	FUNCTION_START
	graphics.post(TransitionMsg::M_SetDurationNew2f(), destValue1, destValue2);
	FUNCTION_DONE
}

void TransitionProxy::AddListener(ITimeLineListener *listener, void *userData)
{
	PRINT("TransitionProxy::%s\n", __FUNCTION__);
	TransitionListenerProxy *p = dynamic_cast<TransitionListenerProxy*>(listener);

	graphics.post(TransitionMsg::M_AddListener(), RemotePtr<TransitionListenerProxy>(p), (int)userData);
	PRINT("TransitionProxy::%s END\n", __FUNCTION__);
}

void TransitionProxy::RemoveListener(ITimeLineListener *listener, void* &userData)
{
	PRINT("TransitionProxy::%s\n", __FUNCTION__);
	TransitionListenerProxy *p = dynamic_cast<TransitionListenerProxy*>(listener);

	userData = (void*)graphics.execute<int>(TransitionMsg::M_RemoveListener(), RemotePtr<TransitionListenerProxy>(p));
	PRINT("TransitionProxy::%s END\n", __FUNCTION__);
}

void TransitionProxy::Stop(void)
{
	printf("%s NOT implemented!\n", __FUNCTION__);
}

void TransitionProxy::Pause(void)
{
	printf("%s NOT implemented!\n", __FUNCTION__);
}

bool TransitionProxy::IsInitialized(void) const
{
	printf("%s NOT implemented!\n", __FUNCTION__);
	return false;
}

bool TransitionProxy::IsPlaying(void)
{
	PRINT("TransitionProxy::%s\n", __FUNCTION__);
	return graphics.execute<bool>(TransitionMsg::M_IsPlaying());
}

Transition1iProxy::Transition1iProxy()
{
	FUNCTION_START
	//Get the universal ID of the graphics process
	std::string targetProcess = VoltMessageCenter::Instance().GfxProcessID();
	//Remote ptr has a convience method for calling the remote constructors
	trans1iGraphics = RemotePtr<Transition1iGraphics>::construct(targetProcess, Trans1iMsg::M_Create());

	graphics = trans1iGraphics;
	FUNCTION_DONE
}

void Transition1iProxy::SetDestination(int destValue)
{
	FUNCTION_START
	trans1iGraphics.post(Trans1iMsg::M_SetDestination(),destValue);
	FUNCTION_DONE
}

Transition1fProxy::Transition1fProxy()
{
	FUNCTION_START
	//Get the universal ID of the graphics process
	std::string targetProcess = VoltMessageCenter::Instance().GfxProcessID();
	//Remote ptr has a convience method for calling the remote constructors
	trans1fGraphics = RemotePtr<Transition1fGraphics>::construct(targetProcess, Trans1fMsg::M_Create());

	graphics = trans1fGraphics;
	FUNCTION_DONE
}

void Transition1fProxy::SetDestination(float destValue)
{
	FUNCTION_START

	trans1fGraphics.post(Trans1fMsg::M_SetDestination(),destValue);
	FUNCTION_DONE
}

Transition2fProxy::Transition2fProxy()
{
	FUNCTION_START
	//Get the universal ID of the graphics process
	std::string targetProcess = VoltMessageCenter::Instance().GfxProcessID();
	//Remote ptr has a convience method for calling the remote constructors
	trans2fGraphics = RemotePtr<Transition2fGraphics>::construct(targetProcess, Trans2fMsg::M_Create());

	graphics = trans2fGraphics;
	FUNCTION_DONE
}

void Transition2fProxy::SetDestination(float destValue, float destValue2)
{
	FUNCTION_START
	trans2fGraphics.post(Trans2fMsg::M_SetDestination(), destValue, destValue2);
	FUNCTION_DONE
}
