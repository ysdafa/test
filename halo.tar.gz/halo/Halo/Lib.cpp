#include "Halo1_0.h"
#include "LibImpl.h"
#ifdef WIN32
#include <process.h>
#else
#include <unistd.h>
#endif

namespace HALO
{
	FactorySet *g_factorySet = NULL;

	FactorySet& GetFactorySet()
	{
		// Exposing pointer address from an instance is illegal according to HALO rule
		return *g_factorySet;
	}

	Instance::Instance()
	{
		m_id.data1 = getpid(); //get pid
		m_id.data2 = (gulong)this; //get address
	}

	HIID Instance::ID()
	{
		return m_id;
	}
	void Instance::Release(void)
	{
		delete this;
	}

	Instance* Instance::CreateInstance(CLASS_ID classID)
	{
		HALO_ASSERT(g_factorySet != NULL);
		return g_factorySet->CreateInstanceFromFactory(classID);
	}


	FactorySet::FactorySet()
	{
		//m_factoryClasses.clear();
	}

	FactorySet::~FactorySet()
	{
		FactoryClass* fc = NULL;
		FactoryClassMap::iterator itor = m_factoryClasses.begin();
		while (itor != m_factoryClasses.end())
		{
			fc = itor->second;
			if (fc)
			{
				delete fc;
				fc = NULL;
			}
			itor++;
		}

		m_factoryClasses.clear();
	}

	void FactorySet::RegisterFactory(HALO::CLASS_ID classID, FactoryClass &factory)
	{
		m_factoryClasses.insert(std::pair<HALO::CLASS_ID, FactoryClass*>(classID, &factory));
	}

	Instance* FactorySet::CreateInstanceFromFactory(HALO::CLASS_ID classID)
	{
		Instance *ptr = NULL;

		FactoryClassMap::iterator it;
		it = m_factoryClasses.find(classID);

		if (it != m_factoryClasses.end())
		{
			ptr = dynamic_cast<Instance *>(((FactoryClass*)(it->second))->Instantiate());
		}

		return ptr;
	}

	//FactoryClassAction::FactoryClassAction()
	//{
	//}

	//FactoryClassAction::~FactoryClassAction()
	//{
	//}

	//Instance* FactoryClassAction::Instantiate()
	//{
	//	return new CAction;
	//}

	FactoryClassActor::FactoryClassActor()
	{
	}

	FactoryClassActor::~FactoryClassActor()
	{
	}

	Instance* FactoryClassActor::Instantiate()
	{
		return new CActor;
	}

	FactoryClassTimeLine::FactoryClassTimeLine()
	{
	}

	FactoryClassTimeLine::~FactoryClassTimeLine()
	{
	}

	Instance* FactoryClassTimeLine::Instantiate()
	{
		return new CTimeLine;
	}

	FactoryClassTransition::FactoryClassTransition()
	{
	}

	FactoryClassTransition::~FactoryClassTransition()
	{
	}

	Instance* FactoryClassTransition::Instantiate()
	{
		return new CTransition;
	}

	FactoryClassAsyncTask::FactoryClassAsyncTask()
	{
	}

	FactoryClassAsyncTask::~FactoryClassAsyncTask()
	{
	}

	Instance* FactoryClassAsyncTask::Instantiate()
	{
		return new CAsyncTask;
	}

	//FactoryClassBaseSelectButton::FactoryClassBaseSelectButton()
	//{
	//}

	//FactoryClassBaseSelectButton::~FactoryClassBaseSelectButton()
	//{
	//}

	//Instance* FactoryClassBaseSelectButton::Instantiate()
	//{
	//	return new CSelectButton;
	//}

	//FactoryClassBaseSelectButtonGroup::FactoryClassBaseSelectButtonGroup()
	//{
	//}

	//FactoryClassBaseSelectButtonGroup::~FactoryClassBaseSelectButtonGroup()
	//{
	//}

	//Instance* FactoryClassBaseSelectButtonGroup::Instantiate()
	//{
	//	return new CSelectButtonGroup;
	//}

	FactoryClassButton::FactoryClassButton()
	{
	}

	FactoryClassButton::~FactoryClassButton()
	{
	}

	Instance* FactoryClassButton::Instantiate()
	{
		return new CButton;
	}


	FactoryClassCheckBoxGroup::FactoryClassCheckBoxGroup()
	{
	}

	FactoryClassCheckBoxGroup::~FactoryClassCheckBoxGroup()
	{
	}

	Instance* FactoryClassCheckBoxGroup::Instantiate()
	{
		return new CCheckBoxGroup;
	}

	FactoryClassCompositeImage::FactoryClassCompositeImage()
	{
	}

	FactoryClassCompositeImage::~FactoryClassCompositeImage()
	{
	}

	Instance* FactoryClassCompositeImage::Instantiate()
	{
		return new CCompositeImage;
	}

	//FactoryClassDataListControl::FactoryClassDataListControl()
	//{
	//}

	//FactoryClassDataListControl::~FactoryClassDataListControl()
	//{
	//}

	//Instance* FactoryClassDataListControl::Instantiate()
	//{
	//	return new CDataListControl;
	//}

	//FactoryClassDataSource::FactoryClassDataSource()
	//{
	//}

	//FactoryClassDataSource::~FactoryClassDataSource()
	//{
	//}

	//Instance* FactoryClassDataSource::Instantiate()
	//{
	//	return new CDataSource;
	//}

	//FactoryClassDataType::FactoryClassDataType()
	//{
	//}

	//FactoryClassDataType::~FactoryClassDataType()
	//{
	//}

	//Instance* FactoryClassDataType::Instantiate()
	//{
	//	return new CDataType;
	//}

	FactoryClassDefaultWindow::FactoryClassDefaultWindow()
	{
	}

	FactoryClassDefaultWindow::~FactoryClassDefaultWindow()
	{
	}

	Instance* FactoryClassDefaultWindow::Instantiate()
	{
		return new CDefaultWindow;
	}

	//FactoryClassDevice::FactoryClassDevice()
	//{
	//}

	//FactoryClassDevice::~FactoryClassDevice()
	//{
	//}

	//Instance* FactoryClassDevice::Instantiate()
	//{
	//	return new CDevice;
	//}

	FactoryClassDeviceManager::FactoryClassDeviceManager()
	{
	}

	FactoryClassDeviceManager::~FactoryClassDeviceManager()
	{
	}

	Instance* FactoryClassDeviceManager::Instantiate()
	{
		return new CDeviceManager;
	}

	FactoryClassDesaturationEffect::FactoryClassDesaturationEffect()
	{
	}

	FactoryClassDesaturationEffect::~FactoryClassDesaturationEffect()
	{
	}

	Instance* FactoryClassDesaturationEffect::Instantiate()
	{
		return new CDesaturationEffect;
	}

	FactoryClassShadowEffect::FactoryClassShadowEffect()
	{
	}

	FactoryClassShadowEffect::~FactoryClassShadowEffect()
	{
	}

	Instance* FactoryClassShadowEffect::Instantiate()
	{
		return new CShadowEffect;
	}

	FactoryClassEvent::FactoryClassEvent()
	{
	}

	FactoryClassEvent::~FactoryClassEvent()
	{
	}

	Instance* FactoryClassEvent::Instantiate()
	{
		return new CEvent;
	}

	FactoryClassEventManager::FactoryClassEventManager()
	{
	}

	FactoryClassEventManager::~FactoryClassEventManager()
	{
	}

	Instance* FactoryClassEventManager::Instantiate()
	{
		return new CEventManager;
	}

	FactoryClassFirstScreenControl::FactoryClassFirstScreenControl()
	{
	}

	FactoryClassFirstScreenControl::~FactoryClassFirstScreenControl()
	{
	}

	Instance* FactoryClassFirstScreenControl::Instantiate()
	{
		return new CFirstScreenListControl;
	}

	FactoryClassThumbnail::FactoryClassThumbnail()
	{
	}

	FactoryClassThumbnail::~FactoryClassThumbnail()
	{
	}

	Instance* FactoryClassThumbnail::Instantiate()
	{
		return new CThumbnail;
	}


	FactoryClassGridListControl::FactoryClassGridListControl()
	{
	}

	FactoryClassGridListControl::~FactoryClassGridListControl()
	{
	}

	Instance* FactoryClassGridListControl::Instantiate()
	{
		return new CGridListControl;
	}

	FactoryClassImage::FactoryClassImage()
	{
	}

	FactoryClassImage::~FactoryClassImage()
	{
	}

	Instance* FactoryClassImage::Instantiate()
	{
		return new CImage;
	}

	FactoryClassImageBuffer::FactoryClassImageBuffer()
	{
	}

	FactoryClassImageBuffer::~FactoryClassImageBuffer()
	{
	}

	Instance* FactoryClassImageBuffer::Instantiate()
	{
		return new CImageBuffer;
	}

	FactoryClassMultiImage::FactoryClassMultiImage()
	{
	}

	FactoryClassMultiImage::~FactoryClassMultiImage()
	{
	}

	Instance* FactoryClassMultiImage::Instantiate()
	{
		return new CMultiImage;
	}

	FactoryClassLabel::FactoryClassLabel()
	{
	}

	FactoryClassLabel::~FactoryClassLabel()
	{
	}

	Instance* FactoryClassLabel::Instantiate()
	{
		return new CLabel;
	}

	//Layout:
	FactoryClassFixedLayout::FactoryClassFixedLayout()
	{
	}

	FactoryClassFixedLayout::~FactoryClassFixedLayout()
	{
	}

	Instance* FactoryClassFixedLayout::Instantiate()
	{
		return new CFixedLayout;
	}

	FactoryClassBinLayout::FactoryClassBinLayout()
	{
	}

	FactoryClassBinLayout::~FactoryClassBinLayout()
	{
	}

	Instance* FactoryClassBinLayout::Instantiate()
	{
		return new CBinLayout;
	}

	FactoryClassBoxLayout::FactoryClassBoxLayout()
	{
	}

	FactoryClassBoxLayout::~FactoryClassBoxLayout()
	{
	}

	Instance* FactoryClassBoxLayout::Instantiate()
	{
		return new CBoxLayout;
	}

	FactoryClassFlowLayout::FactoryClassFlowLayout()
	{
	}

	FactoryClassFlowLayout::~FactoryClassFlowLayout()
	{
	}

	Instance* FactoryClassFlowLayout::Instantiate()
	{
		return new CFlowLayout;
	}

	FactoryClassGridLayout::FactoryClassGridLayout()
	{
	}

	FactoryClassGridLayout::~FactoryClassGridLayout()
	{
	}

	Instance* FactoryClassGridLayout::Instantiate()
	{
		return new CGridLayout;
	}

	//FactoryClassListener::FactoryClassListener()
	//{
	//}

	//FactoryClassListener::~FactoryClassListener()
	//{
	//}

	//Instance* FactoryClassListener::Instantiate()
	//{
	//	return new CListener;
	//}

	//FactoryClassMatrixListControl::FactoryClassMatrixListControl()
	//{
	//}

	//FactoryClassMatrixListControl::~FactoryClassMatrixListControl()
	//{
	//}

	//Instance* FactoryClassMatrixListControl::Instantiate()
	//{
	//	return new CMatrixListControl;
	//}

	FactoryClassMessageBox::FactoryClassMessageBox()
	{
	}

	FactoryClassMessageBox::~FactoryClassMessageBox()
	{
	}

	Instance* FactoryClassMessageBox::Instantiate()
	{
		return new CMessageBox;
	}

	FactoryClassPageControl::FactoryClassPageControl()
	{
	}

	FactoryClassPageControl::~FactoryClassPageControl()
	{
	}

	Instance* FactoryClassPageControl::Instantiate()
	{
		return new CPageControl;
	}

	FactoryClassProgress::FactoryClassProgress()
	{
	}

	FactoryClassProgress::~FactoryClassProgress()
	{
	}

	Instance* FactoryClassProgress::Instantiate()
	{
		return new CProgress;
	}

	FactoryClassRadioButtonGroup::FactoryClassRadioButtonGroup()
	{
	}

	FactoryClassRadioButtonGroup::~FactoryClassRadioButtonGroup()
	{
	}

	Instance* FactoryClassRadioButtonGroup::Instantiate()
	{
		return new CRadioButtonGroup;
	}

	FactoryClassRectangle::FactoryClassRectangle()
	{
	}

	FactoryClassRectangle::~FactoryClassRectangle()
	{
	}

	Instance* FactoryClassRectangle::Instantiate()
	{
		return new CRectangle;
	}

	//FactoryClassRendererProvider::FactoryClassRendererProvider()
	//{
	//}

	//FactoryClassRendererProvider::~FactoryClassRendererProvider()
	//{
	//}

	//Instance* FactoryClassRendererProvider::Instantiate()
	//{
	//	return new CRendererProvider;
	//}

	FactoryClassRichText::FactoryClassRichText()
	{
	}

	FactoryClassRichText::~FactoryClassRichText()
	{
	}

	Instance* FactoryClassRichText::Instantiate()
	{
		return new CRichText;
	}

	FactoryClassInputBox::FactoryClassInputBox()
	{
	}

	FactoryClassInputBox::~FactoryClassInputBox()
	{
	}

	Instance* FactoryClassInputBox::Instantiate()
	{
		return new CInputBox;
	}

	FactoryClassScroll::FactoryClassScroll()
	{
	}

	FactoryClassScroll::~FactoryClassScroll()
	{
	}

	Instance* FactoryClassScroll::Instantiate()
	{
		return new CScroll;
	}

	//FactoryClassSerializable::FactoryClassSerializable()
	//{
	//}

	//FactoryClassSerializable::~FactoryClassSerializable()
	//{
	//}

	//Instance* FactoryClassSerializable::Instantiate()
	//{
	//	return new CSerializable;
	//}

	FactoryClassSingleLineListControl::FactoryClassSingleLineListControl()
	{
	}

	FactoryClassSingleLineListControl::~FactoryClassSingleLineListControl()
	{
	}

	Instance* FactoryClassSingleLineListControl::Instantiate()
	{
		return new CSingleLineListControl;
	}

	FactoryClassSlider::FactoryClassSlider()
	{
	}

	FactoryClassSlider::~FactoryClassSlider()
	{
	}

	Instance* FactoryClassSlider::Instantiate()
	{
		return new CSlider;
	}

	FactoryClassSpinButton::FactoryClassSpinButton()
	{
	}

	FactoryClassSpinButton::~FactoryClassSpinButton()
	{
	}

	Instance* FactoryClassSpinButton::Instantiate()
	{
		return new CSpinButton;
	}

	FactoryClassStage::FactoryClassStage()
	{
	}

	FactoryClassStage::~FactoryClassStage()
	{
	}

	Instance* FactoryClassStage::Instantiate()
	{
		return new CStage;
	}

	FactoryClassDimWindow::FactoryClassDimWindow()
	{
	}

	FactoryClassDimWindow::~FactoryClassDimWindow()
	{
	}

	Instance* FactoryClassDimWindow::Instantiate()
	{
		return new CDimWindow;
	}

	FactoryClassText::FactoryClassText()
	{
	}

	FactoryClassText::~FactoryClassText()
	{
	}

	Instance* FactoryClassText::Instantiate()
	{
		return new CText;
	}

	FactoryClassThreadPool::FactoryClassThreadPool()
	{
	}

	FactoryClassThreadPool::~FactoryClassThreadPool()
	{
	}

	Instance* FactoryClassThreadPool::Instantiate()
	{
		return new CThreadPool;
	}

	FactoryClassToggleButton::FactoryClassToggleButton()
	{
	}

	FactoryClassToggleButton::~FactoryClassToggleButton()
	{
	}

	Instance* FactoryClassToggleButton::Instantiate()
	{
		return new CToggleButton;
	}

	FactoryClassWarningWidget::FactoryClassWarningWidget()
	{
	}

	FactoryClassWarningWidget::~FactoryClassWarningWidget()
	{
	}

	Instance* FactoryClassWarningWidget::Instantiate()
	{
		return new CWarningWidget;
	}

	//FactoryClassWizardWidget::FactoryClassWizardWidget()
	//{
	//}

	//FactoryClassWizardWidget::~FactoryClassWizardWidget()
	//{
	//}

	//Instance* FactoryClassWizardWidget::Instantiate()
	//{
	//	return new CWizardWidget;
	//}


	FactoryClassClickAction::FactoryClassClickAction()
	{
	}

	FactoryClassClickAction::~FactoryClassClickAction()
	{
	}

	Instance* FactoryClassClickAction::Instantiate()
	{
		return new CClickAction;
	}
	FactoryClassDragAction::FactoryClassDragAction()
	{
	}

	FactoryClassDragAction::~FactoryClassDragAction()
	{
	}

	Instance* FactoryClassDragAction::Instantiate()
	{
		return new CDragAction;
	}
	FactoryClassGestureAction::FactoryClassGestureAction()
	{
	}

	FactoryClassGestureAction::~FactoryClassGestureAction()
	{
	}

	Instance* FactoryClassGestureAction::Instantiate()
	{
		return new CGestureAction;
	}
	FactoryClassKeyLongPressAction::FactoryClassKeyLongPressAction()
	{
	}

	FactoryClassKeyLongPressAction::~FactoryClassKeyLongPressAction()
	{
	}

	Instance* FactoryClassKeyLongPressAction::Instantiate()
	{
		return new CKeyLongPressAction;
	}
	FactoryClassKeyCombinationAction::FactoryClassKeyCombinationAction()
	{
	}

	FactoryClassKeyCombinationAction::~FactoryClassKeyCombinationAction()
	{
	}

	Instance* FactoryClassKeyCombinationAction::Instantiate()
	{
		return new CKeyCombinationAction;
	}

	FactoryClassKeyboardEvent::FactoryClassKeyboardEvent()
	{
	}

	FactoryClassKeyboardEvent::~FactoryClassKeyboardEvent()
	{
	}

	Instance* FactoryClassKeyboardEvent::Instantiate()
	{
		return new CKeyboardEvent;
	}
	FactoryClassMouseEvent::FactoryClassMouseEvent()
	{
	}

	FactoryClassMouseEvent::~FactoryClassMouseEvent()
	{
	}

	Instance* FactoryClassMouseEvent::Instantiate()
	{
		return new CMouseEvent;
	}
	FactoryClassRemoconEvent::FactoryClassRemoconEvent()
	{
	}

	FactoryClassRemoconEvent::~FactoryClassRemoconEvent()
	{
	}

	Instance* FactoryClassRemoconEvent::Instantiate()
	{
		return new CRemoconEvent;
	}
	FactoryClassMotionEvent::FactoryClassMotionEvent()
	{
	}

	FactoryClassMotionEvent::~FactoryClassMotionEvent()
	{
	}

	Instance* FactoryClassMotionEvent::Instantiate()
	{
		return new CMotionEvent;
	}
	FactoryClassTouchEvent::FactoryClassTouchEvent()
	{
	}

	FactoryClassTouchEvent::~FactoryClassTouchEvent()
	{
	}

	Instance* FactoryClassTouchEvent::Instantiate()
	{
		return new CTouchEvent;
	}
	FactoryClassRidgeEvent::FactoryClassRidgeEvent()
	{
	}

	FactoryClassRidgeEvent::~FactoryClassRidgeEvent()
	{
	}

	Instance* FactoryClassRidgeEvent::Instantiate()
	{
		return new CRidgeEvent;
	}
	FactoryClassCursorEvent::FactoryClassCursorEvent()
	{
	}

	FactoryClassCursorEvent::~FactoryClassCursorEvent()
	{
	}

	Instance* FactoryClassCursorEvent::Instantiate()
	{
		return new CCursorEvent;
	}
	FactoryClassSensorEvent::FactoryClassSensorEvent()
	{
	}

	FactoryClassSensorEvent::~FactoryClassSensorEvent()
	{
	}

	Instance* FactoryClassSensorEvent::Instantiate()
	{
		return new CSensorEvent;
	}
	FactoryClassClickEvent::FactoryClassClickEvent()
	{
	}

	FactoryClassClickEvent::~FactoryClassClickEvent()
	{
	}

	Instance* FactoryClassClickEvent::Instantiate()
	{
		return new CClickEvent;
	}
	FactoryClassLongPressEvent::FactoryClassLongPressEvent()
	{
	}

	FactoryClassLongPressEvent::~FactoryClassLongPressEvent()
	{
	}

	Instance* FactoryClassLongPressEvent::Instantiate()
	{
		return new CLongPressEvent;
	}
	FactoryClassDragEvent::FactoryClassDragEvent()
	{
	}

	FactoryClassDragEvent::~FactoryClassDragEvent()
	{
	}

	Instance* FactoryClassDragEvent::Instantiate()
	{
		return new CDragEvent;
	}
	FactoryClassGestureEvent::FactoryClassGestureEvent()
	{
	}

	FactoryClassGestureEvent::~FactoryClassGestureEvent()
	{
	}

	Instance* FactoryClassGestureEvent::Instantiate()
	{
		return new CGestureEvent;
	}
	FactoryClassSystemEvent::FactoryClassSystemEvent()
	{
	}

	FactoryClassSystemEvent::~FactoryClassSystemEvent()
	{
	}

	Instance* FactoryClassSystemEvent::Instantiate()
	{
		return new CSystemEvent;
	}
	FactoryClassCustomEvent::FactoryClassCustomEvent()
	{
	}

	FactoryClassCustomEvent::~FactoryClassCustomEvent()
	{
	}

	Instance* FactoryClassCustomEvent::Instantiate()
	{
		return new CCustomEvent;
	}
	FactoryClassFocusEvent::FactoryClassFocusEvent()
	{
	}

	FactoryClassFocusEvent::~FactoryClassFocusEvent()
	{
	}

	Instance* FactoryClassFocusEvent::Instantiate()
	{
		return new CFocusEvent;
	}
	
	FactoryClassCategoryTab::FactoryClassCategoryTab()
	{
	}

	FactoryClassCategoryTab::~FactoryClassCategoryTab()
	{
	}

	Instance* FactoryClassCategoryTab::Instantiate()
	{
		return new CCategoryTab;
	}

	FactoryClassToolTip::FactoryClassToolTip()
	{
	}

	FactoryClassToolTip::~FactoryClassToolTip()
	{
	}

	Instance* FactoryClassToolTip::Instantiate()
	{
		return new CToolTip;
	}

	FactoryClassPopupRating::FactoryClassPopupRating()
	{
	}

	FactoryClassPopupRating::~FactoryClassPopupRating()
	{
	}

	Instance* FactoryClassPopupRating::Instantiate()
	{
		return new CPopupRating;
	}
	

	FactoryClassListItem::FactoryClassListItem()
	{
	}

	FactoryClassListItem::~FactoryClassListItem()
	{
	}

	Instance* FactoryClassListItem::Instantiate()
	{
		return new CListItem;
	}

	FactoryClassListSelectItem::FactoryClassListSelectItem()
	{
	}

	FactoryClassListSelectItem::~FactoryClassListSelectItem()
	{
	}

	Instance* FactoryClassListSelectItem::Instantiate()
	{
		return new CListSelectItem;
	}
	FactoryClassExpandableListItem::FactoryClassExpandableListItem()
	{
	}

	FactoryClassExpandableListItem::~FactoryClassExpandableListItem()
	{
	}

	Instance* FactoryClassExpandableListItem::Instantiate()
	{
		return new CExpandableListItem;
	}

	FactoryClassSelectButton::FactoryClassSelectButton()
	{
	}

	FactoryClassSelectButton::~FactoryClassSelectButton()
	{

	}

	Instance* FactoryClassSelectButton::Instantiate()
	{
		return new CSelectButton;
	}

	FactoryClassUtility::FactoryClassUtility()
	{
	}

	FactoryClassUtility::~FactoryClassUtility()
	{

	}

	Instance* FactoryClassUtility::Instantiate()
	{
		return new CUtility;
	}

	FactoryClassLoading::FactoryClassLoading()
	{
	}

	FactoryClassLoading::~FactoryClassLoading()
	{
	}

	Instance* FactoryClassLoading::Instantiate()
	{
		return new CLoading;
	}

	FactoryClassSubList::FactoryClassSubList()
	{
	}

	FactoryClassSubList::~FactoryClassSubList()
	{
	}

	Instance* FactoryClassSubList::Instantiate()
	{
		return new CSubList;
	}

	FactoryClassActionPopup::FactoryClassActionPopup()
	{
	}

	FactoryClassActionPopup::~FactoryClassActionPopup()
	{

	}

	Instance* FactoryClassActionPopup::Instantiate()
	{
		return new CActionPopup;
	}

	FactoryClassPinPopup::FactoryClassPinPopup()
	{
	}

	FactoryClassPinPopup::~FactoryClassPinPopup()
	{

	}

	Instance* FactoryClassPinPopup::Instantiate()
	{
		return new CPinPopup;
	}
	FactoryClassVideoActor::FactoryClassVideoActor()
	{

	}

	FactoryClassVideoActor::~FactoryClassVideoActor()
	{

	}

	Instance* FactoryClassVideoActor::Instantiate()
	{
#if !defined(WIN32) && !defined(LINUX_BUILD)
		return new CVideoActor;
#else
		return NULL;
#endif
	}

	FactoryClassFoveaAnimator::FactoryClassFoveaAnimator()
	{
	}
	
	FactoryClassFoveaAnimator::~FactoryClassFoveaAnimator()
	{
	}
	
	Instance* FactoryClassFoveaAnimator::Instantiate()
	{
		return new CFoveaAnimator;
	}

    FactoryClassAudioUI::FactoryClassAudioUI()
    {
    }

    FactoryClassAudioUI::~FactoryClassAudioUI()
    {
    }

    Instance* FactoryClassAudioUI::Instantiate()
    {
#ifndef WIN32

        return new CAudioUI;
#else
        return NULL;
#endif
    }
}
