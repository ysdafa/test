#ifndef _LIBIMPL_H_
#define _LIBIMPL_H_

#include "Halo.h"

namespace HALO
{
	//class FactoryClassAction : public FactoryClass
	//{
	//public:
	//	FactoryClassAction();
	//	~FactoryClassAction();
	//	virtual Instance* Instantiate();
	//};

	class FactoryClassActor : public FactoryClass
	{
	public:
		FactoryClassActor();
		~FactoryClassActor();
		virtual Instance* Instantiate();
	};

	class FactoryClassTimeLine : public FactoryClass
	{
	public:
		FactoryClassTimeLine();
		~FactoryClassTimeLine();
		virtual Instance* Instantiate();
	};

	class FactoryClassTransition : public FactoryClass
	{
	public:
		FactoryClassTransition();
		~FactoryClassTransition();
		virtual Instance* Instantiate();
	};

	class FactoryClassAsyncTask : public FactoryClass
	{
	public:
		FactoryClassAsyncTask();
		~FactoryClassAsyncTask();
		virtual Instance* Instantiate();
	};

	//class FactoryClassBaseSelectButton : public FactoryClass
	//{
	//public:
	//	FactoryClassBaseSelectButton();
	//	~FactoryClassBaseSelectButton();
	//	virtual Instance* Instantiate();
	//};

	//class FactoryClassBaseSelectButtonGroup : public FactoryClass
	//{
	//public:
	//	FactoryClassBaseSelectButtonGroup();
	//	~FactoryClassBaseSelectButtonGroup();
	//	virtual Instance* Instantiate();
	//};

	class FactoryClassButton : public FactoryClass
	{
	public:
		FactoryClassButton();
		~FactoryClassButton();
		virtual Instance* Instantiate();
	};
	class FactoryClassCheckBoxGroup : public FactoryClass
	{
	public:
		FactoryClassCheckBoxGroup();
		~FactoryClassCheckBoxGroup();
		virtual Instance* Instantiate();
	};

	class FactoryClassCompositeImage : public FactoryClass
	{
	public:
		FactoryClassCompositeImage();
		~FactoryClassCompositeImage();
		virtual Instance* Instantiate();
	};

	//class FactoryClassDataListControl : public FactoryClass
	//{
	//public:
	//	FactoryClassDataListControl();
	//	~FactoryClassDataListControl();
	//	virtual Instance* Instantiate();
	//};

	//class FactoryClassDataSource : public FactoryClass
	//{
	//public:
	//	FactoryClassDataSource();
	//	~FactoryClassDataSource();
	//	virtual Instance* Instantiate();
	//};

	//class FactoryClassDataType : public FactoryClass
	//{
	//public:
	//	FactoryClassDataType();
	//	~FactoryClassDataType();
	//	virtual Instance* Instantiate();
	//};

	class FactoryClassDefaultWindow : public FactoryClass
	{
	public:
		FactoryClassDefaultWindow();
		~FactoryClassDefaultWindow();
		virtual Instance* Instantiate();
	};

	//class FactoryClassDevice : public FactoryClass
	//{
	//public:
	//	FactoryClassDevice();
	//	~FactoryClassDevice();
	//	virtual Instance* Instantiate();
	//};

	class FactoryClassDeviceManager : public FactoryClass
	{
	public:
		FactoryClassDeviceManager();
		~FactoryClassDeviceManager();
		virtual Instance* Instantiate();
	};

	class FactoryClassDesaturationEffect : public FactoryClass
	{
	public:
		FactoryClassDesaturationEffect();
		~FactoryClassDesaturationEffect();
		virtual Instance* Instantiate();
	};

	class FactoryClassShadowEffect : public FactoryClass
	{
	public:
		FactoryClassShadowEffect();
		~FactoryClassShadowEffect();
		virtual Instance* Instantiate();
	};

	class FactoryClassEvent : public FactoryClass
	{
	public:
		FactoryClassEvent();
		~FactoryClassEvent();
		virtual Instance* Instantiate();
	};

	class FactoryClassEventManager : public FactoryClass
	{
	public:
		FactoryClassEventManager();
		~FactoryClassEventManager();
		virtual Instance* Instantiate();
	};

	class FactoryClassFirstScreenControl : public FactoryClass
	{
	public:
		FactoryClassFirstScreenControl();
		~FactoryClassFirstScreenControl();
		virtual Instance* Instantiate();
	};

	class FactoryClassThumbnail : public FactoryClass
	{
	public:
		FactoryClassThumbnail();
		~FactoryClassThumbnail();
		virtual Instance* Instantiate();
	};

	class FactoryClassGridListControl : public FactoryClass
	{
	public:
		FactoryClassGridListControl();
		~FactoryClassGridListControl();
		virtual Instance* Instantiate();
	};

	class FactoryClassImage : public FactoryClass
	{
	public:
		FactoryClassImage();
		~FactoryClassImage();
		virtual Instance* Instantiate();
	};

	class FactoryClassImageBuffer : public FactoryClass
	{
	public:
		FactoryClassImageBuffer();
		~FactoryClassImageBuffer();
		virtual Instance* Instantiate();
	};

	class FactoryClassMultiImage : public FactoryClass
	{
	public:
		FactoryClassMultiImage();
		~FactoryClassMultiImage();
		virtual Instance* Instantiate();
	};

	//class FactoryClassInputHandler : public FactoryClass
	//{
	//public:
	//	FactoryClassInputHandler();
	//	~FactoryClassInputHandler();
	//	virtual Instance* Instantiate();
	//};

	class FactoryClassLabel : public FactoryClass
	{
	public:
		FactoryClassLabel();
		~FactoryClassLabel();
		virtual Instance* Instantiate();
	};

	//layout:
	class FactoryClassFixedLayout : public FactoryClass
	{
	public:
		FactoryClassFixedLayout();
		~FactoryClassFixedLayout();
		virtual Instance* Instantiate();
	};

	class FactoryClassBinLayout : public FactoryClass
	{
	public:
		FactoryClassBinLayout();
		~FactoryClassBinLayout();
		virtual Instance* Instantiate();
	};

	class FactoryClassBoxLayout : public FactoryClass
	{
	public:
		FactoryClassBoxLayout();
		~FactoryClassBoxLayout();
		virtual Instance* Instantiate();
	};

	class FactoryClassFlowLayout : public FactoryClass
	{
	public:
		FactoryClassFlowLayout();
		~FactoryClassFlowLayout();
		virtual Instance* Instantiate();
	};

	class FactoryClassGridLayout : public FactoryClass
	{
	public:
		FactoryClassGridLayout();
		~FactoryClassGridLayout();
		virtual Instance* Instantiate();
	};

	//class FactoryClassListener : public FactoryClass
	//{
	//public:
	//	FactoryClassListener();
	//	~FactoryClassListener();
	//	virtual Instance* Instantiate();
	//};

	//class FactoryClassMatrixListControl : public FactoryClass
	//{
	//public:
	//	FactoryClassMatrixListControl();
	//	~FactoryClassMatrixListControl();
	//	virtual Instance* Instantiate();
	//};

	class FactoryClassMessageBox : public FactoryClass
	{
	public:
		FactoryClassMessageBox();
		~FactoryClassMessageBox();
		virtual Instance* Instantiate();
	};

	class FactoryClassPageControl : public FactoryClass
	{
	public:
		FactoryClassPageControl();
		~FactoryClassPageControl();
		virtual Instance* Instantiate();
	};

	class FactoryClassProgress : public FactoryClass
	{
	public:
		FactoryClassProgress();
		~FactoryClassProgress();
		virtual Instance* Instantiate();
	};

	class FactoryClassRadioButton : public FactoryClass
	{
	public:
		FactoryClassRadioButton();
		~FactoryClassRadioButton();
		virtual Instance* Instantiate();
	};

	class FactoryClassRadioButtonGroup : public FactoryClass
	{
	public:
		FactoryClassRadioButtonGroup();
		~FactoryClassRadioButtonGroup();
		virtual Instance* Instantiate();
	};

	class FactoryClassRectangle : public FactoryClass
	{
	public:
		FactoryClassRectangle();
		~FactoryClassRectangle();
		virtual Instance* Instantiate();
	};

	//class FactoryClassRendererProvider : public FactoryClass
	//{
	//public:
	//	FactoryClassRendererProvider();
	//	~FactoryClassRendererProvider();
	//	virtual Instance* Instantiate();
	//};

	class FactoryClassRichText : public FactoryClass
	{
	public:
		FactoryClassRichText();
		~FactoryClassRichText();
		virtual Instance* Instantiate();
	};

	class FactoryClassInputBox : public FactoryClass
	{
	public:
		FactoryClassInputBox();
		~FactoryClassInputBox();
		virtual Instance* Instantiate();
	};

	class FactoryClassScroll : public FactoryClass
	{
	public:
		FactoryClassScroll();
		~FactoryClassScroll();
		virtual Instance* Instantiate();
	};

	//class FactoryClassSerializable : public FactoryClass
	//{
	//public:
	//	FactoryClassSerializable();
	//	~FactoryClassSerializable();
	//	virtual Instance* Instantiate();
	//};

	class FactoryClassSingleLineListControl : public FactoryClass
	{
	public:
		FactoryClassSingleLineListControl();
		~FactoryClassSingleLineListControl();
		virtual Instance* Instantiate();
	};

	class FactoryClassSlider : public FactoryClass
	{
	public:
		FactoryClassSlider();
		~FactoryClassSlider();
		virtual Instance* Instantiate();
	};

	class FactoryClassSpinButton : public FactoryClass
	{
	public:
		FactoryClassSpinButton();
		~FactoryClassSpinButton();
		virtual Instance* Instantiate();
	};

	class FactoryClassStage : public FactoryClass
	{
	public:
		FactoryClassStage();
		~FactoryClassStage();
		virtual Instance* Instantiate();
	};

	class FactoryClassDimWindow : public FactoryClass
	{
	public:
		FactoryClassDimWindow();
		~FactoryClassDimWindow();
		virtual Instance* Instantiate();
	};

	class FactoryClassText : public FactoryClass
	{
	public:
		FactoryClassText();
		~FactoryClassText();
		virtual Instance* Instantiate();
	};

	class FactoryClassThreadPool : public FactoryClass
	{
	public:
		FactoryClassThreadPool();
		~FactoryClassThreadPool();
		virtual Instance* Instantiate();
	};

	class FactoryClassToggleButton : public FactoryClass
	{
	public:
		FactoryClassToggleButton();
		~FactoryClassToggleButton();
		virtual Instance* Instantiate();
	};

	class FactoryClassWarningWidget : public FactoryClass
	{
	public:
		FactoryClassWarningWidget();
		~FactoryClassWarningWidget();
		virtual Instance* Instantiate();
	};

	//class FactoryClassWizardWidget : public FactoryClass
	//{
	//public:
	//	FactoryClassWizardWidget();
	//	~FactoryClassWizardWidget();
	//	virtual Instance* Instantiate();
	//};

	class FactoryClassKeyboardEvent : public FactoryClass
	{
	public:
		FactoryClassKeyboardEvent();
		~FactoryClassKeyboardEvent();
		virtual Instance* Instantiate();
	};
	class FactoryClassMouseEvent : public FactoryClass
	{
	public:
		FactoryClassMouseEvent();
		~FactoryClassMouseEvent();
		virtual Instance* Instantiate();
	};
	class FactoryClassRemoconEvent : public FactoryClass
	{
	public:
		FactoryClassRemoconEvent();
		~FactoryClassRemoconEvent();
		virtual Instance* Instantiate();
	};
	class FactoryClassMotionEvent : public FactoryClass
	{
	public:
		FactoryClassMotionEvent();
		~FactoryClassMotionEvent();
		virtual Instance* Instantiate();
	};
	class FactoryClassTouchEvent : public FactoryClass
	{
	public:
		FactoryClassTouchEvent();
		~FactoryClassTouchEvent();
		virtual Instance* Instantiate();
	};
	class FactoryClassRidgeEvent : public FactoryClass
	{
	public:
		FactoryClassRidgeEvent();
		~FactoryClassRidgeEvent();
		virtual Instance* Instantiate();
	};
	class FactoryClassCursorEvent : public FactoryClass
	{
	public:
		FactoryClassCursorEvent();
		~FactoryClassCursorEvent();
		virtual Instance* Instantiate();
	};
	class FactoryClassSensorEvent : public FactoryClass
	{
	public:
		FactoryClassSensorEvent();
		~FactoryClassSensorEvent();
		virtual Instance* Instantiate();
	};
	class FactoryClassClickEvent : public FactoryClass
	{
	public:
		FactoryClassClickEvent();
		~FactoryClassClickEvent();
		virtual Instance* Instantiate();
	};
	class FactoryClassLongPressEvent : public FactoryClass
	{
	public:
		FactoryClassLongPressEvent();
		~FactoryClassLongPressEvent();
		virtual Instance* Instantiate();
	};
	class FactoryClassDragEvent : public FactoryClass
	{
	public:
		FactoryClassDragEvent();
		~FactoryClassDragEvent();
		virtual Instance* Instantiate();
	};
	class FactoryClassGestureEvent : public FactoryClass
	{
	public:
		FactoryClassGestureEvent();
		~FactoryClassGestureEvent();
		virtual Instance* Instantiate();
	};
	class FactoryClassSystemEvent : public FactoryClass
	{
	public:
		FactoryClassSystemEvent();
		~FactoryClassSystemEvent();
		virtual Instance* Instantiate();
	};
	class FactoryClassCustomEvent : public FactoryClass
	{
	public:
		FactoryClassCustomEvent();
		~FactoryClassCustomEvent();
		virtual Instance* Instantiate();
	};
	class FactoryClassFocusEvent : public FactoryClass
	{
	public:
		FactoryClassFocusEvent();
		~FactoryClassFocusEvent();
		virtual Instance* Instantiate();
	};

	class FactoryClassClickAction : public FactoryClass
	{
	public:
		FactoryClassClickAction();
		~FactoryClassClickAction();
		virtual Instance* Instantiate();
	};
	class FactoryClassDragAction : public FactoryClass
	{
	public:
		FactoryClassDragAction();
		~FactoryClassDragAction();
		virtual Instance* Instantiate();
	};
	class FactoryClassGestureAction : public FactoryClass
	{
	public:
		FactoryClassGestureAction();
		~FactoryClassGestureAction();
		virtual Instance* Instantiate();
	};
	class FactoryClassKeyLongPressAction : public FactoryClass
	{
	public:
		FactoryClassKeyLongPressAction();
		~FactoryClassKeyLongPressAction();
		virtual Instance* Instantiate();
	};
	class FactoryClassKeyCombinationAction : public FactoryClass
	{
	public:
		FactoryClassKeyCombinationAction();
		~FactoryClassKeyCombinationAction();
		virtual Instance* Instantiate();
	};

	class FactoryClassCategoryTab : public FactoryClass
	{
	public:
		FactoryClassCategoryTab();
		~FactoryClassCategoryTab();
		virtual Instance* Instantiate();
	};

	class FactoryClassToolTip : public FactoryClass
	{
	public:
		FactoryClassToolTip();
		~FactoryClassToolTip();
		virtual Instance* Instantiate();
	};

	class FactoryClassPopupRating : public FactoryClass
	{
	public:
		FactoryClassPopupRating();
		~FactoryClassPopupRating();
		virtual Instance* Instantiate();
	};
	//ListItem
	class FactoryClassListItem : public FactoryClass
	{
	public:
		FactoryClassListItem();
		~FactoryClassListItem();
		virtual Instance* Instantiate();
	};
	class FactoryClassListSelectItem : public FactoryClass
	{
	public:
		FactoryClassListSelectItem();
		~FactoryClassListSelectItem();
		virtual Instance* Instantiate();
	};
	class FactoryClassExpandableListItem : public FactoryClass
	{
	public:
		FactoryClassExpandableListItem();
		~FactoryClassExpandableListItem();
		virtual Instance* Instantiate();
	};

	class FactoryClassSelectButton : public FactoryClass
	{
	public:
		FactoryClassSelectButton();
		~FactoryClassSelectButton();
		virtual Instance* Instantiate();
	};

	class FactoryClassUtility: public FactoryClass
	{
	public:
		FactoryClassUtility();
		~FactoryClassUtility();
		virtual Instance* Instantiate();
	};

	class FactoryClassLoading : public FactoryClass
	{
	public:
		FactoryClassLoading();
		~FactoryClassLoading();
		virtual Instance* Instantiate();
	};

	class FactoryClassActionPopup : public FactoryClass
	{
	public:
		FactoryClassActionPopup();
		~FactoryClassActionPopup();
		virtual Instance* Instantiate();
	};

	class FactoryClassPinPopup : public FactoryClass
	{
	public:
		FactoryClassPinPopup();
		~FactoryClassPinPopup();
		virtual Instance* Instantiate();
	};
	class FactoryClassVideoActor : public FactoryClass
	{
	public:
		FactoryClassVideoActor();
		~FactoryClassVideoActor();
		virtual Instance* Instantiate();
	};
}

#endif
