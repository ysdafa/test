#include "LibImpl.h"
#include "Halo1_0.h"

namespace HALO
{
	class IEmpty : public Instance
	{
	};

	class Empty : public IEmpty
	{
	};

	class FactoryClassEmpty : public FactoryClass
	{
	public:
		FactoryClassEmpty()
		{

		}

		virtual Instance *Instantiate()
		{
			return new Empty;
		}
	};

	bool g_initialized = false;
	bool g_preInitialized = false;
	CStage *g_stage = NULL;
	CEventManager* g_pEventManager = NULL;
	CDeviceManager* g_pDeviceManager = NULL;
	CThreadPool* g_pThreadPoolExecutor = NULL;
	EHaloVersion g_HaloVersion = HALO_VERSION_1_0;
	guint g_preprocessFilter = 0;
	extern FactorySet *g_factorySet;

	static HALO::util::Logger LOGGER("Halo");

	gboolean StageEventFilter(const ClutterEvent* event, gpointer user_data)
	{
		HALO::CEventManager* pEventManager = (HALO::CEventManager*)user_data;
		if (!pEventManager)
		{
			return CLUTTER_EVENT_PROPAGATE;
		}
		return pEventManager->ProcessClutterEvent(event);
	}

	bool Initialize(int aArgc, char **aArgv, EHaloVersion version)
	{
		H_LOG_TRACE(LOGGER, "Halo::Initialize full !!");
		if (!clutter_init(&aArgc, &aArgv))
		{
			return false;
		}

		PreInitialize();

		g_stage = dynamic_cast<CStage*>(IStage::GetInstance());
		if (g_stage == NULL)
		{
			return false;
		}

		g_pDeviceManager->Initialize();

		g_initialized = true;
		return true;		
	}

	bool Initialize(EHaloVersion version)
	{
		H_LOG_TRACE(LOGGER, "Halo::Initialize with only version !!");
		return Initialize(0, NULL, version);
	}

	void Main(void)
	{
		H_LOG_TRACE(LOGGER, "Halo::Main !!");
		clutter_main();
	}

	void Finalize(void)
	{
		H_LOG_TRACE(LOGGER, "Halo::Finalize START!!");
		if (!g_initialized)
		{
			return;
		}
		
		CFocusManager* pFocusManager = CFocusManager::GetInstance();
		if (pFocusManager)
		{
			pFocusManager->Enable(false);
		}

		g_stage->Destroy();
		delete g_stage;
		
		g_initialized = false;
		g_preInitialized = false;

		//! Release device manager instance
		if (g_pDeviceManager)
		{
			delete g_pDeviceManager;
			g_pDeviceManager = NULL;
		}		
		//clutter_main_quit();
		if (g_pEventManager)
		{
			delete g_pEventManager;
			g_pEventManager = NULL;
		}
		if (g_pThreadPoolExecutor)
		{
			delete g_pThreadPoolExecutor;
			g_pThreadPoolExecutor = NULL;
		}
		if (g_factorySet)
		{
			delete g_factorySet;
			g_factorySet = NULL;
		}
		H_LOG_TRACE(LOGGER, "Halo::Finalize DONE!!");
	}

	EHaloVersion Version(void)
	{
		H_LOG_TRACE(LOGGER, "Halo::Version !!");
		return g_HaloVersion;
	}

	void HALO_API PreInitialize(void)
	{
		H_LOG_TRACE(LOGGER, "Halo::PreInitialize !!");
		if (g_preInitialized)
		{
			return;
		}

		g_preInitialized = true;

		if (g_factorySet == NULL)
		{
			g_factorySet = new FactorySet;

			FactoryClass* fc;
			fc = new FactoryClassEmpty;
			g_factorySet->RegisterFactory(CLASS_ID_EMPTY, fc);

			//fc = new FactoryClassAction;
			//g_factorySet->RegisterFactory(CLASS_ID_IACTION, fc);
			fc = new FactoryClassActor;
			g_factorySet->RegisterFactory(CLASS_ID_IACTOR, fc);
			fc = new FactoryClassTimeLine;
			g_factorySet->RegisterFactory(CLASS_ID_ITIMELINE, fc);
			fc = new FactoryClassTransition;
			g_factorySet->RegisterFactory(CLASS_ID_ITRANSITION, fc);
			fc = new FactoryClassClickAction;
			g_factorySet->RegisterFactory(CLASS_ID_ICLICKACTION, fc);
			fc = new FactoryClassDragAction;
			g_factorySet->RegisterFactory(CLASS_ID_IDRAGACTION, fc);
			fc = new FactoryClassGestureAction;
			g_factorySet->RegisterFactory(CLASS_ID_IGESTUREACTION, fc);
			fc = new FactoryClassKeyLongPressAction;
			g_factorySet->RegisterFactory(CLASS_ID_IKEYLONGPRESSACTION, fc);
			fc = new FactoryClassKeyCombinationAction;
			g_factorySet->RegisterFactory(CLASS_ID_IKEYCOMBINATIONACTION, fc);
			//fc = new FactoryClassActor;
			//g_factorySet->RegisterFactory(CLASS_ID_IACTOR, fc);
			//fc = new FactoryClassAnimation;
			//g_factorySet->RegisterFactory(CLASS_ID_IANIMATION, fc);
			fc = new FactoryClassAsyncTask;
			g_factorySet->RegisterFactory(CLASS_ID_IASYNCTASK, fc);
			//fc = new FactoryClassBaseSelectButton;
			//g_factorySet->RegisterFactory(CLASS_ID_IBASESELECTBUTTON, fc);
			//fc = new FactoryClassBaseSelectButtonGroup;
			//g_factorySet->RegisterFactory(CLASS_ID_IBASESELECTBUTTONGROUP, fc);
			fc = new FactoryClassButton;
			g_factorySet->RegisterFactory(CLASS_ID_IBUTTON, fc);
			fc = new FactoryClassCheckBoxGroup;
			g_factorySet->RegisterFactory(CLASS_ID_ICHECKBOXGROUP, fc);
			fc = new FactoryClassCompositeImage;
			g_factorySet->RegisterFactory(CLASS_ID_ICOMPOSITEIMAGE, fc);
			//fc = new FactoryClassDataListControl;
			//g_factorySet->RegisterFactory(CLASS_ID_IDATALISTCONTROL, fc);
			//fc = new FactoryClassDataSource;
			//g_factorySet->RegisterFactory(CLASS_ID_IDATASOURCE, fc);
			//fc = new FactoryClassDataType;
			//g_factorySet->RegisterFactory(CLASS_ID_IDATATYPE, fc);
			fc = new FactoryClassDefaultWindow;
			g_factorySet->RegisterFactory(CLASS_ID_IDEFAULTWINDOW, fc);
			//fc = new FactoryClassDevice;
			//g_factorySet->RegisterFactory(CLASS_ID_IDEVICE, fc);
			fc = new FactoryClassDeviceManager;
			g_factorySet->RegisterFactory(CLASS_ID_IDEVICEMANAGER, fc);
			fc = new FactoryClassDesaturationEffect;
			g_factorySet->RegisterFactory(CLASS_ID_IDESATURATIONEFFECT, fc);
			fc = new FactoryClassShadowEffect;
			g_factorySet->RegisterFactory(CLASS_ID_IDSHADOWEFFECT, fc);
			fc = new FactoryClassEvent;
			g_factorySet->RegisterFactory(CLASS_ID_IEVENT, fc);
			fc = new FactoryClassKeyboardEvent;
			g_factorySet->RegisterFactory(CLASS_ID_IKEYBOARDEVENT, fc);
			fc = new FactoryClassMouseEvent;
			g_factorySet->RegisterFactory(CLASS_ID_IMOUSEEVENT, fc);
			fc = new FactoryClassRemoconEvent;
			g_factorySet->RegisterFactory(CLASS_ID_IREMOCONEVENT, fc);
			fc = new FactoryClassMotionEvent;
			g_factorySet->RegisterFactory(CLASS_ID_IMOTIONEVENT, fc);
			fc = new FactoryClassTouchEvent;
			g_factorySet->RegisterFactory(CLASS_ID_ITOUCHEVENT, fc);
			fc = new FactoryClassRidgeEvent;
			g_factorySet->RegisterFactory(CLASS_ID_IRIDGEEVENT, fc);
			fc = new FactoryClassCursorEvent;
			g_factorySet->RegisterFactory(CLASS_ID_ICURSOREVENT, fc);
			fc = new FactoryClassSensorEvent;
			g_factorySet->RegisterFactory(CLASS_ID_ISENSOREVENT, fc);
			fc = new FactoryClassClickEvent;
			g_factorySet->RegisterFactory(CLASS_ID_ICLICKEVENT, fc);
			fc = new FactoryClassLongPressEvent;
			g_factorySet->RegisterFactory(CLASS_ID_ILONGPRESSEVENT, fc);
			fc = new FactoryClassDragEvent;
			g_factorySet->RegisterFactory(CLASS_ID_IDRAGEVENT, fc);
			fc = new FactoryClassGestureEvent;
			g_factorySet->RegisterFactory(CLASS_ID_IGESTUREEVENT, fc);
			fc = new FactoryClassSystemEvent;
			g_factorySet->RegisterFactory(CLASS_ID_ISYSTEMEVENT, fc);
			fc = new FactoryClassCustomEvent;
			g_factorySet->RegisterFactory(CLASS_ID_ICUSTOMEVENT, fc);
			fc = new FactoryClassFocusEvent;
			g_factorySet->RegisterFactory(CLASS_ID_IFOCUSEVENT, fc);
			fc = new FactoryClassEventManager;
			g_factorySet->RegisterFactory(CLASS_ID_IEVENTMANAGER, fc);
			fc = new FactoryClassFirstScreenControl;
			g_factorySet->RegisterFactory(CLASS_ID_IFIRSTSCREENLISTCONTROL, fc);
			fc = new FactoryClassThumbnail;
			g_factorySet->RegisterFactory(CLASS_ID_ITHUMBNAIL, fc);
			fc = new FactoryClassGridListControl;
			g_factorySet->RegisterFactory(CLASS_ID_IGRIDLISTCONTROL, fc);
			fc = new FactoryClassImage;
			g_factorySet->RegisterFactory(CLASS_ID_IIMAGE, fc);
			fc = new FactoryClassImageBuffer;
			g_factorySet->RegisterFactory(CLASS_ID_IIMAGEBUFFER, fc);
			fc = new FactoryClassMultiImage;
			g_factorySet->RegisterFactory(CLASS_ID_IMULTIIMAGE, fc);
			fc = new FactoryClassLabel;
			g_factorySet->RegisterFactory(CLASS_ID_ILABEL, fc);
			//Layout:
			fc = new FactoryClassFixedLayout;
			g_factorySet->RegisterFactory(CLASS_ID_IFIXEDLAYOUT, fc);
			fc = new FactoryClassBinLayout;
			g_factorySet->RegisterFactory(CLASS_ID_IBINLAYOUT, fc);
			fc = new FactoryClassBoxLayout;
			g_factorySet->RegisterFactory(CLASS_ID_IBOXLAYOUT, fc);
			fc = new FactoryClassFlowLayout;
			g_factorySet->RegisterFactory(CLASS_ID_IFLOWLAYOUT, fc);
			fc = new FactoryClassGridLayout;
			g_factorySet->RegisterFactory(CLASS_ID_IGRIDLAYOUT, fc);
			//fc = new FactoryClassListener;
			//g_factorySet->RegisterFactory(CLASS_ID_ILISTENER, fc);
			//fc = new FactoryClassMatrixListControl;
			//g_factorySet->RegisterFactory(CLASS_ID_IMATRIXLISTCONTROL, fc);
			fc = new FactoryClassMessageBox;
			g_factorySet->RegisterFactory(CLASS_ID_IMESSAGEBOX, fc);
			fc = new FactoryClassPageControl;
			g_factorySet->RegisterFactory(CLASS_ID_IPAGECONTROL, fc);
			fc = new FactoryClassProgress;
			g_factorySet->RegisterFactory(CLASS_ID_IPROGRESS, fc);
			fc = new FactoryClassRadioButtonGroup;
			g_factorySet->RegisterFactory(CLASS_ID_IRADIOBUTTONGROUP, fc);
			fc = new FactoryClassRectangle;
			g_factorySet->RegisterFactory(CLASS_ID_IRECTANGLE, fc);
			//fc = new FactoryClassRendererProvider;
			//g_factorySet->RegisterFactory(CLASS_ID_IRENDERERPROVIDER, fc);
			fc = new FactoryClassRichText;
			g_factorySet->RegisterFactory(CLASS_ID_IRICHTEXT, fc);
			fc = new FactoryClassInputBox;
			g_factorySet->RegisterFactory(CLASS_ID_IINPUTBOX, fc);
			fc = new FactoryClassScroll;
			g_factorySet->RegisterFactory(CLASS_ID_ISCROLL, fc);
			//fc = new FactoryClassSerializable;
			//g_factorySet->RegisterFactory(CLASS_ID_ISERIALIZABLE, fc);
			fc = new FactoryClassSingleLineListControl;
			g_factorySet->RegisterFactory(CLASS_ID_ISINGLELINELISTCONTROL, fc);
			fc = new FactoryClassSlider;
			g_factorySet->RegisterFactory(CLASS_ID_ISLIDER, fc);
			fc = new FactoryClassSpinButton;
			g_factorySet->RegisterFactory(CLASS_ID_ISPINBUTTON, fc);
			fc = new FactoryClassStage;
			g_factorySet->RegisterFactory(CLASS_ID_ISTAGE, fc);
			fc = new FactoryClassDimWindow;
			g_factorySet->RegisterFactory(CLASS_ID_IDIMWINDOW, fc);
			fc = new FactoryClassText;
			g_factorySet->RegisterFactory(CLASS_ID_ITEXT, fc);
			fc = new FactoryClassThreadPool;
			g_factorySet->RegisterFactory(CLASS_ID_ITHREADPOOL, fc);
			fc = new FactoryClassToggleButton;
			g_factorySet->RegisterFactory(CLASS_ID_ITOGGLEBUTTON, fc);
			fc = new FactoryClassWarningWidget;
			g_factorySet->RegisterFactory(CLASS_ID_IWARNINGWIDGET, fc);
			//fc = new FactoryClassWizardWidget;
			//g_factorySet->RegisterFactory(CLASS_ID_IWIZARDWIDGET, fc);
			fc = new FactoryClassCategoryTab;
			g_factorySet->RegisterFactory(CLASS_ID_ICATEGORYTAB, fc);
			fc = new FactoryClassToolTip;
			g_factorySet->RegisterFactory(CLASS_ID_ITOOLTIP, fc);
			fc = new FactoryClassPopupRating;
			g_factorySet->RegisterFactory(CLASS_ID_IPOPUPRATING, fc);
			fc = new FactoryClassListItem;
			g_factorySet->RegisterFactory(CLASS_ID_ILISTITEM, fc);
			fc = new FactoryClassListSelectItem;
			g_factorySet->RegisterFactory(CLASS_ID_ILISTSElECTITEM, fc);
			fc = new FactoryClassExpandableListItem;
			g_factorySet->RegisterFactory(CLASS_ID_IEXPANDABLELISTITEM, fc);
			fc = new FactoryClassSelectButton;
			g_factorySet->RegisterFactory(CLASS_ID_ISELECTBUTTON, fc);
			fc = new FactoryClassUtility;
			g_factorySet->RegisterFactory(CLASS_ID_IUTILITY, fc);
			fc = new FactoryClassLoading;
			g_factorySet->RegisterFactory(CLASS_ID_ILOADING, fc);
			fc = new FactoryClassActionPopup;
			g_factorySet->RegisterFactory(CLASS_ID_IACTIONPOPUP, fc);
			fc = new FactoryClassPinPopup;
			g_factorySet->RegisterFactory(CLASS_ID_IPINPOPUP, fc);
			fc = new FactoryClassVideoActor;
			g_factorySet->RegisterFactory(CLASS_ID_IVIDEOACTOR, fc);
		}

		if (g_pEventManager == NULL)
		{
			g_pEventManager = dynamic_cast<CEventManager*>(IEventManager::GetInstance());
		}

		g_pThreadPoolExecutor = new HALO::CThreadPool();
		ASSERT(g_pThreadPoolExecutor);

		g_pThreadPoolExecutor->Initialize(20, 10, 100);

		if (g_pEventManager == NULL)
		{
			g_pEventManager = dynamic_cast<CEventManager*>(IEventManager::GetInstance());
		}

		//! Create device manager instance
		if (g_pDeviceManager == NULL)
		{
			g_pDeviceManager = (CDeviceManager*)IDeviceManager::GetInstance();
		}

		//g_preInitialized = true;
	}

}



