#ifndef _CSUBLIST_H_
#define _CSUBLIST_H_

namespace HALO
{
	class CSubList:virtual public ISubList, public CActor, public IKeyboardListener, public IFocusListener, public IMouseListener, public IButtonListener, public ISingleLineListControlListener, public IRendererProvider
	{
	public:
		struct TItemDataInfo
		{
			CSublistItem::TImageInfo imageInfo;
			CSublistItem::TImageInfo image2Info;
			CSublistItem::TTextInfo textInfo;
			CSublistItem::TTextInfo text2Info;
			CSublistItem::TTextScrollInfo itemTextScrollInfo;
			ClutterColor itemBGNormalColor;
			ClutterColor itemBGFocusedColor;
			ClutterColor itemBGDimColor;
		};

		CSubList();
		virtual ~CSubList();
		virtual bool Initialize(IActor* parent, const TSubListAttr &attr);
		virtual bool Initialize( Widget* parent, const TSubListAttr &attr );

		virtual void SetFirstLayerBGColor(const ClutterColor BGColor);
		virtual void SetSecondLayerBGColor(const ClutterColor BGColor);
		virtual void SetThirdLayerBGBorderWidth(float BGBorderWidth);
		virtual void SetThirdLayerBGBorderColor(const ClutterColor BGBorderColor);
		virtual void SetFourthLayerBGImage(std::string &shadowImagePath);

		virtual void AddItem(int itemNum, float *itemSpaceArray, float itemGap );
		virtual void AddItem(int itemNum, float itemSpace, float itemGap);
		
		void AddItemData(const int nId, const TItemDataInfo &itemDataInfo);
		virtual void UpdateItem(int itemIndex);
		virtual void DeleteItem(int fromItem, int deleteItemNum);
		virtual void UpdateAllItems(void);
		virtual void SetDataSource();
		virtual ISingleLineDataSource* GetDataSource();
		virtual IRenderer* GetRenderer(IData *data, IActor *parent);
		virtual void SetFocusItemIndex(const int itemIndex);
		virtual int FocusItemIndex(void) const;
		virtual void SetSingleLineListPosition(const float x, const float y);
		virtual void SetArrowImageAttr(EArrowDirections arrowDirection, const TArrowAttr &arrowAttr);
		virtual void SetButtonAttr(const TRect &buttonImageRect, std::string &buttonNormalImagePath, std::string &buttonFocusedImagePath, std::string &buttonDimImagePath);
		virtual void SetCheckItemIndex(int checkedItemIndex);
		virtual int CheckItemIndex() const;
		virtual bool ShowFocus(bool flagAnimation);
		virtual bool HideFocus(bool flagAnimation);
		virtual bool SetFocus(void);
		virtual void KillFocus(void);
		virtual int NumofItem(void);
		virtual void SetDimItem(int itemIndex, bool ifDim);
		virtual bool IfDim(int itemIndex);
		virtual std::string Text(int itemIndex);
		virtual std::string Text2(int itemIndex);
		virtual void SetAnimationDuration(ISingleLineListControl::ESingleLineAniType aniType, int duration);

		virtual bool AddListener(ISubListListener* listener);
		virtual bool RemoveListener(ISubListListener* listener);
		virtual void SetShowTime(guint nShowTime);
		virtual guint ShowTime() const;

	protected:
		float t_parentWidth;
		float t_parentHeight;
		int t_nTotalItemNumber;
		int t_nItemNumberOnWindow;
		CSingleLineListControl *t_singleLineList;
		ISingleLineListControl::TSingleLineListControlAttr t_singleLineListControlAttr;
		CActor *t_firstLayerBG;
		CActor *t_secondLayerBG;
		CActor *t_thirdLayerBG;
		CCompositeImage *t_fourthLayerBG;

		std::vector<CSublistItem*> t_ItemVector;
		ISingleLineDataSource *t_subListDataSource;
		class CSubListListenerSet *t_pSubListListenerSet;

		virtual bool OnMousePointerIn(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnKeyPressed(IWidgetExtension* pThis, IKeyboardEvent* event);
		virtual bool OnKeyReleased(IWidgetExtension* pThis, IKeyboardEvent* event);
		virtual bool OnMouseButtonReleased(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnMouseMoved(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);

		virtual bool OnItemClicked(class ISingleLineListControl* list, int itemIndex);
		virtual bool OnFocusChanged(class ISingleLineListControl* list, int fromItemIndex, int toItemIndex);
		virtual bool OnEnterKeyLongPressed(class ISingleLineListControl *list, int itemIndex);

		virtual bool OnFocusIn(IWidgetExtension* pWindow);
		virtual bool OnFocusOut(IWidgetExtension* pWindow);

	private:
		IImage *m_upArrowImage;
		IImage *m_downArrowImage;
		IImage *m_leftArrowImage;
		IImage *m_rightArrowImage;
		TArrowAttr m_arrowAttr[4];

		int m_checkedItemIndex;
		guint m_showTimerId;
		guint m_showTime;
		bool m_flagMousePressed;

		static gboolean m_ShowTimeFinishedCB(gpointer data);
		void m_ResetShowTime();
		void m_Initialize();
		void m_CreateBG(Widget* parent, const TSubListAttr &attr);
		void m_CreateList();
		void m_CreateArrowImage();
		void m_ChangeArrowImage(EArrowDirections arrowDirection, std::string &buttonImagePath, int imageAlpha);
		void m_ItemClicked(int itemIndex);
		void m_Destroy();
	};
}
#endif
