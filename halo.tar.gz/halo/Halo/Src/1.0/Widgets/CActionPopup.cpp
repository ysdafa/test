#include "Halo.h"
#include "Halo1_0.h"
#define ACTIONPOPUP_WIDTH_RATE 0.584375
#define ACTIONPOPUP_HEIGHT_RATE 0.088889

namespace HALO
{
	CActionPopup::CActionPopup()	
	{

	}

	CActionPopup::~CActionPopup()
	{
		if (NULL != t_Title)
		{
			t_Title = NULL;
			delete t_Title;
		}
		if (NULL != m_titleLine)
		{
			m_titleLine = NULL;
			delete m_titleLine;
		}
	}

	bool CActionPopup::Initialize( Widget* parent, const TActionPopupAttr &attr )
	{
		t_isTitle = attr.isTitle;
		t_Width = attr.w;
		t_Height = attr.h;
		this->SetPosition(attr.x , attr.y);
		m_BackGrundType = attr.nBackGroundType;
		CActor::Initialize(parent, t_Width, t_Height);
		if (t_isTitle == true)
		{
			t_Title = IText::CreateInstance(dynamic_cast<Widget*>(this) , (float)t_Width * ACTIONPOPUP_WIDTH_RATE , (float)t_Height * ACTIONPOPUP_HEIGHT_RATE);
			t_Title->SetPosition((t_Width - (float)t_Width * ACTIONPOPUP_WIDTH_RATE) / 2 , 0);
			t_Title->SetTextAlignment(HALIGN_CENTER , VALIGN_MIDDLE);
			m_titleLine = IActor::CreateInstance(dynamic_cast<Widget*>(this), (float)(t_Width * ACTIONPOPUP_WIDTH_RATE), 1.0);
		}
		m_CreateBackGround();
		return true;
	}

	bool CActionPopup::Initialize( IActor* parent, const TActionPopupAttr &attr )
	{
		t_isTitle = attr.isTitle;
		t_Width = attr.w;
		t_Height = attr.h;
		this->SetPosition(attr.x , attr.y);
		m_BackGrundType = attr.nBackGroundType;
		CActor::Initialize(parent, t_Width, t_Height);
		if (t_isTitle == true)
		{
			t_Title = IText::CreateInstance(dynamic_cast<Widget*>(this) , (float)t_Width * ACTIONPOPUP_WIDTH_RATE , (float)t_Height * ACTIONPOPUP_HEIGHT_RATE);
			t_Title->SetPosition((t_Width - (float)t_Width * ACTIONPOPUP_WIDTH_RATE) / 2 , 0);
			t_Title->SetTextAlignment(HALIGN_CENTER , VALIGN_MIDDLE);
			m_titleLine = IActor::CreateInstance(dynamic_cast<Widget*>(this), (float)(t_Width * ACTIONPOPUP_WIDTH_RATE), 1.0);
		}
		m_CreateBackGround();
		return true;
	}

	void CActionPopup::SetTitle( const char* title )
	{
		t_Title->SetText(title);
	}

	void CActionPopup::UpdateTitlePosition( float xPos , float yPos )
	{
		t_Title->SetPosition(xPos , yPos);
	}

	void CActionPopup::UpdateTitleSize( float width , float height )
	{
		t_Title->Resize(width , height);
	}

	void CActionPopup::SetTitleAlignment( EHAlignment hAlign, EVAlignment vAlign )
	{
		t_Title->SetTextAlignment(hAlign , vAlign);
	}

	void CActionPopup::SetTitleTextColor( const ClutterColor textcolor )
	{
		t_Title->SetTextColor(textcolor);
	}

	void CActionPopup::SetTitleTextFontSize( int fontSize )
	{
		t_Title->SetFontSize(fontSize);
	}

	void CActionPopup::SetBackgroundType( E_BACKGROUND_TYPE backgroundType )
	{

	}

	void CActionPopup::SetBlendColor( const ClutterColor textcolor )
	{

	}

	void CActionPopup::m_CreateBackGround()
	{
		if (m_BackGrundType == E_TYPE_ONE)
		{
			ClutterColor BgColor = {39,124,175,200};
			SetBackgroundColor(BgColor);
		}
	}

	void CActionPopup::SetTitleLineColor( const ClutterColor color )
	{
		m_titleLine->SetBackgroundColor(color);
	}
}