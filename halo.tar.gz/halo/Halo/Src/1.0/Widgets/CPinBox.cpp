#include "Halo.h"
#include "Halo1_0.h"
#ifndef WIN32
#include <vconf/vconf.h>
#endif

#define PINBOX_IMAGEGAP_RATE 0.016666
#define PINBOX_NUMBERGAP_RATE 0.003125
#define PINBOX_NUMBERW_RATE 0.015625
#define PINBOX_NUMBERH_RATE 0.037037

namespace HALO
{
	CPinBox::CPinBox()
	{
	}

	CPinBox::~CPinBox()
	{
		m_Destroy();
	}

	bool CPinBox::Initialize(IActor *parent, float width, float height, bool isCheck)
	{
		if (ParentType::Initialize(parent , width , height) == false)
		{
			return false;
		}
		t_IsCheck = isCheck;
		m_Initialize();
		return true;
	}

	bool CPinBox::Initialize( Widget *parent , float width , float height , bool isCheck)
	{
		if (ParentType::Initialize(parent , width , height) == false)
		{
			return false;
		}
		t_IsCheck = isCheck;
		m_Initialize();
		return true;
	}

	void CPinBox::m_Destroy()
	{	
		RemoveKeyboardListener(this);
	}

	bool CPinBox::AddListener(IPinNumberListener* listener)
	{
		ASSERT(NULL != listener);
		m_Listener = listener;
		return true;
	}

	bool CPinBox::RemoveListener()
	{
		if (NULL != m_Listener)
		{
			m_Listener = NULL;
			delete m_Listener;
		}
		return true;
	}

	bool CPinBox::OnKeyPressed( IActor* pThis, IKeyboardEvent* event )
	{
		if (this->IsFocused())
		{
			int keyVal;
			keyVal = event->GetKeyVal();
			if (keyVal == 48 ||keyVal == 49 ||keyVal == 50 ||keyVal == 51 ||keyVal == 52 ||keyVal == 53 ||keyVal == 54 ||keyVal == 55 ||keyVal == 56 ||keyVal == 57)
			{
				m_ChangeDigitTo(keyVal - 48 , t_focusPos);
			}
			if (keyVal == CLUTTER_KEY_Return && t_focusPos < MAX_ITEM)
			{
				m_InputPassWord.append(m_tempPwd);
				m_ChangrStateTo(E_STATE_FINISHINPUT , t_focusPos);
				t_focusPos++;
				if (t_focusPos == MAX_ITEM)
				{	
					if (NULL != m_Listener)
					{
						if (t_IsCheck)
						{
							m_Listener->OnValidConfirm(this , m_CheckPassWord());
						}
						else
						{
							m_Listener->OutputPassWord(this , m_InputPassWord);
						}
					}
					return true;
				}
			}
		}
		return true;
	}

	void CPinBox::SetInputItemsGap( float gap )
	{
		m_itemgap = gap;
	}

	void CPinBox::SetInputItemSize( float w , float h )
	{
		m_itemwidth = w;
		m_itemheight = h;
		float imagerightgap = (t_boxwidth - m_itemwidth * MAX_ITEM - (float)(m_ParentW *PINBOX_IMAGEGAP_RATE) * (MAX_ITEM - 1)) / 2;
		float ypos = (t_boxheight - m_itemheight) / 2;
		for (int index = 0 ; index < MAX_ITEM; index++)
		{
			m_PinBoxImage[index]->SetPosition(imagerightgap + index * m_itemwidth + index * (float)(m_ParentW *PINBOX_IMAGEGAP_RATE) , ypos);
		}
	}

	void CPinBox::SetInputItemImage( EInputBoxsState inputboxState , const std::string& iconPath )
	{
		ASSERT(inputboxState <= EInputBoxsState::E_STATE_FINISHINPUT && !iconPath.empty());
		for (int index = 0; index < MAX_ITEM ; index++)
		{
			if (inputboxState == E_STATE_NOINPUT)
			{
				m_noInputImagePath = iconPath;
				m_ChangrStateTo(EInputBoxsState::E_STATE_NOINPUT , index);
			}
			else if (inputboxState == E_STATE_FINISHINPUT)
			{
				m_finishInputImagePath = iconPath;
			}
		}
	}

	void CPinBox::SetDigitTextFontSize( int fontSize )
	{
		for (int index = 0; index < MAX_ITEM ; index++)
		{
			m_PinText[index]->SetFontSize(fontSize);
		}
	}

	void CPinBox::SetDigitTextColor( const ClutterColor color )
	{
		for (int index = 0; index < MAX_ITEM ; index++)
		{
			m_PinText[index]->SetTextColor(color);
		}
	}

	void CPinBox::SetDigitTextFont( const char* font )
	{
		for (int index = 0; index < MAX_ITEM ; index++)
		{
			m_PinText[index]->SetFont(font);
		}
	}

	void CPinBox::m_Initialize( void )
	{
		//m_textwidth =(float)(t_boxwidth * PINBOX_NUMBERW_RATE);
		//m_textheight = (float)(t_boxheight * PINBOX_NUMBERH_RATE);
		m_itemgap = 0;
		t_focusPos = 0;
		m_Listener = NULL;
		for (int index = 0 ; index < MAX_ITEM; index ++)
		{
			m_PinBoxImage[index] = IImage::CreateInstance(dynamic_cast<Widget*>(this) , 9, 9);
			m_PinText[index] = IText::CreateInstance(dynamic_cast<Widget*>(this) , m_textwidth , m_textheight);
		}
		AddKeyboardListener(this);
		m_strPwd = m_GetPassWordByVconf();
	}

	const char* CPinBox::m_GetPassWordByVconf()
	{
		#ifndef WIN32
		char* pchPin = vconf_get_str( "db/menu/system/change_pin" );
		#else
		char* pchPin = "6666";
		#endif
		return pchPin;
	}

	bool CPinBox::m_CheckPassWord()
	{	
		std::string s2(m_strPwd);
		bool ret = m_InputPassWord == s2;
		if (ret)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}

	void CPinBox::ResetPassword()
	{
		m_InputPassWord.clear();
		t_focusPos = ITEM_FIRST;
		for (int index = 0 ; index < MAX_ITEM; index++)
		{
			m_ChangrStateTo(E_STATE_NOINPUT , index);
		}
	}

	void CPinBox::m_ChangrStateTo( EInputBoxsState toBoxState ,int itemindex)
	{
		if (toBoxState == E_STATE_NOINPUT)
		{
			m_PinBoxImage[itemindex]->SetImage(m_noInputImagePath.c_str());
			m_PinBoxImage[itemindex]->Show();

		}
		else if (toBoxState == E_STATE_FINISHINPUT)
		{
			m_PinText[itemindex]->Hide();
			m_PinBoxImage[itemindex]->SetImage(m_finishInputImagePath.c_str());
			m_PinBoxImage[itemindex]->Show();
		}
	}

	void CPinBox::m_ChangeDigitTo( int number ,int itemindex)
	{
		m_PinBoxImage[itemindex]->Hide();
		char buf[16] = {0};
		SNPRINTF(buf, 16, "%d", number);
		m_PinText[itemindex]->SetText(buf);
		m_PinText[itemindex]->Show();
		m_tempPwd = buf;
	}


	void CPinBox::SetNumberSize( float w, float h )
	{
		m_ParentW = w;
		m_ParentH = h;
		m_textwidth = (float)(m_ParentW * PINBOX_NUMBERW_RATE);
		m_textheight = (float)(m_ParentH * PINBOX_NUMBERH_RATE);
		for (int index = 0 ; index < MAX_ITEM; index ++)
		{
			m_PinText[index] = IText::CreateInstance(dynamic_cast<Widget*>(this) , m_textwidth , m_textheight);
		}
		float textrightgap = (t_boxwidth - m_textwidth * MAX_ITEM - (float)(m_ParentW *PINBOX_NUMBERGAP_RATE) * (MAX_ITEM - 1)) / 2;
		float ypos = (t_boxheight - m_textheight) / 2;
		for (int index = 0 ; index < MAX_ITEM; index++)
		{
			m_PinText[index]->SetPosition(textrightgap + index * m_textwidth + index * (float)(m_ParentW *PINBOX_NUMBERGAP_RATE) , ypos);
			m_PinText[index]->SetTextAlignment(HALIGN_CENTER , VALIGN_MIDDLE);
			m_PinText[index]->SetFontSize(34);
		}
	}

	int CPinBox::DigitTextFontSize( void )
	{
		return m_PinText[0]->FontSize();
	}

	ClutterColor CPinBox::DigitTextColor( void )
	{
		return m_PinText[0]->TextColor();
	}

	const char* CPinBox::DigitTextFont( void )
	{
		return m_PinText[0]->Font();
	}


	bool CBaseInputBox::OnMousePointerIn( IActor* pWindow, IMouseEvent* ptrMouseEvent )
	{
		SetFocus();
		return true;
	}

	bool CBaseInputBox::OnMousePointerOut( IActor* pWindow, IMouseEvent* ptrMouseEvent )
	{
		return true;
	}

	bool CBaseInputBox::OnFocusIn( IActor* pWindow )
	{
		EInputBoxState state;
		state = E_STATE_FOCUSED;
		m_ChangeStateTo(state);
		return true;
	}

	bool CBaseInputBox::OnFocusOut( IActor* pWindow )
	{
		EInputBoxState state;
		state = E_STATE_NORMAL;
		m_ChangeStateTo(state);
		return true;
	}

	void CBaseInputBox::m_ChangeStateTo( EInputBoxState toState )
	{
		if (toState == m_curState || E_STATE_ALL == toState)
		{
			return;
		}
		m_curState = toState;
		m_OnStateChange();
	}

	void CBaseInputBox::m_OnStateChange( void )
	{
		if (m_curState == E_STATE_FOCUSED)
		{
			m_BoxImage->SetImage(m_focusImagePath.c_str());
			m_BoxImage->Show();	
			m_BoxImage->Lower(NULL);
		}
		else if (m_curState == E_STATE_NORMAL)
		{
			m_BoxImage->SetImage(m_unfocusImagePath.c_str());
			m_BoxImage->Show();
			m_BoxImage->Lower(NULL);
		}
	}

	void CBaseInputBox::SetInputBoxBackGroundImage( EInputBoxState pinstate , const std::string& iconPath )
	{
		ASSERT(!iconPath.empty() && pinstate <= E_STATE_ALL);
		if (pinstate == E_STATE_FOCUSED)
		{
			m_focusImagePath = iconPath;
		}
		else if (pinstate == E_STATE_NORMAL)
		{
			m_unfocusImagePath = iconPath;
			m_OnStateChange();
		}
	}

	bool CBaseInputBox::Initialize( IActor *parent , float width , float height )
	{
		t_boxwidth = width;
		t_boxheight = height;
		CActor::Initialize(parent , width ,height);
		m_Initialize();
		return true;
	}

	bool CBaseInputBox::Initialize( Widget *parent , float width , float height )
	{
		t_boxwidth = width;
		t_boxheight = height;
		CActor::Initialize(parent , width ,height);
		m_Initialize();
		return true;
	}

	void CBaseInputBox::m_Initialize( void )
	{
		m_BoxImage = ICompositeImage::CreateInstance(dynamic_cast<Widget*>(this) , t_boxwidth, t_boxheight);
		m_curState = E_STATE_NORMAL;
		AddFocusListener(this);
		AddMouseListener(this);
		EnableFocus(true);
		EnablePointerFocus(false);

	}

	CBaseInputBox::CBaseInputBox()
	{

	}

	CBaseInputBox::~CBaseInputBox()
	{
		m_Destroy();
	}

	void CBaseInputBox::m_Destroy()
	{
		if (NULL != m_BoxImage)
		{
			delete m_BoxImage;
		}
		RemoveMouseListener(this);
		RemoveFocusListener(this);
	}
}


