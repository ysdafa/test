#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	ISpinButton* ISpinButton::CreateInstance(IActor* parent, const TSpinButtonAttr &attr)
	{
		CSpinButton* spinButton = dynamic_cast<CSpinButton*>(Instance::CreateInstance(CLASS_ID_ISPINBUTTON));

		if (NULL != spinButton)
		{
			spinButton->Initialize(parent, attr);
		}
		return spinButton;
	}
}