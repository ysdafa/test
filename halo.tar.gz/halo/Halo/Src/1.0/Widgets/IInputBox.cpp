#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	IInputBox* IInputBox::CreateInstance(IActor* parent, float width, float height, const TInputBoxAttr &attr)
	{
		CInputBox* inputBox = dynamic_cast<CInputBox*>(Instance::CreateInstance(CLASS_ID_IINPUTBOX));
		if (NULL != inputBox)
		{
			inputBox->Initialize(parent, width, height, attr);
		}
		return inputBox;
	}

	IInputBox* IInputBox::CreateInstance(Widget* parent, float width, float height, const TInputBoxAttr &attr)
	{
		CInputBox* inputBox = dynamic_cast<CInputBox*>(Instance::CreateInstance(CLASS_ID_IINPUTBOX));
		ASSERT(inputBox != NULL);

		if (inputBox != NULL)
		{
			inputBox->Initialize(parent, width, height, attr);
		}

		return inputBox;
	}
}
