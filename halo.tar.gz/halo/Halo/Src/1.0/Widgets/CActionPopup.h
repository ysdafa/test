#ifndef _CACTIONPOPUP_H_
#define _CACTIONPOPUP_H_

namespace HALO
{
	class CActionPopup: virtual public IActionPopup, public CActor
	{

	public:
		CActionPopup();
		virtual ~CActionPopup();

		virtual bool Initialize(IActor* parent, const TActionPopupAttr &attr);

		virtual bool Initialize(Widget* parent, const TActionPopupAttr &attr);

		virtual void SetTitle(const char* title);

		virtual void UpdateTitlePosition(float xPos , float yPos);

		virtual void UpdateTitleSize(float width , float height);

		virtual void SetTitleAlignment(EHAlignment hAlign, EVAlignment vAlign);

		virtual void SetTitleTextColor(const ClutterColor textcolor);

		virtual void SetTitleTextFontSize(int fontSize);

		virtual void SetBackgroundType(E_BACKGROUND_TYPE  backgroundType);

		virtual void SetBlendColor(const ClutterColor textcolor);

		virtual void SetTitleLineColor(const ClutterColor color);
	protected:
		float t_Width;
		float t_Height;
		float t_TitleW;
		float t_TitleH;
		IText* t_Title;
		bool t_isTitle;
		E_BACKGROUND_TYPE m_BackGrundType;
		IActor *m_titleLine;
		void m_CreateBackGround();
	};
}
#endif
