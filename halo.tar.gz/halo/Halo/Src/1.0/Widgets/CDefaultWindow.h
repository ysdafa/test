#ifndef _CDEFAULTWINDOW_H_
#define _CDEFAULTWINDOW_H_

namespace HALO
{
	class CDefaultWindow: virtual public IDefaultWindow, public CActor
	{
		 typedef CActor ParentType;
	public:
		CDefaultWindow();
		virtual ~CDefaultWindow();

		//!Create the instance
		virtual bool Initialize(IActor* parent, const TDefaultWindowAttr &attr);

		//!Show the defaultwindow by animationtype
		virtual void Show(E_ANIMATION_TYPE nAnimationType);
		//!Hide the defaultwindow by animationtype
		virtual void Hide(E_ANIMATION_TYPE nAnimationType);
		// !Set the title string of the defaultwindow
		virtual void SetTitleText(const char* pTitle);

		virtual void SetTitleTextColor(const ClutterColor textcolor);

		virtual void SetTitleTextFontSize(int fontSize);

		virtual void SetBGImage(IImageBuffer* pBGImage);
	
		virtual void SetBGType(int nBGType);
		
		virtual void EnableAutoTransparency();
		
		virtual void SetCursorShape(int nHelpBarType, int nType); 
		
		virtual void SetTransparency(int nValue);	
		
		virtual void SetShadowBGImage(IImageBuffer* pShadowBGImage = NULL, int nRelativeX = -1, int nRelativeY = -1, float nDestWidth = -1, float nDestHeight = -1/*, STRect* sourceRect = NULL*/);

		virtual void SetAlarmTimeOut(unsigned long nTimeOut);

		virtual void ResetTimeOutAlarm(void);
		//!Stop the time out Alarm
		virtual void StopTimeOutAlarm(void);
	protected:
		ILabel *t_Title;
		IRectangle *t_BGAlphaDrawing;
		IActor *t_BGShadowWidget;
		IActor *t_BGWidget;
		//CAnimation *t_ani;
		IImage *t_BGImageDrawing;
		IImage *t_BGShadowDrawing;
		int t_nManualTransparency;

		virtual bool CreateAni(E_ANIMATION_TYPE nAnimationType);
		virtual void PlayAni(E_ANIMATION_TYPE nAnimationType);

		void t_ResetTimeOutAlarm(void);
		void t_StopTimeOutAlarm(void);

		static int t_ProcessExit(gpointer user_data);
		//void m_CreateBGDrawing(int width, int height, int nItemType, bool bUseCompositeBGImage);
	private:
		ITransition *ani1f;
		ITransition *ani2f;
		bool m_b3DFlag;
		bool m_bHideAniFlag;
		bool m_IfAni;
		int m_exitTimerID;
		unsigned long m_nTimeOutAlarmTime;
		int AinType;
		bool m_CreateTitle(int nItemType, float width);
		void m_Show();
		void m_ShowAni(E_ANIMATION_TYPE nAnimationType);
		bool m_Hide();
		void m_Destroy();
		void m_DestroyAni(int  nAnimationType);
		void m_CreateBGAlphaIDrawing(float width, float height);
		void m_CreateBGDrawing(float width, float height, int nItemType, bool bUseCompositeBGImage);
		void m_CreateBGShadowDrawing(float width, float height);
	};
}
#endif
