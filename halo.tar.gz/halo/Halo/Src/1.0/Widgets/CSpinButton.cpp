#include "Halo.h"
#include "Halo1_0.h"
#include "COSDInfo.h"
#ifdef WIN32
#define IMAGE_PATH RESROOT"TF_PinNumberWidget/images/"
#else
#define IMAGE_PATH "T_HaloSample/Sample/TF_PinNumberWidget/images/"
#endif
namespace HALO
{
	CSpinButton::CSpinButton()
	{

	}

	CSpinButton::~CSpinButton()
	{
		m_Destroy();
	}
	bool CSpinButton::Initialize( IActor* parent, const TSpinButtonAttr &attr )
	{
		t_bContentText = attr.bcontent;
		IDefaultWindow::T_DEFAULTWINDOW_ATTR dattr;
		dattr.xPos = attr.xPos;
		dattr.yPos = attr.yPos;
		dattr.bUseCompositeBGImage = false;
		dattr.nItemType = 0;
		dattr.screenNumber = 0;
		if (t_bContentText)
		{
			dattr.width = COSDInfo::SUBINPUTWIDGET_WITHCONTENT_W;
			dattr.height = COSDInfo::SUBINPUTWIDGET_H;
			ParentType::Initialize(parent , dattr);
		}
		else
		{
			dattr.width = COSDInfo::SUBINPUTWIDGET_WITHOUTCONTENT_W;
			dattr.height = COSDInfo::SUBINPUTWIDGET_H;
			ParentType::Initialize(parent , dattr);
		}
		ClutterColor c = {0,51,113, 255};
		ParentType::SetBackgroundColor(*clutter_color_init(&c, 0, 51, 113, 255));
		return t_Initialize(attr.leftText , attr.rightText);
	}

	void CSpinButton::Show()
	{
		ParentType::Show(IDefaultWindow::ANIMATION_NONE);
		m_LeftArrow->Show();
		m_RightArrow->Show();
		m_LeftText->Show();
		m_RightText->Show();
		
		if (t_bContentText)
		{
			m_ContentText->Show();
		}
	}

	void CSpinButton::Hide()
	{

	}

	void CSpinButton::m_CreateArrows()
	{
		m_LeftArrow = IButton::CreateInstance(this, COSDInfo::SUBINPUTWIDGET_ARROW_W , COSDInfo::SUBINPUTWIDGET_ARROW_H);
		m_RightArrow = IButton::CreateInstance(this, COSDInfo::SUBINPUTWIDGET_ARROW_W , COSDInfo::SUBINPUTWIDGET_ARROW_H);

		/*CImageBuffer::CreateInstance(&m_LeftNormalArrow);
		IImageBuffer::CreateInstance(&m_RightNormalArrow);
		IImageBuffer::CreateInstance(&m_LeftFocusedArrow);
		IImageBuffer::CreateInstance(&m_RightFocusedArrow);*/
		m_LeftNormalArrow = IImageBuffer::CreateInstance(IMAGE_PATH "popup_btn_arrow_left_n.png");
		m_RightNormalArrow = IImageBuffer::CreateInstance(IMAGE_PATH "popup_btn_arrow_left_f.png");
		m_LeftFocusedArrow = IImageBuffer::CreateInstance(IMAGE_PATH "popup_btn_arrow_right_n.png");
		m_RightFocusedArrow = IImageBuffer::CreateInstance(IMAGE_PATH "popup_btn_arrow_right_f.png");

		//if (NULL != m_LeftArrow && NULL != m_LeftNormalArrow && NULL != m_LeftFocusedArrow && NULL != m_RightArrow)
		//{
		//	m_LeftArrow->SetBackgroundImage(IButton::E_STATE_UNFOCUSED ,m_LeftNormalArrow);
		//	m_LeftArrow->SetBackgroundImage(IButton::E_STATE_FOCUSED ,m_LeftFocusedArrow);
		//	m_LeftArrow->AddKeyboardListener(this);	
		//	m_LeftArrow->AddMouseListener(this);
		//	m_LeftArrow->SetFocus();
		//	m_LeftArrow->SetTabWindow(DIRECTION_RIGHT , m_RightArrow);
		//	m_LeftArrow->SetPosition(COSDInfo::SUBINPUTWIDGET_LEFTARROW_X , COSDInfo::SUBINPUTWIDGET_ARROW_Y);
		//}
		//if (NULL != m_RightArrow && NULL != m_RightNormalArrow && NULL != m_RightFocusedArrow && NULL != m_LeftArrow)
		//{
		//	m_RightArrow->SetBackgroundImage(IButton::E_STATE_UNFOCUSED , m_RightNormalArrow);
		//	m_RightArrow->SetBackgroundImage(IButton::E_STATE_FOCUSED , m_RightFocusedArrow);
		//	m_RightArrow->SetTabWindow(DIRECTION_LEFT , m_LeftArrow);
		//	m_RightArrow->AddKeyboardListener(this);
		//	m_RightArrow->AddMouseListener(this);
		//}
		if (t_bContentText && NULL != m_RightArrow)
		{
			m_RightArrow->SetPosition(COSDInfo::SUBINPUTWIDGET_CONTENT_X + 32 + COSDInfo::SUBINPUTWIDGET_CONTENT_W + COSDInfo::SUBINPUTWIDGET_ARROW_TEXT_W - 14 , COSDInfo::SUBINPUTWIDGET_ARROW_Y);
		}
		else if (NULL != m_RightArrow)
		{
			m_RightArrow->SetPosition(COSDInfo::SUBINPUTWIDGET_RIGHTARROW_X , COSDInfo::SUBINPUTWIDGET_ARROW_Y);
		}
		
	}

	void CSpinButton::m_CreateText()
	{

		if (!t_bContentText)
		{	m_LeftText = IText::CreateInstance(dynamic_cast<Widget*>(this) ,COSDInfo::SUBINPUTWIDGET_ARROW_TEXT_W, COSDInfo::SUBINPUTWIDGET_ARROW_H);
			m_RightText = IText::CreateInstance(dynamic_cast<Widget*>(this) ,COSDInfo::SUBINPUTWIDGET_ARROW_TEXT_W, COSDInfo::SUBINPUTWIDGET_ARROW_H);
			if (NULL != m_LeftText)
			{
				m_LeftText->SetPosition(COSDInfo::SUBINPUTWIDGET_LEFTTEXT_X ,COSDInfo::SUBINPUTWIDGET_ARROW_Y);
			}
			if (NULL != m_RightText)
			{
				m_RightText->SetPosition(COSDInfo::SUBINPUTWIDGET_RIGHTTEXT_X , COSDInfo::SUBINPUTWIDGET_ARROW_Y);
			}
		}
		else
		{
			m_ContentText = IText::CreateInstance(dynamic_cast<Widget*>(this),COSDInfo::SUBINPUTWIDGET_CONTENT_W , COSDInfo::SUBINPUTWIDGET_ARROW_H);
			m_LeftText = IText::CreateInstance(dynamic_cast<Widget*>(this) ,COSDInfo::SUBINPUTWIDGET_ARROW_TEXT_W - 14, COSDInfo::SUBINPUTWIDGET_ARROW_H);
			m_RightText = IText::CreateInstance(dynamic_cast<Widget*>(this) ,COSDInfo::SUBINPUTWIDGET_ARROW_TEXT_W - 14, COSDInfo::SUBINPUTWIDGET_ARROW_H);
			if (NULL != m_LeftText)
			{
				m_LeftText->SetPosition(COSDInfo::SUBINPUTWIDGET_LEFTTEXT_WITHCONTENT_X ,COSDInfo::SUBINPUTWIDGET_ARROW_Y);
			}
			if (NULL != m_RightText)
			{
				m_RightText->SetPosition(COSDInfo::SUBINPUTWIDGET_RIGHTTEXT_WITHCONTENT_X , COSDInfo::SUBINPUTWIDGET_ARROW_Y);
			}
			if (NULL != m_ContentText)
			{
				m_ContentText->SetPosition(COSDInfo::SUBINPUTWIDGET_CONTENT_X , COSDInfo::SUBINPUTWIDGET_ARROW_Y);
			}
		}
	}

	bool CSpinButton::t_Initialize(const char* leftText, const char* rightText)
	{
		m_CreateArrows();
		m_CreateText();
		SetLeftRightText(leftText, rightText);
		return true;
	}

	void CSpinButton::SetLeftRightText( const char* leftText, const char* rightText )
	{
		ClutterColor c = {255,255,255, 255};
		//m_text->SetTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
		m_LeftText->SetText(leftText);
		m_RightText->SetText(rightText);
		m_LeftText->SetTextColor((*clutter_color_init(&c, 255,255,255, 255)));
		m_RightText->SetTextColor((*clutter_color_init(&c, 255,255,255, 255)));
		m_RightText->SetTextAlignment(HALIGN_RIGHT , VALIGN_MIDDLE);
		m_LeftText->SetTextAlignment(HALIGN_LEFT ,VALIGN_MIDDLE);
	}

	bool CSpinButton::OnClicked( IActor* pWindow, IClickEvent* pClickEvent )
	{
		return true;
	}

	bool CSpinButton::OnMouseButtonPressed( IActor* pWindow, IMouseEvent* ptrMouseEvent )
	{
		return true;
	}

	bool CSpinButton::OnKeyPressed( IActor* pThis, IKeyboardEvent* event )
	{
		int keyVal = event->GetKeyVal();
		switch (keyVal)
		{
		case CLUTTER_KEY_Left:
			pThis->MoveTab(DIRECTION_LEFT);
			return true;
			break;
		case CLUTTER_KEY_Right:
			pThis->MoveTab(DIRECTION_RIGHT);
			return true;
			break;
		}
		if (t_bContentText)
		{
			return t_ProcessArrowEvent(pThis);
		}
		else
		{
			ListenerList::iterator listenerIter = m_list.begin();
			if (m_list.empty())
			{
				return false;
			}
			while (listenerIter != m_list.end())
			{
				ISpinButtonListener* pListener = (ISpinButtonListener*)(*listenerIter);
				if (pThis == m_LeftArrow && keyVal == 65293)
				{
					pListener->OnLeftArrowEvent(this , event ,CLUTTER_KEY_PRESS);
				}
				if (pThis == m_RightArrow && keyVal == 65293)
				{
					pListener->OnRightArrowEvent(this , event ,CLUTTER_KEY_PRESS);
				}
				listenerIter++;
			}
			return true;
		}
	}


	bool CSpinButton::AddListener( ISpinButtonListener* listener )
	{
		bool ret = false;
		ret = this->Add(listener);
		return ret;
	}

	bool CSpinButton::RemoveListener( ISpinButtonListener* listener )
	{
		bool ret = false;
		ret = this->Remove(listener);
		return ret;
	}

	void CSpinButton::m_Destroy()
	{
		
		m_LeftArrow->RemoveKeyboardListener(this);
		m_LeftArrow->RemoveMouseListener(this);
		m_LeftNormalArrow->Release();
		m_LeftFocusedArrow->Release();

		m_RightArrow->RemoveKeyboardListener(this);
		m_RightArrow->RemoveMouseListener(this);
		m_RightNormalArrow->Release();
		m_RightFocusedArrow->Release();

		m_LeftText->Release();
		
		m_RightText->Release();
		if (t_bContentText)
		{
			m_ContentText->Release();
		}
	}

	bool CSpinButton::t_ProcessArrowEvent(IActor* pThis)
	{
		if (pThis == m_LeftArrow)
		{
			t_subUpadte();
		}
		else if (pThis == m_RightArrow)
		{
			t_addUpdate();
		}
		return true;
	}

	void CSpinButton::t_subUpadte()
	{

	}

	void CSpinButton::t_addUpdate()
	{

	}

}