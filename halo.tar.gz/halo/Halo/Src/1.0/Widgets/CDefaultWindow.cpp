#include "Halo.h"
#include "Halo1_0.h"
#include "COSDInfo.h"
namespace HALO
{
	CDefaultWindow::CDefaultWindow()
	:t_nManualTransparency(-1)
	{
		
	}
	CDefaultWindow::~CDefaultWindow()
	{
		m_Destroy();
	}
	bool CDefaultWindow::Initialize( IActor* parent, const TDefaultWindowAttr &attr )
	{
		float w = attr.width;
		float h = attr.height;
		ParentType::Initialize(parent, attr.width, attr.height);
		ParentType::SetPosition(attr.xPos, attr.yPos);
		m_CreateBGShadowDrawing(w, h);
		m_CreateBGAlphaIDrawing(w, h);
		m_CreateBGDrawing(w, h, attr.nItemType, attr.bUseCompositeBGImage);
		m_CreateTitle(attr.nItemType, w);
		//t_BGShadowWidget->raise(NULL);
		t_Title->Raise(NULL);
		return true;
	}

	void CDefaultWindow::m_Destroy(void)
	{
		if(m_exitTimerID > 0)
		{
			g_source_remove(m_exitTimerID);
		}
		if(m_IfAni == true)
		{
			m_DestroyAni(AinType);
		}
		t_Title->Release();
		t_BGAlphaDrawing->Release();
		t_BGImageDrawing->Release();
		t_BGShadowDrawing->Release();
		t_BGShadowWidget->Release();
		t_BGWidget->Release();
		
	}
		
	void CDefaultWindow::Show(E_ANIMATION_TYPE nAnimationType)
	{
		m_IfAni = CreateAni(nAnimationType);
		m_Show();
		if (m_IfAni == true)
		{
			PlayAni(nAnimationType);
		}
	}
		
	void CDefaultWindow::Hide(E_ANIMATION_TYPE nAnimationType)
	{
		m_Hide();
	}
		
	void CDefaultWindow::SetTitleText(const char* pTitle)
	{
		t_Title->SetText(pTitle);
	}

	void CDefaultWindow::SetTitleTextColor(const ClutterColor textcolor)
	{
		t_Title->SetTextColor(textcolor);
	}

	void CDefaultWindow::SetTitleTextFontSize(int fontSize)
	{
		t_Title->SetFontSize(fontSize);
	}


	void CDefaultWindow::SetBGImage(IImageBuffer* pBGImage)
	{
		t_BGImageDrawing->SetImage(pBGImage);
		//t_BGAlphaDrawing.Resize(pBGImage->Width() , pBGImage->Height());
		m_CreateBGAlphaIDrawing((float)pBGImage->Width() ,(float)pBGImage->Height());
	}
	
	void CDefaultWindow::SetBGType(int nBGType)
	{
		
	
	
	}


	void CDefaultWindow::EnableAutoTransparency()
	{
		t_nManualTransparency = -1;
	}

	void CDefaultWindow::SetCursorShape(int nHelpBarType, int nType)
	{
		
	}

	void CDefaultWindow::SetTransparency(int nValue)	
	{}
	void CDefaultWindow::m_Show()
	{
		if (m_nTimeOutAlarmTime > 0)
		{
			t_ResetTimeOutAlarm();
		}
		t_Title->Show();
		ParentType::Show();
		t_BGAlphaDrawing->Show();
		t_BGImageDrawing->Show();
		t_BGShadowWidget->Show();
		t_BGShadowDrawing->Show();
		t_BGWidget->Show();
	}


	
	bool CDefaultWindow::m_Hide()
	{
		t_Title->Hide();
		t_BGAlphaDrawing->Hide();
		t_BGImageDrawing->Hide();
		t_BGShadowWidget->Show();
		t_BGShadowDrawing->Show();
		return true;
	}

	bool CDefaultWindow::m_CreateTitle(int nItemType, float width)
	{
		Widget *widget = dynamic_cast<Widget*>(this);
		if (widget != NULL)
		{
			t_Title = ILabel::CreateInstance(widget, width, COSDInfo::ACTION_WINDOW_TITLE_H);
		}
		if(NULL != t_Title)
		{
			t_Title->SetPosition(COSDInfo::ACTION_WINDOW_TITLE_X, COSDInfo::ACTION_WINDOW_TITLE_Y);
			//t_Title.SetTextFont();
			t_Title->SetFontSize(COSDInfo::ACTION_WINDOW_TITLE_FONT_SIZE);
			t_Title->SetTextColor(COSDInfo::TITLE_TEXT_COLOR);
		}
		return true;
	}

	void CDefaultWindow::SetShadowBGImage(IImageBuffer* pShadowBGImage, int nRelativeX , int nRelativeY , float nDestWidth , float nDestHeight /*, STRect* sourceRect = NULL*/)
	{
		float width = 0;
		float height = 0;
		this->GetSize(width, height);
		if( pShadowBGImage == NULL )
		{
			//pShadowBGImage = g_AppCommonResMgr->GetImageForAppCM(IDS_IMG_COMMON_SHADOW_BG, this);
		}

		if( nRelativeX == -1 )
		{
			nRelativeX = 0;
		}

		if( nRelativeY == -1 )
		{
			nRelativeY =  0;
		}
	
		if( nDestWidth == -1 )
		{
			nDestWidth = width + COSDInfo::DEFAULTWND_SHADOW_BG_WIDTH;
		}

		if( nDestHeight == -1 )
		{
			nDestHeight = height + COSDInfo::DEFAULTWND_SHADOW_BG_HEIGHT;
		}

		//t_BGShadowDrawing.Create(t_BGShadowWidget ,nDestWidth ,nDestHeight);
		t_BGShadowDrawing->SetImage(pShadowBGImage);
	}

	void CDefaultWindow::m_CreateBGShadowDrawing(float width, float height)
	{
		t_BGShadowWidget = IActor::CreateInstance((IActor*)this, width+ COSDInfo::DEFAULTWND_SHADOW_BG_WIDTH, height+ COSDInfo::DEFAULTWND_SHADOW_BG_HEIGHT);
		if(NULL != t_BGShadowWidget)
		{
			ClutterColor c = {125, 125, 125, 125};
			t_BGShadowWidget->SetBackgroundColor(*clutter_color_init(&c, 125, 125, 125, 125));
			t_BGShadowDrawing = IImage::CreateInstance(t_BGShadowWidget,width+ COSDInfo::DEFAULTWND_SHADOW_BG_WIDTH,height+ COSDInfo::DEFAULTWND_SHADOW_BG_HEIGHT);
		}
		
	}

	void CDefaultWindow::m_CreateBGAlphaIDrawing(float width, float height)
	{
		t_BGAlphaDrawing = IRectangle::CreateInstance(dynamic_cast<Widget *>(this), width, height);
		//t_BGAlphaDrawing->SetBackgroudColor(COSDInfo::BG_ALPHA_COLOR);
		if(t_nManualTransparency != -1)
		{
			if (NULL != t_BGAlphaDrawing)
			{
				t_BGAlphaDrawing->SetAlpha(t_nManualTransparency);
			}
		}
	}

	void CDefaultWindow::m_CreateBGDrawing(float width, float height, int nItemType, bool bUseCompositeBGImage)
	{
		t_BGWidget = IActor::CreateInstance((IActor*)this, width, height);
		if (NULL != t_BGWidget)
		{
			t_BGImageDrawing = IImage::CreateInstance(t_BGWidget, width, height);
		}
		
	}

	bool CDefaultWindow::CreateAni( E_ANIMATION_TYPE nAnimationType )
	{
		if (nAnimationType == ANIMATION_NONE )
		{
			AinType = 0;
			return false;
		}
		if (nAnimationType == ANIMATION_ZOOM_OUT_TO_IN)
		{
			AinType = ANIMATION_ZOOM_OUT_TO_IN;
			
			ani1f = ITransition::CreateInstance();
			if (NULL != ani1f)
			{
				BindTransition(ani1f, CActor::ACTOR_ANI_POSITION_Z);
				ani1f->SetDuration(500);
				ani1f->SetDestination(120.0f);
			}
			return true;
		}
		if (nAnimationType == ANIMATION_RIGHT_TO_LEFT)
		{
			AinType = ANIMATION_RIGHT_TO_LEFT;
			return true;
		}

		return false;

		
	}

	void CDefaultWindow::PlayAni( E_ANIMATION_TYPE nAnimationType )
	{
		if (nAnimationType = ANIMATION_ZOOM_OUT_TO_IN)
		{
			ani1f->Play();
		}

	}

	void CDefaultWindow::m_DestroyAni(int  nAnimationType)
	{
		if (nAnimationType == ANIMATION_ZOOM_OUT_TO_IN)
		{
			ani1f->Release();
		}
	}

	void CDefaultWindow::SetAlarmTimeOut( unsigned long nTimeOut )
	{
		m_nTimeOutAlarmTime = nTimeOut;
	}

	void CDefaultWindow::ResetTimeOutAlarm( void )
	{
		t_ResetTimeOutAlarm();
	}

	void CDefaultWindow::StopTimeOutAlarm( void )
	{

	}

	void CDefaultWindow::t_ResetTimeOutAlarm( void )
	{
		m_exitTimerID = clutter_threads_add_timeout(m_nTimeOutAlarmTime, t_ProcessExit, this);
	}

	void CDefaultWindow::t_StopTimeOutAlarm( void )
	{

	}

	int CDefaultWindow::t_ProcessExit( gpointer user_data )
	{
		CDefaultWindow* pThis = (CDefaultWindow*)user_data;
		delete pThis;
		return true;
	}

}