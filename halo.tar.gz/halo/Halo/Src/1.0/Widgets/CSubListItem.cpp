#include "Halo1_0.h"

namespace HALO
{
	void CSublistItem::SetItemImageData(const int nId, const TImageInfo &itemImageInfo)
	{
		itemIndex = nId;
		imageInfo[0] = itemImageInfo;
	}

	void CSublistItem::SetItemImage2Data(const int nId, const TImageInfo &itemImageInfo)
	{
		itemIndex = nId;
		imageInfo[1] = itemImageInfo;
	}

	void CSublistItem::SetItemTextData(const int nId, const TTextInfo &textInfo)
	{
		itemIndex = nId;
		itemTextInfo[0] = textInfo;
	}

	void CSublistItem::SetItemText2Data(const int nId, const TTextInfo &textInfo)
	{
		itemIndex = nId;
		itemTextInfo[1] = textInfo;
	}

	void CSublistItem::SetItemTextScrollInfo(const int nId, const TTextScrollInfo &itemTextScrollInfo)
	{
		itemIndex = nId;
		textScrollInfo = itemTextScrollInfo;
	}

	void CSublistItem::SetBGNormalColor(const int nId, const ClutterColor &itemBGColor)
	{
		itemIndex = nId;
		ItemBGNormalColor = itemBGColor;
	}

	void CSublistItem::SetBGFocusedColor(const int nId, const ClutterColor &itemBGColor)
	{
		itemIndex = nId;
		ItemBGFocusedColor = itemBGColor;
	}

	void CSublistItem::SetBGDimColor(const int nId, const ClutterColor &itemBGColor)
	{
		itemIndex = nId;
		ItemBGDimColor = itemBGColor;
	}
}
