#include "Halo.h"
#include "Halo1_0.h"
#include "COSDInfo.h"
namespace HALO
{

	CWarningWidget::CWarningWidget()
	{

	}
	CWarningWidget::~CWarningWidget()
	{
		m_Destroy();
	}

	bool CWarningWidget::Initialize( IActor *parent ,const TWarningWidgetAttr &attr )
	{
		m_loadingType = attr.waringtype;
		

		IDefaultWindow::T_DEFAULTWINDOW_ATTR dattr;
		dattr.xPos = (float)COSDInfo::WARNING_WIDGET_X;
		dattr.yPos = (float)COSDInfo::WARNING_WIDGET_Y;
		dattr.width = (float)COSDInfo::WARNING_WIDGET_W;
		dattr.height = (float)COSDInfo::WARNING_WIDGET_H;
		dattr.bUseCompositeBGImage = false;
		dattr.nItemType = 0;
		dattr.screenNumber = 0;

		if (CDefaultWindow::Initialize(parent ,dattr))
		{
		}
		Widget *widget = dynamic_cast<Widget*>(this);
		if (widget != NULL)
		{
			m_MessageLabel = ILabel::CreateInstance(widget, (float)COSDInfo::WARNING_WIDGET_TEXT_W, (float)COSDInfo::WARNING_WIDGET_TEXT_H);
		}
		if (NULL != m_MessageLabel)
		{
			m_MessageLabel->SetText(attr.pMessage);
		}
		return false;
	}

	void CWarningWidget::Show()
	{
		CDefaultWindow::Show(IDefaultWindow::ANIMATION_NONE);
		m_MessageLabel->Show();
		if(m_loadingType == WARNING_WITH_LOADING)
		{
			m_ShowAni();
		}
		else
		{
			m_ShowTTS();
		}
	}

	void CWarningWidget::SetTimer( int nTimer )
	{
		SetAlarmTimeOut(nTimer);
	}

	void CWarningWidget::Hide( void )
	{
	
	}

	void CWarningWidget::m_Destroy()
	{
		m_MessageLabel->Release();
		if(m_loadingType == WARNING_WITH_LOADING)
		{
			
		}
		else
		{
			
		}
		
		
	}

	void CWarningWidget::m_ResizeWindow()
	{

	}

	void CWarningWidget::SetMessageText(const char* pMessage)
	{
		m_MessageLabel->SetText(pMessage);
		m_ResizeWindow();
		m_MessageLabel->Show();
	}

	void CWarningWidget::SetMessageTextColor(const ClutterColor textcolor)
	{
		m_MessageLabel->SetTextColor(textcolor);
	}

	void CWarningWidget::m_ShowAni()
	{

	}

	void CWarningWidget::m_ShowTTS()
	{

	}

}