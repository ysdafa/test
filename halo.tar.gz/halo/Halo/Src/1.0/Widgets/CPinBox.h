#ifndef _CPinBox_H_
#define _CPinBox_H_
#include "Halo.h"
#include "Halo1_0.h"
namespace HALO
{
	class  CBaseInputBox : public CActor , public IFocusListener , public IMouseListener
	{
	public:
		enum EInputBoxState
		{
			E_STATE_NORMAL = 0,
			E_STATE_FOCUSED,
			E_STATE_ALL,
		};
	public:
		CBaseInputBox();
		virtual ~CBaseInputBox();
		virtual bool Initialize(IActor *parent ,  float width , float height);

		virtual bool Initialize(Widget *parent ,  float width , float height);

		virtual void SetInputBoxBackGroundImage(EInputBoxState pinstate , const std::string& iconPath);

		virtual void Resize(float width, float height);
	protected:

		float t_boxwidth;

		float t_boxheight;

		virtual bool OnMousePointerIn(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);

		//! The callback function when mouse pointer out.
		virtual bool OnMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);

		virtual bool OnFocusIn(IWidgetExtension* pWindow);

		virtual bool OnFocusOut(IWidgetExtension* pWindow);
	
	private:
		ICompositeImage* m_BoxImage;

		std::string m_focusImagePath;

		std::string m_unfocusImagePath;

		int m_curState;

		void m_ChangeStateTo(EInputBoxState toState);

		void m_OnStateChange(void);

		void m_Initialize(void);

		void m_Destroy();
	};

	class  IPinNumberListener
	{
	public:
		IPinNumberListener(){};

		virtual ~IPinNumberListener(){};

		virtual void OnValidConfirm(class CPinBox* list ,  bool isPassWordRight){};

		virtual void OutputPassWord(class CPinBox* list , std::string inputPassWord){};
	};

	class CPinBox : public CBaseInputBox , public IKeyboardListener 
	{
		typedef CBaseInputBox ParentType;
	public:
		enum
		{
			ITEM_FIRST = 0, //!< the first item. 
			ITEM_SECOND,	//!< the second item. 
			ITEM_THIRD,		//!< the third item. 
			ITEM_FOURTH,	//!< the fourth item. 
			MAX_ITEM		//!< the max item count. 
		};

		enum EInputBoxsState
		{
			E_STATE_NOINPUT = 0,
			E_STATE_FINISHINPUT,
			E_STATE_ALL
		};

		enum 
		{
			MAX_INPUT_DIGIT = 10,
			MAX_ARRAY_LENGHT = 500,			//!< the max array length. 
		};
	public:
		CPinBox();

		virtual ~CPinBox();

		virtual bool Initialize(IActor *parent ,  float width , float height , bool isCheck);

		virtual bool Initialize(Widget *parent ,  float width , float height , bool isCheck);

		virtual bool AddListener(IPinNumberListener* listener);

		virtual bool RemoveListener();

		virtual void SetInputItemsGap(EInputBoxsState inputboxState , float gap);

		virtual void SetInputItemSize(EInputBoxsState inputboxState , float w , float h);

		virtual void SetInputItemImage(EInputBoxsState inputboxState  , const std::string& iconPath);

		virtual void SetDigitTextFontSize(int fontSize);

		virtual int DigitTextFontSize(void);

		virtual void SetDigitTextColor(const ClutterColor color);

		virtual ClutterColor DigitTextColor(void);

		virtual void SetDigitTextFont(const char* font);

		virtual const char* DigitTextFont(void);

		virtual void SetDigitTextSize(float w, float h);

		virtual void SetDigitGap(float gap);

		virtual void ResetPassword();

	protected:
		int t_focusPos;

		int t_processStep;
		
		bool t_IsCheck;

		virtual bool OnKeyPressed(IWidgetExtension* pThis, IKeyboardEvent* event);

		virtual bool OnKeyReleased(IWidgetExtension* pThis, IKeyboardEvent* event);
	private:
		void m_Destroy();

		int m_PinInput[MAX_ITEM];

		float m_itemwidth;

		float m_itemheight;

		float m_textwidth;

		float m_textheight;

		float m_ParentW;

		float m_ParentH;

		float m_ItemGap1;

		float m_ItemGap2;

		float m_Digitgap;

		const char* m_strPwd;

		std::string m_tempPwd;

		//std::vector<const char*> m_InputPassWord;
		std::string m_InputPassWord;

		IPinNumberListener* m_Listener;

		bool m_CheckPassWord();

		void m_Initialize(void);

		void m_ChangrStateTo(EInputBoxsState toBoxState , int itemindex);

		void m_ChangeDigitTo(int number , int itemindex);

		const char* m_GetPassWordByVconf();


		IImage* m_NoInputImage[MAX_ITEM];

		IImage* m_FinishImage[MAX_ITEM];

		IText* m_PinText[MAX_ITEM];

		std::string m_noInputImagePath;
		std::string m_finishInputImagePath;
	};
}
#endif