#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{

	IWizardWidget* IWizardWidget::CreateInstance(IActor* parent, int nTotalStep, int nNavigationButtonType)
	{
		CWizardWidget* wizardWidget = dynamic_cast<CWizardWidget*>(Instance::CreateInstance(CLASS_ID_IWIZARDWIDGET));

		if (NULL != wizardWidget)
		{
			wizardWidget->Initialize(parent, nTotalStep, nNavigationButtonType);
		}

		return wizardWidget;
	}
}