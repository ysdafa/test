#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	IWarningWidget* IWarningWidget::CreateInstance(IActor* parent, const TWarningWidgetAttr &attr)
	{
		CWarningWidget* warningWidget = dynamic_cast<CWarningWidget*>(Instance::CreateInstance(CLASS_ID_IWARNINGWIDGET));

		if (NULL != warningWidget)
		{
			warningWidget->Initialize(parent , attr);
		}
		return warningWidget;
	}

}