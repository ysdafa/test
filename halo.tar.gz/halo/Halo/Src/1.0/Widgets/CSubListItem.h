#ifndef _CSUBLISTITEM_H_
#define _CSUBLISTITEM_H_

namespace HALO
{
	class CSublistItem : public IData
	{
	public:
		struct TImageInfo
		{
			TRect imageAlloc;
			std::string normalImagePath;
			std::string focusedImagePath;
			std::string dimImagePath;
			int normalAlpha;
			int focusAlpha;
			int dimAlpha;

			TImageInfo() : imageAlloc(0,0,0,0), normalImagePath(""), focusedImagePath(""), dimImagePath(""), normalAlpha(255), focusAlpha(255), dimAlpha(25) {}
		};

		struct TTextInfo
		{
			TRect textAlloc;
			std::string itemTextString;
			std::string itemTextFont[3];
			ClutterColor itemTextColor[3];
			EHAlignment hAlign;
			EVAlignment vAlign;

			TTextInfo() : textAlloc(0,0,0,0), itemTextString(""), hAlign(HALIGN_LEFT), vAlign(VALIGN_MIDDLE) 
			{
				for(uint i =0; i < 3; i++)
				{
					itemTextFont[i] = "Sans 20px";
				}
			}
		};

		struct TTextScrollInfo
		{
			guint duration;
			gfloat speed;
			guint delay;
			gint repeat;
			ClutterTextScrollType type;
			ClutterTimelineDirection direction;
			guint continueGap;
			TTextScrollInfo() : duration(5000), speed(0.1f), delay(10), repeat(-1), type(CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_OUTSIDE), direction(CLUTTER_TIMELINE_BACKWARD), continueGap(0) {}
		};

	public:
		CSublistItem(void)
		{
			itemIndex = 0;
			ifDim = false;
			ifFocused = false;
			ifChecked = false;
		}

		~CSublistItem()
		{

		}

		void SetItemImageData(const int nId, const TImageInfo &itemImageInfo);
		void SetItemImage2Data(const int nId, const TImageInfo &itemImageInfo);
		void SetItemTextData(const int nId, const TTextInfo &textInfo);
		void SetItemText2Data(const int nId, const TTextInfo &textInfo);
		void SetItemTextScrollInfo(const int nId, const TTextScrollInfo &itemTextScrollInfo);
		void SetBGNormalColor(const int nId, const ClutterColor &itemBGColor);
		void SetBGFocusedColor(const int nId, const ClutterColor &itemBGColor);
		void SetBGDimColor(const int nId, const ClutterColor &itemBGColor);

		int itemIndex;
		ClutterColor ItemBGNormalColor;
		ClutterColor ItemBGFocusedColor;
		ClutterColor ItemBGDimColor;
		TImageInfo imageInfo[2];
		TTextInfo itemTextInfo[2];
		TTextScrollInfo textScrollInfo;
		bool ifDim;
		bool ifFocused;
		bool ifChecked;
	};
}
#endif
