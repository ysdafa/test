#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	IMessageBox* IMessageBox::CreateInstance(IActor* parent, const TMessageBoxAttr &attr)
	{
		CMessageBox* messageBox = dynamic_cast<CMessageBox*>(Instance::CreateInstance(CLASS_ID_IMESSAGEBOX));
		if (NULL != messageBox)
		{
			messageBox->Initialize(parent, attr);
		}
		return messageBox;
	}

	IMessageBox* IMessageBox::CreateInstance(Widget* parent, const TMessageBoxAttr &attr)
	{
		CMessageBox* messageBox = dynamic_cast<CMessageBox*>(Instance::CreateInstance(CLASS_ID_IMESSAGEBOX));
		ASSERT(messageBox != NULL);

		if (messageBox != NULL)
		{
			messageBox->Initialize(parent, attr);
		}

		return messageBox;
	}
}
