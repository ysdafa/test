#include "Halo1_0.h"

namespace HALO
{
	void CSubListRenderer::Draw(IData *data, IActor* parent, E_DRAW_TYPE drawType)
	{
		t_itemData = static_cast<CSublistItem*>(data);

		switch (drawType)
		{
		case LOAD_DATA_DRAW:
		case UPDATE_DATA_DRAW:
			{
				for(uint i = 0; i < 2; i++)
				{		
					t_itemText[i]->SetText((t_itemData->itemTextInfo[i].itemTextString).c_str());
					t_itemText[i]->SetPosition(t_itemData->itemTextInfo[i].textAlloc.x, t_itemData->itemTextInfo[i].textAlloc.y);
					t_itemText[i]->Resize(t_itemData->itemTextInfo[i].textAlloc.w, t_itemData->itemTextInfo[i].textAlloc.h);
					t_itemText[i]->SetTextAlignment(t_itemData->itemTextInfo[i].hAlign, t_itemData->itemTextInfo[i].vAlign);
					t_itemText[i]->SetScrollAttribute(t_itemData->textScrollInfo.duration, t_itemData->textScrollInfo.speed, t_itemData->textScrollInfo.delay, t_itemData->textScrollInfo.repeat, t_itemData->textScrollInfo.type, t_itemData->textScrollInfo.direction, t_itemData->textScrollInfo.continueGap);
					t_iconImage[i]->SetPosition(t_itemData->imageInfo[i].imageAlloc.x, t_itemData->imageInfo[i].imageAlloc.y);
					t_iconImage[i]->Resize(t_itemData->imageInfo[i].imageAlloc.w, t_itemData->imageInfo[i].imageAlloc.h);
				}
				m_UpdateItem(parent);
			}
			break;

		case UNLOAD_DATA_DRAW:
			{
			}
			break;

		case ITEM_SCROLL_DRAW:
			
			break;

		case FOCUS_CHANGE_START_FROM_DRAW:
			{
				t_itemData->ifFocused = false;
				if(t_itemData->ifDim)
				{
					parent->SetBackgroundColor(t_itemData->ItemBGDimColor);
					for(uint i = 0; i < 2; i++)
					{
						t_itemText[i]->SetFont((t_itemData->itemTextInfo[i].itemTextFont[2]).c_str());
						t_itemText[i]->SetTextColor(t_itemData->itemTextInfo[i].itemTextColor[2]);
						if(0 != t_itemData->textScrollInfo.speed)
						{
							t_itemText[i]->StopScrollText();
						}

						if("" != t_itemData->imageInfo[i].dimImagePath)
						{
							t_iconImage[i]->SetImage((t_itemData->imageInfo[i].dimImagePath).c_str());
							t_iconImage[i]->SetAlpha(t_itemData->imageInfo[i].dimAlpha);
						}
					}
				}
				else
				{
					parent->SetBackgroundColor(t_itemData->ItemBGNormalColor);
					for(uint i = 0; i < 2; i++)
					{	
						t_itemText[i]->SetTextColor(t_itemData->itemTextInfo[i].itemTextColor[0]);
						t_itemText[i]->SetFont((t_itemData->itemTextInfo[i].itemTextFont[0]).c_str());
						if(0 != t_itemData->textScrollInfo.speed)
						{
							t_itemText[i]->StopScrollText();
						}

						if("" != t_itemData->imageInfo[i].normalImagePath)
						{
							t_iconImage[i]->SetImage((t_itemData->imageInfo[i].normalImagePath).c_str());
							t_iconImage[i]->SetAlpha(t_itemData->imageInfo[i].normalAlpha);
						}
					}
				}
			}
			break;

		case FOCUS_CHANGE_START_TO_DRAW:

			break;
				
		case FOCUS_CHANGE_FINISH_FROM_DRAW:

			break;

		case FOCUS_CHANGE_FINISH_TO_DRAW:
			{
				t_itemData->ifFocused = true;
				if(t_itemData->ifDim)
				{
					parent->SetBackgroundColor(t_itemData->ItemBGFocusedColor);
					for(uint i = 0; i < 2; i++)
					{
						t_itemText[i]->SetFont((t_itemData->itemTextInfo[i].itemTextFont[2]).c_str());
						t_itemText[i]->SetTextColor(t_itemData->itemTextInfo[i].itemTextColor[2]);
						if(0 != t_itemData->textScrollInfo.speed)
						{
							t_itemText[i]->StopScrollText();
						}

						if("" != t_itemData->imageInfo[i].dimImagePath)
						{
							t_iconImage[i]->SetImage((t_itemData->imageInfo[i].dimImagePath).c_str());
							t_iconImage[i]->SetAlpha(t_itemData->imageInfo[i].dimAlpha);
						}
					}
				}
				else
				{
					parent->SetBackgroundColor(t_itemData->ItemBGFocusedColor);
					for(uint i = 0; i < 2; i++)
					{
						t_itemText[i]->SetTextColor(t_itemData->itemTextInfo[i].itemTextColor[1]);
						t_itemText[i]->SetFont((t_itemData->itemTextInfo[i].itemTextFont[1]).c_str());
						if(0 != t_itemData->textScrollInfo.speed)
						{
							t_itemText[i]->StartScrollText();
						}

						if("" != t_itemData->imageInfo[i].focusedImagePath)
						{
							t_iconImage[i]->SetImage((t_itemData->imageInfo[i].focusedImagePath).c_str());
							t_iconImage[i]->SetAlpha(t_itemData->imageInfo[i].focusAlpha);
						}
					}
				}
			}
			break;
		default:
			break;
		}
	}

	void CSubListRenderer::GetParentPosition(float &X, float &Y)
	{
		t_iconImage[0]->Parent()->GetPosition(X, Y);
	}

	void CSubListRenderer::ImageShow()
	{
		t_itemData->ifChecked = true;
		t_iconImage[0]->Show();
	}

	void CSubListRenderer::ImageHide()
	{
		t_itemData->ifChecked = false;
		t_iconImage[0]->Hide();
	}

	void CSubListRenderer::SetDim(bool bIfDim)
	{
		t_itemData->ifDim = bIfDim;
		m_UpdateItem(t_iconImage[0]->Parent());
	}

	bool CSubListRenderer::Dim(void)
	{
		return t_itemData->ifDim;
	}

	std::string CSubListRenderer::Text()
	{
		return t_itemText[0]->Text();
	}

	std::string CSubListRenderer::Text2()
	{
		return t_itemText[1]->Text();
	}

	void CSubListRenderer::m_UpdateItem(IActor* parent)
	{
		if(t_itemData->ifChecked)
		{
			ImageShow();
		}
		else
		{
			ImageHide();
		}

		for(uint i = 0; i < 2; i++)
		{		
			if(false == t_itemData->ifDim && t_itemData->ifFocused)
			{
				parent->SetBackgroundColor(t_itemData->ItemBGFocusedColor);
				t_itemText[i]->SetFont((t_itemData->itemTextInfo[i].itemTextFont[1]).c_str());
				t_itemText[i]->SetTextColor(t_itemData->itemTextInfo[i].itemTextColor[1]);
			}
			else if(false == t_itemData->ifDim && false == t_itemData->ifFocused)
			{
				parent->SetBackgroundColor(t_itemData->ItemBGNormalColor);	
				t_itemText[i]->SetFont((t_itemData->itemTextInfo[i].itemTextFont[0]).c_str());
				t_itemText[i]->SetTextColor(t_itemData->itemTextInfo[i].itemTextColor[0]);
			}
			else if(t_itemData->ifDim && t_itemData->ifFocused)
			{
				parent->SetBackgroundColor(t_itemData->ItemBGFocusedColor);
				t_itemText[i]->SetFont((t_itemData->itemTextInfo[i].itemTextFont[2]).c_str());
				t_itemText[i]->SetTextColor(t_itemData->itemTextInfo[i].itemTextColor[2]);
			}
			else if(t_itemData->ifDim && false == t_itemData->ifFocused)
			{
				parent->SetBackgroundColor(t_itemData->ItemBGDimColor);
				t_itemText[i]->SetFont((t_itemData->itemTextInfo[i].itemTextFont[2]).c_str());
				t_itemText[i]->SetTextColor(t_itemData->itemTextInfo[i].itemTextColor[2]);
			}
			else
			{
				// Do nothing
			}

			if(false == t_itemData->ifDim && false == t_itemData->ifFocused && "" != t_itemData->imageInfo[i].normalImagePath)
			{
				t_iconImage[i]->SetImage((t_itemData->imageInfo[i].normalImagePath).c_str());
				t_iconImage[i]->SetAlpha(t_itemData->imageInfo[i].normalAlpha);
			}
			else if(false == t_itemData->ifDim && t_itemData->ifFocused && "" != t_itemData->imageInfo[i].focusedImagePath)
			{
				t_iconImage[i]->SetImage((t_itemData->imageInfo[i].focusedImagePath).c_str());
				t_iconImage[i]->SetAlpha(t_itemData->imageInfo[i].focusAlpha);
			}
			else if(t_itemData->ifDim && "" != t_itemData->imageInfo[i].dimImagePath)
			{
				t_iconImage[i]->SetImage((t_itemData->imageInfo[i].dimImagePath).c_str());
				t_iconImage[i]->SetAlpha(t_itemData->imageInfo[i].dimAlpha);
			}
			else
			{
				// Do nothing
			}
		}			
	}
}

