#include "Halo1_0.h"
static HALO::util::Logger LOGGER("SubList");

namespace HALO
{         
	class CSubListListenerSet : public ListenerSet
	{
	public:
		struct TSubListListenerData
		{
			int type;
			int param[2];
			void* pData;
		};

		CSubListListenerSet(CSubList* owner) :m_owner(owner){}
		virtual ~CSubListListenerSet(void){}

		virtual bool Process(TSubListListenerData* data);

	private:
		CSubList* m_owner;
	};

	bool CSubListListenerSet::Process(TSubListListenerData* data)
	{
		bool ret = false;
		Lock();

		if (NULL != data)
		{
			ListenerList::iterator iter = m_list.begin();

			while (iter != m_list.end())
			{
				ISubListListener* listener = (ISubListListener*)(*iter);
				
				switch(data->type)
				{
				case ISubListListener::ON_ITEM_CLICKED:
					ret |= listener->OnItemClicked(m_owner, data->param[0]);
					break;
				case ISubListListener::ON_FOCUS_CHANGED:
					ret |= listener->OnFocusChanged(m_owner, data->param[0], data->param[1]);
					break;
				case ISubListListener::ON_ENTER_KEY_LONG_PRESSED:
					ret |= listener->OnEnterKeyLongPressed(m_owner, data->param[0]);
					break;
				case ISubListListener::TIME_OUT:
					ret |= listener->OnTimeOut(m_owner);
					break;
				default:
					break;
				}	
				if (m_list.empty())
				{
					break;
				}
				iter++;
			}
		}

		Unlock();
		return ret;
	}

	//CSubList
	CSubList::CSubList():t_singleLineListControlAttr(200,72,EDirectionType::TYPE_VERTICAL)
	{
		H_LOG_0_PARAM(FATAL, LOGGER);
	}

	CSubList::~CSubList()
	{
		H_LOG_0_PARAM(FATAL, LOGGER);
		m_Destroy();
	}

	bool CSubList::Initialize( IActor* parent, const TSubListAttr &attr )
	{
		H_LOG_FATAL(LOGGER, "[" << this <<"]CSubList::Initialize with IActor parent");
		Widget *widget = dynamic_cast<Widget *>(parent);
		return Initialize(widget, attr);
	}
	
	bool CSubList::Initialize( Widget* parent, const TSubListAttr &attr )
	{
		H_LOG_FATAL(LOGGER, "[" << this <<"]CSubList::Initialize with Widget parent");
		HALO_ASSERT(attr.w > 0 && attr.h > 0);
		m_Initialize();
		t_parentWidth = attr.w;
		t_parentHeight = attr.h;

		t_nTotalItemNumber = attr.nTotalItemNumber;
		t_nItemNumberOnWindow = attr.nItemNumberOnWindow;

		t_singleLineListControlAttr.width = attr.singleLineListWidth;
		t_singleLineListControlAttr.height = attr.singleLineListHeight;
		t_singleLineListControlAttr.type = attr.singleLineListType;

		m_CreateBG(parent, attr);

		m_CreateList();

		t_pSubListListenerSet = new class CSubListListenerSet(this);

		CActor::EnableFocus(true);
		AddKeyboardListener(this);
		AddMouseListener(this);

		return true;
	}

	void CSubList::SetFirstLayerBGColor(const ClutterColor BGColor)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		t_firstLayerBG->SetBackgroundColor(BGColor);
	}

	void CSubList::SetSecondLayerBGColor(const ClutterColor BGColor)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		t_secondLayerBG->SetBackgroundColor(BGColor);
	}

	void CSubList::SetThirdLayerBGBorderWidth(float BGBorderWidth)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, BGBorderWidth);
		t_thirdLayerBG->setBorderWidth(BGBorderWidth);
	}

	void CSubList::SetThirdLayerBGBorderColor(const ClutterColor BGBorderColor)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		t_thirdLayerBG->setBorderColor(BGBorderColor);
	}

	void CSubList::SetFourthLayerBGImage(std::string &shadowImagePath)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, shadowImagePath);
		if(shadowImagePath != "")
		{
			t_fourthLayerBG->SetImage(shadowImagePath.c_str());
		}
	}

	void CSubList::AddItem(int itemNum, float *itemSpaceArray, float itemGap)
	{
		H_LOG_3_PARAM(DEBUG, LOGGER, itemNum, itemSpaceArray, itemGap);
		t_singleLineList->AddItem(itemNum, itemSpaceArray, itemGap);
	}

	void CSubList::AddItem(int itemNum, float itemSpace, float itemGap)
	{
		H_LOG_3_PARAM(DEBUG, LOGGER, itemNum, itemSpace, itemGap);
		t_singleLineList->AddItem(itemNum, itemSpace, itemGap);
	}

	void CSubList::AddItemData(const int nId, const TItemDataInfo &itemDataInfo)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		CSublistItem *pPopupItem = new CSublistItem;
		pPopupItem->SetItemImageData(nId, itemDataInfo.imageInfo);
		pPopupItem->SetItemImage2Data(nId, itemDataInfo.image2Info);
		pPopupItem->SetItemTextData(nId, itemDataInfo.textInfo);
		pPopupItem->SetItemText2Data(nId, itemDataInfo.text2Info);
		pPopupItem->SetBGNormalColor(nId, itemDataInfo.itemBGNormalColor);
		pPopupItem->SetBGFocusedColor(nId, itemDataInfo.itemBGFocusedColor);
		pPopupItem->SetBGDimColor(nId, itemDataInfo.itemBGDimColor);
		pPopupItem->SetItemTextScrollInfo(nId, itemDataInfo.itemTextScrollInfo);

		t_ItemVector.push_back( pPopupItem );
	}

	void CSubList::UpdateItem(int itemIndex)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		HALO_ASSERT(itemIndex < t_singleLineList->NumofItem() && itemIndex >= 0);

		t_singleLineList->UpdateItem(itemIndex);
	}

	void CSubList::DeleteItem(int fromItem, int deleteItemNum)
	{
		H_LOG_2_PARAM(DEBUG, LOGGER, fromItem, deleteItemNum);
		HALO_ASSERT(fromItem < t_singleLineList->NumofItem() && fromItem >= 0);

		t_singleLineList->DeleteItem(fromItem, deleteItemNum);
	}

	void CSubList::UpdateAllItems(void)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		t_singleLineList->UpdateAllItems();
	}

	void CSubList::SetDataSource()
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		t_subListDataSource = t_singleLineList->GetDataSource();
		for (uint i = 0; i < t_ItemVector.size(); i++)
		{
			t_ItemVector[i]->SetReady(false);
			t_ItemVector[i]->SetDataLoadType(IData::E_LOAD_TYPE_SYNC);
			t_subListDataSource->AddData(t_ItemVector[i]);
		}

		t_singleLineList->LoadData();

		m_CreateArrowImage();
		CSubListRenderer *subListPreRenderer = dynamic_cast<CSubListRenderer*>(t_singleLineList->Renderer(m_checkedItemIndex));
		if(subListPreRenderer)
		{
			subListPreRenderer->ImageShow();
		}
		else
		{
			CSublistItem* itemData = (CSublistItem*)t_subListDataSource->GetData(m_checkedItemIndex);
			itemData->ifChecked = true;
		}
	}

	ISingleLineDataSource* CSubList::GetDataSource(void)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		return t_subListDataSource;
	}

	IRenderer* CSubList::GetRenderer(IData *data, IActor *parent)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		return new CSubListRenderer(parent);
	}

	void CSubList::SetFocusItemIndex(const int itemIndex)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, itemIndex);
		HALO_ASSERT(itemIndex < t_singleLineList->NumofItem() && itemIndex >= 0);

		t_singleLineList->SetFocusItemIndex(itemIndex);
	}
	
	int CSubList::FocusItemIndex(void) const
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		return t_singleLineList->FocusItemIndex();
	}

	bool CSubList::ShowFocus(bool flagAnimation)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, flagAnimation);
		t_singleLineList->ShowFocus(flagAnimation);
		return true;
	}

	bool CSubList::HideFocus(bool flagAnimation)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, flagAnimation);
		t_singleLineList->HideFocus(flagAnimation);
		return true;
	}

	bool CSubList::SetFocus(void)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		t_singleLineList->SetFocus();
		return true;
	}

	void CSubList::KillFocus(void)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		t_singleLineList->KillFocus();
	}
	
	void CSubList::SetSingleLineListPosition(const float x, const float y)
	{
		H_LOG_2_PARAM(DEBUG, LOGGER, x, y);
		t_singleLineList->SetPosition(x, y);
	}

	void CSubList::SetArrowImageAttr(EArrowDirections arrowDirection, const TArrowAttr &arrowAttr)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		switch(arrowDirection)
		{
		case UP_ARROW:
			{
				if(m_upArrowImage)
				{
					m_arrowAttr[0] = arrowAttr;
					m_upArrowImage->SetPosition(arrowAttr.x, arrowAttr.y);
					m_upArrowImage->Resize(arrowAttr.w, arrowAttr.h);
					m_ChangeArrowImage(UP_ARROW, m_arrowAttr[0].arrowNormalImagePath, m_arrowAttr[0].normalAlpha);	
				}
			}
			break;
		case DOWN_ARROW:
			{
				if(m_downArrowImage)
				{
					m_arrowAttr[1] = arrowAttr;
					m_downArrowImage->SetPosition(arrowAttr.x, arrowAttr.y);
					m_downArrowImage->Resize(arrowAttr.w, arrowAttr.h);
					m_ChangeArrowImage(DOWN_ARROW, m_arrowAttr[1].arrowNormalImagePath, m_arrowAttr[1].normalAlpha);
				}
			}
			break;
		case LEFT_ARROW:
			{
				if(m_leftArrowImage)
				{
					m_arrowAttr[2] = arrowAttr;
					m_leftArrowImage->SetPosition(arrowAttr.x, arrowAttr.y);
					m_leftArrowImage->Resize(arrowAttr.w, arrowAttr.h);
					m_ChangeArrowImage(LEFT_ARROW, m_arrowAttr[2].arrowNormalImagePath, m_arrowAttr[2].normalAlpha);
				}
			}
			break;
		case RIGHT_ARROW:
			{
				if(m_rightArrowImage)
				{
					m_arrowAttr[3] = arrowAttr;
					m_rightArrowImage->SetPosition(arrowAttr.x, arrowAttr.y);
					m_rightArrowImage->Resize(arrowAttr.w, arrowAttr.h);
					m_ChangeArrowImage(RIGHT_ARROW, m_arrowAttr[3].arrowNormalImagePath, m_arrowAttr[3].normalAlpha);
				}
			}
			break;
		default: 
			break;
		}
	}

	void CSubList::SetButtonAttr(const TRect &buttonImageRect, std::string &buttonNormalImagePath, std::string &buttonFocusedImagePath, std::string &buttonDimImagePath)
	{

	}

	void CSubList::SetCheckItemIndex(int checkedItemIndex)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, checkedItemIndex);
		HALO_ASSERT(checkedItemIndex < t_singleLineList->NumofItem() && checkedItemIndex >= 0);

		CSubListRenderer *subListPreRenderer = dynamic_cast<CSubListRenderer*>(t_singleLineList->Renderer(m_checkedItemIndex));

		CSubListRenderer *subListRenderer = dynamic_cast<CSubListRenderer*>(t_singleLineList->Renderer(checkedItemIndex));

		if(subListPreRenderer && subListRenderer)
		{
			if(false == subListRenderer->Dim() && false == subListPreRenderer->Dim())
			{
				subListPreRenderer->ImageHide();
				subListRenderer->ImageShow();
				m_checkedItemIndex = checkedItemIndex;
			}
		}
		else if(subListPreRenderer && NULL == subListRenderer)
		{
			CSublistItem* itemData = (CSublistItem*)t_subListDataSource->GetData(checkedItemIndex);
			if(false == subListPreRenderer->Dim() && false == itemData->ifDim)
			{
				subListPreRenderer->ImageHide();
				itemData->ifChecked = true;
				m_checkedItemIndex = checkedItemIndex;
			}
		}
		else if(subListRenderer && NULL == subListPreRenderer)
		{
			CSublistItem* itemData = (CSublistItem*)t_subListDataSource->GetData(m_checkedItemIndex);
			if(false == itemData->ifDim && false == subListRenderer->Dim())
			{
				itemData->ifChecked = false;
				subListRenderer->ImageShow();
				m_checkedItemIndex = checkedItemIndex;
			}
		}
		else
		{
			// Do nothing
		}
	}

	int CSubList::CheckItemIndex() const
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		return m_checkedItemIndex;
	}

	int CSubList::NumofItem()
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		return t_singleLineList->NumofItem();
	}

	void CSubList::SetDimItem(int itemIndex, bool ifDim)
	{
		H_LOG_2_PARAM(DEBUG, LOGGER, itemIndex, ifDim);
		HALO_ASSERT(itemIndex < t_singleLineList->NumofItem() && itemIndex >= 0);

		CSubListRenderer *subListRenderer = dynamic_cast<CSubListRenderer*>(t_singleLineList->Renderer(itemIndex));
		if(subListRenderer)
		{
			subListRenderer->SetDim(ifDim);
		}
		else
		{
			CSublistItem* itemData = (CSublistItem*)t_subListDataSource->GetData(itemIndex);
			itemData->ifDim = ifDim;
		}
	}

	bool CSubList::IfDim(int itemIndex)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, itemIndex);
		HALO_ASSERT(itemIndex < t_singleLineList->NumofItem() && itemIndex >= 0);

		CSubListRenderer *subListRenderer = dynamic_cast<CSubListRenderer*>(t_singleLineList->Renderer(itemIndex));
		if(subListRenderer)
		{
			return subListRenderer->Dim();
		}
		else
		{
			CSublistItem* itemData = (CSublistItem*)t_subListDataSource->GetData(itemIndex);
			return itemData->ifDim;
		}
	}

	std::string CSubList::Text(int itemIndex)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, itemIndex);
		if(itemIndex < 0 || itemIndex >= t_singleLineList->NumofItem())
		{
			return "";
		}
		CSubListRenderer *subListRenderer = dynamic_cast<CSubListRenderer*>(t_singleLineList->Renderer(itemIndex));
		if(subListRenderer)
		{
			return subListRenderer->Text();
		}
		else
		{
			CSublistItem* itemData = (CSublistItem*)t_subListDataSource->GetData(itemIndex);
			return itemData->itemTextInfo[0].itemTextString;
		}
	}

	std::string CSubList::Text2(int itemIndex)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, itemIndex);
		if(itemIndex < 0 || itemIndex >= t_singleLineList->NumofItem())
		{
			return "";
		}
		CSubListRenderer *subListRenderer = dynamic_cast<CSubListRenderer*>(t_singleLineList->Renderer(itemIndex));
		if(subListRenderer)
		{
			return subListRenderer->Text2();
		}
		else
		{
			CSublistItem* itemData = (CSublistItem*)t_subListDataSource->GetData(itemIndex);
			return itemData->itemTextInfo[1].itemTextString;
		}
	}

	void CSubList::SetAnimationDuration(ISingleLineListControl::ESingleLineAniType aniType, int duration)
	{
		H_LOG_2_PARAM(DEBUG, LOGGER, aniType, duration);
		t_singleLineList->SetAnimationDuration(aniType, duration);
	}

	bool CSubList::AddListener(ISubListListener* listener)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, listener);
		HALO_ASSERT(listener != NULL);

		return t_pSubListListenerSet->Add(listener);
	}

	bool CSubList::RemoveListener(ISubListListener* listener)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, listener);
		HALO_ASSERT(listener != NULL);

		return t_pSubListListenerSet->Remove(listener);
	}

	void CSubList::SetShowTime(guint nShowTime)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, nShowTime);
		if(nShowTime < 0)
		{
			return;
		}

		m_showTime = nShowTime;
		if(0 != m_showTimerId)
		{
			g_source_remove(m_showTimerId);
			m_showTimerId = 0;
		}
		if(nShowTime > 0)
		{
			m_showTimerId = g_timeout_add(m_showTime, (GSourceFunc)m_ShowTimeFinishedCB, this);
		}
	}

	guint CSubList::ShowTime() const
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		return m_showTime;
	}

	gboolean CSubList::m_ShowTimeFinishedCB(gpointer data)
	{
		CSubList* subList = reinterpret_cast<CSubList *>(data);
		if(NULL == subList)
		{
			return false;
		}
		subList->Hide();
		if (subList->t_pSubListListenerSet)
		{
			CSubListListenerSet::TSubListListenerData data;
			data.type = ISubListListener::TIME_OUT;
			data.param[0] = 0;
			data.param[1] = 0;
			subList->t_pSubListListenerSet->Process(&data);
		}
		return false;
	}

	void CSubList::m_ResetShowTime()
	{
		if (m_showTimerId > 0)
		{
			g_source_remove(m_showTimerId);
			m_showTimerId = 0;
			if(m_showTime > 0)
			{
				m_showTimerId = g_timeout_add(m_showTime, (GSourceFunc)m_ShowTimeFinishedCB, this);
			}
		}
	}

	bool CSubList::OnMousePointerIn(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		m_ResetShowTime();

		if(m_upArrowImage && pWindow == m_upArrowImage)
		{
			m_ChangeArrowImage(UP_ARROW, m_arrowAttr[0].arrowFocusedImagePath, m_arrowAttr[0].focusAlpha);
		}
		else if(m_downArrowImage && pWindow == m_downArrowImage)
		{
			m_ChangeArrowImage(DOWN_ARROW, m_arrowAttr[1].arrowFocusedImagePath, m_arrowAttr[1].focusAlpha);
		}
		else if(m_leftArrowImage && pWindow == m_leftArrowImage)
		{
			m_ChangeArrowImage(LEFT_ARROW, m_arrowAttr[2].arrowFocusedImagePath, m_arrowAttr[2].focusAlpha);
		}
		else if(m_rightArrowImage && pWindow == m_rightArrowImage)
		{
			m_ChangeArrowImage(RIGHT_ARROW, m_arrowAttr[3].arrowFocusedImagePath, m_arrowAttr[3].focusAlpha);
		}
		else
		{
			return false;
		}

		return true;
	}
	
	bool CSubList::OnMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		m_ResetShowTime();

		if(m_upArrowImage && pWindow == m_upArrowImage)
		{
			m_ChangeArrowImage(UP_ARROW, m_arrowAttr[0].arrowNormalImagePath, m_arrowAttr[0].normalAlpha);
		}
		else if(m_downArrowImage && pWindow == m_downArrowImage)
		{
			m_ChangeArrowImage(DOWN_ARROW, m_arrowAttr[1].arrowNormalImagePath, m_arrowAttr[1].normalAlpha);
		}
		else if(m_leftArrowImage && pWindow == m_leftArrowImage)
		{
			m_ChangeArrowImage(LEFT_ARROW, m_arrowAttr[2].arrowNormalImagePath, m_arrowAttr[2].normalAlpha);
		}
		else if(m_rightArrowImage && pWindow == m_rightArrowImage)
		{
			m_ChangeArrowImage(RIGHT_ARROW, m_arrowAttr[3].arrowNormalImagePath, m_arrowAttr[3].normalAlpha);
		}
		else
		{
			return false;
		}

		return true;
	}

	bool CSubList::OnKeyPressed(IWidgetExtension* pThis, IKeyboardEvent* event)
	{
		m_flagMousePressed = true;

		return true;
	}

	bool CSubList::OnKeyReleased( IWidgetExtension* pWindow, IKeyboardEvent* ptrKeyboardEvent )
	{
		m_ResetShowTime();

		int keyValue = ptrKeyboardEvent->GetKeyVal();
	
		switch (keyValue)
		{
		case CLUTTER_KEY_Up:
			if(t_singleLineList != pWindow)
			{
				t_singleLineList->MoveFocus(DIRECTION_UP);
			}
			break;
		case CLUTTER_KEY_Down:
			if(t_singleLineList != pWindow)
			{
				t_singleLineList->MoveFocus(DIRECTION_DOWN);
			}
			break;
		case CLUTTER_KEY_Left:
			if(t_singleLineList != pWindow)
			{
				t_singleLineList->MoveFocus(DIRECTION_LEFT);
			}
			break;
		case CLUTTER_KEY_Right:
			if(t_singleLineList != pWindow)
			{
				t_singleLineList->MoveFocus(DIRECTION_RIGHT);
			}
			break;
		case CLUTTER_KEY_Return:
			{
				if(t_singleLineList == pWindow && m_flagMousePressed)
				{
					m_ItemClicked(t_singleLineList->FocusItemIndex());
				}
			}
			break;
		default: 
			break;
		}
		m_flagMousePressed = false;
		return true;
	}

	bool CSubList::OnMouseButtonReleased(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		m_ResetShowTime();
		if(m_upArrowImage && pWindow == m_upArrowImage)
		{
			t_singleLineList->MoveFocus(DIRECTION_UP);
		}
		else if(m_downArrowImage && pWindow == m_downArrowImage)
		{
			t_singleLineList->MoveFocus(DIRECTION_DOWN);
		}
		else if(m_leftArrowImage && pWindow == m_leftArrowImage)
		{
			t_singleLineList->MoveFocus(DIRECTION_LEFT);
		}
		else if(m_rightArrowImage && pWindow == m_rightArrowImage)
		{
			t_singleLineList->MoveFocus(DIRECTION_RIGHT);
		}
		else
		{
			return false;
		}
		return true;
	}

	bool CSubList::OnMouseMoved(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		m_ResetShowTime();
		return true;
	}

	bool CSubList::OnItemClicked(class ISingleLineListControl* list, int itemIndex)
	{
		m_ResetShowTime();

		m_ItemClicked(itemIndex);
		return true;
	}

	bool CSubList::OnFocusChanged(class ISingleLineListControl* list, int fromItemIndex, int toItemIndex)
	{
		m_ResetShowTime();

		if (t_pSubListListenerSet)
		{
			CSubListListenerSet::TSubListListenerData data;
			data.type = ISubListListener::ON_FOCUS_CHANGED;
			data.param[0] = fromItemIndex;
			data.param[1] = toItemIndex;
			t_pSubListListenerSet->Process(&data);
		}
		return true;
	}

	bool CSubList::OnEnterKeyLongPressed(class ISingleLineListControl *list, int itemIndex)
	{
		if (t_pSubListListenerSet)
		{
			CSubListListenerSet::TSubListListenerData data;
			data.type = ISubListListener::ON_ENTER_KEY_LONG_PRESSED;
			data.param[0] = itemIndex;
			data.param[1] = 0;
			t_pSubListListenerSet->Process(&data);
		}
		return true;
	}

	bool CSubList::OnFocusIn(IWidgetExtension* pWindow)
	{
		if(t_singleLineList == pWindow)
		{
			t_singleLineList->ShowFocus(false);
			return true;
		}
		return false;
	}

	bool CSubList::OnFocusOut(IWidgetExtension* pWindow)
	{
		if(t_singleLineList == pWindow)
		{
			t_singleLineList->HideFocus(false);
			return true;
		}
		return false;
	}

	void CSubList::m_Initialize()
	{
		t_parentHeight = 0;
		t_parentWidth = 0;
		t_nTotalItemNumber = 0;
		t_nItemNumberOnWindow = 5;

		t_singleLineList = NULL;
		t_firstLayerBG = NULL;
		t_secondLayerBG = NULL;
		t_thirdLayerBG = NULL;
		t_fourthLayerBG = NULL;
		t_ItemVector.clear();
		t_subListDataSource = NULL;

		m_upArrowImage = NULL;
		m_downArrowImage = NULL;
		m_leftArrowImage = NULL;
		m_rightArrowImage = NULL;

		m_checkedItemIndex = 0;
		m_showTimerId = 0;
		m_showTime = 0;
		m_flagMousePressed = false;
	}

	void CSubList::m_CreateBG(Widget* parent, const TSubListAttr &attr)
	{
		ClutterColor BgColor = {0,0,0,0};
		CActor::Initialize(parent, t_parentWidth, t_parentHeight + 4);
		CActor::SetPosition(attr.x, attr.y);
		CActor::SetBackgroundColor(BgColor);
		
		t_firstLayerBG = dynamic_cast<CActor*>(IActor::CreateInstance(dynamic_cast<Widget*>(this), t_parentWidth, t_parentHeight));
		t_firstLayerBG->SetBackgroundColor(*clutter_color_init(&BgColor, 39,124,175,200));

		t_secondLayerBG = dynamic_cast<CActor*>(IActor::CreateInstance(dynamic_cast<Widget*>(this), t_parentWidth, t_parentHeight));
		t_secondLayerBG->SetBackgroundColor(*clutter_color_init(&BgColor, 0,0,0,51));

		t_thirdLayerBG = dynamic_cast<CActor*>(IActor::CreateInstance(dynamic_cast<Widget*>(this), t_parentWidth, t_parentHeight));
		t_thirdLayerBG->setBorderWidth(1.0);
		t_thirdLayerBG->setBorderColor(*clutter_color_init(&BgColor, 255,255,255,25));

		t_fourthLayerBG = dynamic_cast<CCompositeImage*>(ICompositeImage::CreateInstance(dynamic_cast<Widget*>(this), t_parentWidth, 4));
		t_fourthLayerBG->SetPosition(0, t_parentHeight);
	}

	void CSubList::m_CreateList()
	{
		if(NULL == t_singleLineList)
		{
			t_singleLineList = dynamic_cast<CSingleLineListControl*>(ISingleLineListControl::CreateInstance(dynamic_cast<Widget*>(this), t_singleLineListControlAttr));
		}
		t_singleLineList->AddListListener(this);
		t_singleLineList->AddKeyboardListener(this);
		t_singleLineList->AddFocusListener(this);
		t_singleLineList->SetRendererProvider(this);
		t_singleLineList->SetAnimationDuration(ISingleLineListControl::ANITYPE_FOCUS_MOVE, 0);
		t_singleLineList->EnableShadowEffect(false);
		t_singleLineList->EnableMarginWhenFocusEdgeItem(false);
		t_singleLineList->EnableUnload(false);
		t_singleLineList->EnableFocus(true);
		t_AddNoticeActor(t_singleLineList);
	}

	void CSubList::m_CreateArrowImage()
	{
		if(t_singleLineList->NumofItem() > t_nItemNumberOnWindow)
		{
			if(TYPE_VERTICAL == t_singleLineListControlAttr.type)
			{
				if(NULL == m_upArrowImage)
				{
					m_upArrowImage = IImage::CreateInstance(dynamic_cast<Widget*>(this), 1, 1);
					m_upArrowImage->AddFocusListener(this);
					m_upArrowImage->AddMouseListener(this);
				}
				if(NULL == m_downArrowImage)
				{
					m_downArrowImage = IImage::CreateInstance(dynamic_cast<Widget*>(this), 1, 1);
					m_downArrowImage->AddFocusListener(this);
					m_downArrowImage->AddMouseListener(this);
				}					
			}
			else if(TYPE_HORIZONTAL == t_singleLineListControlAttr.type)
			{
				if(NULL == m_leftArrowImage)
				{
					m_leftArrowImage = IImage::CreateInstance(dynamic_cast<Widget*>(this), 1, 1);
					m_leftArrowImage->AddFocusListener(this);
					m_leftArrowImage->AddMouseListener(this);
				}
				if(NULL == m_rightArrowImage)
				{
					m_rightArrowImage = IImage::CreateInstance(dynamic_cast<Widget*>(this), 1, 1);
					m_rightArrowImage->AddFocusListener(this);
					m_rightArrowImage->AddMouseListener(this);
				}			
			}
			else
			{
				// Do nothing
			}
		}
	}

	void CSubList::m_ChangeArrowImage(EArrowDirections arrowDirection, std::string &buttonImagePath, int imageAlpha)
	{
		switch(arrowDirection)
		{
		case UP_ARROW:
			{
				if(buttonImagePath != "")
				{
					m_upArrowImage->SetImage((buttonImagePath).c_str());
				}
				m_upArrowImage->SetAlpha(imageAlpha);
			}
			break;
		case DOWN_ARROW:
			{
				if(buttonImagePath != "")
				{
					m_downArrowImage->SetImage((buttonImagePath).c_str());
				}
				m_downArrowImage->SetAlpha(imageAlpha);
			}
			break;
		case LEFT_ARROW:
			{
				if(buttonImagePath != "")
				{
					m_leftArrowImage->SetImage((buttonImagePath).c_str());
				}
				m_leftArrowImage->SetAlpha(imageAlpha);
			}
			break;
		case RIGHT_ARROW:
			{
				if(buttonImagePath != "")
				{
					m_rightArrowImage->SetImage((buttonImagePath).c_str());
				}
				m_rightArrowImage->SetAlpha(imageAlpha);
			}
			break;
		default: 
			break;
		}
	}

	void CSubList::m_ItemClicked(int itemIndex)
	{
		if(itemIndex != t_singleLineList->FocusItemIndex())
		{
			return;
		}

		CSubListRenderer *subListPreRenderer = dynamic_cast<CSubListRenderer*>(t_singleLineList->Renderer(m_checkedItemIndex));

		CSubListRenderer *subListRenderer = dynamic_cast<CSubListRenderer*>(t_singleLineList->Renderer(itemIndex));
		if(subListPreRenderer && subListRenderer)
		{
			if(false == subListRenderer->Dim() && false == subListPreRenderer->Dim())
			{
				subListPreRenderer->ImageHide();
				subListRenderer->ImageShow();
				m_checkedItemIndex = itemIndex;
			}
		}
		else if(subListPreRenderer && NULL == subListRenderer)
		{
			CSublistItem* itemData = (CSublistItem*)t_subListDataSource->GetData(itemIndex);
			if(false == subListPreRenderer->Dim() && false == itemData->ifDim)
			{
				subListPreRenderer->ImageHide();
				itemData->ifChecked = true;
				m_checkedItemIndex = itemIndex;
			}
		}
		else if(subListRenderer && NULL == subListPreRenderer)
		{
			CSublistItem* itemData = (CSublistItem*)t_subListDataSource->GetData(m_checkedItemIndex);
			if(false == itemData->ifDim && false == subListRenderer->Dim())
			{
				itemData->ifChecked = false;
				subListRenderer->ImageShow();
				m_checkedItemIndex = itemIndex;
			}
		}
		else
		{
			// Do nothing
		}
		
		if (t_pSubListListenerSet)
		{
			CSubListListenerSet::TSubListListenerData data;
			data.type = ISubListListener::ON_ITEM_CLICKED;
			data.param[0] = itemIndex;
			data.param[1] = 0;
			t_pSubListListenerSet->Process(&data);
		}
	}

	void CSubList::m_Destroy()
	{
		t_ItemVector.clear();

		if(t_singleLineList)
		{
			t_subListDataSource = NULL;
			t_singleLineList->RemoveKeyboardListener(this);
			t_singleLineList->RemoveFocusListener(this);
			t_singleLineList->Release();
		}

		if(t_firstLayerBG)
		{
			t_firstLayerBG->Release();
		}
		if(t_secondLayerBG)
		{
			t_secondLayerBG->Release();
		}
		if(t_thirdLayerBG)
		{
			t_thirdLayerBG->Release();
		}
		if(t_fourthLayerBG)
		{
			t_fourthLayerBG->Release();
		}

		if(m_upArrowImage)
		{
			m_upArrowImage->RemoveMouseListener(this);
			m_upArrowImage->RemoveFocusListener(this);
			m_upArrowImage->Release();
		}

		if(m_downArrowImage)
		{
			m_downArrowImage->RemoveMouseListener(this);
			m_downArrowImage->RemoveFocusListener(this);
			m_downArrowImage->Release();
		}

		if(m_leftArrowImage)
		{
			m_leftArrowImage->RemoveMouseListener(this);
			m_leftArrowImage->RemoveFocusListener(this);
			m_leftArrowImage->Release();
		}

		if(m_rightArrowImage)
		{
			m_rightArrowImage->RemoveMouseListener(this);
			m_rightArrowImage->RemoveFocusListener(this);
			m_rightArrowImage->Release();
		}

		if (m_showTimerId > 0)
		{
			g_source_remove(m_showTimerId);
			m_showTimerId = 0;
		}

		//delete t_pSubListListenerSet;
		if (t_pSubListListenerSet)
		{
			if (t_pSubListListenerSet->IsLocked())
			{
				t_pSubListListenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(t_pSubListListenerSet);
			} 
			else
			{
				delete t_pSubListListenerSet;
			}
			t_pSubListListenerSet = NULL;
		}

		RemoveKeyboardListener(this);
		RemoveMouseListener(this);
	}
}