#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	IActionPopup* IActionPopup::CreateInstance( IActor* parent, const TActionPopupAttr &attr )
	{
		CActionPopup* actionPopup = dynamic_cast<CActionPopup*>(Instance::CreateInstance(CLASS_ID_IACTIONPOPUP));
		if (NULL != actionPopup)
		{
			actionPopup->Initialize(parent, attr);
		}
		return actionPopup;
	}

}