#include "Halo.h"
#include "Halo1_0.h"
#include <clutter/clutter.h>

#ifdef WIN32
#define IMAGE_PATH "../../../Halo/Src/1.0/Widgets/WizardWidget/images/"
#else
#define IMAGE_PATH "T_HaloSample/Sample/TF_Image/images/"
#endif

namespace HALO
{
	CWizardWidget::CWizardWidget():
	m_pBGImage(NULL),
	m_nNavigationButtonType(0),
	m_nTotalStep(0),
	m_nCurrentStep(0),
	m_pTitle(NULL),
	m_pPreviousButton(NULL),
	m_pNextButton(NULL),
	m_pSkipButton(NULL)
	{
		for(int i = 0; i < 9; i++)
		{
			m_pStepButton[i] = NULL;
		}
		for(int i = 0; i < 10; i++)
		{
			m_pStepLine[i] = NULL;
		}
	}

	CWizardWidget::~CWizardWidget()
	{
		m_Destroy();
	}

	bool CWizardWidget::Initialize(IActor* parent, int nTotalStep, int nNavigationButtonType)
	{
		if (parent == NULL)
		{
			return false;
		}

		m_nTotalStep = nTotalStep;
		if(m_nTotalStep < 0)
		{
			m_nTotalStep = 0;
		}
		m_nNavigationButtonType = nNavigationButtonType;
		m_CreateBG(parent);
		m_CreateTitle(parent);
		m_CreateNavigationButton(parent);

		return t_Initialize();
	}

	void CWizardWidget::Show()
	{
		m_ShowBG();
		m_ShowTitle();
		m_ShowNavigationButton();
	}

	void CWizardWidget::Hide()
	{
		m_HideBG();
		m_HideTitle();
		m_HideNavigationButton();
	}

	void CWizardWidget::SetTitle(const char* pTitle)
	{
		if (m_pTitle != NULL)
		{
			m_pTitle->SetText(pTitle);
		}
		for(int i = 0; i < m_nTotalStep; i++)
		{
			if (m_pStepButton[i] != NULL)
			{
				m_pStepButton[i]->SetPosition((float)((1920 - 102 * m_nTotalStep)/2 + i *102), 0);
			}
		}
	}
	
	void CWizardWidget::SetCurrentStep(int nCurrentStep)
	{
		m_nCurrentStep = nCurrentStep;
		if(m_nCurrentStep > m_nTotalStep)
		{
			m_nCurrentStep = m_nTotalStep;
		}
		if(m_nCurrentStep < 0)
		{
			m_nCurrentStep = 0;
		}
	}

	int CWizardWidget::CurrentStep(void)
	{
		return m_nCurrentStep;
	}

	void CWizardWidget::SetTotalStep(int nTotalStep)
	{
		m_nTotalStep = nTotalStep;
		if(m_nTotalStep < 0)
		{
			m_nTotalStep = 0;
		}
	}

	int CWizardWidget::TotalStep()
	{
		return m_nTotalStep;
	}

	void CWizardWidget::m_CreateBG(IActor* parent)
	{
		//IImageBuffer *imageBuffer ;
		//IImageBuffer::CreateInstance(&imageBuffer);

		//imageBuffer->Initialize(IMAGE_PATH"wizard_bg.bmp");
		//IImage::CreateInstance(&m_pBGImage);
		//m_pBGImage->Initialize(parent, 1920, 1280);
		//m_pBGImage->SetPosition(0, 0);
		//m_pBGImage->SetImage(imageBuffer, false);
	}

	void CWizardWidget::m_ShowBG()
	{
		if ( m_pBGImage != NULL)
		{
			m_pBGImage->Show();
		}
	}

	void CWizardWidget::m_CreateTitle(IActor* parent)
	{
		IImageBuffer *StepSelImageBuffer[9], *stepPreviewImageBuffer[9], *stepSkipImageBuffer[9];
		for(int i = 0; i < 9; i++)//TODO:
		{
			StepSelImageBuffer[i] = IImageBuffer::CreateInstance(IMAGE_PATH"obe_step_1_sel.png");
			stepPreviewImageBuffer[i] = IImageBuffer::CreateInstance(IMAGE_PATH"obe_step_1_preview.png");
			stepSkipImageBuffer[i] = IImageBuffer::CreateInstance(IMAGE_PATH"obe_step_1_skip.png");

			m_pStepButton[i] = IButton::CreateInstance(parent, 42, 40);
			if (NULL != m_pStepButton[i]&& NULL != StepSelImageBuffer[i] && NULL != stepPreviewImageBuffer[i] && NULL != stepSkipImageBuffer[i])
			{
				m_pStepButton[i]->SetPosition(0, 0);
				//m_pStepButton[i]->SetBackgroundImage(IButton::STATE_ALL, stepPreviewImageBuffer[i]);
				//m_pStepButton[i]->SetBackgroundImage(IButton::STATE_ROLL_OVER, StepSelImageBuffer[i]);
				//m_pStepButton[i]->SetBackgroundImage(IButton::STATE_DISABLED, stepSkipImageBuffer[i]);
			}
		}
	}

	void CWizardWidget::m_ShowTitle()
	{
		if (m_pTitle != NULL)
		{
			m_pTitle->Show();
		}
		for(int i = 0; i < m_nTotalStep; i++)
		{
			if (m_pStepButton[i] != NULL)
			{
				m_pStepButton[i]->Show();
			}
		}
	}

	void CWizardWidget::m_HideBG()
	{
		if (m_pBGImage != NULL)
		{
			m_pBGImage->Hide();
		}
	}

	void CWizardWidget::m_HideTitle()
	{
		if (m_pTitle != NULL)
		{
			m_pTitle->Hide();
		}
		for(int i = 0; i < m_nTotalStep; i++)
		{
			if (m_pStepButton[i] != NULL)
			{
				m_pStepButton[i]->Hide();
			}
		}
	}

	void CWizardWidget::m_CreateNavigationButton(IActor* parent)
	{
		IImageBuffer *focusedImageBuffer[3], *unfocusedImageBuffer[3], *disabledImageBuffer[3];

		if(m_nNavigationButtonType & NAVIGATION_BUTTON_TYPE_PREVIOUS)
		{
			m_pPreviousButton= IButton::CreateInstance(parent, 134, 134);
			if (NULL != m_pPreviousButton)
			{
				m_pPreviousButton->SetPosition(0, 473);
				ClutterColor c = {125, 125, 125, 255};
				//m_pPreviousButton->SetText(IButton::E_STATE_FOCUSED, "Previous");
				//m_pPreviousButton->SetTextColor(IButton::E_STATE_FOCUSED, *clutter_color_init(&c, 46, 46, 46, 255));
				////m_pPreviousButton->SetTextFont(IButton::E_STATE_FOCUSED, font);
				//m_pPreviousButton->SetText(IButton::E_STATE_FOCUSED_ROLL_OVER, "Previous");
				//m_pPreviousButton->SetTextColor(IButton::E_STATE_FOCUSED_ROLL_OVER, *clutter_color_init(&c, 46, 46, 46, 255));
				//m_pPreviousButton->SetTextFont(IButton::E_STATE_FOCUSED_ROLL_OVER, "Sans 25px");
				m_pPreviousButton->TextActor()->SetPosition(0, 67);

				focusedImageBuffer[0] = IImageBuffer::CreateInstance(IMAGE_PATH "obe_navi_arrow_l_f.png");
				unfocusedImageBuffer[0] = IImageBuffer::CreateInstance(IMAGE_PATH "obe_navi_arrow_l_n.png");
				disabledImageBuffer[0] = IImageBuffer::CreateInstance(IMAGE_PATH "obe_navi_arrow_l_d.png");
				//if (NULL != unfocusedImageBuffer[0])
				//{
				//	m_pPreviousButton->SetBackgroundImage(IButton::E_STATE_ALL, unfocusedImageBuffer[0]);
				//}
				//if (NULL != focusedImageBuffer[0])
				//{
				//	m_pPreviousButton->SetBackgroundImage(IButton::E_STATE_FOCUSED, focusedImageBuffer[0]);
				//	m_pPreviousButton->SetBackgroundImage(IButton::E_STATE_CLICKED, focusedImageBuffer[0]);
				//	m_pPreviousButton->SetBackgroundImage(IButton::E_STATE_SELECTED, focusedImageBuffer[0]);
				//	m_pPreviousButton->SetBackgroundImage(IButton::E_STATE_FOCUSED_ROLL_OVER, focusedImageBuffer[0]);
				//}
				//if (NULL != disabledImageBuffer[0])
				//{
				//	m_pPreviousButton->SetBackgroundImage(IButton::E_STATE_DISABLED, disabledImageBuffer[0]);
				//}
				
			}
		}

		if(m_nNavigationButtonType & NAVIGATION_BUTTON_TYPE_NEXT)
		{
			m_pNextButton = IButton::CreateInstance(parent, 134, 134);
			if (NULL != m_pNextButton)
			{
				m_pNextButton->SetPosition(1786, 473);
				ClutterColor c = {125, 125, 125, 255};
				//m_pNextButton->SetText(IButton::E_STATE_FOCUSED, "Next");
				//m_pNextButton->SetTextColor(IButton::E_STATE_FOCUSED, *clutter_color_init(&c, 46, 46, 46, 255));
				////m_pNextButton->SetTextFont(IButton::E_STATE_FOCUSED, "Sans 25px");
				//m_pNextButton->SetText(IButton::E_STATE_FOCUSED_ROLL_OVER, "Next");
				//m_pNextButton->SetTextColor(IButton::E_STATE_FOCUSED_ROLL_OVER, *clutter_color_init(&c, 46, 46, 46, 255));
				//m_pNextButton->SetTextFont(IButton::E_STATE_FOCUSED_ROLL_OVER, "Sans 25px");
				m_pNextButton->TextActor()->SetPosition(0, 67);

				focusedImageBuffer[1] = IImageBuffer::CreateInstance(IMAGE_PATH "obe_navi_arrow_r_f.png");
				unfocusedImageBuffer[1] = IImageBuffer::CreateInstance(IMAGE_PATH "obe_navi_arrow_r_n.png");
				disabledImageBuffer[1] = IImageBuffer::CreateInstance(IMAGE_PATH "obe_navi_arrow_r_d.png");
				//if (NULL != unfocusedImageBuffer[1])
				//{
				//	m_pNextButton->SetBackgroundImage(IButton::E_STATE_ALL, unfocusedImageBuffer[1]);
				//}
				//if (NULL != focusedImageBuffer[1])
				//{
				//	m_pNextButton->SetBackgroundImage(IButton::E_STATE_FOCUSED, focusedImageBuffer[1]);
				//	m_pNextButton->SetBackgroundImage(IButton::E_STATE_CLICKED, focusedImageBuffer[1]);
				//	m_pNextButton->SetBackgroundImage(IButton::E_STATE_SELECTED, focusedImageBuffer[1]);
				//	m_pNextButton->SetBackgroundImage(IButton::E_STATE_FOCUSED_ROLL_OVER, focusedImageBuffer[1]);
				//}
				//if (NULL != disabledImageBuffer[1])
				//{
				//	m_pNextButton->SetBackgroundImage(IButton::E_STATE_DISABLED, disabledImageBuffer[1]);
				//}
				
			}
		}

		
		if(m_nNavigationButtonType & NAVIGATION_BUTTON_TYPE_SKIP)
		{
			m_pSkipButton = IButton::CreateInstance(parent, 134, 134);
			if (NULL != m_pSkipButton)
			{
				m_pSkipButton->SetPosition(1786, 607);
				ClutterColor c = {125, 125, 125, 255};
				//m_pSkipButton->SetText(IButton::E_STATE_FOCUSED, "Skip");
				//m_pSkipButton->SetTextColor(IButton::E_STATE_FOCUSED, *clutter_color_init(&c, 46, 46, 46, 255));
				////m_pSkipButton->SetTextFont(IButton::E_STATE_FOCUSED, "Sans 25px");
				//m_pSkipButton->SetText(IButton::E_STATE_FOCUSED_ROLL_OVER, "Skip");
				//m_pSkipButton->SetTextColor(IButton::E_STATE_FOCUSED_ROLL_OVER, *clutter_color_init(&c, 46, 46, 46, 255));
				//m_pSkipButton->SetTextFont(IButton::E_STATE_FOCUSED_ROLL_OVER, "Sans 25px");
				m_pSkipButton->TextActor()->SetPosition(0, 67);

				focusedImageBuffer[2] = IImageBuffer::CreateInstance(IMAGE_PATH "obe_navi_arrow_r_skip_f.png");
				unfocusedImageBuffer[2] = IImageBuffer::CreateInstance(IMAGE_PATH "obe_navi_arrow_r_skip_n.png");
				disabledImageBuffer[2] = IImageBuffer::CreateInstance(IMAGE_PATH "obe_navi_arrow_r_skip_d.png");
				//if (NULL != unfocusedImageBuffer[2])
				//{
				//	m_pSkipButton->SetBackgroundImage(IButton::E_STATE_ALL, unfocusedImageBuffer[2]);
				//}
				//if (NULL != focusedImageBuffer[2])
				//{
				//	m_pSkipButton->SetBackgroundImage(IButton::E_STATE_FOCUSED, focusedImageBuffer[2]);
				//	m_pSkipButton->SetBackgroundImage(IButton::E_STATE_CLICKED, focusedImageBuffer[2]);
				//	m_pSkipButton->SetBackgroundImage(IButton::E_STATE_SELECTED, focusedImageBuffer[2]);
				//	m_pSkipButton->SetBackgroundImage(IButton::E_STATE_FOCUSED_ROLL_OVER, focusedImageBuffer[2]);
				//}
				//if (NULL != disabledImageBuffer[2])
				//{
				//	m_pSkipButton->SetBackgroundImage(IButton::E_STATE_DISABLED, disabledImageBuffer[2]);
				//}
			}
		}
	}

	void CWizardWidget::m_ShowNavigationButton()
	{
		if(m_pPreviousButton != NULL)
		{
			m_pPreviousButton->Show();
		}
		if(m_pNextButton != NULL)
		{
			m_pNextButton->Show();
		}
		if(m_pSkipButton != NULL)
		{
			m_pSkipButton->Show();
		}
	}

	void CWizardWidget::m_HideNavigationButton()
	{
		if(m_pPreviousButton != NULL)
		{
			m_pPreviousButton->Hide();
		}
		if(m_pNextButton != NULL)
		{
			m_pNextButton->Hide();
		}
		if(m_pSkipButton != NULL)
		{
			m_pSkipButton->Hide();
		}
	}

	void CWizardWidget::m_DestroyNavigationButton()
	{
		if (m_pPreviousButton != NULL)
		{
			m_pPreviousButton->Release();
		}
		if(m_pNextButton != NULL)
		{
			m_pNextButton->Release();
		}
		if(m_pSkipButton != NULL)
		{
			m_pSkipButton->Release();
		}
	}

	void CWizardWidget::m_DestroyBG()
	{
		if (m_pBGImage != NULL)
		{
			m_pBGImage->Release();
		}
	}

	void CWizardWidget::m_DestroyTitle()
	{
		if (m_pTitle != NULL)
		{
			m_pTitle->Release();
		}
		for(int i = 0; i < 9; i++) //TODO:
		{
			if (m_pStepButton[i] != NULL)
			{
				m_pStepButton[i]->Release();
			}
		}
	}

	void CWizardWidget::m_Destroy()
	{
		m_DestroyBG();
		m_DestroyTitle();
		m_DestroyNavigationButton();
	}

	bool CWizardWidget::t_Initialize()
	{
		return true;
	}
}