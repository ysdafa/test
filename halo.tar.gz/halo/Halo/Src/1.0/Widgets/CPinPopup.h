#ifndef _CPINNUMBER_H_
#define _CPINNUMBER_H_
namespace HALO
{
	class CPinPopup: virtual public IPinPopup, public CActionPopup , public IPinNumberListener ,public IKeyboardListener , public IFocusListener , public IClickListener, public IMouseListener
	{
		friend class CPinBox;
		friend class IPinPopupListener;
	public:
		CPinPopup();
		virtual ~CPinPopup();

		virtual bool Initialize(IActor* parent, const TPinPopupAttr &attr);

		virtual bool Initialize(Widget* parent, const TPinPopupAttr &attr);

		virtual void SetContentText(const std::string& text);

		virtual  std::string ContentText(void) const;

		virtual void SetContentRect(float xPos , float yPos ,float width , float height);

		virtual void SetContentTextFont(const std::string& font);

		virtual std::string ContentTextFont(void) const;

		virtual void SetContentTextFontSize(int fontSize);

		virtual int ContentTextFontSize(void) const;

		virtual void SetContentTextFontColor(const ClutterColor textcolor);

		virtual ClutterColor ContentTextFontColor(void) const;

		virtual void SetPinBoxBackGroundImage(EInputBoxState pinstate , const std::string& iconPath);

		virtual void SetPinBoxItemImage(EInputItemsState inputboxState  , const std::string& iconPath);

		virtual void SetPinBoxDescriptionText(E_PINNUMBER_TYPE pinType , const char* pinTitle);

		virtual void SetPinBoxDescriptionRect(E_PINNUMBER_TYPE pinType , float xPos , float yPos ,float width , float height);

		virtual void SetPinBoxDescriptionTextFontSize(E_PINNUMBER_TYPE pinType , int fontSize);

		virtual void SetPinBoxDescriptionTextColor(E_PINNUMBER_TYPE pinType , const ClutterColor textcolor);

		virtual void SetPinBoxItemDigitFontSize(int digitsize);

		virtual int PinBoxItemDigitFontSize(void) const;

		virtual void SetPinBoxItemDigitColor(const ClutterColor textcolor);

		virtual ClutterColor PinBoxItemDigitColor(void) const;

		virtual void SetPinBoxItemDigitFont(const std::string& font);

		virtual std::string PinBoxItemDigitFont(void) const;

		virtual void ResetPassWord(E_PINNUMBER_TYPE pinType);

		virtual void SetPinBoxFocus(E_PINNUMBER_TYPE pinType);

		virtual void SetButtonPosition(const EPinPopupButtons nButton, float x, float y);

		virtual void SetButtonSize(const EPinPopupButtons nButton, float w, float h);

		virtual void SetButtonImage(const EPinPopupButtons nButton, IButton::EButtonState state, const std::string& imagePath);

		virtual void SetButtonText(const EPinPopupButtons nButton, IButton::EButtonState state, const std::string& text);

		virtual void SetButtonTextColor(const EPinPopupButtons nButton, IButton::EButtonState state, const ClutterColor color);

		virtual void SetButtonTextFontSize(const EPinPopupButtons nButton, IButton::EButtonState state, int fontSize);

		virtual bool AddListener(class IPinPopupListener* listener);

		virtual bool RemoveListener(class IPinPopupListener* listener);
	protected:

		virtual bool OnFocusIn(IActor* pWindow);

		virtual bool OnFocusOut(IActor* pWindow);	

		virtual bool OnMousePointerIn(IActor* pWindow, IMouseEvent* ptrMouseEvent);

		//! The callback function when mouse pointer out.
		virtual bool OnMousePointerOut(IActor* pWindow, IMouseEvent* ptrMouseEvent);

		virtual bool OnClicked(IActor* pWindow, IEvent* pClickEvent);

		virtual bool OnKeyReleased(IActor* pThis, IKeyboardEvent* event);

		virtual void OnValidConfirm(class CPinBox* list ,  bool isPassWordRight);

		virtual void OutputPassWord(class CPinBox* list , std::string inputPassWord);

		virtual void t_UpdateOrientation(EOrientation orientation);

		class CPinPopupListenerSet *t_pPinPopupListenerSet;
	private:
		int m_pinType;
		int m_buttonNum;
		IText* m_pinText1;
		IText* m_pinText2;
		IText* m_ConTentText;
		float m_TitleXPos;
		float m_ContentYpos;
		float m_pinXpos;
		float m_pin1Ypos;
		float m_pin2Ypos;
		float m_parentHeightRate;
		bool m_IsContent;
		//bool m_IsButton;
		bool m_reverseFlag;
		std::string m_pwd1Str;
		std::string m_pwd2Str;
		class CPinBox* m_pinNumber1;
		class CPinBox* m_pinNumber2;
		class IButton* m_button1;
		class IButton* m_button2;
		//class IPinPopupListener* m_Listener;
		IAction* m_action1;
		IAction* m_action2;
		void m_Update();
		void m_CreatePinBox();
		void m_CreateButton();
		void m_SetWindowTab();
		void m_Initialize();
		void m_Destroy();
		void m_AutoArrangeTitle();
		void m_AutoArrangePinBox();
		void m_AutoArrangePinBoxDescription();
	};
}
#endif