#include "Halo1_0.h"

namespace HALO
{         
	static HALO::util::Logger LOGGER("CInputBox");

	CInputBox::CInputBox()
	{
		
	}

	CInputBox::~CInputBox()
	{
		m_objText->RemoveStateChangedListener(this);
		m_objText->Release();
		m_objText = NULL;

		m_objImage->RemoveMouseListener(this);
		m_objImage->Release();
		m_objImage = NULL;
	}

	void CInputBox::m_initial()
	{
		m_marginH = 0;
		m_marginV = 0;

		m_focusState = INPUTBOX_STATE_NORMAL;

		t_orientation = Orientation(true);
	}

	bool CInputBox::Initialize(IActor* parent, float width, float height, const TInputBoxAttr &attr)
	{
		Widget *widget = dynamic_cast<Widget *>(parent);
		return Initialize(widget, width, height, attr);
	}
	
	bool CInputBox::Initialize(Widget* parent, float width, float height, const TInputBoxAttr &attr)
	{
		m_initial();
		
		m_marginH = attr.margin_h;
		m_marginV = attr.margin_v;

		m_imageWidth = width;
		m_imageHeight = height;

		m_hAlign = HALIGN_CENTER;
		
		CActor::Initialize(parent, m_imageWidth, m_imageHeight);
		ClutterColor bgColor = { 96, 96, 96, 255 };
		CActor::SetBackgroundColor(bgColor);

		m_createImage();
		m_createText();

		m_initialStateAttr();

		m_objImage->AddMouseListener(this);
		m_objText->AddStateChangedListener(this);
		return true;
	}

	void CInputBox::m_createImage()
	{
		m_objImage = ICompositeImage::CreateInstance(dynamic_cast<Widget*>(this), m_imageWidth, m_imageHeight);
	}

	void CInputBox::m_createText()
	{
		ASSERT(m_imageWidth >= 2 * m_marginH);
		ASSERT(m_imageHeight >= 2 * m_marginV);

		float textWdith = m_imageWidth - 2 * m_marginH;
		float textHeight = m_imageHeight - 2 * m_marginV;
		m_objText = IRichText::CreateInstance(dynamic_cast<Widget*>(this), textWdith, textHeight);
		t_AddNoticeActor(m_objText);

		// set text at the center of the image
		m_objText->SetPosition(m_marginH, m_marginV);
		m_objText->SetSingleLineTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
	}

	void CInputBox::m_initialStateAttr()
	{
		m_stateAttr[INPUTBOX_STATE_NORMAL].m_imageName = "";
		ClutterColor colorNormal = CLUTTER_COLOR_INIT(64, 64, 64, 204);
		m_stateAttr[INPUTBOX_STATE_NORMAL].m_textColor = colorNormal;

		m_stateAttr[INPUTBOX_STATE_FOCUS].m_imageName = "";
		ClutterColor colorFocus = CLUTTER_COLOR_INIT(33, 158, 230, 255);
		m_stateAttr[INPUTBOX_STATE_FOCUS].m_textColor = colorFocus;
	}

	void CInputBox::SetImage(const std::string& filepath)
	{
		m_objImage->SetImage(filepath.c_str());
	}

	void CInputBox::SetNormal_FocusImage(const std::string& file_normal, const std::string& file_focus)
	{
		m_stateAttr[INPUTBOX_STATE_NORMAL].m_imageName = file_normal;
		m_stateAttr[INPUTBOX_STATE_FOCUS].m_imageName = file_focus;
		m_updateStateAttr(true, false);
	}

	void CInputBox::SetImage(T_INPUTBOX_STATE state, const std::string& filepath)
	{
		m_stateAttr[state].m_imageName = filepath;
		m_updateStateAttr(true, false);
	}

	void CInputBox::SetNormal_FocusTextColor(const ClutterColor color_normal, const ClutterColor color_focus)
	{
		ClutterColor colorNormal = CLUTTER_COLOR_INIT(color_normal.red, color_normal.green, color_normal.blue, color_normal.alpha);
		m_stateAttr[INPUTBOX_STATE_NORMAL].m_textColor = colorNormal;

		ClutterColor colorFocus = CLUTTER_COLOR_INIT(color_focus.red, color_focus.green, color_focus.blue, color_focus.alpha);
		m_stateAttr[INPUTBOX_STATE_FOCUS].m_textColor = colorFocus;

		m_updateStateAttr(false, true);
	}

	void CInputBox::SetTextColor(T_INPUTBOX_STATE state, const ClutterColor color)
	{
		ClutterColor col = CLUTTER_COLOR_INIT(color.red, color.green, color.blue, color.alpha);
		m_stateAttr[state].m_textColor = col;
		m_updateStateAttr(false, true);
	}

	void CInputBox::m_updateStateAttr(bool updateImage, bool updateTextColor)
	{
		if (updateImage)
		{
			if (m_focusState == INPUTBOX_STATE_NORMAL)
			{
				SetImage(m_stateAttr[INPUTBOX_STATE_NORMAL].m_imageName);
			}
			else if (m_focusState == INPUTBOX_STATE_FOCUS)
			{
				SetImage(m_stateAttr[INPUTBOX_STATE_FOCUS].m_imageName);
			}
		}

		if (updateTextColor)
		{
			if (m_focusState == INPUTBOX_STATE_NORMAL)
			{
				SetTextColor(m_stateAttr[INPUTBOX_STATE_NORMAL].m_textColor);
			}
			else if (m_focusState == INPUTBOX_STATE_FOCUS)
			{
				SetTextColor(m_stateAttr[INPUTBOX_STATE_FOCUS].m_textColor);
			}
		}
	}

	void CInputBox::SetText(const std::string& text)
	{
		m_objText->SetText(text.c_str());
		const char* buf = m_objText->Text();
		int len = strlen(buf);
		m_objText->SetCursorPosition(len);
	}

	std::string CInputBox::Text() const
	{
		return m_objText->Text();
	}

	void CInputBox::InsertText(const std::string& text)
	{
		m_objText->InsertText((char*)text.c_str());
	}

	void CInputBox::SetBGColor(const ClutterColor color)
	{
		m_objImage->SetBackgroundColor(color);
	}

	void CInputBox::SetTextBGColor(const ClutterColor color)
	{
		m_objText->SetBackgroundColor(color);
	}

	void CInputBox::SetTextColor(const ClutterColor color)
	{
		m_objText->SetTextColor(color);
	}

	void CInputBox::SetTextCursorColor(const ClutterColor color)
	{
		m_objText->SetCursorColor(color);
	}

	void CInputBox::SetTextSelectionColor(const ClutterColor color)
	{
		m_objText->SetSelectionColor(color);
	}

	void CInputBox::SetTextHAlignment(EHAlignment hAlign)
	{
		m_hAlign = hAlign;
		m_objText->SetSingleLineTextAlignment(m_hAlign, VALIGN_MIDDLE);
	}

	EHAlignment CInputBox::TextHAlignment()
	{
		return m_hAlign;
	}

	void CInputBox::SetFont(const std::string& font)
	{
		m_objText->SetFont(font.c_str());
	}

	std::string CInputBox::Font() const
	{
		return m_objText->Font();
	}

	void CInputBox::SetFontSize(int size)
	{
		m_objText->SetFontSize(size);
	}

	int CInputBox::FontSize()
	{
		return m_objText->FontSize();
	}

	void CInputBox::SetTextMaxCount(int count)
	{
		m_objText->SetSingleLineTextMaxCount(count);
	}

	int CInputBox::TextCount()
	{
		return strlen(m_objText->Text());
	}

	bool CInputBox::SetFocus()
	{
		m_objText->EnableFocus(true);
		m_objText->SetFocus();
		m_focusState = INPUTBOX_STATE_FOCUS;
		return true;
	}

	bool CInputBox::KillFocus()
	{
		m_objText->EnableFocus(false);
		m_objText->KillFocus();
		m_focusState = INPUTBOX_STATE_NORMAL;
		return true;
	}

	bool CInputBox::OnMouseButtonPressed(IActor* pWindow, IMouseEvent* ptrMouseEvent)
	{
		return CLUTTER_EVENT_PROPAGATE;
	}

	bool CInputBox::OnMouseButtonReleased(IActor* pWindow, IMouseEvent* ptrMouseEvent)
	{
		return CLUTTER_EVENT_PROPAGATE;
	}

	bool CInputBox::OnStateChanged(class IRichText* richtext, int keyval)
	{	
		if (keyval == INPUTBOX_STATE_FOCUS)
		{//focus in
			H_LOG_TRACE(LOGGER, "CInputBox::OnstateChanged() INPUTBOX_STATE_FOCUS \n");
			m_focusState = INPUTBOX_STATE_FOCUS;
			m_updateStateAttr(true, true);
		}
		else if (keyval == INPUTBOX_STATE_NORMAL)
		{//focus out
			H_LOG_TRACE(LOGGER, "CInputBox::OnstateChanged() INPUTBOX_STATE_NORMAL \n");
			m_focusState = INPUTBOX_STATE_NORMAL;
			m_updateStateAttr(true, true);
		}
		return true;
	}

	void CInputBox::t_UpdateOrientation(EOrientation orientation)
	{
		if (t_orientation == orientation)
		{
			return;
		}
		else
		{
			t_orientation = orientation;
			if (m_hAlign == HALIGN_LEFT)
			{
				SetTextHAlignment(HALIGN_RIGHT);
			}
		}
		CActor::t_UpdateOrientation(orientation);
	}

#ifdef HAVE_ECORE_IMF	
	void CInputBox::EnableIME(bool IsIMEEnabled)
	{
		m_objText->EnableIMFOnFocus(IsIMEEnabled);
	}
#endif
}
