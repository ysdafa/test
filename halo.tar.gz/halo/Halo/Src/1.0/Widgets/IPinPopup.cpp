#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	IPinPopup* HALO::IPinPopup::CreateInstance( IActor *parent , const TPinPopupAttr &attr )
	{
		CPinPopup* pinPopup = dynamic_cast<CPinPopup*>(Instance::CreateInstance(CLASS_ID_IPINPOPUP));
		if (NULL != pinPopup)
		{
			pinPopup->Initialize(parent, attr);
		}
		return pinPopup;
	}

	IPinPopup* IPinPopup::CreateInstance( Widget *parent , const TPinPopupAttr &attr )
	{
		CPinPopup* pinPopup = dynamic_cast<CPinPopup*>(Instance::CreateInstance(CLASS_ID_IPINPOPUP));
		if (NULL != pinPopup)
		{
			pinPopup->Initialize(parent, attr);
		}
		return pinPopup;
	}

}