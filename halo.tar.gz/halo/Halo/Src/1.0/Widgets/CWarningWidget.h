#ifndef	_CWARNINGWIDGET_H_
#define	_CWARNINGWIDGET_H_

namespace HALO
{
	class CWarningWidget:virtual public IWarningWidget, public CDefaultWindow
	{
	public:

		CWarningWidget();
		virtual ~CWarningWidget();
		virtual bool Initialize(IActor *parent ,const TWarningWidgetAttr &attr);

		virtual void Show();

		virtual void SetTimer(int nTimer);

		virtual void Hide( void );

		void SetMessageText(const char* pMessage);

		void SetMessageTextColor(const ClutterColor textcolor);
	private:
		int m_loadingType;
		ILabel *m_MessageLabel;
		void m_Destroy();
		void m_ResizeWindow();
		void m_ShowAni();
		void m_ShowTTS();
	};
}
#endif