#include "Halo1_0.h"

#define TEXT_WIDTH_RATE 0.407292
#define TITLE_TEXT_HEIGHT_RATE 0.088889
#define CONTEXT_HEIGHT_RATE 0.044444
#define TITLE_CONTENT_GAP_RATE 0.011111
#define CONTENT_ARROW_GAP_RATE 0.018519
#define ARROW_BUTTON_GAP_RATE 0.032407
#define CONTENT_STAR_GAP_RATE 0.024074
#define STAR_ICON_GAP_RATE 0.041667
#define STAR_WIDTH_RATE 0.0239583
#define STAR_HEIGHT_RATE 0.0425923
#define STAR_GAP_RATE 0.0057297
#define ARROW_WIDTH_RATE 0.03125
#define ARROW_HEIGHT_RATE 0.057407
#define BUTTON_WIDTH_RATE 0.140625
#define BUTTON_HEIGHT_RATE 0.061111
#define BUTTON_BUTTOM_GAP_RATE 0.027778

namespace HALO
{
	class CPopupRatingListenerSet : public ListenerSet
	{
	public:
		struct TPopupRatingListenerData
		{
			int type;
			int param[1];
			void* pData;
		};

		CPopupRatingListenerSet(CPopupRating* owner) :m_owner(owner){}
		virtual ~CPopupRatingListenerSet(void){}

		virtual bool Process(TPopupRatingListenerData* data);

	private:
		CPopupRating* m_owner;
	};

	bool CPopupRatingListenerSet::Process(TPopupRatingListenerData* data)
	{
		bool ret = false;

		if (NULL != data)
		{
			ListenerList::iterator iter = m_list.begin();

			while (iter != m_list.end())
			{
				IPopupRatingListener* listener = (IPopupRatingListener*)(*iter);

				switch (data->param[0])
				{
				case IPopupRating::BUTTON_1:
					ret |= listener->OnButtonEvent(m_owner, data->param[0], data->type);
					break;
				case IPopupRating::BUTTON_2:
					ret |= listener->OnButtonEvent(m_owner, data->param[0], data->type);
					break;
				case IPopupRating::STAR_ICON_ALL:
					ret |= listener->OnStarIconEvent(m_owner, data->type);
					break;
				default:
					break;
				}
				iter++;
			}
		}

		return ret;
	}

	//CPopupRating
	CPopupRating::CPopupRating()
	{
	}

	CPopupRating::~CPopupRating()
	{
		m_Destroy();
	}

	bool CPopupRating::Initialize( IActor* parent, const TPopupRatingAttr &attr )
	{
		Widget *widget = dynamic_cast<Widget *>(parent);
		return Initialize(widget, attr);
	}
	
	bool CPopupRating::Initialize( Widget* parent, const TPopupRatingAttr &attr )
	{
		ASSERT(attr.w > 0 && attr.h > 0);
		m_Initialize();
		t_parentWidth = attr.w;
		t_parentHeight = attr.h;
		m_bHasHalfMarkedStar = attr.bHasHalfMarkedStar;

		// TODO: this color will be replaced by color picker later
		ClutterColor BgColor = {39,124,175,200};
		t_nPopupRatingType = attr.nPopupRatingType;			
		t_bAutoArrange = attr.bAutoFlag;
		m_nButtonNum = 2;
		t_orientation = Orientation(true);

		CActor::Initialize(parent, t_parentWidth, t_parentHeight);
		CActor::SetPosition(attr.x, attr.y);
		CActor::SetBackgroundColor(BgColor);
		if(t_bAutoArrange)
		{
			m_AutoArrangeBGSize();
		}
		m_CreateStarIcon();

		if(BASE_LABEL_WITH_POPUP == t_nPopupRatingType)
		{
			m_CreateArrowButton();
			m_CreateTitle();
			m_CreateContent();
			m_CreateButton();
			m_SetArrowButtonTap();
			m_SetButtonTap();
		}
		t_pPopupRatingListenerSet = new class CPopupRatingListenerSet(this);
		CActor::EnableFocus(true);

		IClickAction* action = IClickAction::CreateInstance(this);
		AddAction(action);
		m_parentAction = action;
		AddClickListener(this);
		AddKeyboardListener(this);
		AddFocusListener(this);
		AddMouseListener(this);

		return true;
	}

	void CPopupRating::SetBGColor(const ClutterColor BGColor)
	{
		CActor::SetBackgroundColor(BGColor);
	}

	void CPopupRating::SetTitleRect(float x, float y, float w, float h)
	{
		if(NULL == m_titleText || NULL == m_titleLine)
		{
			return;
		}

		if(false == t_bAutoArrange)
		{
			m_titleText->Resize(w, h);
			m_titleText->SetPosition(x, y);

			m_titleLine->Resize(w, 1);
			m_titleLine->SetPosition(w, y + h);
		}
	}

	void CPopupRating::SetTitleText(const std::string& titleText)
	{
		if(NULL == m_titleText)
		{
			return;
		}
		m_titleText->SetText(titleText.c_str());

		if(t_bAutoArrange)
		{
			m_AutoArrangeTitle();
		}
	}

	std::string CPopupRating::TitleText() const
	{
		if(NULL == m_titleText)
		{
			return "";
		}
		return m_titleText->Text();
	}

	void CPopupRating::SetTitleTextColor(const ClutterColor textcolor)
	{
		if(NULL == m_titleText)
		{
			return;
		}
		m_titleText->SetTextColor(textcolor);
	}

	void CPopupRating::SetTitleTextFont(const std::string& font)
	{		
		if(NULL == m_titleText)
		{
			return;
		}
		m_titleText->SetFont(font.c_str());
	}

	void CPopupRating::SetTitleTextAlignment(EHAlignment hAlign, EVAlignment vAlign)
	{
		if(NULL == m_titleText)
		{
			return;
		}
		m_titleText->SetTextAlignment(hAlign, vAlign);
	}

	std::string CPopupRating::TitleTextFont() const
	{
		if(NULL == m_titleText)
		{
			return "";
		}
		return m_titleText->Font();
	}

	void CPopupRating::SetTitleLineColor(const ClutterColor color)
	{	
		if(NULL == m_titleLine)
		{
			return;
		}
		m_titleLine->SetBackgroundColor(color);
	}

	void CPopupRating::SetContentRect(float x, float y, float w, float h)
	{	
		if(NULL == m_contentText)
		{
			return;
		}
		
		if(false == t_bAutoArrange)
		{
			m_contentText->Resize(w, h);
			m_contentText->SetPosition(x, y);
		}
	}

	void CPopupRating::SetContentText(const std::string& contentText)
	{
		if(NULL == m_contentText)
		{
			return;
		}
		
		m_contentText->SetText(contentText.c_str());

		if(t_bAutoArrange)
		{
			int nLineNum = 0; 
			nLineNum = m_contentText->LineCount();
			if(nLineNum > 2)
			{
				nLineNum = 2;
			}
			m_AutoArrangeContent(nLineNum);
			m_AutoArrangeButton();
		}
	}

	std::string CPopupRating::ContentText() const
	{
		if(NULL == m_contentText)
		{
			return "";
		}
		return m_contentText->Text();
	}

	void CPopupRating::SetContentTextColor(const ClutterColor textcolor)
	{
		if(NULL == m_contentText)
		{
			return;
		}

		m_contentText->SetTextColor(textcolor);
	}

	void CPopupRating::SetContentTextFont(const std::string& font)
	{
		if(NULL == m_contentText)
		{
			return;
		}

		m_contentText->SetFont(font.c_str());
	}

	void CPopupRating::SetContentTextAlignment(EHAlignment hAlign, EVAlignment vAlign)
	{
		if(NULL == m_contentText)
		{
			return;
		}
		m_contentText->SetTextAlignment(hAlign, vAlign);
	}

	std::string CPopupRating::ContentTextFont() const
	{
		if(NULL == m_contentText)
		{
			return "";
		}
		return m_contentText->Font();
	}

	void CPopupRating::SetStarIconRect(const EPopupRatingStarIcons nStarIcon, float x, float y, float w, float h)
	{
		ASSERT(nStarIcon <= STAR_ICON_ALL && nStarIcon >= STAR_ICON_1);

		if(t_bAutoArrange)
		{
			return;
		}
		if(STAR_ICON_ALL == nStarIcon)
		{
 			for(uint i = 0; i < (STAR_ICON_ALL - 1); i++)
			{
				t_StarIcon[i]->Resize(w, h);
				t_StarIcon[i]->SetPosition(x, y);
			}
		}
		else
		{
			t_StarIcon[nStarIcon - 1]->Resize(w, h);
			t_StarIcon[nStarIcon - 1]->SetPosition(x, y);
		}
	}

	void CPopupRating::SetStarIconUnmarkedImage(const std::string& imagePath)
	{
		t_starUnmarkedImagePath = imagePath;

		if(t_bAutoArrange)
		{
			m_AutoArrangeStarIcon();
		}
	}

	std::string CPopupRating::StarIconUnmarkedImage() const
	{
		return t_starUnmarkedImagePath;
	}

	void CPopupRating::SetStarIconMarkedImage(const std::string& imagePath)
	{
		t_starMarkedImagePath = imagePath;
		
		if(t_bAutoArrange)
		{
			m_AutoArrangeStarIcon();
		}
	}

	std::string CPopupRating::StarIconMarkedImage() const
	{
		return t_starMarkedImagePath;
	}

	void CPopupRating::SetStarIconHalfMarkedImage(const std::string& imagePath)
	{
		t_starHalfMarkedImagePath = imagePath;
		
		if(t_bAutoArrange)
		{
			m_AutoArrangeStarIcon();
		}
	}

	std::string CPopupRating::StarIconHalfMarkedImage() const
	{
		return t_starHalfMarkedImagePath;
	}

	void CPopupRating::SetArrowButtonRect(const EPopupRatingArrowButtons nArrowButton, float x, float y, float w, float h)
	{
		ASSERT(nArrowButton <= ARROW_BUTTON_ALL && nArrowButton >= ARROW_BUTTON_1);

		if(t_bAutoArrange || BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return;
		}
		if(ARROW_BUTTON_ALL == nArrowButton)
		{
 			for(uint i = 0; i < (ARROW_BUTTON_ALL - 1); i++)
			{
				t_ArrowButton[i]->Resize(w, h);
				t_ArrowButton[i]->SetPosition(x, y);
			}
		}
		else
		{
			t_ArrowButton[nArrowButton - 1]->Resize(w, h);
			t_ArrowButton[nArrowButton - 1]->SetPosition(x, y);
		}
	}

	void CPopupRating::SetArrowButtonImage(const EPopupRatingArrowButtons nArrowButton, IButton::EButtonState state, const std::string& imagePath)
	{
		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return;
		}

		if(ARROW_BUTTON_ALL == nArrowButton)
		{
 			for(uint i = 0; i < (ARROW_BUTTON_ALL - 1); i++)
			{
				t_ArrowButton[i]->SetBackgroundImage(state, imagePath);
			}
		}
		else
		{
			t_ArrowButton[nArrowButton - 1]->SetBackgroundImage(state, imagePath);
		}

		if(t_bAutoArrange)
		{
			m_AutoArrangeArrowButton();
		}
	}

	void CPopupRating::SetButtonRect(const EPopupRatingButtons nButton, float x, float y, float w, float h)
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(t_bAutoArrange || BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return;
		}
		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->Resize(w, h);
				t_Button[i]->SetPosition(x, y);
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->Resize(w, h);
			t_Button[nButton - 1]->SetPosition(x, y);
		}
	}

	void CPopupRating::SetButtonImage(const EPopupRatingButtons nButton, IButton::EButtonState state, const std::string& imagePath)
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return;
		}
		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->SetBackgroundImage(state, imagePath);
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->SetBackgroundImage(state, imagePath);
		}
	}

	void CPopupRating::SetButtonBackgroundColor(const EPopupRatingButtons nButton, IButton::EButtonState state, const ClutterColor color)
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return;
		}

		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->SetBackgroundColor(state, color);
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->SetBackgroundColor(state, color);
		}
	}

	void CPopupRating::SetButtonText(const EPopupRatingButtons nButton, IButton::EButtonState state, const std::string& text)
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return;
		}
		ClutterColor c = {255, 255, 255, 255};
		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->SetText(state, text);
				t_Button[i]->SetTextColor(IButton::STATE_ALL, *clutter_color_init(&c, 255, 255, 255, 255));
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->SetText(state, text);
			t_Button[nButton - 1]->SetTextColor(IButton::STATE_ALL, *clutter_color_init(&c, 255, 255, 255, 255));
		}
	}

	void CPopupRating::SetButtonTextColor(const EPopupRatingButtons nButton, IButton::EButtonState state, const ClutterColor color)
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return;
		}
		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->SetTextColor(state, color);
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->SetTextColor(state, color);
		}
	}

	void CPopupRating::SetButtonTextFontSize(const EPopupRatingButtons nButton, IButton::EButtonState state, int fontSize)
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return;
		}

		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->SetFontSize(state, fontSize);
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->SetFontSize(state, fontSize);
		}	
	}

	void CPopupRating::SetDefaultFocus(int nButton)
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return;
		}

		if((uint)nButton > m_nButtonNum)
		{
			return;
		}
		t_Button[nButton - 1]->SetFocus();
		return;
	}

	int CPopupRating::DefaultFocus() const
	{
		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return 0;
		}

		for(uint i = 0; i < m_nButtonNum; i++)
		{
			if(t_Button[i]->IsFocused())
			{
				return (i + 1);
			}
		}

		return 0;
	}

	void CPopupRating::SetMarkedStarIconNumber(int markedStarIconNumber)
	{
		ASSERT(markedStarIconNumber <= 2 * (STAR_ICON_ALL - 1) && markedStarIconNumber >= (STAR_ICON_1 - 1));

		if(m_bHasHalfMarkedStar)
		{
			m_nTotalMarkedStarIconNum = markedStarIconNumber;
		}
		else
		{
			m_nTotalMarkedStarIconNum = (markedStarIconNumber / 2) * 2;
		}

		for(uint i = 0; i < (m_nTotalMarkedStarIconNum + 1) / 2; i++)
		{
			t_StarIcon[i]->SetImage(t_starMarkedImagePath.c_str());
			t_bStarIconselectedFlag[i] = true;
		}
		for(uint i = (m_nTotalMarkedStarIconNum + 1) / 2; i < STAR_ICON_ALL - 1; i++)
		{
			t_StarIcon[i]->SetImage(t_starUnmarkedImagePath.c_str());
			t_bStarIconselectedFlag[i] = false;
		}	

		if(m_bHasHalfMarkedStar && t_starHalfMarkedImagePath != "" && m_nTotalMarkedStarIconNum % 2)
		{
			t_StarIcon[(m_nTotalMarkedStarIconNum + 1) / 2 - 1]->SetImage(t_starHalfMarkedImagePath.c_str());
			t_bStarIconselectedFlag[(m_nTotalMarkedStarIconNum + 1) / 2 - 1] = true;
		}

		if(BASE_LABEL_ONLY != t_nPopupRatingType)
		{
			t_ArrowButton[0]->Enable(true);
			t_ArrowButton[1]->Enable(true);
			if(m_nTotalMarkedStarIconNum <= 0)
			{
				m_nTotalMarkedStarIconNum = 0;
				t_ArrowButton[0]->Enable(false);
			}
			else if(m_nTotalMarkedStarIconNum >= (STAR_ICON_ALL - 1) * 2)
			{
				m_nTotalMarkedStarIconNum = (STAR_ICON_ALL - 1) * 2;
				t_ArrowButton[1]->Enable(false);
			}
			else
			{
				// Nothing
			}
		}
	}

	int CPopupRating::MarkedStarIconNumber() const
	{
		return m_nTotalMarkedStarIconNum;
	}

	bool CPopupRating::AddListener(IPopupRatingListener* listener)
	{
		ASSERT(listener != NULL);

		return t_pPopupRatingListenerSet->Add(listener);
	}

	bool CPopupRating::RemoveListener(IPopupRatingListener* listener)
	{
		ASSERT(listener != NULL);

		return t_pPopupRatingListenerSet->Remove(listener);
	}

	void CPopupRating::SetSupportTTS(bool bSupport)
	{
		m_bSupportTTS = bSupport;
	}

	bool CPopupRating::SupportTTS() const
	{
		return m_bSupportTTS;
	}

	void CPopupRating::SetShowTime(guint nShowTime)
	{
		if(nShowTime <= 0)
		{
			return;
		}
		m_showTime = nShowTime;
		m_showTimerId = g_timeout_add(m_showTime, (GSourceFunc)m_ShowTimeFinishedCB, this);
	}

	guint CPopupRating::ShowTime() const
	{
		return m_showTime;
	}

	gboolean CPopupRating::m_ShowTimeFinishedCB(gpointer data)
	{
		CPopupRating* popupRating = reinterpret_cast<CPopupRating *>(data);
		if(popupRating)
		{
			popupRating->Hide();
		}

		return false;
	}

	void CPopupRating::t_UpdateOrientation(EOrientation orientation)	
	{
		if(t_orientation == orientation)
		{
			return;
		}
		else
		{
			t_orientation = orientation;
			EHAlignment ehAlign = HALIGN_LEFT;
			EVAlignment evAlign = VALIGN_TOP;
			if(m_contentText)
			{
				m_contentText->GetTextAlignment(ehAlign, evAlign);
				if(HALIGN_LEFT == ehAlign)
				{
					m_contentText->SetTextAlignment(HALIGN_RIGHT, evAlign);
				}
				else if(HALIGN_RIGHT == ehAlign)
				{
					m_contentText->SetTextAlignment(HALIGN_LEFT, evAlign);
				}
				else
				{
					// Noting
				}
			}

			float button1X = 0.0, button1Y = 0.0, button2X = 0.0, button2Y = 0.0;
			if(t_Button[0] && t_Button[1])
			{
				t_Button[0]->GetPosition(button1X, button1Y);
				t_Button[1]->GetPosition(button2X, button2Y);
				t_Button[0]->SetPosition(button2X, button2Y);
				t_Button[1]->SetPosition(button1X, button1Y);
			}
		}

		CActor::t_UpdateOrientation(orientation);
	}

	bool CPopupRating::OnFocusIn( IActor* pWindow )
	{
		m_ResetShowTime();
		if(NULL == t_pPopupRatingListenerSet)
		{
			return false;
		}

		m_ProcessButtonEvent(pWindow, IPopupRatingListener::BUTTON_FOCUS_IN);
		
		return true;
	}
	
	bool CPopupRating::OnFocusOut( IActor* pWindow )
	{
		m_ResetShowTime();
		if(NULL == t_pPopupRatingListenerSet)
		{
			return false;
		}

		m_ProcessButtonEvent(pWindow, IPopupRatingListener::BUTTON_FOCUS_OUT);

		return true;
	}
	
	bool CPopupRating::OnClicked(IActor* pWindow, IEvent* pClickEvent)
	{
		m_ResetShowTime();
		if(NULL == t_pPopupRatingListenerSet)
		{
			return false;
		}

		m_ProcessButtonEvent(pWindow, IPopupRatingListener::BUTTON_CLICKED);
		m_ProcessArrowButtonClicked(pWindow);

		return true;
	}
	
	bool CPopupRating::OnKeyReleased( IActor* pWindow, IKeyboardEvent* ptrKeyboardEvent )
	{
		m_ResetShowTime();
		int keyValue = ptrKeyboardEvent->GetKeyVal();
	
		switch (keyValue)
		{
		case CLUTTER_KEY_Up:
			if(BASE_LABEL_ONLY != t_nPopupRatingType)
			{
				if(false == t_ArrowButton[0]->IsEnabled())
				{
					t_Button[0]->SetTabWindow(DIRECTION_UP, t_ArrowButton[1]);
					t_Button[1]->SetTabWindow(DIRECTION_UP, t_ArrowButton[1]);
				}
				else
				{
					t_Button[0]->SetTabWindow(DIRECTION_UP, t_ArrowButton[0]);
					t_Button[1]->SetTabWindow(DIRECTION_UP, t_ArrowButton[0]);
				}
			}
			break;
		case KEY_ENTER:
			if(NULL == t_pPopupRatingListenerSet)
			{
				return false;
			}
			m_ProcessButtonEvent(pWindow, IPopupRatingListener::BUTTON_CLICKED);
			m_ProcessArrowButtonClicked(pWindow, true);
			break;
		default: 
			break;
		}

		return true;
	
	}
	bool CPopupRating::OnMouseButtonPressed(IActor* pWindow, IMouseEvent* ptrMouseEvent)
	{
		m_ResetShowTime();
		m_bStarIconPressed = true;
		return true;
	}

	bool CPopupRating::OnMouseButtonReleased(IActor* pWindow, IMouseEvent* ptrMouseEvent)
	{
		m_ResetShowTime();
		m_bStarIconPressed = false;
		if(false == m_bStarMove)
		{
			m_ProcessStarIconClicked(pWindow, IPopupRatingListener::BUTTON_CLICKED);
		}
		m_bStarMove = false;
		return true;
	}

	bool CPopupRating::OnMouseMoved(IActor* pWindow, IMouseEvent* ptrMouseEvent)
	{
		m_ResetShowTime();
		if(false == m_bStarIconPressed)
		{
			return false;
		}
		m_bStarMove = true;
		float mouseX = 0.0, mouseY = 0.0, thisX = 0.0, thisY = 0.0, StarIconX = 0.0, StarIconY = 0.0, lastStarIconX = 0.0, lastStarIconY = 0.0;
		float StarIconW = 0.0, StarIconH = 0.0;
		mouseX = ptrMouseEvent->GetX();
		mouseY = ptrMouseEvent->GetY();
		GetPosition(thisX, thisY);
		t_StarIcon[0]->GetPosition(StarIconX, StarIconY);
		t_StarIcon[0]->GetSize(StarIconW, StarIconH);
		if((mouseY - thisY) < StarIconY || (mouseY - thisY) > (StarIconY + StarIconH))
		{
			return false;
		}
		for(uint i = 0; i < STAR_ICON_ALL - 1; i++)
		{
			t_StarIcon[i]->GetPosition(StarIconX, StarIconY);
			t_StarIcon[i]->GetSize(StarIconW, StarIconH);
			if(STAR_ICON_ALL - 2 > i)
			{
				t_StarIcon[i + 1]->GetPosition(lastStarIconX, lastStarIconY);
			}
			else
			{
				lastStarIconX = StarIconX + StarIconW;
			}

			if(m_bHasHalfMarkedStar)
			{
				if((mouseX - thisX) >= StarIconX && (mouseX - thisX) <= (StarIconX + StarIconW / 2.0))
				{
					m_nTotalMarkedStarIconNum = i * 2 + 1;
					break;
				}
				if(((mouseX - thisX) < lastStarIconX) && (mouseX - thisX) > (StarIconX + StarIconW / 2.0))
				{
					m_nTotalMarkedStarIconNum = i * 2 + 2;
					break;
				}
			}
			else
			{
				if((mouseX - thisX) >= StarIconX && (mouseX - thisX) < lastStarIconX)
				{
					m_nTotalMarkedStarIconNum = i * 2 + 2;
					break;
				}
			}

			if((STAR_ICON_ALL - 2 == i) && (mouseX - thisX) > lastStarIconX + StarIconW)
			{
				m_nTotalMarkedStarIconNum = 10;
				break;
			}
			if(0 == i && (mouseX - thisX) < StarIconX)
			{
				m_nTotalMarkedStarIconNum = 0;
				break;
			}
		}

		if(m_nTotalMarkedStarIconNum % 2)
		{
			for(uint i = 0; i < (m_nTotalMarkedStarIconNum + 1) / 2 - 1; i++)
			{
				t_StarIcon[i]->SetImage(t_starMarkedImagePath.c_str());
				t_bStarIconselectedFlag[i] = true;
			}
			t_StarIcon[(m_nTotalMarkedStarIconNum + 1) / 2 - 1]->SetImage(t_starHalfMarkedImagePath.c_str());
			t_bStarIconselectedFlag[(m_nTotalMarkedStarIconNum + 1) / 2 - 1] = true;
		}
		else
		{
			for(uint i = 0; i < (m_nTotalMarkedStarIconNum + 1) / 2; i++)
			{
				t_StarIcon[i]->SetImage(t_starMarkedImagePath.c_str());
				t_bStarIconselectedFlag[i] = true;
			}
		}

		for(uint i = (m_nTotalMarkedStarIconNum + 1) / 2; i < STAR_ICON_ALL - 1; i++)
		{
			t_StarIcon[i]->SetImage(t_starUnmarkedImagePath.c_str());
			t_bStarIconselectedFlag[i] = false;
		}

		if(BASE_LABEL_ONLY != t_nPopupRatingType)
		{
			t_ArrowButton[0]->Enable(true);
			t_ArrowButton[1]->Enable(true);
			if(m_nTotalMarkedStarIconNum == 0)
			{
				t_ArrowButton[0]->Enable(false);
			}
			else if(0 == (m_nTotalMarkedStarIconNum % 2) && m_nTotalMarkedStarIconNum == (STAR_ICON_ALL - 1) * 2)
			{
				t_ArrowButton[1]->Enable(false);
			}
			else
			{
				// Nothing
			}
		}
		return true;
	}

	bool CPopupRating::OnMousePointerIn( IActor* pWindow, IMouseEvent* ptrMouseEvent )
	{
		m_ResetShowTime();
		return true;
	}

	bool CPopupRating::OnMousePointerOut( IActor* pWindow, IMouseEvent* ptrMouseEvent )
	{
		m_ResetShowTime();
		return true;
	}

	void CPopupRating::m_ResetShowTime()
	{
		if (m_showTimerId > 0)
		{
			g_source_remove(m_showTimerId);
			m_showTimerId = 0;
			if(m_showTime > 0)
			{
				m_showTimerId = g_timeout_add(m_showTime, (GSourceFunc)m_ShowTimeFinishedCB, this);
			}
		}
	}

	void CPopupRating::m_Initialize()
	{
		t_parentHeight = 0;
		t_parentWidth = 0;
		t_nPopupRatingType = 0;
		t_bAutoArrange = true;		
		for(uint i = 0; i < BUTTON_ALL-1; i++)
		{
			t_Button[i] = NULL;
			m_actions[i] = NULL;
		}
		for(uint i = 0; i < (STAR_ICON_ALL - 1); i++)
		{
			t_StarIcon[i] = NULL;
			m_StarActions[i] = NULL;
			t_bStarIconselectedFlag[i] = false;
		}
		for(uint i = 0; i < (ARROW_BUTTON_ALL - 1); i++)
		{
			t_ArrowButton[i] = NULL;
			m_ArrowActions[i] = NULL;
		}

		m_parentAction = NULL;
		t_pPopupRatingListenerSet = NULL;
		t_starUnmarkedImagePath = "";
		t_starMarkedImagePath = "";
		t_starHalfMarkedImagePath = "";
		t_orientation = ORIENTATION_LEFT_TO_RIGHT;
		
		m_nButtonNum = 2;
		m_nTotalMarkedStarIconNum = 6;
		m_bHasHalfMarkedStar = false;
		m_bStarMove = false;
		m_titleText = NULL;
		m_titleLine = NULL;
		m_contentText = NULL;
		m_bSupportTTS = false;

		m_bStarIconPressed = false;
		m_showTimerId = 0;
		m_showTime = 0;
	}

	void CPopupRating::m_CreateStarIcon()
	{
		for(uint i = 0; i < (STAR_ICON_ALL - 1); i++)
		{
			t_StarIcon[i] = IImage::CreateInstance(dynamic_cast<IActor*>(this), (float)(t_parentWidth * STAR_WIDTH_RATE), (float)(t_parentHeight * STAR_HEIGHT_RATE));
			IClickAction* action = IClickAction::CreateInstance(t_StarIcon[i]);
			t_StarIcon[i]->AddAction(action);
			m_StarActions[i] = action;
			t_StarIcon[i]->AddClickListener(this);
			t_StarIcon[i]->AddKeyboardListener(this);
			t_StarIcon[i]->AddFocusListener(this);
			t_StarIcon[i]->AddMouseListener(this);
		}
	}

	void CPopupRating::m_CreateArrowButton()
	{
		ClutterColor c = {255, 255, 255, 255};
		for(uint i = 0; i < (ARROW_BUTTON_ALL - 1); i++)
		{
			t_ArrowButton[i] = IButton::CreateInstance(this, (float)(t_parentWidth * ARROW_WIDTH_RATE), (float)(t_parentHeight *ARROW_HEIGHT_RATE));
			t_ArrowButton[i]->SetBackgroundColor(IButton::STATE_ALL, *clutter_color_init(&c, 0, 0, 0, 0));
			IClickAction* action = IClickAction::CreateInstance(t_ArrowButton[i]);
			t_ArrowButton[i]->AddAction(action);
			m_ArrowActions[i] = action;
			t_ArrowButton[i]->AddClickListener(this);
			t_ArrowButton[i]->AddKeyboardListener(this);
			t_ArrowButton[i]->AddFocusListener(this);
		}
	}

	void CPopupRating::m_CreateContent()
	{
		ClutterColor c = {255,255,255,255};
		m_contentText = IText::CreateInstance(dynamic_cast<Widget*>(this), (float)(t_parentWidth * TEXT_WIDTH_RATE), (float)(t_parentHeight * CONTEXT_HEIGHT_RATE));
		m_contentText->EnableMultiLine(true);
		m_contentText->SetTextColor(*clutter_color_init(&c, 255,255,255,255));
	}

	void CPopupRating::m_CreateTitle()
	{
		ClutterColor c = {255,255,255,255};
		m_titleText = IText::CreateInstance(dynamic_cast<Widget*>(this), (float)(t_parentWidth * TEXT_WIDTH_RATE), (float)(t_parentHeight * TITLE_TEXT_HEIGHT_RATE));
		m_titleText->EnableMultiLine(false);
		m_titleText->SetTextColor(*clutter_color_init(&c, 255,255,255,255));
		m_titleText->SetTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
		m_titleLine = IActor::CreateInstance(dynamic_cast<Widget*>(this), (float)(t_parentWidth * TEXT_WIDTH_RATE), 1.0);
		m_titleLine->SetBackgroundColor(*clutter_color_init(&c, 255,255,255,255));
	}

	void CPopupRating::m_CreateButton()
	{
		ClutterColor c = {255, 255, 255, 255};
		for(uint i = 0; i < m_nButtonNum; i++)
		{
			t_Button[i] = IButton::CreateInstance(this, (float)(t_parentWidth * BUTTON_WIDTH_RATE), (float)(t_parentHeight * BUTTON_HEIGHT_RATE));
			IClickAction* action = IClickAction::CreateInstance(t_Button[i]);
			t_Button[i]->AddAction(action);
			m_actions[i] = action;
			t_Button[i]->AddClickListener(this);
			t_Button[i]->AddKeyboardListener(this);
			t_Button[i]->AddFocusListener(this);
			t_Button[i]->SetBackgroundColor(IButton::STATE_ALL, *clutter_color_init(&c, 0, 0, 0, 0));
			t_Button[i]->SetTextColor(IButton::STATE_ALL, *clutter_color_init(&c, 255, 255, 255, 255));
			t_AddNoticeActor(t_Button[i]);
		}
		m_SetButtonTap();
	}

	void CPopupRating::m_SetArrowButtonTap()
	{
		for(uint i = 0; i < (ARROW_BUTTON_ALL - 1); i++)
		{
			if (i == 0) 	
			{			
				t_ArrowButton[i]->SetTabWindow(DIRECTION_LEFT, t_ArrowButton[ARROW_BUTTON_ALL - 2]);	
			}		
			else		
			{		
				t_ArrowButton[i]->SetTabWindow(DIRECTION_LEFT, t_ArrowButton[i-1]); 
			}		
			if (i == ARROW_BUTTON_ALL - 2) 	
			{			
				t_ArrowButton[i]->SetTabWindow(DIRECTION_RIGHT, t_ArrowButton[0]);		
			}		
			else	
			{			
				t_ArrowButton[i]->SetTabWindow(DIRECTION_RIGHT, t_ArrowButton[i + 1]);	
			}
			t_ArrowButton[i]->SetTabWindow(DIRECTION_DOWN, t_Button[0]);
		}
	}

	void CPopupRating::m_SetButtonTap()
	{
		for(uint i = 0; i < m_nButtonNum; i++)
		{
			if (i == 0) 	
			{			
				t_Button[i]->SetTabWindow(DIRECTION_LEFT, t_Button[m_nButtonNum - 1]);	
			}		
			else		
			{		
				t_Button[i]->SetTabWindow(DIRECTION_LEFT, t_Button[i-1]); 
			}		
			if (i == m_nButtonNum - 1) 	
			{			
				t_Button[i]->SetTabWindow(DIRECTION_RIGHT, t_Button[0]);		
			}		
			else	
			{	
				if (i != 1)
				{
					t_Button[i]->SetTabWindow(DIRECTION_RIGHT, t_Button[i + 1]);	
				}				
			}
			t_Button[i]->SetTabWindow(DIRECTION_UP, t_ArrowButton[0]);
		}
	}
	
	void CPopupRating::m_AutoArrangeBGSize()
	{
		float bgWidthRate = 0.0;
		float bgHeightRate = 0.0;
		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			bgWidthRate = (float)((STAR_WIDTH_RATE + STAR_GAP_RATE) * 5.0 + STAR_GAP_RATE);
			bgHeightRate = (float)STAR_HEIGHT_RATE;
			CActor::Resize(t_parentWidth * bgWidthRate, t_parentHeight * bgHeightRate);
			CActor::SetPosition(0.0, 0.0);
			ClutterColor BgColor = {0,0,0,0};
			CActor::SetBackgroundColor(BgColor);
		}
		else
		{
			bgHeightRate = (float)(TITLE_TEXT_HEIGHT_RATE + CONTEXT_HEIGHT_RATE * 2.0 + TITLE_CONTENT_GAP_RATE + CONTENT_STAR_GAP_RATE +
				STAR_ICON_GAP_RATE + STAR_HEIGHT_RATE + BUTTON_HEIGHT_RATE + BUTTON_BUTTOM_GAP_RATE);
			CActor::Resize(t_parentWidth, t_parentHeight * bgHeightRate);
			CActor::SetPosition(0.0, (float)((1.0 - bgHeightRate) * t_parentHeight / 2.0));
		}
	}

	void CPopupRating::m_AutoArrangeStarIcon()
	{
		float buttonGapWidth = (float)(t_parentWidth * (STAR_GAP_RATE + STAR_WIDTH_RATE));
		float firstPosX = (float)((t_parentWidth - buttonGapWidth * 5.0) / 2.0);
		float PosY = (float)(t_parentHeight * (TITLE_TEXT_HEIGHT_RATE + CONTEXT_HEIGHT_RATE * 2.0 + TITLE_CONTENT_GAP_RATE + CONTENT_STAR_GAP_RATE));
		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			firstPosX = (float)(t_parentWidth * STAR_GAP_RATE);
			PosY = 0.0;
		}
		
		for(uint i = 0; i < (STAR_ICON_ALL - 1); i++)
		{
			t_StarIcon[i]->Resize((float)(t_parentWidth * STAR_WIDTH_RATE), (float)(t_parentHeight * STAR_HEIGHT_RATE));
			t_StarIcon[i]->SetPosition((float)(firstPosX + (float)i * buttonGapWidth), PosY);
			if(t_starUnmarkedImagePath != "")
			{
				t_StarIcon[i]->SetImage(t_starUnmarkedImagePath.c_str());
			}
		}

		for(uint i = 0; i < (m_nTotalMarkedStarIconNum + 1) / 2; i++)
		{
			if(t_starMarkedImagePath != "")
			{
				t_StarIcon[i]->SetImage(t_starMarkedImagePath.c_str());
				t_bStarIconselectedFlag[i] = true;
			}
		}

		if(m_bHasHalfMarkedStar && t_starHalfMarkedImagePath != "" && m_nTotalMarkedStarIconNum % 2)
		{
			t_StarIcon[(m_nTotalMarkedStarIconNum + 1) / 2 - 1]->SetImage(t_starHalfMarkedImagePath.c_str());
			t_bStarIconselectedFlag[(m_nTotalMarkedStarIconNum + 1) / 2 - 1] = true;
		}
	}

	void CPopupRating::m_AutoArrangeArrowButton()
	{
		float buttonGapWidth = (float)(t_parentWidth * ((STAR_GAP_RATE + STAR_WIDTH_RATE) * 6.0 + ARROW_WIDTH_RATE));
		float firstPosX = (float)((t_parentWidth * (1.0 - 1.25 * ARROW_WIDTH_RATE) - buttonGapWidth) / 2.0);
		float PosY = (float)(t_parentHeight * (TITLE_TEXT_HEIGHT_RATE + CONTEXT_HEIGHT_RATE * 2.0 + TITLE_CONTENT_GAP_RATE + CONTENT_ARROW_GAP_RATE));

		for(uint i = 0; i < (ARROW_BUTTON_ALL - 1); i++)
		{
			t_ArrowButton[i]->Resize((float)(t_parentWidth * ARROW_WIDTH_RATE), (float)(t_parentHeight * ARROW_HEIGHT_RATE));
			t_ArrowButton[i]->SetPosition((float)(firstPosX + (float)i * buttonGapWidth), PosY);
		}
	}

	void CPopupRating::m_AutoArrangeTitle()
	{
		m_titleText->SetPosition((float)(t_parentWidth * (1.0 - TEXT_WIDTH_RATE) / 2.0), 0.0);
		m_titleLine->SetPosition((float)(t_parentWidth * (1.0 - TEXT_WIDTH_RATE) / 2.0), (float)(t_parentHeight * TITLE_TEXT_HEIGHT_RATE));
	}

	void CPopupRating::m_AutoArrangeContent(int nLineNum)
	{
		m_contentText->Resize((float)(t_parentWidth * TEXT_WIDTH_RATE), (float)(t_parentHeight * CONTEXT_HEIGHT_RATE * 2.0));
		if(1 == nLineNum)
		{
			m_contentText->SetTextAlignment(HALIGN_CENTER, VALIGN_TOP);
		}
		else
		{
			if(ORIENTATION_LEFT_TO_RIGHT == Orientation(true))
			{
				m_contentText->SetTextAlignment(HALIGN_LEFT, VALIGN_TOP);
			}
			else
			{
				m_contentText->SetTextAlignment(HALIGN_RIGHT, VALIGN_TOP);
			}
		}
		m_contentText->SetPosition((float)(t_parentWidth * (1.0 - TEXT_WIDTH_RATE) / 2.0), (float)(t_parentHeight * (TITLE_TEXT_HEIGHT_RATE + TITLE_CONTENT_GAP_RATE)));
	}

	void CPopupRating::m_AutoArrangeButton()
	{
		float buttonGapWidth = (float)(t_parentWidth * 0.146875);
		float firstPosX = (float)((t_parentWidth - buttonGapWidth * (float)m_nButtonNum) / 2.0);
		for(uint i = 0; i < m_nButtonNum; i++)
		{
			t_Button[i]->Resize((float)(t_parentWidth * BUTTON_WIDTH_RATE), (float)(t_parentHeight * BUTTON_HEIGHT_RATE));
			if(ORIENTATION_LEFT_TO_RIGHT == Orientation(true))
			{
				t_Button[i]->SetPosition((float)(firstPosX + (float)i * buttonGapWidth), (float)(t_parentHeight * (TITLE_TEXT_HEIGHT_RATE + CONTEXT_HEIGHT_RATE * 2.0 + TITLE_CONTENT_GAP_RATE + CONTENT_STAR_GAP_RATE + STAR_HEIGHT_RATE + STAR_ICON_GAP_RATE)));
			}
			else
			{
				t_Button[m_nButtonNum - 1 - i]->SetPosition((float)(firstPosX + (float)i * buttonGapWidth), (float)(t_parentHeight * (TITLE_TEXT_HEIGHT_RATE + CONTEXT_HEIGHT_RATE * 2.0 + TITLE_CONTENT_GAP_RATE + CONTENT_STAR_GAP_RATE + STAR_HEIGHT_RATE + STAR_ICON_GAP_RATE)));
			}
		}
	}

	bool CPopupRating::m_ProcessStarIconClicked(IActor* pWindow, int EventType)
	{
		uint j = 0;
		bool bStarIcon = false;
		for(uint i = 0; i < (STAR_ICON_ALL - 1); i++)
		{
			if (pWindow == t_StarIcon[i])
			{
				j = i;
				bStarIcon = true;
				break;
			}
		}

		if(bStarIcon)
		{
			if(false == t_bStarIconselectedFlag[j])
			{
				if(m_bHasHalfMarkedStar)
				{
					for(uint i = 0; i < j; i++)
					{
						t_StarIcon[i]->SetImage(t_starMarkedImagePath.c_str());
						t_bStarIconselectedFlag[i] = true;
					}
					t_StarIcon[j]->SetImage(t_starHalfMarkedImagePath.c_str());
					t_bStarIconselectedFlag[j] = true;
					m_nTotalMarkedStarIconNum = 2 * j + 1;
				}
				else
				{
					for(uint i = 0; i <= j; i++)
					{
						t_StarIcon[i]->SetImage(t_starMarkedImagePath.c_str());
						t_bStarIconselectedFlag[i] = true;
					}	
					m_nTotalMarkedStarIconNum = 2 * j + 2;
				}
			}
			else
			{
				if(m_bHasHalfMarkedStar)
				{
					for(uint i = j + 1; i < (STAR_ICON_ALL - 1); i++)
					{
						t_StarIcon[i]->SetImage(t_starUnmarkedImagePath.c_str());
						t_bStarIconselectedFlag[i] = false;
					}	
					
					if(m_nTotalMarkedStarIconNum % 2)
					{
						if(j == m_nTotalMarkedStarIconNum / 2)
						{
							t_StarIcon[j]->SetImage(t_starMarkedImagePath.c_str());
							m_nTotalMarkedStarIconNum = m_nTotalMarkedStarIconNum + 1;
							t_bStarIconselectedFlag[j] = true;
						}
						else
						{
							t_StarIcon[j]->SetImage(t_starUnmarkedImagePath.c_str());
							m_nTotalMarkedStarIconNum = j * 2;
							t_bStarIconselectedFlag[j] = false;
						}
					}
					else
					{
						t_StarIcon[j]->SetImage(t_starUnmarkedImagePath.c_str());
						m_nTotalMarkedStarIconNum = j * 2;
						t_bStarIconselectedFlag[j] = false;
					}
				}
				else
				{
					for(uint i = j; i < (STAR_ICON_ALL - 1); i++)
					{
						t_StarIcon[i]->SetImage(t_starUnmarkedImagePath.c_str());
						t_bStarIconselectedFlag[i] = false;
					}	
					m_nTotalMarkedStarIconNum = 2 * j;
				}
			}
			
			if(BASE_LABEL_ONLY != t_nPopupRatingType)
			{
				t_ArrowButton[0]->Enable(true);
				t_ArrowButton[1]->Enable(true);
				if(m_nTotalMarkedStarIconNum <= 0)
				{
					m_nTotalMarkedStarIconNum = 0;
					t_ArrowButton[0]->Enable(false);
				}
				else if(m_nTotalMarkedStarIconNum >= (STAR_ICON_ALL - 1) * 2)
				{
					m_nTotalMarkedStarIconNum = (STAR_ICON_ALL - 1) * 2;
					t_ArrowButton[1]->Enable(false);
				}
				else
				{
					// Nothing
				}
			}

			if (t_pPopupRatingListenerSet)
			{
				CPopupRatingListenerSet::TPopupRatingListenerData data;
				data.type = EventType;
				data.param[0] = STAR_ICON_ALL;
				t_pPopupRatingListenerSet->Process(&data);
			}
			return true;
		}

		return false;
	}

	bool CPopupRating::m_ProcessArrowButtonClicked(IActor* pWindow, bool bIfKeyPressed)
	{
		if (pWindow == t_ArrowButton[0] && t_ArrowButton[0]->IsEnabled())
		{
			if(m_bHasHalfMarkedStar)
			{
				m_nTotalMarkedStarIconNum = m_nTotalMarkedStarIconNum - 1;
			}
			else
			{
				m_nTotalMarkedStarIconNum = m_nTotalMarkedStarIconNum - 2;
			}
			t_ArrowButton[1]->Enable(true);
			if(m_nTotalMarkedStarIconNum <= 0)
			{
				m_nTotalMarkedStarIconNum = 0;
				if(bIfKeyPressed)
				{
					t_ArrowButton[1]->SetFocus();
				}
				t_ArrowButton[0]->Enable(false);
			}

			if(m_bHasHalfMarkedStar)
			{
				if(m_nTotalMarkedStarIconNum % 2)
				{
					t_StarIcon[m_nTotalMarkedStarIconNum / 2]->SetImage(t_starHalfMarkedImagePath.c_str());
					t_bStarIconselectedFlag[m_nTotalMarkedStarIconNum / 2] = true;
				}
				else
				{
					t_StarIcon[m_nTotalMarkedStarIconNum / 2]->SetImage(t_starUnmarkedImagePath.c_str());
					t_bStarIconselectedFlag[m_nTotalMarkedStarIconNum / 2] = false;
				}
			}
			else
			{
				t_StarIcon[m_nTotalMarkedStarIconNum / 2]->SetImage(t_starUnmarkedImagePath.c_str());
				t_bStarIconselectedFlag[m_nTotalMarkedStarIconNum / 2] = false;
			}
			
			return true;
		}
		if (pWindow == t_ArrowButton[1] && t_ArrowButton[1]->IsEnabled())
		{
			if(m_bHasHalfMarkedStar)
			{
				m_nTotalMarkedStarIconNum = m_nTotalMarkedStarIconNum + 1;
			}
			else
			{
				m_nTotalMarkedStarIconNum = m_nTotalMarkedStarIconNum + 2;
			}
			t_ArrowButton[0]->Enable(true);
			if(m_nTotalMarkedStarIconNum >= (STAR_ICON_ALL - 1) * 2)
			{
				m_nTotalMarkedStarIconNum = (STAR_ICON_ALL - 1) * 2;
				if(bIfKeyPressed)
				{
					t_ArrowButton[0]->SetFocus();
				}
				t_ArrowButton[1]->Enable(false);
			}

			if(m_bHasHalfMarkedStar)
			{
				if(m_nTotalMarkedStarIconNum % 2)
				{
					t_StarIcon[(m_nTotalMarkedStarIconNum + 1) / 2 - 1]->SetImage(t_starHalfMarkedImagePath.c_str());
					t_bStarIconselectedFlag[(m_nTotalMarkedStarIconNum + 1) / 2 - 1] = true;
				}
				else
				{
					t_StarIcon[(m_nTotalMarkedStarIconNum + 1) / 2 - 1]->SetImage(t_starMarkedImagePath.c_str());
					t_bStarIconselectedFlag[(m_nTotalMarkedStarIconNum + 1) / 2 - 1] = true;
				}
			}
			else
			{
				t_StarIcon[(m_nTotalMarkedStarIconNum + 1) / 2 - 1]->SetImage(t_starMarkedImagePath.c_str());
				t_bStarIconselectedFlag[(m_nTotalMarkedStarIconNum + 1) / 2 - 1] = true;
			}

			return true;
		}

		return false;
	}

	bool CPopupRating::m_ProcessButtonEvent(IActor* pWindow, int EventType)
	{
		if (t_pPopupRatingListenerSet)
		{
			CPopupRatingListenerSet::TPopupRatingListenerData data;
			data.type = EventType;

			if (pWindow == t_Button[0])
			{
				data.param[0] = BUTTON_1;
			}
			else if (pWindow == t_Button[1])
			{
				data.param[0] = BUTTON_2;
			}
			else
			{
				data.param[0] = 0;
			}
			t_pPopupRatingListenerSet->Process(&data);
			return true;
		}

		return false;
	}

	void CPopupRating::m_Destroy()
	{
		if(m_titleText)
		{
			m_titleText->Release();
		}

		if(m_titleLine)
		{
			m_titleLine->Release();
		}
		
		if(m_contentText)
		{
			m_contentText->Release();
		}
		for(uint i = 0; i < (STAR_ICON_ALL - 1); i++)
		{
			if(t_StarIcon[i])
			{
				t_StarIcon[i]->RemoveAction(m_StarActions[i]);
				m_StarActions[i]->Release();
				t_StarIcon[i]->RemoveClickListener(this);
				t_StarIcon[i]->RemoveKeyboardListener(this);
				t_StarIcon[i]->RemoveFocusListener(this);
				t_StarIcon[i]->RemoveMouseListener(this);
				t_StarIcon[i]->Release();
			}
		}
		for(uint i = 0; i < (ARROW_BUTTON_ALL - 1); i++)
		{
			if(t_ArrowButton[i])
			{
				t_ArrowButton[i]->RemoveAction(m_ArrowActions[i]);
				m_ArrowActions[i]->Release();
				t_ArrowButton[i]->RemoveClickListener(this);
				t_ArrowButton[i]->RemoveKeyboardListener(this);
				t_ArrowButton[i]->RemoveFocusListener(this);
				t_ArrowButton[i]->Release();
			}
		}
		for(uint i = 0; i < BUTTON_ALL-1; i++)
		{
			if(t_Button[i])
			{
				t_Button[i]->RemoveAction(m_actions[i]);
				m_actions[i]->Release();
				t_Button[i]->RemoveClickListener(this);
				t_Button[i]->RemoveKeyboardListener(this);
				t_Button[i]->RemoveFocusListener(this);
				t_Button[i]->Release();
			}
		}

		if (m_showTimerId > 0)
		{
			g_source_remove(m_showTimerId);
			m_showTimerId = 0;
		}

		delete t_pPopupRatingListenerSet;

		RemoveAction(m_parentAction);
		m_parentAction->Release();
		RemoveClickListener(this);
		RemoveKeyboardListener(this);
		RemoveFocusListener(this);
		RemoveMouseListener(this);
	}
}
