#include "Halo1_0.h"
static HALO::util::Logger LOGGER("PopupRating");

#define TEXT_WIDTH_RATE 0.407292
#define TITLE_TEXT_HEIGHT_RATE 0.088889
#define CONTEXT_HEIGHT_RATE 0.044444
#define TITLE_CONTENT_GAP_RATE 0.011111
#define CONTENT_ARROW_GAP_RATE 0.018519
#define ARROW_BUTTON_GAP_RATE 0.032407
#define CONTENT_STAR_GAP_RATE 0.024074
#define STAR_ICON_GAP_RATE 0.041667
#define STAR_WIDTH_RATE 0.0239583
#define STAR_HEIGHT_RATE 0.0425923
#define STAR_GAP_RATE 0.008333
#define STARSBG_WIDTH_RATE 0.163021
#define STARSBG_HEIGHT_RATE 0.057407
#define ARROW_WIDTH_RATE 0.03125
#define ARROW_HEIGHT_RATE 0.057407
#define BUTTON_WIDTH_RATE 0.140625
#define BUTTON_HEIGHT_RATE 0.061111
#define BUTTON_BUTTOM_GAP_RATE 0.027778

namespace HALO
{
	class CPopupRatingListenerSet : public ListenerSet
	{
	public:
		struct TPopupRatingListenerData
		{
			int type;
			int param[1];
			void* pData;
		};

		CPopupRatingListenerSet(CPopupRating* owner) :m_owner(owner){}
		virtual ~CPopupRatingListenerSet(void){}

		virtual bool Process(TPopupRatingListenerData* data);

	private:
		CPopupRating* m_owner;
	};

	bool CPopupRatingListenerSet::Process(TPopupRatingListenerData* data)
	{
		bool ret = false;
		Lock();

		if (NULL != data)
		{
			ListenerList::iterator iter = m_list.begin();

			while (iter != m_list.end())
			{
				IPopupRatingListener* listener = (IPopupRatingListener*)(*iter);

				switch (data->type)
				{
				case IPopupRating::BUTTON_1:
					ret |= listener->OnButtonEvent(m_owner, data->type, data->param[0]);
					break;
				case IPopupRating::BUTTON_2:
					ret |= listener->OnButtonEvent(m_owner, data->type, data->param[0]);
					break;
				case IPopupRating::STAR_ICON_ALL:
					ret |= listener->OnStarIconEvent(m_owner, data->param[0]);
					break;
				case 7:
					ret |= listener->OnTimeOut(m_owner);
					break;
				default:
					break;
				}
				if (m_list.empty())
				{
					break;
				}
				iter++;
			}
		}
		Unlock();

		return ret;
	}

	//CPopupRating
	CPopupRating::CPopupRating()
	{
		H_LOG_0_PARAM(FATAL, LOGGER);
	}

	CPopupRating::~CPopupRating()
	{
		H_LOG_0_PARAM(FATAL, LOGGER);
		m_Destroy();
	}

	bool CPopupRating::Initialize( IActor* parent, const TPopupRatingAttr &attr )
	{
		H_LOG_FATAL(LOGGER, "[" << this <<"]CPopupRating::Initialize with IActor parent");
		Widget *widget = dynamic_cast<Widget *>(parent);
		return Initialize(widget, attr);
	}
	
	bool CPopupRating::Initialize( Widget* parent, const TPopupRatingAttr &attr )
	{
		H_LOG_FATAL(LOGGER, "[" << this <<"]CPopupRating::Initialize with Widget parent");
		HALO_ASSERT(attr.w > 0 && attr.h > 0);
		m_Initialize();
		t_parentWidth = attr.w;
		t_parentHeight = attr.h;
		m_bHasHalfMarkedStar = attr.bHasHalfMarkedStar;

		// TODO: this color will be replaced by color picker later
		ClutterColor BgColor = {39,124,175,200};
		t_nPopupRatingType = attr.nPopupRatingType;			
		t_bAutoArrange = attr.bAutoFlag;
		m_nButtonNum = 2;

		CActor::Initialize(parent, t_parentWidth, t_parentHeight);
		CActor::SetPosition(attr.x, attr.y);
		CActor::SetBackgroundColor(BgColor);
		if(t_bAutoArrange)
		{
			m_AutoArrangeBGSize();
		}
		m_CreateStarIcon();

		if(BASE_LABEL_WITH_POPUP == t_nPopupRatingType)
		{
			m_CreateArrowButton();
			m_CreateTitle();
			m_CreateContent();
			m_CreateButton();
			m_SetArrowButtonTap();
			m_SetButtonTap();
		}
		t_pPopupRatingListenerSet = new class CPopupRatingListenerSet(this);
		CActor::EnableFocus(true);

	//	IClickAction* action = IClickAction::CreateInstance(this);
	//	AddAction(action);
	//	m_parentAction = action;
	//	AddClickListener(this);
		AddKeyboardListener(this);
		AddMouseListener(this);

		return true;
	}

	void CPopupRating::SetBGColor(const ClutterColor BGColor)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		CActor::SetBackgroundColor(BGColor);
	}

	void CPopupRating::SetTitleRect(float x, float y, float w, float h)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		if(NULL == m_titleText || NULL == m_titleLine)
		{
			return;
		}

		if(false == t_bAutoArrange)
		{
			m_titleText->Resize(w, h);
			m_titleText->SetPosition(x, y);

			m_titleLine->Resize(w, 1);
			m_titleLine->SetPosition(w, y + h);
		}
	}

	void CPopupRating::SetTitleText(const std::string& titleText)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, titleText);
		if(NULL == m_titleText)
		{
			return;
		}
		m_titleText->SetText(titleText.c_str());

		if(t_bAutoArrange)
		{
			m_AutoArrangeTitle();
		}
	}

	std::string CPopupRating::TitleText() const
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		if(NULL == m_titleText)
		{
			return "";
		}
		return m_titleText->Text();
	}

	void CPopupRating::SetTitleTextColor(const ClutterColor textcolor)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		if(NULL == m_titleText)
		{
			return;
		}
		m_titleText->SetTextColor(textcolor);
	}

	void CPopupRating::SetTitleTextFont(const std::string& font)
	{		
		H_LOG_1_PARAM(DEBUG, LOGGER, font);
		if(NULL == m_titleText)
		{
			return;
		}
		m_titleText->SetFont(font.c_str());
	}

	void CPopupRating::SetTitleTextAlignment(EHAlignment hAlign, EVAlignment vAlign)
	{
		H_LOG_2_PARAM(DEBUG, LOGGER, hAlign, vAlign);
		if(NULL == m_titleText)
		{
			return;
		}
		m_titleText->SetTextAlignment(hAlign, vAlign);
	}

	std::string CPopupRating::TitleTextFont() const
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		if(NULL == m_titleText)
		{
			return "";
		}
		return m_titleText->Font();
	}

	void CPopupRating::SetTitleLineRect(float x, float y, float w, float h)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		if(NULL == m_titleLine)
		{
			return;
		}
		m_titleLine->Resize(w, h);
		m_titleLine->SetPosition(x, y);
	}

	void CPopupRating::SetTitleLineColor(const ClutterColor color)
	{	
		H_LOG_0_PARAM(DEBUG, LOGGER);
		if(NULL == m_titleLine)
		{
			return;
		}
		m_titleLine->SetBackgroundColor(color);
	}

	void CPopupRating::SetContentRect(float x, float y, float w, float h)
	{	
		H_LOG_0_PARAM(DEBUG, LOGGER);
		if(NULL == m_contentText)
		{
			return;
		}
		
		if(false == t_bAutoArrange)
		{
			m_contentText->Resize(w, h);
			m_contentText->SetPosition(x, y);
		}
	}

	void CPopupRating::SetContentText(const std::string& contentText)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, contentText);
		if(NULL == m_contentText)
		{
			return;
		}
		
		m_contentText->SetText(contentText.c_str());

		if(t_bAutoArrange)
		{
			int nLineNum = 0; 
			nLineNum = m_contentText->LineCount();
			if(nLineNum > 2)
			{
				nLineNum = 2;
			}
			m_AutoArrangeContent(nLineNum);
			m_AutoArrangeButton();
		}
	}

	std::string CPopupRating::ContentText() const
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		if(NULL == m_contentText)
		{
			return "";
		}
		return m_contentText->Text();
	}

	void CPopupRating::SetContentTextColor(const ClutterColor textcolor)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		if(NULL == m_contentText)
		{
			return;
		}

		m_contentText->SetTextColor(textcolor);
	}

	void CPopupRating::SetContentTextFont(const std::string& font)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, font);
		if(NULL == m_contentText)
		{
			return;
		}

		m_contentText->SetFont(font.c_str());
	}

	void CPopupRating::SetContentTextAlignment(EHAlignment hAlign, EVAlignment vAlign)
	{
		H_LOG_2_PARAM(DEBUG, LOGGER, hAlign, vAlign);
		if(NULL == m_contentText)
		{
			return;
		}
		m_contentText->SetTextAlignment(hAlign, vAlign);
	}

	std::string CPopupRating::ContentTextFont() const
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		if(NULL == m_contentText)
		{
			return "";
		}
		return m_contentText->Font();
	}

	void CPopupRating::SetStarIconRect(const EPopupRatingStarIcons nStarIcon, float x, float y, float w, float h)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		HALO_ASSERT(nStarIcon <= STAR_ICON_ALL && nStarIcon >= STAR_ICON_1);

		if(t_bAutoArrange)
		{
			return;
		}
		if(STAR_ICON_ALL == nStarIcon)
		{
 			for(uint i = 0; i < (STAR_ICON_ALL - 1); i++)
			{
				t_StarIcon[i]->Resize(w, h);
				t_StarIcon[i]->SetPosition(x, y);
			}
		}
		else
		{
			t_StarIcon[nStarIcon - 1]->Resize(w, h);
			t_StarIcon[nStarIcon - 1]->SetPosition(x, y);
		}
	}

	void CPopupRating::SetStarIconUnmarkedImage(const std::string& imagePath)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, imagePath);
		t_starUnmarkedImagePath = imagePath;

		if(t_bAutoArrange)
		{
			m_AutoArrangeStarIcon();
		}
	}

	std::string CPopupRating::StarIconUnmarkedImage() const
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		return t_starUnmarkedImagePath;
	}

	void CPopupRating::SetStarIconMarkedImage(const std::string& imagePath)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, imagePath);
		t_starMarkedImagePath = imagePath;
		
		if(t_bAutoArrange)
		{
			m_AutoArrangeStarIcon();
		}
	}

	std::string CPopupRating::StarIconMarkedImage() const
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		return t_starMarkedImagePath;
	}

	void CPopupRating::SetStarIconHalfMarkedImage(const std::string& imagePath)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, imagePath);
		t_starHalfMarkedImagePath = imagePath;
		
		if(t_bAutoArrange)
		{
			m_AutoArrangeStarIcon();
		}
	}

	std::string CPopupRating::StarIconHalfMarkedImage() const
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		return t_starHalfMarkedImagePath;
	}

	void CPopupRating::SetStarIconsBGRect(float x, float y, float w, float h)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		if(NULL == m_starIconsBG)
		{
			return;
		}
		m_starIconsBG->Resize(w, h);
		m_starIconsBG->SetPosition(x, y);
	}

	void CPopupRating::SetStarIconsBGColor(const ClutterColor color)
	{	
		H_LOG_0_PARAM(DEBUG, LOGGER);
		if(NULL == m_starIconsBG)
		{
			return;
		}
		m_starIconsBG->SetBackgroundColor(color);
	}

	void CPopupRating::SetArrowButtonRect(const EPopupRatingArrowButtons nArrowButton, float x, float y, float w, float h)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		HALO_ASSERT(nArrowButton <= ARROW_BUTTON_ALL && nArrowButton >= ARROW_BUTTON_1);

		if(t_bAutoArrange || BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return;
		}
		if(ARROW_BUTTON_ALL == nArrowButton)
		{
 			for(uint i = 0; i < (ARROW_BUTTON_ALL - 1); i++)
			{
				t_ArrowButton[i]->Resize(w, h);
				t_ArrowButton[i]->SetPosition(x, y);
			}
		}
		else
		{
			t_ArrowButton[nArrowButton - 1]->Resize(w, h);
			t_ArrowButton[nArrowButton - 1]->SetPosition(x, y);
		}
	}

	void CPopupRating::SetArrowButtonImage(const EPopupRatingArrowButtons nArrowButton, IButton::EButtonState state, const std::string& imagePath)
	{
		H_LOG_3_PARAM(DEBUG, LOGGER, nArrowButton, state, imagePath);
		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return;
		}

		if(ARROW_BUTTON_ALL == nArrowButton)
		{
 			for(uint i = 0; i < (ARROW_BUTTON_ALL - 1); i++)
			{
				t_ArrowButton[i]->SetIconImage(state, imagePath);
			}
		}
		else
		{
			t_ArrowButton[nArrowButton - 1]->SetIconImage(state, imagePath);
		}

		if(t_bAutoArrange)
		{
			m_AutoArrangeArrowButton();
		}
	}

	void CPopupRating::SetButtonRect(const EPopupRatingButtons nButton, float x, float y, float w, float h)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		HALO_ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(t_bAutoArrange || BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return;
		}
		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->Resize(w, h);
				t_Button[i]->SetPosition(x, y);
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->Resize(w, h);
			t_Button[nButton - 1]->SetPosition(x, y);
		}
	}

	void CPopupRating::SetButtonImage(const EPopupRatingButtons nButton, IButton::EButtonState state, const std::string& imagePath)
	{
		H_LOG_3_PARAM(DEBUG, LOGGER, nButton, state, imagePath);
		HALO_ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return;
		}
		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->SetBackgroundImage(state, imagePath);
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->SetBackgroundImage(state, imagePath);
		}
	}

	void CPopupRating::SetButtonBackgroundColor(const EPopupRatingButtons nButton, IButton::EButtonState state, const ClutterColor color)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		HALO_ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return;
		}

		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->SetBackgroundColor(state, color);
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->SetBackgroundColor(state, color);
		}
	}

	void CPopupRating::SetButtonText(const EPopupRatingButtons nButton, IButton::EButtonState state, const std::string& text)
	{
		H_LOG_3_PARAM(DEBUG, LOGGER, nButton, state, text);
		HALO_ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return;
		}

		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->SetText(state, text);
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->SetText(state, text);
		}
	}

	void CPopupRating::SetButtonTextColor(const EPopupRatingButtons nButton, IButton::EButtonState state, const ClutterColor color)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		HALO_ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return;
		}
		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->SetTextColor(state, color);
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->SetTextColor(state, color);
		}
	}

	void CPopupRating::SetButtonTextFontSize(const EPopupRatingButtons nButton, IButton::EButtonState state, int fontSize)
	{
		H_LOG_3_PARAM(DEBUG, LOGGER, nButton, state, fontSize);
		HALO_ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return;
		}

		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->SetFontSize(state, fontSize);
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->SetFontSize(state, fontSize);
		}	
	}

	void CPopupRating::SetButtonBorderColor(const EPopupRatingButtons nButton, IButton::EButtonState state, const ClutterColor& color)
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		HALO_ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);
		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->SetBorderColor(state, color);
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->SetBorderColor(state, color);
		}
	}

	void CPopupRating::SetButtonBorderWidth(const EPopupRatingButtons nButton, IButton::EButtonState state, float width)
	{
		H_LOG_3_PARAM(DEBUG, LOGGER, nButton, state, width);
		HALO_ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);
		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->SetBorderWidth(state, width);
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->SetBorderWidth(state, width);
		}
	}

	void CPopupRating::SetDefaultFocus(int nButton)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, nButton);
		HALO_ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return;
		}

		if((uint)nButton > m_nButtonNum)
		{
			return;
		}
		t_Button[nButton - 1]->SetFocus();
		return;
	}

	int CPopupRating::DefaultFocus() const
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			return 0;
		}

		for(uint i = 0; i < m_nButtonNum; i++)
		{
			if(t_Button[i]->IsFocused())
			{
				return (i + 1);
			}
		}

		return 0;
	}

	void CPopupRating::SetMarkedStarIconNumber(int markedStarIconNumber)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, markedStarIconNumber);
		HALO_ASSERT(markedStarIconNumber <= 2 * (STAR_ICON_ALL - 1) && markedStarIconNumber >= (STAR_ICON_1 - 1));

		if(m_bHasHalfMarkedStar)
		{
			m_nTotalMarkedStarIconNum = markedStarIconNumber;
		}
		else
		{
			m_nTotalMarkedStarIconNum = (markedStarIconNumber / 2) * 2;
		}

		for(uint i = 0; i < (m_nTotalMarkedStarIconNum + 1) / 2; i++)
		{
			t_StarIcon[i]->SetImage(t_starMarkedImagePath.c_str());
			t_bStarIconselectedFlag[i] = true;
		}
		for(uint i = (m_nTotalMarkedStarIconNum + 1) / 2; i < STAR_ICON_ALL - 1; i++)
		{
			t_StarIcon[i]->SetImage(t_starUnmarkedImagePath.c_str());
			t_bStarIconselectedFlag[i] = false;
		}	

		if(m_bHasHalfMarkedStar && t_starHalfMarkedImagePath != "" && m_nTotalMarkedStarIconNum % 2)
		{
			t_StarIcon[(m_nTotalMarkedStarIconNum + 1) / 2 - 1]->SetImage(t_starHalfMarkedImagePath.c_str());
			t_bStarIconselectedFlag[(m_nTotalMarkedStarIconNum + 1) / 2 - 1] = true;
		}

		if(BASE_LABEL_ONLY != t_nPopupRatingType)
		{
			t_ArrowButton[0]->Enable(true);
			t_ArrowButton[0]->EnableFocus(true);
			t_ArrowButton[1]->Enable(true);
			t_ArrowButton[1]->EnableFocus(true);
			if(m_nTotalMarkedStarIconNum <= 0)
			{
				m_nTotalMarkedStarIconNum = 0;
				t_ArrowButton[0]->Enable(false);
				t_ArrowButton[0]->EnableFocus(false);
			}
			else if(m_nTotalMarkedStarIconNum >= (STAR_ICON_ALL - 1) * 2)
			{
				m_nTotalMarkedStarIconNum = (STAR_ICON_ALL - 1) * 2;
				t_ArrowButton[1]->Enable(false);
				t_ArrowButton[1]->EnableFocus(false);
			}
			else
			{
				// Nothing
			}
		}
	}

	int CPopupRating::MarkedStarIconNumber() const
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		return m_nTotalMarkedStarIconNum;
	}

	bool CPopupRating::AddListener(IPopupRatingListener* listener)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, listener);
		HALO_ASSERT(listener != NULL);

		return t_pPopupRatingListenerSet->Add(listener);
	}

	bool CPopupRating::RemoveListener(IPopupRatingListener* listener)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, listener);
		HALO_ASSERT(listener != NULL);

		return t_pPopupRatingListenerSet->Remove(listener);
	}

	void CPopupRating::SetSupportTTS(bool bSupport)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, bSupport);
		m_bSupportTTS = bSupport;
	}

	bool CPopupRating::SupportTTS() const
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		return m_bSupportTTS;
	}

	void CPopupRating::SetShowTime(guint nShowTime)
	{
		H_LOG_1_PARAM(DEBUG, LOGGER, nShowTime);
		if(nShowTime <= 0)
		{
			return;
		}
		m_showTime = nShowTime;
		if(0 != m_showTimerId)
		{
			g_source_remove(m_showTimerId);	
			m_showTimerId = 0;
		}
		m_showTimerId = g_timeout_add(m_showTime, (GSourceFunc)m_ShowTimeFinishedCB, this);
	}

	guint CPopupRating::ShowTime() const
	{
		H_LOG_0_PARAM(DEBUG, LOGGER);
		return m_showTime;
	}

	gboolean CPopupRating::m_ShowTimeFinishedCB(gpointer data)
	{
		CPopupRating* popupRating = reinterpret_cast<CPopupRating *>(data);
		if(NULL == popupRating)
		{
			return false;
		}
		popupRating->Hide();
		if (popupRating->t_pPopupRatingListenerSet)
		{
			CPopupRatingListenerSet::TPopupRatingListenerData data;
			data.type = 7;
			data.param[0] = 0;
			popupRating->t_pPopupRatingListenerSet->Process(&data);
		}

		return false;
	}

	bool CPopupRating::OnFocusIn(IWidgetExtension* pWindow )
	{
		m_ResetShowTime();
		if(NULL == t_pPopupRatingListenerSet)
		{
			return false;
		}

		m_ProcessButtonEvent(dynamic_cast<IActor*>(pWindow), IPopupRatingListener::BUTTON_FOCUS_IN);
		
		return true;
	}
	
	bool CPopupRating::OnFocusOut( IWidgetExtension* pWindow )
	{
		m_ResetShowTime();
		if(NULL == t_pPopupRatingListenerSet)
		{
			return false;
		}

		m_ProcessButtonEvent(dynamic_cast<IActor*>(pWindow), IPopupRatingListener::BUTTON_FOCUS_OUT);

		return true;
	}
	
	bool CPopupRating::OnClicked(IWidgetExtension* pWindow, IEvent* pClickEvent)
	{
		m_ResetShowTime();

		return true;
	}
	
	bool CPopupRating::OnKeyReleased( IWidgetExtension* pWindow, IKeyboardEvent* ptrKeyboardEvent )
	{
		m_ResetShowTime();
		int keyValue = ptrKeyboardEvent->GetKeyVal();
	
		switch (keyValue)
		{
		case CLUTTER_KEY_Left:
		case CLUTTER_KEY_Right:
			if(t_ArrowButton[0]->IsFocused() || t_ArrowButton[1]->IsFocused())
			{
				m_ProcessLeftRightKey(keyValue == CLUTTER_KEY_Left);
			}
			break;
		case CLUTTER_KEY_Up:
			if(BASE_LABEL_ONLY != t_nPopupRatingType)
			{
				if(t_ArrowButton[0] && true == t_ArrowButton[0]->IsEnabled())
				{
					t_ArrowButton[0]->SetFocus();
				}
				else
				{
					t_ArrowButton[1]->SetFocus();
				}
			}
			break;
		default: 
			break;
		}

		return true;
	
	}
	bool CPopupRating::OnMouseButtonPressed(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		m_ResetShowTime();
		if(pWindow == this)
		{
			return false;
		}
		m_bStarIconPressed = true;
		return true;
	}

	bool CPopupRating::OnMouseButtonReleased(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		m_ResetShowTime();
		m_bStarIconPressed = false;
		if(false == m_bStarMove)
		{
			m_ProcessStarIconClicked(dynamic_cast<IActor*>(pWindow), IPopupRatingListener::BUTTON_CLICKED);
		}
		m_bStarMove = false;
		return true;
	}

	bool CPopupRating::OnMouseMoved(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		m_ResetShowTime();
		if(false == m_bStarIconPressed)
		{
			return false;
		}
		m_bStarMove = true;
		float mouseX = 0.0, mouseY = 0.0, thisX = 0.0, thisY = 0.0, StarIconX = 0.0, StarIconY = 0.0, lastStarIconX = 0.0, lastStarIconY = 0.0;
		float StarIconW = 0.0, StarIconH = 0.0;
		float StarIconBGX = 0.0, StarIconBGY = 0.0;
		GetPosition(thisX, thisY);
		m_starIconsBG->GetPosition(StarIconBGX, StarIconBGY);
		t_StarIcon[0]->GetPosition(StarIconX, StarIconY);
		t_StarIcon[0]->GetSize(StarIconW, StarIconH);
		mouseX = ptrMouseEvent->GetX() - thisX - StarIconBGX;
		mouseY = ptrMouseEvent->GetY() - thisY - StarIconBGY;
		if(mouseY < StarIconY || mouseY > (StarIconY + StarIconH))
		{
			return false;
		}
		for(uint i = 0; i < STAR_ICON_ALL - 1; i++)
		{
			t_StarIcon[i]->GetPosition(StarIconX, StarIconY);
			t_StarIcon[i]->GetSize(StarIconW, StarIconH);
			if(STAR_ICON_ALL - 2 > i)
			{
				t_StarIcon[i + 1]->GetPosition(lastStarIconX, lastStarIconY);
			}
			else
			{
				lastStarIconX = StarIconX + StarIconW;
			}

			if(m_bHasHalfMarkedStar)
			{
				if(mouseX >= StarIconX && mouseX <= (StarIconX + StarIconW / 2.0))
				{
					m_nTotalMarkedStarIconNum = i * 2 + 1;
					break;
				}
				if((mouseX < lastStarIconX) && mouseX > (StarIconX + StarIconW / 2.0))
				{
					m_nTotalMarkedStarIconNum = i * 2 + 2;
					break;
				}
			}
			else
			{
				if(mouseX >= StarIconX && mouseX < lastStarIconX)
				{
					m_nTotalMarkedStarIconNum = i * 2 + 2;
					break;
				}
			}

			if((STAR_ICON_ALL - 2 == i) && mouseX > lastStarIconX + StarIconW)
			{
				m_nTotalMarkedStarIconNum = 10;
				break;
			}
			if(0 == i && mouseX < StarIconX)
			{
				m_nTotalMarkedStarIconNum = 0;
				break;
			}
		}

		if(m_nTotalMarkedStarIconNum % 2)
		{
			for(uint i = 0; i < (m_nTotalMarkedStarIconNum + 1) / 2 - 1; i++)
			{
				t_StarIcon[i]->SetImage(t_starMarkedImagePath.c_str());
				t_bStarIconselectedFlag[i] = true;
			}
			t_StarIcon[(m_nTotalMarkedStarIconNum + 1) / 2 - 1]->SetImage(t_starHalfMarkedImagePath.c_str());
			t_bStarIconselectedFlag[(m_nTotalMarkedStarIconNum + 1) / 2 - 1] = true;
		}
		else
		{
			for(uint i = 0; i < (m_nTotalMarkedStarIconNum + 1) / 2; i++)
			{
				t_StarIcon[i]->SetImage(t_starMarkedImagePath.c_str());
				t_bStarIconselectedFlag[i] = true;
			}
		}

		for(uint i = (m_nTotalMarkedStarIconNum + 1) / 2; i < STAR_ICON_ALL - 1; i++)
		{
			t_StarIcon[i]->SetImage(t_starUnmarkedImagePath.c_str());
			t_bStarIconselectedFlag[i] = false;
		}

		if(BASE_LABEL_ONLY != t_nPopupRatingType)
		{
			t_ArrowButton[0]->Enable(true);
			t_ArrowButton[0]->EnableFocus(true);
			t_ArrowButton[1]->Enable(true);
			t_ArrowButton[1]->EnableFocus(true);
			if(m_nTotalMarkedStarIconNum == 0)
			{
				if(t_ArrowButton[0]->IsFocused())
				{
					t_ArrowButton[1]->SetFocus();
				}
				t_ArrowButton[0]->Enable(false);
				t_ArrowButton[0]->EnableFocus(false);
			}
			else if(0 == (m_nTotalMarkedStarIconNum % 2) && m_nTotalMarkedStarIconNum == (STAR_ICON_ALL - 1) * 2)
			{
				if(t_ArrowButton[1]->IsFocused())
				{
					t_ArrowButton[0]->SetFocus();
				}
				t_ArrowButton[1]->Enable(false);
				t_ArrowButton[1]->EnableFocus(false);
			}
			else
			{
				// Nothing
			}
		}
		return true;
	}

	bool CPopupRating::OnButtonClicked(class IButton* button, EButtonClickType type)
	{
		m_ResetShowTime();

		if(NULL == t_pPopupRatingListenerSet)
		{
			return false;
		}

		if(button == t_ArrowButton[0])
		{
			m_ProcessLeftRightKey(true);
		}
		else if(button == t_ArrowButton[1])
		{
			m_ProcessLeftRightKey(false);
		}
		else
		{
			m_ProcessButtonEvent(button, IPopupRatingListener::BUTTON_CLICKED);
		}

		return true;
	}

	void CPopupRating::m_ResetShowTime()
	{
		if (m_showTimerId > 0)
		{
			g_source_remove(m_showTimerId);
			m_showTimerId = 0;
			if(m_showTime > 0)
			{
				m_showTimerId = g_timeout_add(m_showTime, (GSourceFunc)m_ShowTimeFinishedCB, this);
			}
		}
	}

	void CPopupRating::m_Initialize()
	{
		t_parentHeight = 0;
		t_parentWidth = 0;
		t_nPopupRatingType = 0;
		t_bAutoArrange = true;		
		for(uint i = 0; i < BUTTON_ALL-1; i++)
		{
			t_Button[i] = NULL;
		}
		for(uint i = 0; i < (STAR_ICON_ALL - 1); i++)
		{
			t_StarIcon[i] = NULL;
			t_bStarIconselectedFlag[i] = false;
		}
		for(uint i = 0; i < (ARROW_BUTTON_ALL - 1); i++)
		{
			t_ArrowButton[i] = NULL;
		}

	//	m_parentAction = NULL;
		m_starIconsBG = NULL;
		t_pPopupRatingListenerSet = NULL;
		t_starUnmarkedImagePath = "";
		t_starMarkedImagePath = "";
		t_starHalfMarkedImagePath = "";
		
		m_nButtonNum = 2;
		m_nTotalMarkedStarIconNum = 6;
		m_bHasHalfMarkedStar = false;
		m_bStarMove = false;
		m_titleText = NULL;
		m_titleLine = NULL;
		m_contentText = NULL;
		m_bSupportTTS = false;

		m_bStarIconPressed = false;
		m_showTimerId = 0;
		m_showTime = 0;
	}

	void CPopupRating::m_CreateStarIcon()
	{
		m_starIconsBG = IActor::CreateInstance(dynamic_cast<IActor*>(this), (float)(t_parentWidth * STARSBG_WIDTH_RATE), (float)(t_parentHeight * STARSBG_HEIGHT_RATE));

		for(uint i = 0; i < (STAR_ICON_ALL - 1); i++)
		{
			t_StarIcon[i] = IImage::CreateInstance(m_starIconsBG, (float)(t_parentWidth * STAR_WIDTH_RATE), (float)(t_parentHeight * STAR_HEIGHT_RATE));
			t_StarIcon[i]->EnableReverse(false);
			t_StarIcon[i]->AddFocusListener(this);
			t_StarIcon[i]->AddMouseListener(this);
		}
	}

	void CPopupRating::m_CreateArrowButton()
	{
		for(uint i = 0; i < (ARROW_BUTTON_ALL - 1); i++)
		{
			t_ArrowButton[i] = IButton::CreateInstance(m_starIconsBG, (float)(t_parentWidth * ARROW_WIDTH_RATE), (float)(t_parentHeight *ARROW_HEIGHT_RATE));
			t_ArrowButton[i]->EnableReverse(false);
			t_ArrowButton[i]->AddFocusListener(this);
			t_ArrowButton[i]->AddListener(dynamic_cast<IButtonListener*>(this));
			t_ArrowButton[i]->EnablePointerFocus(true);
		}
	}

	void CPopupRating::m_CreateContent()
	{
		ClutterColor c = {255,255,255,255};
		m_contentText = IText::CreateInstance(dynamic_cast<Widget*>(this), (float)(t_parentWidth * TEXT_WIDTH_RATE), (float)(t_parentHeight * CONTEXT_HEIGHT_RATE));
		m_contentText->EnableMultiLine(true);
		m_contentText->SetTextColor(*clutter_color_init(&c, 255,255,255,255));
	}

	void CPopupRating::m_CreateTitle()
	{
		ClutterColor c = {255,255,255,255};
		m_titleText = IText::CreateInstance(dynamic_cast<Widget*>(this), (float)(t_parentWidth * TEXT_WIDTH_RATE), (float)(t_parentHeight * TITLE_TEXT_HEIGHT_RATE));
		m_titleText->EnableMultiLine(false);
		m_titleText->SetTextColor(*clutter_color_init(&c, 255,255,255,255));
		m_titleText->SetTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
		m_titleLine = IActor::CreateInstance(dynamic_cast<Widget*>(this), (float)(t_parentWidth * TEXT_WIDTH_RATE), 1.0);
		m_titleLine->SetBackgroundColor(*clutter_color_init(&c, 255,255,255,255));
	}

	void CPopupRating::m_CreateButton()
	{
		ClutterColor c = {255, 255, 255, 255};
		for(uint i = 0; i < m_nButtonNum; i++)
		{
			t_Button[i] = IButton::CreateInstance(this, (float)(t_parentWidth * BUTTON_WIDTH_RATE), (float)(t_parentHeight * BUTTON_HEIGHT_RATE));
			t_Button[i]->AddListener(this);
			t_Button[i]->AddFocusListener(this);
			t_Button[i]->SetBackgroundColor(IButton::STATE_ALL, *clutter_color_init(&c, 0, 0, 0, 0));
			t_Button[i]->SetTextColor(IButton::STATE_ALL, *clutter_color_init(&c, 255, 255, 255, 255));
			t_Button[i]->EnablePointerFocus(true);
			t_AddNoticeActor(t_Button[i]);
		}
		m_SetButtonTap();
	}

	void CPopupRating::m_SetArrowButtonTap()
	{
		for(uint i = 0; i < (ARROW_BUTTON_ALL - 1); i++)
		{
			if (i != 0) 	
			{					
				t_ArrowButton[i]->SetTabWindow(DIRECTION_LEFT, t_ArrowButton[i-1]); 
			}		
			if (i != ARROW_BUTTON_ALL - 2) 	
			{					
				t_ArrowButton[i]->SetTabWindow(DIRECTION_RIGHT, t_ArrowButton[i + 1]);	
			}
			t_ArrowButton[i]->SetTabWindow(DIRECTION_DOWN, t_Button[0]);
		}
	}

	void CPopupRating::m_SetButtonTap()
	{
		for(uint i = 0; i < m_nButtonNum; i++)
		{
			if (i == 0) 	
			{			
				t_Button[i]->SetTabWindow(DIRECTION_LEFT, t_Button[m_nButtonNum - 1]);	
			}		
			else		
			{		
				t_Button[i]->SetTabWindow(DIRECTION_LEFT, t_Button[i-1]); 
			}		
			if (i == m_nButtonNum - 1) 	
			{			
				t_Button[i]->SetTabWindow(DIRECTION_RIGHT, t_Button[0]);		
			}		
			else	
			{	
				if (i != 1)
				{
					t_Button[i]->SetTabWindow(DIRECTION_RIGHT, t_Button[i + 1]);	
				}				
			}
			t_Button[i]->SetTabWindow(DIRECTION_UP, t_ArrowButton[0]);
		}
	}
	
	void CPopupRating::m_AutoArrangeBGSize()
	{
		float bgWidthRate = 0.0;
		float bgHeightRate = 0.0;
		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			bgWidthRate = (float)STARSBG_WIDTH_RATE;
			bgHeightRate = (float)STARSBG_HEIGHT_RATE;
			CActor::Resize(t_parentWidth * bgWidthRate, t_parentHeight * bgHeightRate);
			CActor::SetPosition(0.0, 0.0);
			ClutterColor BgColor = {0,0,0,0};
			CActor::SetBackgroundColor(BgColor);
		}
		else
		{
			bgHeightRate = (float)(TITLE_TEXT_HEIGHT_RATE + CONTEXT_HEIGHT_RATE * 2.0 + TITLE_CONTENT_GAP_RATE + CONTENT_STAR_GAP_RATE +
				STAR_ICON_GAP_RATE + STAR_HEIGHT_RATE + BUTTON_HEIGHT_RATE + BUTTON_BUTTOM_GAP_RATE);
			CActor::Resize(t_parentWidth, t_parentHeight * bgHeightRate);
			CActor::SetPosition(0.0, (float)((1.0 - bgHeightRate) * t_parentHeight / 2.0));
		}
	}

	void CPopupRating::m_AutoArrangeStarIcon()
	{
		float starIconsBGX = (float)(t_parentWidth * (1 - STARSBG_WIDTH_RATE) / 2.0);
		float starIconsBGY = (float)(t_parentHeight * 0.207407);
		

		float buttonGapWidth = (float)(t_parentWidth * (STAR_GAP_RATE + STAR_WIDTH_RATE));
		float firstPosX = (float)((t_parentWidth - buttonGapWidth * 5.0 + t_parentWidth * STAR_GAP_RATE) / 2.0 - starIconsBGX);
		float PosY = (float)(t_parentHeight * (TITLE_TEXT_HEIGHT_RATE + CONTEXT_HEIGHT_RATE * 2.0 + TITLE_CONTENT_GAP_RATE + CONTENT_STAR_GAP_RATE) - starIconsBGY);
		if(BASE_LABEL_ONLY == t_nPopupRatingType)
		{
			firstPosX = (float)((t_parentWidth * STARSBG_WIDTH_RATE - buttonGapWidth * 5.0 + t_parentWidth * STAR_GAP_RATE) / 2.0);
			PosY = (float)((t_parentHeight * (STARSBG_HEIGHT_RATE - STAR_HEIGHT_RATE)) / 2.0);
			starIconsBGX = 0.0;
			starIconsBGY = 0.0;
		}

		m_starIconsBG->SetPosition(starIconsBGX, starIconsBGY);
		for(uint i = 0; i < (STAR_ICON_ALL - 1); i++)
		{
			t_StarIcon[i]->Resize((float)(t_parentWidth * STAR_WIDTH_RATE), (float)(t_parentHeight * STAR_HEIGHT_RATE));
			t_StarIcon[i]->SetPosition((float)(firstPosX + (float)i * buttonGapWidth), PosY);
			if(t_starUnmarkedImagePath != "")
			{
				t_StarIcon[i]->SetImage(t_starUnmarkedImagePath.c_str());
			}
		}

		for(uint i = 0; i < (m_nTotalMarkedStarIconNum + 1) / 2; i++)
		{
			if(t_starMarkedImagePath != "")
			{
				t_StarIcon[i]->SetImage(t_starMarkedImagePath.c_str());
				t_bStarIconselectedFlag[i] = true;
			}
		}

		if(m_bHasHalfMarkedStar && t_starHalfMarkedImagePath != "" && m_nTotalMarkedStarIconNum % 2)
		{
			t_StarIcon[(m_nTotalMarkedStarIconNum + 1) / 2 - 1]->SetImage(t_starHalfMarkedImagePath.c_str());
			t_bStarIconselectedFlag[(m_nTotalMarkedStarIconNum + 1) / 2 - 1] = true;
		}
	}

	void CPopupRating::m_AutoArrangeArrowButton()
	{
		float starIconsBGX = (float)(t_parentWidth * (1 - STARSBG_WIDTH_RATE) / 2.0);
		float starIconsBGY = (float)(t_parentHeight * 0.207407);
		float buttonGapWidth = (float)(t_parentWidth * (ARROW_WIDTH_RATE + 2 * 0.005208 + STARSBG_WIDTH_RATE));
		float firstPosX = (float)((t_parentWidth * (1.0 - 2 * (ARROW_WIDTH_RATE + 0.005208) - STARSBG_WIDTH_RATE) / 2.0) - starIconsBGX);
		float PosY = 0.0;

		for(uint i = 0; i < (ARROW_BUTTON_ALL - 1); i++)
		{
			t_ArrowButton[i]->Resize((float)(t_parentWidth * ARROW_WIDTH_RATE), (float)(t_parentHeight * ARROW_HEIGHT_RATE));
			t_ArrowButton[i]->SetPosition((float)(firstPosX + (float)i * buttonGapWidth), PosY);
		}
	}

	void CPopupRating::m_AutoArrangeTitle()
	{
		m_titleText->SetPosition((float)(t_parentWidth * (1.0 - TEXT_WIDTH_RATE) / 2.0), 0.0);
		m_titleLine->SetPosition((float)(t_parentWidth * (1.0 - TEXT_WIDTH_RATE) / 2.0), (float)(t_parentHeight * TITLE_TEXT_HEIGHT_RATE));
	}

	void CPopupRating::m_AutoArrangeContent(int nLineNum)
	{
		m_contentText->Resize((float)(t_parentWidth * TEXT_WIDTH_RATE), (float)(t_parentHeight * CONTEXT_HEIGHT_RATE * 2.0));
		if(1 == nLineNum)
		{
			m_contentText->SetTextAlignment(HALIGN_CENTER, VALIGN_TOP);
		}
		else
		{
			m_contentText->SetTextAlignment(HALIGN_LEFT, VALIGN_TOP);
		}
		m_contentText->SetPosition((float)(t_parentWidth * (1.0 - TEXT_WIDTH_RATE) / 2.0), (float)(t_parentHeight * (TITLE_TEXT_HEIGHT_RATE + TITLE_CONTENT_GAP_RATE)));
	}

	void CPopupRating::m_AutoArrangeButton()
	{
		float buttonGapWidth = (float)(t_parentWidth * 0.146875);
		float firstPosX = (float)((t_parentWidth - buttonGapWidth * (float)m_nButtonNum) / 2.0);
		for(uint i = 0; i < m_nButtonNum; i++)
		{
			t_Button[i]->Resize((float)(t_parentWidth * BUTTON_WIDTH_RATE), (float)(t_parentHeight * BUTTON_HEIGHT_RATE));
			t_Button[i]->SetPosition((float)(firstPosX + (float)i * buttonGapWidth), (float)(t_parentHeight * (TITLE_TEXT_HEIGHT_RATE + CONTEXT_HEIGHT_RATE * 2.0 + TITLE_CONTENT_GAP_RATE + CONTENT_STAR_GAP_RATE + STAR_HEIGHT_RATE + STAR_ICON_GAP_RATE)));
		}
	}

	bool CPopupRating::m_ProcessStarIconClicked(IActor* pWindow, int EventType)
	{
		uint j = 0;
		bool bStarIcon = false;
		for(uint i = 0; i < (STAR_ICON_ALL - 1); i++)
		{
			if (pWindow == t_StarIcon[i])
			{
				j = i;
				bStarIcon = true;
				break;
			}
		}

		if(bStarIcon)
		{
			if(false == t_bStarIconselectedFlag[j])
			{
				if(m_bHasHalfMarkedStar)
				{
					for(uint i = 0; i < j; i++)
					{
						t_StarIcon[i]->SetImage(t_starMarkedImagePath.c_str());
						t_bStarIconselectedFlag[i] = true;
					}
					t_StarIcon[j]->SetImage(t_starHalfMarkedImagePath.c_str());
					t_bStarIconselectedFlag[j] = true;
					m_nTotalMarkedStarIconNum = 2 * j + 1;
				}
				else
				{
					for(uint i = 0; i <= j; i++)
					{
						t_StarIcon[i]->SetImage(t_starMarkedImagePath.c_str());
						t_bStarIconselectedFlag[i] = true;
					}	
					m_nTotalMarkedStarIconNum = 2 * j + 2;
				}
			}
			else
			{
				if(m_bHasHalfMarkedStar)
				{
					for(uint i = j + 1; i < (STAR_ICON_ALL - 1); i++)
					{
						t_StarIcon[i]->SetImage(t_starUnmarkedImagePath.c_str());
						t_bStarIconselectedFlag[i] = false;
					}	
					
					if(m_nTotalMarkedStarIconNum % 2)
					{
						if(j == m_nTotalMarkedStarIconNum / 2)
						{
							t_StarIcon[j]->SetImage(t_starMarkedImagePath.c_str());
							m_nTotalMarkedStarIconNum = m_nTotalMarkedStarIconNum + 1;
							t_bStarIconselectedFlag[j] = true;
						}
						else
						{
							t_StarIcon[j]->SetImage(t_starUnmarkedImagePath.c_str());
							m_nTotalMarkedStarIconNum = j * 2;
							t_bStarIconselectedFlag[j] = false;
						}
					}
					else
					{
						t_StarIcon[j]->SetImage(t_starUnmarkedImagePath.c_str());
						m_nTotalMarkedStarIconNum = j * 2;
						t_bStarIconselectedFlag[j] = false;
					}
				}
				else
				{
					for(uint i = j; i < (STAR_ICON_ALL - 1); i++)
					{
						t_StarIcon[i]->SetImage(t_starUnmarkedImagePath.c_str());
						t_bStarIconselectedFlag[i] = false;
					}	
					m_nTotalMarkedStarIconNum = 2 * j;
				}
			}
			
			if(BASE_LABEL_ONLY != t_nPopupRatingType)
			{
				t_ArrowButton[0]->Enable(true);
				t_ArrowButton[0]->EnableFocus(true);
				t_ArrowButton[1]->Enable(true);
				t_ArrowButton[1]->EnableFocus(true);
				if(m_nTotalMarkedStarIconNum <= 0)
				{
					m_nTotalMarkedStarIconNum = 0;
					if(t_ArrowButton[0]->IsFocused())
					{
						t_ArrowButton[1]->SetFocus();
					}
					t_ArrowButton[0]->Enable(false);
					t_ArrowButton[0]->EnableFocus(false);
				}
				else if(m_nTotalMarkedStarIconNum >= (STAR_ICON_ALL - 1) * 2)
				{
					m_nTotalMarkedStarIconNum = (STAR_ICON_ALL - 1) * 2;
					if(t_ArrowButton[1]->IsFocused())
					{
						t_ArrowButton[0]->SetFocus();
					}
					t_ArrowButton[1]->Enable(false);
					t_ArrowButton[1]->EnableFocus(false);
				}
				else
				{
					// Nothing
				}
			}

			if (t_pPopupRatingListenerSet)
			{
				CPopupRatingListenerSet::TPopupRatingListenerData data;
				data.param[0] = EventType;
				data.type = STAR_ICON_ALL;
				t_pPopupRatingListenerSet->Process(&data);
			}
			return true;
		}

		return false;
	}

	bool CPopupRating::m_ProcessLeftRightKey(bool ifLeftKeyPressed)
	{
		if (ifLeftKeyPressed && t_ArrowButton[0]->IsEnabled())
		{
			t_ArrowButton[0]->SetFocus();
			if(m_bHasHalfMarkedStar)
			{
				m_nTotalMarkedStarIconNum = m_nTotalMarkedStarIconNum - 1;
			}
			else
			{
				m_nTotalMarkedStarIconNum = m_nTotalMarkedStarIconNum - 2;
			}
			t_ArrowButton[1]->Enable(true);
			t_ArrowButton[1]->EnableFocus(true);
			if(m_nTotalMarkedStarIconNum <= 0)
			{
				m_nTotalMarkedStarIconNum = 0;
				t_ArrowButton[1]->SetFocus();
				t_ArrowButton[0]->Enable(false);
				t_ArrowButton[0]->EnableFocus(false);
			}

			if(m_bHasHalfMarkedStar)
			{
				if(m_nTotalMarkedStarIconNum % 2)
				{
					t_StarIcon[m_nTotalMarkedStarIconNum / 2]->SetImage(t_starHalfMarkedImagePath.c_str());
					t_bStarIconselectedFlag[m_nTotalMarkedStarIconNum / 2] = true;
				}
				else
				{
					t_StarIcon[m_nTotalMarkedStarIconNum / 2]->SetImage(t_starUnmarkedImagePath.c_str());
					t_bStarIconselectedFlag[m_nTotalMarkedStarIconNum / 2] = false;
				}
			}
			else
			{
				t_StarIcon[m_nTotalMarkedStarIconNum / 2]->SetImage(t_starUnmarkedImagePath.c_str());
				t_bStarIconselectedFlag[m_nTotalMarkedStarIconNum / 2] = false;
			}
			
			return true;
		}
		else if(false == ifLeftKeyPressed && t_ArrowButton[1]->IsEnabled())
		{
			t_ArrowButton[1]->SetFocus();
			if(m_bHasHalfMarkedStar)
			{
				m_nTotalMarkedStarIconNum = m_nTotalMarkedStarIconNum + 1;
			}
			else
			{
				m_nTotalMarkedStarIconNum = m_nTotalMarkedStarIconNum + 2;
			}
			t_ArrowButton[0]->Enable(true);
			t_ArrowButton[0]->EnableFocus(true);
			if(m_nTotalMarkedStarIconNum >= (STAR_ICON_ALL - 1) * 2)
			{
				m_nTotalMarkedStarIconNum = (STAR_ICON_ALL - 1) * 2;
				t_ArrowButton[0]->SetFocus();
				t_ArrowButton[1]->Enable(false);
				t_ArrowButton[1]->EnableFocus(false);
			}

			if(m_bHasHalfMarkedStar)
			{
				if(m_nTotalMarkedStarIconNum % 2)
				{
					t_StarIcon[(m_nTotalMarkedStarIconNum + 1) / 2 - 1]->SetImage(t_starHalfMarkedImagePath.c_str());
					t_bStarIconselectedFlag[(m_nTotalMarkedStarIconNum + 1) / 2 - 1] = true;
				}
				else
				{
					t_StarIcon[(m_nTotalMarkedStarIconNum + 1) / 2 - 1]->SetImage(t_starMarkedImagePath.c_str());
					t_bStarIconselectedFlag[(m_nTotalMarkedStarIconNum + 1) / 2 - 1] = true;
				}
			}
			else
			{
				t_StarIcon[(m_nTotalMarkedStarIconNum + 1) / 2 - 1]->SetImage(t_starMarkedImagePath.c_str());
				t_bStarIconselectedFlag[(m_nTotalMarkedStarIconNum + 1) / 2 - 1] = true;
			}

			return true;
		}
		else
		{
			// Do nothing
		}

		return false;
	}

	bool CPopupRating::m_ProcessButtonEvent(IActor* pWindow, int EventType)
	{
		if (t_pPopupRatingListenerSet)
		{
			CPopupRatingListenerSet::TPopupRatingListenerData data;
			data.param[0] = EventType;

			if (pWindow == t_Button[0])
			{
				data.type = BUTTON_1;
			}
			else if (pWindow == t_Button[1])
			{
				data.type = BUTTON_2;
			}
			else
			{
				data.type = 0;
			}
			t_pPopupRatingListenerSet->Process(&data);
			return true;
		}

		return false;
	}

	void CPopupRating::m_Destroy()
	{
		if(m_titleText)
		{
			m_titleText->Release();
		}

		if(m_titleLine)
		{
			m_titleLine->Release();
		}
		
		if(m_contentText)
		{
			m_contentText->Release();
		}
		for(uint i = 0; i < (STAR_ICON_ALL - 1); i++)
		{
			if(t_StarIcon[i])
			{
				t_StarIcon[i]->RemoveFocusListener(this);
				t_StarIcon[i]->RemoveMouseListener(this);
				t_StarIcon[i]->Release();
			}
		}
		for(uint i = 0; i < (ARROW_BUTTON_ALL - 1); i++)
		{
			if(t_ArrowButton[i])
			{
				t_ArrowButton[i]->RemoveFocusListener(this);
				t_ArrowButton[i]->RemoveListener(this);
				t_ArrowButton[i]->Release();
			}
		}
		for(uint i = 0; i < BUTTON_ALL-1; i++)
		{
			if(t_Button[i])
			{
				t_Button[i]->RemoveFocusListener(this);
				t_Button[i]->RemoveListener(this);
				t_Button[i]->Release();
			}
		}

		if(m_starIconsBG)
		{
			m_starIconsBG->Release();
		}

		if (m_showTimerId > 0)
		{
			g_source_remove(m_showTimerId);
			m_showTimerId = 0;
		}

		//delete t_pPopupRatingListenerSet;
		if (t_pPopupRatingListenerSet)
		{
			if (t_pPopupRatingListenerSet->IsLocked())
			{
				t_pPopupRatingListenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(t_pPopupRatingListenerSet);
			} 
			else
			{
				delete t_pPopupRatingListenerSet;
			}
			t_pPopupRatingListenerSet = NULL;
		}

	//	RemoveAction(m_parentAction);
	//	m_parentAction->Release();
	//	RemoveClickListener(this);
		RemoveKeyboardListener(this);
		RemoveMouseListener(this);
	}
}
