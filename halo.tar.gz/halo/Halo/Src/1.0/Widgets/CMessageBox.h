#ifndef _CMESSAGEBOX_H_
#define _CMESSAGEBOX_H_
namespace HALO
{
	class CMessageBox:virtual public IMessageBox, public CActor, public IKeyboardListener, public IClickListener, public IFocusListener, public IMouseListener, public IButtonListener
	{
	public:
		CMessageBox();
		virtual ~CMessageBox();
		virtual bool Initialize(IActor* parent, const TMessageBoxAttr &attr);
		virtual bool Initialize( Widget* parent, const TMessageBoxAttr &attr );
		virtual void SetBGColor(const ClutterColor BGColor);
		virtual void SetTitleRect(float x, float y, float w, float h);
		virtual void SetTitleText(const std::string& titleText);
		virtual std::string TitleText() const;
		virtual void SetTitleTextColor(const ClutterColor textcolor);
		virtual void SetTitleTextFont(const std::string& font);
		virtual std::string TitleTextFont() const;
		virtual void SetTitleTextAlignment(EHAlignment hAlign, EVAlignment vAlign);
		virtual int TitleTextLineCount();
		virtual void SetTitleLineRect(float x, float y, float w, float h);
		virtual void SetTitleLineColor(const ClutterColor color);
		virtual void SetContentRect(float x, float y, float w, float h);
		virtual void SetContentText(const std::string& contentText);
		virtual std::string ContentText() const;
		virtual void SetContentTextColor(const ClutterColor textcolor);
		virtual void SetContentTextFont(const std::string& font);
		virtual std::string ContentTextFont() const;
		virtual void SetContentTextAlignment(EHAlignment hAlign, EVAlignment vAlign);
		virtual void SetContentTextRowGap(int gap);
		virtual int ContentTextRowGap() const;
		virtual int ContentTextLineCount();
		virtual int ContentTextLineHeight(int index);
		virtual void SetContent2Rect(float x, float y, float w, float h);
		virtual void SetContentText2(const std::string& contentText);
		virtual std::string ContentText2() const;
		virtual void SetContentText2Color(const ClutterColor textcolor);
		virtual void SetContentText2Font(const std::string& font);
		virtual std::string ContentText2Font() const;
		virtual void SetContentText2Alignment(EHAlignment hAlign, EVAlignment vAlign);
		virtual int ContentText2LineCount();
		virtual void SetButtonRect(const EMessageButtons nButton, float x, float y, float w, float h);
		virtual void SetButtonImage(const EMessageButtons nButton, IButton::EButtonState state, const std::string& imagePath);
		virtual void SetButtonBackgroundColor(const EMessageButtons nButton, IButton::EButtonState state, const ClutterColor color);
		virtual void SetButtonText(const EMessageButtons nButton, IButton::EButtonState state, const std::string& text);
		virtual void SetButtonTextColor(const EMessageButtons nButton, IButton::EButtonState state, const ClutterColor color);
		virtual void SetButtonTextFontSize(const EMessageButtons nButton, IButton::EButtonState state, int fontSize);
		virtual void SetButtonBorderColor(const EMessageButtons nButton, IButton::EButtonState state, const ClutterColor& color);
		virtual void SetButtonBorderWidth(const EMessageButtons nButton, IButton::EButtonState state, float width);
		virtual void SetDefaultFocus(int nButton);
		virtual int DefaultFocus() const;
		virtual void SetLoadingAttr(const ILoading::TLoadingAttr &attr);
		virtual bool AddListener(IMessageBoxListener* listener);
		virtual bool RemoveListener(IMessageBoxListener* listener);
		virtual void SetSupportTTS(bool bSupport);
		virtual bool SupportTTS() const;
		virtual void SetShowTime(guint nShowTime);
		virtual guint ShowTime() const;

	protected:
		float t_parentWidth;
		float t_parentHeight;
		int t_nMessageContentType;
		bool t_bAutoArrange;
		IButton *t_Button[BUTTON_ALL-1];
		ILoading *t_Loading;
		class CMessageBoxListenerSet *t_pMessageBoxListenerSet;

	protected:
		virtual bool OnFocusIn(IWidgetExtension* pWindow);
		virtual bool OnFocusOut(IWidgetExtension* pWindow);	
		virtual bool OnClicked(IWidgetExtension* pWindow, IEvent* pClickEvent);
		virtual bool OnKeyReleased(IWidgetExtension* pThis, IKeyboardEvent* event);
		virtual bool OnMouseMoved(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnButtonClicked(class IButton* button, EButtonClickType type);
		
	private:
		uint m_nButtonNum;
		bool m_bTitle;
		IText *m_titleText;
		IActor *m_titleLine;
		IText *m_contentText;
		IText *m_contentText2;
		float m_parentHeightRate;
		float m_contentPosYRate;
		float m_content2PosYRate;
		float m_buttonPosYRate;
		float m_loadingPosYRate;
		bool m_bSupportTTS;
	//	IAction* m_parentAction;
		guint m_showTimerId;
		guint m_showTime;

		static gboolean m_ShowTimeFinishedCB(gpointer data);
		void m_ResetShowTime();
		void m_Initialize();
		void m_CreateContent();
		void m_CreateTitle();
		void m_CreateButton();
		void m_SetButtonTap();
		void m_AutoArrangeRate(int nLineNum);
		void m_AutoArrangeBGSize();
		void m_AutoArrangeTitle();
		void m_AutoArrangeContent(int nLineNum);
		void m_AutoArrangeContent2();
		void m_AutoArrangeButton();
		void m_AutoArrangeLoading();
		void m_Destroy();
	};
}
#endif
