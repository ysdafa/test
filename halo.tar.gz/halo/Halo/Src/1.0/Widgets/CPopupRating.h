#ifndef _CPOPUPRATING_H_
#define _CPOPUPRATING_H_
namespace HALO
{
	class CPopupRating:virtual public IPopupRating, public CActor, public IKeyboardListener, public IClickListener, public IFocusListener, public IMouseListener, public IButtonListener
	{
	public:
		CPopupRating();
		virtual ~CPopupRating();
		virtual bool Initialize(IActor* parent, const TPopupRatingAttr &attr);
		virtual bool Initialize( Widget* parent, const TPopupRatingAttr &attr );
		virtual void SetBGColor(const ClutterColor BGColor);
		virtual void SetTitleRect(float x, float y, float w, float h);
		virtual void SetTitleText(const std::string& titleText);
		virtual std::string TitleText() const;
		virtual void SetTitleTextColor(const ClutterColor textcolor);
		virtual void SetTitleTextFont(const std::string& font);
		virtual std::string TitleTextFont() const;
		virtual void SetTitleTextAlignment(EHAlignment hAlign, EVAlignment vAlign);
		virtual void SetTitleLineRect(float x, float y, float w, float h);
		virtual void SetTitleLineColor(const ClutterColor color);
		virtual void SetContentRect(float x, float y, float w, float h);
		virtual void SetContentText(const std::string& contentText);
		virtual std::string ContentText() const;
		virtual void SetContentTextColor(const ClutterColor textcolor);
		virtual void SetContentTextFont(const std::string& font);
		virtual std::string ContentTextFont() const;
		virtual void SetContentTextAlignment(EHAlignment hAlign, EVAlignment vAlign);
		virtual void SetStarIconRect(const EPopupRatingStarIcons nStarIcon, float x, float y, float w, float h);
		virtual void SetStarIconUnmarkedImage(const std::string& imagePath);
		virtual std::string StarIconUnmarkedImage() const;
		virtual void SetStarIconMarkedImage(const std::string& imagePath);
		virtual std::string StarIconMarkedImage() const;
		virtual void SetStarIconHalfMarkedImage(const std::string& imagePath);
		virtual std::string StarIconHalfMarkedImage() const;
		virtual void SetStarIconsBGRect(float x, float y, float w, float h);
		virtual void SetStarIconsBGColor(const ClutterColor color);
		virtual void SetArrowButtonRect(const EPopupRatingArrowButtons nArrowButton, float x, float y, float w, float h);
		virtual void SetArrowButtonImage(const EPopupRatingArrowButtons nArrowButton, IButton::EButtonState state, const std::string& imagePath);
		virtual void SetButtonRect(const EPopupRatingButtons nButton, float x, float y, float w, float h);
		virtual void SetButtonImage(const EPopupRatingButtons nButton, IButton::EButtonState state, const std::string& imagePath);
		virtual void SetButtonBackgroundColor(const EPopupRatingButtons nButton, IButton::EButtonState state, const ClutterColor color);
		virtual void SetButtonText(const EPopupRatingButtons nButton, IButton::EButtonState state, const std::string& text);
		virtual void SetButtonTextColor(const EPopupRatingButtons nButton, IButton::EButtonState state, const ClutterColor color);
		virtual void SetButtonTextFontSize(const EPopupRatingButtons nButton, IButton::EButtonState state, int fontSize);
		virtual void SetButtonBorderColor(const EPopupRatingButtons nButton, IButton::EButtonState state, const ClutterColor& color);
		virtual void SetButtonBorderWidth(const EPopupRatingButtons nButton, IButton::EButtonState state, float width);
		virtual void SetDefaultFocus(int nButton);
		virtual int DefaultFocus() const;
		virtual void SetMarkedStarIconNumber(int markedStarIconNumber);
		virtual int MarkedStarIconNumber() const;
		virtual bool AddListener(IPopupRatingListener* listener);
		virtual bool RemoveListener(IPopupRatingListener* listener);
		virtual void SetSupportTTS(bool bSupport);
		virtual bool SupportTTS() const;
		virtual void SetShowTime(guint nShowTime);
		virtual guint ShowTime() const;

	protected:
		float t_parentWidth;
		float t_parentHeight;
		int t_nPopupRatingType;
		bool t_bAutoArrange;
		IButton *t_Button[BUTTON_ALL - 1];
		IImage *t_StarIcon[STAR_ICON_ALL - 1];
		IButton *t_ArrowButton[ARROW_BUTTON_ALL - 1];
		bool t_bStarIconselectedFlag[5];
		class CPopupRatingListenerSet *t_pPopupRatingListenerSet;
		std::string t_starUnmarkedImagePath;
		std::string t_starMarkedImagePath;
		std::string t_starHalfMarkedImagePath;

	protected:
		virtual bool OnFocusIn(IWidgetExtension* pWindow);
		virtual bool OnFocusOut(IWidgetExtension* pWindow);	
		virtual bool OnClicked(IWidgetExtension* pWindow, IEvent* pClickEvent);
		virtual bool OnKeyReleased(IWidgetExtension* pThis, IKeyboardEvent* event);

		virtual bool OnMouseButtonPressed(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnMouseButtonReleased(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnMouseMoved(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnButtonClicked(class IButton* button, EButtonClickType type);

	private:
		uint m_nButtonNum;
		uint m_nTotalMarkedStarIconNum;
		bool m_bHasHalfMarkedStar;
		bool m_bStarMove;
		IText *m_titleText;
		IActor *m_titleLine;
		IText *m_contentText;
		bool m_bSupportTTS;
		bool m_bStarIconPressed;
	//	IAction* m_parentAction;
		guint m_showTimerId;
		guint m_showTime;
		IActor *m_starIconsBG;

		static gboolean m_ShowTimeFinishedCB(gpointer data);
		void m_ResetShowTime();
		void m_Initialize();
		void m_CreateStarIcon();
		void m_CreateArrowButton();
		void m_CreateContent();
		void m_CreateTitle();
		void m_CreateButton();
		void m_SetArrowButtonTap();
		void m_SetButtonTap();
		void m_AutoArrangeBGSize();
		void m_AutoArrangeStarIcon();
		void m_AutoArrangeArrowButton();
		void m_AutoArrangeTitle();
		void m_AutoArrangeContent(int nLineNum);
		void m_AutoArrangeButton();
		bool m_ProcessStarIconClicked(IActor* pWindow, int EventType);
		bool m_ProcessLeftRightKey(bool ifLeftKeyPressed);
		bool m_ProcessButtonEvent(IActor* pWindow, int EventType);
		void m_Destroy();
	};
}
#endif
