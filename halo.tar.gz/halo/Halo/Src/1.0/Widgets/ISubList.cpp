#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	ISubList* ISubList::CreateInstance(IActor* parent, const TSubListAttr &attr)
	{
		CSubList* subList = dynamic_cast<CSubList*>(Instance::CreateInstance(CLASS_ID_ISUBLIST));
		if (NULL != subList)
		{
			subList->Initialize(parent, attr);
		}
		return subList;
	}

	ISubList* ISubList::CreateInstance(Widget* parent, const TSubListAttr &attr)
	{
		CSubList* subList = dynamic_cast<CSubList*>(Instance::CreateInstance(CLASS_ID_ISUBLIST));
		HALO_ASSERT(subList != NULL);

		if (subList != NULL)
		{
			subList->Initialize(parent, attr);
		}

		return subList;
	}
}
