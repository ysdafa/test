#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	IPopupRating* IPopupRating::CreateInstance(IActor* parent, const TPopupRatingAttr &attr)
	{
		CPopupRating* popupRating = dynamic_cast<CPopupRating*>(Instance::CreateInstance(CLASS_ID_IPOPUPRATING));
		if (NULL != popupRating)
		{
			popupRating->Initialize(parent, attr);
		}
		return popupRating;
	}

	IPopupRating* IPopupRating::CreateInstance(Widget* parent, const TPopupRatingAttr &attr)
	{
		CPopupRating* popupRating = dynamic_cast<CPopupRating*>(Instance::CreateInstance(CLASS_ID_IPOPUPRATING));
		HALO_ASSERT(popupRating != NULL);

		if (popupRating != NULL)
		{
			popupRating->Initialize(parent, attr);
		}

		return popupRating;
	}
}