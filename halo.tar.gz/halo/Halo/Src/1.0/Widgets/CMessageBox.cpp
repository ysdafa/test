#include "Halo1_0.h"

#define TEXT_WIDTH_RATE 0.584375
#define TITLE_TEXT_HEIGHT_RATE 0.088889
#define CONTEXT_HEIGHT_RATE 0.044444
#define SINGLE_LINE_TITLE_CONTEXT_GAP 0.063889
#define SINGLE_LINE_TITLE_CONTEXT_NO_TITLE_Y 0.042593
#define BUTTON_WIDTHRATE 0.140625
#define BUTTON_HEIGHTRATE 0.061111
#define MULTI_LINE_BUTTON_GAP_RATE 0.020370

namespace HALO
{         
	class CMessageBoxListenerSet : public ListenerSet
	{
	public:
		struct TMessageBoxListenerData
		{
			int type;
			int param[1];
			void* pData;
		};

		CMessageBoxListenerSet(CMessageBox* owner) :m_owner(owner){}
		virtual ~CMessageBoxListenerSet(void){}

		virtual bool Process(TMessageBoxListenerData* data);

	private:
		CMessageBox* m_owner;
	};

	bool CMessageBoxListenerSet::Process(TMessageBoxListenerData* data)
	{
		bool ret = false;

		if (NULL != data)
		{
			ListenerList::iterator iter = m_list.begin();

			while (iter != m_list.end())
			{
				IMessageBoxListener* listener = (IMessageBoxListener*)(*iter);

				ret |= listener->OnButtonEvent(m_owner, data->param[0], data->type);
	
				iter++;
			}
		}

		return ret;
	}

	//CMessageBox
	CMessageBox::CMessageBox()
	{
	}

	CMessageBox::~CMessageBox()
	{
		m_Destroy();
	}

	bool CMessageBox::Initialize( IActor* parent, const TMessageBoxAttr &attr )
	{
		Widget *widget = dynamic_cast<Widget *>(parent);
		return Initialize(widget, attr);
	}
	
	bool CMessageBox::Initialize( Widget* parent, const TMessageBoxAttr &attr )
	{
		ASSERT(attr.w > 0 && attr.h > 0);
		m_Initialize();
		t_parentWidth = attr.w;
		t_parentHeight = attr.h;

		// TODO: this color will be replaced by color picker later
		ClutterColor BgColor = {39,124,175,200};
		m_nButtonNum = attr.nButtonType;
		t_nMessageContentType = attr.nContentType;			
		m_bTitle = attr.bTitle;
		t_bAutoArrange = attr.bAutoFlag;
		t_orientation = Orientation(true);

		CActor::Initialize(parent, t_parentWidth, t_parentHeight);
		CActor::SetPosition(attr.x, attr.y);
		CActor::SetBackgroundColor(BgColor);

		m_CreateContent();
		
		if(m_bTitle)
		{
			m_CreateTitle();
		}

		if(NO_BUTTON != m_nButtonNum)
		{
			m_CreateButton();
		}
		t_pMessageBoxListenerSet = new class CMessageBoxListenerSet(this);
		CActor::EnableFocus(true);

		IClickAction* action = IClickAction::CreateInstance(this);
		AddAction(action);
		m_parentAction = action;
		AddClickListener(this);
		AddKeyboardListener(this);
		AddFocusListener(this);
		AddMouseListener(this);
		return true;
	}

	void CMessageBox::SetBGColor(const ClutterColor BGColor)
	{
		CActor::SetBackgroundColor(BGColor);
	}

	void CMessageBox::SetTitleRect(float x, float y, float w, float h)
	{
		if(false == m_bTitle || NULL == m_titleText)
		{
			return;
		}
		if(false == t_bAutoArrange)
		{
			m_titleText->Resize(w, h);
			m_titleText->SetPosition(x, y);

			m_titleLine->Resize(w, 1);
			m_titleLine->SetPosition(x, y + h);
		}
	}

	void CMessageBox::SetTitleText(const std::string& titleText)
	{
		if(false == m_bTitle || NULL == m_titleText)
		{
			return;
		}

		m_titleText->SetText(titleText.c_str());

		if(t_bAutoArrange)
		{
			m_AutoArrangeTitle();
		}
	}

	std::string CMessageBox::TitleText() const
	{
		if(NULL == m_titleText)
		{
			return "";
		}
		return m_titleText->Text();
	}

	void CMessageBox::SetTitleTextColor(const ClutterColor textcolor)
	{
		if(false == m_bTitle || NULL == m_titleText)
		{
			return;
		}
		m_titleText->SetTextColor(textcolor);
	}

	void CMessageBox::SetTitleTextFont(const std::string& font)
	{
		
		if(false == m_bTitle || NULL == m_titleText)
		{
			return;
		}
		
		m_titleText->SetFont(font.c_str());
	}

	std::string CMessageBox::TitleTextFont() const
	{
		if(NULL == m_titleText)
		{
			return "";
		}
		return m_titleText->Font();
	}

	void CMessageBox::SetTitleTextAlignment(EHAlignment hAlign, EVAlignment vAlign)
	{
		if(NULL == m_titleText)
		{
			return;
		}
		m_titleText->SetTextAlignment(hAlign, vAlign);
	}

	int CMessageBox::TitleTextLineCount()
	{
		if(NULL == m_titleText)
		{
			return 0;
		}
		return m_titleText->LineCount();
	}

	void CMessageBox::SetTitleLineRect(float x, float y, float w, float h)
	{
		if(NULL == m_titleLine)
		{
			return;
		}
		m_titleLine->Resize(w, h);
		m_titleLine->SetPosition(x, y);
	}

	void CMessageBox::SetTitleLineColor(const ClutterColor color)
	{
		if(false == m_bTitle || NULL == m_titleLine)
		{
			return;
		}
		
		m_titleLine->SetBackgroundColor(color);
	}

	void CMessageBox::SetContentRect(float x, float y, float w, float h)
	{	
		if(NULL == m_contentText)
		{
			return;
		}
		
		if(false == t_bAutoArrange)
		{
			m_contentText->Resize(w, h);
			m_contentText->SetPosition(x, y);
		}
	}

	void CMessageBox::SetContentText(const std::string& contentText)
	{
		if(NULL == m_contentText)
		{
			return;
		}
		
		m_contentText->SetText(contentText.c_str());

		if(t_bAutoArrange)
		{
			int nLineNum = 0; 
			nLineNum = m_contentText->LineCount();
			if(nLineNum > 8)
			{
				nLineNum = 8;
			}
			m_AutoArrangeRate(nLineNum);
			m_AutoArrangeBGSize();
			m_AutoArrangeContent(nLineNum);
			m_AutoArrangeButton();
		}
	}

	std::string CMessageBox::ContentText() const
	{
		if(NULL == m_contentText)
		{
			return "";
		}
		return m_contentText->Text();
	}

	void CMessageBox::SetContentTextColor(const ClutterColor textcolor)
	{
		if(NULL == m_contentText)
		{
			return;
		}

		m_contentText->SetTextColor(textcolor);
	}

	void CMessageBox::SetContentTextFont(const std::string& font)
	{
		if(NULL == m_contentText)
		{
			return;
		}

		m_contentText->SetFont(font.c_str());
	}

	std::string CMessageBox::ContentTextFont() const
	{
		if(NULL == m_contentText)
		{
			return "";
		}
		return m_contentText->Font();
	}

	void CMessageBox::SetContentTextAlignment(EHAlignment hAlign, EVAlignment vAlign)
	{
		if(NULL == m_contentText)
		{
			return;
		}
		m_contentText->SetTextAlignment(hAlign, vAlign);
	}

	void CMessageBox::SetContentTextRowGap(int gap)
	{
		if(NULL == m_contentText)
		{
			return;
		}
		m_contentText->SetRowGap(gap);
	}

	int CMessageBox::ContentTextRowGap() const
	{
		if(NULL == m_contentText)
		{
			return 0;
		}
		return m_contentText->RowGap();
	}

	int CMessageBox::ContentTextLineCount()
	{
		if(NULL == m_contentText)
		{
			return 0;
		}
		return m_contentText->LineCount();
	}

	void CMessageBox::SetContent2Rect(float x, float y, float w, float h)
	{
		if(NULL == m_contentText2)
		{
			return;
		}

		if( false == t_bAutoArrange)
		{
			m_contentText2->Resize(w, h);
			m_contentText2->SetPosition(x, y);
		}
	}

	void CMessageBox::SetContentText2(const std::string& contentText)
	{
		if(NULL == m_contentText2)
		{
			return;
		}

		m_contentText2->SetText(contentText.c_str());

		if(t_bAutoArrange)
		{
			int nLineNum = 0;
			nLineNum = m_contentText->LineCount();
			if(nLineNum > 8)
			{
				nLineNum = 8;
			}
			m_AutoArrangeRate(nLineNum);
			m_AutoArrangeBGSize();
			m_AutoArrangeContent2();
			m_AutoArrangeButton();
		}
	}

	std::string CMessageBox::ContentText2() const
	{
		if(NULL == m_contentText2)
		{
			return "";
		}
		return m_contentText2->Text();
	}

	void CMessageBox::SetContentText2Color(const ClutterColor textcolor)
	{
		if(NULL == m_contentText2)
		{
			return;
		}

		m_contentText2->SetTextColor(textcolor);
	}

	void CMessageBox::SetContentText2Font(const std::string& font)
	{
		if(NULL == m_contentText2)
		{
			return;
		}

		m_contentText2->SetFont(font.c_str());
	}

	std::string CMessageBox::ContentText2Font() const
	{
		if(NULL == m_contentText2)
		{
			return "";
		}
		return m_contentText2->Font();
	}

	void CMessageBox::SetContentText2Alignment(EHAlignment hAlign, EVAlignment vAlign)
	{
		if(NULL == m_contentText2)
		{
			return;
		}
		m_contentText2->SetTextAlignment(hAlign, vAlign);
	}

	int CMessageBox::ContentText2LineCount()
	{
		if(NULL == m_contentText2)
		{
			return 0;
		}
		return m_contentText2->LineCount();
	}

	void CMessageBox::SetButtonRect(const EMessageButtons nButton, float x, float y, float w, float h)
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);
		if(t_bAutoArrange)
		{
			return;
		}
		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->Resize(w, h);
				t_Button[i]->SetPosition(x, y);
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->Resize(w, h);
			t_Button[nButton - 1]->SetPosition(x, y);
		}
		
	}

	void CMessageBox::SetButtonImage(const EMessageButtons nButton, IButton::EButtonState state, const std::string& imagePath)
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);
		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->SetBackgroundImage(state, imagePath);
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->SetBackgroundImage(state, imagePath);
		}
	}

	void CMessageBox::SetButtonBackgroundColor(const EMessageButtons nButton, IButton::EButtonState state, const ClutterColor color)
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->SetBackgroundColor(state, color);
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->SetBackgroundColor(state, color);
		}
	}

	void CMessageBox::SetButtonText(const EMessageButtons nButton, IButton::EButtonState state, const std::string& text)
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);
		ClutterColor c = {255, 255, 255, 255};
		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->SetText(state, text);
				t_Button[i]->SetTextColor(IButton::STATE_ALL, *clutter_color_init(&c, 255, 255, 255, 255));
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->SetText(state, text);
			t_Button[nButton - 1]->SetTextColor(IButton::STATE_ALL, *clutter_color_init(&c, 255, 255, 255, 255));
		}
	}

	void CMessageBox::SetButtonTextColor(const EMessageButtons nButton, IButton::EButtonState state, const ClutterColor color)
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);
		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->SetTextColor(state, color);
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->SetTextColor(state, color);
		}
	}

	void CMessageBox::SetButtonTextFontSize(const EMessageButtons nButton, IButton::EButtonState state, int fontSize)
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);
		if(BUTTON_ALL == nButton)
		{
 			for(uint i = 0; i < m_nButtonNum; i++)
			{
				t_Button[i]->SetFontSize(state, fontSize);
			}
		}
		else
		{
			if(nButton > m_nButtonNum)
			{
				return;
			}
			t_Button[nButton - 1]->SetFontSize(state, fontSize);
		}	
	}

	void CMessageBox::SetDefaultFocus(int nButton)
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);
		if((uint)nButton > m_nButtonNum)
		{
			return;
		}
		t_Button[nButton - 1]->SetFocus();
	}

	int CMessageBox::DefaultFocus() const
	{
		for(uint i = 0; i < m_nButtonNum; i++)
		{
			if(t_Button[i]->IsFocused())
			{
				return (i + 1);
			}
		}

		return 0;
	}

	void CMessageBox::SetLoadingAttr(const ILoading::TLoadingAttr &attr)
	{
		if((SINGLE_LINE_CONTENT_WITH_LOADING == t_nMessageContentType) || (MULTI_LINE_CONTENT_WITH_LOADING == t_nMessageContentType))
		{
			if(NULL != t_Loading)
			{
				return;
			}
			t_Loading = ILoading::CreateInstance(dynamic_cast<Widget*>(this), attr);
			if(t_bAutoArrange)
			{
				int nLineNum = 0;
				nLineNum = m_contentText->LineCount();
				if(nLineNum > 8)
				{
					nLineNum = 8;
				}
				m_AutoArrangeRate(nLineNum);
				m_AutoArrangeBGSize();
				m_AutoArrangeLoading();
			}
			t_Loading->Play();
		}
	}

	bool CMessageBox::AddListener(IMessageBoxListener* listener)
	{
		ASSERT(listener != NULL);

		return t_pMessageBoxListenerSet->Add(listener);
	}

	bool CMessageBox::RemoveListener(IMessageBoxListener* listener)
	{
		ASSERT(listener != NULL);

		return t_pMessageBoxListenerSet->Remove(listener);
	}

	void CMessageBox::SetSupportTTS(bool bSupport)
	{
		m_bSupportTTS = bSupport;
	}

	bool CMessageBox::SupportTTS() const
	{
		return m_bSupportTTS;
	}

	void CMessageBox::SetShowTime(guint nShowTime)
	{
		if(nShowTime <= 0)
		{
			return;
		}
		m_showTime = nShowTime;
		m_showTimerId = g_timeout_add(m_showTime, (GSourceFunc)m_ShowTimeFinishedCB, this);
	}

	guint CMessageBox::ShowTime() const
	{
		return m_showTime;
	}

	gboolean CMessageBox::m_ShowTimeFinishedCB(gpointer data)
	{
		CMessageBox* messageBox = reinterpret_cast<CMessageBox *>(data);
		if(messageBox)
		{
			messageBox->Hide();
		}

		return false;
	}

	void CMessageBox::t_UpdateOrientation(EOrientation orientation)	
	{
		if(t_orientation == orientation)
		{
			return;
		}
		else
		{
			t_orientation = orientation;
			EHAlignment ehAlign = HALIGN_LEFT;
			EVAlignment evAlign = VALIGN_TOP;
			if(m_contentText)
			{
				m_contentText->GetTextAlignment(ehAlign, evAlign);
				if(HALIGN_LEFT == ehAlign)
				{
					m_contentText->SetTextAlignment(HALIGN_RIGHT, evAlign);
				}
				else if(HALIGN_RIGHT == ehAlign)
				{
					m_contentText->SetTextAlignment(HALIGN_LEFT, evAlign);
				}
				else
				{
					// Nothing
				}
			}
			if(m_contentText2)
			{
				m_contentText2->GetTextAlignment(ehAlign, evAlign);
				if(HALIGN_LEFT == ehAlign)
				{
					m_contentText2->SetTextAlignment(HALIGN_RIGHT, evAlign);
				}
				else if(HALIGN_RIGHT == ehAlign)
				{
					m_contentText2->SetTextAlignment(HALIGN_LEFT, evAlign);
				}
				else
				{
					// Nothing
				}
			}
			float button1X = 0.0, button1Y = 0.0, button2X = 0.0, button2Y = 0.0;
			if(BUTTON_2 == m_nButtonNum)
			{
				t_Button[0]->GetPosition(button1X, button1Y);
				t_Button[1]->GetPosition(button2X, button2Y);
				t_Button[0]->SetPosition(button2X, button2Y);
				t_Button[1]->SetPosition(button1X, button1Y);
			}
			else if(BUTTON_3 == m_nButtonNum)
			{
				t_Button[0]->GetPosition(button1X, button1Y);
				t_Button[2]->GetPosition(button2X, button2Y);
				t_Button[0]->SetPosition(button2X, button2Y);
				t_Button[2]->SetPosition(button1X, button1Y);
				m_SetButtonTap();
			}
			else
			{
				// Nothing
			}
		}

		CActor::t_UpdateOrientation(orientation);
	}

	bool CMessageBox::OnFocusIn( IActor* pWindow )
	{
		m_ResetShowTime();
		if (pWindow == t_Button[0])
		{
			if (t_pMessageBoxListenerSet)
			{
				CMessageBoxListenerSet::TMessageBoxListenerData data;
				data.type = IMessageBoxListener::BUTTON_FOCUS_IN;
				data.param[0] = BUTTON_1;
				t_pMessageBoxListenerSet->Process(&data);
			}
		}
		else if (pWindow == t_Button[1])
		{
			if (t_pMessageBoxListenerSet)
			{
				CMessageBoxListenerSet::TMessageBoxListenerData data;
				data.type = IMessageBoxListener::BUTTON_FOCUS_IN;
				data.param[0] = BUTTON_2;
				t_pMessageBoxListenerSet->Process(&data);
			}
		}
		else if (pWindow == t_Button[2])
		{
			if (t_pMessageBoxListenerSet)
			{
				CMessageBoxListenerSet::TMessageBoxListenerData data;
				data.type = IMessageBoxListener::BUTTON_FOCUS_IN;
				data.param[0] = BUTTON_3;
				t_pMessageBoxListenerSet->Process(&data);
			}
		}
		else
		{
			// Nothing
		}
		return true;
	}
	
	bool CMessageBox::OnFocusOut( IActor* pWindow )
	{
		m_ResetShowTime();
		if (pWindow == t_Button[0])
		{
			if (t_pMessageBoxListenerSet)
			{
				CMessageBoxListenerSet::TMessageBoxListenerData data;
				data.type = IMessageBoxListener::BUTTON_FOCUS_OUT;
				data.param[0] = BUTTON_1;
				t_pMessageBoxListenerSet->Process(&data);
			}
		}
		else if (pWindow == t_Button[1])
		{
			if (t_pMessageBoxListenerSet)
			{
				CMessageBoxListenerSet::TMessageBoxListenerData data;
				data.type = IMessageBoxListener::BUTTON_FOCUS_OUT;
				data.param[0] = BUTTON_2;
				t_pMessageBoxListenerSet->Process(&data);
			}
		}
		else if (pWindow == t_Button[2])
		{
			if (t_pMessageBoxListenerSet)
			{
				CMessageBoxListenerSet::TMessageBoxListenerData data;
				data.type = IMessageBoxListener::BUTTON_FOCUS_OUT;
				data.param[0] = BUTTON_3;
				t_pMessageBoxListenerSet->Process(&data);
			}
		}
		else
		{
			// Nothing
		}
		return true;
	}
	
	bool CMessageBox::OnClicked(IActor* pWindow, IEvent* pClickEvent)
	{
		m_ResetShowTime();
		if (pWindow == t_Button[0])
		{
			if (t_pMessageBoxListenerSet)
			{
				CMessageBoxListenerSet::TMessageBoxListenerData data;
				data.type = IMessageBoxListener::BUTTON_CLICKED;
				data.param[0] = BUTTON_1;
				t_pMessageBoxListenerSet->Process(&data);
			}
		}
		else if (pWindow == t_Button[1])
		{
			if (t_pMessageBoxListenerSet)
			{
				CMessageBoxListenerSet::TMessageBoxListenerData data;
				data.type = IMessageBoxListener::BUTTON_CLICKED;
				data.param[0] = BUTTON_2;
				t_pMessageBoxListenerSet->Process(&data);
			}
		}
		else if (pWindow == t_Button[2])
		{
			if (t_pMessageBoxListenerSet)
			{
				CMessageBoxListenerSet::TMessageBoxListenerData data;
				data.type = IMessageBoxListener::BUTTON_CLICKED;
				data.param[0] = BUTTON_3;
				t_pMessageBoxListenerSet->Process(&data);
			}
		}
		else
		{
			// Nothing
		}
		return true;
	}
	
	bool CMessageBox::OnKeyReleased( IActor* pWindow, IKeyboardEvent* ptrKeyboardEvent )
	{
		m_ResetShowTime();
		int keyValue = ptrKeyboardEvent->GetKeyVal();
	
		switch (keyValue)
		{
		case KEY_ENTER:
			if (pWindow == t_Button[0])
			{
				if (t_pMessageBoxListenerSet)
				{
					CMessageBoxListenerSet::TMessageBoxListenerData data;
					data.type = IMessageBoxListener::BUTTON_CLICKED;
					data.param[0] = BUTTON_1;
					t_pMessageBoxListenerSet->Process(&data);
				}
			}
			else if (pWindow == t_Button[1])
			{
				if (t_pMessageBoxListenerSet)
				{
					CMessageBoxListenerSet::TMessageBoxListenerData data;
					data.type = IMessageBoxListener::BUTTON_CLICKED;
					data.param[0] = BUTTON_2;
					t_pMessageBoxListenerSet->Process(&data);
				}
			}
			else if (pWindow == t_Button[2])
			{
				if (t_pMessageBoxListenerSet)
				{
					CMessageBoxListenerSet::TMessageBoxListenerData data;
					data.type = IMessageBoxListener::BUTTON_CLICKED;
					data.param[0] = BUTTON_3;
					t_pMessageBoxListenerSet->Process(&data);
				}
			}
			else
			{
				// Nothing
			}
			break;
		default: 
			break;
		}

		return true;
	}
	
	bool CMessageBox::OnMouseMoved( IActor* pWindow, IMouseEvent* ptrMouseEvent )
	{
		m_ResetShowTime();
		return true;
	}

	bool CMessageBox::OnMousePointerIn( IActor* pWindow, IMouseEvent* ptrMouseEvent )
	{
		m_ResetShowTime();
		return true;
	}

	bool CMessageBox::OnMousePointerOut( IActor* pWindow, IMouseEvent* ptrMouseEvent )
	{
		m_ResetShowTime();
		return true;
	}

	void CMessageBox::m_ResetShowTime()
	{
		if (m_showTimerId > 0)
		{
			g_source_remove(m_showTimerId);
			m_showTimerId = 0;
			if(m_showTime > 0)
			{
				m_showTimerId = g_timeout_add(m_showTime, (GSourceFunc)m_ShowTimeFinishedCB, this);
			}
		}
	}

	void CMessageBox::m_Initialize()
	{
		t_parentHeight = 0;
		t_parentWidth = 0;
		t_nMessageContentType = 0;
		t_bAutoArrange = true;		
		for(int i = 0; i < BUTTON_ALL-1; i++)
		{
			t_Button[i] = NULL;
			m_actions[i] = NULL;
		}
		m_parentAction = NULL;
		t_Loading = NULL;
		t_orientation = ORIENTATION_LEFT_TO_RIGHT;
		t_pMessageBoxListenerSet = NULL;		
		m_nButtonNum = 0;
		m_bTitle = false;
		m_titleText = NULL;
		m_titleLine = NULL;
		m_contentText = NULL;
		m_contentText2 = NULL;
		m_parentHeightRate = 1.0;
		m_contentPosYRate = 1.0;
		m_content2PosYRate = 1.0;
		m_buttonPosYRate = 1.0;
		m_loadingPosYRate = 0.0;
		m_bSupportTTS = false;
		m_showTimerId = 0;
		m_showTime = 0;
	}

	void CMessageBox::m_CreateContent()
	{
		ClutterColor c = {255,255,255,255};

		m_contentText = IText::CreateInstance(dynamic_cast<Widget*>(this), (float)(t_parentWidth * TEXT_WIDTH_RATE), (float)(t_parentHeight * CONTEXT_HEIGHT_RATE));
		m_contentText->EnableMultiLine(false);
		m_contentText->SetTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
		m_contentText->EnableEllipsize(true);
		if(SINGLE_LINE_CONTENT != t_nMessageContentType && SINGLE_LINE_CONTENT_WITH_LOADING != t_nMessageContentType)
		{
			m_contentText->EnableMultiLine(true);
			m_contentText->SetTextAlignment(HALIGN_LEFT, VALIGN_MIDDLE);
		}
		m_contentText->SetTextColor(*clutter_color_init(&c, 255,255,255,255));

		if( MULTI_LINE_CONTENT_WITH_SINGLE_LINE_CONTENT == t_nMessageContentType)
		{
			m_contentText2 = IText::CreateInstance(dynamic_cast<Widget*>(this), (float)(t_parentWidth * TEXT_WIDTH_RATE), (float)(t_parentHeight * CONTEXT_HEIGHT_RATE));
		    m_contentText2->EnableMultiLine(false);
			m_contentText2->SetTextColor(*clutter_color_init(&c, 69,187,163,230));
			m_contentText2->SetTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
			m_contentText2->EnableEllipsize(true);
		}	
	}

	void CMessageBox::m_CreateTitle()
	{
		ClutterColor c = {255,255,255,255};
		m_titleText = IText::CreateInstance(dynamic_cast<Widget*>(this), (float)(t_parentWidth * TEXT_WIDTH_RATE), (float)(t_parentHeight * TITLE_TEXT_HEIGHT_RATE));
		m_titleText->EnableMultiLine(false);
		m_titleText->EnableEllipsize(true);
		m_titleText->SetTextColor(*clutter_color_init(&c, 255,255,255,255));
		m_titleText->SetTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
		m_titleLine = IActor::CreateInstance(dynamic_cast<Widget*>(this), (float)(t_parentWidth * TEXT_WIDTH_RATE), 1.0);
		m_titleLine->SetBackgroundColor(*clutter_color_init(&c, 255,255,255,255));
	}

	void CMessageBox::m_CreateButton()
	{
		ClutterColor c = {255, 255, 255, 255};
		for(uint i = 0; i < m_nButtonNum; i++)
		{
			t_Button[i] = IButton::CreateInstance(this, (float)(t_parentWidth * BUTTON_WIDTHRATE), (float)(t_parentHeight * BUTTON_HEIGHTRATE));
			IClickAction* action = IClickAction::CreateInstance(t_Button[i]);
			t_Button[i]->AddAction(action);
			m_actions[i] = action;
			t_Button[i]->AddClickListener(this);
			t_Button[i]->AddKeyboardListener(this);
			t_Button[i]->AddFocusListener(this);
			t_Button[i]->SetBackgroundColor(IButton::STATE_ALL, *clutter_color_init(&c, 0, 0, 0, 0));
			t_Button[i]->SetTextColor(IButton::STATE_ALL, *clutter_color_init(&c, 255, 255, 255, 255));
			t_AddNoticeActor(t_Button[i]);
		}
		m_SetButtonTap();
	}

	void CMessageBox::m_SetButtonTap()
	{
		if(ORIENTATION_LEFT_TO_RIGHT == Orientation(true))
		{
			for(uint i = 0; i < m_nButtonNum; i++)
			{
				if (i == 0) 	
				{			
					t_Button[i]->SetTabWindow(DIRECTION_LEFT, t_Button[m_nButtonNum - 1]);	
				}		
				else		
				{		
					t_Button[i]->SetTabWindow(DIRECTION_LEFT, t_Button[i-1]); 
				}		
				if (i == m_nButtonNum - 1) 	
				{			
					t_Button[i]->SetTabWindow(DIRECTION_RIGHT, t_Button[0]);		
				}		
				else	
				{			
					t_Button[i]->SetTabWindow(DIRECTION_RIGHT, t_Button[i + 1]);	
				}
			}
		}
		else
		{
			for(uint i = 0; i < m_nButtonNum; i++)
			{
				if (i == 0) 	
				{			
					t_Button[i]->SetTabWindow(DIRECTION_RIGHT, t_Button[m_nButtonNum - 1]);	
				}		
				else		
				{		
					t_Button[i]->SetTabWindow(DIRECTION_RIGHT, t_Button[i-1]); 
				}		
				if (i == m_nButtonNum - 1) 	
				{			
					t_Button[i]->SetTabWindow(DIRECTION_LEFT, t_Button[0]);		
				}		
				else	
				{			
					t_Button[i]->SetTabWindow(DIRECTION_LEFT, t_Button[i + 1]);	
				}
			}
		}
	}

	void CMessageBox::m_AutoArrangeRate(int nLineNum)
	{
		if(m_bTitle)
		{
			switch(t_nMessageContentType)
			{
			case SINGLE_LINE_CONTENT:
			{
				if(NO_BUTTON != m_nButtonNum)
				{
					m_parentHeightRate = (float)0.350926;
					m_contentPosYRate = (float)0.152778;
					m_buttonPosYRate = (float)(m_contentPosYRate + CONTEXT_HEIGHT_RATE + 0.064815);
				}
				else
				{
					m_parentHeightRate = (float)0.238889;
					m_contentPosYRate = (float)(TITLE_TEXT_HEIGHT_RATE + SINGLE_LINE_TITLE_CONTEXT_GAP);
				}
				break;
			}
			case MULTI_LINE_CONTENT:
			{
				if(NO_BUTTON != m_nButtonNum)
				{
					m_parentHeightRate = (float)(0.225 + CONTEXT_HEIGHT_RATE * nLineNum);
					m_contentPosYRate = (float)0.115741;
					m_buttonPosYRate = (float)(m_contentPosYRate + CONTEXT_HEIGHT_RATE * nLineNum + MULTI_LINE_BUTTON_GAP_RATE);
				}
				else
				{
					m_parentHeightRate = (float)(0.136111 + CONTEXT_HEIGHT_RATE * nLineNum);
					m_contentPosYRate = (float)(TITLE_TEXT_HEIGHT_RATE + MULTI_LINE_BUTTON_GAP_RATE);;
				}
				break;
			}
			case MULTI_LINE_CONTENT_WITH_SINGLE_LINE_CONTENT:
			{
				if(NO_BUTTON != m_nButtonNum)
				{
					m_parentHeightRate = (float)(0.225 + CONTEXT_HEIGHT_RATE * (nLineNum + 1));
					m_contentPosYRate = (float)0.115741;
				}
				else
				{
					m_parentHeightRate = (float)(0.171297 + CONTEXT_HEIGHT_RATE * (nLineNum + 1));
					m_contentPosYRate = (float)(TITLE_TEXT_HEIGHT_RATE + MULTI_LINE_BUTTON_GAP_RATE);
				}
				m_content2PosYRate = (float)(m_contentPosYRate + CONTEXT_HEIGHT_RATE * nLineNum + 0.029630);
				m_buttonPosYRate = (float)(m_content2PosYRate + CONTEXT_HEIGHT_RATE + SINGLE_LINE_TITLE_CONTEXT_NO_TITLE_Y);
				break;
			}
			default:
				break;
			}
		}
		else
		{
			switch(t_nMessageContentType)
			{
			case SINGLE_LINE_CONTENT:
				{
					if(NO_BUTTON != m_nButtonNum)
					{
						m_parentHeightRate = (float)0.287037;
						m_contentPosYRate = (float)TITLE_TEXT_HEIGHT_RATE;
						m_buttonPosYRate = (float)(m_contentPosYRate + CONTEXT_HEIGHT_RATE +0.064815);
					}
					else
					{
						m_parentHeightRate = (float)(0.087037 + CONTEXT_HEIGHT_RATE);
						m_contentPosYRate = (float)CONTEXT_HEIGHT_RATE;
					}
					break;
				}
			case MULTI_LINE_CONTENT:
				{
					if(NO_BUTTON != m_nButtonNum)
					{
						m_parentHeightRate = (float)(0.153703 + CONTEXT_HEIGHT_RATE * nLineNum);
					}
					else
					{
						m_parentHeightRate = (float)(0.087037 + CONTEXT_HEIGHT_RATE * nLineNum);
					}
					m_contentPosYRate = (float)CONTEXT_HEIGHT_RATE;
					m_buttonPosYRate = (float)(m_contentPosYRate + CONTEXT_HEIGHT_RATE * nLineNum + MULTI_LINE_BUTTON_GAP_RATE);
					break;
				}
			case MULTI_LINE_CONTENT_WITH_SINGLE_LINE_CONTENT:
			{
				if(NO_BUTTON != m_nButtonNum)
				{
					m_parentHeightRate = (float)(0.205556 + CONTEXT_HEIGHT_RATE * (nLineNum + 1));
				}
				else
				{
					m_parentHeightRate = (float)(0.116667 + CONTEXT_HEIGHT_RATE * (nLineNum + 1));
				}
				m_contentPosYRate = (float)CONTEXT_HEIGHT_RATE;
				m_content2PosYRate = (float)(m_contentPosYRate + CONTEXT_HEIGHT_RATE * nLineNum + 0.029630);
				m_buttonPosYRate = (float)(m_content2PosYRate + CONTEXT_HEIGHT_RATE + SINGLE_LINE_TITLE_CONTEXT_NO_TITLE_Y);
				break;
			}	
			case SINGLE_LINE_CONTENT_WITH_LOADING:
			{
				m_parentHeightRate = (float)(0.046296 + 0.030208 + 0.033333 + CONTEXT_HEIGHT_RATE + SINGLE_LINE_TITLE_CONTEXT_NO_TITLE_Y);
				m_loadingPosYRate = (float)0.046296;
				m_contentPosYRate = (float)(0.046296 + 0.030208 + 0.033333);
				break;
			}
			case MULTI_LINE_CONTENT_WITH_LOADING:
			{
				m_parentHeightRate = (float)(0.048148 + 0.030208 + 0.031481 + CONTEXT_HEIGHT_RATE * nLineNum + CONTEXT_HEIGHT_RATE);
				m_loadingPosYRate = (float)0.048148;
				m_contentPosYRate = (float)(0.048148 + 0.030208 + 0.031481);
				break;
			}
			default:
				break;
			}
		}
	}
	
	void CMessageBox::m_AutoArrangeBGSize()
	{
		CActor::Resize(t_parentWidth, t_parentHeight * m_parentHeightRate);
		CActor::SetPosition(0.0, (float)((1.0 - m_parentHeightRate) * t_parentHeight / 2.0));
	}

	void CMessageBox::m_AutoArrangeTitle()
	{
		m_titleText->SetPosition((float)(t_parentWidth * (1.0 - TEXT_WIDTH_RATE) / 2.0), 0.0);
		m_titleLine->SetPosition((float)(t_parentWidth * (1.0 - TEXT_WIDTH_RATE) / 2.0), (float)(t_parentHeight * TITLE_TEXT_HEIGHT_RATE));
	}

	void CMessageBox::m_AutoArrangeContent(int nLineNum)
	{
		if(SINGLE_LINE_CONTENT == t_nMessageContentType || SINGLE_LINE_CONTENT_WITH_LOADING == t_nMessageContentType)
		{
			m_contentText->Resize((float)(t_parentWidth * TEXT_WIDTH_RATE), (float)(t_parentHeight * CONTEXT_HEIGHT_RATE));
		}
		else
		{
			m_contentText->Resize((float)(t_parentWidth * TEXT_WIDTH_RATE), (float)(t_parentHeight * CONTEXT_HEIGHT_RATE * nLineNum));
		}
		m_contentText->SetPosition((float)(t_parentWidth * (1.0 - TEXT_WIDTH_RATE) / 2.0), (float)(t_parentHeight * m_contentPosYRate));
	}

	void CMessageBox::m_AutoArrangeContent2()
	{
		m_contentText2->SetPosition((float)(t_parentWidth * (1.0 - TEXT_WIDTH_RATE) / 2.0), (float)(t_parentHeight * m_content2PosYRate));
	}

	void CMessageBox::m_AutoArrangeButton()
	{
		if(NO_BUTTON == m_nButtonNum)
		{
			return;
		}
		float buttonGapWidth = (float)(t_parentWidth * 0.146875);
		float firstPosX = (float)((t_parentWidth - buttonGapWidth * (float)m_nButtonNum) / 2.0);
		for(uint i = 0; i < m_nButtonNum; i++)
		{
			t_Button[i]->Resize((float)(t_parentWidth * BUTTON_WIDTHRATE), (float)(t_parentHeight * BUTTON_HEIGHTRATE));
			if(ORIENTATION_LEFT_TO_RIGHT == Orientation(true))
			{
				t_Button[i]->SetPosition((float)(firstPosX + (float)i * buttonGapWidth), (float)(t_parentHeight * m_buttonPosYRate));
			}
			else
			{
				t_Button[m_nButtonNum - 1 - i]->SetPosition((float)(firstPosX + (float)i * buttonGapWidth), (float)(t_parentHeight * m_buttonPosYRate));
			}
		}
	}

	void CMessageBox::m_AutoArrangeLoading()
	{
		float loadingPosX = (float)((t_parentWidth * (1.0 - 0.156771) ) / 2.0);
		t_Loading->SetPosition(loadingPosX, (float)(t_parentHeight * m_loadingPosYRate));
	}

	void CMessageBox::m_Destroy()
	{
		if(m_titleText)
		{
			m_titleText->Release();
		}

		if(m_titleLine)
		{
			m_titleLine->Release();
		}
		
		if(m_contentText)
		{
			m_contentText->Release();
		}

		if(m_contentText2)
		{
			m_contentText2->Release();
		}

		for(int i = 0; i < BUTTON_ALL-1; i++)
		{
			if(t_Button[i])
			{
				t_Button[i]->RemoveAction(m_actions[i]);
				m_actions[i]->Release();
				t_Button[i]->RemoveClickListener(this);
				t_Button[i]->RemoveKeyboardListener(this);
				t_Button[i]->RemoveFocusListener(this);
				t_Button[i]->Release();
			}
		}

		if(t_Loading)
		{
			t_Loading->Stop();
			t_Loading->Release();
		}

		if (m_showTimerId > 0)
		{
			g_source_remove(m_showTimerId);
			m_showTimerId = 0;
		}

		delete t_pMessageBoxListenerSet;

		RemoveAction(m_parentAction);
		m_parentAction->Release();
		RemoveClickListener(this);
		RemoveKeyboardListener(this);
		RemoveFocusListener(this);
		RemoveMouseListener(this);
	}
}
