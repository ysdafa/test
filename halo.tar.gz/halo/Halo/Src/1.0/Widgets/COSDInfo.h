#include "Halo.h"

#ifndef _COSDINFO_H_
#define _COSDINFO_H_

namespace HALO
{
	class COSDInfo
	{
	public:
		//Common
		static const ClutterColor BG_ALPHA_COLOR;
		static const ClutterColor TITLE_TEXT_COLOR;
		//DefaultWindow
		static const int ACTION_WINDOW_TITLE_W;
		static const float ACTION_WINDOW_TITLE_H;
		static const float ACTION_WINDOW_TITLE_X;
		static const float ACTION_WINDOW_TITLE_Y;
		static const int FULL_WINDOW_W;
		static const int FULL_WINDOW_H;
		static const int ACTION_WINDOW_SIZE_W;
		static const int ACTION_WINDOW_SIZE_H;

		static const int ACTION_WINDOW_TITLE_FONT_SIZE;
		static const float DEFAULTWND_SHADOW_BG_WIDTH;
		static const float DEFAULTWND_SHADOW_BG_HEIGHT;


		static const int MESSAGEBOX_BG_W;
		static const int MESSAGEBOX_BUTTON_6LINE_BG_H;
		static const float MESSAGEBOX_BUTTON_WIDTH;
		static const float MESSAGEBOX_BUTTON_HEIGHT;
		static const int MESSAGEBOX_BUTTON_GAP;
		static const float MESSAGEBOX_CONTENTS_X;
		static const int MESSAGEBOX_CONTENTS_TITLE_GAP;
		static const int MESSAGEBOX_CONTENTS_W;
		static const int MESSAGEBOX_CONTENTS_H;
		static const float MESSAGEBOX_CONTENT_NOTITLE_Y;

		static const int WARNING_WIDGET_X;
		static const int WARNING_WIDGET_Y;
		static const int WARNING_WIDGET_W;
		static const int WARNING_WIDGET_H;
		static const int WARNING_WIDGET_TEXT_W;
		static const int WARNING_WIDGET_TEXT_H;

		static const int PINNUMBERWIDGET_WND_X;
		static const int PINNUMBERWIDGET_WND_Y;
		static const int PINNUMBERWIDGET_WND_W;
		static const int PINNUMBERWIDGET_WND_H;
		static const int PINNUMBERWIDGET_PINBOX_W;
		static const int PINNUMBERWIDGET_PINBOX_H;
		static const int PINNUMBERWIDGET_PINBOX_GAP;
		static const float PINNUMBERWIDGET_PINBOX_X;
		static const float PINNUMBERWIDGET_PINBOX_Y;
		static const int PINNUMBERWIDGET_CANCELBUTTON_W;
		static const int PINNUMBERWIDGET_CANCELBUTTON_H;
		static const float PINNUMBERWIDGET_CANCELBUTTON_Y;
		static const float PINNUMBERWIDGET_CONTENTSTEXT_X;
		static const float PINNUMBERWIDGET_CONTENTSTEXT_Y;
		static const int PINNUMBERWIDGET_CONTENTSTEXT_H;
		static const int PINNUMBERWIDGET_CONTENTSTEXT_W;

		static const float SUBINPUTWIDGET_WITHCONTENT_W;
		static const float SUBINPUTWIDGET_WITHOUTCONTENT_W;
		static const float SUBINPUTWIDGET_H;
		static const float SUBINPUTWIDGET_ARROW_W;
		static const float SUBINPUTWIDGET_ARROW_H;
		static const float SUBINPUTWIDGET_ARROW_Y;
		static const float SUBINPUTWIDGET_LEFTARROW_X;
		static const float SUBINPUTWIDGET_LEFTTEXT_X;
		static const float SUBINPUTWIDGET_RIGHTTEXT_X;
		static const float SUBINPUTWIDGET_RIGHTARROW_X;
		static const float SUBINPUTWIDGET_ARROW_TEXT_W;
		static const float SUBINPUTWIDGET_LEFTTEXT_WITHCONTENT_X;
		static const float SUBINPUTWIDGET_RIGHTTEXT_WITHCONTENT_X;
		static const float SUBINPUTWIDGET_CONTENT_W;
		static const float SUBINPUTWIDGET_CONTENT_X;
	protected:
		static void t_InitResolution(bool bFlagReverseOsd, int nMultiplier, int nDivider);
	};
}


#endif