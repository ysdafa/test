#ifndef _CINPUTBOX_H_
#define _CINPUTBOX_H_

#ifndef WIN32
#define HAVE_ECORE_IMF
#endif

namespace HALO
{
	class CInputBox :virtual public IInputBox, public CActor, public IKeyboardListener, public IMouseListener, public IFocusListener, public IRichTextListener
	{
	public:
		CInputBox();
		virtual ~CInputBox();
		virtual bool Initialize(IActor* parent, float width, float height, const TInputBoxAttr &attr);
		virtual bool Initialize(Widget* parent, float width, float height, const TInputBoxAttr &attr);

		virtual void SetImage(const std::string& filepath);
		virtual void SetNormal_FocusImage(const std::string& file_normal, const std::string& file_focus);
		virtual void SetNormal_FocusTextColor(const ClutterColor color_normal, const ClutterColor color_focus);

		virtual void SetImage(T_INPUTBOX_STATE state, const std::string& filepath);
		virtual void SetTextColor(T_INPUTBOX_STATE state, const ClutterColor color);

		virtual void SetText(const std::string& text);
		virtual std::string Text() const;
		virtual void SetBGColor(const ClutterColor color);
		virtual void SetTextBGColor(const ClutterColor color);
		virtual void SetTextColor(const ClutterColor color);
		virtual void SetTextCursorColor(const ClutterColor color);
		virtual void SetTextSelectionColor(const ClutterColor color);
		virtual void SetTextHAlignment(EHAlignment hAlign);
		virtual EHAlignment TextHAlignment();
		virtual void SetFont(const std::string& font);
		virtual std::string Font() const;
		virtual void SetFontSize(int size);
		virtual int FontSize();
		virtual void SetTextMaxCount(int count);
		virtual int TextCount();

		virtual void InsertText(const std::string& text);

		virtual bool SetFocus();
		virtual bool KillFocus();
#ifdef HAVE_ECORE_IMF
		virtual void EnableIME(bool IsIMEEnabled);
#endif	
		virtual bool OnStateChanged(class IRichText* richtext, int keyval);

	private:
		ICompositeImage* m_objImage;
		IRichText* m_objText;

		float m_imageWidth;
		float m_imageHeight;
		float m_marginH;
		float m_marginV;

		EHAlignment m_hAlign;

		int m_focusState;
		struct T_INPUTBOX_STATE_ATTR
		{
			std::string m_imageName;
			ClutterColor m_textColor;
		};
		T_INPUTBOX_STATE_ATTR m_stateAttr[2];

	protected:
		EOrientation t_orientation;

	private:
		void m_initial();
		void m_createImage();
		void m_createText();

		void m_initialStateAttr();
		void m_updateStateAttr(bool updateImage, bool updateTextColor);

		virtual bool OnMouseButtonPressed(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnMouseButtonReleased(IActor* pWindow, IMouseEvent* ptrMouseEvent);

	protected:
		virtual void t_UpdateOrientation(EOrientation orientation);
	};
}
#endif
