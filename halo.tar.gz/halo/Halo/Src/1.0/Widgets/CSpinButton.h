#ifndef	_CISPINBUTTON_H_
#define	_CISPINBUTTON_H_
namespace HALO
{
	class CSpinButton:virtual public ISpinButton , public CDefaultWindow, public IKeyboardListener, public IMouseListener, public IFocusListener, public IClickListener, private ListenerSet
	{
		typedef CDefaultWindow ParentType;
	public:
		CSpinButton();
		virtual ~CSpinButton();

		virtual bool Initialize(IActor* parent, const TSpinButtonAttr &attr);

		virtual void Show();

		virtual void Hide();

		virtual bool AddListener(ISpinButtonListener* listener);

		virtual bool RemoveListener(ISpinButtonListener* listener);

		virtual void SetLeftRightText(const char* leftText, const char* rightText);

		//virtual void SetInputData();

		//virtual void SetDefaultValue(int value);
	protected:
		virtual bool OnClicked(IWidgetExtension* pWindow, IClickEvent* pClickEvent);

		virtual bool OnMouseButtonPressed(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);

		virtual bool OnKeyPressed(IWidgetExtension* pThis, IKeyboardEvent* event);

		virtual bool t_Initialize(const char* leftText, const char* rightText );

		bool t_ProcessArrowEvent(IActor* pThis);

		void t_subUpadte();

		void t_addUpdate();
		bool t_bContentText;
	private:
		IButton *m_LeftArrow;
		IButton *m_RightArrow;
		IText *m_LeftText;
		IText *m_RightText;
		IText *m_ContentText;
		IImageBuffer *m_LeftNormalArrow;
		IImageBuffer *m_RightNormalArrow;
		IImageBuffer *m_LeftFocusedArrow;
		IImageBuffer *m_RightFocusedArrow;
		void m_CreateArrows();
		void m_CreateText();
		void m_Destroy();
	};
}
#endif