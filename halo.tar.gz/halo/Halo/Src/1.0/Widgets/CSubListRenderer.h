#ifndef _CSUBLISTRENDERER_H_
#define _CSUBLISTRENDERER_H_

namespace HALO
{
	class CSubListRenderer : public IRenderer
	{
	public:
		CSubListRenderer(IActor* parent) 
		{
			float w, h;
			parent->GetSize(w, h);
			
			for(uint i = 0; i < 2; i++)
			{
				t_iconImage[i] = IImage::CreateInstance(parent, w, h);
				t_itemText[i] = IText::CreateInstance(parent, w, h);
				t_itemText[i]->EnableEllipsize(true);
			}
			t_iconImage[0]->Hide();
			t_itemData = NULL;
		}

		~CSubListRenderer()
		{	
			for(uint i = 0; i < 2; i++)
			{
				t_iconImage[i]->Release();
				t_itemText[i]->Release();
			}
			t_itemData = NULL;
		}

		virtual void Draw(IData *data, IActor* parent, E_DRAW_TYPE drawType);
		virtual void Update(IData *data, IActor* parent) {};
		virtual void Resize(IData *data, IActor* parent, ClutterSize destSize, bool flagAni, int animationDuration)
		{

		}
		void GetParentPosition(float &X, float &Y);
		void ImageShow();
		void ImageHide();
		void SetDim(bool bIfDim);
		bool Dim(void);
		std::string Text();
		std::string Text2();

	protected:
		CSublistItem* t_itemData;
		IImage *t_iconImage[2];
		IText *t_itemText[2];

	private:
		void m_UpdateItem(IActor* parent);
	};
}
#endif
