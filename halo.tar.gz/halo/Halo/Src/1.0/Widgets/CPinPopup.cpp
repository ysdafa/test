#include "Halo.h"
#include "Halo1_0.h"

#define PINTITLE_PINNUMBER_GAP_RATE 0.0141815
#define TITLE_CONTENTTEXT_GAP_RATE 0.010185
#define PINNUMBER_WIDTH_RATE 0.181771
#define PINNUMBER_HEIGHT_RATE 0.053704
#define PINNUMBER_GAP_RATE 0.025926
#define PIN_TITLE_WIDTH_RATE_WITHCONTENT  0.584375
#define PIN_TITLE_WIDTH_RATE_WITHOUTCONTENT  0.407292
#define PIN_TITLE_HEIGHT_RATE 0.088889
#define PIN_TITLE_HEIGHT_RATE_WITHOUTCONTENT 0.089815
#define PIN_CONTENTTEXT_WIDTH_RATE 0.584375
#define PIN_CONTENTTEXT_HEIGHT_RATE 0.044444
#define PIN_HEIGHT_RATE_WITHCONTENT 0.500000
#define PIN_HEIGHT_RATE_WITHOUTCONTENT 0.491667
#define TITLE_PIN1TEXT_GAP_RATE 0.029630
#define PIN1TEXT_PIN1_GAP_RATE 0.017593
#define PIN1_PIN2TEXT_GAP_RATE 0.018519
#define PIN2_PIN2TEXT_GAP_RATE 0.016667
#define PINTEXT1_PINBOX1_GAP_RATE 0.021296
#define PINBOX_H_WITHOUTCONTENT  0.053704
#define PINBOX1_PINTEXT2_GAP_RATE 0.013889
#define BUTTON_WIDTH_RATE 0.140625
#define BUTTON_HEIGHT_RATE 0.061111
#define BUTTON_DOWN_GAP 0.027778
#define BUTTON_PINBOX_GAP 0.034259

namespace HALO
{
	class CPinPopupListenerSet : public ListenerSet
	{
	public:
		struct TPinPopupListenerData
		{
			int type;
			int param[2];
			const char* paramstr1;
			const char* paramstr2;
			void* pData;
		};

		CPinPopupListenerSet(CPinPopup* owner) :m_owner(owner){}
		virtual ~CPinPopupListenerSet(void){}

		virtual bool Process(TPinPopupListenerData* data);

	private:
		CPinPopup* m_owner;
	};

	bool CPinPopupListenerSet::Process(TPinPopupListenerData* data)
	{
		bool ret = false;
		Lock();

		if (NULL != data)
		{
			ListenerList::iterator iter = m_list.begin();

			while (iter != m_list.end())
			{
				IPinPopupListener* listener = (IPinPopupListener*)(*iter);

				switch (data->param[0])
				{
				case IPinPopup::BUTTON_1:
					ret |= listener->OnButtonEvent(m_owner, data->param[0], data->type);
					break;
				case IPinPopup::BUTTON_2:
					ret |= listener->OnButtonEvent(m_owner, data->param[0], data->type);
					break;
				case IPinPopup::E_PINNUMBER_ONE:
					ret |= listener->OnValidConfirm(m_owner , data->type);
					break;
				case IPinPopup::E_PINNUMBER_ALL:
					ret |= listener->OnCompareConfirm(m_owner , data->type ,  data->paramstr1 , data->paramstr2);
					break;
				default:
					break;
				}

				if (m_list.empty())
				{
					break;
				}
				iter++;
			}
		}
		Unlock();
		return ret;
	}
	CPinPopup::CPinPopup()
	{
		t_pPinPopupListenerSet = NULL;
		m_button1 = NULL;
		m_button2 = NULL;
		m_ConTentText = NULL;
		m_pinNumber1 = NULL;
		m_pinNumber2 = NULL;
		m_pinText1 = NULL;
		m_pinText2 = NULL;
	}

	CPinPopup::~CPinPopup()
	{
		m_Destroy();
	}

	bool CPinPopup::Initialize( IActor* parent, const TPinPopupAttr &attr )
	{
		TActionPopupAttr actionPopupAttr;
		actionPopupAttr.x = attr.x;
		actionPopupAttr.y = attr.y;
		actionPopupAttr.w = attr.w;
		actionPopupAttr.h = attr.h;
		actionPopupAttr.nAnimationType = attr.nAnimationType;
		actionPopupAttr.nBackGroundType = attr.nBackGroundType;
		m_pinType = attr.pinType;
		m_IsContent = attr.isContent;
		m_buttonNum = attr.buttonNum;
		m_autoArrange = attr.isAutoArrange;
		if (CActionPopup::Initialize(parent , actionPopupAttr) == false)
		{
			return false;
		}
		m_Initialize();
		return true;
	}

	bool CPinPopup::Initialize( Widget* parent, const TPinPopupAttr &attr )
	{
		TActionPopupAttr actionPopupAttr;
		actionPopupAttr.x = attr.x;
		actionPopupAttr.y = attr.y;
		actionPopupAttr.w = attr.w;
		actionPopupAttr.h = attr.h;
		actionPopupAttr.nAnimationType = attr.nAnimationType;
		actionPopupAttr.nBackGroundType = attr.nBackGroundType;
		m_pinType = attr.pinType;
		m_IsContent = attr.isContent;
		m_buttonNum = attr.buttonNum;
		m_autoArrange = attr.isAutoArrange;
		if (CActionPopup::Initialize(parent , actionPopupAttr) == false)
		{
			return false;
		}
		m_Initialize();
		return true;
	}

	void CPinPopup::SetPinBoxDescriptionTextFontSize( E_PINNUMBER_TYPE pinType , int fontSize )
	{
		ASSERT(pinType <= E_PINNUMBER_ALL);
		if (pinType == E_PINNUMBER_ALL)
		{
			m_pinText1->SetFontSize(fontSize);
			m_pinText2->SetFontSize(fontSize);
		}
		else if (pinType == E_PINNUMBER_ONE)
		{
			m_pinText1->SetFontSize(fontSize);
		}
		else if (pinType == E_PINNUMBER_TWO)
		{
			m_pinText2->SetFontSize(fontSize);
		}
	}

	void CPinPopup::SetPinBoxDescriptionTextColor( E_PINNUMBER_TYPE pinType , const ClutterColor textcolor )
	{
		ASSERT(pinType <= E_PINNUMBER_ALL);
		if (pinType == E_PINNUMBER_ALL)
		{
			m_pinText1->SetTextColor(textcolor);
			m_pinText2->SetTextColor(textcolor);
		}
		else if (pinType == E_PINNUMBER_ONE)
		{
			m_pinText1->SetTextColor(textcolor);
		}
		else if (pinType == E_PINNUMBER_TWO)
		{
			m_pinText2->SetTextColor(textcolor);
		}
	}

	void CPinPopup::SetPinBoxDescriptionText( E_PINNUMBER_TYPE pinType , const char* pinTitle )
	{
		ASSERT(pinType <= E_PINNUMBER_ALL && NULL != pinTitle);
		if (pinType == E_PINNUMBER_ALL)
		{
			m_pinText1->SetText(pinTitle);
			m_pinText2->SetText(pinTitle);
		}
		else if (pinType == E_PINNUMBER_ONE)
		{
			m_pinText1->SetText(pinTitle);
		}
		else if (pinType == E_PINNUMBER_TWO)
		{
			m_pinText2->SetText(pinTitle);
		}
	}

	void CPinPopup::m_Update()
	{
		m_pinXpos = (t_Width - (float)t_Width *(PINNUMBER_WIDTH_RATE )) /2;
		if (m_IsContent)
		{
			m_pin1Ypos = m_ContentYpos + (float)t_Height *(PIN_CONTENTTEXT_HEIGHT_RATE + PIN_CONTENTTEXT_HEIGHT_RATE + PINTITLE_PINNUMBER_GAP_RATE +PIN_CONTENTTEXT_HEIGHT_RATE);
			m_pin2Ypos = m_pin1Ypos + (float)t_Height * (PINNUMBER_HEIGHT_RATE + PINNUMBER_GAP_RATE + PIN_CONTENTTEXT_HEIGHT_RATE + PINTITLE_PINNUMBER_GAP_RATE);
		}
		else
		{
			m_pin1Ypos = (float)t_Height *(TITLE_PIN1TEXT_GAP_RATE + PIN1TEXT_PIN1_GAP_RATE + PIN_TITLE_HEIGHT_RATE + PIN_CONTENTTEXT_HEIGHT_RATE);
			m_pin2Ypos =  m_pin1Ypos + (float)t_Height *(PINNUMBER_HEIGHT_RATE + PIN1_PIN2TEXT_GAP_RATE + PIN_CONTENTTEXT_HEIGHT_RATE + PIN2_PIN2TEXT_GAP_RATE);
		}
	}

	void CPinPopup::SetPinBoxItemImage( EInputItemsState inputboxState , const std::string& iconPath )
	{
		if (m_pinType == E_PINNUMBER_ONE)
		{
			if (inputboxState == IPinPopup::E_STATE_NOINPUT)
			{
				m_pinNumber1->SetInputItemImage(CPinBox::E_STATE_NOINPUT , iconPath);
			}
			else if (inputboxState == E_STATE_FINISHINPUT)
			{
				m_pinNumber1->SetInputItemImage(CPinBox::E_STATE_FINISHINPUT , iconPath);
			}
		}
		else 
		{
			if (inputboxState == E_STATE_NOINPUT)
			{
				m_pinNumber1->SetInputItemImage(CPinBox::E_STATE_NOINPUT , iconPath);
				m_pinNumber2->SetInputItemImage(CPinBox::E_STATE_NOINPUT , iconPath);
			}
			else if (inputboxState == E_STATE_FINISHINPUT)
			{
				m_pinNumber1->SetInputItemImage(CPinBox::E_STATE_FINISHINPUT , iconPath);
				m_pinNumber2->SetInputItemImage(CPinBox::E_STATE_FINISHINPUT , iconPath);
			}
		
			
		}
	}

	void CPinPopup::SetPinBoxBackGroundImage( EInputBoxState pinstate , const std::string& iconPath )
	{
		if (m_pinType == E_PINNUMBER_ONE)
		{
			if (pinstate == IPinPopup::E_STATE_NORMAL)
			{
				m_pinNumber1->SetInputBoxBackGroundImage(CBaseInputBox::E_STATE_NORMAL , iconPath);
			}
			else if (pinstate == IPinPopup::E_STATE_FOCUSED)
			{
				m_pinNumber1->SetInputBoxBackGroundImage(CBaseInputBox::E_STATE_FOCUSED , iconPath);
				//m_pinNumber1->SetFocus();
			}
		}
		else 
		{
			if (pinstate == IPinPopup::E_STATE_NORMAL)
			{
				m_pinNumber1->SetInputBoxBackGroundImage(CBaseInputBox::E_STATE_NORMAL , iconPath);
				m_pinNumber2->SetInputBoxBackGroundImage(CBaseInputBox::E_STATE_NORMAL , iconPath);
			}
			else if (pinstate == IPinPopup::E_STATE_FOCUSED)
			{
				m_pinNumber1->SetInputBoxBackGroundImage(CBaseInputBox::E_STATE_FOCUSED , iconPath);
				m_pinNumber2->SetInputBoxBackGroundImage(CBaseInputBox::E_STATE_FOCUSED , iconPath);
				//m_pinNumber1->SetFocus();
			}
		}
	}

	void CPinPopup::m_CreatePinBox()
	{
		if (m_pinType == E_PINNUMBER_ONE)
		{
			m_pinNumber1 = new CPinBox;
			if (m_IsContent)
			{
				m_pinNumber1->Initialize(dynamic_cast<Widget*>(this) , (float)t_Width * PINNUMBER_WIDTH_RATE, (float)t_Height * PINNUMBER_HEIGHT_RATE , true);
			}
			else
			{
				m_pinNumber1->Initialize(dynamic_cast<Widget*>(this) , (float)t_Width * PINNUMBER_WIDTH_RATE, (float)t_Height * PINBOX_H_WITHOUTCONTENT , true);
			}
			if (m_autoArrange)
			{
				m_pinNumber1->SetPosition(m_pinXpos , m_pin1Ypos);
				m_pinNumber1->SetDigitTextSize(1920 * 0.015625 , 1080 * 0.037037);
				m_pinNumber1->SetInputItemSize(CPinBox::E_STATE_ALL ,9,9);
			}
			m_pinNumber1->EnableReverse(false);
			m_pinNumber1->SetOrientation(ORIENTATION_LEFT_TO_RIGHT);
			m_pinNumber1->SetDigitTextSize(1920 * 0.015625 , 1080 * 0.037037);
			m_pinNumber1->SetInputItemSize(CPinBox::E_STATE_ALL ,9,9);
			m_pinNumber1->AddListener(this);
			t_AddNoticeActor(m_pinNumber1);
		}
		else
		{
			m_pinNumber1 = new CPinBox;
			m_pinNumber2 = new CPinBox;
			if (m_IsContent)
			{
				m_pinNumber1->Initialize(dynamic_cast<Widget*>(this) , (float)t_Width * PINNUMBER_WIDTH_RATE, (float)t_Height * PINNUMBER_HEIGHT_RATE , false);
				m_pinNumber2->Initialize(dynamic_cast<Widget*>(this) , (float)t_Width * PINNUMBER_WIDTH_RATE, (float)t_Height * PINNUMBER_HEIGHT_RATE , false);
			}
			else
			{
				m_pinNumber1->Initialize(dynamic_cast<Widget*>(this) , (float)t_Width * PINNUMBER_WIDTH_RATE, (float)t_Height * PINBOX_H_WITHOUTCONTENT , false);
				m_pinNumber2->Initialize(dynamic_cast<Widget*>(this) , (float)t_Width * PINNUMBER_WIDTH_RATE, (float)t_Height * PINBOX_H_WITHOUTCONTENT , false);
			}
			if (m_autoArrange)
			{
				m_pinNumber1->SetPosition(m_pinXpos , m_pin1Ypos);
				m_pinNumber1->SetDigitTextSize(t_Width , t_Height);
				m_pinNumber2->SetPosition(m_pinXpos , m_pin2Ypos);
				m_pinNumber2->SetDigitTextSize(t_Width , t_Height);
				m_pinNumber2->SetInputItemSize(CPinBox::E_STATE_ALL ,9,9);
				m_pinNumber1->SetInputItemSize(CPinBox::E_STATE_ALL ,9,9);
			}
			m_pinNumber2->AddListener(this);
			m_pinNumber1->AddListener(this);
			m_pinNumber1->EnableReverse(false);
			m_pinNumber2->EnableReverse(false);
			m_pinNumber1->SetOrientation(ORIENTATION_LEFT_TO_RIGHT);
			m_pinNumber2->SetOrientation(ORIENTATION_LEFT_TO_RIGHT);
			t_AddNoticeActor(m_pinNumber1);
			t_AddNoticeActor(m_pinNumber2);
		}
	}

	void CPinPopup::SetContentText( const std::string& text )
	{
		m_ConTentText->SetText(text.c_str());
	}

	void CPinPopup::OnValidConfirm( class CPinBox* list , bool isPassWordRight )
	{
		if (t_pPinPopupListenerSet)
		{
			CPinPopupListenerSet::TPinPopupListenerData data;
			data.type = isPassWordRight;
			data.param[0] = E_PINNUMBER_ONE;
			t_pPinPopupListenerSet->Process(&data);
		}
	}

	void CPinPopup::OutputPassWord( class CPinBox* list , std::string inputPassWord )
	{
		if (list == m_pinNumber1)
		{
			m_pwd1Str = inputPassWord.c_str();
			if (NULL != m_pinNumber2 )
			{
				m_pinNumber2->SetFocus();
			}
		}
		else
		{
			m_pwd2Str = inputPassWord.c_str();
			if (NULL != m_button1)
			{
				m_button1->SetFocus();
			}
			if (t_pPinPopupListenerSet)
			{
				if (m_pwd1Str == m_pwd2Str)
				{
					CPinPopupListenerSet::TPinPopupListenerData data;
					data.type = true;
					data.param[0] = E_PINNUMBER_ALL;
					data.paramstr1 = m_pwd1Str.c_str();
					data.paramstr2 = m_pwd2Str.c_str();
					t_pPinPopupListenerSet->Process(&data);
				}
				else
				{
					CPinPopupListenerSet::TPinPopupListenerData data;
					data.type = false;
					data.param[0] = E_PINNUMBER_ALL;
					data.paramstr1 = m_pwd1Str.c_str();
					data.paramstr2 = m_pwd2Str.c_str();
					t_pPinPopupListenerSet->Process(&data);
				}
			}
		}
		
	}

	bool CPinPopup::AddListener( class IPinPopupListener* listener )
	{
		ASSERT(listener != NULL);

		return t_pPinPopupListenerSet->Add(listener);
	}

	bool CPinPopup::RemoveListener(class IPinPopupListener* listener)
	{
		ASSERT(listener != NULL);

		return t_pPinPopupListenerSet->Remove(listener);
	}

	void CPinPopup::m_Initialize()
	{
		ClutterColor BgColor = {255,255,255,225};
		if (m_autoArrange)
		{
			if (m_IsContent)
			{
				this->Resize(t_Width ,t_Height * PIN_HEIGHT_RATE_WITHCONTENT);
				this->SetPosition(0 ,(float)((1.0 - PIN_HEIGHT_RATE_WITHCONTENT) * t_Height / 2.0));
			}
			else
			{
				this->Resize(t_Width ,t_Height * PIN_HEIGHT_RATE_WITHOUTCONTENT);
				this->SetPosition(0 ,(float)((1.0 - PIN_HEIGHT_RATE_WITHOUTCONTENT) * t_Height / 2.0));
			}
		}	
		m_AutoArrangeTitle();
		if (m_IsContent)
		{
			m_ConTentText = IText::CreateInstance(dynamic_cast<Widget*>(this) , (float)t_Width * PIN_CONTENTTEXT_WIDTH_RATE , (float)t_Height * PIN_CONTENTTEXT_HEIGHT_RATE);
			m_ContentYpos = (float)t_Height * PIN_TITLE_HEIGHT_RATE + (float)t_Height * TITLE_CONTENTTEXT_GAP_RATE;
			m_ConTentText->SetPosition(m_TitleXPos , m_ContentYpos);
			m_ConTentText->SetTextAlignment(HALIGN_CENTER , VALIGN_MIDDLE);
			m_ConTentText->SetFontSize(34);
			m_ConTentText->SetTextColor(BgColor);
		}
		m_Update();
		m_AutoArrangePinBoxDescription();
		m_CreatePinBox();
		if ( m_buttonNum > 0)
		{
			m_CreateButton();
		}
		t_pPinPopupListenerSet = new class CPinPopupListenerSet(this);
		m_SetWindowTab();
		AddKeyboardListener(this);
	}

	void CPinPopup::ResetPassWord( E_PINNUMBER_TYPE pinType )
	{
		if (pinType == E_PINNUMBER_ONE)
		{
			m_pinNumber1->ResetPassword();
		}
		else if (pinType == E_PINNUMBER_TWO)
		{
			m_pinNumber2->ResetPassword();
		}
		else if (pinType == E_PINNUMBER_ALL)
		{
			m_pinNumber1->ResetPassword();
			m_pinNumber2->ResetPassword();
		}
	}

	void CPinPopup::SetContentTextFont( const std::string& font )
	{
		m_ConTentText->SetFont(font.c_str());
	}

	void CPinPopup::SetContentTextFontSize( int fontSize )
	{
		m_ConTentText->SetFontSize(fontSize);
	}

	void CPinPopup::SetContentTextFontColor( const ClutterColor textcolor )
	{
		m_ConTentText->SetTextColor(textcolor);
	}

	void CPinPopup::m_Destroy()
	{
		if ( NULL != m_ConTentText)
		{
			m_ConTentText->Release();
		}
		if (NULL != m_pinNumber1)
		{
			m_pinNumber1->RemoveKeyboardListener(this);
			m_pinNumber1->Release();
		}
		if (NULL != m_pinNumber2)
		{
			m_pinNumber2->RemoveKeyboardListener(this);
			m_pinNumber2->Release();
		}
		if (NULL != m_pinText1)
		{
			m_pinText1->Release();
		}
		if (NULL != m_pinText2)
		{
			m_pinText2->Release();
		}
		if (m_buttonNum != 0)
		{
			m_button1->RemoveAction(m_action1);
			m_action1->Release();
			m_button1->RemoveKeyboardListener(this);
			m_button1->RemoveMouseListener(this);
			m_button1->RemoveClickListener(this);
			m_button1->Release();
			if (m_buttonNum == 2)
			{
				m_button2->RemoveAction(m_action2);
				m_action2->Release();
				m_button2->RemoveKeyboardListener(this);
				m_button2->RemoveMouseListener(this);
				m_button2->RemoveClickListener(this);
				m_button2->Release();
			}		
		}
		if (NULL != t_pPinPopupListenerSet)
		{
			//delete t_pPinPopupListenerSet;
			if (t_pPinPopupListenerSet->IsLocked())
			{
				t_pPinPopupListenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(t_pPinPopupListenerSet);
			} 
			else
			{
				delete t_pPinPopupListenerSet;
			}

			t_pPinPopupListenerSet = NULL;
		}
		
	}

	void CPinPopup::SetPinBoxDescriptionRect( E_PINNUMBER_TYPE pinType , float xPos , float yPos ,float width , float height )
	{
		ASSERT(pinType <= E_PINNUMBER_ALL);
		if (pinType == E_PINNUMBER_ALL)
		{
			m_pinText1->SetPosition(xPos , yPos);
			m_pinText2->SetPosition(xPos , yPos);
			m_pinText1->Resize(width , height);
			m_pinText2->Resize(width , height);
		}
		else if (pinType == E_PINNUMBER_ONE)
		{
			m_pinText1->SetPosition(xPos , yPos);
			m_pinText1->Resize(width , height);
		}
		else if (pinType == E_PINNUMBER_TWO)
		{
			m_pinText2->SetPosition(xPos , yPos);
			m_pinText2->Resize(width , height);
		}
	}

	void CPinPopup::SetContentRect( float xPos , float yPos ,float width , float height )
	{
		if (m_IsContent)
		{
			m_ConTentText->SetPosition(xPos , yPos);
			m_ConTentText->Resize(width , height);
		}
	}

	void CPinPopup::m_AutoArrangeTitle()
	{
		ClutterColor BgColor = {255,255,255,225};
		t_Title->SetFontSize(50);
		if (m_IsContent)
		{
			m_TitleXPos =( float)(t_Width * (1.0 - PIN_TITLE_WIDTH_RATE_WITHCONTENT) / 2.0);
			m_titleLine->Resize((float)(t_Width* PIN_TITLE_WIDTH_RATE_WITHCONTENT) , 1);
			t_Title->Resize((float)t_Width * PIN_TITLE_WIDTH_RATE_WITHCONTENT, (float)t_Height * PIN_TITLE_HEIGHT_RATE);
			t_Title->SetPosition((t_Width - (float)t_Width * PIN_TITLE_WIDTH_RATE_WITHCONTENT) / 2 , 0);
		}
		else
		{
			m_TitleXPos =( float)(t_Width * (1.0 - PIN_TITLE_WIDTH_RATE_WITHOUTCONTENT) / 2.0);
			m_titleLine->Resize((float)(t_Width* PIN_TITLE_WIDTH_RATE_WITHOUTCONTENT) , 1);
			t_Title->Resize((float)t_Width * PIN_TITLE_WIDTH_RATE_WITHOUTCONTENT, (float)t_Height * PIN_TITLE_HEIGHT_RATE);
			t_Title->SetPosition((t_Width - (float)t_Width * PIN_TITLE_WIDTH_RATE_WITHOUTCONTENT) / 2 , 0);
		}
		m_titleLine->SetPosition(m_TitleXPos , (float)(t_Height * PIN_TITLE_HEIGHT_RATE));
		m_titleLine->SetBackgroundColor(BgColor);
		SetTitleTextFontSize(44);
		SetTitleTextColor(BgColor);
	}

	void CPinPopup::m_AutoArrangePinBox()
	{
		m_pinXpos = (t_Width - (float)t_Width *(PINNUMBER_WIDTH_RATE )) /2;
		if (m_IsContent)
		{
			m_pin1Ypos = m_ContentYpos + (float)t_Height *(PIN_CONTENTTEXT_HEIGHT_RATE + PIN_CONTENTTEXT_HEIGHT_RATE + PINTITLE_PINNUMBER_GAP_RATE +PIN_CONTENTTEXT_HEIGHT_RATE);
			m_pin2Ypos = m_pin1Ypos + (float)t_Height * (PINNUMBER_HEIGHT_RATE + PINNUMBER_GAP_RATE + PIN_CONTENTTEXT_HEIGHT_RATE + PINTITLE_PINNUMBER_GAP_RATE);
		}
		else
		{
			m_pin1Ypos = (float)t_Height *(PIN_TITLE_HEIGHT_RATE_WITHOUTCONTENT + PIN_CONTENTTEXT_HEIGHT_RATE + PINNUMBER_GAP_RATE + PINTEXT1_PINBOX1_GAP_RATE);
			m_pin2Ypos = m_pin1Ypos + (float)t_Height * (PINBOX_H_WITHOUTCONTENT + PINBOX1_PINTEXT2_GAP_RATE + PIN_CONTENTTEXT_HEIGHT_RATE + PINTEXT1_PINBOX1_GAP_RATE);
		}
	}

	void CPinPopup::m_AutoArrangePinBoxDescription()
	{
		ClutterColor BgColor = {255,255,255,225};
		if (m_IsContent)
		{
			m_pinText1 = IText::CreateInstance(dynamic_cast<Widget*>(this) , (float)t_Width * PIN_TITLE_WIDTH_RATE_WITHCONTENT , (float)t_Height *PIN_CONTENTTEXT_HEIGHT_RATE);
			m_pinText1->SetPosition(m_TitleXPos , m_ContentYpos + (float)t_Height *PIN_CONTENTTEXT_HEIGHT_RATE + (float)t_Height * PIN_CONTENTTEXT_HEIGHT_RATE);
		}
		else
		{
			m_pinText1 = IText::CreateInstance(dynamic_cast<Widget*>(this) , (float)t_Width * PIN_TITLE_WIDTH_RATE_WITHOUTCONTENT , (float)t_Height *PIN_CONTENTTEXT_HEIGHT_RATE);
			m_pinText1->SetPosition(m_TitleXPos , (float)t_Height * TITLE_PIN1TEXT_GAP_RATE + (float)t_Height * PIN_TITLE_HEIGHT_RATE);
		}
		m_pinText1->SetTextAlignment(HALIGN_CENTER , VALIGN_MIDDLE);
		m_pinText1->SetTextColor(BgColor);
		m_pinText1->SetFontSize(34);
		if (m_pinType == E_PINNUMBER_TWO)
		{
			if (m_IsContent)
			{
				m_pinText2 = IText::CreateInstance(dynamic_cast<Widget*>(this) , (float)t_Width * PIN_TITLE_WIDTH_RATE_WITHCONTENT , (float)t_Height *PIN_CONTENTTEXT_HEIGHT_RATE);
				m_pinText2->SetPosition(m_TitleXPos , m_ContentYpos + (float)t_Height *(PIN_CONTENTTEXT_HEIGHT_RATE + PIN_CONTENTTEXT_HEIGHT_RATE  + PINNUMBER_GAP_RATE + PINTITLE_PINNUMBER_GAP_RATE + PINNUMBER_HEIGHT_RATE + PIN_CONTENTTEXT_HEIGHT_RATE));
			}
			else
			{
				m_pinText2 = IText::CreateInstance(dynamic_cast<Widget*>(this) , (float)t_Width * PIN_TITLE_WIDTH_RATE_WITHOUTCONTENT , (float)t_Height *PIN_CONTENTTEXT_HEIGHT_RATE);
				m_pinText2->SetPosition(m_TitleXPos , (float)t_Height * (PIN_TITLE_HEIGHT_RATE_WITHOUTCONTENT + PINNUMBER_GAP_RATE + PIN_CONTENTTEXT_HEIGHT_RATE + PINTEXT1_PINBOX1_GAP_RATE + PINBOX_H_WITHOUTCONTENT + PINBOX1_PINTEXT2_GAP_RATE));
			}
			m_pinText2->SetTextAlignment(HALIGN_CENTER , VALIGN_MIDDLE);
			m_pinText2->SetTextColor(BgColor);
			m_pinText2->SetFontSize(34);
		}
	}

	void CPinPopup::SetPinBoxItemDigitFontSize( int digitsize )
	{
		m_pinNumber1->SetDigitTextFontSize(digitsize);
		if (m_pinType == E_PINNUMBER_TWO)
		{
			m_pinNumber2->SetDigitTextFontSize(digitsize);
		}
	}

	void CPinPopup::SetPinBoxItemDigitColor( const ClutterColor textcolor )
	{
		m_pinNumber1->SetDigitTextColor(textcolor);
		if (m_pinType == E_PINNUMBER_TWO)
		{
			m_pinNumber2->SetDigitTextColor(textcolor);
		}
	}

	void CPinPopup::SetPinBoxItemDigitFont( const std::string& font )
	{
		m_pinNumber1->SetDigitTextFont(font.c_str());
		if (m_pinType == E_PINNUMBER_TWO)
		{
			m_pinNumber2->SetDigitTextFont(font.c_str());
		}
	}

	std::string CPinPopup::ContentText( void ) const
	{
		return m_ConTentText->Text();
	}

	std::string CPinPopup::ContentTextFont( void ) const
	{
		return m_ConTentText->Font();
	}

	int CPinPopup::ContentTextFontSize( void ) const
	{
		return m_ConTentText->FontSize();
	}

	ClutterColor CPinPopup::ContentTextFontColor( void ) const
	{
		return m_ConTentText->TextColor();
	}

	int CPinPopup::PinBoxItemDigitFontSize( void ) const
	{
		return m_pinNumber1->DigitTextFontSize();
	}

	ClutterColor CPinPopup::PinBoxItemDigitColor( void ) const
	{
		return m_pinNumber1->DigitTextColor();
	}

	std::string CPinPopup::PinBoxItemDigitFont( void ) const
	{
		return m_pinNumber1->DigitTextFont();
	}

	void CPinPopup::SetPinBoxFocus( E_PINNUMBER_TYPE pinType )
	{
		ASSERT(pinType <= m_pinType);
		if (pinType == E_PINNUMBER_ONE && NULL != m_pinNumber1)
		{
			m_pinNumber1->SetFocus();
		}
		else
		{
			m_pinNumber2->SetFocus();
		}
	}

	void CPinPopup::m_CreateButton()
	{
		ClutterColor c = {255, 255, 255, 255};
		float buttonw = (float)(t_Width * BUTTON_WIDTH_RATE);
		float buttonh = (float)(t_Height * BUTTON_HEIGHT_RATE);
		float ypos = 0.0f;
		if (m_IsContent)
		{
			ypos = (float)((PIN_HEIGHT_RATE_WITHCONTENT - BUTTON_DOWN_GAP - BUTTON_HEIGHT_RATE) * t_Height);
		}
		else
		{
			ypos = (float)((PIN_HEIGHT_RATE_WITHOUTCONTENT - BUTTON_DOWN_GAP - BUTTON_HEIGHT_RATE) * t_Height);
		}
		m_button1 = IButton::CreateInstance(this, buttonw , buttonh);
		IClickAction* action1 = IClickAction::CreateInstance(m_button1);
		m_button1->AddAction(action1);
		m_action1 = action1;
		m_button1->AddClickListener(this);
		m_button1->AddKeyboardListener(this);
		m_button1->AddFocusListener(this);
		m_button1->AddMouseListener(this);
		m_button1->EnablePointerFocus(true);
		t_AddNoticeActor(m_button1);
		if (m_buttonNum == 1)
		{
			m_button1->SetBackgroundColor(IButton::STATE_ALL, *clutter_color_init(&c, 0, 0, 0, 0));
			m_button1->SetPosition((t_Width - buttonw) / 2.0 , ypos);
		}
		else
		{
			m_button2 = IButton::CreateInstance(this, buttonw, buttonh);
			IClickAction* action2 = IClickAction::CreateInstance(m_button2);
			m_button2->AddAction(action2);
			m_action2 = action2;
			m_button2->AddClickListener(this);
			m_button2->AddKeyboardListener(this);
			m_button2->AddFocusListener(this);
			m_button2->AddMouseListener(this);
			m_button2->EnablePointerFocus(true);
			float buttonGapWidth = (float)(t_Width * 0.0146875);
			float xgap = (t_Width - buttonGapWidth - 2 * buttonw) / 2.0;
			
			m_button1->SetPosition(xgap , ypos);
			m_button2->SetPosition(xgap + buttonGapWidth + (float)(t_Width * BUTTON_WIDTH_RATE) , ypos);
			m_button1->SetBackgroundColor(IButton::STATE_ALL, *clutter_color_init(&c, 0, 0, 0, 0));
			m_button2->SetBackgroundColor(IButton::STATE_ALL, *clutter_color_init(&c, 0, 0, 0, 0));
			t_AddNoticeActor(m_button2);
		}
	}


	void CPinPopup::SetButtonImage( const EPinPopupButtons nButton, IButton::EButtonState state, const std::string& imagePath )
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(BUTTON_ALL == nButton)
		{
			m_button1->SetBackgroundImage(state, imagePath);
			m_button2->SetBackgroundImage(state, imagePath);
		}
		else if (nButton == BUTTON_1)
		{
			m_button1->SetBackgroundImage(state, imagePath);
		}
		else if(nButton == BUTTON_2)
		{
			m_button2->SetBackgroundImage(state, imagePath);
		}
	}

	void CPinPopup::SetButtonText( const EPinPopupButtons nButton, IButton::EButtonState state, const std::string& text )
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		ClutterColor c = {255, 255, 255, 255};
		if(BUTTON_ALL == nButton)
		{
			m_button1->SetText(state, text);
			m_button1->SetTextColor(IButton::STATE_ALL, *clutter_color_init(&c, 255, 255, 255, 255));
			m_button2->SetText(state, text);
			m_button2->SetTextColor(IButton::STATE_ALL, *clutter_color_init(&c, 255, 255, 255, 255));
		}
		else if(nButton == BUTTON_1)
		{
			m_button1->SetText(state, text);
			m_button1->SetTextColor(IButton::STATE_ALL, *clutter_color_init(&c, 255, 255, 255, 255));
		}
		else if(nButton == BUTTON_2)
		{
			m_button2->SetText(state, text);
			m_button2->SetTextColor(IButton::STATE_ALL, *clutter_color_init(&c, 255, 255, 255, 255));
		}
	}

	void CPinPopup::SetButtonTextColor( const EPinPopupButtons nButton, IButton::EButtonState state, const ClutterColor color )
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(BUTTON_ALL == nButton)
		{
			m_button1->SetTextColor(state, color);
			m_button2->SetTextColor(state, color);
		}
		else if(nButton == BUTTON_1)
		{
			m_button1->SetTextColor(state, color);
		}
		else if(nButton == BUTTON_2)
		{
			m_button2->SetTextColor(state, color);
		}
	}

	void CPinPopup::SetButtonTextFontSize( const EPinPopupButtons nButton, IButton::EButtonState state, int fontSize )
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(BUTTON_ALL == nButton)
		{
			m_button1->SetFontSize(state, fontSize);
			m_button2->SetFontSize(state, fontSize);
		}
		else if(nButton == BUTTON_1)
		{
			m_button1->SetFontSize(state, fontSize);
		}
		else if(nButton == BUTTON_2)
		{
			m_button2->SetFontSize(state, fontSize);
		}
	}

	bool CPinPopup::OnFocusIn(IWidgetExtension* pWindow )
	{
		if (pWindow == m_button1)
		{
			if (t_pPinPopupListenerSet)
			{
				CPinPopupListenerSet::TPinPopupListenerData data;
				data.type = IPinPopupListener::BUTTON_FOCUS_IN;
				data.param[0] = BUTTON_1;
				t_pPinPopupListenerSet->Process(&data);
			}
		}
		else if(pWindow == m_button2)
		{

			if (t_pPinPopupListenerSet)
			{
				CPinPopupListenerSet::TPinPopupListenerData data;
				data.type = IPinPopupListener::BUTTON_FOCUS_IN;
				data.param[0] = BUTTON_2;
				t_pPinPopupListenerSet->Process(&data);
			}
		}
		return true;
	}

	bool CPinPopup::OnFocusOut( IWidgetExtension* pWindow )
	{
		if (pWindow == m_button1)
		{
			if (t_pPinPopupListenerSet)
			{
				CPinPopupListenerSet::TPinPopupListenerData data;
				data.type = IPinPopupListener::BUTTON_FOCUS_OUT;
				data.param[0] = BUTTON_1;
				t_pPinPopupListenerSet->Process(&data);
			}
		}
		else if(pWindow == m_button2)
		{
			
			if (t_pPinPopupListenerSet)
			{
				CPinPopupListenerSet::TPinPopupListenerData data;
				data.type = IPinPopupListener::BUTTON_FOCUS_OUT;
				data.param[0] = BUTTON_2;
				t_pPinPopupListenerSet->Process(&data);
			}
			
		}
		return true;
	}

	bool CPinPopup::OnClicked( IWidgetExtension* pWindow, IEvent* pClickEvent )
	{
		if (pWindow == m_button1)
		{
			if (t_pPinPopupListenerSet)
			{
				CPinPopupListenerSet::TPinPopupListenerData data;
				data.type = IPinPopupListener::BUTTON_CLICKED;
				data.param[0] = BUTTON_1;
				t_pPinPopupListenerSet->Process(&data);
			}
		}
		else if(pWindow == m_button2)
		{

			if (t_pPinPopupListenerSet)
			{
				CPinPopupListenerSet::TPinPopupListenerData data;
				data.type = IPinPopupListener::BUTTON_CLICKED;
				data.param[0] = BUTTON_2;
				t_pPinPopupListenerSet->Process(&data);
			}

		}
		return true;
	}

	bool CPinPopup::OnKeyReleased(IWidgetExtension* pThis, IKeyboardEvent* event)
	{
		if (m_buttonNum != 0)
		{
			int keyValue = event->GetKeyVal();

			if (pThis == m_button1 && keyValue == CLUTTER_KEY_Return)
			{
				if (t_pPinPopupListenerSet)
				{
					CPinPopupListenerSet::TPinPopupListenerData data;
					data.type = IPinPopupListener::BUTTON_PRESSED;
					data.param[0] = BUTTON_1;
					t_pPinPopupListenerSet->Process(&data);
				}
				return true;
			}
			
			if (m_buttonNum == 2 && pThis == m_button1 && keyValue == CLUTTER_KEY_Return)
			{
				if (t_pPinPopupListenerSet)
				{
					CPinPopupListenerSet::TPinPopupListenerData data;
					data.type = IPinPopupListener::BUTTON_PRESSED;
					data.param[0] = BUTTON_1;
					t_pPinPopupListenerSet->Process(&data);
				}
				return true;
			}
		}
		return true;
	}

	bool CPinPopup::OnMousePointerIn(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent )
	{
		return true;
	}

	bool CPinPopup::OnMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent )
	{
		return true;
	}

	void CPinPopup::m_SetWindowTab()
	{
		m_pinNumber1->AddKeyboardListener(this);
		if (m_pinType == E_PINNUMBER_TWO)
		{
			m_pinNumber2->AddKeyboardListener(this);
		}
		if (m_buttonNum == 2)
		{
			m_button1->SetTabWindow(DIRECTION_LEFT , m_button2);
			m_button1->SetTabWindow(DIRECTION_RIGHT , m_button2);
			m_button2->SetTabWindow(DIRECTION_LEFT , m_button1);
			m_button2->SetTabWindow(DIRECTION_RIGHT , m_button1);
		}
		if (m_pinType == E_PINNUMBER_TWO)
		{
			m_pinNumber1->SetTabWindow(DIRECTION_DOWN , m_pinNumber2);
			m_pinNumber2->SetTabWindow(DIRECTION_UP , m_pinNumber1);
			if (m_buttonNum != 0)
			{
				m_pinNumber2->SetTabWindow(DIRECTION_DOWN , m_button1);
				m_button1->SetTabWindow(DIRECTION_UP , m_pinNumber2);
				if (m_buttonNum == 2)
				{
					m_button2->SetTabWindow(DIRECTION_UP , m_pinNumber2);
				}
			}
		}
		else if (m_pinType == E_PINNUMBER_ONE && m_buttonNum != 0)
		{
			m_pinNumber1->SetTabWindow(DIRECTION_DOWN , m_button1);
			m_button1->SetTabWindow(DIRECTION_UP , m_pinNumber1);
			if (m_buttonNum == 2)
			{
				m_button2->SetTabWindow(DIRECTION_UP , m_pinNumber1);
			}
		}
	}
	void CPinPopup::SetButtonBackgroundColor( const EPinPopupButtons nButton, IButton::EButtonState state, const ClutterColor color )
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);

		if(BUTTON_ALL == nButton)
		{
			
			m_button1->SetBackgroundColor(state, color);
			m_button2->SetBackgroundColor(state, color);
		}
		else if (BUTTON_1 == nButton)
		{
			m_button1->SetBackgroundColor(state, color);
		}
		else if (BUTTON_2 == nButton)
		{
			m_button2->SetBackgroundColor(state, color);
		}
	}

	void CPinPopup::SetPinBoxRect( E_PINNUMBER_TYPE pinType, float x , float y ,float w, float h )
	{
		if (pinType == E_PINNUMBER_ONE)
		{
			m_pinNumber1->SetPosition(x , y);
			m_pinNumber1->Resize(w , h);
		}
		else if (pinType == E_PINNUMBER_TWO)
		{
			m_pinNumber2->SetPosition(x , y);
			m_pinNumber2->Resize(w , h);
		}
	}

	void CPinPopup::SetDigitTextSize( float parentW, float parentH )
	{
		if (m_pinType == E_PINNUMBER_ONE)
		{
			m_pinNumber1->SetDigitTextSize(parentW , parentH);
		}
		else if (m_pinType == E_PINNUMBER_TWO)
		{
			m_pinNumber1->SetDigitTextSize(parentW , parentH);
			m_pinNumber2->SetDigitTextSize(parentW , parentH);
		}
	}

	void CPinPopup::SetButtonRect( const EPinPopupButtons nButton, float x, float y, float w, float h )
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);
		if(BUTTON_ALL == nButton)
		{
			m_button1->SetPosition(x , y);
			m_button2->SetPosition(x , y);
			m_button1->Resize(w, h);
			m_button2->Resize(w, h);
		}
		else
		{
			if (nButton == BUTTON_1)
			{
				m_button1->SetPosition(x , y);
				m_button1->Resize(w, h);
			}
			else if(nButton == BUTTON_2)
			{
				m_button2->SetPosition(x , y);
				m_button2->Resize(w, h);
			}
		}
	}

	void CPinPopup::SetButtonPosition( const EPinPopupButtons nButton, float x, float y )
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);
		if(BUTTON_ALL == nButton)
		{
			m_button1->SetPosition(x , y);
			m_button2->SetPosition(x , y);
		}
		else
		{
			if (nButton == BUTTON_1)
			{
				m_button1->SetPosition(x , y);
			}
			else if(nButton == BUTTON_2)
			{
				m_button2->SetPosition(x , y);
			}
		}
	}

	void CPinPopup::SetButtonSize( const EPinPopupButtons nButton, float w, float h )
	{
		ASSERT(nButton <= BUTTON_ALL && nButton >= BUTTON_1);
		if(BUTTON_ALL == nButton)
		{
			m_button1->Resize(w, h);
			m_button2->Resize(w, h);
		}
		else
		{
			if (nButton == BUTTON_1)
			{
				m_button1->Resize(w, h);
			}
			else if(nButton == BUTTON_2)
			{
				m_button2->Resize(w, h);
			}
		}
	}

	void CPinPopup::SetDigitGap( float gap )
	{
		if (m_pinType == E_PINNUMBER_ONE)
		{
			m_pinNumber1->SetDigitGap(gap);
		}
		else if (m_pinType == E_PINNUMBER_TWO)
		{
			m_pinNumber1->SetDigitGap(gap);
			m_pinNumber2->SetDigitGap(gap);
		}
	}


	void CPinPopup::SetInputItemsGap( EInputItemsState inputboxState , float gap )
	{
		if (m_pinType == E_PINNUMBER_ONE)
		{
			if (inputboxState == IPinPopup::E_STATE_NOINPUT)
			{
				m_pinNumber1->SetInputItemsGap(CPinBox::E_STATE_NOINPUT , gap);
			}
			else if (inputboxState == E_STATE_FINISHINPUT)
			{
				m_pinNumber1->SetInputItemsGap(CPinBox::E_STATE_FINISHINPUT , gap);
			}
			else if (inputboxState == E_STATE_INPUT_ALL)
			{
				m_pinNumber1->SetInputItemsGap(CPinBox::E_STATE_ALL , gap);
			}
			
		}
		else 
		{
			if (inputboxState == E_STATE_NOINPUT)
			{
				m_pinNumber1->SetInputItemsGap(CPinBox::E_STATE_NOINPUT , gap);
				m_pinNumber2->SetInputItemsGap(CPinBox::E_STATE_NOINPUT , gap);
			}
			else if (inputboxState == E_STATE_FINISHINPUT)
			{
				m_pinNumber1->SetInputItemsGap(CPinBox::E_STATE_FINISHINPUT , gap);
				m_pinNumber2->SetInputItemsGap(CPinBox::E_STATE_FINISHINPUT , gap);
			}
			else if (inputboxState == E_STATE_INPUT_ALL)
			{
				m_pinNumber1->SetInputItemsGap(CPinBox::E_STATE_ALL , gap);
				m_pinNumber2->SetInputItemsGap(CPinBox::E_STATE_ALL , gap);
			}
			
		}
	}

	void CPinPopup::SetInputBoxItemSize( EInputItemsState inputboxState , float w , float h )
	{
		if (m_pinType == E_PINNUMBER_ONE)
		{
			if (inputboxState == IPinPopup::E_STATE_NOINPUT)
			{
				m_pinNumber1->SetInputItemSize(CPinBox::E_STATE_NOINPUT , w , h);
			}
			else if (inputboxState == E_STATE_FINISHINPUT)
			{
				m_pinNumber1->SetInputItemSize(CPinBox::E_STATE_FINISHINPUT , w , h);
			}
			else if (inputboxState == E_STATE_INPUT_ALL)
			{
				m_pinNumber1->SetInputItemSize(CPinBox::E_STATE_ALL , w , h);
			}
			
		}
		else 
		{
			if (inputboxState == E_STATE_NOINPUT)
			{
				m_pinNumber1->SetInputItemSize(CPinBox::E_STATE_NOINPUT , w , h);
				m_pinNumber2->SetInputItemSize(CPinBox::E_STATE_NOINPUT , w , h);
			}
			else if (inputboxState == E_STATE_FINISHINPUT)
			{
				m_pinNumber1->SetInputItemSize(CPinBox::E_STATE_FINISHINPUT , w , h);
				m_pinNumber2->SetInputItemSize(CPinBox::E_STATE_FINISHINPUT , w , h);
			}
			else if (inputboxState == E_STATE_INPUT_ALL)
			{
				m_pinNumber1->SetInputItemSize(CPinBox::E_STATE_ALL , w , h);
				m_pinNumber2->SetInputItemSize(CPinBox::E_STATE_ALL , w , h);
			}
			
		}
	}



}
