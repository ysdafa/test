#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{

	IDefaultWindow* IDefaultWindow::CreateInstance(IActor* parent, const TDefaultWindowAttr &attr)
	{
		CDefaultWindow* window = dynamic_cast<CDefaultWindow*>(Instance::CreateInstance(CLASS_ID_IDEFAULTWINDOW));

		if (NULL != window)
		{
			window->Initialize(parent, attr);
		}

		return window;
	}

}