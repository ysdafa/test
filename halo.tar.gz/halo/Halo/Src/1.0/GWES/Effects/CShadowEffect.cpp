#include "Halo1_0.h"

namespace HALO
{
	bool CShadowEffect::Initialize(float topOffset, float bottomOffset, float leftOffset, float rightOffset)
	{
		t_effect = clutter_shadow_effect_new();
		g_object_ref_sink(t_effect);

		clutter_shadow_effect_set_positionoffset(CLUTTER_SHADOW_EFFECT(t_effect), topOffset, bottomOffset, leftOffset, rightOffset);

		return true;
	}

	void CShadowEffect::SetShadowOffset(float top, float bottom, float left, float right)
	{
		clutter_shadow_effect_set_positionoffset(CLUTTER_SHADOW_EFFECT(t_effect), top, bottom, left, right);
	}

}
