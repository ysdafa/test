#ifndef _HALO_CDESATURATIONEFFECT_H_
#define _HALO_CDESATURATIONEFFECT_H_

namespace HALO
{
	class CDesaturationEffect :virtual public IDesaturationEffect, public CEffect
	{
	public:
		bool Initialize(double factor);

		void SetFactor(double factor);
		double GetFactor(void);
	};
}

#endif //_HALO_CDESATURATIONEFFECT_H_