#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	IDesaturationEffect* IDesaturationEffect::CreateInstance(double factor)
	{
		CDesaturationEffect* effect = dynamic_cast<CDesaturationEffect*>(Instance::CreateInstance(CLASS_ID_IDESATURATIONEFFECT));

		if (NULL != effect)
		{
			effect->Initialize(factor);
		}

		return effect;
	}


	IShadowEffect* IShadowEffect::CreateInstance(float topOffset, float bottomOffset, float leftOffset, float rightOffset)
	{
		CShadowEffect* effect = dynamic_cast<CShadowEffect*>(Instance::CreateInstance(CLASS_ID_IDSHADOWEFFECT));

		if (NULL != effect)
		{
			effect->Initialize(topOffset, bottomOffset, leftOffset, rightOffset);
		}

		return effect;
	}

}