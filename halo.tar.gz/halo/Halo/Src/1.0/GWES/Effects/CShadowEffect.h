#ifndef _HALO_CSHADOWEFFECT_H_
#define _HALO_CSHADOWEFFECT_H_

namespace HALO
{
	class CShadowEffect :virtual public IShadowEffect, public CEffect
	{
	public:
		virtual bool Initialize(float topOffset, float bottomOffset, float leftOffset, float rightOffset);

		virtual void SetShadowOffset(float top, float bottom, float left, float right);

	};
}

#endif //_HALO_CSHADOWEFFECT_H_