#ifndef _HALO_CEFFECT_H_
#define _HALO_CEFFECT_H_

namespace HALO
{
	class CEffect : virtual public IEffect
	{
	public:
		CEffect(void) :t_effect(NULL) {}
		~CEffect(void);

		void Enabled(bool flagEnable);
		bool IsEnabled(void);
		ClutterEffect* GetEffect(void);

	protected:
		ClutterEffect* t_effect;
	};
}

#endif //_HALO_CEFFECT_H_