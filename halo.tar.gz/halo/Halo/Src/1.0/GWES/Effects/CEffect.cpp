#include "Halo1_0.h"

namespace HALO
{
	CEffect::~CEffect(void)
	{
		if (NULL != t_effect)
		{
			g_object_unref(t_effect);
			t_effect = NULL;
		}
	}

	void CEffect::Enabled(bool flagEnable)
	{
		clutter_actor_meta_set_enabled(CLUTTER_ACTOR_META(t_effect), flagEnable);
	}

	bool CEffect::IsEnabled(void)
	{
		return clutter_actor_meta_get_enabled(CLUTTER_ACTOR_META(t_effect)) != FALSE;
	}

	ClutterEffect* CEffect::GetEffect(void)
	{
		return t_effect;
	}

}