#include "Halo1_0.h"

namespace HALO
{
	bool CDesaturationEffect::Initialize(double factor)
	{
		t_effect = clutter_desaturate_effect_new(factor);
		g_object_ref_sink(t_effect);

		return true;
	}

	void CDesaturationEffect::SetFactor(double factor)
	{
		clutter_desaturate_effect_set_factor(CLUTTER_DESATURATE_EFFECT( t_effect), factor);
	}

	double CDesaturationEffect::GetFactor(void)
	{
		return clutter_desaturate_effect_get_factor(CLUTTER_DESATURATE_EFFECT(t_effect));
	}
}
