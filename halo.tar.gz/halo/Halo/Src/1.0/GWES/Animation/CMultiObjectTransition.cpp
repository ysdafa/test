#include "Halo1_0.h"

static HALO::util::Logger LOGGER("CMultiObjectTransition");

namespace HALO
{
	CMultiObjectTransition::CMultiObjectTransition(void)
	{
		m_flagNeedAllocNewObjInfo = true;
		m_currentPos = 0.0f;
		m_startPos = 0.0f;
		m_totalDistance = 0.0f;
		m_popedDistance = 0.0f;
		m_totalDestinationCount = 0;
	}

	CMultiObjectTransition::~CMultiObjectTransition(void)
	{
		m_flagNeedAllocNewObjInfo = true;

		for (std::map<CAnimatable*, TAnimatableObject*>::iterator x = m_objectMap.begin(); x != m_objectMap.end(); ++x)
		{
			delete x->second;
		}
	}

	void CMultiObjectTransition::AddAnimatableObject(IAnimatable *object, int animationType)
	{
		CAnimatable *realObj = dynamic_cast<CAnimatable*>(object);
		ASSERT(NULL != realObj);

		std::map<CAnimatable*, TAnimatableObject*>::iterator x = m_objectMap.find(realObj);

		TAnimatableObject *animatableObject = NULL;

		if (m_objectMap.end() == x)
		{
			TAnimatableObject *animatableObject = new TAnimatableObject(realObj);
			ASSERT(NULL != animatableObject);

			if (NULL == animatableObject)
			{
				return;
			}

			animatableObject->AddAnimationType(animationType);
			m_objectMap.insert(std::make_pair(realObj, animatableObject));
		}
		else
		{
			x->second->AddAnimationType(animationType);
		}
	}

	void CMultiObjectTransition::SetDestination(IAnimatable *object, int aniType, TValueBase &dest)
	{
		SetDestination(object, aniType, &dest);
	}

	void CMultiObjectTransition::SetDestination(IAnimatable *object, int aniType, TValueBase *dest)
	{
		CAnimatable *realObj = dynamic_cast<CAnimatable*>(object);

		std::map<CAnimatable*, TAnimatableObject*>::iterator x = m_objectMap.find(realObj);
		ASSERT(m_objectMap.end() != x);

		if (m_objectMap.end() == x)
		{
			return;
		}

		std::vector<TAniObjInfo*>* objInfoList;

		if (true == m_flagNeedAllocNewObjInfo)
		{
			m_totalDestinationCount++;
			m_totalDistance += 1.0f;

			objInfoList = new std::vector<TAniObjInfo*>;
			ASSERT(NULL != objInfoList);

			if (NULL == objInfoList)
			{
				return;
			}

			m_usedObjList.push_back(objInfoList);

			m_flagNeedAllocNewObjInfo = false;
		} 
		else
		{
			objInfoList = m_usedObjList.back();
		}

		TAniObjInfo *objInfo = new TAniObjInfo;
		ASSERT(NULL != objInfo);

		if (NULL == objInfo)
		{
			return;
		}

		objInfo->object = x->second;
		objInfo->aniType = aniType;
		objInfoList->push_back(objInfo);

		x->second->AddWayPointAndGetDistance(dest, aniType);
	}

	void CMultiObjectTransition::Play(void)
	{
		ASSERT((int)m_usedObjList.size() == m_totalDestinationCount);

		m_flagNeedAllocNewObjInfo = true;

		if (0 == t_duration)
		{
			JumpToDestination();
		}
		else
		{
			if (TRUE == clutter_timeline_is_playing(t_timeLine))
			{
				int duration = clutter_timeline_get_duration(t_timeLine);

				if (t_duration - 1 == duration)
				{
					if (NULL != t_timeLine && 0 < duration)
					{
						clutter_timeline_set_duration(t_timeLine, duration);
					}
				}
				else
				{
					if (NULL != t_timeLine && 0 < duration)
					{
						clutter_timeline_set_duration(t_timeLine, duration - 1);
					}
				}
			}

			if (false == CTimeLine::IsPlaying())
			{
				CTimeLine::Play();
			}
		}

		m_startPos = m_currentPos;
	}

	void CMultiObjectTransition::JumpToDestination(void)
	{
		t_StartCallback(t_timeLine, this);
		t_OnNewFrame(this, 1.0f);
		t_CompleteCallback(t_timeLine, this);
		t_StopCallback(t_timeLine, true, this);
	}

	void CMultiObjectTransition::t_OnNewFrame(class ITimeLine *animation, double currentProgress)
	{
		float newPosition = m_startPos + (m_totalDistance - m_startPos) * (float)currentProgress;
		m_currentPos = newPosition;

		while (0 != m_totalDestinationCount)
		{
			float curDistance = 1.0f;
			std::vector<TAniObjInfo*>* objInfoList = m_usedObjList.front();

			if (newPosition - m_popedDistance <= curDistance)
			{
				for (int i = 0; i < (int)objInfoList->size(); i++)
				{
					TAniObjInfo *objInfo = (*objInfoList)[i];
					objInfo->object->SetProgress(0, objInfo->aniType, (newPosition - m_popedDistance) / curDistance);
				}

				break;
			}
			else
			{
				CTimeLine::t_CallListener(EVENT_VIA);

				for (int i = 0; i < (int)objInfoList->size(); i++)
				{
					TAniObjInfo *objInfo = (*objInfoList)[i];
					objInfo->object->PopFrontWayPoint(objInfo->aniType);

					if (1 == objInfo->object->WayPointCount(objInfo->aniType))
					{
						objInfo->object->SetProgress(0, objInfo->aniType, 0.0f);
					}
				}

				m_popedDistance += curDistance;
			}

			m_totalDestinationCount--;

			for (int i = 0; i < (int)objInfoList->size(); i++)
			{
				delete (*objInfoList)[i];
			}
			delete objInfoList;
			m_usedObjList.pop_front();
		}
	}

	void CMultiObjectTransition::t_OnComplete(ITimeLine *animation)
	{
		m_flagNeedAllocNewObjInfo = true;
		m_totalDestinationCount = 0;

		m_popedDistance = 0.0f;
		m_totalDistance = 0.0f;
		m_startPos = 0.0f;
		m_currentPos = 0.0f;

		int size = m_usedObjList.size();
		while (false == m_usedObjList.empty())
		{
			std::vector<TAniObjInfo*> *objInfoList = m_usedObjList.front();
			
			for (int i = 0; i < (int)objInfoList->size(); i++)
			{
				TAniObjInfo *objInfo = (*objInfoList)[i];
				objInfo->object->ClearWayPoint(objInfo->aniType);

				delete (*objInfoList)[i];
			}

			delete objInfoList;
			m_usedObjList.pop_front();
		}
	}

	void CMultiObjectTransition::t_OnStop(ITimeLine *animation)
	{
		t_OnComplete(animation);
	}

	template <typename T>
	CMultiObjectTransition::TWayPointSystem<T>::TWayPointSystem(CAnimatable *inObject, int type)
	{
		m_animationType = type;

		inObject->GetPropertyName(type, &m_clutterValueType);
	}

	template <typename T>
	CMultiObjectTransition::TWayPointSystem<T>::~TWayPointSystem(void)
	{
	}

	template <typename T>
	float CMultiObjectTransition::TWayPointSystem<T>::AddWayPointAndGetDistance(TValueBase *val, CAnimatable *object)
	{
		TWayPoint newWayPoint;
		T *realWayPoint = dynamic_cast<T*>(val);
		ASSERT(NULL != realWayPoint);

		newWayPoint.valueList = *realWayPoint;
		return m_AddWayPointAndGetDistance(object, newWayPoint);
	}

	template <typename T>
	void CMultiObjectTransition::TWayPointSystem<T>::PopFrontWayPoint(void)
	{
		if (1 == (int)m_wayPointList.size())
		{
			TWayPoint point = m_wayPointList[0];
		}
		m_wayPointList.pop_front();
	}

	template <typename T>
	void CMultiObjectTransition::TWayPointSystem<T>::ClearWayPoint(void)
	{
		m_wayPointList.clear();
	}

	template <typename T>
	void CMultiObjectTransition::TWayPointSystem<T>::SetProgress(CAnimatable *object, int wayPointIndex, float progress)
	{
		if (0 == (int)m_wayPointList.size())
		{
			return;
		}

		TWayPoint &point = m_wayPointList[wayPointIndex];

		float distance = point.distanceToNext * progress;
		T curValue = point.valueList;

		for (int i = 0; i < curValue.ElementCount(); i++)
		{
			curValue.SetElementValue(i, curValue.ElementValue(i) + distance * point.rakeRatio.ElementValue(i));
		}

		UValueElement val;

		if (G_TYPE_UINT == m_clutterValueType)
		{
			val.i = (int)curValue.ElementValue(0);
			object->SetPropertyValue(m_animationType, val);
		}
		else if (G_TYPE_DOUBLE == m_clutterValueType)
		{
			val.d = (double)curValue.ElementValue(0);
			object->SetPropertyValue(m_animationType, val);
		}
		else if (CLUTTER_TYPE_POINT == m_clutterValueType)
		{
			ClutterPoint clutterPoint = {curValue.ElementValue(0), curValue.ElementValue(1)};
			val.p = &clutterPoint;

			object->SetPropertyValue(m_animationType, val);
		}
		else if (CLUTTER_TYPE_SIZE == m_clutterValueType)
		{
			ClutterSize size = {curValue.ElementValue(0), curValue.ElementValue(1)};
			val.p = &size;

			object->SetPropertyValue(m_animationType, val);
		}
		else
		{
			H_LOG_FATAL(LOGGER, "[" << std::hex << this << "]CMultiObjectTransition::TAnimatableObject::SetProgress ClutterValueType is error " << m_clutterValueType << "!!!!!");
		}
	}

	template <typename T>
	float CMultiObjectTransition::TWayPointSystem<T>::m_AddWayPointAndGetDistance(CAnimatable *object, const TWayPoint &wayPoint)
	{
		if (0 == (int)m_wayPointList.size())
		{
			TWayPoint startPoint;
			UValueElement val;
			val.p = NULL;
			object->GetAnimatableValue(m_animationType, val);

			if (G_TYPE_UINT == m_clutterValueType)
			{
				startPoint.valueList.SetElementValue(0, (float)val.i);
			}
			else if (G_TYPE_DOUBLE == m_clutterValueType)
			{
				startPoint.valueList.SetElementValue(0, (float)val.d);
			}
			else if (CLUTTER_TYPE_POINT == m_clutterValueType)
			{
				ClutterPoint *point = (ClutterPoint*)(val.p);
				startPoint.valueList.SetElementValue(0, point->x);
				startPoint.valueList.SetElementValue(1, point->y);
				delete point;
			}
			else if (CLUTTER_TYPE_SIZE == m_clutterValueType)
			{
				ClutterSize *size = (ClutterSize*)(val.p);
				startPoint.valueList.SetElementValue(0, size->width);
				startPoint.valueList.SetElementValue(1, size->height);
				delete size;
			}
			else
			{
				H_LOG_FATAL(LOGGER, "[" << std::hex << this << "]CMultiObjectTransition::TAnimatableObject::SetProgress ClutterValueType is error " << m_clutterValueType << "!!!!!");
			}

			m_wayPointList.clear();
			m_wayPointList.push_back(startPoint);
		}

		float lastDistance = 0.0f;

		TWayPoint &prev = m_wayPointList.back();

		for (int i = 0; i < wayPoint.valueList.ElementCount(); i++)
		{
			lastDistance += (wayPoint.valueList.ElementValue(i) - prev.valueList.ElementValue(i)) * (wayPoint.valueList.ElementValue(i) - prev.valueList.ElementValue(i));
		}

		lastDistance = sqrt(lastDistance);
		prev.distanceToNext = lastDistance;

		for (int i = 0; i < wayPoint.valueList.ElementCount(); i++)
		{
			if (0.0f == prev.distanceToNext)
			{
				prev.rakeRatio.SetElementValue(i, 0.0f);
			}
			else
			{
				prev.rakeRatio.SetElementValue(i, (wayPoint.valueList.ElementValue(i) - prev.valueList.ElementValue(i))/ prev.distanceToNext);
			}
		}

		m_wayPointList.push_back(wayPoint);

		return lastDistance;
	}

	CMultiObjectTransition::TAnimatableObject::TAnimatableObject(CAnimatable *inObject)
	{
		m_object = inObject;
	}

	CMultiObjectTransition::TAnimatableObject::~TAnimatableObject(void)
	{
		for (std::map<int, TWayPointSystemBase*>::iterator x = m_wayPointSysMap.begin(); x != m_wayPointSysMap.end(); ++x)
		{
			x->second->Release();
		}
	}

	void CMultiObjectTransition::TAnimatableObject::AddAnimationType(int aniType)
	{
		if (m_wayPointSysMap.find(aniType) != m_wayPointSysMap.end())
		{
			//ToDo: Add log for abnormal return.
			return;
		}

		GType gType;
		m_object->GetPropertyName(aniType, &gType);

		TWayPointSystemBase *wayPointSys = NULL;

		if (G_TYPE_UINT == gType)
		{
			wayPointSys = (TWayPointSystemBase*)(new TWayPointSystem<TValue1i>(m_object, aniType));
		}
		else if (G_TYPE_FLOAT == gType || G_TYPE_DOUBLE == gType)
		{
			wayPointSys = (TWayPointSystemBase*)(new TWayPointSystem<TValue1f>(m_object, aniType));
		}
		else if (CLUTTER_TYPE_POINT == gType || CLUTTER_TYPE_SIZE == gType)
		{
			wayPointSys = (TWayPointSystemBase*)(new TWayPointSystem<TValue2f>(m_object, aniType));
		}

		ASSERT(NULL != wayPointSys);

		m_wayPointSysMap.insert(std::make_pair(aniType, wayPointSys));
	}

	float CMultiObjectTransition::TAnimatableObject::AddWayPointAndGetDistance(TValueBase *val, int type)
	{
		std::map<int, TWayPointSystemBase*>::iterator x = m_wayPointSysMap.find(type);
		ASSERT(m_wayPointSysMap.end() != x);

		if (m_wayPointSysMap.end() == x)
		{
			return 0.0f;
		}
		
		return x->second->AddWayPointAndGetDistance(val, m_object);
	}

	void CMultiObjectTransition::TAnimatableObject::PopFrontWayPoint(int aniType)
	{
		std::map<int, TWayPointSystemBase*>::iterator x = m_wayPointSysMap.find(aniType);
		ASSERT(m_wayPointSysMap.end() != x);

		if (m_wayPointSysMap.end() == x)
		{
			return;
		}

		x->second->PopFrontWayPoint();
	}

	int CMultiObjectTransition::TAnimatableObject::WayPointCount(int aniType)
	{
		std::map<int, TWayPointSystemBase*>::iterator x = m_wayPointSysMap.find(aniType);
		ASSERT(m_wayPointSysMap.end() != x);

		if (m_wayPointSysMap.end() == x)
		{
			return -1;
		}

		return x->second->WayPointCount();
	}

	void CMultiObjectTransition::TAnimatableObject::ClearWayPoint(int aniType)
	{
		std::map<int, TWayPointSystemBase*>::iterator x = m_wayPointSysMap.find(aniType);
		ASSERT(m_wayPointSysMap.end() != x);

		if (m_wayPointSysMap.end() == x)
		{
			return;
		}

		x->second->ClearWayPoint();
	}

	void CMultiObjectTransition::TAnimatableObject::SetProgress(int wayPointIndex, int aniType, float progress)
	{
		std::map<int, TWayPointSystemBase*>::iterator x = m_wayPointSysMap.find(aniType);
		ASSERT(m_wayPointSysMap.end() != x);

		if (m_wayPointSysMap.end() == x)
		{
			return;
		}

		x->second->SetProgress(m_object, wayPointIndex, progress);
	}

	int CMultiObjectTransition::TAnimatableObject::CurrentWaypointCount(int aniType)
	{
		std::map<int, TWayPointSystemBase*>::iterator iter = m_wayPointSysMap.find(aniType);
		ASSERT(m_wayPointSysMap.end() != iter);

		if (m_wayPointSysMap.end() == iter)
		{
			return -1;
		}

		return iter->second->CurrentWaypointCount();
	}
}
