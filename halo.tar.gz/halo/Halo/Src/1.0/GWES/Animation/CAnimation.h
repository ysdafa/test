#ifndef _CANIMATION_H_
#define _CANIMATION_H_

namespace HALO
{
	union UValueElement
	{
		int i;
		float f;
		double d;
		void* p;
	};

	class CTimeLine : virtual public ITimeLine
	{
	public:
		CTimeLine(void) : t_timeLine(NULL), m_flagCreated(false), m_flagCustomAni(false) {};
		virtual ~CTimeLine(void);

		enum ETimeLineListenerType
		{
			EVENT_COMPLETED = 0,
			EVENT_STARTED,
			EVENT_VIA,
			EVENT_PAUSED,
			EVENT_STOPPED,
			EVENT_NEWFRAME,
			EVENT_MARKER_REACHED
		};

		virtual bool Initialize(void) {return Initialize(false);}

		virtual bool Initialize(bool flagCustomAnimation);

		virtual bool IsInitialized(void) const;

		virtual void SetDuration(int duration);

		virtual int Duration(void);

		virtual void SetMode(ClutterAnimationMode animationMode);

		virtual void AddListener(ITimeLineListener *listener, void *userData);

		virtual void RemoveListener(ITimeLineListener *listener, void* &userData);

		virtual bool IsPlaying(void);

		virtual void Play(void);

		virtual void Stop(void);

		virtual void Pause(void);

	protected:
		ClutterTimeline *t_timeLine;

		int t_duration;
		ClutterAnimationMode t_animationMode;

		void t_RegisterCallback(void);

		virtual void t_CreateSubClass(void){};

		void t_CallListener(ETimeLineListenerType type, void *data = NULL);

		static void t_StopCallback(ClutterTimeline *timeline, bool flagFinished, CTimeLine *ani);
		static void t_CompleteCallback(ClutterTimeline *timeline, CTimeLine *ani);
		static void t_StartCallback(ClutterTimeline *timeline, CTimeLine *ani);
		static void t_PauseCallback(ClutterTimeline *timeline, CTimeLine *ani);
		static void t_NewFrameCallback(ClutterTimeline *timeline, gint msecs, CTimeLine *ani);
		static void t_DestinationReachedCallback(ClutterKeyframeTransition* trans, CTimeLine *ani);

		virtual void t_OnNewFrame(ITimeLine *animation, double currentProgress) {};
		virtual void t_OnComplete(ITimeLine *animation) {};
		virtual void t_OnStop(ITimeLine *animation) {};

	private:
		bool m_flagCreated;
		bool m_flagCustomAni;

		std::map<ITimeLineListener*, void*> m_listenerMap;
	};

	class CTransition : virtual public ITransition, public CTimeLine
	{
	public:
		CTransition(void);
		virtual ~CTransition(void);

		void SetAnimatableObject(class CAnimatable *animatable);

		void SetPropertyName(const char *propertyName, GType valueType, int animatableValueType);

		char* TransitionName(void);

		ClutterTransition* Transition(void);

		void Play(void);
		void JumpToDestination(void);

		void SetDestination(int destValue);
		void SetDestination(float destValue);
		void SetDestination(float destValue1, float destValue2);

	protected:
		int t_animatableValueType;
		GType t_valueType;
		class CAnimatable *t_animatable;
		ClutterTransition *t_trans;	//Point to the t_timeLine

		bool m_flagAdded;
		bool m_flagHasDestination;
		UValueElement t_curDest;

		void t_SetFrom(void);
		virtual void t_CreateSubClass(void);

	private:
		char m_aniName[10];

		ClutterPoint m_pointDest;
		ClutterSize m_sizeDest;
	};

	class CAnimatable : virtual public IAnimatable
	{
	public:
		virtual bool BindTransition(ITransition *transition, int animationType);

		virtual void AddTransition(CTransition *transition) = 0;

		virtual void RemoveTransition(CTransition *transition) = 0;

		virtual void GetAnimatableValue(int animationType, UValueElement &val) = 0;

		virtual void SetPropertyValue(int animationType, UValueElement element) = 0;

		virtual const char* GetPropertyName(int animationType, GType *valueType) = 0;

	protected:
		virtual ClutterAnimatable *t_GetAnimatableObject(void) = 0;

		virtual bool t_AnimationIsValid(CTransition *animation, int animationType) = 0;
	};
}

#endif