#include "Halo1_0.h"

namespace HALO
{
	CTimeLine::~CTimeLine(void)
	{
		if (true == IsPlaying())
		{
			Stop();
		}

		if (true == m_flagCustomAni)
		{
			g_object_unref(t_timeLine);
		}

		m_listenerMap.clear();
	}

	bool CTimeLine::Initialize(bool flagCustomAnimation /* = false */)
	{
		HALO_ASSERT(false == IsInitialized());

		m_flagCustomAni = flagCustomAnimation;

		t_duration = 500;

		if (true == m_flagCustomAni)
		{
			t_timeLine = clutter_timeline_new(t_duration);
			t_RegisterCallback();
		}
		else
		{
			t_timeLine = NULL;
		}

		//t_duration = 0;
		t_animationMode = CLUTTER_LINEAR;

		m_flagCreated = true;

		t_CreateSubClass();

		return true;
	}

	bool CTimeLine::IsInitialized(void) const
	{
		return m_flagCreated;
	}

// 	void CTimeLine::Destroy(void)
// 	{
// 		HALO_ASSERT(true == IsInitialized());
// 
// 		if (NULL != t_timeLine)
// 		{
// 			clutter_timeline_stop(t_timeLine);
// 			g_object_unref(t_timeLine);
// 			t_timeLine = NULL;
// 		}
// 
// 		m_listenerMap.clear();
// 
// 		t_duration = 0;
// 		m_flagCreated = false;
// 	}

	void CTimeLine::SetDuration(int duration)
	{
		HALO_ASSERT(true == IsInitialized());

		if (t_duration != duration)
		{
			t_duration = duration;

			if (NULL != t_timeLine && 0 < duration)
			{
				clutter_timeline_set_duration(t_timeLine, duration);
			}
		}
	}

	int CTimeLine::Duration(void)
	{
		HALO_ASSERT(true == IsInitialized());

		int duration = -1;
		if (NULL != t_timeLine)
		{
			duration = clutter_timeline_get_duration(t_timeLine);
		}

		return duration;
	}

	void CTimeLine::SetMode(ClutterAnimationMode animationMode)
	{
		HALO_ASSERT(true == IsInitialized());

		/*switch (animationMode)
		{
		case ANI_MODE_LINEAR:
			t_animationMode = CLUTTER_LINEAR;
			break;

		case ANI_MODE_EASE_IN_QUAD:
			t_animationMode = CLUTTER_EASE_IN_QUAD;
			break;

		case ANI_MODE_EASE_OUT_QUAD:
			t_animationMode = CLUTTER_EASE_OUT_QUAD;
			break;

		case ANI_MODE_EASE_IN_OUT_QUAD:
			t_animationMode = CLUTTER_EASE_IN_OUT_QUAD;
			break;

		default:
			break;
		}*/
		t_animationMode = animationMode;
		if (NULL != t_timeLine)
		{
			clutter_timeline_set_progress_mode(t_timeLine, t_animationMode);
		}
	}

	void CTimeLine::AddListener(ITimeLineListener *listener, void *userData)
	{
		HALO_ASSERT(true == IsInitialized());
		HALO_ASSERT(NULL != listener);
		HALO_ASSERT(m_listenerMap.end() == m_listenerMap.find(listener));

		m_listenerMap.insert(std::make_pair(listener, userData));
	}

	void CTimeLine::RemoveListener(ITimeLineListener *listener, void* &userData)
	{
		HALO_ASSERT(NULL != listener);

		std::map<ITimeLineListener*, void*>::iterator x = m_listenerMap.find(listener);
		//HALO_ASSERT(m_listenerMap.end() != x);

		if (m_listenerMap.end() != x)
		{
			userData = x->second;
			m_listenerMap.erase(x);
		}
	}

	bool CTimeLine::IsPlaying(void)
	{
		HALO_ASSERT(true == IsInitialized());
		HALO_ASSERT(NULL != t_timeLine);

		return clutter_timeline_is_playing(t_timeLine) != FALSE;
	}

	void CTimeLine::Play(void)
	{
		HALO_ASSERT(true == IsInitialized());
		HALO_ASSERT(NULL != t_timeLine);

		clutter_timeline_start(t_timeLine);
	}

	void CTimeLine::Stop(void)
	{
		HALO_ASSERT(true == IsInitialized());
		HALO_ASSERT(NULL != t_timeLine);

		if (true == IsPlaying())
		{
			t_OnStop(this);
			clutter_timeline_stop(t_timeLine);
		}
	}

	void CTimeLine::Pause(void)
	{
		HALO_ASSERT(true == IsInitialized());
		HALO_ASSERT(NULL != t_timeLine);

		clutter_timeline_pause(t_timeLine);
	}

	void CTimeLine::t_RegisterCallback(void)
	{
		g_signal_connect (t_timeLine, "stopped", G_CALLBACK(t_StopCallback), this);
		g_signal_connect (t_timeLine, "completed", G_CALLBACK(t_CompleteCallback), this);
		g_signal_connect (t_timeLine, "paused", G_CALLBACK(t_PauseCallback), this);
		g_signal_connect (t_timeLine, "started", G_CALLBACK(t_StartCallback), this);
		g_signal_connect (t_timeLine, "new-frame", G_CALLBACK(t_NewFrameCallback), this);
		g_signal_connect (t_timeLine, "destination-reached", G_CALLBACK(t_DestinationReachedCallback), this);
	}

	void CTimeLine::t_CallListener(ETimeLineListenerType type, void *data /* = NULL */)
	{
		for (std::map<ITimeLineListener*, void*>::iterator x = m_listenerMap.begin(); x != m_listenerMap.end(); ++x)
		{
			ITimeLineListener *listener = x->first;

			switch (type)
			{
			case EVENT_STARTED:
				listener->OnStarted(this, x->second);
				break;

			case EVENT_VIA:
				listener->OnVia(this, x->second);
				break;

			case EVENT_COMPLETED:
				listener->OnCompleted(this, x->second);
				break;

			case EVENT_PAUSED:
				listener->OnPaused(this, x->second);
				break;

			case EVENT_STOPPED:
				{
					bool *flagFinished = (bool*)data;
					listener->OnStoped(this, *flagFinished, x->second);
				}
				break;

			case EVENT_NEWFRAME:
				{
					double *progress = (double*)data;
					listener->OnNewFrame(this, *progress, x->second);
				}
				break;

			case EVENT_MARKER_REACHED:
				break;

			default:
				break;
			}
		}
	}

	void CTimeLine::t_StopCallback(ClutterTimeline *timeline, bool flagFinished, CTimeLine *ani)
	{
		ani->t_CallListener(EVENT_STOPPED, &flagFinished);
	}

	void CTimeLine::t_CompleteCallback(ClutterTimeline *timeline, CTimeLine *ani)
	{
		ani->t_OnComplete(ani);
		ani->t_CallListener(EVENT_COMPLETED);
	}

	void CTimeLine::t_StartCallback(ClutterTimeline *timeline, CTimeLine *ani)
	{
		ani->t_CallListener(EVENT_STARTED);
	}

	void CTimeLine::t_PauseCallback(ClutterTimeline *timeline, CTimeLine *ani)
	{
		ani->t_CallListener(EVENT_PAUSED);
	}

	void CTimeLine::t_NewFrameCallback(ClutterTimeline *timeline, gint msecs, CTimeLine *ani)
	{
		double progress = clutter_timeline_get_progress(timeline);

		ani->t_OnNewFrame(ani, progress);
		ani->t_CallListener(EVENT_NEWFRAME, &progress);
	}

	void CTimeLine::t_DestinationReachedCallback(ClutterKeyframeTransition* trans, CTimeLine *ani)
	{
		if (TRUE == clutter_timeline_is_playing(CLUTTER_TIMELINE(trans)))
		{
			ani->t_CallListener(EVENT_VIA);
		}
	}
	
	CTransition::CTransition(void)
	{
		t_trans = NULL;
		t_animatable = NULL;
		m_flagAdded = false;
		m_flagHasDestination = false;

		t_curDest.p = NULL;
	}
	
	CTransition::~CTransition(void)
	{
		if (NULL != t_curDest.p)
		{
			t_curDest.p = NULL;
		}
		if (t_trans != NULL)
		{
			g_object_unref(t_trans);
		}
	}

	void CTransition::SetAnimatableObject(CAnimatable *animatable)
	{
		HALO_ASSERT(NULL != t_trans);

		if (NULL != t_trans && NULL != t_animatable && t_animatable != animatable)
		{
			m_flagAdded = false;
			t_animatable->RemoveTransition(this);
			t_curDest.p = NULL;
		}

		t_animatable = animatable;
	}

	void CTransition::SetPropertyName(const char *propertyName, GType valueType, int animatableValueType)
	{
		HALO_ASSERT(true == IsInitialized());

		if (t_valueType != valueType)
		{
			t_curDest.p = NULL;
		}

		t_valueType = valueType;
		t_animatableValueType = animatableValueType;

		if (NULL == t_trans)
		{
			t_trans = clutter_keyframe_transition_new(propertyName);

			t_timeLine = CLUTTER_TIMELINE(t_trans);

			if (0 != t_duration)
			{
				clutter_timeline_set_duration(t_timeLine, t_duration);
			}

			clutter_timeline_set_progress_mode(t_timeLine, t_animationMode);

		#ifdef WIN32
			sprintf(m_aniName, "%x", (unsigned long)this);
		#else
			snprintf(m_aniName, 10, "%x", (unsigned long)this);
		#endif
			t_RegisterCallback();
		}
		else
		{
			clutter_timeline_stop(t_timeLine);
			clutter_property_transition_set_property_name(CLUTTER_PROPERTY_TRANSITION(t_trans), propertyName);
		}
	}

	char* CTransition::TransitionName(void)
	{
		return m_aniName;
	}

	ClutterTransition* CTransition::Transition(void)
	{
		return t_trans;
	}

	void CTransition::Play(void)
	{
		if (0 == t_duration)
		{
			JumpToDestination();
		}
		else
		{
			if (false == m_flagAdded)
			{
				t_animatable->AddTransition(this);
				m_flagAdded = true;
			}
			else
			{
				if (false == CTimeLine::IsPlaying())
				{
					CTimeLine::Play();
				}
			}
		}
	}

	void CTransition::JumpToDestination(void)
	{
		if (true == m_flagHasDestination)
		{
			t_StartCallback(t_timeLine, this);
			t_animatable->SetPropertyValue(t_animatableValueType, t_curDest);
			t_CompleteCallback(t_timeLine, this);
			t_StopCallback(t_timeLine, true, this);
		}
	}

	void CTransition::SetDestination(int destValue)
	{
		if (TRUE == clutter_timeline_is_playing(t_timeLine))
		{
			if (t_curDest.i == destValue)
			{
				return;
			}
		}

		m_flagHasDestination = true;

		if (0 != t_duration)
		{
			clutter_timeline_set_duration(t_timeLine, t_duration);
		}

		t_SetFrom();

		t_curDest.i = destValue;
		clutter_transition_set_to(t_trans, t_valueType, t_curDest);
	}

	void CTransition::SetDestination(float destValue)
	{
		if (TRUE == clutter_timeline_is_playing(t_timeLine))
		{
			if (t_curDest.d == destValue)
			{
				return;
			}
		}

		m_flagHasDestination = true;

		if (0 != t_duration)
		{
			clutter_timeline_set_duration(t_timeLine, t_duration);
		}

		t_SetFrom();

		t_curDest.d = destValue;
		clutter_transition_set_to(t_trans, t_valueType, t_curDest);
	}

	void CTransition::SetDestination(float destValue1, float destValue2)
	{
		if (TRUE == clutter_timeline_is_playing(t_timeLine))
		{
			if (CLUTTER_TYPE_POINT == t_valueType)
			{
				if (m_curVal.pointVal.x == destValue1 && m_curVal.pointVal.y == destValue2)
				{
					return;
				}
			}
			else if (CLUTTER_TYPE_SIZE == t_valueType)
			{
				if (m_curVal.sizeVal.width == destValue1 && m_curVal.sizeVal.height == destValue2)
				{
					return;
				}
			}
		}

		m_flagHasDestination = true;

		if (0 != t_duration)
		{
			clutter_timeline_set_duration(t_timeLine, t_duration);
		}

		t_SetFrom();

		if (CLUTTER_TYPE_POINT == t_valueType)
		{
			clutter_point_init(&m_curVal.pointVal, destValue1, destValue2);
			clutter_transition_set_to(t_trans, CLUTTER_TYPE_POINT, t_curDest);
		}
		else if (CLUTTER_TYPE_SIZE == t_valueType)
		{
			clutter_size_init(&m_curVal.sizeVal, destValue1, destValue2);
			clutter_transition_set_to(t_trans, CLUTTER_TYPE_SIZE, t_curDest);
		}
	}

	void CTransition::t_CreateSubClass(void)
	{
		t_trans = NULL;
		t_animatable = NULL;
		m_flagAdded = false;

		t_curDest.p = NULL;
	}

	void CTransition::t_SetFrom(void)
	{
		if (false == clutter_timeline_is_playing(t_timeLine))
		{
			if (NULL == t_curDest.p)
			{
				t_curDest.p = &m_curVal;
			}

			t_animatable->GetAnimatableValue(t_animatableValueType, t_curDest);
			clutter_transition_set_from(t_trans, t_valueType, t_curDest);
		}
	}

	bool CAnimatable::BindTransition(ITransition *animation, int animationType)
	{
		CTransition *ani = dynamic_cast<CTransition*>(animation);
		if (NULL == ani)
		{
			return false;
		}
		bool flagValid = t_AnimationIsValid(ani, animationType);
		HALO_ASSERT(true == flagValid);

		if (true == flagValid)
		{
			GType clutterValueType;
			const char* propertyName = GetPropertyName(animationType, &clutterValueType);
			if (NULL != propertyName)
			{
				ani->SetPropertyName(propertyName, clutterValueType, animationType);
			}

			ani->SetAnimatableObject(this);
		}

		return true;
	}
}
