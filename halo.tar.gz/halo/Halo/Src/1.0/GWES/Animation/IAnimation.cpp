#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	ITimeLine* ITimeLine::CreateInstance(bool flagCustomAnimation)
	{
		CTimeLine* timeLine = dynamic_cast<CTimeLine*>(Instance::CreateInstance(CLASS_ID_ITIMELINE));

		if (NULL != timeLine)
		{
			timeLine->Initialize(flagCustomAnimation);
		}

		return timeLine;
	}

	ITransition* ITransition::CreateInstance(void)
	{
		CTransition* transition = dynamic_cast<CTransition*>(Instance::CreateInstance(CLASS_ID_ITRANSITION));

		if (NULL != transition)
		{
			transition->CTimeLine::Initialize();
		}

		return transition;
	}
}