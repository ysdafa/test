#ifndef _CMULTIOBJECTTRANSITION_H_
#define _CMULTIOBJECTTRANSITION_H_

namespace HALO
{
	class CMultiObjectTransition : public CTimeLine
	{
	public:
		CMultiObjectTransition(void);
		virtual ~CMultiObjectTransition(void);

		bool Initialize(void) 
		{
			return CTimeLine::Initialize(true);
		}

		void AddAnimatableObject(IAnimatable *object, int animationType);

		void SetDestination(IAnimatable *object, int aniType, TValueBase &dest);
		void SetDestination(IAnimatable *object, int aniType, TValueBase *dest);

		void Play(void);
		void StopAndJump(bool flagJumpToDest);

		void JumpToDestination(void);

	protected:
		void t_OnNewFrame(ITimeLine *animation, double currentProgress);
		void t_OnComplete(ITimeLine *animation);
		void t_OnStop(ITimeLine *animation);

	private:
		struct TWayPointSystemBase
		{
			virtual void Release(void) = 0;
			virtual float AddWayPointAndGetDistance(TValueBase *val, CAnimatable *object) = 0;
			virtual void PopFrontWayPoint(void) = 0;
			virtual int WayPointCount(void) = 0;
			virtual void ClearWayPoint(void) = 0;
			virtual void SetProgress(CAnimatable *object, int wayPointIndex, float progress) = 0;
			virtual int CurrentWaypointCount(void) = 0;
		};

		template <typename T>
		struct TWayPointSystem : public TWayPointSystemBase
		{
		public:
			TWayPointSystem(CAnimatable *inObject, int type);
			virtual ~TWayPointSystem(void);

			void Release(void)
			{
				delete this;
			}

			float AddWayPointAndGetDistance(TValueBase *val, CAnimatable *object);
			void PopFrontWayPoint(void);
			int WayPointCount(void)
			{
				return m_wayPointList.size();
			}

			void ClearWayPoint(void);

			void SetProgress(CAnimatable *object, int wayPointIndex, float progress);

			int CurrentWaypointCount(void)
			{
				return (int)m_wayPointList.size();
			}

		protected:

		private:
			int m_animationType;

			struct TWayPoint
			{
				TWayPoint(void)
				{
					distanceToNext = 0.0f;
				}

				float distanceToNext;
				T rakeRatio;
				T valueList;
			};

			GType m_clutterValueType;
			std::deque<TWayPoint> m_wayPointList;

			TWayPoint m_nextWayPoint;

			float m_AddWayPointAndGetDistance(CAnimatable *object, const TWayPoint &point);
		};

		struct TAnimatableObject
		{
		public:
			TAnimatableObject(CAnimatable *inObject);
			virtual ~TAnimatableObject(void);

			void AddAnimationType(int aniType);

			float AddWayPointAndGetDistance(TValueBase *val, int type);

			void PopFrontWayPoint(int aniType);

			int WayPointCount(int aniType);

			void ClearWayPoint(int aniType);

			void SetProgress(int wayPointIndex, int aniType, float progress);

			int CurrentWaypointCount(int aniType);

		protected:

		private:
			CAnimatable *m_object;

			std::map<int, TWayPointSystemBase*> m_wayPointSysMap;
		};

		std::map<CAnimatable*, TAnimatableObject*> m_objectMap;

		float m_currentPos;
		float m_startPos;
		float m_totalDistance;
		float m_popedDistance;
		bool m_flagNeedAllocNewObjInfo;

		struct TAniObjInfo
		{
			TAnimatableObject *object;
			int aniType;
		};

		std::deque<std::vector<TAniObjInfo*>*> m_usedObjList;

		int m_totalDestinationCount;
	};
}

#endif