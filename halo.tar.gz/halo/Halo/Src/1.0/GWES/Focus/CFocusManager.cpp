#include "Halo1_0.h"

static HALO::util::Logger LOGGER("FocusManager");

namespace HALO
{
	CFocusManager::CFocusManager() : m_pFocusableWindow(NULL), m_flagEnabled(true), m_FocusStackPrintCount(10)
	{

	}

	CFocusManager::~CFocusManager()
	{			
		m_pPreFocusableWindowList.clear();
	
		m_pFocusableWindow = NULL;
	}

	CFocusManager* CFocusManager::GetInstance(void)
	{
		//H_LOG_TRACE(LOGGER, "CFocusManager::GetInstance ");
		static CFocusManager s_FocusMgr;
		return &s_FocusMgr;
	}

	void CFocusManager::Enable(bool flagEnable)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::Enable(" << flagEnable << ")");
		m_flagEnabled = flagEnable;
	}

	bool CFocusManager::IsEnabled(void)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::IsEnabled: m_flagEnabled = " << m_flagEnabled);
		return m_flagEnabled;
	}

	void CFocusManager::m_SetFocusedWindow(CWidgetExtension* pWin)
	{
		//H_LOG_TRACE(LOGGER, "CFocusManager::m_SetFocusedWindow(" << pWin << ")");
		m_pFocusableWindow = pWin;
	}
	
	CWidgetExtension* CFocusManager::FocusedWindow(void)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::FocusedWindow: m_pFocusableWindow = " << m_pFocusableWindow);
		return m_pFocusableWindow;
	}

	bool CFocusManager::m_SavePreFocusedWindow(CWidgetExtension* pWin)
	{
		//H_LOG_TRACE(LOGGER, "CFocusManager::m_SavePreFocusedWindow(" << pWin << ")");
		bool ret = false;

		if (pWin)
		{		
			m_pPreFocusableWindowList.push_front(pWin);
			
			ret = true;
		}

		return ret;
	}

	CWidgetExtension* CFocusManager::m_PopPreFocusedWindow(void)
	{
		//H_LOG_TRACE(LOGGER, "CFocusManager::m_PopPreFocusedWindow");
		CWidgetExtension* pPreFocusableWindow = NULL;

		if (!m_pPreFocusableWindowList.empty())
		{
			pPreFocusableWindow = m_pPreFocusableWindowList.front();
			m_pPreFocusableWindowList.pop_front();
		}

		return pPreFocusableWindow;
	}

	void CFocusManager::m_DeleteFocusedWindow(CWidgetExtension* pWin)
	{
		if (pWin == NULL)
		{
			return;
		}
		else
		{
			m_pPreFocusableWindowList.remove(pWin);
		}
	}

	void CFocusManager::SetFocusBySignal(CWidgetExtension* pThis)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::SetFocusBySignal(" << pThis << ")");
		if (!IsEnabled())
		{
			return;
		}

		HALO_ASSERT(pThis);
		
		CWidgetExtension* pCurFocusWindow = FocusedWindow();

		if (pCurFocusWindow)
		{	
			CFocusEvent focusOutEvent(EVENT_FOCUSOUT);
			pCurFocusWindow->OnEvent(&focusOutEvent);
		}

		m_SetFocusedWindow(pThis);

		CFocusEvent focusInEvent(EVENT_FOCUSIN);
		pThis->OnEvent(&focusInEvent);
		PrintFocusStack();
	}

	void CFocusManager::KillFocusBySignal(CWidgetExtension* pThis)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::KillFocusBySignal(" << pThis << ")");
		if (!IsEnabled())
		{
			return;
		}

		HALO_ASSERT(pThis);

		m_SetFocusedWindow(NULL);

		CFocusEvent focusOutEvent(EVENT_FOCUSOUT);
		pThis->OnEvent(&focusOutEvent);
		PrintFocusStack();
		H_LOG_WARN(LOGGER, "!!!Warning!!!----Halo focus is grabbed by Volt or Clutter or stage focus out.----");
	}

	void CFocusManager::ChangeFocusBySet(CWidgetExtension* pThis)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::ChangeFocusBySet(" << pThis << ")");
		if (!IsEnabled())
		{
			return;
		}
		
		HALO_ASSERT(pThis);

		CWidgetExtension* pNextFocusableWindow = pThis;
		CWidgetExtension* pPreFocusableWindow = FocusedWindow();

		if (pNextFocusableWindow != pPreFocusableWindow)  //last focused window
		{
			m_SetFocusedWindow(pNextFocusableWindow);
			m_SavePreFocusedWindow(pPreFocusableWindow);

			if (pPreFocusableWindow)
			{ 
				CFocusEvent focusOutEvent(EVENT_FOCUSOUT);
				focusOutEvent.SetEventType("samsung.tv.halo.input.focus");
				focusOutEvent.SetReceiver(pPreFocusableWindow);
				
				IEventManager* pEventManager = IEventManager::GetInstance();
				if (pEventManager)
				{
					pEventManager->SendEventLocal(&focusOutEvent);	
				}
			}

			CFocusEvent focusInEvent(EVENT_FOCUSIN);
			focusInEvent.SetEventType("samsung.tv.halo.input.focus");
			focusInEvent.SetReceiver(pNextFocusableWindow);
			
			IEventManager* pEventManager = IEventManager::GetInstance();
			if (pEventManager)
			{
				pEventManager->SendEventLocal(&focusInEvent);	
			}

			clutter_actor_grab_key_focus(pNextFocusableWindow->Actor());
			PrintFocusStack();
		}	
	}

	void CFocusManager::ChangeFocusByKill(CWidgetExtension* pThis, bool bAutoFocus)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::ChangeFocusByKill(" << pThis << ", " << bAutoFocus << ")");
		if (!IsEnabled())
		{
			return;
		}
	
		if (pThis == NULL)
		{
			return;
		}
		else
		{
			CWidgetExtension* pFocusableWindow = FocusedWindow();

			if (pFocusableWindow == pThis)
			{
				if (bAutoFocus)
				{
					CWidgetExtension* pNextFocusableWindow = NULL;

					pNextFocusableWindow = m_PopPreFocusedWindow();

					while (pNextFocusableWindow)
					{
						if (CLUTTER_ACTOR_IS_VISIBLE(pNextFocusableWindow->Actor()) && pNextFocusableWindow->IsFocusEnabled() && pNextFocusableWindow != pThis)
						{	
							break;
						}
						else
						{
							pNextFocusableWindow = m_PopPreFocusedWindow();	
						}
					}

					m_SetFocusedWindow(pNextFocusableWindow);

					if (pFocusableWindow)
					{	
						CFocusEvent focusOutEvent(EVENT_FOCUSOUT);
						focusOutEvent.SetEventType("samsung.tv.halo.input.focus");
						focusOutEvent.SetReceiver(dynamic_cast<CActor*>(pFocusableWindow));
						
						IEventManager* pEventManager = IEventManager::GetInstance();
						if (pEventManager)
						{
							pEventManager->SendEventLocal(&focusOutEvent);	
						}
					}

					if (pNextFocusableWindow)
					{
						CFocusEvent focusInEvent(EVENT_FOCUSIN);
						focusInEvent.SetEventType("samsung.tv.halo.input.focus");
						focusInEvent.SetReceiver(dynamic_cast<CActor*>(pNextFocusableWindow));
						
						IEventManager* pEventManager = IEventManager::GetInstance();
						if (pEventManager)
						{
							pEventManager->SendEventLocal(&focusInEvent);	
						}

						clutter_actor_grab_key_focus(pNextFocusableWindow->Actor());
					}
					else
					{
						IStage* stage = IStage::GetInstance();
						clutter_actor_grab_key_focus(stage->Stage());
					}
				}
				else
				{
					m_SetFocusedWindow(NULL);

					if (pFocusableWindow)
					{
						CFocusEvent focusOutEvent(EVENT_FOCUSOUT);
						focusOutEvent.SetEventType("samsung.tv.halo.input.focus");
						focusOutEvent.SetReceiver(dynamic_cast<CActor*>(pFocusableWindow));
						
						IEventManager* pEventManager = IEventManager::GetInstance();
						if (pEventManager)
						{
							pEventManager->SendEventLocal(&focusOutEvent);	
						}
						
						IStage* stage = IStage::GetInstance();
						clutter_actor_grab_key_focus(stage->Stage());
					}
				}
				PrintFocusStack();
			}
		}	
	}

	void CFocusManager::ChangeFocusByUnviewable(CWidgetExtension* pThis, bool bAutoFocus)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::ChangeFocusByUnviewable(" << pThis << ", " << bAutoFocus << ")");
		if (!IsEnabled())
		{
			return;
		}

		if (pThis == NULL)
		{
			return;
		}
		else
		{
			m_DeleteFocusedWindow(pThis);

			CWidgetExtension* pFocusableWindow = FocusedWindow();
			
			if (pFocusableWindow == pThis || pThis->IsAncestor(pFocusableWindow))
			{
				if (bAutoFocus)
				{
					CWidgetExtension* pNextFocusableWindow = NULL;

					pNextFocusableWindow = m_PopPreFocusedWindow();

					while (pNextFocusableWindow)
					{
						if (CLUTTER_ACTOR_IS_VISIBLE(pNextFocusableWindow->Actor()) && pNextFocusableWindow->IsFocusEnabled() && pNextFocusableWindow != pThis && !pThis->IsAncestor(pNextFocusableWindow))
						{	
							break;
						}
						else
						{
							pNextFocusableWindow = m_PopPreFocusedWindow();	
						}
					}

					m_SetFocusedWindow(pNextFocusableWindow);

					if (pNextFocusableWindow)
					{
						CFocusEvent focusInEvent(EVENT_FOCUSIN);
						focusInEvent.SetEventType("samsung.tv.halo.input.focus");
						focusInEvent.SetReceiver(dynamic_cast<CActor*>(pNextFocusableWindow));
						
						IEventManager* pEventManager = IEventManager::GetInstance();
						if (pEventManager)
						{
							pEventManager->SendEventLocal(&focusInEvent);	
						}

						clutter_actor_grab_key_focus(pNextFocusableWindow->Actor());
					}
					else
					{
						IStage* stage = IStage::GetInstance();
						clutter_actor_grab_key_focus(stage->Stage());
					}
				}
				else
				{
					m_SetFocusedWindow(NULL);

					IStage* stage = IStage::GetInstance();
					clutter_actor_grab_key_focus(stage->Stage());
				}
				PrintFocusStack();
			}
		}
	}

	void CFocusManager::PrintFocusStack(void)
	{
		H_LOG_TRACE(LOGGER, "----------Focus Stack Begin----------");
		if (m_pFocusableWindow)
		{
			H_LOG_TRACE(LOGGER, "          Current Focus: " << m_pFocusableWindow << "-" << m_pFocusableWindow->GetActorType());
		}
		else 
		{ 
			H_LOG_TRACE(LOGGER, "          Current Focus: "  << "NULL" );
		}
		int historyFocusCount = m_pPreFocusableWindowList.size();
		H_LOG_TRACE(LOGGER, "          History Focus: " << historyFocusCount);
		if (historyFocusCount > 0)
		{
			std::list<CWidgetExtension*>::iterator itor = m_pPreFocusableWindowList.begin();
			for (int i = 0; i < m_FocusStackPrintCount && itor != m_pPreFocusableWindowList.end(); itor++, i++)
			{
				H_LOG_TRACE(LOGGER, "                         " << historyFocusCount-- << ":" << *itor << "-" << (*itor)->GetActorType());
			}
		}
		H_LOG_TRACE(LOGGER, "----------Focus Stack End  ----------");
	}
}