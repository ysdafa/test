#include "Halo1_0.h"

static HALO::util::Logger LOGGER("FocusManager");

namespace HALO
{
	CFocusManager::CFocusManager() : m_pFocusableWindow (NULL), m_flagEnabled (true)
	{

	}

	CFocusManager::~CFocusManager()
	{			
		m_pPreFocusableWindowList.clear();
	
		m_pFocusableWindow = NULL;
	}

	CFocusManager* CFocusManager::GetInstance(void)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::GetInstance ");
		static CFocusManager s_FocusMgr;
		return &s_FocusMgr;
	}

	void CFocusManager::Enable(bool flagEnable)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::Enable(" << flagEnable << ")");
		m_flagEnabled = flagEnable;
	}

	bool CFocusManager::IsEnabled(void)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::IsEnabled: m_flagEnabled = " << m_flagEnabled);
		return m_flagEnabled;
	}

	void CFocusManager::m_SetFocusedWindow(CActor* pWin)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::m_SetFocusedWindow(" << pWin << ")");
		m_pFocusableWindow = pWin;
	}
	
	CActor* CFocusManager::FocusedWindow(void)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::FocusedWindow: m_pFocusableWindow = " << m_pFocusableWindow);
		return m_pFocusableWindow;
	}

	bool CFocusManager::m_SavePreFocusedWindow(CActor* pWin)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::m_SavePreFocusedWindow(" << pWin << ")");
		bool ret = false;

		if (pWin)
		{		
			m_pPreFocusableWindowList.push_front(pWin);
			
			ret = true;
		}

		return ret;
	}

	CActor* CFocusManager::m_PopPreFocusedWindow(void)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::m_PopPreFocusedWindow");
		CActor* pPreFocusableWindow = NULL;

		if (!m_pPreFocusableWindowList.empty())
		{
			pPreFocusableWindow = m_pPreFocusableWindowList.front();
			m_pPreFocusableWindowList.pop_front();
		}

		return pPreFocusableWindow;
	}

	void CFocusManager::m_DeleteFocusedWindow(CActor* pWin)
	{
		if (pWin == NULL)
		{
			return;
		}
		else
		{
			m_pPreFocusableWindowList.remove(pWin);
		}
	}

	void CFocusManager::SetFocusBySignal(CActor* pThis)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::SetFocusBySignal(" << pThis << ")");
		if (!IsEnabled())
		{
			return;
		}

		ASSERT(pThis);
		
		CActor* pCurFocusWindow = FocusedWindow();

		if (pCurFocusWindow)
		{	
			CFocusEvent focusOutEvent(EVENT_FOCUSOUT);
			pCurFocusWindow->OnEvent(&focusOutEvent);
		}

		m_SetFocusedWindow(pThis);

		CFocusEvent focusInEvent(EVENT_FOCUSIN);
		pThis->OnEvent(&focusInEvent);
	}

	void CFocusManager::KillFocusBySignal(CActor* pThis)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::KillFocusBySignal(" << pThis << ")");
		if (!IsEnabled())
		{
			return;
		}

		ASSERT(pThis);

		m_SetFocusedWindow(NULL);

		CFocusEvent focusOutEvent(EVENT_FOCUSOUT);
		pThis->OnEvent(&focusOutEvent);
	}

	void CFocusManager::ChangeFocusBySet(CActor* pThis)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::ChangeFocusBySet(" << pThis << ")");
		if (!IsEnabled())
		{
			return;
		}
		
		ASSERT(pThis);

		CActor* pNextFocusableWindow = pThis;
		CActor* pPreFocusableWindow = FocusedWindow();

		if (pNextFocusableWindow != pPreFocusableWindow)  //last focused window
		{
			m_SetFocusedWindow(pNextFocusableWindow);
			m_SavePreFocusedWindow(pPreFocusableWindow);

			if (pPreFocusableWindow)
			{ 
				CFocusEvent focusOutEvent(EVENT_FOCUSOUT);
				pPreFocusableWindow->OnEvent(&focusOutEvent);
			}

			CFocusEvent focusInEvent(EVENT_FOCUSIN);
			pNextFocusableWindow->OnEvent(&focusInEvent);
			clutter_actor_grab_key_focus(pNextFocusableWindow->Actor());
		}	
	}

	void CFocusManager::ChangeFocusByKill(CActor* pThis, bool bAutoFocus)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::ChangeFocusByKill(" << pThis << ", " << bAutoFocus << ")");
		if (!IsEnabled())
		{
			return;
		}
	
		if (pThis == NULL)
		{
			return;
		}
		else
		{
			CActor* pFocusableWindow = FocusedWindow();

			if (pFocusableWindow == pThis)
			{
				if (bAutoFocus)
				{
					CActor* pNextFocusableWindow = NULL;

					pNextFocusableWindow = m_PopPreFocusedWindow();

					while (pNextFocusableWindow)
					{
						if (CLUTTER_ACTOR_IS_VISIBLE(pNextFocusableWindow->Actor()) && pNextFocusableWindow->IsFocusEnabled() && pNextFocusableWindow != pThis)
						{	
							break;
						}
						else
						{
							pNextFocusableWindow = m_PopPreFocusedWindow();	
						}
					}

					m_SetFocusedWindow(pNextFocusableWindow);

					if (pFocusableWindow)
					{	
						CFocusEvent focusOutEvent(EVENT_FOCUSOUT);
						pFocusableWindow->OnEvent(&focusOutEvent);
					}

					if (pNextFocusableWindow)
					{
						CFocusEvent focusInEvent(EVENT_FOCUSIN);
						pNextFocusableWindow->OnEvent(&focusInEvent);
						clutter_actor_grab_key_focus(pNextFocusableWindow->Actor());
					}
					else
					{
						IStage* stage = IStage::GetInstance();
						clutter_actor_grab_key_focus(stage->Stage());
					}
				}
				else
				{
					m_SetFocusedWindow(NULL);

					if (pFocusableWindow)
					{
						CFocusEvent focusOutEvent(EVENT_FOCUSOUT);
						pFocusableWindow->OnEvent(&focusOutEvent);
						clutter_actor_grab_key_focus(NULL);
					}
				}
			}
		}	
	}

	void CFocusManager::ChangeFocusByUnviewable(CActor* pThis, bool bAutoFocus)
	{
		H_LOG_TRACE(LOGGER, "CFocusManager::ChangeFocusByUnviewable(" << pThis << ", " << bAutoFocus << ")");
		if (!IsEnabled())
		{
			return;
		}

		if (pThis == NULL)
		{
			return;
		}
		else
		{
			m_DeleteFocusedWindow(pThis);

			CActor* pFocusableWindow = FocusedWindow();
			
			if (pFocusableWindow == pThis || pThis->IsAncestor(pFocusableWindow))
			{
				if (bAutoFocus)
				{
					CActor* pNextFocusableWindow = NULL;

					pNextFocusableWindow = m_PopPreFocusedWindow();

					while (pNextFocusableWindow)
					{
						if (CLUTTER_ACTOR_IS_VISIBLE(pNextFocusableWindow->Actor()) && pNextFocusableWindow->IsFocusEnabled() && pNextFocusableWindow != pThis && !pThis->IsAncestor(pNextFocusableWindow))
						{	
							break;
						}
						else
						{
							pNextFocusableWindow = m_PopPreFocusedWindow();	
						}
					}

					m_SetFocusedWindow(pNextFocusableWindow);

					if (pNextFocusableWindow)
					{
						CFocusEvent focusInEvent(EVENT_FOCUSIN);
						pNextFocusableWindow->OnEvent(&focusInEvent);
						clutter_actor_grab_key_focus(pNextFocusableWindow->Actor());
					}
					else
					{
						IStage* stage = IStage::GetInstance();
						clutter_actor_grab_key_focus(stage->Stage());
					}
				}
				else
				{
					m_SetFocusedWindow(NULL);

					IStage* stage = IStage::GetInstance();
					clutter_actor_grab_key_focus(stage->Stage());;
				}
			}
		}
	}
}