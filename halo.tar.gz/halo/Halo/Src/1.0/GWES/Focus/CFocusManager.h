#ifndef _CFOCUSMANAGER_H_
#define _CFOCUSMANAGER_H_

namespace HALO
{
	class CFocusManager
	{
	public:
		static CFocusManager* GetInstance(void);

		void ChangeFocusBySet(CWidgetExtension* pThis);
		void ChangeFocusByKill(CWidgetExtension* pThis, bool bAutoFocus);
		void ChangeFocusByUnviewable(CWidgetExtension* pThis, bool bAutoFocus);

		//! Sets whether the focusmanager can manage the focus
		void Enable(bool flagEnable);
		//! Checks whether the focusmanager can manage the focus
		bool IsEnabled(void);

		void SetFocusBySignal(CWidgetExtension* pThis);
		void KillFocusBySignal(CWidgetExtension* pThis);
		
		CWidgetExtension* FocusedWindow(void);	
		void PrintFocusStack(void);

	private:
		CFocusManager();
		~CFocusManager();

		CFocusManager(const CFocusManager &);
		CFocusManager & operator = (const CFocusManager &);

		void m_DeleteFocusedWindow(CWidgetExtension* pWin);
	    void m_SetFocusedWindow(CWidgetExtension* pWin);
		bool m_SavePreFocusedWindow(CWidgetExtension* pWin);
		CWidgetExtension* m_PopPreFocusedWindow(void);

	private:
		bool  m_flagEnabled;
		CWidgetExtension* m_pFocusableWindow;
		
		std::list<CWidgetExtension*> m_pPreFocusableWindowList;			
		int m_FocusStackPrintCount;
	};
}
#endif /* _CFOCUSMANAGER_H_ */