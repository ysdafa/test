#ifndef _CFOCUSMANAGER_H_
#define _CFOCUSMANAGER_H_

namespace HALO
{
	class CFocusManager
	{
	public:
		static CFocusManager* GetInstance(void);

		void ChangeFocusBySet(CActor* pThis);
		void ChangeFocusByKill(CActor* pThis, bool bAutoFocus);
		void ChangeFocusByUnviewable(CActor* pThis, bool bAutoFocus);

		//! Sets whether the focusmanager can manage the focus
		void Enable(bool flagEnable);
		//! Checks whether the focusmanager can manage the focus
		bool IsEnabled(void);

		void SetFocusBySignal(CActor* pThis);
		void KillFocusBySignal(CActor* pThis);
		
		CActor* FocusedWindow(void);	

	private:
		CFocusManager();
		~CFocusManager();

		CFocusManager(const CFocusManager &);
		CFocusManager & operator = (const CFocusManager &);

		void m_DeleteFocusedWindow(CActor* pWin);
	    void m_SetFocusedWindow(CActor* pWin);
		bool m_SavePreFocusedWindow(CActor* pWin);
		CActor* m_PopPreFocusedWindow(void);

	private:
		bool  m_flagEnabled;
		CActor* m_pFocusableWindow;
		
		std::list<CActor*> m_pPreFocusableWindowList;			
	};
}
#endif /* _CFOCUSMANAGER_H_ */