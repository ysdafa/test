#include "Halo1_0.h"

#ifdef _WIN32
#include <winuser.h>
#else
namespace HALO { 
#include <X11/X.h> 
#include <X11/Xlib.h> 
#include <X11/Xutil.h> 
}
#endif

static HALO::util::Logger LOGGER("Device");

namespace HALO
{
	CDevice::CDevice(ClutterInputDevice* clutterInputDevice) : m_deviceType(0), m_deviceId(0), m_deviceName(NULL), t_clutterInputDevice(clutterInputDevice)
	{
	}

	CDevice::~CDevice()
	{
		if (m_deviceName)
		{
			delete [] m_deviceName;
			m_deviceName = NULL;
		}
	}

	int CDevice::DeviceType(void) 
	{
		H_LOG_TRACE(LOGGER, "CDevice::DeviceType m_deviceType =" << m_deviceType);
		return  m_deviceType;
	}

	int CDevice::DeviceId(void) 
	{
		H_LOG_TRACE(LOGGER, "CDevice::DeviceId m_deviceId = " << m_deviceId);
		return  m_deviceId;
	}

	char* CDevice::DeviceName(void) 
	{
		H_LOG_TRACE(LOGGER, "CDevice::DeviceId m_deviceName = " << m_deviceName);
		return  m_deviceName;
	}

	ClutterInputDevice* CDevice::InputDevice()
	{
		H_LOG_TRACE(LOGGER, "CDevice::InputDevice t_clutterInputDevice = " << t_clutterInputDevice);
		return t_clutterInputDevice;
	}

	void CDevice::SetDeviceType(int deviceType) 
	{
		H_LOG_TRACE(LOGGER, "CDevice::SetDeviceType(" << deviceType << ")");
		m_deviceType = deviceType;
	}

	void CDevice::SetDeviceId(int deviceId)
	{
		H_LOG_TRACE(LOGGER, "CDevice::SetDeviceId(" << deviceId << ")");
		m_deviceId = deviceId;
	}

	void CDevice::SetDeviceName(const char* deviceName) 
	{ 
		H_LOG_TRACE(LOGGER, "CDevice::SetDeviceName(" << deviceName << ")");
		int len = strlen(deviceName);
		m_deviceName = new char[len+1];
		memset(m_deviceName, 0, len+1);
		memcpy(m_deviceName, deviceName, len);
	}

	//!CMouseDevice
	CMouseDevice::CMouseDevice(ClutterInputDevice* clutterInputDevice) : CDevice(clutterInputDevice)
	{
	}
	void CMouseDevice::SetPointerSensibility(int level)
	{
		H_LOG_TRACE(LOGGER, "CMouseDevice::SetPointerSensibility(" << level << ")");
		m_pointerSensibilityLevel = level;
	}

	int CMouseDevice::PointerSensibility( void )
	{
		H_LOG_TRACE(LOGGER, "CMouseDevice::PointerSensibility m_pointerSensibilityLevel = " << m_pointerSensibilityLevel);
		return m_pointerSensibilityLevel;
	}

	void CMouseDevice::SetMouseOption(CMouseDevice::EMouseOption optionType, int optionValue)
	{
		H_LOG_TRACE(LOGGER, "CMouseDevice::SetMouseOption(" << optionType <<", " << optionValue << ")");
		ASSERT(optionType < MOUSE_OPTION_MAX);
	
		m_mouseOption[optionType] = optionValue;
	}

	int CMouseDevice::MouseOption(int optionType)
	{
		H_LOG_TRACE(LOGGER, "CMouseDevice::MouseOption optionType = " << optionType);
		ASSERT(optionType < MOUSE_OPTION_MAX);
	
		return m_mouseOption[optionType];
	}

	bool CMouseDevice::GetMousePoint(ClutterPoint* clutterPoint)
	{		
		H_LOG_TRACE(LOGGER, "CMouseDevice::GetMousePoint");
		ASSERT(clutterPoint != NULL);
#ifdef WIN32
		POINT point;
		GetCursorPos(&point);
		clutterPoint->x = point.x;
		clutterPoint->y = point.y;
#else
		Display* display = XOpenDisplay(NULL);
		Window fromRootWindow, childWindow, rootWindow;
		int x = -1; 
		int y = -1; 
		int tmp = -1;
		unsigned int utmp = 0;

		rootWindow = DefaultRootWindow(display);

		XQueryPointer(display, rootWindow, &fromRootWindow, &childWindow, &x, &y, &tmp, &tmp, &utmp);

		clutterPoint->x = x;
		clutterPoint->y = y;

		XCloseDisplay(display);
#endif
		H_LOG_TRACE(LOGGER, "CMouseDevice::GetMousePoint point->x = " << clutterPoint->x << ", point->y = " << clutterPoint->y);
		return true;
	}
	void CMouseDevice::MoveMousePoint(long offsetX, long offsetY)
	{
		H_LOG_TRACE(LOGGER, "CMouseDevice::MoveMousePoint(" << offsetX << ", " << offsetY << ")");
#ifdef WIN32
		POINT point;
		GetCursorPos(&point);
		g_message("x = %f, y = %f", point.x, point.y);
		SetCursorPos(point.x + offsetX, point.y + offsetY);
#else
		Display* display = XOpenDisplay(NULL);
		Window fromRootWindow, childWindow, rootWindow;
		int x = -1; 
		int y = -1; 
		int tmp = -1;
		unsigned int utmp = 0;

		rootWindow = DefaultRootWindow(display);

		XQueryPointer(display, rootWindow, &fromRootWindow, &childWindow, &x, &y, &tmp, &tmp, &utmp);

		XWarpPointer(display, None, rootWindow, 0, 0, 0, 0, x+offsetX, y+offsetY);
		XFlush(display);
		XCloseDisplay(display);
#endif
	}

	//!CKeyboardDevice
	CKeyboardDevice::CKeyboardDevice(ClutterInputDevice* clutterInputDevice) : CDevice(clutterInputDevice)
	{
	}
	void CKeyboardDevice::SetKeyboardOption(EKeyboardOption optionType , int optionValue)
	{
		H_LOG_TRACE(LOGGER, "CKeyboardDevice::SetKeyboardOption(" << optionType << ", " << optionValue << ")");
		ASSERT( optionType < KEYBOARD_OPTION_MAX );
	
		m_keyboardOption[optionType] = optionValue;
	}

	int CKeyboardDevice::KeyboardOption(int optionType)
	{
		H_LOG_TRACE(LOGGER, "CKeyboardDevice::KeyboardOption optionType = " << optionType);
		ASSERT( optionType < KEYBOARD_OPTION_MAX );
	
		return m_keyboardOption[optionType];
	}

	//!CTouchDevice
	CTouchDevice::CTouchDevice(ClutterInputDevice* clutterInputDevice) : CDevice(clutterInputDevice)
	{
	}
	void CTouchDevice::SetTouchMode(ETouchMode touchMode)
	{
		H_LOG_TRACE(LOGGER, "CTouchDevice::SetTouchMode(" << touchMode << ")");
		m_touchMode = touchMode;
	}

	CTouchDevice::ETouchMode CTouchDevice::TouchMode()
	{
		H_LOG_TRACE(LOGGER, "CTouchDevice::TouchMode m_touchMode = " << m_touchMode);
		return m_touchMode;
	}

	CRemoconDevice::CRemoconDevice(ClutterInputDevice* clutterInputDevice) : CDevice(clutterInputDevice)
	{
	}

	CSmartconDevice::CSmartconDevice(ClutterInputDevice* clutterInputDevice) : CDevice(clutterInputDevice)
	{
	}

}
