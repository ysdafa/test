#include "Halo1_0.h"

static HALO::util::Logger LOGGER("DeviceManager");

namespace HALO
{
	const char* VCONF_KEY_CURSOR_VISIBLE = "memory/window_system/input/cursor_visible";

	CDeviceManager::CDeviceManager() : m_deviceInfoList(NULL), m_bFlagInit(false)
	{
#ifndef WIN32
		vconf_notify_key_changed(VCONF_KEY_CURSOR_VISIBLE, m_VconfKeyChangeCb, NULL);
#endif
	}

	CDeviceManager::~CDeviceManager()
	{
#ifndef WIN32
		vconf_ignore_key_changed(VCONF_KEY_CURSOR_VISIBLE, m_VconfKeyChangeCb);
#endif
		m_DeleteAllInput();

		/*if (m_deviceInfoList)
		{
			delete m_deviceInfoList;
			m_deviceInfoList = NULL;
		}*/		
	}
	
	void CDeviceManager::Initialize()
	{
		H_LOG_TRACE(LOGGER, "CDeviceManager::Initialize ");
		m_manager = clutter_device_manager_get_default();

		g_signal_connect(m_manager, "device-added", G_CALLBACK(m_AddDeviceEventCb), this);
		g_signal_connect(m_manager, "device-removed", G_CALLBACK(m_RemoveDeviceEventCb), this);

		m_deviceInfoList = new DeviceInfoList;
		// search the keyboard device
		const GSList *l;

		const GSList *list = clutter_device_manager_peek_devices(m_manager);		
		//g_slist_foreach(list, (GFunc) m_HaloDeviceList, this);

		for (l = list; l != NULL; l = l->next)
		{
			ClutterInputDevice *device =static_cast<ClutterInputDevice*>(l->data);
			ClutterInputDeviceType device_type = clutter_input_device_get_device_type(device);

			m_HaloDeviceList(device, device_type);
		 }
		m_bFlagInit = true;
	}

	void CDeviceManager::EnableDevice(IDevice *device, bool enabled)
	{
		H_LOG_TRACE(LOGGER, "CDeviceManager::EnableDevice(" << device << ", " << enabled << ")");
		ASSERT(device != NULL);
		if (false == m_bFlagInit)
		{
			Initialize();
		}
		
		int id = device->DeviceId();
		ClutterDeviceManager *device_manager = clutter_device_manager_get_default();
		ClutterInputDevice *clutterDivice = clutter_device_manager_get_device(device_manager, id);

		//int mode = clutter_input_device_get_device_mode(clutterDivice);

		clutter_input_device_set_enabled(clutterDivice, enabled);
	}

	bool CDeviceManager::IsDeviceEnabled(IDevice *device)
	{
		H_LOG_TRACE(LOGGER, "CDeviceManager::IsDeviceEnabled(" << device << ")");
		ASSERT(device != NULL);
		if (false == m_bFlagInit)
		{
			Initialize();
		}
		
		int id = device->DeviceId();
		ClutterDeviceManager *device_manager = clutter_device_manager_get_default();
		ClutterInputDevice *clutterDivice = clutter_device_manager_get_device(device_manager, id);
			
		return (clutter_input_device_get_enabled(clutterDivice) == 1);
	}
	
	void CDeviceManager::m_HaloDeviceList(ClutterInputDevice *device, int type)
	{
		switch (type)
		{
		case CLUTTER_POINTER_DEVICE:
			{
				m_CreateMouseDevice(device);				
			}
			break;
		case CLUTTER_KEYBOARD_DEVICE:
			{
				m_CreateKeyboardDevice(device);
			}
			break;
		case CLUTTER_TOUCHPAD_DEVICE:
		case CLUTTER_TOUCHSCREEN_DEVICE:
			{
				m_CreateTouchDevice(device);
			}
			break;
		default:
			break;
		}
	}

	int CDeviceManager::m_CreateMouseDevice(ClutterInputDevice* device)
	{
		// map a CMouseDevice in HALO
		int type = clutter_input_device_get_device_type(device);
		int id = clutter_input_device_get_device_id(device);
		const char* name = clutter_input_device_get_device_name(device);

		CMouseDevice*  halo_device = new CMouseDevice(device);
		halo_device->SetDeviceType(type);
		halo_device->SetDeviceId(id);
		halo_device->SetDeviceName(name);

		m_mouseDeviceInstance.insert(MouseDeviceMap::value_type(id , halo_device));
		
		m_InsertDeviceInfo(type, id, const_cast<char *>(name), 0);

		return id;
	}

	int CDeviceManager::m_CreateKeyboardDevice(ClutterInputDevice* device)
	{
		// map a CKeyboardDevice in HALO
		int type = clutter_input_device_get_device_type(device);
		int id = clutter_input_device_get_device_id(device);
		const char* name = clutter_input_device_get_device_name(device);

		CKeyboardDevice*  halo_device = new CKeyboardDevice(device);
		halo_device->SetDeviceType(type);
		halo_device->SetDeviceId(id);
		halo_device->SetDeviceName(name);

		m_keyboardDeviceInstance.insert(KeyboardDeviceMap::value_type(id, halo_device));

		m_InsertDeviceInfo(type, id, const_cast<char *>(name), 0);
		
		return id;
	}

	int CDeviceManager::m_CreateTouchDevice(ClutterInputDevice* device)
	{
		// map a CTouchDevice in HALO
		int type = clutter_input_device_get_device_type(device);
		int id = clutter_input_device_get_device_id(device);
		const char* name = clutter_input_device_get_device_name(device);

		CTouchDevice*  halo_device = new CTouchDevice(device);
		halo_device->SetDeviceType(type);
		halo_device->SetDeviceId(id);
		halo_device->SetDeviceName(name);

		m_touchDeviceInstance.insert(TouchDeviceMap::value_type(id , halo_device));

		m_InsertDeviceInfo(type, id, const_cast<char *>(name), 0);
		
		return id;
	}

	int CDeviceManager::m_CreateRemoteControlDevice(ClutterInputDevice* device)
	{
		// map a CRemocontrolDevice in HALO
		int type = clutter_input_device_get_device_type(device);
		int id = clutter_input_device_get_device_id(device);
		const char* name = clutter_input_device_get_device_name(device);

		CRemoconDevice*  halo_device = new CRemoconDevice(device);
		halo_device->SetDeviceType(type);
		halo_device->SetDeviceId(id);
		halo_device->SetDeviceName(name);

		m_remoteControlDeviceInstance.insert(RemoteControlDeviceMap::value_type(id , halo_device ));

		m_InsertDeviceInfo(type, id, const_cast<char *>(name), 0);
		
		return id;
	}

	int CDeviceManager::m_CreateSmartControlDevice(ClutterInputDevice* device)
	{
		// map a CSmartControlDevice in HALO
		int type = clutter_input_device_get_device_type(device);
		int id = clutter_input_device_get_device_id(device);
		const char* name = clutter_input_device_get_device_name(device);

		CSmartconDevice*  halo_device = new CSmartconDevice(device);
		halo_device->SetDeviceType(type);
		halo_device->SetDeviceId(id);
		halo_device->SetDeviceName(name);

		m_smartControlDeviceInstance.insert(SmartconDeviceMap::value_type(id , halo_device ));

		m_InsertDeviceInfo(type, id, const_cast<char *>(name), 0);

		return id;
	}

	void CDeviceManager::m_DestroyMouseDevice(int deviceId)
	{
		MouseDeviceMap::iterator iter;

		iter = m_mouseDeviceInstance.find(deviceId);

		if (iter != m_mouseDeviceInstance.end())
		{
			CMouseDevice* delDevice = iter->second;
			
			delete delDevice;

			m_mouseDeviceInstance.erase(deviceId);

			m_DeleteDeviceInfo(deviceId);
		}
	}

	void CDeviceManager::m_DestroyKeyboardDevice(int deviceId)
	{
		KeyboardDeviceMap::iterator iter;

		iter = m_keyboardDeviceInstance.find(deviceId);

		if (iter != m_keyboardDeviceInstance.end())
		{
			CKeyboardDevice* delDevice = iter->second;
			
			delete delDevice;

			m_keyboardDeviceInstance.erase(deviceId);

			m_DeleteDeviceInfo(deviceId);
		}
	}

	void CDeviceManager::m_DestroyTouchDevice(int deviceId)
	{
		TouchDeviceMap::iterator iter;

		iter = m_touchDeviceInstance.find(deviceId);

		if (iter != m_touchDeviceInstance.end())
		{
			CTouchDevice* delDevice = iter->second;
			
			delete delDevice;

			m_touchDeviceInstance.erase(deviceId);

			m_DeleteDeviceInfo(deviceId);
		}
	}

	void CDeviceManager::m_DestroyRemoteControlDevice(int deviceId)
	{
		RemoteControlDeviceMap::iterator iter;

		iter = m_remoteControlDeviceInstance.find(deviceId);

		if (iter != m_remoteControlDeviceInstance.end())
		{
			CRemoconDevice* delDevice = iter->second;
			
			delete delDevice;

			m_remoteControlDeviceInstance.erase(deviceId);

			m_DeleteDeviceInfo(deviceId);
		}
	}

	void CDeviceManager::m_DestroySmartControlDevice(int deviceId)
	{
		SmartconDeviceMap::iterator iter;

		iter = m_smartControlDeviceInstance.find(deviceId);

		if (iter != m_smartControlDeviceInstance.end())
		{
			CSmartconDevice* delDevice = iter->second;
			
			delete delDevice;

			m_smartControlDeviceInstance.erase(deviceId);

			m_DeleteDeviceInfo(deviceId);
		}
	}

	IDevice* CDeviceManager::GetDevice(ClutterInputDeviceType deviceId)
	{
		H_LOG_TRACE(LOGGER, "CDeviceManager::GetDevice(" << deviceId << ")");
		ASSERT(0 <= deviceId && deviceId < CLUTTER_N_DEVICE_TYPES);
		if (false == m_bFlagInit)
		{
			Initialize();
		}
		
		switch (deviceId)
		{
		case CLUTTER_POINTER_DEVICE:
			{
				return m_GetMouseDevice(deviceId);
			}
			break;
		case CLUTTER_KEYBOARD_DEVICE:
			{
				return m_GetKeyboardDevice(deviceId);
			}
			break;
		case CLUTTER_TOUCHPAD_DEVICE:
		case CLUTTER_TOUCHSCREEN_DEVICE:
			{
				return m_GetTouchDevice(deviceId);
			}
			break;
		/*case HALO_REMOCON_ID:
			{
				return m_GetRemoconDevice(deviceId);
			}
			break;*/
		/*case HALO_SMARTCON_ID:
			{
				return m_GetSmartControlDevice(deviceId);
			}
			break;*/
		default:
			break;
		}

		return NULL;
	}

	IMouseDevice* CDeviceManager::GetMouseDevice(void)
	{
		H_LOG_TRACE(LOGGER, "CDeviceManager::GetMouseDevice");
		if (false == m_bFlagInit)
		{
			Initialize();
		}
		
		IMouseDevice* mouseDevice = NULL;
		mouseDevice = dynamic_cast<IMouseDevice*>(GetDevice(CLUTTER_POINTER_DEVICE));
		return mouseDevice;
	}

	IDevice* CDeviceManager::m_GetKeyboardDevice(int deviceId)
	{
		KeyboardDeviceMap::iterator iter;
		CKeyboardDevice* retInput = NULL;

		iter = m_keyboardDeviceInstance.find(deviceId);

		if (iter != m_keyboardDeviceInstance.end())
		{
			retInput = (CKeyboardDevice*)iter->second;
		}

		return retInput;
	}

	IDevice* CDeviceManager::m_GetMouseDevice(int deviceId)
	{
		MouseDeviceMap::iterator iter;
		CMouseDevice* retInput = NULL;

		iter = m_mouseDeviceInstance.find(deviceId);

		if (iter != m_mouseDeviceInstance.end())
		{
			retInput = (CMouseDevice*)iter->second;
		}

		return retInput;
	}

	IDevice* CDeviceManager::m_GetTouchDevice(int deviceId)
	{
		TouchDeviceMap::iterator iter;
		CTouchDevice* retInput = NULL;

		iter = m_touchDeviceInstance.find(deviceId);

		if (iter != m_touchDeviceInstance.end())
		{
			retInput = (CTouchDevice*)iter->second;
		}

		return retInput;
	}

	IDevice* CDeviceManager::m_GetRemoconDevice(int deviceId)
	{
		RemoteControlDeviceMap::iterator iter;
		CRemoconDevice* retInput = NULL;

		iter = m_remoteControlDeviceInstance.find(deviceId);

		if (iter != m_remoteControlDeviceInstance.end())
		{
			retInput = (CRemoconDevice*)iter->second;
		}

		return retInput;
	}

	IDevice* CDeviceManager::m_GetSmartControlDevice(int deviceId)
	{
		SmartconDeviceMap::iterator iter;
		CSmartconDevice* retInput = NULL;

		iter = m_smartControlDeviceInstance.find(deviceId);

		if (iter != m_smartControlDeviceInstance.end())
		{
			retInput = (CSmartconDevice*)iter->second;
		}

		return retInput;
	}

	IActor* CDeviceManager::GetGrabedActor(IDevice *device)
	{
		H_LOG_TRACE(LOGGER, "CDeviceManager::GetGrabedActor(" << device << ")");
		ASSERT(device != NULL);
		if (false == m_bFlagInit)
		{
			Initialize();
		}
		
		ClutterActor* actor = NULL;
		int id = device->DeviceId();
		ClutterInputDevice *clutterDivice = clutter_device_manager_get_device(m_manager, id);

		actor = clutter_input_device_get_grabbed_actor(clutterDivice);

		return D_GET_HALO_ACTOR(G_OBJECT(actor));
	}

	void CDeviceManager::m_AddDeviceEventCb(ClutterDeviceManager *device_manager, ClutterInputDevice *device, CDeviceManager *deviceManager)
	{
		CDeviceManager* pThis = (CDeviceManager*)deviceManager;

		int type = clutter_input_device_get_device_type(device);
		//int id = clutter_input_device_get_device_id(device);

		switch (type)
		{
		case CLUTTER_POINTER_DEVICE:
			{
				pThis->m_CreateMouseDevice(device);	
			}
			break;
		case CLUTTER_KEYBOARD_DEVICE:
			{
				pThis->m_CreateKeyboardDevice(device);
			}
			break;
		case CLUTTER_TOUCHPAD_DEVICE:
		case CLUTTER_TOUCHSCREEN_DEVICE:
			{
				pThis->m_CreateTouchDevice(device);
			}
			break;
		default:
			break; 
		}
	}

	void CDeviceManager::m_RemoveDeviceEventCb(ClutterDeviceManager *device_manager, ClutterInputDevice *device, CDeviceManager *deviceManager)
	{
		CDeviceManager* pThis = (CDeviceManager*)deviceManager;

		int type = clutter_input_device_get_device_type(device);
		int id = clutter_input_device_get_device_id(device);

		switch (type)
		{
		case CLUTTER_POINTER_DEVICE:
			{
				pThis->m_DestroyMouseDevice(id);	
			}
			break;
		case CLUTTER_KEYBOARD_DEVICE:
			{
				pThis->m_DestroyKeyboardDevice(id);
			}
			break;
		case CLUTTER_TOUCHPAD_DEVICE:
		case CLUTTER_TOUCHSCREEN_DEVICE:
			{
				pThis->m_DestroyTouchDevice(id);
			}
			break;
		default:
			break; 
		}
	}

	void CDeviceManager::SetCursorImage(IStage* scene, const char* imagePath)
	{
		H_LOG_TRACE(LOGGER, "CDeviceManager::SetCursorImage(" << scene << ", " << imagePath << ")");
		//need clutter provide interface
		if (false == m_bFlagInit)
		{
			Initialize();
		}
	}
	
	void CDeviceManager::m_InsertDeviceInfo(int deviceType, int deviceId, char* deviceName,  int connectionType, int highKey, int lowKey)
	{
		TDeviceInfo* pNewDeviceInfo = new TDeviceInfo;

		ASSERT( pNewDeviceInfo );

		pNewDeviceInfo->deviceId = deviceId;
		pNewDeviceInfo->deviceType = deviceType;
		pNewDeviceInfo->deviceName = deviceName;
		pNewDeviceInfo->connectionType = connectionType;
		pNewDeviceInfo->highKey = highKey;
		pNewDeviceInfo->lowKey = lowKey;	

		m_deviceInfoList->push_back(pNewDeviceInfo);
	}

	bool CDeviceManager::m_DeleteDeviceInfo(int deviceId)
	{	
		TDeviceInfo* pCheckInfo = NULL;
		DeviceInfoList::iterator iter = m_deviceInfoList->begin();

		while(iter != m_deviceInfoList->end())
		{
			pCheckInfo = (*iter);

			if (pCheckInfo->deviceId == deviceId)
			{
				m_deviceInfoList->erase(iter);
				delete pCheckInfo;

				return true;
			}
			iter++;
		}

		return false;
	}

	void CDeviceManager::m_DeleteAllInput(void)
	{	
		//del mouse
		MouseDeviceMap::iterator mouseIter = m_mouseDeviceInstance.begin();

		while(mouseIter != m_mouseDeviceInstance.end())
		{
			CMouseDevice* pDelInput = mouseIter->second;

			if (NULL != pDelInput)
			{
				delete pDelInput;
			}

			mouseIter++;
		}

		m_mouseDeviceInstance.clear();

		//del touch
		TouchDeviceMap::iterator touchIter = m_touchDeviceInstance.begin();

		while(touchIter != m_touchDeviceInstance.end())
		{
			CTouchDevice* pDelInput = touchIter->second;

			if (NULL != pDelInput)
			{
				delete pDelInput;
			}

			touchIter++;
		}

		m_touchDeviceInstance.clear();

		//del keyboard
		KeyboardDeviceMap::iterator keyboardIter = m_keyboardDeviceInstance.begin();

		while(keyboardIter != m_keyboardDeviceInstance.end())
		{
			CKeyboardDevice* pDelInput = keyboardIter->second;

			if (NULL != pDelInput)
			{
				delete pDelInput;
			}

			keyboardIter++;
		}

		m_keyboardDeviceInstance.clear();

		//del remotecontrol
		RemoteControlDeviceMap::iterator remoteIter = m_remoteControlDeviceInstance.begin();

		while(remoteIter != m_remoteControlDeviceInstance.end())
		{
			CRemoconDevice* pDelInput = remoteIter->second;

			if (NULL != pDelInput)
			{
				delete pDelInput;
			}

			remoteIter++;
		}

		m_remoteControlDeviceInstance.clear();
		
		//del remotecontrol
		SmartconDeviceMap::iterator smartIter = m_smartControlDeviceInstance.begin();

		while(smartIter != m_smartControlDeviceInstance.end())
		{
			CSmartconDevice* pDelInput = smartIter->second;

			if (NULL != pDelInput)
			{
				delete pDelInput;
			}

			smartIter++;
		}

		m_smartControlDeviceInstance.clear();

		//del deviceinfo
		if (m_deviceInfoList != NULL)
		{
			DeviceInfoList::iterator iter = m_deviceInfoList->begin();

			while(iter != m_deviceInfoList->end())
			{
				TDeviceInfo* pDelInfo = (*iter);

				if (pDelInfo != NULL)
				{
					delete pDelInfo;
				}

				iter++;
			}

			m_deviceInfoList->clear();

			delete m_deviceInfoList;
			m_deviceInfoList = NULL;
		}
	}

	bool CDeviceManager::IsCursorVisible(void)
	{
#ifndef WIN32
		int val = 0;

		if (!vconf_get_int(VCONF_KEY_CURSOR_VISIBLE, &val) & val)
		{
			return true;
		}
#endif
		return false;
	}

#ifndef WIN32
	void CDeviceManager::m_VconfKeyChangeCb(keynode_t *keyNode, void *dt)
	{
		H_LOG_TRACE(LOGGER, "CDeviceManager::m_VconfKeyChangeCb");
		ASSERT(keyNode != NULL);

		char* keyName = vconf_keynode_get_name(keyNode);
		if (keyName == NULL)
		{
			H_LOG_FATAL(LOGGER, "Get KeyName Fail.");
			return;
		}
		H_LOG_TRACE(LOGGER, "KeyName = " << keyName);
		if (!strncmp(keyName, VCONF_KEY_CURSOR_VISIBLE, strlen(keyName)))
		{
			int val = 0;
			if (!vconf_get_int(VCONF_KEY_CURSOR_VISIBLE, &val))
			{
				H_LOG_TRACE(LOGGER, "KeyValue = " << val);

				ISystemEvent* cursorStausEvent = ISystemEvent::CreateInstance();
				if (cursorStausEvent == NULL)
				{
					return;
				}
				IMouseEvent* mouseEvent = IMouseEvent::CreateInstance();
				if (mouseEvent == NULL)
				{
					cursorStausEvent->Release();
					return;
				}

				ClutterPoint mousePointer = CLUTTER_POINT_INIT_ZERO;
				IDeviceManager* pDeviceManager = CDeviceManager::GetInstance();
				if (pDeviceManager && pDeviceManager->GetMouseDevice())
				{
					//Warning! If MouseDevice is removed when mouse is disconnected, can't get mouse point any more.
					pDeviceManager->GetMouseDevice()->GetMousePoint(&mousePointer);
					H_LOG_TRACE(LOGGER, "MousePoint: x = " << mousePointer.x << ", y = " << mousePointer.y);
				}
				mouseEvent->SetX(mousePointer.x);
				mouseEvent->SetY(mousePointer.y);

				ClutterActor* sourceActor = clutter_stage_get_actor_at_pos(CLUTTER_STAGE(IStage::GetInstance()->Stage()), CLUTTER_PICK_REACTIVE, mousePointer.x, mousePointer.y);
				if (sourceActor)
				{
					CActor* receiverActor = D_GET_HALO_ACTOR(G_OBJECT(sourceActor));
					if (receiverActor)
					{
						mouseEvent->SetReceiver(receiverActor);
					}
				}

				if (val)
				{
					H_LOG_TRACE(LOGGER, "Cursor is visible.");
					cursorStausEvent->SetEventType("samsung.tv.halo.system.cursorvisible");
					mouseEvent->SetEventType("samsung.tv.halo.input.mouseenter");
				}
				else
				{
					H_LOG_TRACE(LOGGER, "Cursor is hidden.");
					cursorStausEvent->SetEventType("samsung.tv.halo.system.cursorhidden");
					mouseEvent->SetEventType("samsung.tv.halo.input.mouseleave");
				}

				IEventManager* pEventManager = IEventManager::GetInstance();
				if (pEventManager)
				{
					pEventManager->SendEventLocal(cursorStausEvent);
					if (mouseEvent->Receiver() != NULL)
					{
						pEventManager->SendEventLocal(mouseEvent);
					}
				}
				cursorStausEvent->Release();
				mouseEvent->Release();
			}
		}
	}
#endif

}//end namespace
