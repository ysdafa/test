#ifndef _HALO_CDEVICE_H_
#define _HALO_CDEVICE_H_

namespace HALO
{
	class CDevice : virtual public  IDevice
	{
	public:
		CDevice(ClutterInputDevice* clutterInputDevice);
		virtual ~CDevice();
		virtual int DeviceType(void);
		virtual int DeviceId(void);
		virtual char* DeviceName(void);
		virtual ClutterInputDevice* InputDevice(void);

	//!No public for user
	public: 
		virtual void SetDeviceType(int deviceType);
		virtual void SetDeviceId(int deviceId);
		virtual void SetDeviceName(const char* deviceName);

	protected:
		ClutterInputDevice* t_clutterInputDevice;
	private:
		int m_deviceType;
		int m_deviceId;
		char* m_deviceName;
	};

	class CRemoconDevice : virtual public  IRemoconDevice, public CDevice
	{
	public:
		CRemoconDevice(ClutterInputDevice* clutterInputDevice);
		virtual ~CRemoconDevice(){}

	};

	class CMouseDevice : virtual public  IMouseDevice, public CDevice
	{
	public:
		CMouseDevice(ClutterInputDevice* clutterInputDevice);
		virtual ~CMouseDevice(){}
		//!Set pointer level
		virtual void SetPointerSensibility(int level);
		virtual int PointerSensibility(void);

		//!Set mouse property
		virtual void SetMouseOption(EMouseOption optionType, int optionValue);
		virtual int MouseOption(int optionType);
		virtual bool GetMousePoint(ClutterPoint* point);
		virtual void MoveMousePoint(long offsetX, long offsetY);

	private:
		int m_pointerSensibilityLevel;
		int m_mouseOption[MOUSE_OPTION_MAX];

	};

	class CKeyboardDevice : virtual public  IKeyboardDevice, public CDevice
	{
	public:
		CKeyboardDevice(ClutterInputDevice* clutterInputDevice);
		virtual ~CKeyboardDevice(){}
		//set keyboard property
		virtual void SetKeyboardOption(EKeyboardOption optionType, int optionValue);
		virtual int KeyboardOption(int optionType);

	private:
		int m_keyboardOption[KEYBOARD_OPTION_MAX];
	};

	class CTouchDevice : virtual public  ITouchDevice, public CDevice
	{
	public:
		CTouchDevice(ClutterInputDevice* clutterInputDevice);
		virtual ~CTouchDevice(){}
		//!Set touch property
		virtual void SetTouchMode(ETouchMode touchMode);
		virtual ETouchMode TouchMode(void);

	private:
		ETouchMode m_touchMode;
	};
	
	class CSmartconDevice : virtual public  ISmartconDevice, public CDevice
	{
	public:
		CSmartconDevice(ClutterInputDevice* clutterInputDevice);
		virtual ~CSmartconDevice(){}

	};

}

#endif