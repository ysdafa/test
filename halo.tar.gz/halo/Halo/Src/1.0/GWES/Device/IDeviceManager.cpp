#include "Halo1_0.h"

namespace HALO
{
	IDeviceManager* IDeviceManager::m_deviceManager = NULL;

	IDeviceManager* IDeviceManager::GetInstance(void)
	{
		if (m_deviceManager == NULL)
		{
			m_deviceManager = (IDeviceManager*)Instance::CreateInstance(CLASS_ID_IDEVICEMANAGER);
		}
		return m_deviceManager;
	}
}