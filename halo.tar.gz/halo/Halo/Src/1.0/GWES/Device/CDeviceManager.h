#ifndef _HALO_CDEVICE_MANAGER_H_
#define _HALO_CDEVICE_MANAGER_H_

#if !defined(WIN32) && !defined(LINUX_BUILD)
#include <vconf/vconf.h>
#endif

namespace HALO
{
	#define D_NOT_DEFINED 0

	struct TDeviceInfo
	{
		int deviceId;
		int deviceType;
		char* deviceName;
		int highKey;
		int lowKey;
		int connectionType;
	};

	typedef std::list<TDeviceInfo*> DeviceInfoList;
	typedef std::map<int, CMouseDevice*> MouseDeviceMap;
	typedef std::map<int, CTouchDevice*> TouchDeviceMap;
	typedef std::map<int, CKeyboardDevice*> KeyboardDeviceMap;
	typedef std::map<int, CRemoconDevice*> RemoteControlDeviceMap;
	typedef std::map<int, CSmartconDevice*> SmartconDeviceMap;

	class CDeviceManager : public IDeviceManager
	{
	public:	
		CDeviceManager();
		virtual ~CDeviceManager();

		//!Get the devicelist of HALO
		//virtual DeviceInfoList* GetDeviceInfoList(void);

		//!Get halo device
		virtual IDevice* GetDevice(ClutterInputDeviceType deviceId);

		//! Get mouse device
		virtual IMouseDevice* GetMouseDevice(void);

		//!Only ClutterInputDevice of types CLUTTER_POINTER_DEVICE and CLUTTER_KEYBOARD_DEVICE can hold a grab.
		virtual IActor* GetGrabedActor(IDevice *device);

		//!Set cursor property
		virtual void SetCursorImage(IStage* scene, const char* imagePath);

		//!Only devices with a �device-mode" property set to CLUTTER_INPUT_MODE_SLAVE or CLUTTER_INPUT_MODE_FLOATING can be disabled.
		virtual void EnableDevice(IDevice *device, bool enabled);
		virtual bool IsDeviceEnabled(IDevice *device);		

		//! Check cursor is visible or hidden
		virtual bool IsCursorVisible(void);

	public:
		//!No public for user
		virtual void Initialize();
	private:
		ClutterDeviceManager *m_manager;

		MouseDeviceMap m_mouseDeviceInstance;
		TouchDeviceMap m_touchDeviceInstance;
		KeyboardDeviceMap m_keyboardDeviceInstance;
		RemoteControlDeviceMap m_remoteControlDeviceInstance;
		SmartconDeviceMap m_smartControlDeviceInstance;
		DeviceInfoList* m_deviceInfoList;
		bool m_bFlagInit;

		static void m_AddDeviceEventCb(ClutterDeviceManager *device_manager, ClutterInputDevice   *device, CDeviceManager *pThis);
		static void m_RemoveDeviceEventCb(ClutterDeviceManager *device_manager, ClutterInputDevice   *device, CDeviceManager *pThis);
#if !defined(WIN32) && !defined(LINUX_BUILD)
		static void m_VconfKeyChangeCb(keynode_t *keyNode, void *dt);
#endif

		void m_HaloDeviceList(ClutterInputDevice *device, int type);
		void m_InsertDeviceInfo(int deviceType, int deviceId, char* deviceName, int connectionType, int hKey = D_NOT_DEFINED, int lKey = D_NOT_DEFINED);
		bool m_DeleteDeviceInfo(int deviceId);
		void m_DeleteAllInput(void);

		int m_CreateKeyboardDevice(ClutterInputDevice* device);
		int m_CreateMouseDevice(ClutterInputDevice* device);
		int m_CreateTouchDevice(ClutterInputDevice* device);
		int m_CreateRemoteControlDevice(ClutterInputDevice* device);
		int m_CreateSmartControlDevice(ClutterInputDevice* device);

		void m_DestroyKeyboardDevice(int deviceId);
		void m_DestroyMouseDevice(int deviceId);
		void m_DestroyTouchDevice(int deviceId);
		void m_DestroyRemoteControlDevice(int deviceId);
		void m_DestroySmartControlDevice(int deviceId);

		IDevice* m_GetKeyboardDevice(int deviceId);
		IDevice* m_GetRemoconDevice(int deviceId);
		IDevice* m_GetMouseDevice(int deviceId);
		IDevice* m_GetTouchDevice(int deviceId);
		IDevice* m_GetSmartControlDevice(int deviceId);
	};
}

#endif
