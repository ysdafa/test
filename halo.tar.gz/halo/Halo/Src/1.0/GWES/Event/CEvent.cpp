#include "Halo1_0.h"

static HALO::util::Logger LOGGER("Event");

namespace HALO
{	
	extern CStage *g_stage;
	extern CEventManager* g_pEventManager;
	extern CDeviceManager* g_pDeviceManager;

	CEvent::CEvent():
		t_eventType(CLUTTER_EVENT_NONE),
		t_time(0),
		t_flags(0),
		t_pReceiveStage(g_stage),
		t_pReceiverActor(NULL)
	{
	}

	CEvent::CEvent(const CEvent& event)
	{
		t_eventType = event.t_eventType;
		t_time= event.t_time;
		t_flags= event.t_flags;
		t_pReceiveStage= event.t_pReceiveStage;
		t_pReceiverActor= event.t_pReceiverActor;
		t_bundle= event.t_bundle;
	}
		
	CEvent::CEvent(ClutterEvent* event)
	{
		t_eventType = event->any.type;
		t_time = event->any.time;
		t_flags = event->any.flags;
		t_pReceiveStage = g_stage;
		if (event->any.source)
		{
			t_pReceiverActor = D_GET_HALO_ACTOR(G_OBJECT(event->any.source));
		}
		if (event->any.type == CLUTTER_CLIENT_MESSAGE && event->client.pointer)
		{
			TClientInfo* clientInfo = (TClientInfo*)event->client.pointer;
			t_bundle.DecodeBundle((const unsigned char*)clientInfo->data, clientInfo->len);
			int eventType = 0;
			t_bundle.IntValue("EventType", eventType);
			SetEventType(eventType);
			delete clientInfo;
		}
	}
		
	CEvent::~CEvent()
	{
	}

	CEvent& CEvent::operator=(const CEvent& event)
	{
		if (this == &event)
		{
			return *this;
		}

		t_eventType = event.t_eventType;
		t_time= event.t_time;
		t_flags= event.t_flags;
		t_pReceiveStage= event.t_pReceiveStage;
		t_pReceiverActor= event.t_pReceiverActor;
		t_bundle= event.t_bundle;

		return *this;
	}

	IEvent* CEvent::Clone(void) 
	{
		H_LOG_TRACE(LOGGER, "CEvent::Clone ");
		CEvent* pCloneEvent = new CEvent(*this);
		return pCloneEvent;
	}

	int CEvent::SetReceiver(IActor* actor) 
	{
		H_LOG_TRACE(LOGGER, "CEvent::SetReceiver(" << actor << ")");
		t_pReceiverActor = actor;
		return 0;
	}
	IActor* CEvent::Receiver(void) 
	{
		H_LOG_TRACE(LOGGER, "CEvent::Receiver t_pReceiverActor = " << t_pReceiverActor);
		return t_pReceiverActor;
	} 
	void CEvent::SetEventType(int eventType) 
	{
		H_LOG_TRACE(LOGGER, "CEvent::SetEventType(" << eventType << ")");
		t_eventType = eventType;
	}
	int CEvent::EventType(void) const
	{
		H_LOG_TRACE(LOGGER, "CEvent::EventType t_eventType = " << t_eventType);
		return t_eventType;
	}
	void CEvent::SetEventType(const char* eventName) 
	{
		H_LOG_TRACE(LOGGER, "CEvent::SetEventType(" << eventName << ")");
		t_eventType = g_pEventManager->GetEventType(eventName);
		return;
	}
	bool CEvent::IsEventType(const char* eventName) 
	{
		H_LOG_TRACE(LOGGER, "CEvent::IsEventType(" << eventName << ")");
		return t_eventType == g_pEventManager->GetEventType(eventName);
	}

	ClutterEvent* CEvent::Transform(void)
	{
		H_LOG_TRACE(LOGGER, "CEvent::Transform ");
		ClutterEvent* clutterEvent = clutter_event_new(CLUTTER_NOTHING);
		clutterEvent->any.time = t_time;
		clutterEvent->any.flags = (ClutterEventFlags)t_flags;
		clutterEvent->any.stage = CLUTTER_STAGE(t_pReceiveStage->Stage());
		if (t_pReceiverActor)
		{
			//clutterEvent->any.source = dynamic_cast<CActor*>(t_pReceiverActor)->Actor();
			CActor *actor = dynamic_cast<CActor*>(t_pReceiverActor);
			if (actor)
			{
				clutterEvent->any.source = actor->Actor();
			}			
		}
		else
		{
			clutterEvent->any.source = NULL;
		}
		return clutterEvent;
	}

	bool CEvent::PutInt(const char* key, int value) 
	{
		H_LOG_TRACE(LOGGER, "CEvent::PutInt(" << key <<", " << value << ")");
		return t_bundle.AddInt(key, value) == 0;
	}
	bool CEvent::PutLong(const char* key, long value)
	{
		H_LOG_TRACE(LOGGER, "CEvent::PutLong(" << key <<", " << value << ")");
		return t_bundle.AddLong(key, value) == 0;
	}
	bool CEvent::PutDouble(const char* key, double value)
	{
		H_LOG_TRACE(LOGGER, "CEvent::PutDouble(" << key <<", " << value << ")");
		return t_bundle.AddDouble(key, value) == 0;
	}
	bool CEvent::PutFloat(const char* key, float value)
	{
		H_LOG_TRACE(LOGGER, "CEvent::PutFloat(" << key <<", " << value << ")");
		return t_bundle.AddFloat(key, value) == 0;
	}
	bool CEvent::PutChar(const char* key, char value)
	{
		H_LOG_TRACE(LOGGER, "CEvent::PutChar(" << key <<", " << value << ")");
		return t_bundle.AddChar(key, value) == 0;
	}
	bool CEvent::PutString(const char* key, const char* value)
	{
		H_LOG_TRACE(LOGGER, "CEvent::PutString(" << key <<", " << value << ")");
		return t_bundle.AddString(key, value) == 0;
	}

	bool CEvent::PutPointor(const char* key, void* pointor)
	{
		H_LOG_TRACE(LOGGER, "CEvent::PutPointor(" << key <<", " << pointor << ")");
		return t_bundle.AddLong(key, (long)(pointor)) == 0;
	}

	bool CEvent::GetInt(const char* key, int& value)
	{
		H_LOG_TRACE(LOGGER, "CEvent::GetInt(" << key << ")");
		return t_bundle.IntValue(key, value) == 0;
	}
	bool CEvent::GetLong(const char* key, long& value)
	{
		H_LOG_TRACE(LOGGER, "CEvent::GetLong(" << key << ")");
		return t_bundle.LongValue(key, value) == 0;
	}
	bool CEvent::GetDouble(const char* key, double& value)
	{
		H_LOG_TRACE(LOGGER, "CEvent::GetDouble(" << key << ")");
		return t_bundle.DoubleValue(key, value) == 0;
	}
	bool CEvent::GetFloat(const char* key, float& value)
	{
		H_LOG_TRACE(LOGGER, "CEvent::GetFloat(" << key << ")");
		return t_bundle.FloatValue(key, value) == 0;
	}
	bool CEvent::GetChar(const char* key, char& value)
	{
		H_LOG_TRACE(LOGGER, "CEvent::GetChar(" << key << ")");
		return t_bundle.CharValue(key, value) == 0;
	}
	bool CEvent::GetString(const char* key, char** value)
	{
		H_LOG_TRACE(LOGGER, "CEvent::GetString(" << key << ")");
		return t_bundle.StringValue(key, value) == 0;
	}
	bool CEvent::GetPointor(const char* key, void** value)
	{
		H_LOG_TRACE(LOGGER, "CEvent::GetPointor(" << key << ")");
		if (value)
		{
			return t_bundle.LongValue(key, (long&)*value) == 0;
		}
		return false;
	}
	//! CDbus
	bool CEvent::EncodeBundle(unsigned char** r, int* len)
	{
		H_LOG_TRACE(LOGGER, "CEvent::EncodeBundle ");
		return t_bundle.EncodeBundle(r, len) == 0;
	}
	bool CEvent::DecodeBundle(const unsigned char* r, const int data_size)
	{
		H_LOG_TRACE(LOGGER, "CEvent::DecodeBundle ");
		return t_bundle.DecodeBundle(r, data_size) == 0;
	}

	CKeyboardEvent::CKeyboardEvent()
	{
		m_modifierState = (ClutterModifierType)0;
		m_keyVal = 0;
		m_hardwareKeyCode = 0;
		m_unicodeValue = 0;
	}
	CKeyboardEvent::CKeyboardEvent(ClutterEvent* event): CEvent(event)
	{
		m_modifierState = event->key.modifier_state;
		m_keyVal = event->key.keyval;
		m_hardwareKeyCode = event->key.hardware_keycode;
		m_unicodeValue = event->key.unicode_value;
	}
	CKeyboardEvent::~CKeyboardEvent()
	{
	}
	ClutterEvent* CKeyboardEvent::Transform(void)
	{
		H_LOG_TRACE(LOGGER, "CKeyboardEvent::Transform ");
		ClutterEvent* pNewEvent = CEvent::Transform();
		pNewEvent->key.type = (ClutterEventType)EventType();
		pNewEvent->key.keyval = m_keyVal;
		pNewEvent->key.hardware_keycode = m_hardwareKeyCode;
		pNewEvent->key.unicode_value = m_unicodeValue;
		pNewEvent->key.modifier_state = m_modifierState;
		//TODO Device
		return pNewEvent;
	}
	int CKeyboardEvent::GetModifierType(void) const
	{
		H_LOG_TRACE(LOGGER, "CKeyboardEvent::GetModifierType m_modifierState = " << m_modifierState);
		return m_modifierState;
	}
	int CKeyboardEvent::GetKeyVal(void) const
	{
		H_LOG_TRACE(LOGGER, "CKeyboardEvent::GetKeyVal m_keyVal = " << m_keyVal);
		return m_keyVal;
	}
	short CKeyboardEvent::GetHardwareKeyCode(void) const
	{
		H_LOG_TRACE(LOGGER, "CKeyboardEvent::GetHardwareKeyCode m_hardwareKeyCode = " << m_hardwareKeyCode);
		return m_hardwareKeyCode;
	}
	int CKeyboardEvent::GetUnicodeValue(void) const
	{
		H_LOG_TRACE(LOGGER, "CKeyboardEvent::GetUnicodeValue m_unicodeValue = " << m_unicodeValue);
		return m_unicodeValue;
	}
	void* CKeyboardEvent::GetKeyComActionData(void) const
	{
		H_LOG_TRACE(LOGGER, "CKeyboardEvent::GetKeyComActionData m_pData = " << m_pData);
		return m_pData;
	}
	void CKeyboardEvent::SetModifierType(int modifierType)
	{
		H_LOG_TRACE(LOGGER, "CKeyboardEvent::SetModifierType(" << modifierType << ")");
		m_modifierState = (ClutterModifierType)modifierType;
	}
	void CKeyboardEvent::SetKeyVal(int keyVal)
	{
		H_LOG_TRACE(LOGGER, "CKeyboardEvent::SetKeyVal(" << keyVal << ")");
		m_keyVal = keyVal;
	}
	void CKeyboardEvent::SetHardwareKeyCode(short hardwareKeyCode)
	{
		H_LOG_TRACE(LOGGER, "CKeyboardEvent::SetHardwareKeyCode(" << hardwareKeyCode << ")");
		m_hardwareKeyCode = hardwareKeyCode;
	}
	void CKeyboardEvent::SetUnicodeValue(int unicodeValue)
	{
		H_LOG_TRACE(LOGGER, "CKeyboardEvent::SetUnicodeValue(" << unicodeValue << ")");
		m_unicodeValue = unicodeValue;
	}
	void CKeyboardEvent::SetKeyComActionData(void* data)
	{
		H_LOG_TRACE(LOGGER, "CKeyboardEvent::SetKeyComActionData(" << data << ")");
		m_pData = data;
	}
	CClickEvent::CClickEvent()
	{
		//t_eventType = E_HALO_EVENT_CLICKED;
		t_eventType = g_pEventManager->GetEventType("samsung.tv.halo.input.mouseclicked");
		t_time = (int)time(NULL);
		t_pReceiveStage = g_stage;
	}
	CClickEvent::CClickEvent(ClutterEvent* event)
	{
	}
	CClickEvent::~CClickEvent()
	{
	}

	CLongPressEvent::CLongPressEvent()
	{
		//t_eventType = E_HALO_EVENT_LONGPRESS;
		t_eventType = g_pEventManager->GetEventType("samsung.tv.halo.input.mouselongpress");
		t_time = (int)time(NULL);
		t_pReceiveStage = g_stage;
	}
	CLongPressEvent::CLongPressEvent(ClutterEvent* event)
	{
	}
	CLongPressEvent::~CLongPressEvent()
	{
	}

	//! Drag event

	CDragEvent::CDragEvent(EDragSignalType signalType)
	{
		//t_eventType = E_HALO_EVENT_DRAG;
		t_eventType = g_pEventManager->GetEventType("samsung.tv.halo.input.drag");
		t_time = (int)time(NULL);
		t_pReceiveStage = g_stage;
		t_signalType = signalType;
		t_motionX = 0;
		t_motionY = 0;
		t_pressX = 0;
		t_pressY = 0;
		t_deltaX = 0;
		t_deltaY = 0;
	}
	CDragEvent::CDragEvent(ClutterEvent* event)
	{
	}
	CDragEvent::~CDragEvent()
	{
	}
	EDragSignalType CDragEvent::DragSignalType()
	{
		H_LOG_TRACE(LOGGER, "CDragEvent::DragSignalType t_signalType = " << t_signalType);
		return t_signalType;
	}
	void CDragEvent::MotionCoords(float *motion_x, float *motion_y)
	{
		H_LOG_TRACE(LOGGER, "CDragEvent::MotionCoords motion_x = " << t_motionX << ", motion_y = " << t_motionY);
		*motion_x = t_motionX;
		*motion_y = t_motionY;
	}
	void CDragEvent::PressCoords(float *press_x, float *press_y)
	{
		H_LOG_TRACE(LOGGER, "CDragEvent::PressCoords press_x = " << t_pressX << ", press_y = " << t_pressY);
		*press_x = t_pressX;
		*press_y = t_pressY;
	}
	void CDragEvent::MotionDelta(float *delta_x, float * delta_y)
	{
		H_LOG_TRACE(LOGGER, "CDragEvent::MotionDelta delta_x = " << t_deltaX << ", delta_y = " << t_deltaY);
		*delta_x = t_deltaX;
		*delta_y = t_deltaY;
	}
	void CDragEvent::SetMotionCoords(float motion_x, float motion_y)
	{
		H_LOG_TRACE(LOGGER, "CDragEvent::SetMotionCoords(" << motion_x << ", " << motion_y << ")");
		t_motionX = motion_x;
		t_motionY = motion_y;
	}
	void CDragEvent::SetPressCoords(float press_x, float press_y)
	{
		H_LOG_TRACE(LOGGER, "CDragEvent::SetPressCoords(" << press_x << ", " << press_y << ")");
		t_pressX = press_x;
		t_pressY = press_y;
	}
	void CDragEvent::SetMotionDelta(float delta_x, float delta_y)
	{
		H_LOG_TRACE(LOGGER, "CDragEvent::SetMotionDelta(" << delta_x << ", " << delta_y << ")");
		t_deltaX = delta_x;
		t_deltaY = delta_y;
	}
	//! Drag event end

	CGestureEvent::CGestureEvent(EGestureSignalType signalType)
	{
		//t_eventType = E_HALO_EVENT_GESTURE;
		t_eventType = g_pEventManager->GetEventType("samsung.tv.halo.input.gesture");
		t_time = (int)time(NULL);
		t_pReceiveStage = g_stage;
		t_signalType = signalType;
		t_thresholdX = 0;
		t_thresholdY = 0;
		t_touchPoints = 0;
		t_curPoints = 0;
	}
	
	EGestureSignalType CGestureEvent::GestureSignalType()
	{
		return t_signalType;
	}

	CGestureEvent::CGestureEvent(ClutterEvent* event)
	{
	}
	CGestureEvent::~CGestureEvent()
	{
	}

	void CGestureEvent::SetThresholdTriggerDistance(float x, float y)
	{
		H_LOG_TRACE(LOGGER, "CGestureEvent::SetThresholdTriggerDistance(" << x << ", " << y << ")");
		t_thresholdX = x;
		t_thresholdY = y;
	}

	void CGestureEvent::ThresholdTriggerDistance(float *x, float *y)
	{
		H_LOG_TRACE(LOGGER, "CGestureEvent::ThresholdTriggerDistance x = " << t_thresholdX << ", y = " << t_thresholdY);
		*x = t_thresholdX;
		*y = t_thresholdY;
	}

	void CGestureEvent::SetTouchPoints(int num)
	{
		H_LOG_TRACE(LOGGER, "CGestureEvent::SetTouchPoints(" << num << ")");
		t_touchPoints = num;
	}

	int CGestureEvent::TouchPoints()
	{
		H_LOG_TRACE(LOGGER, "CGestureEvent::TouchPoints t_touchPoints = " << t_touchPoints);
		return t_touchPoints;
	}

	void CGestureEvent::SetCurrentPoints(int num)
	{
		H_LOG_TRACE(LOGGER, "CGestureEvent::SetCurrentPoints(" << num << ")");
		t_curPoints = num;
	}

	int CGestureEvent::CurrentPoints()
	{
		H_LOG_TRACE(LOGGER, "CGestureEvent::CurrentPoints t_curPoints = " << t_curPoints);
		return t_curPoints;
	}
	//! Gesture event end
	
	CFocusEvent::CFocusEvent(EFocusType eventType)
	{
		//t_eventType = EVENT_FOCUS;
		t_eventType = g_pEventManager->GetEventType("samsung.tv.halo.input.focus");
		t_time = (int)time(NULL);
		t_pReceiveStage = g_stage;
		m_eventType = eventType;
	}

	CFocusEvent::CFocusEvent(ClutterEvent* event)
	{

	}

	CFocusEvent::~CFocusEvent()
	{

	}

	EFocusType CFocusEvent::FocusEventType()
	{
		H_LOG_TRACE(LOGGER, "CFocusEvent::FocusEventType m_eventType = " << m_eventType);
		return m_eventType;
	}

	CMouseEvent::CMouseEvent()
	{
		m_x = 0.0;
		m_y = 0.0;
		m_modifierState = (ClutterModifierType)0;
		m_device = g_pDeviceManager->GetMouseDevice()->InputDevice();
		m_scrollDirection = (ClutterScrollDirection)0;
		m_button = NONE_PRESS;
		m_click_count = 0;
		m_related = NULL;
	}
	CMouseEvent::CMouseEvent(const CMouseEvent& mouseEvent) : 
		CEvent(mouseEvent), 
		m_x(mouseEvent.m_x), 
		m_y(mouseEvent.m_y),
		m_modifierState(mouseEvent.m_modifierState),
		m_device(mouseEvent.m_device),
		m_scrollDirection(mouseEvent.m_scrollDirection),
		m_button(mouseEvent.m_button),
		m_click_count(mouseEvent.m_click_count),
		m_related(mouseEvent.m_related)
	{
	}

	CMouseEvent& CMouseEvent::operator=(const CMouseEvent& event)
	{
		if (this == &event)
		{
			return *this;
		}	

		m_x = event.m_x;
		m_y = event.m_y;
		m_modifierState = event.m_modifierState;
		m_device = event.m_device;
		m_scrollDirection = event.m_scrollDirection;
		m_button = event.m_button;
		m_click_count = event.m_click_count;
		m_related = event.m_related;

		return *this;
	}
	
	CMouseEvent::CMouseEvent(ClutterEvent* event) : CEvent(event)
	{
		switch (t_eventType)
		{
		case CLUTTER_ENTER:
		case CLUTTER_LEAVE:
			{
				m_x = event->crossing.x;
				m_y = event->crossing.y;
				m_related = event->crossing.related;
			}
			break;
		case CLUTTER_MOTION:
			{
				m_x = event->motion.x;
				m_y = event->motion.y;
				m_modifierState = event->motion.modifier_state;
			}
			break;
		case CLUTTER_BUTTON_PRESS:
		case CLUTTER_BUTTON_RELEASE:
			{
				m_x = event->button.x;
				m_y = event->button.y;
				m_modifierState = event->button.modifier_state;
				m_button = (EButtonPressType)event->button.button;
				m_click_count = event->button.click_count;
			}
			break;
		case CLUTTER_SCROLL:
			{
				m_x = event->scroll.x;
				m_y = event->scroll.y;
				m_modifierState = event->scroll.modifier_state;
				m_scrollDirection = event->scroll.direction;
			}
			break;
		default:
			break;
		}
	}

	CMouseEvent::~CMouseEvent()
	{
	}
	CMouseEvent* CMouseEvent::Clone(void)
	{
		H_LOG_TRACE(LOGGER, "CMouseEvent::Clone ");
		CMouseEvent* mouseEvent = new CMouseEvent(*this);
		return mouseEvent;
	}
	ClutterEvent* CMouseEvent::Transform(void)
	{
		H_LOG_TRACE(LOGGER, "CMouseEvent::Transform ");
		ClutterEvent* pNewEvent = CEvent::Transform();
		//pNewEvent->button.type = (ClutterEventType)t_eventType;
		
		switch (t_eventType)
		{
		case CLUTTER_ENTER:
		case CLUTTER_LEAVE:
			{
				pNewEvent->crossing.type = (ClutterEventType)t_eventType;
				pNewEvent->crossing.x = m_x;
				pNewEvent->crossing.y  = m_y;
				pNewEvent->crossing.related = m_related;
			}
			break;
		case CLUTTER_MOTION:
			{
				pNewEvent->motion.type = (ClutterEventType)t_eventType;
				pNewEvent->motion.x = m_x;
				pNewEvent->motion.y = m_y;
				pNewEvent->motion.modifier_state = m_modifierState;
				pNewEvent->motion.device = m_device;
			}
			break;
		case CLUTTER_BUTTON_PRESS:
		case CLUTTER_BUTTON_RELEASE:
			{
				pNewEvent->button.type = (ClutterEventType)t_eventType;
				pNewEvent->button.x = m_x;
				pNewEvent->button.y = m_y;
				pNewEvent->button.modifier_state = m_modifierState;
				pNewEvent->button.button = m_button;
				pNewEvent->button.click_count = m_click_count;
			}
			break;
		case CLUTTER_SCROLL:
			{
				pNewEvent->scroll.type = (ClutterEventType)t_eventType;
				pNewEvent->scroll.x = m_x;
				pNewEvent->scroll.y = m_y;
				pNewEvent->scroll.modifier_state = m_modifierState;
				pNewEvent->scroll.direction = m_scrollDirection;
			}
			break;
		default:
			break;
		}
		return pNewEvent;
	}

	CSystemEvent::CSystemEvent()
	{
	}
	CSystemEvent::CSystemEvent(const CSystemEvent& event):CEvent(event)
	{
	}
	CSystemEvent::CSystemEvent(ClutterEvent* event):CEvent(event)
	{
		TClientInfo* clientInfo = (TClientInfo*)event->client.pointer;
		t_bundle.DecodeBundle((const unsigned char*)clientInfo->data, clientInfo->len);
		int eventType = 0;
		t_bundle.IntValue("EventType", eventType);
		SetEventType(eventType);
		delete clientInfo;
	}
	CSystemEvent::~CSystemEvent()
	{

	}
	CSystemEvent& CSystemEvent::operator=(const CSystemEvent& event)
	{
		return *this;
	}
	IEvent* CSystemEvent::Clone()
	{
		H_LOG_TRACE(LOGGER, "CSystemEvent::Clone ");
		CSystemEvent* pNewEvent = new CSystemEvent(*this);
		return pNewEvent;
	}
	ClutterEvent* CSystemEvent::Transform(void)
	{
		H_LOG_TRACE(LOGGER, "CSystemEvent::Transform ");
		ClutterEvent* pNewEvent = CEvent::Transform();
		pNewEvent->client.type = CLUTTER_CLIENT_MESSAGE;
		IEvent* event = (IEvent*)this;
		pNewEvent->client.pointer = event;
		return pNewEvent;
	}
	CCustomEvent::CCustomEvent()
	{
	}
	CCustomEvent::CCustomEvent(const CCustomEvent& event):CEvent(event)
	{
	}
	CCustomEvent::CCustomEvent(ClutterEvent* event):CEvent(event)
	{
		TClientInfo* clientInfo = (TClientInfo*)event->client.pointer;
		t_bundle.DecodeBundle((const unsigned char*)clientInfo->data, clientInfo->len);
		int eventType = 0;
		t_bundle.IntValue("EventType", eventType);
		SetEventType(eventType);
		delete clientInfo;
	}
	CCustomEvent::~CCustomEvent()
	{

	}
	CCustomEvent& CCustomEvent::operator=(const CCustomEvent& event)
	{
		return *this;
	}
	IEvent* CCustomEvent::Clone(void)
	{
		H_LOG_TRACE(LOGGER, "CCustomEvent::Clone ");
		CCustomEvent* pNewEvent = new CCustomEvent(*this);
		return pNewEvent;
	}
	ClutterEvent* CCustomEvent::Transform(void)
	{
		H_LOG_TRACE(LOGGER, "CCustomEvent::Transform ");
		ClutterEvent* pNewEvent = CEvent::Transform();
		pNewEvent->client.type = CLUTTER_CLIENT_MESSAGE;
		IEvent* event = (IEvent*)this;
		pNewEvent->client.pointer = event;
		return pNewEvent;
	}
	void CCustomEvent::SetEventType(int eventType)
	{
		H_LOG_TRACE(LOGGER, "CCustomEvent::SetEventType(" << eventType << ")");
		CEvent::SetEventType(eventType);
	}

	void CCustomEvent::SetEventType(const char* eventName)
	{
		H_LOG_TRACE(LOGGER, "CCustomEvent::SetEventType(" << eventName << ")");
		CEvent::SetEventType(eventName);
	}
	/*bool CCustomEvent::IsEventType(const char* eventName)
	{
		return false;
	}*/

}
