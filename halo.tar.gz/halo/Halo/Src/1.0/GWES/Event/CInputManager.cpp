#include "Halo1_0.h"

namespace HALO
{
	CInputManager::CInputManager()
	{
	}
	CInputManager::~CInputManager()
	{
	}
	gboolean CInputManager::ProcessInputEvent(const ClutterEvent* event)
	{
		//device filter

		//global recognizer

		//propagate
		return CLUTTER_EVENT_PROPAGATE;
	}
}