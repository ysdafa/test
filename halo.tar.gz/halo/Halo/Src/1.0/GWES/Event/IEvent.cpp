#include "Halo1_0.h"

namespace HALO
{
	IEvent* IEvent::CreateInstance()
	{
		CEvent* event = dynamic_cast<CEvent*>(Instance::CreateInstance(CLASS_ID_IEVENT));
		if (event)
		{
			event->Initialize();
		}
		return (IEvent*)event;
	}
	IMouseEvent* IMouseEvent::CreateInstance()
	{
		CMouseEvent* event = dynamic_cast<CMouseEvent*>(Instance::CreateInstance(CLASS_ID_IMOUSEEVENT));
		if (event)
		{
			event->Initialize();
		}
		return (IMouseEvent*)event;
	}
	IKeyboardEvent* IKeyboardEvent::CreateInstance()
	{
		CKeyboardEvent* event = dynamic_cast<CKeyboardEvent*>(Instance::CreateInstance(CLASS_ID_IKEYBOARDEVENT));
		if (event)
		{
			event->Initialize();
		}
		return (IKeyboardEvent*)event;
	}
	IRemoconEvent* IRemoconEvent::CreateInstance()
	{
		CRemoconEvent* event = dynamic_cast<CRemoconEvent*>(Instance::CreateInstance(CLASS_ID_IREMOCONEVENT));
		if (event)
		{
			event->Initialize();
		}
		return (IRemoconEvent*)event;
	}
	IMotionEvent* IMotionEvent::CreateInstance()
	{
		CMotionEvent* event = dynamic_cast<CMotionEvent*>(Instance::CreateInstance(CLASS_ID_IMOTIONEVENT));
		if (event)
		{
			event->Initialize();
		}
		return (IMotionEvent*)event;
	}
	ITouchEvent* ITouchEvent::CreateInstance()
	{
		CTouchEvent* event = dynamic_cast<CTouchEvent*>(Instance::CreateInstance(CLASS_ID_ITOUCHEVENT));
		if (event)
		{
			event->Initialize();
		}
		return (ITouchEvent*)event;
	}
	IRidgeEvent* IRidgeEvent::CreateInstance()
	{
		CRidgeEvent* event = dynamic_cast<CRidgeEvent*>(Instance::CreateInstance(CLASS_ID_IRIDGEEVENT));
		if (event)
		{
			event->Initialize();
		}
		return (IRidgeEvent*)event;
	}
	ICursorEvent* ICursorEvent::CreateInstance()
	{
		CCursorEvent* event = dynamic_cast<CCursorEvent*>(Instance::CreateInstance(CLASS_ID_ICURSOREVENT));
		if (event)
		{
			event->Initialize();
		}
		return (ICursorEvent*)event;
	}
	ISensorEvent* ISensorEvent::CreateInstance()
	{
		CSensorEvent* event = dynamic_cast<CSensorEvent*>(Instance::CreateInstance(CLASS_ID_ISENSOREVENT));
		if (event)
		{
			event->Initialize();
		}
		return (ISensorEvent*)event;
	}
	IClickEvent* IClickEvent::CreateInstance()
	{
		CClickEvent* event = dynamic_cast<CClickEvent*>(Instance::CreateInstance(CLASS_ID_ICLICKEVENT));
		if (event)
		{
			event->Initialize();
		}
		return (IClickEvent*)event;
	}
	ILongPressEvent* ILongPressEvent::CreateInstance()
	{
		CLongPressEvent* event = dynamic_cast<CLongPressEvent*>(Instance::CreateInstance(CLASS_ID_ILONGPRESSEVENT));
		if (event)
		{
			event->Initialize();
		}
		return (ILongPressEvent*)event;
	}
	IDragEvent* IDragEvent::CreateInstance()
	{
		CDragEvent* event = dynamic_cast<CDragEvent*>(Instance::CreateInstance(CLASS_ID_IDRAGEVENT));
		if (event)
		{
			event->Initialize();
		}
		return (IDragEvent*)event;
	}
	IGestureEvent* IGestureEvent::CreateInstance()
	{
		CGestureEvent* event = dynamic_cast<CGestureEvent*>(Instance::CreateInstance(CLASS_ID_IGESTUREEVENT));
		if (event)
		{
			event->Initialize();
		}
		return (IGestureEvent*)event;
	}
	ISystemEvent* ISystemEvent::CreateInstance()
	{
		CSystemEvent* event = dynamic_cast<CSystemEvent*>(Instance::CreateInstance(CLASS_ID_ISYSTEMEVENT));
		if (event)
		{
			event->Initialize();
		}
		return (ISystemEvent*)event;
	}
	ICustomEvent* ICustomEvent::CreateInstance()
	{
		CCustomEvent* event = dynamic_cast<CCustomEvent*>(Instance::CreateInstance(CLASS_ID_ICUSTOMEVENT));
		if (event)
		{
			event->Initialize();
		}
		return (ICustomEvent*)event;
	}
	IFocusEvent* IFocusEvent::CreateInstance()
	{
		CFocusEvent* event = dynamic_cast<CFocusEvent*>(Instance::CreateInstance(CLASS_ID_IFOCUSEVENT));
		if (event)
		{
			event->Initialize();
		}
		return (IFocusEvent*)event;
	}

}