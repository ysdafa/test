#ifndef _CLISTENER_H_
#define _CLISTENER_H_
namespace HALO
{
	//! Event or Captured event
	typedef enum E_HALO_EVENT_ROUTINE_TYPE 
	{
		E_HALO_EVENT_ROUTINE_CAPTURED	= 0,				//!< Captured event
		E_HALO_EVENT_ROUTINE_BUBBLE,   					//!< Bubble event

		E_HALO_EVENT_ROUTINE_MAX,
	}EEventRoutineType;

	class ListenerSet
	{
		struct sListenerPtrComparator
		{
			bool operator()(IListenerPtr left, IListenerPtr right) const
			{
				return left < right;
			}
		};
	protected:
		typedef std::set<IListenerPtr, sListenerPtrComparator> ListenerList ;
		ListenerList m_list;

	public:
		ListenerSet();
		virtual ~ListenerSet();

		bool Add(IListenerPtr ptr);

		bool Remove(IListenerPtr listener);

		bool Empty(void);
	};

	//! focus listener set
	class CFocusListenerSet : public ListenerSet
	{
	public:
		CFocusListenerSet();
		CFocusListenerSet(IActor* owner);
		virtual ~CFocusListenerSet();
		virtual bool Process(IEvent* event);
	private:
		IActor* m_pOwner;
	};

	class CSemanticEventListenerSet : public ListenerSet
	{
	public:
		CSemanticEventListenerSet();
		CSemanticEventListenerSet(IActor* owner);
		virtual ~CSemanticEventListenerSet();
		virtual bool Process(IEvent* event);
	private:
		IActor* m_pOwner;
	};
	
	class CSystemEventListenerSet : public ListenerSet
	{
	public:
		CSystemEventListenerSet();
		virtual ~CSystemEventListenerSet();
		virtual bool Process(IEvent* event);
	};

	class CAsyncTaskListenerSet : public ListenerSet
	{
	public:
		CAsyncTaskListenerSet();
		virtual ~CAsyncTaskListenerSet();
		virtual bool Process(IEvent* event);
	};

	class CCustomEventListenerSet : public ListenerSet
	{
	public:
		CCustomEventListenerSet();
		virtual ~CCustomEventListenerSet();
		virtual bool Process(IEvent* event, IEvent* reply, bool bReply);
	};

	class CKeyboardListenerSet : public ListenerSet
	{
	public:
		CKeyboardListenerSet(IActor* owner);
		virtual ~CKeyboardListenerSet();
		virtual bool Process(IEvent* event, EEventRoutineType eventType);
		virtual bool Process(ClutterEvent* event, EEventRoutineType eventType);
	private:
		IActor* m_pOwner;
	};
	
	// !mouse listener set
	class CMouseListenerSet : public ListenerSet
	{
	public:
		CMouseListenerSet(IActor* owner);
		virtual ~CMouseListenerSet();
		virtual bool Process(IEvent* event, EEventRoutineType eventType);
		virtual bool Process(ClutterEvent* event, EEventRoutineType eventType);
	private:
		IActor* m_pOwner;
	};

	class CClickListenerSet : public ListenerSet
	{
	public:
		CClickListenerSet();
		CClickListenerSet(IActor* owner);
		virtual ~CClickListenerSet();
		virtual bool Process(IEvent* event);
	private:
		IActor* m_pOwner;
	};

	//! Drag listener set
	class CDragListenerSet : public ListenerSet
	{
	public:
		CDragListenerSet();
		CDragListenerSet(IActor* owner);
		virtual ~CDragListenerSet();
		virtual bool Process(IEvent* event);
	private:
		IActor* m_pOwner;
	};

	//! Gesture listener set
	class CGestureListenerSet : public ListenerSet
	{
	public:
		CGestureListenerSet();
		CGestureListenerSet(IActor* owner);
		virtual ~CGestureListenerSet();
		virtual bool Process(IEvent* event);
	private:
		IActor* m_pOwner;
	};
	
	//! Key long press listener set
	class CKeyLongPressListenerSet : public ListenerSet
	{
	public:
		CKeyLongPressListenerSet();
		CKeyLongPressListenerSet(IActor* owner);
		virtual ~CKeyLongPressListenerSet();
		virtual bool Process(IEvent* event);
	private:
		IActor* m_pOwner;
	};

	class CKeyCombinationListenerSet : public ListenerSet
	{
	public:
		CKeyCombinationListenerSet();
		CKeyCombinationListenerSet(IActor* owner);
		virtual ~CKeyCombinationListenerSet();
		virtual bool Process(IEvent* event);
	private:
		IActor* m_pOwner;
	};
}
#endif