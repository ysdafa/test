#ifndef _CLISTENER_H_
#define _CLISTENER_H_
namespace HALO
{
	//! Event or Captured event
	typedef enum E_HALO_EVENT_ROUTINE_TYPE 
	{
		E_HALO_EVENT_ROUTINE_CAPTURED	= 0,				//!< Captured event
		E_HALO_EVENT_ROUTINE_BUBBLE,   					//!< Bubble event

		E_HALO_EVENT_ROUTINE_MAX,
	}EEventRoutineType;

	class CWidgetExtension;

	class IListenerData
	{
	public:
		IListenerData();
		virtual ~IListenerData();
	};

	class ListenerSet
	{
		struct sListenerPtrComparator
		{
			bool operator()(IListenerPtr left, IListenerPtr right) const
			{
				return left < right;
			}
		};
	protected:
		typedef std::set<IListenerPtr, sListenerPtrComparator> ListenerList ;
		ListenerList m_list;
	private:
		int m_isProcessing;

	public:
		ListenerSet();
		virtual ~ListenerSet();

		bool Add(IListenerPtr ptr);

		bool Remove(IListenerPtr listener);
		
		bool Empty(void);

		void Clear(void);

		void Lock(void);

		void Unlock(void);

		bool IsLocked(void);

		bool Process(IListenerData* data);
	protected:
		virtual bool t_Process(IListenerData* data);
	};

	//! focus listener set
	class CFocusListenerSet : public ListenerSet
	{
	public:
		CFocusListenerSet();
		CFocusListenerSet(CWidgetExtension* owner);
		virtual ~CFocusListenerSet();
		virtual bool Process(IEvent* event);
	private:
		CWidgetExtension* m_pOwner;
	};

	class CSemanticEventListenerSet : public ListenerSet
	{
	public:
		CSemanticEventListenerSet();
		CSemanticEventListenerSet(CWidgetExtension* owner);
		virtual ~CSemanticEventListenerSet();
		virtual bool Process(IEvent* event);
	private:
		CWidgetExtension* m_pOwner;
	};
	
	class CSystemEventListenerSet : public ListenerSet
	{
	public:
		CSystemEventListenerSet();
		virtual ~CSystemEventListenerSet();
		virtual bool Process(IEvent* event);
	};

	class CAsyncTaskListenerSet : public ListenerSet
	{
	public:
		CAsyncTaskListenerSet();
		virtual ~CAsyncTaskListenerSet();
		virtual bool Process(IEvent* event);
	};

	class CCustomEventListenerSet : public ListenerSet
	{
	public:
		CCustomEventListenerSet();
		virtual ~CCustomEventListenerSet();
		virtual bool Process(IEvent* event, IEvent* reply, bool bReply);
	};

	class CKeyboardListenerSet : public ListenerSet
	{
	public:
		CKeyboardListenerSet(CWidgetExtension* owner);
		virtual ~CKeyboardListenerSet();
		virtual bool Process(IEvent* event, EEventRoutineType eventType);
		virtual bool Process(ClutterEvent* event, EEventRoutineType eventType);
	private:
		CWidgetExtension* m_pOwner;
	};
	
	// !mouse listener set
	class CMouseListenerSet : public ListenerSet
	{
	public:
		CMouseListenerSet(CWidgetExtension* owner);
		virtual ~CMouseListenerSet();
		virtual bool Process(IEvent* event, EEventRoutineType eventType);
		virtual bool Process(ClutterEvent* event, EEventRoutineType eventType);
	private:
		CWidgetExtension* m_pOwner;
	};

	class CClickListenerSet : public ListenerSet
	{
	public:
		CClickListenerSet();
		CClickListenerSet(CWidgetExtension* owner);
		virtual ~CClickListenerSet();
		virtual bool Process(IEvent* event);
	private:
		CWidgetExtension* m_pOwner;
	};

	//! Drag listener set
	class CDragListenerSet : public ListenerSet
	{
	public:
		CDragListenerSet();
		CDragListenerSet(CWidgetExtension* owner);
		virtual ~CDragListenerSet();
		virtual bool Process(IEvent* event);
	private:
		CWidgetExtension* m_pOwner;
	};

	//! Gesture listener set
	class CGestureListenerSet : public ListenerSet
	{
	public:
		CGestureListenerSet();
		CGestureListenerSet(CWidgetExtension* owner);
		virtual ~CGestureListenerSet();
		virtual bool Process(IEvent* event);
	private:
		CWidgetExtension* m_pOwner;
	};
	
	//! Key long press listener set
	class CKeyLongPressListenerSet : public ListenerSet
	{
	public:
		CKeyLongPressListenerSet();
		CKeyLongPressListenerSet(CWidgetExtension* owner);
		virtual ~CKeyLongPressListenerSet();
		virtual bool Process(IEvent* event);
	private:
		CWidgetExtension* m_pOwner;
	};

	class CKeyCombinationListenerSet : public ListenerSet
	{
	public:
		CKeyCombinationListenerSet();
		CKeyCombinationListenerSet(CWidgetExtension* owner);
		virtual ~CKeyCombinationListenerSet();
		virtual bool Process(IEvent* event);
	private:
		CWidgetExtension* m_pOwner;
	};

	//! Cursor listener set
	class CCursorListenerSet : public ListenerSet
	{
	public:
		CCursorListenerSet();
		CCursorListenerSet(CWidgetExtension* owner);
		virtual ~CCursorListenerSet();
		virtual bool Process(IEvent* event);
	private:
		CWidgetExtension* m_pOwner;
	};
}
#endif