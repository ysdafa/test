#ifndef _RECOGNIZER_H_
#define _RECOGNIZER_H_
namespace HALO
{
	class CActor;
	class CEvent;
	class CAction : virtual public IAction
	{
	public:
		CAction(/*CActor* owner*/);
		virtual ~CAction();

		virtual bool Initialize(IActor* params) ;
		virtual bool IsInterestEvent(IEvent* event) ;
		virtual bool Process(IEvent* inEvent, IEvent** outEvent) ;

		virtual bool Initialize(void) {return true;}
		virtual bool IsInitialized(void) const { return true; }

		virtual ClutterAction* Action(void);

	protected:
		CActor* t_pOwner;
		ClutterAction* t_pClutterAction;
	};

	typedef CAction* CActionPtr;

	class CClickAction : virtual public CAction, virtual public IClickAction
	{
	public:
		CClickAction();
		~CClickAction();

		virtual bool Initialize(IActor* params) ;
		virtual bool IsInterestEvent(IEvent* event) ;
		virtual bool Process(IEvent* inEvent, IEvent** outEvent);

		unsigned int GetButton(void);
		unsigned int GetState(void);
		void GetCoords(float* pX, float* pY);
	private:
		static gboolean s_onClickedCb(ClutterClickAction* action, ClutterActor* owner, ClutterLongPressState state, gpointer user);
		static gboolean s_onLongPressCb(ClutterClickAction* action, ClutterActor* owner, ClutterLongPressState state, gpointer user);
	};

	//! Drag recognizer
	class CDragAction : virtual public CAction, virtual public IDragAction
	{
	public:
		CDragAction();
		virtual ~CDragAction();

		virtual void SetDragAxis(ClutterDragAxis axis);
		virtual void SetDragArea(float x, float y, float width, float height);

		virtual bool Initialize(IActor* params) ;
		virtual bool IsInterestEvent(IEvent* event) ;
		virtual bool Process(IEvent* inEvent, IEvent** outEvent);

		void GetDragThreshold(ClutterDragAction *action, unsigned int *x_threshold, unsigned int *y_threshold);
		int GetDragAxis(void);
		void GetDragArea(ClutterRect *drag_area);
		void GetPressCoords (ClutterDragAction *action, gfloat *press_x, gfloat *press_y);
		void GetMotionCoords (ClutterDragAction *action, gfloat *motion_x, gfloat *motion_y);
	private:
		static void s_onDragBeginCb(ClutterDragAction  *action, ClutterActor *actor, gfloat event_x, gfloat event_y, ClutterModifierType modifiers, gpointer user_data);
		static void s_onDragEndCb(ClutterDragAction  *action, ClutterActor *actor, gfloat event_x, gfloat event_y, ClutterModifierType modifiers, gpointer user_data);
		static void s_onDragMotionCb(ClutterDragAction  *action, ClutterActor *actor, gfloat delta_x, gfloat delta_y, gpointer user_data);
		//static gboolean s_onDragProgressCb(ClutterDragAction  *action, ClutterActor *actor, gfloat delta_x, gfloat delta_y, gpointer user_data);

		gfloat m_motionX;
		gfloat m_motionY;
		gfloat m_preMotionX;
		gfloat m_preMotionY;
		gfloat m_pressX;
		gfloat m_pressY;
		unsigned int m_timer;
		ClutterActor *m_actor;
		static gboolean m_onHoldStatusCb(void *data);
	}; //! Drag recognizer end
	
	//! Gesture recognizer
	class CGestureAction : virtual public CAction, virtual public IGestureAction
	{
	public:
		CGestureAction();
		virtual ~CGestureAction();

		virtual bool Initialize(IActor* params) ;
		virtual bool IsInterestEvent(IEvent* event) ;
		virtual bool Process(IEvent* inEvent, IEvent** outEvent);
		
	private:
		static gboolean s_onGestureBeginCb(ClutterGestureAction *action, ClutterActor *actor, gpointer user_data);
		static void s_onGestureCancelCb(ClutterGestureAction *action, ClutterActor *actor, gpointer user_data);
		static void s_onGestureEndCb(ClutterGestureAction *action, ClutterActor *actor, gpointer user_data);
		static gboolean s_onGestureProgressCb(ClutterGestureAction *action, ClutterActor *actor, gpointer user_data);
	}; //! Gesture recognizer end

	//! KeyLongPressRecognizer
	class CKeyLongPressAction : virtual public CAction, virtual public IKeyLongPressAction
	{
	public:
		CKeyLongPressAction();
		virtual ~CKeyLongPressAction();

		virtual bool Initialize(IActor* params) ;
		virtual bool IsInterestEvent(IEvent* event) ;
		virtual bool Process(IEvent* inEvent, IEvent** outEvent);
		virtual bool AddLongPressKey(unsigned int key_val);
		virtual bool RemoveLongPressKey(unsigned int key_val);
		
	private:
		static gboolean s_onKeyLongPressCb(ClutterActor* actor, ClutterEvent* event, gpointer user_data);

		//bool m_IsLongPressKey(ClutterEvent* pEvent);
		bool m_bLongPressSend;
		int m_keyCounter;
		unsigned int m_timer;
		ClutterEvent* m_clutterEvent;
		typedef std::set<unsigned int> LongPressEventList;
		LongPressEventList m_longPressKeyList;

		guint m_eventId;
		guint m_focusInId;
		guint m_focusOutId;
		
		static gboolean m_onKeyLongPressTimerCb(void *data);

		static gboolean m_KeyFocusOutCb(ClutterActor* actor, CKeyLongPressAction *user_data);
		static gboolean m_KeyFocusInCb(ClutterActor* actor, CKeyLongPressAction *user_data);
		bool m_IsLongPressKey(ClutterEvent* pEvent);
	}; //! KeyLongPressRecognizer end

	class CKeyCombinationAction : virtual public CAction, virtual public IKeyCombinationAction
	{
	public:	
		CKeyCombinationAction();
		~CKeyCombinationAction();

		virtual bool Initialize(IActor* params);
		virtual bool IsInterestEvent(IEvent* event);
		virtual bool Process(IEvent* inEvent, IEvent** outEvent);
		virtual bool AddKey(unsigned int key_val);

	private:
		std::vector<unsigned int> m_keyList;

		int m_timer;
		int m_keyCounter;

		long m_getTime(void);
		bool m_isCombinationKey(ClutterEvent* pEvent);	
		void m_sendEvent(ClutterEvent* pEvent);
		static gboolean m_onTimerCb(void *data);
		static gboolean s_onKeyCombinationCb(ClutterActor *actor, ClutterEvent *event, gpointer user_data);
	};
	
	class RecognizerSet
	{
		struct sRecognizerPtrComparator
		{
			bool operator()(CActionPtr left, CActionPtr right) const
			{
				return left < right;
			}
		};
	protected:
		typedef std::set<CActionPtr, sRecognizerPtrComparator> RecognizerList ;
		RecognizerList m_list;

	public:
		RecognizerSet() {}
		virtual ~RecognizerSet()
		{
			ASSERT( m_list.empty() );
			m_list.clear();
		}

		bool Add(CActionPtr ptr)
		{
			std::pair<RecognizerList::iterator, bool> ret = m_list.insert(ptr);
			if(ret.second != true)
			{
				ASSERT(false && "Add existing Recognizer");
			}

			return true;
		}

		bool Remove(CActionPtr Recognizer)
		{
			unsigned int num = (unsigned int)m_list.erase(Recognizer);

			if(num !=1)
			{
				ASSERT(false);
			}

			return true;
		}

		bool Empty(void)
		{
			return m_list.empty();
		}

	};
}

#endif