#ifndef _CINPUTMANAGER_H_
#define _CINPUTMANAGER_H_

namespace HALO
{
	class CInputManager
	{
	public:
		CInputManager();
		~CInputManager();
		gboolean ProcessInputEvent(const ClutterEvent* event);
	};
}
#endif