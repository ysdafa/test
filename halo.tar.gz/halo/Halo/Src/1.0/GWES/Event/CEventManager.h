#ifndef _CEVENTMANAGER_H_
#define _CEVENTMANAGER_H_
namespace HALO
{
	class CEventManager : public IEventManager
	{	
	public:
		CEventManager();
		virtual ~CEventManager();
		bool SendEventLocal(IEvent* event);
		bool SendEventLocalSync(IEvent* requestEvent, IEvent* responseEvent);
		bool SendEventRemote(const char* target, IEvent* requestEvent, bool bAsync, bool* pbHasResponse, IEvent* responseEvent);

		bool AddSystemEventListener(ISystemEventListener* systemListener);
		bool RemoveSystemEventListener(ISystemEventListener* systemListener);
		bool AddAsyncTaskListener(ITaskListener* taskListener);
		bool RemoveAsyncTaskListener(ITaskListener* taskListener);
		bool AddCustomEventListener(ICustomEventListener* customListener);
		bool RemoveCustomEventListener(ICustomEventListener* customListener);
		gboolean ProcessClutterEvent(const ClutterEvent* event);
		gboolean ProcessEvent(CEvent* event);
		int GetEventType(const char* eventName);
		const char* GetEventName(int eventType);
		virtual void RegisterInterestingEvent(const char *eventName);
		virtual void UnregisterInterestingEvent(const char *eventName);
		//! Set key long press timer interval
		virtual void SetKeyLongPressInterval(int interval);
		virtual int KeyLongPressInterval(void);
		
	private:
		CInputManager* m_pInputManager;
		CMutex* m_pListenerSetLock;
		CSystemEventListenerSet* m_pSystemEventListenerSet;
		CAsyncTaskListenerSet* m_pAsyncTaskListenerSet;
		CCustomEventListenerSet* m_pCustomEventListenerSet;
		typedef std::map<int, std::string> EventTypeMap;
		typedef std::map<int, std::string>::iterator EventTypeMapIter;
		EventTypeMap m_eventTypeMap;
		int m_eventTypeMax;
		CMutex m_eventTypeMapLock;
		CDbus* m_dbus;
		int m_keyLongPressInterval;

	private:
		CEventManager(const CEventManager& eventManager);
		CEventManager& operator=(const CEventManager& eventManager);

	};
}
#endif