#ifndef _CEVENT_H_
#define _CEVENT_H_

namespace HALO
{
	struct TClientInfo
	{
		char* data;
		int len;
		TClientInfo(): data(NULL), len(0){}
		~TClientInfo()
		{
			if (data)
			{
				delete[] data;
				data = NULL;
			}
		}
	};
	class CEventManager;
	class CEvent : virtual public IEvent
	{
		friend class CEventManager;
	public:
		CEvent();
		CEvent(const CEvent& pEvent);
		CEvent(ClutterEvent* event);
		virtual ~CEvent();
		//assignment operator
		CEvent& operator=(const CEvent& pEvent);

		virtual bool Initialize() {return true;}
		virtual bool IsInitialized() const {return true;}

		virtual IEvent* Clone(void);

		//! Destroy an instance
		//virtual void Destroy(void) ;
		virtual int SetReceiver(IWidgetExtension* actor) ;
		virtual IWidgetExtension* Receiver(void) ;

	protected:
		virtual void SetEventType(int eventType) ;
		virtual int EventType(void) const;

	public:
		virtual void SetEventType(const char* eventName) ;
		virtual bool IsEventType(const char* eventName) ;

		virtual ClutterEvent* Transform(void);

		virtual bool PutInt(const char* key, int value);
		virtual bool PutLong(const char* key, long value);
		virtual bool PutDouble(const char* key, double value);
		virtual bool PutFloat(const char* key, float value);
		virtual bool PutChar(const char* key, char value);
		virtual bool PutString(const char* key, const char* value);
		virtual bool PutPointor(const char* key, void* pointor);

		virtual bool GetInt(const char* key, int& value);
		virtual bool GetLong(const char* key, long& value);
		virtual bool GetDouble(const char* key, double& value);
		virtual bool GetFloat(const char* key, float& value);
		virtual bool GetChar(const char* key, char& value);
		virtual bool GetString(const char* key, char** value);
		virtual bool GetPointor(const char* key, void** value);
	protected:
		int t_eventType;
		int t_time;
		int t_flags;
		CStage* t_pReceiveStage;
		IWidgetExtension* t_pReceiverActor;
		CBundle t_bundle;
	//! Not public, only internal use
	public:
		bool EncodeBundle(unsigned char** r, int* len);
		bool DecodeBundle(const unsigned char* r, const int data_size);
	};
	class CKeyboardEvent : virtual public IKeyboardEvent, virtual public CEvent
	{
	public:
		CKeyboardEvent();
		CKeyboardEvent(ClutterEvent* event);
		virtual ~CKeyboardEvent();
		virtual ClutterEvent* Transform(void);
		virtual int GetModifierType(void) const;
		virtual int GetKeyVal(void) const;
		virtual short GetHardwareKeyCode(void) const;
		virtual int GetUnicodeValue(void) const;
		virtual void* GetKeyComActionData(void) const;
		virtual void SetModifierType(int modifierType);
		virtual void SetKeyVal(int keyVal);
		virtual void SetHardwareKeyCode(short hardwareKeyCode);
		virtual void SetUnicodeValue(int unicodeValue);
		virtual void SetKeyComActionData(void* data);
	private:
		ClutterModifierType m_modifierState;
		unsigned int m_keyVal;
		unsigned short m_hardwareKeyCode;
		unsigned int m_unicodeValue;
		void* m_pData;
		//CInputDevice* m_pInputDevice;

	};

	//mouse event
	class CMouseEvent : virtual public IMouseEvent, virtual public CEvent
	{
	public:
		CMouseEvent();
		CMouseEvent(const CMouseEvent& mouseEvent);
		CMouseEvent(ClutterEvent* event);
		virtual ~CMouseEvent();	
		//assignment operator
		CMouseEvent& operator=(const CMouseEvent& pEvent);
		virtual CMouseEvent* Clone(void);
		virtual ClutterEvent* Transform(void);
		virtual int GetModifierType() const { return m_modifierState; };
		virtual float GetX(); //{ return m_x; }
		virtual float GetY(); //{ return m_y; }
		virtual int ClickCount() const { return m_click_count; };
		virtual EButtonPressType ButtonPressType() const { return m_button; };
		virtual ClutterScrollDirection ScrollDirection() const { return m_scrollDirection; };

		virtual void SetModifierType( int type) { m_modifierState = (ClutterModifierType)type; };
		virtual void SetX(float x) { m_x = x; }
		virtual void SetY(float y) { m_y = y; }
		

	private:
		//! General mouse property
		float m_x;
		float m_y;
		ClutterModifierType m_modifierState;
		ClutterInputDevice* m_device;
		//! Scroll event only
		ClutterScrollDirection m_scrollDirection;  
		//! Button event only
		EButtonPressType m_button;
		unsigned int m_click_count;
		//! Enter event only
		ClutterActor *m_related;
	};
	class CTouchEvent : virtual public ITouchEvent , virtual public CEvent
	{
	public:
		CTouchEvent() {}
	};
	class CRemoconEvent : virtual public IRemoconEvent , virtual public CEvent
	{
	public:
		CRemoconEvent() {}
	};
	class CRidgeEvent : virtual public IRidgeEvent , virtual public CEvent
	{
	public:
		CRidgeEvent() {}
	};
	class CMotionEvent : virtual public IMotionEvent , virtual public CEvent
	{
	public:
		CMotionEvent() {}
	};
	class CSensorEvent : virtual public ISensorEvent , virtual public CEvent
	{
	public:
		CSensorEvent() {}
	};
	class CCursorEvent : virtual public ICursorEvent , virtual public CEvent
	{
	public:
		CCursorEvent();
		CCursorEvent(const CCursorEvent& event);
		CCursorEvent(ClutterEvent* event);
		virtual ~CCursorEvent();		
		CCursorEvent& operator=(const CCursorEvent& pEvent);
		virtual IEvent* Clone(void);
		virtual ClutterEvent* Transform(void);
		virtual float GetX() const { return m_x; }
		virtual float GetY() const { return m_y; }
		virtual void SetX(float x) { m_x = x; }
		virtual void SetY(float y) { m_y = y; }
	private:
		float m_x;
		float m_y;
	};
	class CClickEvent : virtual public IClickEvent , virtual public CEvent
	{
	public:
		CClickEvent();
		CClickEvent(ClutterEvent* event);
		virtual ~CClickEvent();
	};
	class CLongPressEvent : virtual public ILongPressEvent , virtual public CEvent
	{
	public:
		CLongPressEvent();
		CLongPressEvent(ClutterEvent* event);
		virtual	~CLongPressEvent();
	};

	//! Drag event
	class CDragEvent : virtual public IDragEvent , virtual public CEvent
	{
	public:
		CDragEvent() {}
		CDragEvent(EDragSignalType signalType);
		CDragEvent(ClutterEvent* event);
		virtual ~CDragEvent();
		virtual EDragSignalType DragSignalType();
		virtual void MotionCoords(float *motion_x, float *motion_y);
		virtual void PressCoords(float *press_x, float *press_y);
		virtual void MotionDelta(float *delta_x, float * delta_y);
	
	//! no public
	public:  
		void SetMotionCoords(float motion_x, float motion_y);
		void SetPressCoords(float press_x, float press_y);
		void SetMotionDelta(float delta_x, float delta_y);

	private:
		EDragSignalType t_signalType;
		float t_motionX;
		float t_motionY;
		float t_pressX;
		float t_pressY;
		float t_deltaX;
		float t_deltaY;
	}; //! Drag event end

	//! Gesture event
	class CGestureEvent : virtual public IGestureEvent , virtual public CEvent
	{
	public:
		CGestureEvent() {}
		CGestureEvent(EGestureSignalType signalType);
		CGestureEvent(ClutterEvent* event);
		virtual ~CGestureEvent();

		EGestureSignalType GestureSignalType();
		//! Retrieves the threshold trigger distance of the gesture action
		virtual void ThresholdTriggerDistance(float *x, float *y);
		//! Retrieves the number of requested points to trigger the gesture.
		virtual int TouchPoints();
		//! Retrieves the number of points currently active.
		virtual int CurrentPoints();

	public:
		void SetThresholdTriggerDistance(float x, float y);
		void SetTouchPoints(int num);
		void SetCurrentPoints(int num);

	private:
		EGestureSignalType t_signalType;
		float t_thresholdX;
		float t_thresholdY;
		int t_touchPoints;
		int t_curPoints;

	}; // !Gesture event end
	
	class CSystemEvent : virtual public ISystemEvent, virtual public CEvent
	{
	public:
		CSystemEvent();
		CSystemEvent(const CSystemEvent& event);
		CSystemEvent(ClutterEvent* event);
		virtual ~CSystemEvent();
		CSystemEvent& operator=(const CSystemEvent& pEvent);		
		virtual IEvent* Clone(void);
		virtual ClutterEvent* Transform();
	};

	class CCustomEvent : virtual public ICustomEvent, virtual public CEvent
	{
	public:
		CCustomEvent();
		CCustomEvent(const CCustomEvent& event);
		CCustomEvent(ClutterEvent* event);
		virtual ~CCustomEvent();
		CCustomEvent& operator=(const CCustomEvent& pEvent);		
		virtual IEvent* Clone(void);
		virtual ClutterEvent* Transform();
		virtual void SetEventType(int eventType);
		virtual void SetEventType(const char* eventName);
		/*virtual bool IsEventType(const char* eventName);*/
	};

	class CFocusEvent : virtual public IFocusEvent , virtual public CEvent
	{
	public:
		CFocusEvent() {}
		CFocusEvent(EFocusType eventType);
		CFocusEvent(ClutterEvent* event);
		CFocusEvent& operator=(const CFocusEvent& pEvent);		
		virtual IEvent* Clone(void);
		virtual ClutterEvent* Transform();
		virtual ~CFocusEvent();

		EFocusType FocusEventType();
	private:
		EFocusType m_eventType;
	};
}
#endif