#include "Halo1_0.h"

namespace HALO
{
	IEventManager* IEventManager::g_eventManager = NULL;
	extern bool g_initialized;
	extern bool g_preInitialized;

	IEventManager* IEventManager::GetInstance(void)
	{
		if (g_initialized == false && g_preInitialized == false)
		{
			return NULL;
		}

		if (g_eventManager == NULL)
		{
			g_eventManager = (IEventManager*)Instance::CreateInstance(CLASS_ID_IEVENTMANAGER);
		}
		return g_eventManager;
	}
}