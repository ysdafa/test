#include "Halo1_0.h"

#define LONG_PRESS_COUNT 10
static HALO::util::Logger LOGGER("Action");

namespace HALO
{
	extern CStage *g_stage;
	extern CEventManager* g_pEventManager;

	CAction::CAction(/*CActor* owner*/):t_pOwner(/*owner*/NULL), t_pClutterAction(NULL)
	{
	}
	CAction::~CAction()
	{
	}

	bool CAction::Initialize(IActor* params) 
	{
		H_LOG_TRACE(LOGGER, "CAction::Initialize ");
		CActor* pOwner = dynamic_cast<CActor*>(params);
		if (pOwner == NULL)
		{
			return false;
		}
		t_pOwner = pOwner;
		return true;
	}
	
	bool CAction::IsInterestEvent(IEvent* event) 
	{
		return false;
	}
	bool CAction::Process(IEvent* inEvent, IEvent** outEvent) 
	{
		return false;
	}

	ClutterAction* CAction::Action(void)
	{
		return t_pClutterAction;
	}

	CClickAction::CClickAction()
	{
		
	}
	CClickAction::~CClickAction()
	{
		clutter_click_action_release((ClutterClickAction*)t_pClutterAction);
	}

	bool CClickAction::Initialize(IActor* params) 
	{
		H_LOG_TRACE(LOGGER, "CClickAction::Initialize ");
		CAction::Initialize(params);
		t_pClutterAction = clutter_click_action_new();
		//clutter_actor_add_action(t_pOwner->Actor(), t_pClutterAction);
		g_signal_connect (t_pClutterAction, "clicked", G_CALLBACK (s_onClickedCb), t_pOwner->Actor());
		g_signal_connect (t_pClutterAction, "long-press", G_CALLBACK (s_onLongPressCb), t_pOwner->Actor());
		GValue longPressDuration = G_VALUE_INIT;
		g_value_init (&longPressDuration, G_TYPE_INT);
		g_value_set_int(&longPressDuration, 1000);
		GValue longPressThreshold = G_VALUE_INIT;
		g_value_init (&longPressThreshold, G_TYPE_INT);
		g_value_set_int(&longPressThreshold, 5);
		 
		g_object_set_property(G_OBJECT(t_pClutterAction), "long-press-duration", (GValue*)&longPressDuration);
		g_object_set_property(G_OBJECT(t_pClutterAction), "long-press-threshold", (GValue*)&longPressThreshold);

		return true;
	}
	
	bool CClickAction::IsInterestEvent(IEvent* event) 
	{
		return false;
	}
	bool CClickAction::Process(IEvent* inEvent, IEvent** outEvent) 
	{
		return false;
	}

	gboolean CClickAction::s_onClickedCb(ClutterClickAction* action, ClutterActor* owner, ClutterLongPressState state, gpointer userData)
	{
		H_LOG_TRACE(LOGGER, "CClickAction::s_onClickedCb(" << action << ", " << owner << ", " << state << ")");
		CClickEvent clickEvent;
		clickEvent.SetEventType("samsung.tv.halo.input.mouseclicked");
		CActor* actor = D_GET_HALO_ACTOR(G_OBJECT(owner));
		if (NULL != actor)
		{
			clickEvent.SetReceiver(actor);
			actor->OnEvent(&clickEvent);
		}
		return false;
	}
	gboolean CClickAction::s_onLongPressCb(ClutterClickAction* action, ClutterActor* owner, ClutterLongPressState state, gpointer userData)
	{
		H_LOG_TRACE(LOGGER, "CClickAction::s_onLongPressCb(" << action << ", " << owner << ", " << state << ")");
		switch (state)
		{
		case CLUTTER_LONG_PRESS_QUERY:
			{
				return true;
			}
		case CLUTTER_LONG_PRESS_ACTIVATE:
			{
				CLongPressEvent longPressEvent;
				longPressEvent.SetEventType("samsung.tv.halo.input.mouselongpress");
				CActor *actor = D_GET_HALO_ACTOR(G_OBJECT(owner));
				if (NULL != actor)
				{
					longPressEvent.SetReceiver(actor);
					actor->OnEvent(&longPressEvent);
				}
				return false;
			}
		case CLUTTER_LONG_PRESS_CANCEL:
			{
				break;
			}
		default:
			{
				break;
			}
		}
		return false;
	}
	unsigned int CClickAction::GetButton(void)
	{
		return 0;
	}
	unsigned int CClickAction::GetState(void)
	{
		return 0;
	}
	void CClickAction::GetCoords(float* pX, float* pY)
	{
	}

	CDragAction::CDragAction()
	{
		
	}
	//! CDragRecognizer
	bool CDragAction::Initialize(IActor* params)
	{
		H_LOG_TRACE(LOGGER, "CDragAction::Initialize ");
		CAction::Initialize(params);
		m_motionX = 0;
		m_motionY = 0;
		m_preMotionX = 0;
		m_preMotionY = 0;
		m_pressX = 0;
		m_pressY = 0;
		m_timer = 0;
		m_actor = NULL;
		t_pClutterAction = clutter_drag_action_new();
		ASSERT(t_pClutterAction != NULL);
		g_object_ref_sink(t_pClutterAction);

		//! Set drag threshold
		clutter_drag_action_set_drag_threshold(CLUTTER_DRAG_ACTION(t_pClutterAction), 2, 2);
		//! Set drag axis
		clutter_drag_action_set_drag_axis(CLUTTER_DRAG_ACTION (t_pClutterAction), CLUTTER_DRAG_AXIS_NONE);
		//! Set drag area
		/*ClutterRect drag_rect = CLUTTER_RECT_INIT_ZERO;
		ClutterActor *stage = IStage::GetInstance()->Stage();
		clutter_actor_get_size(stage, &drag_rect.size.width, &drag_rect.size.height);
		gfloat w = 0.f;
		gfloat h = 0.f;
		clutter_actor_get_size(t_pOwner->Actor(), &w, &h);
		drag_rect.origin.x = 0.0f;
		drag_rect.origin.y = 0.0f;
		drag_rect.size.height -= h;
		drag_rect.size.width -= w;*/
		//clutter_drag_action_set_drag_area(CLUTTER_DRAG_ACTION(t_pClutterAction), &drag_rect);
		//! Add action to actor
		//clutter_actor_add_action(t_pOwner->Actor(), t_pClutterAction);
		//! Set signal callback
		g_signal_connect (t_pClutterAction, "drag-begin", G_CALLBACK (s_onDragBeginCb), this);
		g_signal_connect (t_pClutterAction, "drag-end", G_CALLBACK (s_onDragEndCb), this);
		g_signal_connect (t_pClutterAction, "drag-motion", G_CALLBACK (s_onDragMotionCb), this);
		//g_signal_connect (t_pClutterAction, "drag-progress", G_CALLBACK (s_onDragProgressCb), this);

		return true;
	}

	CDragAction::~CDragAction()
	{
		
	}

	void CDragAction::GetMotionCoords (ClutterDragAction *action, gfloat *motion_x, gfloat *motion_y)
	{		
		clutter_drag_action_get_motion_coords(action, motion_x, motion_y);
		H_LOG_TRACE(LOGGER, "CDragAction::GetMotionCoords motion_x = " << motion_x << ", motion_y = " << motion_y);
	}

	void CDragAction::GetPressCoords (ClutterDragAction *action, gfloat *press_x, gfloat *press_y)
	{
		clutter_drag_action_get_press_coords(action, press_x, press_y);
		H_LOG_TRACE(LOGGER, "CDragAction::GetPressCoords press_x = " << press_x << ", press_y = " << press_y);
	}

	void CDragAction::GetDragArea(ClutterRect *drag_area)
	{		
		clutter_drag_action_get_drag_area(CLUTTER_DRAG_ACTION (t_pClutterAction), drag_area);
		H_LOG_TRACE(LOGGER, "CDragAction::GetDragArea drag_area.x = " << drag_area->origin.x << ", drag_area.x = " << drag_area->origin.y << ", drag_area.width = " << drag_area->size.width << ", drag_area.height" << drag_area->size.height);
	}

	bool CDragAction::IsInterestEvent(IEvent* event) 
	{
		return false;
	}
	bool CDragAction::Process(IEvent* inEvent, IEvent** outEvent) 
	{
		return false;
	}

	void CDragAction::SetDragAxis(ClutterDragAxis axis)
	{
		H_LOG_TRACE(LOGGER, "CDragAction::SetDragAxis(" << axis << ")");
		clutter_drag_action_set_drag_axis(CLUTTER_DRAG_ACTION (t_pClutterAction), axis);		
	}

	int CDragAction::GetDragAxis(void)
	{
		H_LOG_TRACE(LOGGER, "CDragAction::GetDragAxis axis = " << clutter_drag_action_get_drag_axis(CLUTTER_DRAG_ACTION (t_pClutterAction)));
		return clutter_drag_action_get_drag_axis(CLUTTER_DRAG_ACTION (t_pClutterAction));
	}

	void CDragAction::SetDragArea(float x, float y, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CDragAction::SetDragArea(" << x <<", " << y << ", " << width << ", " << height << ")");
		ClutterRect drag_rect = CLUTTER_RECT_INIT_ZERO;
		gfloat w = 0.f;
		gfloat h = 0.f;
		clutter_actor_get_size(t_pOwner->Actor(), &w, &h);
		drag_rect.origin.x = x;
		drag_rect.origin.y = y;
		//drag_rect.size.height = height - h;
		//drag_rect.size.width = width - w;
		ClutterDragAxis axis = clutter_drag_action_get_drag_axis(CLUTTER_DRAG_ACTION (t_pClutterAction));
		if (CLUTTER_DRAG_X_AXIS == axis)
		{
			drag_rect.size.width = width - w;
			drag_rect.size.height = height;
		}
		else if (CLUTTER_DRAG_Y_AXIS == axis)
		{
			drag_rect.size.width = width;
			drag_rect.size.height = height - h;
		}
		else if (CLUTTER_DRAG_AXIS_NONE == axis)
		{
			drag_rect.size.width = width - w;
			drag_rect.size.height = height - h;
		}

		clutter_drag_action_set_drag_area(CLUTTER_DRAG_ACTION (t_pClutterAction), &drag_rect);
		H_LOG_TRACE(LOGGER, "CDragAction::SetDragArea drag_rect.x = " << drag_rect.origin.x << ", drag_rect.x = " << drag_rect.origin.y << ", drag_rect.width = " << drag_rect.size.width << ", drag_rect.height" << drag_rect.size.height);
	}


	void CDragAction::s_onDragBeginCb(ClutterDragAction  *action, ClutterActor *actor, gfloat event_x, gfloat event_y, ClutterModifierType modifiers, gpointer user_data)
	{
		H_LOG_TRACE(LOGGER, "CDragAction::s_onDragBeginCb(" << action << ", " << actor << ", " << event_x << ", " << event_y << ", " << modifiers << ", " << user_data << ")");
		CDragAction *pThis = (CDragAction *)user_data;
		//! start hold timer
		pThis->m_timer = g_timeout_add(2000, (GSourceFunc)pThis->m_onHoldStatusCb, user_data); 
		ASSERT(pThis->m_timer > 0);
		//! end
		CDragEvent dragEvent(DRAG_BEGIN);
		gfloat motion_x;
		gfloat motion_y;
		gfloat press_x;
		gfloat press_y;
		pThis->GetMotionCoords (action, &motion_x, &motion_y);
		pThis->GetPressCoords (action, &press_x, &press_y);
		dragEvent.SetMotionCoords(motion_x, motion_y);
		dragEvent.SetPressCoords(press_x, press_y);
		CActor *cActor = D_GET_HALO_ACTOR(G_OBJECT(actor));
		if (NULL != cActor)
		{
			dragEvent.SetReceiver(cActor);
			cActor->OnEvent(&dragEvent);
		}
	}

	void CDragAction::s_onDragEndCb(ClutterDragAction  *action, ClutterActor *actor, gfloat event_x, gfloat event_y, ClutterModifierType modifiers, gpointer user_data)
	{
		H_LOG_TRACE(LOGGER, "CDragAction::s_onDragEndCb(" << action << ", " << actor << ", " << event_x << ", " << event_y << ", " << modifiers << ", " << user_data << ")");
		CDragAction *pThis = (CDragAction *)user_data;
		//! stop hold timer
		if (pThis->m_timer > 0)
		{
			g_source_remove(pThis->m_timer);
			pThis->m_timer = 0;
		}
		//! end
		CDragEvent dragEvent(DRAG_END);
		gfloat motion_x;
		gfloat motion_y;
		gfloat press_x;
		gfloat press_y;
		pThis->GetMotionCoords (action, &motion_x, &motion_y);
		pThis->GetPressCoords (action, &press_x, &press_y);
		dragEvent.SetMotionCoords(motion_x, motion_y);
		dragEvent.SetPressCoords(press_x, press_y);
		CActor *cActor = D_GET_HALO_ACTOR(G_OBJECT(actor));
		if (NULL != cActor)
		{
			dragEvent.SetReceiver(cActor);
			cActor->OnEvent(&dragEvent);
		}
	}

	void CDragAction::s_onDragMotionCb(ClutterDragAction  *action, ClutterActor *actor, gfloat delta_x, gfloat delta_y, gpointer user_data)
	{
		H_LOG_TRACE(LOGGER, "CDragAction::s_onDragMotionCb(" << action << ", " << actor << ", " << delta_x << ", " << delta_y << ", " << user_data << ")");
		CDragAction *pThis = (CDragAction *)user_data;
		CDragEvent dragEvent(DRAG_MOTION);
		gfloat motion_x;
		gfloat motion_y;
		gfloat press_x;
		gfloat press_y;
		pThis->GetMotionCoords (action, &motion_x, &motion_y);
		pThis->GetPressCoords (action, &press_x, &press_y);
		pThis->m_motionX = motion_x;
		pThis->m_motionY = motion_y;
		pThis->m_pressX = press_x;
		pThis->m_pressY = press_y;
		pThis->m_actor = actor;
		dragEvent.SetMotionCoords(motion_x, motion_y);
		dragEvent.SetPressCoords(press_x, press_y);
		dragEvent.SetMotionDelta(delta_x, delta_y);
		CActor *cActor = D_GET_HALO_ACTOR(G_OBJECT(actor));
		dragEvent.SetReceiver(cActor);

		//! judge hold status
		if ((pThis->m_preMotionX - pThis->m_motionX > 2 || pThis->m_motionX - pThis->m_preMotionX > 2) ||
			(pThis->m_preMotionY - pThis->m_motionY > 2 || pThis->m_motionY - pThis->m_preMotionY > 2))
		{
			//! reset the timer
			if (pThis->m_timer > 0)
			{
				g_source_remove(pThis->m_timer);
			}			
			pThis->m_timer = g_timeout_add(2000, (GSourceFunc)pThis->m_onHoldStatusCb, user_data); 
			ASSERT(pThis->m_timer > 0);
		}
		//! end

		if (NULL != cActor)
		{
			cActor->OnEvent(&dragEvent);
		}

		pThis->m_preMotionX = motion_x;
		pThis->m_preMotionY = motion_y;
	}

	gboolean CDragAction::m_onHoldStatusCb(void *data)
	{
		H_LOG_TRACE(LOGGER, "CDragAction::m_onHoldStatusCb ");
		CDragAction *pThis = (CDragAction *)data;
		
		CDragEvent dragEvent(DRAG_HOLD);
		dragEvent.SetMotionCoords(pThis->m_motionX, pThis->m_motionY);
		dragEvent.SetPressCoords(pThis->m_pressX, pThis->m_pressY);
		CActor *cActor = D_GET_HALO_ACTOR(G_OBJECT(pThis->m_actor));
		if (NULL != cActor)
		{
			dragEvent.SetReceiver(cActor);
			cActor->OnEvent(&dragEvent);
		}

		pThis->m_timer = 0;

		return false;
	}

	/*gboolean CDragAction::s_onDragProgressCb(ClutterDragAction  *action, ClutterActor *actor, gfloat delta_x, gfloat delta_y, gpointer user_data)
	{
		H_LOG_TRACE(LOGGER, "CDragAction::s_onDragProgressCb(" << action << ", " << actor << ", " << delta_x << ", " << delta_y << ", " << user_data << ")");
		CDragAction *pThis = (CDragAction *)user_data;
		CDragEvent dragEvent(DRAG_PROGRESS);
		gfloat motion_x;
		gfloat motion_y;
		gfloat press_x;
		gfloat press_y;
		pThis->GetMotionCoords (action, &motion_x, &motion_y);
		pThis->GetPressCoords (action, &press_x, &press_y);
		dragEvent.SetMotionCoords(motion_x, motion_y);
		dragEvent.SetPressCoords(press_x, press_y);
		CActor *cActor = D_GET_HALO_ACTOR(G_OBJECT(actor));
		if (NULL != cActor)
		{
			dragEvent.SetReceiver(cActor);
			cActor->OnEvent(&dragEvent);
		}

		return true;
	}*/
	//! CDragRecognizer End

	CGestureAction::CGestureAction()
	{
	}

	//! CGestureRecognizer
	bool CGestureAction::Initialize(IActor* params)/*:CAction(owner)*/
	{
		H_LOG_TRACE(LOGGER, "CGestureAction::Initialize ");
		CAction::Initialize(params);
		t_pClutterAction = clutter_gesture_action_new();
		//! Set touch points num, default value is 1
		clutter_gesture_action_set_n_touch_points((ClutterGestureAction *)t_pClutterAction, 1);
		//! Set threshold-trigger-distance-x, default value is -1
		//clutter_gesture_action_set_threshold_trigger_distance((ClutterGestureAction *)t_pClutterAction, 6, 6);
		//! Set threshold-trigger-edge, default value is CLUTTER_GESTURE_TRIGGER_EDGE_NONE
		//clutter_gesture_action_set_threshold_trigger_edge((ClutterGestureAction *)t_pClutterAction, CLUTTER_GESTURE_TRIGGER_EDGE_NONE);
		//! Add action to actor
		//clutter_actor_add_action(t_pOwner->Actor(), t_pClutterAction);
		g_signal_connect (t_pClutterAction, "gesture-begin", G_CALLBACK (s_onGestureBeginCb), NULL);
		g_signal_connect (t_pClutterAction, "gesture-cancel", G_CALLBACK (s_onGestureCancelCb), NULL);
		g_signal_connect (t_pClutterAction, "gesture-progress", G_CALLBACK (s_onGestureProgressCb), NULL);
		g_signal_connect (t_pClutterAction, "gesture-end", G_CALLBACK (s_onGestureEndCb), NULL);

		return true;
	}

	CGestureAction::~CGestureAction()
	{
		
	}

	gboolean CGestureAction::s_onGestureBeginCb(ClutterGestureAction *action, ClutterActor *actor, gpointer user_data)
	{
		H_LOG_TRACE(LOGGER, "CGestureAction::s_onGestureBeginCb(" << action << ", " << actor << ", " << user_data << ")");
		CGestureEvent gestureEvent(GESTURE_BEGIN);

		int n;
		n = clutter_gesture_action_get_n_current_points(action);
		gestureEvent.SetCurrentPoints(n);
		n = clutter_gesture_action_get_n_touch_points(action);
		gestureEvent.SetTouchPoints(n);
		//clutter_gesture_action_get_threshold_trigger_distance(action, &x, &y);
		//gestureEvent.SetThresholdTriggerDistance(x, y);

		CActor *cActor = D_GET_HALO_ACTOR(G_OBJECT(actor));
		if (NULL != cActor)
		{
			gestureEvent.SetReceiver(cActor);
			cActor->OnEvent(&gestureEvent);
		}

		return true;
	}

	void CGestureAction::s_onGestureCancelCb(ClutterGestureAction *action, ClutterActor *actor, gpointer user_data)
	{
		H_LOG_TRACE(LOGGER, "CGestureAction::s_onGestureCancelCb(" << action << ", " << actor << ", " << user_data << ")");
		CGestureEvent gestureEvent(GESTURE_CANCEL);
		
		int n;
		n = clutter_gesture_action_get_n_current_points(action);
		gestureEvent.SetCurrentPoints(n);
		n = clutter_gesture_action_get_n_touch_points(action);
		gestureEvent.SetTouchPoints(n);
		//clutter_gesture_action_get_threshold_trigger_distance(action, &x, &y);
		//gestureEvent.SetThresholdTriggerDistance(x, y);

		CActor *cActor = D_GET_HALO_ACTOR(G_OBJECT(actor));
		if (NULL != cActor)
		{
			gestureEvent.SetReceiver(cActor);
			cActor->OnEvent(&gestureEvent);
		}
	}
	bool CGestureAction::IsInterestEvent(IEvent* event) 
	{
		return false;
	}
	bool CGestureAction::Process(IEvent* inEvent, IEvent** outEvent) 
	{
		return false;
	}
	void CGestureAction::s_onGestureEndCb(ClutterGestureAction *action, ClutterActor *actor, gpointer user_data)
	{
		H_LOG_TRACE(LOGGER, "CGestureAction::s_onGestureCancelCb(" << action << ", " << actor << ", " << user_data << ")");
		CGestureEvent gestureEvent(GESTURE_END);

		int n;
		n = clutter_gesture_action_get_n_current_points(action);
		gestureEvent.SetCurrentPoints(n);
		n = clutter_gesture_action_get_n_touch_points(action);
		gestureEvent.SetTouchPoints(n);
		//clutter_gesture_action_get_threshold_trigger_distance(action, &x, &y);
		//gestureEvent.SetThresholdTriggerDistance(x, y);

		CActor *cActor = D_GET_HALO_ACTOR(G_OBJECT(actor));
		if (NULL != cActor)
		{
			gestureEvent.SetReceiver(cActor);
			cActor->OnEvent(&gestureEvent);
		}
	}

	gboolean CGestureAction::s_onGestureProgressCb(ClutterGestureAction *action, ClutterActor *actor, gpointer user_data)
	{
		H_LOG_TRACE(LOGGER, "CGestureAction::s_onGestureProgressCb(" << action << ", " << actor << ", " << user_data << ")");
		CGestureEvent gestureEvent(GESTURE_PROGRESS);

		int n;
		n = clutter_gesture_action_get_n_current_points(action);
		gestureEvent.SetCurrentPoints(n);
		n = clutter_gesture_action_get_n_touch_points(action);
		gestureEvent.SetTouchPoints(n);
		//clutter_gesture_action_get_threshold_trigger_distance(action, &x, &y);
		//gestureEvent.SetThresholdTriggerDistance(x, y);

		CActor *cActor = D_GET_HALO_ACTOR(G_OBJECT(actor));
		if (NULL != cActor)
		{
			gestureEvent.SetReceiver(cActor);
			cActor->OnEvent(&gestureEvent);
		}

		return true;
	}
	//! CGestureRecognizer end
	
	CKeyLongPressAction::CKeyLongPressAction(): m_bLongPressSend(false), m_keyCounter(0), m_timer(0), m_clutterEvent(NULL)
	{
	}

	//! KeyLongPressRecognizer
	bool CKeyLongPressAction::Initialize(IActor* params)/*:CAction(owner)*/
	{
		H_LOG_TRACE(LOGGER, "CKeyLongPressAction::Initialize ");
		CAction::Initialize(params);
		//m_bLongPressSend = false;
		//m_keyCounter = 0;
		//m_timer = 0;
		//m_clutterEvent = NULL;
		m_clutterEvent = new ClutterEvent;

		
		m_eventId = g_signal_connect(t_pOwner->Actor(), "event", G_CALLBACK(s_onKeyLongPressCb), this);
		m_focusOutId = g_signal_connect(t_pOwner->Actor(), "key-focus-out", G_CALLBACK(m_KeyFocusOutCb), this);
		m_focusInId = g_signal_connect(t_pOwner->Actor(), "key-focus-in", G_CALLBACK(m_KeyFocusInCb), this);

		return true;
	}

	CKeyLongPressAction::~CKeyLongPressAction()
	{
		if (t_pOwner != NULL && t_pOwner->Actor() != NULL)
		{
			g_signal_handler_disconnect(t_pOwner->Actor(), m_eventId);
			g_signal_handler_disconnect(t_pOwner->Actor(), m_focusInId);
			g_signal_handler_disconnect(t_pOwner->Actor(), m_focusOutId);
		}

		if (m_clutterEvent != NULL)
		{
			delete m_clutterEvent;
			m_clutterEvent = NULL;
		}

		if (m_timer > 0)
		{
			g_source_remove(m_timer);
			m_timer = 0;
		}

		if (m_longPressKeyList.empty() == false)
		{
			m_longPressKeyList.erase(m_longPressKeyList.begin() , m_longPressKeyList.end());
		}
	}

	bool CKeyLongPressAction::IsInterestEvent(IEvent* event) 
	{
		return false;
	}
	bool CKeyLongPressAction::Process(IEvent* inEvent, IEvent** outEvent) 
	{
		return false;
	}

	bool CKeyLongPressAction::AddLongPressKey(unsigned int key_val)
	{
		H_LOG_TRACE(LOGGER, "CKeyLongPressAction::AddLongPressKey(" << key_val << ")");
		
		/*LongPressEventList::iterator iter = m_longPressKeyList.begin();

		while (iter != m_longPressKeyList.end())
		{
			if (*iter ==  key_val)
			{
				return false;
			}
			iter++;
		}

		m_longPressKeyList.insert(key_val);*/

		LongPressEventList::iterator iter = m_longPressKeyList.find(key_val);
		if (iter == m_longPressKeyList.end())
		{
			m_longPressKeyList.insert(key_val);
			return true;
		}
		
		return false;
	}

	bool CKeyLongPressAction::RemoveLongPressKey(unsigned int key_val)
	{
		H_LOG_TRACE(LOGGER, "CKeyLongPressAction::RemoveLongPressKey(" << key_val << ")");
		
		/*LongPressEventList::iterator iter = m_longPressKeyList.begin();

		while (iter != m_longPressKeyList.end())
		{
			if (*iter ==  key_val)
			{
				m_longPressKeyList.erase(iter);
				return true;
			}
			iter++;
		}	*/	
		
		LongPressEventList::iterator iter = m_longPressKeyList.find(key_val);
		if (iter != m_longPressKeyList.end())
		{
			m_longPressKeyList.erase(iter);
			return true;
		}

		return false;
	}

	gboolean CKeyLongPressAction::s_onKeyLongPressCb(ClutterActor* actor, ClutterEvent* event, gpointer user_data)
	{
		H_LOG_TRACE(LOGGER, "CKeyLongPressAction::s_onKeyLongPressCb(" << actor << ", " << event << ", " << user_data << ")");
		CKeyLongPressAction *pThis = (CKeyLongPressAction *)user_data;		

		//! Key long press scenario. 
		if (true == pThis->m_IsLongPressKey(event))
		{			
			//pThis->m_clutterEvent = event;			

			H_LOG_TRACE(LOGGER, "CKeyLongPressAction::s_onKeyLongPressCb  event->key.type = " << event->key.type);
			
			switch(event->key.type)
			{
			case CLUTTER_KEY_PRESS:
				{
					if (pThis->m_bLongPressSend == false && pThis->m_timer == 0)
					{
						int interval = g_pEventManager->KeyLongPressInterval();
						memcpy(pThis->m_clutterEvent, event, sizeof(ClutterEvent));
						pThis->m_timer = g_timeout_add(interval, (GSourceFunc)pThis->m_onKeyLongPressTimerCb, user_data); 
						pThis->m_bLongPressSend = true;
					}
				}
				break;
			case CLUTTER_KEY_RELEASE:
				{	
					pThis->m_bLongPressSend = false;
					if (pThis->m_timer > 0)
					{
						g_source_remove(pThis->m_timer);
						pThis->m_timer = 0;						
					}
				}
				break;
			default:
				break;
			}		
		}

		return CLUTTER_EVENT_PROPAGATE;
	}	

	gboolean CKeyLongPressAction::m_onKeyLongPressTimerCb(void *data)
	{		
		H_LOG_TRACE(LOGGER, "CKeyLongPressAction::m_onKeyLongPressCb");
		CKeyLongPressAction *pThis = (CKeyLongPressAction *)data;
		//g_message("action = %x \n", pThis->t_pOwner->Actor());		

		if (pThis->t_pOwner->IsFocused() == true)
		{
			CKeyboardEvent keyEvent(pThis->m_clutterEvent);
			keyEvent.SetEventType("samsung.tv.halo.input.keylongpress");
			CActor *cActor = D_GET_HALO_ACTOR(G_OBJECT(pThis->t_pOwner->Actor()));
			if (NULL != cActor)
			{
				cActor->OnEvent(&keyEvent);
			}
		}		

		pThis->m_timer = 0;
		
		return false;
	}
	
	gboolean CKeyLongPressAction::m_KeyFocusOutCb(ClutterActor* actor, CKeyLongPressAction *user_data)
	{
		H_LOG_TRACE(LOGGER, "CKeyLongPressAction::m_KeyFocusOutCb");
		CKeyLongPressAction *pThis = (CKeyLongPressAction *)user_data;
		pThis->m_bLongPressSend = false;

		if (pThis->m_timer > 0)
		{
			//g_message("m_KeyFocusOutCb action = %x \n", pThis->t_pOwner->Actor());
			g_source_remove(pThis->m_timer);
			pThis->m_timer = 0;			
		}

		return CLUTTER_EVENT_PROPAGATE;
	}

	gboolean CKeyLongPressAction::m_KeyFocusInCb(ClutterActor* actor, CKeyLongPressAction *user_data)
	{
		H_LOG_TRACE(LOGGER, "CKeyLongPressAction::m_KeyFocusInCb");
		CKeyLongPressAction *pThis = (CKeyLongPressAction *)user_data;
		pThis->m_bLongPressSend = false;

		if (pThis->m_timer > 0)
		{
			//g_message("m_KeyFocusInCb action = %x \n", pThis->t_pOwner->Actor());
			g_source_remove(pThis->m_timer);
			pThis->m_timer = 0;			
		}

		return CLUTTER_EVENT_PROPAGATE;
	}
	

	bool CKeyLongPressAction::m_IsLongPressKey(ClutterEvent* pEvent)
	{
		int keyval = pEvent->key.keyval;
		H_LOG_TRACE(LOGGER, "CKeyLongPressAction::m_IsLongPressKey type = " << keyval);

		LongPressEventList::iterator iter = m_longPressKeyList.begin();

		while (iter != m_longPressKeyList.end())
		{
			if (*iter ==  keyval)
			{
				return true;
			}
			iter++;
		}

		return false;	
	} //! KeyLongPressRecognizer end

	CKeyCombinationAction::CKeyCombinationAction()
	{
		m_timer = -1;
		m_keyCounter = 0;
	}
	
	CKeyCombinationAction::~CKeyCombinationAction()
	{
		if (m_keyList.empty() == false)
		{
			m_keyList.erase(m_keyList.begin() , m_keyList.end());
		}
	}

	bool CKeyCombinationAction::Initialize(IActor* params) 
	{
		H_LOG_TRACE(LOGGER, "CKeyCombinationAction::Initialize ");
		CAction::Initialize(params);

		g_signal_connect (t_pOwner->Actor(), "key-press-event", G_CALLBACK (s_onKeyCombinationCb), this);
		g_signal_connect (t_pOwner->Actor(), "key-release-event", G_CALLBACK(s_onKeyCombinationCb), this);		

		return true;
	}

	bool CKeyCombinationAction::IsInterestEvent(IEvent* event) 
	{
		return false;
	}
	bool CKeyCombinationAction::Process(IEvent* inEvent, IEvent** outEvent) 
	{
		return false;
	}

	bool CKeyCombinationAction::AddKey(unsigned int key_val)
	{
		ASSERT(NULL != key_val);
		
		m_keyList.push_back(key_val);
		
		return true;
	}

	gboolean CKeyCombinationAction::s_onKeyCombinationCb(ClutterActor* actor, ClutterEvent* event, gpointer user_data)
	{
		H_LOG_TRACE(LOGGER, "CKeyCombinationAction::s_onKeyCombinationCb(" << actor << ", " << event << ", " << user_data << ")");
		CKeyCombinationAction* pThis = (CKeyCombinationAction*)user_data;

		for (std::vector<IAction*>::iterator iter = pThis->t_pOwner->GetActionList()->begin(); iter !=pThis->t_pOwner->GetActionList()->end(); iter++)
		{
			CKeyCombinationAction* pKeyComAction = dynamic_cast<CKeyCombinationAction*>(*iter);

			if (pKeyComAction)
			{
				if (pKeyComAction->m_isCombinationKey(event))
				{
					switch(event->key.type)
					{
						case CLUTTER_KEY_PRESS:
							if (pKeyComAction->m_timer > 0)
							{
								g_source_remove(pKeyComAction->m_timer);
							}
							break;
						case CLUTTER_KEY_RELEASE:
							{		
								if (pKeyComAction->m_keyCounter == pKeyComAction->m_keyList.size() - 1)
								{
									pKeyComAction->m_sendEvent(event);

									pKeyComAction->m_keyCounter = 0;
								}
								else
								{
									pKeyComAction->m_keyCounter++;
									pKeyComAction->m_timer = g_timeout_add(2000, (GSourceFunc)pKeyComAction->m_onTimerCb, pKeyComAction);
								}
						   }
							break;
						default:
							break;
					}
				}
			}
		}

		return true;
	}

	gboolean CKeyCombinationAction::m_onTimerCb(void *data)
	{
		H_LOG_TRACE(LOGGER, "CKeyCombinationAction::m_onTimerCb ");
		CKeyCombinationAction* pThis = (CKeyCombinationAction*)data;
		
		pThis->m_keyCounter = 0;

		pThis->m_timer = -1;

		return false;
	}

	bool CKeyCombinationAction::m_isCombinationKey(ClutterEvent* pEvent)
	{
		H_LOG_TRACE(LOGGER, "CKeyCombinationAction::m_isCombinationKey ");
		int type = pEvent->type;

		if (type == CLUTTER_KEY_PRESS || type == CLUTTER_KEY_RELEASE)
		{
			if (pEvent->key.keyval == this->m_keyList[this->m_keyCounter])
			{
				return true;
			}
			else
			{
				return false;	
			}
		}

		return false;	
	}

	void CKeyCombinationAction::m_sendEvent(ClutterEvent* pEvent)
	{
		H_LOG_TRACE(LOGGER, "CKeyCombinationAction::m_sendEvent ");
		CKeyboardEvent keyEvent(pEvent);
		keyEvent.SetEventType("samsung.tv.halo.input.keycombination");
		keyEvent.SetKeyComActionData((IKeyCombinationAction*)this);
		CActor *cActor = D_GET_HALO_ACTOR(G_OBJECT(this->t_pOwner->Actor()));
		if (NULL != cActor)
		{
			keyEvent.SetReceiver(cActor);
			cActor->OnEvent(&keyEvent);
		}
	}
}//! HALO end
