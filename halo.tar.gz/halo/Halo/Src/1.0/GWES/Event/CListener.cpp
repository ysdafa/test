#include "Halo1_0.h"

static HALO::util::Logger LOGGER("Listener");

namespace HALO
{
	ListenerSet::ListenerSet() {}
	ListenerSet::~ListenerSet()
	{
		//ASSERT( m_list.empty() );
		m_list.clear();
	}

	bool ListenerSet::Add(IListenerPtr ptr)
	{
		ASSERT(ptr != NULL);
		std::pair<ListenerList::iterator, bool> ret = m_list.insert(ptr);
		if(ret.second != true)
		{
			H_LOG_WARN(LOGGER, "Add existing listener");
		}

		return true;
	}

	bool ListenerSet::Remove(IListenerPtr listener)
	{
		ASSERT(listener != NULL);
		unsigned int num = (unsigned int)m_list.erase(listener);

		if(num !=1)
		{
			H_LOG_WARN(LOGGER, "Remove nonexistent listener");
		}

		return true;
	}

	bool ListenerSet::Empty(void)
	{
		return m_list.empty();
	}

	CFocusListenerSet::CFocusListenerSet(): m_pOwner(NULL)
	{
	}
	CFocusListenerSet::CFocusListenerSet(IActor* owner): m_pOwner(owner)
	{
	}
	CFocusListenerSet::~CFocusListenerSet()
	{
	}
	bool CFocusListenerSet::Process(IEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CFocusListenerSet::Process ");
		bool ret = false;
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				IFocusListener* pListener = (IFocusListener*)(*listenerIter);
				CFocusEvent* pFocusEvent = dynamic_cast<CFocusEvent*>(event);
				
				if (pFocusEvent == NULL)
				{
					return false;
				}

				H_LOG_TRACE(LOGGER, "CFocusListenerSet::Process FocusEventType = " << pFocusEvent->FocusEventType());
				switch (pFocusEvent->FocusEventType())
				{
				case EVENT_FOCUSIN:
					{	
						ret |= pListener->OnFocusIn(m_pOwner);	
					}
					break;
				case EVENT_FOCUSOUT:
					{
						ret |= pListener->OnFocusOut(m_pOwner);
					}
					break;
				default:
					break;
				}
				++listenerIter;
			}

		}
		return ret;
	}

	CKeyboardListenerSet::CKeyboardListenerSet(IActor* owner):m_pOwner(owner)
	{
	}
	CKeyboardListenerSet::~CKeyboardListenerSet()
	{
	}
	bool CKeyboardListenerSet::Process(IEvent* event, EEventRoutineType eventType)
	{
		H_LOG_TRACE(LOGGER, "CKeyboardListenerSet::Process(" << event << ", " << eventType << ")");
		bool ret = false;
		if (event)
		{
			switch (eventType)
			{
			case E_HALO_EVENT_ROUTINE_CAPTURED:                 //! captured event
				{
					ListenerList::iterator listenerIter = m_list.begin();
					while (listenerIter != m_list.end())
					{
						IKeyboardListener* pListener = (IKeyboardListener*)(*listenerIter);
						CKeyboardEvent* pKeyEvent = dynamic_cast<CKeyboardEvent*>(event);
						if (pKeyEvent == NULL)
						{
							return false;
						}
						CKeyboardEvent keyboardEvent = *pKeyEvent;
	
						if (event->IsEventType("samsung.tv.halo.input.keypress"))
						{
							ret |= pListener->OnCapturedKeyPressed(m_pOwner, &keyboardEvent);
						}
						else if (event->IsEventType("samsung.tv.halo.input.keyrelease"))
						{
							ret |= pListener->OnCapturedKeyReleased(m_pOwner, &keyboardEvent);
						}
						++listenerIter;
					}
				}
				break;
			case E_HALO_EVENT_ROUTINE_BUBBLE:
				{
					ListenerList::iterator listenerIter = m_list.begin();
					while (listenerIter != m_list.end())
					{
						IKeyboardListener* pListener = (IKeyboardListener*)(*listenerIter);
						CKeyboardEvent* pKeyEvent = dynamic_cast<CKeyboardEvent*>(event);
						if (pKeyEvent == NULL)
						{
							return false;
						}
						CKeyboardEvent keyboardEvent = *pKeyEvent;

						if (event->IsEventType("samsung.tv.halo.input.keypress"))
						{
							ret |= pListener->OnKeyPressed(m_pOwner, &keyboardEvent);
						}
						else if (event->IsEventType("samsung.tv.halo.input.keyrelease"))
						{
							ret |= pListener->OnKeyReleased(m_pOwner, &keyboardEvent);
						}
						++listenerIter;
					}
				}
				break;
			default:
				break;
			}//end switch
		}//end if
		return ret;
	}
	bool CKeyboardListenerSet::Process(ClutterEvent* event, EEventRoutineType eventType)
	{
		CKeyboardEvent keyboardEvent(event);
		return Process(&keyboardEvent, eventType);
	}

	CClickListenerSet::CClickListenerSet(): m_pOwner(NULL)
	{
	}
	CClickListenerSet::CClickListenerSet(IActor* owner): m_pOwner(owner)
	{
	}
	CClickListenerSet::~CClickListenerSet()
	{
	}
	bool CClickListenerSet::Process(IEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CClickListenerSet::Process ");
		bool ret = false;
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				IClickListener* pListener = (IClickListener*)(*listenerIter);

				if (event->IsEventType("samsung.tv.halo.input.mouseclicked"))
				{
					H_LOG_TRACE(LOGGER, "CClickListenerSet::Process mouseclicked event");
					CClickEvent* pClickEvent = dynamic_cast<CClickEvent*>(event);
					if (pClickEvent == NULL)
					{
						return false;
					}
					CClickEvent clickEvent = *pClickEvent;
					ret |= pListener->OnClicked(m_pOwner, &clickEvent);
				}
				else if (event->IsEventType("samsung.tv.halo.input.mouselongpress"))
				{
					H_LOG_TRACE(LOGGER, "CClickListenerSet::Process mouselongpress event");
					CLongPressEvent* pLongPressEvent = dynamic_cast<CLongPressEvent*>(event);
					if (pLongPressEvent == NULL)
					{
						return false;
					}
					CLongPressEvent longPressEvent = *pLongPressEvent;
					ret |= pListener->OnLongPress(m_pOwner, &longPressEvent);
				}
				++listenerIter;
			}

		}
		return ret;
	}
	
	// !mouse listenerset impl
	CMouseListenerSet::CMouseListenerSet(IActor* owner):m_pOwner(owner)
	{
	}

	CMouseListenerSet::~CMouseListenerSet()
	{
	}

	bool CMouseListenerSet::Process(IEvent* event, EEventRoutineType eventType)
	{
		H_LOG_TRACE(LOGGER, "CKeyboardListenerSet::Process(" << event << ", " << eventType << ")");
		bool ret = false;
		ListenerList::iterator listenerIter = m_list.begin();

		if (event)
		{
			switch (eventType)
			{
			case E_HALO_EVENT_ROUTINE_CAPTURED:                 //! captured event
				{
					while (listenerIter != m_list.end())
					{
						IMouseListener* pListener = (IMouseListener*)(*listenerIter);
						CMouseEvent* pMouseEvent = dynamic_cast<CMouseEvent*>(event);
						if (pMouseEvent)
						{
							CMouseEvent mouseEvent = *pMouseEvent;

							if (event->IsEventType("samsung.tv.halo.input.mousepress"))
							{
								ret |= pListener->OnCapturedMouseButtonPressed(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mouserelease"))
							{
								ret |= pListener->OnCapturedMouseButtonReleased(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mousescroll"))
							{
								ret |= pListener->OnCapturedMouseWheel(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mouseenter"))
							{
								ret |= pListener->OnCapturedMousePointerIn(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mouseleave"))
							{
								ret |= pListener->OnCapturedMousePointerOut(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mousemotion"))
							{
								ret |= pListener->OnCapturedMouseMoved(m_pOwner, &mouseEvent);
							}
						}
						++listenerIter;
					}//end while
				}
				break;
			case E_HALO_EVENT_ROUTINE_BUBBLE:                     //! bubble event
				{
					while (listenerIter != m_list.end())
					{
						IMouseListener* pListener = (IMouseListener*)(*listenerIter);
						CMouseEvent* pMouseEvent = dynamic_cast<CMouseEvent*>(event);
						if (pMouseEvent)
						{
							CMouseEvent mouseEvent = *pMouseEvent;												

							if (event->IsEventType("samsung.tv.halo.input.mousepress"))
							{
								ret |= pListener->OnMouseButtonPressed(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mouserelease"))
							{
								ret |= pListener->OnMouseButtonReleased(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mousescroll"))
							{
								ret |= pListener->OnMouseWheel(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mouseenter"))
							{
								ret |= pListener->OnMousePointerIn(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mouseleave"))
							{
								ret |= pListener->OnMousePointerOut(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mousemotion"))
							{
								ret |= pListener->OnMouseMoved(m_pOwner, &mouseEvent);
							}
						}
						++listenerIter;
					}//end while
				}
				break;
			default:
				break;
			}	

		}

		return ret;
	}

	bool CMouseListenerSet::Process(ClutterEvent* event, EEventRoutineType eventType)
	{
		CMouseEvent mouseEvent(event);
		return Process(&mouseEvent, eventType);
	}

	CSemanticEventListenerSet::CSemanticEventListenerSet()
	{
	}
	CSemanticEventListenerSet::CSemanticEventListenerSet(IActor* owner):m_pOwner(owner)
	{
	}
	CSemanticEventListenerSet::~CSemanticEventListenerSet()
	{
	}
	bool CSemanticEventListenerSet::Process(IEvent* event)
	{
		bool ret = false;
		//if (event)
		//{
		//	ListenerList::iterator listenerIter = m_list.begin();
		//	while (listenerIter != m_list.end())
		//	{
		//		ISemanticEventListener* pListener = (ISemanticEventListener*)(*listenerIter);

		//		switch( event->EventType() )
		//		{
		//		case E_HALO_EVENT_CLICKED:
		//		}
		//	}
		//}
		return ret;
	}

	CSystemEventListenerSet::CSystemEventListenerSet()
	{
	}
	CSystemEventListenerSet::~CSystemEventListenerSet()
	{
	}
	bool CSystemEventListenerSet::Process(IEvent* event)
	{
		bool ret = false;
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				ISystemEventListener* pListener = (ISystemEventListener*)(*listenerIter);

				if (event->IsEventType("samsung.tv.halo.system.quit"))
				{
					ret |= pListener->OnSystemQuit(event);
				}
				else if (event->IsEventType("samsung.tv.halo.system.cursorvisible"))
				{
					ret |= pListener->OnCursorVisible(event);
				}
				else if (event->IsEventType("samsung.tv.halo.system.cursorhidden"))
				{
					ret |= pListener->OnCursorHidden(event);
				}
				listenerIter++;
			}
		}
		return ret;
	}

	CAsyncTaskListenerSet::CAsyncTaskListenerSet()
	{
	}
	CAsyncTaskListenerSet::~CAsyncTaskListenerSet()
	{
	}
	bool CAsyncTaskListenerSet::Process(IEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CAsyncTaskListenerSet::Process ");
		bool ret = false;
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				ITaskListener* pListener = (ITaskListener*)(*listenerIter);
				ret |= pListener->Process(event);
				listenerIter++;
			}
		}
		return ret;
	}

	CCustomEventListenerSet::CCustomEventListenerSet()
	{
	}
	CCustomEventListenerSet::~CCustomEventListenerSet()
	{
	}
	bool CCustomEventListenerSet::Process(IEvent* event, IEvent* reply, bool bReply)
	{
		H_LOG_TRACE(LOGGER, "CCustomEventListenerSet::Process ");
		bool ret = false;
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				ICustomEventListener* pListener = (ICustomEventListener*)(*listenerIter);
				if (true == bReply)
				{
					ret |= pListener->OnCustomEventSync(event, reply);
				}
				else
				{
					ret |= pListener->OnCustomEvent(event);
				}				
				listenerIter++;
			}
		}
		return ret;
	}
	
	//! Drag listener set
	CDragListenerSet::CDragListenerSet(): m_pOwner(NULL)
	{
	}
	CDragListenerSet::CDragListenerSet(IActor* owner): m_pOwner(owner)
	{
	}
	CDragListenerSet::~CDragListenerSet()
	{
	}
	bool CDragListenerSet::Process(IEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CDragListenerSet::Process ");
		bool ret = false;
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				IDragListener* pListener = (IDragListener*)(*listenerIter);
				CDragEvent* pDragEvent = dynamic_cast<CDragEvent*>(event);

				if (pDragEvent)
				{
					switch(pDragEvent->DragSignalType())
					{
					H_LOG_TRACE(LOGGER, "CDragListenerSet::Process DragSignalType = " << pDragEvent->DragSignalType());
					case DRAG_BEGIN:
						{
							ret |= pListener->OnDragBegin(m_pOwner, pDragEvent);
						}
						break;
					case DRAG_END:
						{
							ret |= pListener->OnDragEnd(m_pOwner, pDragEvent);
						}
						break;
					case DRAG_MOTION:
						{
							ret |= pListener->OnDragMotion(m_pOwner, pDragEvent);
						}
						break;
					case DRAG_HOLD:
						{
							ret |= pListener->OnDragHold(m_pOwner, pDragEvent);
						}
						break;
					default:
						break;
						}
				}
				++listenerIter;
			}
		}

		return ret;
	}

	//! Gesture listener set
	CGestureListenerSet::CGestureListenerSet(): m_pOwner(NULL)
	{
	}
	CGestureListenerSet::CGestureListenerSet(IActor* owner): m_pOwner(owner)
	{
	}
	CGestureListenerSet::~CGestureListenerSet()
	{
	}
	bool CGestureListenerSet::Process(IEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CGestureListenerSet::Process ");
		bool ret = false;
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				IGestureListener* pListener = (IGestureListener*)(*listenerIter);
				CGestureEvent* pGestureEvent = dynamic_cast<CGestureEvent*>(event);

				if (pGestureEvent)
				{
					switch(pGestureEvent->GestureSignalType())
					{
					H_LOG_TRACE(LOGGER, "CGestureListenerSet::Process GestureSignalType = " << pGestureEvent->GestureSignalType());
					case GESTURE_BEGIN:
						{
							ret |= pListener->OnGestureBegin(m_pOwner, pGestureEvent);
						}
						break;
					case GESTURE_END:
						{
							ret |= pListener->OnGestureEnd(m_pOwner, pGestureEvent);
						}
						break;
					case GESTURE_CANCEL:
						{
							ret |= pListener->OnGestureCancel(m_pOwner, pGestureEvent);
						}
						break;
					case GESTURE_PROGRESS:
						{
							ret |= pListener->OnGestureProgress(m_pOwner, pGestureEvent);
						}
						break;
					default:
						break;
						}
				}
				++listenerIter;
			}
		}

		return ret;
	}
	
	//! !Key long press listener set
	CKeyLongPressListenerSet::CKeyLongPressListenerSet(): m_pOwner(NULL)
	{
	}
	CKeyLongPressListenerSet::CKeyLongPressListenerSet(IActor* owner): m_pOwner(owner)
	{
	}
	CKeyLongPressListenerSet::~CKeyLongPressListenerSet()
	{
	}
	bool CKeyLongPressListenerSet::Process(IEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CKeyLongPressListenerSet::Process ");
		bool ret = false;
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				IKeyLongPressListener* pListener = (IKeyLongPressListener*)(*listenerIter);
				CKeyboardEvent* pKeyEvent = dynamic_cast<CKeyboardEvent*>(event);
				if (pKeyEvent == NULL)
				{
					return false;
				}

				CKeyboardEvent keyboardEvent = *pKeyEvent;
	
				ret |= pListener->OnKeyLongPress(m_pOwner, &keyboardEvent);
	
				++listenerIter;
			}
		}

		return ret;
	}

	//! keycombination listener set
	CKeyCombinationListenerSet::CKeyCombinationListenerSet(): m_pOwner(NULL)
	{
	}
	CKeyCombinationListenerSet::CKeyCombinationListenerSet(IActor* owner): m_pOwner(owner)
	{
	}
	CKeyCombinationListenerSet::~CKeyCombinationListenerSet()
	{
	}
	bool CKeyCombinationListenerSet::Process(IEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CKeyCombinationListenerSet::Process ");
		bool ret = false;
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				IKeyCombinationListener* pListener = (IKeyCombinationListener*)(*listenerIter);
				
				CKeyboardEvent* pKeyEvent = dynamic_cast<CKeyboardEvent*>(event);
				
				if (pKeyEvent == NULL)
				{
					return false;
				}
				CKeyboardEvent keyboardEvent = *pKeyEvent;
				void* pData = pKeyEvent->GetKeyComActionData();

				ret |= pListener->OnKeyCombination(m_pOwner, &keyboardEvent, pData);
	
				++listenerIter;
			}

		}
		return ret;
	}
	
}// end of HALO
