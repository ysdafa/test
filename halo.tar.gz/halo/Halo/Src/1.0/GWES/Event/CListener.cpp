#include "Halo1_0.h"

static HALO::util::Logger LOGGER("Listener");

namespace HALO
{
	IListenerData::IListenerData()
	{

	}

	IListenerData::~IListenerData()
	{

	}

	ListenerSet::ListenerSet():m_isProcessing(0) {}
	ListenerSet::~ListenerSet()
	{
		//HALO_ASSERT( m_list.empty() );
		if (m_isProcessing != 0)
		{
			H_LOG_FATAL(LOGGER, "Attempt to destroy itself in its listener.");
		}
		m_list.clear();
	}

	bool ListenerSet::Add(IListenerPtr ptr)
	{
		HALO_ASSERT(ptr != NULL);
		std::pair<ListenerList::iterator, bool> ret = m_list.insert(ptr);
		if(ret.second != true)
		{
			H_LOG_WARN(LOGGER, "Add existing listener");
		}

		return true;
	}

	bool ListenerSet::Remove(IListenerPtr listener)
	{
		HALO_ASSERT(listener != NULL);
		unsigned int num = (unsigned int)m_list.erase(listener);

		if(num !=1)
		{
			H_LOG_WARN(LOGGER, "Remove nonexistent listener");
		}

		return true;
	}

	bool ListenerSet::Empty(void)
	{
		return m_list.empty();
	}

	void ListenerSet::Clear(void)
	{
		return m_list.clear();
	}

	void ListenerSet::Lock()
	{
		m_isProcessing++;
	}

	void ListenerSet::Unlock()
	{
		if (m_isProcessing <= 0)
		{
			H_LOG_FATAL(LOGGER, "ListenerSet is not processing.");
		}
		m_isProcessing--;
	}

	bool ListenerSet::IsLocked()
	{
		return m_isProcessing > 0;
	}

	bool ListenerSet::Process(IListenerData* data)
	{
		bool ret = false;
		Lock();
		ret = t_Process(data);
		Unlock();
		return ret;
	}

	bool ListenerSet::t_Process(IListenerData* data)
	{
		return true;
	}

	CFocusListenerSet::CFocusListenerSet(): m_pOwner(NULL)
	{
	}
	CFocusListenerSet::CFocusListenerSet(CWidgetExtension* owner): m_pOwner(owner)
	{
	}
	CFocusListenerSet::~CFocusListenerSet()
	{
	}
	bool CFocusListenerSet::Process(IEvent* event)
	{
		bool ret = false;
		Lock();
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				IFocusListener* pListener = (IFocusListener*)(*listenerIter);
				CFocusEvent* pFocusEvent = dynamic_cast<CFocusEvent*>(event);
				
				if (pFocusEvent == NULL)
				{
					Unlock();
					return false;
				}

				H_LOG_TRACE(LOGGER, "CFocusListenerSet::Process FocusEventType = " << pFocusEvent->FocusEventType());
				switch (pFocusEvent->FocusEventType())
				{
				case EVENT_FOCUSIN:
					{	
						ret |= pListener->OnFocusIn(m_pOwner);	
					}
					break;
				case EVENT_FOCUSOUT:
					{
						ret |= pListener->OnFocusOut(m_pOwner);
					}
					break;
				default:
					break;
				}
				if (m_list.empty())
				{
					break;
				}
				++listenerIter;
			}

		}
		Unlock();
		return ret;
	}

	CKeyboardListenerSet::CKeyboardListenerSet(CWidgetExtension* owner):m_pOwner(owner)
	{
		H_LOG_FATAL(LOGGER, "New CKeyboardListenerSet :" << this);
	}
	CKeyboardListenerSet::~CKeyboardListenerSet()
	{
		H_LOG_FATAL(LOGGER, "Delete CKeyboardListenerSet :" << this);
	}
	bool CKeyboardListenerSet::Process(IEvent* event, EEventRoutineType eventType)
	{
		H_LOG_TRACE(LOGGER, "CKeyboardListenerSet processing begin :" << this);
		bool ret = false;
		Lock();
		if (event)
		{
			switch (eventType)
			{
			case E_HALO_EVENT_ROUTINE_CAPTURED:                 //! captured event
				{
					ListenerList::iterator listenerIter = m_list.begin();
					while (listenerIter != m_list.end())
					{
						IKeyboardListener* pListener = (IKeyboardListener*)(*listenerIter);
						CKeyboardEvent* pKeyEvent = dynamic_cast<CKeyboardEvent*>(event);
						if (pKeyEvent == NULL)
						{
							Unlock();
							H_LOG_TRACE(LOGGER, "CKeyboardListenerSet processing end :" << this);
							return false;
						}
						CKeyboardEvent keyboardEvent = *pKeyEvent;
	
						if (event->IsEventType("samsung.tv.halo.input.keypress"))
						{
							ret |= pListener->OnCapturedKeyPressed(m_pOwner, &keyboardEvent);
						}
						else if (event->IsEventType("samsung.tv.halo.input.keyrelease"))
						{
							ret |= pListener->OnCapturedKeyReleased(m_pOwner, &keyboardEvent);
						}
						if (m_list.empty())
						{
							break;
						}
						++listenerIter;
					}
				}
				break;
			case E_HALO_EVENT_ROUTINE_BUBBLE:
				{
					ListenerList::iterator listenerIter = m_list.begin();
					while (listenerIter != m_list.end())
					{
						IKeyboardListener* pListener = (IKeyboardListener*)(*listenerIter);
						CKeyboardEvent* pKeyEvent = dynamic_cast<CKeyboardEvent*>(event);
						if (pKeyEvent == NULL)
						{
							Unlock();
							H_LOG_TRACE(LOGGER, "CKeyboardListenerSet processing end :" << this);
							return false;
						}
						CKeyboardEvent keyboardEvent = *pKeyEvent;

						if (event->IsEventType("samsung.tv.halo.input.keypress"))
						{
							ret |= pListener->OnKeyPressed(m_pOwner, &keyboardEvent);
						}
						else if (event->IsEventType("samsung.tv.halo.input.keyrelease"))
						{
							ret |= pListener->OnKeyReleased(m_pOwner, &keyboardEvent);
						}
						if (m_list.empty())
						{
							break;
						}
						++listenerIter;
					}
				}
				break;
			default:
				break;
			}//end switch
		}//end if
		Unlock();
		H_LOG_TRACE(LOGGER, "CKeyboardListenerSet processing end :" << this);
		return ret;
	}
	bool CKeyboardListenerSet::Process(ClutterEvent* event, EEventRoutineType eventType)
	{
		CKeyboardEvent keyboardEvent(event);
		return Process(&keyboardEvent, eventType);
	}

	CClickListenerSet::CClickListenerSet(): m_pOwner(NULL)
	{
	}
	CClickListenerSet::CClickListenerSet(CWidgetExtension* owner): m_pOwner(owner)
	{
	}
	CClickListenerSet::~CClickListenerSet()
	{
	}
	bool CClickListenerSet::Process(IEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CClickListenerSet::Process ");
		Lock();
		bool ret = false;
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				IClickListener* pListener = (IClickListener*)(*listenerIter);

				if (event->IsEventType("samsung.tv.halo.input.mouseclicked"))
				{
					H_LOG_TRACE(LOGGER, "CClickListenerSet::Process mouseclicked event");
					CClickEvent* pClickEvent = dynamic_cast<CClickEvent*>(event);
					if (pClickEvent == NULL)
					{
						Unlock();
						return false;
					}
					CClickEvent clickEvent = *pClickEvent;
					ret |= pListener->OnClicked(m_pOwner, &clickEvent);
				}
				else if (event->IsEventType("samsung.tv.halo.input.mouselongpress"))
				{
					H_LOG_TRACE(LOGGER, "CClickListenerSet::Process mouselongpress event");
					CLongPressEvent* pLongPressEvent = dynamic_cast<CLongPressEvent*>(event);
					if (pLongPressEvent == NULL)
					{
						Unlock();
						return false;
					}
					CLongPressEvent longPressEvent = *pLongPressEvent;
					ret |= pListener->OnLongPress(m_pOwner, &longPressEvent);
				}
				if (m_list.empty())
				{
					break;
				}
				++listenerIter;
			}

		}
		Unlock();
		return ret;
	}
	
	// !mouse listenerset impl
	CMouseListenerSet::CMouseListenerSet(CWidgetExtension* owner):m_pOwner(owner)
	{
	}

	CMouseListenerSet::~CMouseListenerSet()
	{
	}

	bool CMouseListenerSet::Process(IEvent* event, EEventRoutineType eventType)
	{
		Lock();
		bool ret = false;
		ListenerList::iterator listenerIter = m_list.begin();

		if (event)
		{
			switch (eventType)
			{
			case E_HALO_EVENT_ROUTINE_CAPTURED:                 //! captured event
				{
					while (listenerIter != m_list.end())
					{
						IMouseListener* pListener = (IMouseListener*)(*listenerIter);
						CMouseEvent* pMouseEvent = dynamic_cast<CMouseEvent*>(event);
						if (pMouseEvent)
						{
							CMouseEvent mouseEvent = *pMouseEvent;

							if (event->IsEventType("samsung.tv.halo.input.mousepress"))
							{
								ret |= pListener->OnCapturedMouseButtonPressed(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mouserelease"))
							{
								ret |= pListener->OnCapturedMouseButtonReleased(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mousescroll"))
							{
								ret |= pListener->OnCapturedMouseWheel(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mouseenter"))
							{
								ret |= pListener->OnCapturedMousePointerIn(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mouseleave"))
							{
								ret |= pListener->OnCapturedMousePointerOut(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mousemotion"))
							{
								ret |= pListener->OnCapturedMouseMoved(m_pOwner, &mouseEvent);
							}
						}
						if (m_list.empty())
						{
							break;
						}
						++listenerIter;
					}//end while
				}
				break;
			case E_HALO_EVENT_ROUTINE_BUBBLE:                     //! bubble event
				{
					while (listenerIter != m_list.end())
					{
						IMouseListener* pListener = (IMouseListener*)(*listenerIter);
						CMouseEvent* pMouseEvent = dynamic_cast<CMouseEvent*>(event);
						if (pMouseEvent)
						{
							CMouseEvent mouseEvent = *pMouseEvent;												

							if (event->IsEventType("samsung.tv.halo.input.mousepress"))
							{
								ret |= pListener->OnMouseButtonPressed(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mouserelease"))
							{
								ret |= pListener->OnMouseButtonReleased(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mousescroll"))
							{
								ret |= pListener->OnMouseWheel(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mouseenter"))
							{
								ret |= pListener->OnMousePointerIn(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mouseleave"))
							{
								ret |= pListener->OnMousePointerOut(m_pOwner, &mouseEvent);
							}
							else if (event->IsEventType("samsung.tv.halo.input.mousemotion"))
							{
								ret |= pListener->OnMouseMoved(m_pOwner, &mouseEvent);
							}
						}
						if (m_list.empty())
						{
							break;
						}
						++listenerIter;
					}//end while
				}
				break;
			default:
				break;
			}	

		}
		Unlock();

		return ret;
	}

	bool CMouseListenerSet::Process(ClutterEvent* event, EEventRoutineType eventType)
	{
		CMouseEvent mouseEvent(event);
		return Process(&mouseEvent, eventType);
	}

	CSemanticEventListenerSet::CSemanticEventListenerSet()
	{
	}
	CSemanticEventListenerSet::CSemanticEventListenerSet(CWidgetExtension* owner):m_pOwner(owner)
	{
	}
	CSemanticEventListenerSet::~CSemanticEventListenerSet()
	{
	}
	bool CSemanticEventListenerSet::Process(IEvent* event)
	{
		Lock();
		bool ret = false;
		//if (event)
		//{
		//	ListenerList::iterator listenerIter = m_list.begin();
		//	while (listenerIter != m_list.end())
		//	{
		//		ISemanticEventListener* pListener = (ISemanticEventListener*)(*listenerIter);

		//		switch( event->EventType() )
		//		{
		//		case E_HALO_EVENT_CLICKED:
		//		}
		//	}
		//}
		Unlock();
		return ret;
	}

	CSystemEventListenerSet::CSystemEventListenerSet()
	{
	}
	CSystemEventListenerSet::~CSystemEventListenerSet()
	{
	}
	bool CSystemEventListenerSet::Process(IEvent* event)
	{
		Lock();
		bool ret = false;
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				ISystemEventListener* pListener = (ISystemEventListener*)(*listenerIter);

				if (pListener)
				{
					if (event->IsEventType("samsung.tv.halo.system.quit"))
					{
						ret |= pListener->OnSystemQuit(event);
					}
					else if (event->IsEventType("samsung.tv.halo.system.cursorvisible"))
					{
						ret |= pListener->OnCursorVisible(event);
					}
					else if (event->IsEventType("samsung.tv.halo.system.cursorhidden"))
					{
						ret |= pListener->OnCursorHidden(event);
					}
				}
				listenerIter++;
			}
		}
		Unlock();
		return ret;
	}

	CAsyncTaskListenerSet::CAsyncTaskListenerSet()
	{
	}
	CAsyncTaskListenerSet::~CAsyncTaskListenerSet()
	{
	}
	bool CAsyncTaskListenerSet::Process(IEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CAsyncTaskListenerSet::Process ");
		Lock();
		bool ret = false;
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				ITaskListener* pListener = (ITaskListener*)(*listenerIter);
				if (pListener)
				{
					ret |= pListener->Process(event);
				}
				listenerIter++;
			}
		}
		Unlock();
		return ret;
	}

	CCustomEventListenerSet::CCustomEventListenerSet()
	{
	}
	CCustomEventListenerSet::~CCustomEventListenerSet()
	{
	}
	bool CCustomEventListenerSet::Process(IEvent* event, IEvent* reply, bool bReply)
	{
		H_LOG_TRACE(LOGGER, "CCustomEventListenerSet::Process ");
		Lock();
		bool ret = false;
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				ICustomEventListener* pListener = (ICustomEventListener*)(*listenerIter);
				if (true == bReply)
				{
					ret |= pListener->OnCustomEventSync(event, reply);
				}
				else
				{
					ret |= pListener->OnCustomEvent(event);
				}				
				listenerIter++;
			}
		}
		Unlock();
		return ret;
	}
	
	//! Drag listener set
	CDragListenerSet::CDragListenerSet(): m_pOwner(NULL)
	{
	}
	CDragListenerSet::CDragListenerSet(CWidgetExtension* owner): m_pOwner(owner)
	{
	}
	CDragListenerSet::~CDragListenerSet()
	{
	}
	bool CDragListenerSet::Process(IEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CDragListenerSet::Process ");
		Lock();
		bool ret = false;
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				IDragListener* pListener = (IDragListener*)(*listenerIter);
				CDragEvent* pDragEvent = dynamic_cast<CDragEvent*>(event);

				if (pDragEvent)
				{
					switch(pDragEvent->DragSignalType())
					{
					H_LOG_TRACE(LOGGER, "CDragListenerSet::Process DragSignalType = " << pDragEvent->DragSignalType());
					case DRAG_BEGIN:
						{
							ret |= pListener->OnDragBegin(m_pOwner, pDragEvent);
						}
						break;
					case DRAG_END:
						{
							ret |= pListener->OnDragEnd(m_pOwner, pDragEvent);
						}
						break;
					case DRAG_MOTION:
						{
							ret |= pListener->OnDragMotion(m_pOwner, pDragEvent);
						}
						break;
					case DRAG_HOLD:
						{
							ret |= pListener->OnDragHold(m_pOwner, pDragEvent);
						}
						break;
					default:
						break;
						}
				}
				if (m_list.empty())
				{
					break;
				}
				++listenerIter;
			}
		}

		Unlock();
		return ret;
	}

	//! Gesture listener set
	CGestureListenerSet::CGestureListenerSet(): m_pOwner(NULL)
	{
	}
	CGestureListenerSet::CGestureListenerSet(CWidgetExtension* owner): m_pOwner(owner)
	{
	}
	CGestureListenerSet::~CGestureListenerSet()
	{
	}
	bool CGestureListenerSet::Process(IEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CGestureListenerSet::Process ");
		Lock();
		bool ret = false;
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				IGestureListener* pListener = (IGestureListener*)(*listenerIter);
				CGestureEvent* pGestureEvent = dynamic_cast<CGestureEvent*>(event);

				if (pGestureEvent)
				{
					switch(pGestureEvent->GestureSignalType())
					{
					H_LOG_TRACE(LOGGER, "CGestureListenerSet::Process GestureSignalType = " << pGestureEvent->GestureSignalType());
					case GESTURE_BEGIN:
						{
							ret |= pListener->OnGestureBegin(m_pOwner, pGestureEvent);
						}
						break;
					case GESTURE_END:
						{
							ret |= pListener->OnGestureEnd(m_pOwner, pGestureEvent);
						}
						break;
					case GESTURE_CANCEL:
						{
							ret |= pListener->OnGestureCancel(m_pOwner, pGestureEvent);
						}
						break;
					case GESTURE_PROGRESS:
						{
							ret |= pListener->OnGestureProgress(m_pOwner, pGestureEvent);
						}
						break;
					default:
						break;
						}
				}
				if (m_list.empty())
				{
					break;
				}
				++listenerIter;
			}
		}

		Unlock();
		return ret;
	}
	
	//! !Key long press listener set
	CKeyLongPressListenerSet::CKeyLongPressListenerSet(): m_pOwner(NULL)
	{
	}
	CKeyLongPressListenerSet::CKeyLongPressListenerSet(CWidgetExtension* owner): m_pOwner(owner)
	{
	}
	CKeyLongPressListenerSet::~CKeyLongPressListenerSet()
	{
	}
	bool CKeyLongPressListenerSet::Process(IEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CKeyLongPressListenerSet::Process ");
		Lock();
		bool ret = false;
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				IKeyLongPressListener* pListener = (IKeyLongPressListener*)(*listenerIter);
				CKeyboardEvent* pKeyEvent = dynamic_cast<CKeyboardEvent*>(event);
				if (pKeyEvent == NULL)
				{
					Unlock();
					return false;
				}

				CKeyboardEvent keyboardEvent = *pKeyEvent;
	
				ret |= pListener->OnKeyLongPress(m_pOwner, &keyboardEvent);
	
				if (m_list.empty())
				{
					break;
				}
				++listenerIter;
			}
		}
		Unlock();

		return ret;
	}

	//! keycombination listener set
	CKeyCombinationListenerSet::CKeyCombinationListenerSet(): m_pOwner(NULL)
	{
	}
	CKeyCombinationListenerSet::CKeyCombinationListenerSet(CWidgetExtension* owner): m_pOwner(owner)
	{
	}
	CKeyCombinationListenerSet::~CKeyCombinationListenerSet()
	{
	}
	bool CKeyCombinationListenerSet::Process(IEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CKeyCombinationListenerSet::Process ");
		Lock();
		bool ret = false;
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				IKeyCombinationListener* pListener = (IKeyCombinationListener*)(*listenerIter);
				
				CKeyboardEvent* pKeyEvent = dynamic_cast<CKeyboardEvent*>(event);
				
				if (pKeyEvent == NULL)
				{
					Unlock();
					return false;
				}
				CKeyboardEvent keyboardEvent = *pKeyEvent;
				void* pData = pKeyEvent->GetKeyComActionData();

				ret |= pListener->OnKeyCombination(m_pOwner, &keyboardEvent, pData);
	
				if (m_list.empty())
				{
					break;
				}
				++listenerIter;
			}

		}
		Unlock();
		return ret;
	}

	//!Cursor listener set
	CCursorListenerSet::CCursorListenerSet(): m_pOwner(NULL)
	{
	}
	CCursorListenerSet::CCursorListenerSet(CWidgetExtension* owner): m_pOwner(owner)
	{
	}
	CCursorListenerSet::~CCursorListenerSet()
	{
	}
	bool CCursorListenerSet::Process(IEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CCursorListenerSet::Process ");
		Lock();
		bool ret = false;
		if (event)
		{
			ListenerList::iterator listenerIter = m_list.begin();
			while (listenerIter != m_list.end())
			{
				ICursorListener* pListener = (ICursorListener*)(*listenerIter);				
				CCursorEvent* pCursorEvent = dynamic_cast<CCursorEvent*>(event);
				
				if (pCursorEvent != NULL)
				{					
					CCursorEvent cursorEvent = *pCursorEvent;												

					if (event->IsEventType("samsung.tv.halo.input.cursorshow"))
					{
						H_LOG_TRACE(LOGGER, "CCursorListenerSet::Process:  CURSOR SHOW .......");
						ret |= pListener->OnShown(m_pOwner, &cursorEvent);
					}
					else if (event->IsEventType("samsung.tv.halo.input.cursorhide"))
					{
						H_LOG_TRACE(LOGGER, "CCursorListenerSet::Process:  CURSOR HIDE .......");
						ret |= pListener->OnHidden(m_pOwner, &cursorEvent);
					}		
				}				
	
				if (m_list.empty())
				{
					break;
				}
				++listenerIter;
			}

		}
		Unlock();
		return ret;
	}
	
}// end of HALO
