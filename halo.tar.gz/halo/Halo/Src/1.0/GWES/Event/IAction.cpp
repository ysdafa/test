#include "Halo1_0.h"

namespace HALO
{
	IClickAction* IClickAction::CreateInstance(void)
	{
		CClickAction* action = dynamic_cast<CClickAction*>(Instance::CreateInstance(CLASS_ID_ICLICKACTION));
		return (IClickAction*)action;
	}
	IClickAction* IClickAction::CreateInstance(IActor* params)
	{
		CClickAction* action = dynamic_cast<CClickAction*>(Instance::CreateInstance(CLASS_ID_ICLICKACTION));
		if (action)
		{
			action->Initialize(params);
		}
		return (IClickAction*)action;
	}
	IDragAction* IDragAction::CreateInstance(IActor* params)
	{
		CDragAction* action = dynamic_cast<CDragAction*>(Instance::CreateInstance(CLASS_ID_IDRAGACTION));
		if (action)
		{
			action->Initialize(params);
		}
		return (IDragAction*)action;
	}
	IGestureAction* IGestureAction::CreateInstance(IActor* params)
	{
		CGestureAction* action = dynamic_cast<CGestureAction*>(Instance::CreateInstance(CLASS_ID_IGESTUREACTION));
		if (action)
		{
			action->Initialize(params);
		}
		return (IGestureAction*)action;
	}
	IKeyLongPressAction* IKeyLongPressAction::CreateInstance(IActor* params)
	{
		CKeyLongPressAction* action = dynamic_cast<CKeyLongPressAction*>(Instance::CreateInstance(CLASS_ID_IKEYLONGPRESSACTION));
		if (action)
		{
			action->Initialize(params);
		}
		return (IKeyLongPressAction*)action;
	}
	IKeyCombinationAction* IKeyCombinationAction::CreateInstance(IActor* params)
	{
		CKeyCombinationAction* action = dynamic_cast<CKeyCombinationAction*>(Instance::CreateInstance(CLASS_ID_IKEYCOMBINATIONACTION));
		if (action)
		{
			action->Initialize(params);
		}
		return (IKeyCombinationAction*)action;
	}
}