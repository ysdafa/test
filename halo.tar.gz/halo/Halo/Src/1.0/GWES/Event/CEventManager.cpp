#include "Halo1_0.h"


static HALO::util::Logger LOGGER("EventManager");

namespace HALO
{
	CEventManager::CEventManager()
	{
		m_pInputManager = new CInputManager();
		ASSERT(m_pInputManager);
		m_pListenerSetLock = new CMutex;
		ASSERT(m_pListenerSetLock);
		m_pListenerSetLock->Create();
		m_pSystemEventListenerSet = NULL;
		m_pAsyncTaskListenerSet = NULL;
		m_pCustomEventListenerSet = NULL;
		m_eventTypeMapLock.Create();
		m_eventTypeMapLock.Lock();
		m_eventTypeMap.insert(std::pair<int, std::string>(CLUTTER_KEY_PRESS, "samsung.tv.halo.input.keypress"));
		m_eventTypeMap.insert(std::pair<int, std::string>(CLUTTER_KEY_RELEASE, "samsung.tv.halo.input.keyrelease"));
		m_eventTypeMap.insert(std::pair<int, std::string>(CLUTTER_MOTION, "samsung.tv.halo.input.mousemotion"));
		m_eventTypeMap.insert(std::pair<int, std::string>(CLUTTER_ENTER, "samsung.tv.halo.input.mouseenter"));
		m_eventTypeMap.insert(std::pair<int, std::string>(CLUTTER_LEAVE, "samsung.tv.halo.input.mouseleave"));
		m_eventTypeMap.insert(std::pair<int, std::string>(CLUTTER_BUTTON_PRESS, "samsung.tv.halo.input.mousepress"));
		m_eventTypeMap.insert(std::pair<int, std::string>(CLUTTER_BUTTON_RELEASE, "samsung.tv.halo.input.mouserelease"));
		m_eventTypeMap.insert(std::pair<int, std::string>(CLUTTER_SCROLL, "samsung.tv.halo.input.mousescroll"));
		m_eventTypeMap.insert(std::pair<int, std::string>(CLUTTER_STAGE_STATE, "samsung.tv.halo.input.mouseenter"));
		m_eventTypeMap.insert(std::pair<int, std::string>(CLUTTER_DESTROY_NOTIFY, "samsung.tv.halo.input.mouseenter"));
		m_eventTypeMap.insert(std::pair<int, std::string>(CLUTTER_CLIENT_MESSAGE, "samsung.tv.clutter.clientmesage"));
		m_eventTypeMap.insert(std::pair<int, std::string>(CLUTTER_DELETE, "samsung.tv.clutter.delete"));
		m_eventTypeMap.insert(std::pair<int, std::string>(CLUTTER_TOUCH_BEGIN, "samsung.tv.halo.input.touchbegin"));
		m_eventTypeMap.insert(std::pair<int, std::string>(CLUTTER_TOUCH_UPDATE, "samsung.tv.halo.input.touchupdate"));
		m_eventTypeMap.insert(std::pair<int, std::string>(CLUTTER_TOUCH_END, "samsung.tv.halo.input.touchend"));
		m_eventTypeMap.insert(std::pair<int, std::string>(CLUTTER_TOUCH_CANCEL, "samsung.tv.halo.input.touchcancel"));
		m_eventTypeMax = 1000;
		m_eventTypeMapLock.Unlock();
		m_dbus = new CDbus;		
		ASSERT(m_dbus);
		m_dbus->DbusInit("org.tizen.input"); 
		m_keyLongPressInterval = 1500;
	}


	
	CEventManager::~CEventManager()
	{
		if (m_pInputManager)
		{
			delete m_pInputManager;
			m_pInputManager = NULL;
		}
		m_pListenerSetLock->Lock();
		if (m_pSystemEventListenerSet)
		{
			delete m_pSystemEventListenerSet;
			m_pSystemEventListenerSet = NULL;
		}
		if (m_pAsyncTaskListenerSet)
		{
			delete m_pAsyncTaskListenerSet;
			m_pAsyncTaskListenerSet = NULL;
		}

		if (m_pCustomEventListenerSet)
		{
			delete m_pCustomEventListenerSet;
			m_pCustomEventListenerSet = NULL;
		}
		m_pListenerSetLock->Destroy();
		delete m_pListenerSetLock;
		m_pListenerSetLock = NULL;
		
		if (m_dbus)
		{
			delete m_dbus;
			m_dbus = NULL;
		}
		m_eventTypeMapLock.Lock();
		m_eventTypeMapLock.Destroy();
	}
	bool CEventManager::SendEventLocal(IEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CEventManager::SendEventLocal ");
		ASSERT(event != NULL);
		if (event == NULL)
		{
			return false;
		}
		//clone event for keeping pointer of event to client message.
		IEvent* pNewEvent = event->Clone();
		CEvent* pEvent = dynamic_cast<CEvent*>(pNewEvent);
		if (pEvent == NULL)
		{
			return false;
		}
		ClutterEvent* clutterEvent = pEvent->Transform();
		if (clutterEvent == NULL)
		{
			return false;
		}

		//client message keep a pointer of event, otherwise destroy the clone event.
		if (clutterEvent->any.type != CLUTTER_CLIENT_MESSAGE)
		{
			pNewEvent->Release();
			pNewEvent = NULL;
		}
		clutter_do_event(clutterEvent);
		clutter_event_free(clutterEvent);
		return true;
	}
	
	bool CEventManager::SendEventLocalSync(IEvent* reqEvent, IEvent* resEvent)
	{
		H_LOG_TRACE(LOGGER, "CEventManager::SendEventLocalSync ");
		bool ret = false;
		if (m_pCustomEventListenerSet)
		{
			ret |= m_pCustomEventListenerSet->Process(reqEvent, resEvent, true);
		}
		
		return ret;
	}
	
	bool CEventManager::SendEventRemote(const char* target, IEvent* requestEvent, bool bAsync, bool* pbHasResponse, IEvent* responseEvent)
	{
		H_LOG_TRACE(LOGGER, "CEventManager::SendEventRemote bAsync = " << bAsync << ")");
		ASSERT(requestEvent != NULL);

		char* requestData = NULL;
		char* responseData = NULL;

		CEvent* pEvent = dynamic_cast<CEvent*>(requestEvent);
		if (pEvent == NULL)
		{
			return false;
		}
		int id = pEvent->EventType();
		char *eventType = (char *)GetEventName(id);
		if (eventType == NULL)
		{
			return false;
		}

		//! Put event type
		pEvent->PutString("EventType", eventType);

		int len = strlen(eventType);
		char *eventName = new char[len+1];
		memcpy(eventName, eventType, len+1);
		for (int i = 0; i < len; i++)
		{
			if (eventName[i] == '.')
			{
				eventName[i] = '_';
			}
		}
		
		pEvent->EncodeBundle((unsigned char **)&requestData, &len);
		
		//! Send event
		bool ret = false;
		if (m_dbus == NULL)
		{
			delete [] eventName;
			eventName = NULL;
			return ret;
		}
		ret = m_dbus->DbusSendEvent(target, eventName, requestData, &responseData, bAsync);
		delete [] eventName;
		eventName = NULL;

		//! If bAsysn == false, need response data
		if (bAsync == false && ret == true && pbHasResponse && responseEvent)
		{
			*pbHasResponse = false;
			if (responseData)
			{
				CEvent *evt = dynamic_cast<CEvent *>(responseEvent);
				if (evt && evt->DecodeBundle((const unsigned char *)responseData, strlen(responseData)))
				{
					*pbHasResponse = true;
				}
			}
		}

		return ret;
	}

	void CEventManager::RegisterInterestingEvent(const char *eventName)
	{
		H_LOG_TRACE(LOGGER, "CEventManager::RegisterInterestingEvent(" << eventName << ")");
		m_dbus->DbusRegEvent(eventName);
	}
	
	void CEventManager::UnregisterInterestingEvent(const char *eventName)
	{
		H_LOG_TRACE(LOGGER, "CEventManager::UnregisterInterestingEvent(" << eventName << ")");
		m_dbus->DbusUnregEvent(eventName);
	}

	bool CEventManager::AddSystemEventListener(ISystemEventListener* systemListener)
	{
		H_LOG_TRACE(LOGGER, "CEventManager::AddSystemEventListener ");
		if (m_pSystemEventListenerSet == NULL)
		{
			m_pSystemEventListenerSet = new CSystemEventListenerSet;
			ASSERT(m_pSystemEventListenerSet);
		}
		return m_pSystemEventListenerSet->Add(systemListener);
	}
	bool CEventManager::RemoveSystemEventListener(ISystemEventListener* systemListener)
	{
		H_LOG_TRACE(LOGGER, "CEventManager::RemoveSystemEventListener ");
		if (m_pSystemEventListenerSet == NULL)
		{
			return false;
		}
		return m_pSystemEventListenerSet->Remove(systemListener);
	}
	bool CEventManager::AddAsyncTaskListener(ITaskListener* taskListener)
	{
		H_LOG_TRACE(LOGGER, "CEventManager::AddAsyncTaskListener ");
		if (m_pAsyncTaskListenerSet == NULL)
		{
			m_pAsyncTaskListenerSet = new CAsyncTaskListenerSet;
		}
		return m_pAsyncTaskListenerSet->Add(taskListener);
	}
	bool CEventManager::RemoveAsyncTaskListener(ITaskListener* taskListener)
	{
		H_LOG_TRACE(LOGGER, "CEventManager::RemoveAsyncTaskListener ");
		if (m_pAsyncTaskListenerSet == NULL)
		{
			return false;
		}
		return m_pAsyncTaskListenerSet->Remove(taskListener);
	}
	bool CEventManager::AddCustomEventListener(ICustomEventListener* customListener)
	{
		H_LOG_TRACE(LOGGER, "CEventManager::AddCustomEventListener ");
		if (m_pCustomEventListenerSet == NULL)
		{
			m_pCustomEventListenerSet = new CCustomEventListenerSet;
		}
		return m_pCustomEventListenerSet->Add(customListener);
	}
	bool CEventManager::RemoveCustomEventListener(ICustomEventListener* customListener)
	{
		H_LOG_TRACE(LOGGER, "CEventManager::RemoveCustomEventListener ");
		if (m_pCustomEventListenerSet == NULL)
		{
			return false;
		}
		return m_pCustomEventListenerSet->Remove(customListener);
	}

	gboolean CEventManager::ProcessClutterEvent(const ClutterEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CEventManager::ProcessClutterEvent");
		ASSERT(event);
		switch (event->type)
		{
		case CLUTTER_KEY_PRESS:
		case CLUTTER_KEY_RELEASE:
		case CLUTTER_MOTION:
		case CLUTTER_ENTER:
		case CLUTTER_LEAVE:
		case CLUTTER_BUTTON_PRESS:
		case CLUTTER_BUTTON_RELEASE:
		case CLUTTER_SCROLL:
		case CLUTTER_STAGE_STATE:
		case CLUTTER_DESTROY_NOTIFY:
		case CLUTTER_DELETE:
		case CLUTTER_TOUCH_BEGIN:
		case CLUTTER_TOUCH_UPDATE:
		case CLUTTER_TOUCH_END:
		case CLUTTER_TOUCH_CANCEL:
			{
				return m_pInputManager->ProcessInputEvent(event);
			}
		case CLUTTER_CLIENT_MESSAGE:
			{
				ClutterEvent* temp = const_cast<ClutterEvent*>(event);
				IEvent* pEvent = (IEvent*)temp->client.pointer;
				return ProcessEvent(dynamic_cast<CEvent*>(pEvent));
			}
		default:
			break;
		}
		return CLUTTER_EVENT_PROPAGATE;
	}
	gboolean CEventManager::ProcessEvent(CEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CEventManager::ProcessEvent");
		if (event)
		{
			if (event->IsEventType("samsung.tv.halo.system.quit")) 
			{
				CFocusManager* pFocusManager = CFocusManager::GetInstance();
				if (pFocusManager)
				{
					pFocusManager->Enable(false);
				}

				if (m_pSystemEventListenerSet)
				{
					m_pSystemEventListenerSet->Process(event);
				}
				clutter_main_quit();
			}
			else if (event->IsEventType("samsung.tv.halo.system.cursorvisible") || event->IsEventType("samsung.tv.halo.system.cursorhidden"))
			{
				if (m_pSystemEventListenerSet)
				{
					m_pSystemEventListenerSet->Process(event);
				}
			}
			else if (event->IsEventType("samsung.tv.halo.system.async.update") || event->IsEventType("samsung.tv.halo.system.async.finish"))
			{
				if (m_pAsyncTaskListenerSet)
				{
					m_pAsyncTaskListenerSet->Process(event);
				}
			}
			else if (event->IsEventType("samsung.tv.halo.system.asyncrelease"))
			{
				CSystemEvent* systemEvent = dynamic_cast<CSystemEvent*>(event);
				if (systemEvent)
				{
					void* pointor = NULL;
					systemEvent->GetPointor("Target", &pointor);
					Widget* target = (Widget*)pointor;
					if (target)
					{
						delete target;
						target = NULL;
					}
				}

			}
			else
			{
				if (m_pCustomEventListenerSet)
				{
					m_pCustomEventListenerSet->Process(event, NULL, false);
				}
			}
			event->Release();
		}
		return true;
	}
	int CEventManager::GetEventType(const char* eventName)
	{
		H_LOG_TRACE(LOGGER, "CEventManager::GetEventType(" << eventName << ")");
		ASSERT(eventName != NULL);

		std::string str = eventName;

		m_eventTypeMapLock.Lock();
		EventTypeMapIter iter = m_eventTypeMap.begin();
		while (iter != m_eventTypeMap.end())
		{
			if (iter->second == str)
			{
				int eventType = iter->first;
				m_eventTypeMapLock.Unlock();
				return eventType;
			}
			iter++;
		}
		m_eventTypeMap.insert(std::pair<int, std::string>(m_eventTypeMax, str));
		m_eventTypeMapLock.Unlock();

		return m_eventTypeMax++;
	}
	const char* CEventManager::GetEventName(int eventType)
	{
		H_LOG_TRACE(LOGGER, "CEventManager::GetEventType(" << eventType << ")");
		const char *ret = NULL;
		m_eventTypeMapLock.Lock();
		EventTypeMapIter iter = m_eventTypeMap.find(eventType);
		if (iter != m_eventTypeMap.end())
		{
			ret = (iter->second).data();
		}
		m_eventTypeMapLock.Unlock();
		return ret;
	}

	void CEventManager::SetKeyLongPressInterval(int interval)
	{
		H_LOG_TRACE(LOGGER, "CEventManager::SetKeyLongPressInterval(" << interval << ")");
		m_keyLongPressInterval = interval;
	}

	int CEventManager::KeyLongPressInterval()
	{
		H_LOG_TRACE(LOGGER, "CEventManager::KeyLongPressInterval m_keyLongPressIntervalc = " << m_keyLongPressInterval);
		return m_keyLongPressInterval;
	}
}
