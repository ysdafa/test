#ifndef _HALO_CGRIDLAYOUT_H_
#define _HALO_CGRIDLAYOUT_H_
namespace HALO 
{
	class CGridLayout: public IGridLayout, public CLayout
	{
	public:
		virtual bool Initialize(void);

		void Attach(IActor* child, int left, int top, int width, int height);
		
		IActor* ChildAt(int left, int top);

		void InsertColumn(int postition);
		void InsertRow(int position);
		void InsertNextTo(IActor* sibling, ClutterGridPosition side);

		void SetDirection(ClutterOrientation orientation);
		ClutterOrientation Direction(void);

		void EnableColumnHomogeneous(bool homogeneous);
		bool IsColumnHomogeneousEnable(void);
		void EnableRowHomogeneous(bool homogeneous);
		bool IsRowHomogeneousEnable(void);

		void SetColumnSpacing(float spacing);
		float ColumnSpacing(void);
		void SetRowSpacing(float spacing);
		float RowSpacing(void);
	};
}
#endif //_HALO_CGRIDLAYOUT_H_
