#include "Halo1_0.h"

namespace HALO 
{
	static HALO::util::Logger LOGGER("CBoxLayout");

	bool CBoxLayout::Initialize(void)
	{
		H_LOG_TRACE(LOGGER, "CBoxLayout::Initialize a BoxLayout");
		layoutmanager = clutter_box_layout_new();
		return true;
	}

	void CBoxLayout::SetPackStartFlag(bool pack_start)
	{
		H_LOG_TRACE(LOGGER, "CBoxLayout::SetPackStartFlag [" << pack_start << "]");
		clutter_box_layout_set_pack_start(CLUTTER_BOX_LAYOUT(layoutmanager), pack_start);
	}

	bool CBoxLayout::FlagPackStart()
	{
		H_LOG_TRACE(LOGGER, "CBoxLayout::FlagPackStart");
		return clutter_box_layout_get_pack_start(CLUTTER_BOX_LAYOUT(layoutmanager)) != FALSE;
	}

	void CBoxLayout::SetSpacing(float spacing)
	{
		H_LOG_TRACE(LOGGER, "CBoxLayout::SetSpacing [" << spacing << "]");
		clutter_box_layout_set_spacing(CLUTTER_BOX_LAYOUT(layoutmanager), guint(spacing));
	}

	float CBoxLayout::Spacing()
	{
		H_LOG_TRACE(LOGGER, "CBoxLayout::Spacing");
		return float(clutter_box_layout_get_spacing(CLUTTER_BOX_LAYOUT(layoutmanager)));
	}

	void CBoxLayout::EnableHomogeneous(bool homogeneous)
	{
		H_LOG_TRACE(LOGGER, "CBoxLayout::EnableHomogeneous [" << homogeneous << "]");
		clutter_box_layout_set_homogeneous(CLUTTER_BOX_LAYOUT(layoutmanager), homogeneous);
	}

	bool CBoxLayout::IsHomogeneousEnable()
	{
		H_LOG_TRACE(LOGGER, "CBoxLayout::IsHomogeneousEnable");
		return clutter_box_layout_get_homogeneous(CLUTTER_BOX_LAYOUT(layoutmanager)) != FALSE;
	}

	ClutterOrientation CBoxLayout::Direction()
	{
		H_LOG_TRACE(LOGGER, "CBoxLayout::Direction");
		return clutter_box_layout_get_orientation(CLUTTER_BOX_LAYOUT(layoutmanager));
	}

	void CBoxLayout::SetDirection(ClutterOrientation orientation)
	{
		H_LOG_TRACE(LOGGER, "CBoxLayout::SetDirection [" << orientation << "]");
		clutter_box_layout_set_orientation(CLUTTER_BOX_LAYOUT(layoutmanager), orientation);
	}
}

