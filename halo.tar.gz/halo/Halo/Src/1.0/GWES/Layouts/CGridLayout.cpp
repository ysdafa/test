#include <iostream>
#include "Halo1_0.h"

namespace HALO 
{
	static HALO::util::Logger LOGGER("CGridLayout");

	bool CGridLayout::Initialize(void)
	{
		H_LOG_TRACE(LOGGER, "CGridLayout::Initialize a GridLayout");
		layoutmanager = clutter_grid_layout_new();
		return true;
	}

	void CGridLayout::Attach(IActor* child, int left, int top, int width, int height)
	{
		H_LOG_TRACE(LOGGER, "CGridLayout::Attach [" << left << "," << top << "," << width << "," << height << "]");
		ASSERT(child != NULL);
		ClutterActor *m_child = child->Actor();
		if (m_child != NULL)
		{
			clutter_actor_show(m_child);
			clutter_grid_layout_attach(CLUTTER_GRID_LAYOUT(layoutmanager), m_child, left, top, width, height);
		}
		else
		{
			H_LOG_FATAL(LOGGER, "CGridLayout::Attach::Child is NULL");
		}
	}

	IActor* CGridLayout::ChildAt(int left, int top)
	{
		H_LOG_TRACE(LOGGER, "CGridLayout::ChildAt[" << left << "," << top << "]");
		ClutterActor *m_actor = clutter_grid_layout_get_child_at(CLUTTER_GRID_LAYOUT(layoutmanager), left, top);
		return D_GET_HALO_ACTOR(G_OBJECT(m_actor));
	}

	void CGridLayout::InsertColumn(int position)
	{
		H_LOG_TRACE(LOGGER, "CGridLayout::InsertColumn [" << position << "]");
		clutter_grid_layout_insert_column(CLUTTER_GRID_LAYOUT(layoutmanager), position);
	}

	void CGridLayout::InsertRow(int position)
	{
		H_LOG_TRACE(LOGGER, "CGridLayout::InsertRow [" << position << "]");
		clutter_grid_layout_insert_row(CLUTTER_GRID_LAYOUT(layoutmanager), position);
	}

	void CGridLayout::InsertNextTo(IActor* sibling, ClutterGridPosition side)
	{
		H_LOG_TRACE(LOGGER, "CGridLayout::InsertNextTo [" << side << "]");
		ASSERT(sibling != NULL);
		CActor* cSibling = dynamic_cast<CActor*>(sibling);
		if (cSibling != NULL)
		{
			clutter_grid_layout_insert_next_to(CLUTTER_GRID_LAYOUT(layoutmanager), cSibling->Actor(), side);
		}	
		else
		{
			H_LOG_FATAL(LOGGER, "CGridLayout::InsertNextTo_Sibling is NULL");
		}
	}

	void CGridLayout::SetDirection(ClutterOrientation orientation)
	{
		H_LOG_TRACE(LOGGER, "CGridLayout::SetDirection [" << orientation << "]");
		clutter_grid_layout_set_orientation(CLUTTER_GRID_LAYOUT(layoutmanager), orientation);
	}

	ClutterOrientation CGridLayout::Direction()
	{
		H_LOG_TRACE(LOGGER, "CGridLayout::Direction");
		return clutter_grid_layout_get_orientation(CLUTTER_GRID_LAYOUT(layoutmanager));
	}

	void CGridLayout::EnableColumnHomogeneous(bool homogeneous)
	{
		H_LOG_TRACE(LOGGER, "CGridLayout::EnableColumnHomogeneous [" << homogeneous << "]");
		clutter_grid_layout_set_column_homogeneous(CLUTTER_GRID_LAYOUT(layoutmanager), homogeneous);
	}

	bool CGridLayout::IsColumnHomogeneousEnable()
	{
		H_LOG_TRACE(LOGGER, "CGridLayout::IsColumnHomogeneousEnable");
		return clutter_grid_layout_get_column_homogeneous(CLUTTER_GRID_LAYOUT(layoutmanager)) != FALSE;
	}

	void CGridLayout::EnableRowHomogeneous(bool homogeneous)
	{
		H_LOG_TRACE(LOGGER, "CGridLayout::EnableRowHomogeneous [" << homogeneous << "]");
		clutter_grid_layout_set_row_homogeneous(CLUTTER_GRID_LAYOUT(layoutmanager), homogeneous);
	}

	bool CGridLayout::IsRowHomogeneousEnable()
	{
		H_LOG_TRACE(LOGGER, "CGridLayout::IsRowHomogeneousEnable");
		return clutter_grid_layout_get_row_homogeneous(CLUTTER_GRID_LAYOUT(layoutmanager)) != FALSE;
	}

	void CGridLayout::SetColumnSpacing(float spacing)
	{
		H_LOG_TRACE(LOGGER, "CGridLayout::SetColumnSpacing [" << spacing << "]");
		clutter_grid_layout_set_column_spacing(CLUTTER_GRID_LAYOUT(layoutmanager), guint(spacing));
	}

	float CGridLayout::ColumnSpacing()
	{
		H_LOG_TRACE(LOGGER, "CGridLayout::ColumnSpacing");
		return float(clutter_grid_layout_get_column_spacing(CLUTTER_GRID_LAYOUT(layoutmanager)));
	}

	void CGridLayout::SetRowSpacing(float spacing)
	{
		H_LOG_TRACE(LOGGER, "CGridLayout::SetRowSpacing [" << spacing << "]");
		clutter_grid_layout_set_row_spacing(CLUTTER_GRID_LAYOUT(layoutmanager), guint(spacing));
	}

	float CGridLayout::RowSpacing()
	{
		H_LOG_TRACE(LOGGER, "CGridLayout::RowSpacing");
		return float(clutter_grid_layout_get_row_spacing(CLUTTER_GRID_LAYOUT(layoutmanager)));
	}
}

