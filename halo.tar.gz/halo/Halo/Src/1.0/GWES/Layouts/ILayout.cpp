#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	static HALO::util::Logger LOGGER("ILayout");
	
	IFixedLayout* IFixedLayout::CreateInstance(void)
	{
		H_LOG_TRACE(LOGGER, "ILayout::Create IFixedLayout Instance");
		CFixedLayout* layout = dynamic_cast<CFixedLayout*>(Instance::CreateInstance(CLASS_ID_IFIXEDLAYOUT));

		if (NULL != layout)
		{
			layout->Initialize();
		}

		return layout;
	}

	IBinLayout* IBinLayout::CreateInstance(void)
	{
		H_LOG_TRACE(LOGGER, "ILayout::Create IBinLayout Instance");
		CBinLayout* layout = dynamic_cast<CBinLayout*>(Instance::CreateInstance(CLASS_ID_IBINLAYOUT));

		if (NULL != layout)
		{
			layout->Initialize();
		}

		return layout;
	}
	
	IBoxLayout* IBoxLayout::CreateInstance(void)
	{
		H_LOG_TRACE(LOGGER, "ILayout::Create IBoxLayout Instance");
		CBoxLayout* layout = dynamic_cast<CBoxLayout*>(Instance::CreateInstance(CLASS_ID_IBOXLAYOUT));

		if (NULL != layout)
		{
			layout->Initialize();
		}

		return layout;
	}

	IFlowLayout* IFlowLayout::CreateInstance(void)
	{
		H_LOG_TRACE(LOGGER, "ILayout::Create IFlowLayout Instance");
		CFlowLayout* layout = dynamic_cast<CFlowLayout*>(Instance::CreateInstance(CLASS_ID_IFLOWLAYOUT));

		if (NULL != layout)
		{
			layout->Initialize();
		}

		return layout;
	}

	IFlowLayout* IFlowLayout::CreateInstance(ClutterFlowOrientation orientation)
	{
		H_LOG_TRACE(LOGGER, "ILayout::Create IFlowLayout Instance with orientation");
		CFlowLayout* layout = dynamic_cast<CFlowLayout*>(Instance::CreateInstance(CLASS_ID_IFLOWLAYOUT));

		if (NULL != layout)
		{
			layout->Initialize(orientation);
		}

		return layout;
	}


	IGridLayout* IGridLayout::CreateInstance(void)
	{
		H_LOG_TRACE(LOGGER, "ILayout::Create IGridLayout Instance");
		CGridLayout* layout = dynamic_cast<CGridLayout*>(Instance::CreateInstance(CLASS_ID_IGRIDLAYOUT));

		if (NULL != layout)
		{
			layout->Initialize();
		}

		return layout;
	}

}