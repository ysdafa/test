#ifndef _HALO_CBOXLAYOUT_H_
#define _HALO_CBOXLAYOUT_H_

namespace HALO 
{
	class CBoxLayout: public IBoxLayout , public CLayout
	{
	public:
		virtual bool Initialize(void);
		
		void SetPackStartFlag(bool pack_start);
		bool FlagPackStart(void);

		void SetSpacing(float spacing);
		float Spacing(void);
		
		void EnableHomogeneous(bool homogeneous);
		bool IsHomogeneousEnable(void);
		
		ClutterOrientation Direction(void);
		void SetDirection(ClutterOrientation orientation);
	};
}
#endif //_HALO_CBOXLAYOUT_H_
