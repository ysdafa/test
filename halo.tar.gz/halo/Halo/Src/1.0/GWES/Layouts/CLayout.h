#ifndef _HALO_CLAYOUT_H_
#define _HALO_CLAYOUT_H_

namespace HALO
{
	class CLayout : virtual public ILayout
	{
	public:
		CLayout(void) : layoutmanager(NULL) {}
		~CLayout(void) { layoutmanager = NULL; }
		virtual bool Initialize() { return true; }
		ClutterLayoutManager* GetLayoutManager(void);

		//Align
		void SetActorXAlign(IActor* self, ClutterActorAlign x_align);
		ClutterActorAlign ActorXAlign(IActor* self);
		void SetActorYAlign(IActor* self, ClutterActorAlign y_align);
		ClutterActorAlign ActorYAlign(IActor* self);

		//Margin
		ClutterMargin* CopyMargin(const ClutterMargin *margin_);
		void SetMargin(IActor* self, const ClutterMargin* margin);
		void GetMargin(IActor* self, ClutterMargin* margin);
		void SetMarginTop(IActor* self, float margin);
		float MarginTop(IActor* self);
		void SetMarginRight(IActor* self, float margin);
		float MarginRight(IActor* self);
		void SetMarginBottom(IActor* self, float margin);
		float MarginBottom(IActor* self);
		void SetMarginLeft(IActor* self, float margin);
		float MarginLeft(IActor* self);

		//Expand
		void SetXExpandFlag(IActor* self, bool expand);
		bool FlagXExpand(IActor* self);
		void SetYExpandFlag(IActor* self, bool expand);
		bool FlagYExpand(IActor* self);

	protected:
		ClutterLayoutManager* layoutmanager;
	};
}
#endif //_HALO_CLAYOUT_H_