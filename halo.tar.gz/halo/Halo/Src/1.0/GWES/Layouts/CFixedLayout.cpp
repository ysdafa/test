#include "Halo1_0.h"

namespace HALO 
{
	static HALO::util::Logger LOGGER("CFixedLayout");

	bool CFixedLayout::Initialize()
	{
		H_LOG_TRACE(LOGGER, "CFixedLayout::Initialize a FixedLayout");
		layoutmanager = clutter_fixed_layout_new();
		return true;
	}
}

