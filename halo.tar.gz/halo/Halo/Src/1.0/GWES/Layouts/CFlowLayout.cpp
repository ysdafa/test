#include "Halo1_0.h"

namespace HALO 
{
	static HALO::util::Logger LOGGER("CFlowLayout");

	bool CFlowLayout::Initialize()
	{
		H_LOG_TRACE(LOGGER, "CFlowLayout::Initialize a FlowLayout");
		Initialize(CLUTTER_FLOW_HORIZONTAL);
		return true;
	}
	
	bool CFlowLayout::Initialize(ClutterFlowOrientation orientation)
	{
		H_LOG_TRACE(LOGGER, "CFlowLayout::Initialize a FlowLayout with orientation [" << orientation << "]");
		layoutmanager = clutter_flow_layout_new(orientation);
		return true;
	}

	void CFlowLayout::EnableHomogeneous(bool homogeneous)
	{
		H_LOG_TRACE(LOGGER, "CFlowLayout::EnableHomogeneous ["<<homogeneous<<"]");
		clutter_flow_layout_set_homogeneous(CLUTTER_FLOW_LAYOUT(layoutmanager), homogeneous);
	}

	bool CFlowLayout::IsHomogeneousEnabled()
	{
		H_LOG_TRACE(LOGGER, "CFlowLayout::IsHomogeneousEnabled");
		return clutter_flow_layout_get_homogeneous(CLUTTER_FLOW_LAYOUT(layoutmanager)) != FALSE;
	}

	void CFlowLayout::SetDirection(ClutterFlowOrientation orientation)
	{
		H_LOG_TRACE(LOGGER, "CFlowLayout::SetDirection [" << orientation << "]");
		clutter_flow_layout_set_orientation(CLUTTER_FLOW_LAYOUT(layoutmanager), orientation);
	}

	ClutterFlowOrientation CFlowLayout::Direction()
	{
		H_LOG_TRACE(LOGGER, "CFlowLayout::Direction");
		return clutter_flow_layout_get_orientation(CLUTTER_FLOW_LAYOUT(layoutmanager));
	}

	void CFlowLayout::SetColumnSpacing(float spacing)
	{
		H_LOG_TRACE(LOGGER, "CFlowLayout::SetColumnSpacing [" << spacing << "]");
		clutter_flow_layout_set_column_spacing(CLUTTER_FLOW_LAYOUT(layoutmanager), spacing);
	}

	float CFlowLayout::ColumnSpacing()
	{
		H_LOG_TRACE(LOGGER, "CFlowLayout::ColumnSpacing");
		return clutter_flow_layout_get_column_spacing(CLUTTER_FLOW_LAYOUT(layoutmanager));
	}

	void CFlowLayout::SetRowSpacing(float spacing)
	{
		H_LOG_TRACE(LOGGER, "CFlowLayout::SetRowSpacing [" << spacing << "]");
		clutter_flow_layout_set_row_spacing(CLUTTER_FLOW_LAYOUT(layoutmanager), spacing);
	}

	float CFlowLayout::RowSpacing()
	{
		H_LOG_TRACE(LOGGER, "CFlowLayout::RowSpacing");
		return clutter_flow_layout_get_row_spacing(CLUTTER_FLOW_LAYOUT(layoutmanager));
	}

	void CFlowLayout::SetColumnWidth(float min_width, float max_width)
	{
		H_LOG_TRACE(LOGGER, "CFlowLayout::SetColumnWidth [" << min_width << "," << max_width << "]");
		clutter_flow_layout_set_column_width(CLUTTER_FLOW_LAYOUT(layoutmanager), min_width, max_width);
	}

	void CFlowLayout::GetColumnWidth(float &min_width, float &max_width)
	{
		H_LOG_TRACE(LOGGER, "CFlowLayout::GetColumnWidth");
		clutter_flow_layout_get_column_width(CLUTTER_FLOW_LAYOUT(layoutmanager), &min_width, &max_width);
	}

	void CFlowLayout::SetRowHeight(float min_height, float max_height)
	{
		H_LOG_TRACE(LOGGER, "CFlowLayout::SetRowHeight [" << min_height << "," << max_height << "]");
		clutter_flow_layout_set_row_height(CLUTTER_FLOW_LAYOUT(layoutmanager), min_height, max_height);
	}

	void CFlowLayout::GetRowHeight(float &min_height, float &max_height)
	{
		H_LOG_TRACE(LOGGER, "CFlowLayout::GetRowHeight");
		clutter_flow_layout_get_row_height(CLUTTER_FLOW_LAYOUT(layoutmanager), &min_height, &max_height);
	}
}

