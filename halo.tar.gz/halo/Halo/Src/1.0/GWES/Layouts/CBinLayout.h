#ifndef _HALO_CBINLAYOUT_H_
#define _HALO_CBINLAYOUT_H_

namespace HALO 
{
	class CBinLayout: public IBinLayout, public CLayout 
	{
	public:
		virtual bool Initialize(void);
		virtual bool Initialize(ClutterBinAlignment hAlignment, ClutterBinAlignment vAlignment);
	};
}
#endif //_HALO_CBINLAYOUT_H_
