#ifndef _HALO_CFLOWLAYOUT_H_
#define _HALO_CFLOWLAYOUT_H_

namespace HALO 
{
	class CFlowLayout: public IFlowLayout, public CLayout
	{
	public:
		bool Initialize(void);
		bool Initialize(ClutterFlowOrientation orientation);

		void EnableHomogeneous(bool homogeneous);
		bool IsHomogeneousEnabled(void);

		void SetDirection(ClutterFlowOrientation orientation);
		ClutterFlowOrientation Direction(void);
		
		void SetColumnSpacing(float spacing);
		float ColumnSpacing(void);
		void SetRowSpacing(float spacing);
		float RowSpacing(void);

		void SetColumnWidth(float min_width, float max_width);
		void GetColumnWidth(float &min_width, float &max_width);
		void SetRowHeight(float min_height, float max_height);
		void GetRowHeight(float &min_height, float &max_height);
	};
}
#endif //_HALO_CFLOWLAYOUT_H_
