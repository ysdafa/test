#include "Halo1_0.h"

namespace HALO 
{
	static HALO::util::Logger LOGGER("CLayout");

	ClutterLayoutManager* CLayout::GetLayoutManager(void)
	{
		H_LOG_TRACE(LOGGER, "CLayout::GetLayoutManager");
		return layoutmanager;
	}

	void CLayout::SetActorXAlign(IActor* self, ClutterActorAlign x_align)
	{
		H_LOG_TRACE(LOGGER, "CLayout::SetActorXAlign [" << x_align << "]");
		ASSERT(self != NULL);
		clutter_actor_set_x_align(self->Actor(), x_align);
	}

	ClutterActorAlign CLayout::ActorXAlign(IActor* self)
	{
		H_LOG_TRACE(LOGGER, "CLayout::ActorXAlign");
		ASSERT(self != NULL);
		return clutter_actor_get_x_align(self->Actor());
	}

	void CLayout::SetActorYAlign(IActor* self, ClutterActorAlign y_align)
	{
		H_LOG_TRACE(LOGGER, "CLayout::SetActorYAlign [" << y_align << "]");
		ASSERT(self != NULL);
		clutter_actor_set_y_align(self->Actor(), y_align);
	}

	ClutterActorAlign CLayout::ActorYAlign(IActor* self)
	{
		H_LOG_TRACE(LOGGER, "CLayout::ActorYAlign");
		ASSERT(self != NULL);
		return clutter_actor_get_y_align(self->Actor());
	}
	
	ClutterMargin* CLayout::CopyMargin(const ClutterMargin *margin_)
	{
		H_LOG_TRACE(LOGGER, "CLayout::CopyMargin");
		ASSERT(margin_ != NULL);
		return clutter_margin_copy(margin_);
	}
	
	void CLayout::SetMargin(IActor* self, const ClutterMargin* margin)
	{
		H_LOG_TRACE(LOGGER, "CLayout::SetMargin");
		ASSERT(self != NULL && margin != NULL);
		clutter_actor_set_margin(self->Actor(), margin);
	}

	void CLayout::GetMargin(IActor* self, ClutterMargin* margin)
	{
		H_LOG_TRACE(LOGGER, "CLayout::GetMargin");
		ASSERT(self != NULL && margin != NULL);
		clutter_actor_get_margin(self->Actor(), margin);
	}

	void CLayout::SetMarginTop(IActor* self, float margin)
	{
		H_LOG_TRACE(LOGGER, "CLayout::SetMarginTop [" << margin << "]");
		ASSERT(self != NULL);
		clutter_actor_set_margin_top(self->Actor(), margin);
	}

	float CLayout::MarginTop(IActor* self)
	{
		H_LOG_TRACE(LOGGER, "CLayout::MarginTop");
		ASSERT(self != NULL);
		return clutter_actor_get_margin_top(self->Actor());
	}

	void CLayout::SetMarginRight(IActor* self, float margin)
	{
		H_LOG_TRACE(LOGGER, "CLayout::SetMarginRight [" << margin << "]");
		ASSERT(self != NULL);
		clutter_actor_set_margin_right(self->Actor(), margin);
	}

	float CLayout::MarginRight(IActor* self)
	{
		H_LOG_TRACE(LOGGER, "CLayout::MarginRight");
		ASSERT(self != NULL);
		return clutter_actor_get_margin_right(self->Actor());
	}

	void CLayout::SetMarginBottom(IActor* self, float margin)
	{
		H_LOG_TRACE(LOGGER, "CLayout::SetMarginBottom [" << margin << "]");
		ASSERT(self != NULL);
		clutter_actor_set_margin_bottom(self->Actor(), margin);
	}

	float CLayout::MarginBottom(IActor* self)
	{
		H_LOG_TRACE(LOGGER, "CLayout::MarginBottom");
		ASSERT(self != NULL);
		return clutter_actor_get_margin_bottom(self->Actor());
	}

	void CLayout::SetMarginLeft(IActor* self, float margin)
	{
		H_LOG_TRACE(LOGGER, "CLayout::SetMarginLeft [" << margin << "]");
		ASSERT(self != NULL);
		clutter_actor_set_margin_left(self->Actor(), margin);
	}

	float CLayout::MarginLeft(IActor* self)
	{
		H_LOG_TRACE(LOGGER, "CLayout::MarginLeft");
		ASSERT(self != NULL);
		return clutter_actor_get_margin_left(self->Actor());
	}

	void CLayout::SetXExpandFlag(IActor* self, bool expand)
	{
		H_LOG_TRACE(LOGGER, "CLayout::SetXExpandFlag [" << expand << "]");
		ASSERT(self != NULL);
		clutter_actor_set_x_expand(self->Actor(), expand);
	}

	bool CLayout::FlagXExpand(IActor* self)
	{
		H_LOG_TRACE(LOGGER, "CLayout::FlagXExpand");
		ASSERT(self != NULL);
		return clutter_actor_get_x_expand(self->Actor()) != FALSE;
	}

	void CLayout::SetYExpandFlag(IActor* self, bool expand)
	{
		H_LOG_TRACE(LOGGER, "CLayout::SetYExpandFlag [" << expand << "]");
		ASSERT(self != NULL);
		clutter_actor_set_y_expand(self->Actor(), expand);
	}

	bool CLayout::FlagYExpand(IActor* self)
	{
		H_LOG_TRACE(LOGGER, "CLayout::FlagYExpand");
		ASSERT(self != NULL);
		return clutter_actor_get_y_expand(self->Actor()) != FALSE;
	}
}

