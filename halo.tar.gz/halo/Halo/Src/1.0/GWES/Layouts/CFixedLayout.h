#ifndef _HALO_CFIXEDLAYOUT_H_
#define _HALO_CFIXEDLAYOUT_H_

namespace HALO 
{
	class CFixedLayout: public IFixedLayout, public CLayout
	{
	public:
		virtual bool Initialize(void);
	};
}
#endif //_HALO_CFIXEDLAYOUT_H_
