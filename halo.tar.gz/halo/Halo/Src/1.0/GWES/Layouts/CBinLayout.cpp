#include "Halo1_0.h"

namespace HALO 
{
	static HALO::util::Logger LOGGER("CBinLayout");

	bool CBinLayout::Initialize(void)
	{
		H_LOG_TRACE(LOGGER, "CBinLayout::Initialize a BinLayout");
		layoutmanager = clutter_bin_layout_new(CLUTTER_BIN_ALIGNMENT_CENTER, CLUTTER_BIN_ALIGNMENT_CENTER);
		return true;
	}

	bool CBinLayout::Initialize(ClutterBinAlignment x_align, ClutterBinAlignment y_align)
	{
		H_LOG_TRACE(LOGGER, "CBinLayout::Initialize a BinLayout with alignment");
		layoutmanager = clutter_bin_layout_new(x_align, y_align);
		return true;
	}
}

