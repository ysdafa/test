#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{

	IActor* IActor::CreateInstance(Widget* parent, float width, float height)
	{
		CActor* actor = dynamic_cast<CActor*>(Instance::CreateInstance(CLASS_ID_IACTOR));

		if (NULL != actor)
		{
			actor->Initialize(parent, width, height);
		}

		return actor;
	}

	IActor* IActor::CreateInstance(IActor* parent, float width, float height)
	{
		CActor* actor = dynamic_cast<CActor*>(Instance::CreateInstance(CLASS_ID_IACTOR));

		if (NULL != actor)
		{
			actor->Initialize(parent, width, height);
		}

		return actor;
	}

	IActor* IActor::CreateInstance(IActor* parent, const TWindowAttr &attr)
	{
		CActor* actor = dynamic_cast<CActor*>(Instance::CreateInstance(CLASS_ID_IACTOR));

		if (NULL != actor)
		{
			actor->Initialize(parent, attr);
		}

		return actor;
	}

}