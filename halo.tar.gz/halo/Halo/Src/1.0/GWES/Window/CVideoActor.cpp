#if !defined(WIN32) && !defined(LINUX_BUILD)
#include "Halo1_0.h"
#include "VoltActor.h"

static HALO::util::Logger LOGGER("CVideoActor");

namespace HALO
{

	/******* CVideoActorListenerSet ***********/
	class CVideoActorListenerSet : public ListenerSet	
	{	
	public: 	
		CVideoActorListenerSet(CVideoActor* owner) :m_owner(owner){};		
		virtual ~CVideoActorListenerSet(void){};		
		virtual bool Process(int type); 
		
	private:		
		CVideoActor* m_owner;	
	};

	bool CVideoActorListenerSet::Process(int type)
	{
		bool ret = false;
		ListenerList::iterator iter = m_list.begin();		
		while (iter != m_list.end())		
		{			
			IVideoActorListener* listener = (IVideoActorListener*)(*iter);			
			switch (type)			
			{			
			case CVideoActor::EVENT_VIDEO_PLAY_COMPLETE: 			
				H_LOG_DEBUG(LOGGER, "[0x" << std::hex << m_owner << "]CVideoActor::EVENT_VIDEO_PLAY_COMPLETE Listener--start");				
				ret |= listener->OnVideoPlayCompleted(m_owner);				
				H_LOG_DEBUG(LOGGER, "[0x" << std::hex << m_owner << "]CVideoActor::EVENT_VIDEO_PLAY_COMPLETE Listener--end");				
				break;			
			default:				
				break;			
			}			
			iter++; 	
		}
		return ret;
	}

	/******* CVideoActor ***********/
	CVideoActor::CVideoActor(void): m_listenerSet(NULL), m_videoPlayCompletedId(0)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::CVideoActor()");	
	}
	
	CVideoActor::~CVideoActor(void)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::~CVideoActor()");

		if (m_videoPlayCompletedId > 0)
		{
			g_signal_handler_disconnect(t_actor, m_videoPlayCompletedId);
		}

		if (m_listenerSet != NULL)
		{
			delete m_listenerSet;
		}
	}
	bool CVideoActor::Initialize(IActor * parent, float width, float height, ClutterVideoController type)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::Initialize with Actor parent " << parent << ",width " << width << ",height " << height << ",type: " << type);	
		Widget *parentWidget = dynamic_cast<Widget*>(parent);
		return Initialize(parentWidget, width, height, type);
	}

	bool CVideoActor::Initialize(Widget* parent, float width, float height, ClutterVideoController type)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::Initialize with Widget parent " << parent << ",width " << width << ",height " << height << ",type: " << type);	
		HALO_ASSERT(parent != NULL && width >= 0 && height >= 0);
		m_videoType = type;
		bool ret = CActor::Initialize(parent, width, height);
		m_listenerSet = new CVideoActorListenerSet(this);
		
		if(m_videoType ==  CLUTTER_VC_TYPE_MM_SYNC || m_videoType == CLUTTER_VC_TYPE_MM_ASYNC)
		{
			m_videoPlayCompletedId = g_signal_connect(t_actor, "video_play_completed", G_CALLBACK(m_VideoPlayerCompletedCb), this);
		}
		return ret;
	}
	
	float CVideoActor::getWidth(void) const
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::getWidth!");	
		
		return clutter_actor_get_width(actor);
	}
	
	void CVideoActor::setWidth(float width)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::setWidth to " << width);	
		
		clutter_actor_set_width(actor, width);
	}
	
	float CVideoActor::getHeight(void) const
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::getHeight!");	
		
		return clutter_actor_get_height(actor);
	}
	
	void CVideoActor::setHeight(float height)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::setHeight to " << height);	
		
		clutter_actor_set_height(actor, height);
	}

	void CVideoActor::Show(void)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::Show");	
		
		clutter_video_show(CLUTTER_VIDEO(actor));
	}

	void CVideoActor::Hide(void)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::Hide");	
		
		clutter_video_hide(CLUTTER_VIDEO(actor));
	}
	
	void CVideoActor::SetVideoType(const ClutterVideoController type)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::SetVideoType with type: " << type);

		m_videoType = type;
		clutter_video_type_set(CLUTTER_VIDEO(actor), type);
	}
	
	ClutterVideoController CVideoActor::VideoType(void) const
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::VideoType");	

		return m_videoType;
	}

	void CVideoActor::SetUri(const std::string& uri)
	{
    	H_LOG_TRACE(LOGGER, "CVideoActor::SetUri: " << uri);
		HALO_ASSERT(m_videoType ==  CLUTTER_VC_TYPE_MM_SYNC || m_videoType == CLUTTER_VC_TYPE_MM_ASYNC);
		
		m_uri = uri;
	}

	std::string CVideoActor::Uri(void) const
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::Uri is" << m_uri);
		HALO_ASSERT(m_videoType ==  CLUTTER_VC_TYPE_MM_SYNC || m_videoType == CLUTTER_VC_TYPE_MM_ASYNC);
		
		return m_uri;
	}
	
	int CVideoActor::Play(void)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::Play");	
		HALO_ASSERT(m_videoType ==  CLUTTER_VC_TYPE_MM_SYNC || m_videoType == CLUTTER_VC_TYPE_MM_ASYNC);

		int ret = clutter_video_uri_set(CLUTTER_VIDEO(actor), m_uri.c_str());	
		H_LOG_INFO(LOGGER, "CVideoActor::clutter_video_uri_set return " << ret);	
		
	    ret |= clutter_video_play_set(CLUTTER_VIDEO(actor));
		H_LOG_INFO(LOGGER, "CVideoActor::Play return " << ret);	
		return ret;
	}
	
	int CVideoActor::Stop(void)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::Stop");
		HALO_ASSERT(m_videoType ==  CLUTTER_VC_TYPE_MM_SYNC || m_videoType == CLUTTER_VC_TYPE_MM_ASYNC);
		
		int ret = clutter_video_stop_set(CLUTTER_VIDEO(actor));
		H_LOG_INFO(LOGGER, "CVideoActor::Stop return " << ret);	
		return ret;
	}
	
	int CVideoActor::Pause(void)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::Pause");
		HALO_ASSERT(m_videoType ==  CLUTTER_VC_TYPE_MM_SYNC || m_videoType == CLUTTER_VC_TYPE_MM_ASYNC);
		
		int ret = clutter_video_pause_set(CLUTTER_VIDEO(actor));
		H_LOG_INFO(LOGGER, "CVideoActor::Pause return " << ret);	
		return ret;
	}

	ClutterVideoControllerState CVideoActor::PlayerState(void) const
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::PlayerState");
		HALO_ASSERT(m_videoType ==  CLUTTER_VC_TYPE_MM_SYNC || m_videoType == CLUTTER_VC_TYPE_MM_ASYNC);
		
	    ClutterVideoControllerState state = CLUTTER_PLAYER_STATE_NONE;
		clutter_video_player_state_get(CLUTTER_VIDEO(actor), &state);
		H_LOG_TRACE(LOGGER, "CVideoActor::PlayerState return " << state);
		
		return state;
	}

	bool CVideoActor::AddListener(IVideoActorListener* listener)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::AddListener: " << listener);
		HALO_ASSERT(m_videoType ==  CLUTTER_VC_TYPE_MM_SYNC || m_videoType == CLUTTER_VC_TYPE_MM_ASYNC);
		HALO_ASSERT(listener != NULL);

		return m_listenerSet->Add(listener);	
	}
	
	bool CVideoActor::RemoveListener(IVideoActorListener* listener)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::RemoveListener: " << listener);
		HALO_ASSERT(m_videoType ==  CLUTTER_VC_TYPE_MM_SYNC || m_videoType == CLUTTER_VC_TYPE_MM_ASYNC);
		HALO_ASSERT(listener != NULL);

		return m_listenerSet->Remove(listener);	
	}
	
	ClutterActor* CVideoActor::t_CreateActor(void)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::t_CreateActor with type: " << m_videoType);	
		
		return clutter_video_new_with_type(m_videoType);
	}

	void CVideoActor::m_VideoPlayerCompletedCb (ClutterVideo *self, gpointer data)
	{
		CVideoActor* pThis = (CVideoActor*)data;
		pThis->m_listenerSet->Process(EVENT_VIDEO_PLAY_COMPLETE);
	}
}

#endif
