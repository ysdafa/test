#ifndef WIN32
#include "Halo1_0.h"
#include "VoltActor.h"

static HALO::util::Logger LOGGER("CVideoActor");

namespace HALO
{
	CVideoActor::CVideoActor(void)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::CVideoActor()");	
	}
	
	CVideoActor::~CVideoActor(void)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::~CVideoActor()");
	}
	bool CVideoActor::Initialize(IActor * parent, float width, float height, ClutterVideoController type)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::Initialize with Actor parent " << parent << ",width " << width << ",height " << height << ",type: " << type);	
		Widget *parentWidget = dynamic_cast<Widget*>(parent);
		return Initialize(parentWidget, width, height, type);
	}

	bool CVideoActor::Initialize(Widget* parent, float width, float height, ClutterVideoController type)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::Initialize with Widget parent " << parent << ",width " << width << ",height " << height << ",type: " << type);	
		ASSERT(parent != NULL && width >= 0 && height >= 0);
		m_videoType = type;
		return CActor::Initialize(parent, width, height);
	}
	
	float CVideoActor::getWidth(void) const
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::getWidth!");	
		
		return clutter_actor_get_width(actor);
	}
	
	void CVideoActor::setWidth(float width)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::setWidth to " << width);	
		
		clutter_actor_set_width(actor, width);
	}
	
	float CVideoActor::getHeight(void) const
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::getHeight!");	
		
		return clutter_actor_get_height(actor);
	}
	
	void CVideoActor::setHeight(float height)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::setHeight to " << height);	
		
		clutter_actor_set_height(actor, height);
	}

	void CVideoActor::Show(void)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::Show");	
		
		clutter_video_show(CLUTTER_VIDEO(actor));
	}

	void CVideoActor::Hide(void)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::Hide");	
		
		clutter_video_hide(CLUTTER_VIDEO(actor));
	}
	
	void CVideoActor::SetVideoType(const ClutterVideoController type)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::SetVideoType with type: " << type);

		m_videoType = type;
		clutter_video_type_set(CLUTTER_VIDEO(actor), type);
	}
	
	ClutterVideoController CVideoActor::VideoType(void) const
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::VideoType");	

		return m_videoType;
	}

	void CVideoActor::SetUri(const std::string& uri)
	{
    	H_LOG_TRACE(LOGGER, "CVideoActor::SetUri: " << uri);
		ASSERT(m_videoType ==  CLUTTER_VC_TYPE_MM_SYNC || m_videoType == CLUTTER_VC_TYPE_MM_ASYNC);
		
		m_uri = uri;
	}

	std::string CVideoActor::Uri(void) const
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::Uri is" << m_uri);
		ASSERT(m_videoType ==  CLUTTER_VC_TYPE_MM_SYNC || m_videoType == CLUTTER_VC_TYPE_MM_ASYNC);
		
		return m_uri;
	}
	
	int CVideoActor::Play(void)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::Play");	
		ASSERT(m_videoType ==  CLUTTER_VC_TYPE_MM_SYNC || m_videoType == CLUTTER_VC_TYPE_MM_ASYNC);

		int ret = clutter_video_uri_set(CLUTTER_VIDEO(actor), m_uri.c_str());	
		H_LOG_INFO(LOGGER, "CVideoActor::clutter_video_uri_set return " << ret);	
		
	    ret |= clutter_video_play_set(CLUTTER_VIDEO(actor));
		H_LOG_INFO(LOGGER, "CVideoActor::Play return " << ret);	
		return ret;
	}
	
	int CVideoActor::Stop(void)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::Stop");
		ASSERT(m_videoType ==  CLUTTER_VC_TYPE_MM_SYNC || m_videoType == CLUTTER_VC_TYPE_MM_ASYNC);
		
		int ret = clutter_video_stop_set(CLUTTER_VIDEO(actor));
		H_LOG_INFO(LOGGER, "CVideoActor::Stop return " << ret);	
		return ret;
	}
	
	int CVideoActor::Pause(void)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::Pause");
		ASSERT(m_videoType ==  CLUTTER_VC_TYPE_MM_SYNC || m_videoType == CLUTTER_VC_TYPE_MM_ASYNC);
		
		int ret = clutter_video_pause_set(CLUTTER_VIDEO(actor));
		H_LOG_INFO(LOGGER, "CVideoActor::Pause return " << ret);	
		return ret;
	}

	ClutterVideoControllerState CVideoActor::PlayerState(void) const
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::PlayerState");
		ASSERT(m_videoType ==  CLUTTER_VC_TYPE_MM_SYNC || m_videoType == CLUTTER_VC_TYPE_MM_ASYNC);
		
	    ClutterVideoControllerState state = CLUTTER_PLAYER_STATE_NONE;
		clutter_video_player_state_get(CLUTTER_VIDEO(actor), &state);
		H_LOG_TRACE(LOGGER, "CVideoActor::PlayerState return " << state);
		
		return state;
	}
	
	
	ClutterActor* CVideoActor::t_CreateActor(void)
	{
		H_LOG_TRACE(LOGGER, "CVideoActor::t_CreateActor with type: " << m_videoType);	
		
		return clutter_video_new_with_type(m_videoType);
	}

}

#endif