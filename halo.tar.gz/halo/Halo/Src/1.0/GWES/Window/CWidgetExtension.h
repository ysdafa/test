#ifndef _HALO_WIDGETHELPER_H
#define _HALO_WIDGETHELPER_H

namespace HALO
{
	class CEvent;
	class CKeyboardEvent;
	class CMouseEvent;
	class CTouchEvent;
	class CRemoconEvent;
	class CRidgeEvent;
	class CMotionEvent;
	class CSensorEvent;
	class CCursorEvent;
	class CAnimatable;
	class CWidgetExtension;

	typedef std::vector<IAction*> TActionList;

	class WidgetHelperListenerSet : public ListenerSet
	{
	public:
		struct TActorListenerData
		{
			int type;
			int param[4];
			void* pData;
		};

		WidgetHelperListenerSet(CWidgetExtension* owner) :m_owner(owner){};
		virtual ~WidgetHelperListenerSet(void){};

		virtual bool Process(TActorListenerData* data);

	private:
		CWidgetExtension* m_owner;
	};

	class WidgetHelperFocusListener : public IFocusListener
	{
	public:
		WidgetHelperFocusListener(class CWidgetExtension* owner) : m_owner(owner) {}

		virtual bool OnFocusIn(IWidgetExtension* pWindow);
		virtual bool OnFocusOut(IWidgetExtension* pWindow);

	protected:

	private:
		class CWidgetExtension* m_owner;
	};

	class CWidgetExtension : virtual public IWidgetExtension, public CAnimatable//: virtual public WidgetHelper, public Widget, public CAnimatable
	{
	public:
		CWidgetExtension(void);
		virtual ~CWidgetExtension(void);

		enum EActorListenerType
		{
			EVENT_FIRST_FOCUSIN = 0,
			EVENT_HIGHCONTRAST_CHANGED,
			EVENT_ENLARGE_CHANGED,
			EVENT_ACTOR_MAX
		};

		//bool Initialize(ClutterActor* parent, float width, float height); // For only rootActor
		//bool Initialize(Widget* parent, float width, float height);
		//bool Initialize(WidgetHelper* parent, float width, float height);
		//bool Initialize(WidgetHelper* parent, const TWindowAttr &attr);

		////! Sets the parent of window to @parent
		//void SetParent(WidgetHelper* parent);
		////! Return the parent of this window
		IWidgetExtension* ParentWidgetExtension(void) const;

		////! Sets the background color of the window
		//virtual void SetBackgroundColor(const ClutterColor &color);

		////! Resize current window
		//virtual void Resize(float width, float height);
		////! Gets the size of the window
		//void GetSize(float &width, float &height);

		////! Sets the position relative to parent, and (0, 0, 0) presents left-top within parent
		//void SetPosition(float x, float y, float z);
		////! Gets the position
		//void GetPosition(float &x, float &y, float &z);
		////! Sets the position without changing z position, and (0, 0) presents left-top within parent
		//void SetPosition(float x, float y);
		////! Gets the position of x,y
		//void GetPosition(float &x, float &y);

		////! Sets the layout manager for this window to @layout
		//virtual bool SetLayout(ILayout* layout);
		////! Return the layout manager that is installed on this window
		//ILayout* Layout(void);

		//! Sets direction orientation
		virtual void UpdateOrientation(EOrientation orientation);

		//! Sets direction orientation
		virtual void SetOrientation(EOrientation orientation);

		//! Return the direction orientation
		EOrientation Orientation(bool flagReferParent = false) const;

		//! Sets current mode to high contrast or not
		virtual void EnableHighContrast(const bool enable);
		//! Return current mode is high contrast or not
		virtual bool IsHighContrastEnabled(void) const;

		virtual void EnableEnlarge(const bool enable);
		virtual bool IsEnlargeEnabled(void) const;

		////! Shows the window
		//virtual void Show(void);
		////! Hides the window and its child windows
		//virtual void Hide(void);
		////! Checks whether the window is shown
		//bool FlagShow(void);

		////! Sets whether the window should be clipped to the same size as its allocation
		//virtual void EnableClipOverflow(bool enable);
		////! Retrieves the value set using EnableCropOverflow() 
		//virtual bool IsClipOverflowEnabled(void);
		////! Sets clip area for the window
		//void SetClipArea(float x, float y, float width, float height);
		////! Gets clip area for the window
		//void GetClipArea(float &x, float &y, float &width, float &height);
		////! Removes clip area from the window
		//void RemoveClipArea(void);
		////! Checks whether the window has a clip area or not
		//bool FlagClip(void);

		////! Sets the window's opacity, with zero being completely transparent and 255 (0xff) being fully opaque. 
		//void SetAlpha(int alpha);
		////! Retrieves the opacity value of a window
		//int Alpha(void);

		////! Sets the position of the "pivot-point" around which the scaling and rotation transformations occur. value range (0.0 ~ 1.0)
		//void SetPivotPoint(float xPivot, float yPivot, float zPivot);
		////! Gets the position of the "pivot-point"
		//void GetPivotPoint(float &xPivot, float &yPivot, float &zPivot);
		////! Sets the rotation angle of a window
		//void SetRotation(double xAngle, double yAngle, double zAngle);
		////! Gets the rotation angle of a window
		//void GetRotation(double &xAngle, double &yAngle, double &zAngle);
		////! Scales a window with the given factors
		//void SetScale(double xFactor, double yFactor, double zFactor);
		////! Retrieves a window's scale factors
		//void GetScale(double &xFactor, double &yFactor, double &zFactor);

		////! Adds effect to window
		//void AddEffect(IEffect* effect);
		////! Removes effect from window
		//void RemoveEffect(IEffect* effect);
		////! Clear all effects that is installed on this window
		//void ClearEffects(void);

		//void AddChild(ClutterActor *actor);

		bool IsAncestor(IWidgetExtension* actor);

		////! Retrieves the number of children
		//int NumOfChildren(void);
		////! Retrieves the window at the given @index inside the list of children of the window
		//WidgetHelper* GetChild(int index);
		////! Destroys all children of this window
		//void DestroyAllChildren(void);

		////! Sets the window to be above @sibling who must have the same parent, if sibling is NULL, Raises this window to the top of the parent window's stack.
		//bool Raise(WidgetHelper* sibling);
		////! Sets the window to be below @sibling who must have the same parent, if sibling is NULL, Lowers the window to the bottom of the parent window's stack.
		//bool Lower(WidgetHelper* sibling);

		//! Sets whether the window can receive input events
		void Enable(bool flagEnable);
		//! Checks whether the window can receive input events
		bool IsEnabled(void);

		//! Sets whether the window can reverse in its parent
		void EnableReverse(const bool enable);
		//! Checks whether the window can reverse in its parent
		bool IsReversible(void) const;

		//! Focus the window when mouse pointer in if @enable is true
		void EnablePointerFocus(bool enable);
		//! Checks if the window auto focus when mouse pointer in
		bool IsPointerFocusEnabled(void);

		//! Sets whether the window can have focus.
		void EnableFocus(bool flagFocusable);
		//! Checks whether the window can set focus.
		bool IsFocusEnabled(void);

		//! Sets the window is focus-window.
		bool SetFocus(void);
		//! Kill the current-focus window and if @autoFocus is true, the focus will pass to the previous focus window.
		bool KillFocus(bool autoFocus = true);
		//! Checks whether the window is current focus-window.
		bool IsFocused(void);

		//! Sets the tab window at direction @dir
		void SetTabWindow(EDirection dir, IWidgetExtension* tabWindow);
		//! Retrieves the tab window at direction @dir
		IWidgetExtension* TabWindow(EDirection dir);
		//! Moves the focus to the window sets as the direction @dir tab window
		virtual bool MoveTab(EDirection dir);

		virtual TActionList* GetActionList(void);

		//! Add Focus Listener
		bool AddFocusListener(IFocusListener* pListener);
		//! Remove Focus Listener
		bool RemoveFocusListener(IFocusListener* pListener);

		virtual void AddTransition(CTransition *transition);
		virtual void RemoveTransition(CTransition *transition);

		//! Grab event
		virtual void GrabDeviceEvent(IDevice *device);
		virtual void UnGrabDeviceEvent(IDevice *device);

	public: //for internal use
		virtual ClutterActor* Actor(void);

	public:
		virtual bool OnEvent(IEvent* pEvent);

		//!Add/Remove mouse listeners
		virtual bool AddMouseListener(IMouseListener* pAddListener);
		virtual bool RemoveMouseListener(IMouseListener* pRemoveListener);

		//! Add/Remove Touch Listener
		virtual bool AddTouchListener(ITouchListener* pAddListener);
		virtual bool RemoveTouchListener(ITouchListener* pRemoveListener);

		//! Add/Remove Keyboard Listener
		virtual bool AddKeyboardListener(IKeyboardListener* pAddListener);
		virtual bool RemoveKeyboardListener(IKeyboardListener* pRemoveListener);

		//! Add/Remove Audio Listener
		virtual bool AddAudioListener(IAudioListener* pAddListener);
		virtual bool RemoveAudioListener(IAudioListener* pRemoveListener);

		//! Add/Remove RemoteControl Listener
		virtual bool AddRemoteControlListener(IRemoteControlListener* pAddListener);
		virtual bool RemoveRemoteControlListener(IRemoteControlListener* pRemoveListener);

		//! Add/Remove RemoteControl Listener
		virtual bool AddRidgeListener(IRidgeListener* pAddListener);
		virtual bool RemoveRidgeListener(IRidgeListener* pRemoveListener);

		//! Add/Remove ActorListener
		virtual bool AddActorListener(IActorListener *pActorListener);
		virtual bool RemoveActorListener(IActorListener *pActorListener);

		//! Add/Remove cursor Listener
		virtual bool AddCursorStateChangeListener(ICursorListener* pAddListener);
		virtual bool RemoveCursorStateChangeListener(ICursorListener* pRemoveListener);

		//! Add/Remove click Listener
		virtual bool AddClickListener(IClickListener* pAddListener);
		virtual bool RemoveClickListener(IClickListener* pRemoveListener);

		//! Add/Remove custom Listener
		virtual bool AddSemanticEventListener(ISemanticEventListener* pAddListener);
		virtual bool RemoveSemanticEventListener(ISemanticEventListener* pRemoveListener);

		//! Add/Remove Actions
		virtual bool AddAction(IAction* pAction);
		virtual bool RemoveAction(IAction* pAction);

		//! Add/Remove drag Listener
		virtual bool AddDragListener(IDragListener* pAddListener);
		virtual bool RemoveDragListener(IDragListener* pRemoveListener);

		//! Add/Remove gesture Listener
		virtual bool AddGestureListener(IGestureListener* pAddListener);
		virtual bool RemoveGestureListener(IGestureListener* pRemoveListener);

		//! Add/Remove key long press Listener
		virtual bool AddKeyLongPressListener(IKeyLongPressListener* pAddListener);
		virtual bool RemoveKeyLongPressListener(IKeyLongPressListener* pRemoveListener);

		//! Add/Remove key combination Listener
		virtual bool AddKeyCombinationListener(IKeyCombinationListener* pAddListener);
		virtual bool RemoveKeyCombinationListener(IKeyCombinationListener* pRemoveListener);
		
		//! Add/Remove cursor Listener
		virtual bool AddCursorListener(ICursorListener* pAddListener);
		virtual bool RemoveCursorListener(ICursorListener* pRemoveListener);

		virtual const char* GetPropertyName(int animationType, GType *valueType);

		//! Get actor type
		//virtual const char* GetActorType(void);
		virtual bool GetResolutionFlag(void);
		virtual void SetResolutionFlag(bool flag);
	protected:
		float t_1920ConvertMultiResolution(float value) const;
		float t_MultiResolutionConvert1920(float value) const;

	protected:
		virtual bool t_CreateWidget(void);
		virtual void t_FocusUnviewable(bool autoFocus = true);

		virtual bool t_AnimationIsValid(CTransition *animation, int animationType);
		virtual ClutterAnimatable *t_GetAnimatableObject(void);

		void t_OnOrientation(EOrientation orientation);
		virtual void t_UpdateOrientation(EOrientation orientation);

		void t_OnHighContrast(bool flagHighContrast);
		virtual void t_UpdateHighContrast(bool flagHighContrast);

		void t_OnEnlarge(bool flagEnlarge);
		virtual void t_UpdateEnlarge(bool flagEnlarge);

		void t_AddNoticeActor(IWidgetExtension *pNoticeActor);

		virtual void t_OnShow(void) {};
		virtual void t_OnHide(void) {};

		Widget *t_widgetSelf;

		bool  t_flagFocusable;

		void t_NoticeActorFocusIn(CWidgetExtension *actor);

	private:
		static gboolean m_CapturedEventCb(ClutterActor *actor, ClutterEvent *event, CWidgetExtension* pThis);
		static gboolean m_EventCb(ClutterActor *actor, ClutterEvent *event, CWidgetExtension* pThis);
		static gboolean m_KeyFocusInCb(ClutterActor* actor, CWidgetExtension *pThis);
		static gboolean m_KeyFocusOutCb(ClutterActor* actor, CWidgetExtension *pThis);

		static void m_Destroy(ClutterActor* actor, CWidgetExtension *pThis);

		guint m_destroyId;
		guint m_eventId;
		guint m_focusInId;
		guint m_focusOutId;
		guint m_capturedEventId;

		bool m_flagInit;

		EOrientation m_orientation;

		bool m_flagReversible;

		bool m_flagHighContrast;
		bool m_flagEnlarge;

		bool m_flagEnabled;

		bool m_enblePointerFocus;

		CWidgetExtension* m_leftWindowTab;
		CWidgetExtension* m_rightWindowTab;
		CWidgetExtension* m_upWindowTab;
		CWidgetExtension* m_downWindowTab;

		TActionList* m_pActionList;

		CKeyboardListenerSet* m_pKeyboardListenerSet;
		CMouseListenerSet* m_pMouseListenerSet;
		CClickListenerSet* m_pClickListenerSet;
		CFocusListenerSet* m_pFocusListenerSet;
		CSemanticEventListenerSet* m_pSemanticEventListenerSet;
		CDragListenerSet* m_pDragListenerSet;
		CGestureListenerSet* m_pGestureListenerSet;
		CKeyLongPressListenerSet* m_pKeyLongPressListenerSet;
		CKeyCombinationListenerSet* m_pKeyCombinationListenerSet;

		WidgetHelperFocusListener *m_pFocusListener;
		WidgetHelperListenerSet *m_pWidgetHelperListenerSet;

		CCursorListenerSet *m_pCursorListenerSet;
		
		bool m_dragEnabled;
		bool m_flagFirstFocusIn;
		bool m_bEnableCovertResolution;
	private:
		virtual bool m_OnMouse(IMouseEvent* pEvent);
		virtual bool m_OnKeyboard(IKeyboardEvent* pEvent);
		virtual bool m_OnRemocon(const IRemoconEvent* pEvent);
		virtual bool m_OnTouch(const ITouchEvent* pEvent);
		virtual bool m_OnRidge(const IRidgeEvent* pEvent);
		virtual bool m_OnMotion(const IMotionEvent* pEvent);
		virtual bool m_OnSensor(const ISensorEvent* pEvent);
		virtual bool m_OnCursor(const ICursorEvent* pEvent);

		virtual bool m_OnCapturedKeyboard(IKeyboardEvent* pEvent);
		virtual bool m_OnCapturedMouse(IMouseEvent* pEvent);

		bool m_enableMouseEvent(bool flagEnabled, bool enforce = false);
	private:
		float m_origX;
		float m_origY;
		float m_origWidth;
		float m_origHeight;

	friend class WidgetHelperFocusListener;
	friend class CWidgetEx;
	friend class CImageWidgetEx;
	friend class CTextWidgetEx;
	};
}
#endif