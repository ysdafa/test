#include "Halo1_0.h"

namespace HALO
{
	IStage* IStage::m_stage = NULL;

	IStage* IStage::GetInstance(void)
	{
		if (m_stage == NULL)
		{
			m_stage = (IStage*)Instance::CreateInstance(CLASS_ID_ISTAGE);
		}
		return m_stage;
	}
}