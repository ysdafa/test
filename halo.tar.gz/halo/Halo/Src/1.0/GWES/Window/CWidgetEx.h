#ifndef _HALO_WIDGETEX_H_
#define _HALO_WIDGETEX_H_

namespace HALO
{
	class CWidgetEx : public Widget, public CWidgetExtension 
	{
	public:
		CWidgetEx(void);
		CWidgetEx(float x, float y, float width, float height, Widget* aParent);
		virtual ~CWidgetEx(void);

		bool Initialize(ClutterActor* parent, float width, float height); 
		bool Initialize(Widget* parent, float width, float height);
		bool Initialize(IActor* parent, float width, float height);

		//Overload for orientation
		/** X position (pixels)*/
		float getX() const;
		void setX(float x);		
		float getY() const;
		void setY(float y);
		float getWidth() const;
		void setWidth(float width);
		float getHeight() const;
		void setHeight(float height);
		int addChild(Widget* child, int index);
		virtual Widget* getParent() const;
		virtual void setParent(Widget* parent);

		//! Get actor type
		virtual const char* GetActorType(void);

		virtual void GetAnimatableValue(int animationType, UValueElement &val);
		virtual void SetPropertyValue(int animationType, UValueElement element);
	};
}


#endif
