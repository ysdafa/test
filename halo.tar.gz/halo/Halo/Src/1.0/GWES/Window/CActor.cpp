#include "Halo1_0.h"
#include "VoltActor.h"

static HALO::util::Logger LOGGER("CActor");

namespace HALO
{
#define D_LAYOUT_MANAGER_MAP "layout_manager_map"
	//bool CActorListenerSet::Process(TActorListenerData* data)
	//{
	//	bool ret = false;

	//	if (NULL != data)
	//	{
	//		ListenerList::iterator iter = m_list.begin();

	//		while (iter != m_list.end())
	//		{
	//			IActorListener* listener = dynamic_cast<IActorListener*>(*iter);

	//			switch (data->type)
	//			{
	//			case CActor::EVENT_FIRST_FOCUSIN:
	//				H_LOG_DEBUG(LOGGER, "[" << std::hex << m_owner << "]CActor::EVENT_FIRST_FOCUSIN Listener--start");
	//				ret |= listener->OnFirstFocusIn(m_owner);
	//				H_LOG_DEBUG(LOGGER, "CActor::EVENT_FIRST_FOCUSIN Listener--end");
	//				break;
	//			}

	//			iter++;
	//		}
	//	}

	//	return true;
	//}

	//bool CActorFocusListener::OnFocusIn(IWidgetExtension* pWindow)
	//{
	//	m_owner->t_NoticeActorFocusIn(pWindow);
	//	return true;
	//}

	//bool CActorFocusListener::OnFocusOut(IWidgetExtension* pWindow)
	//{
	//	return true;
	//}

	CActor::CActor(void) //:
		//m_orientation(ORIENTATION_REFER_TO_PARENT),
		//m_flagEnabled(true),
		//t_flagFocusable(false),
		//m_enblePointerFocus(false),
		//m_leftWindowTab(NULL),
		//m_rightWindowTab(NULL),
		//m_upWindowTab(NULL),
		//m_downWindowTab(NULL),
		////m_pActionList(NULL),
		//m_pKeyboardListenerSet(NULL),
		//m_pMouseListenerSet(NULL),
		//m_pClickListenerSet(NULL),
		//m_pFocusListenerSet(NULL),
		//m_pSemanticEventListenerSet(NULL),
		//m_pDragListenerSet(NULL),
		//m_pGestureListenerSet(NULL),
		//m_pKeyLongPressListenerSet(NULL),
		//m_pKeyCombinationListenerSet(NULL),
		//m_pFocusListener(NULL),
		//m_pActorListenerSet(NULL),
		//m_dragEnabled(false),
		//m_flagFirstFocusIn(true)
	{
		//H_LOG_TRACE(LOGGER, "[" << this << "]");
	}

	CActor::~CActor(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		//if (NULL != actor)
		//{
			//g_signal_handler_disconnect(actor, m_destroyId);
			//g_signal_handler_disconnect(actor, m_eventId);
			//g_signal_handler_disconnect(actor, m_focusInId);
			//g_signal_handler_disconnect(actor, m_focusOutId);
			//g_signal_handler_disconnect(actor, m_capturedEventId);
		//}

		//t_FocusUnviewable(true);

		//if (m_pKeyboardListenerSet)
		//{
		//	delete m_pKeyboardListenerSet;
		//	m_pKeyboardListenerSet = NULL;
		//}
		//if (m_pMouseListenerSet)
		//{
		//	delete m_pMouseListenerSet;
		//	m_pMouseListenerSet = NULL;
		//}
		//if (m_pClickListenerSet)
		//{
		//	delete m_pClickListenerSet;
		//	m_pClickListenerSet = NULL;
		//}
		//if (m_pFocusListenerSet)
		//{
		//	delete m_pFocusListenerSet;
		//	m_pFocusListenerSet = NULL;
		//}
		//if (m_pSemanticEventListenerSet)
		//{
		//	delete m_pSemanticEventListenerSet;
		//	m_pSemanticEventListenerSet = NULL;
		//}
		//if (m_pActionList)
		//{
		//	delete m_pActionList;
		//	m_pActionList = NULL;
		//}

		//if (m_pDragListenerSet)
		//{
		//	delete m_pDragListenerSet;
		//	m_pDragListenerSet = NULL;
		//}

		//if (m_pGestureListenerSet)
		//{
		//	delete m_pGestureListenerSet;
		//	m_pGestureListenerSet = NULL;
		//}

		//if (m_pKeyLongPressListenerSet)
		//{
		//	delete m_pKeyLongPressListenerSet;
		//	m_pKeyLongPressListenerSet = NULL;
		//}
		//if (m_pKeyCombinationListenerSet)
		//{
		//	delete m_pKeyCombinationListenerSet;
		//	m_pKeyCombinationListenerSet = NULL;
		//}

		//if (NULL != m_pFocusListener)
		//{
		//	delete m_pFocusListener;
		//	m_pFocusListener = NULL;
		//}

		//if (NULL != m_pActorListenerSet)
		//{
		//	delete m_pActorListenerSet;
		//	m_pActorListenerSet = NULL;
		//}
	}

	bool CActor::Initialize(ClutterActor* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] parent:ClutterActor(" << parent << ")");
		bool retVal = Initialize((Widget*)NULL, width, height);

		clutter_actor_add_child(parent, actor);

		return retVal;
	}

	bool CActor::Initialize(Widget* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] parent:Widget(" << parent << ") width(" << width << ") height(" << height << ")");
		actor = t_CreateActor();

		init(0, 0, parent);

		//clutter_actor_set_width(actor, width);
		//clutter_actor_set_height(actor, height);
		setWidth(width);
		setHeight(height);

		CWidgetEx::Initialize(parent, width, height);

		D_SET_HALO_ACTOR(G_OBJECT(actor), this);

		t_actor = actor;

		return true;
	}

	bool CActor::Initialize(IActor* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] parent:IActor(" << parent << ")");
		Widget *w;
		w = dynamic_cast<Widget*>(parent);
		
		return Initialize(w, width, height);
	}

	bool CActor::Initialize(IActor* parent, const TWindowAttr &attr)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] parent:IActor(" << parent << ") width(" << attr.width << ") height(" << attr.height << ")");
		Initialize(parent, attr.width, attr.height);

		SetBackgroundColor(attr.bgColor);

		SetPosition(attr.position.x, attr.position.y, attr.position.z);

		SetAlpha(attr.alpha);
		SetPivotPoint(attr.pivotPoint.x, attr.pivotPoint.y, attr.pivotPoint.z);
		SetRotation(attr.rotationAngle.x, attr.rotationAngle.y, attr.rotationAngle.z);
		SetScale(attr.scaleFactor.x, attr.scaleFactor.y, attr.scaleFactor.z);

		return true;
	}

	void CActor::SetParent(IActor* parent)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] parent(" << parent << ")");
		ASSERT(parent != NULL);

		Widget *w = dynamic_cast<Widget*>(parent);
		if (w)
		{
			setParent(w);
		}
	}

	//bool CActor::IsAncestor(IActor* window)
	//{
	//	bool ret = false;

	//	if (window == NULL)
	//	{
	//		return ret;
	//	}
	//	else
	//	{
	//		Widget* parent = NULL;
	//		Widget* root = NULL;

	//		VoltFullProcessRuntime *runtime = static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

	//		if (runtime)
	//		{
	//			root = dynamic_cast<Widget*>(runtime->GetSceneRoot());
	//		}

	//		if (root == NULL)
	//		{
	//			IStage* stage = IStage::GetInstance();
	//			root = dynamic_cast<Widget*>(stage->RootActor());
	//		}

	//		parent = dynamic_cast<CActor*>(window)->getParent();
	//	
	//		while (parent != root)
	//		{
	//			if (this == parent)
	//			{ 
	//				ret = true;
	//				break;
	//			}
	//			else
	//			{
	//				parent = parent->getParent();
	//			}
	//		}

	//		return ret;
	//	}
	//}

	IActor* CActor::Parent(void) const
	{
		return dynamic_cast<IActor*>(getParent());	
	}

	void CActor::SetBackgroundColor(const ClutterColor &color)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] color(r:" << color.red << ",g:" << color.green << ",b:" <<color.blue <<",a:" << color.alpha << ")");
		setColor(color);
	}

	void CActor::Resize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] width(" << width << ") height(" << height << ")");
		setWidth(width);
		setHeight(height);
	}

	void CActor::GetSize(float &width, float &height)
	{
		width = getWidth();
		height = getHeight();
		H_LOG_TRACE(LOGGER, "[" << this << "] width(" << width << ") height(" << height << ")");
	}

	void CActor::SetPosition(float x, float y, float z)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] x(" << x << ") y(" << y << ") z(" << z << ")");

		setX(x);
		setY(y);
		setDepth(z);
	}

	void CActor::GetPosition(float &x, float &y, float &z)
	{
		x = getX();
		y = getY();
		z = getDepth();
		H_LOG_TRACE(LOGGER, "[" << this << "] x(" << x << ") y(" << y << ") z(" << z << ")");
	}

	void CActor::SetPosition(float x, float y)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] x(" << x << ") y(" << y << ")");

		setX(x);
		setY(y);
	}

	void CActor::GetPosition(float &x, float &y)
	{
		x = getX();
		y = getY();
		H_LOG_TRACE(LOGGER, "[" << this << "] x(" << x << ") y(" << y << ")");
	}

	bool CActor::SetLayout(ILayout* layout)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] layout(" << layout << ")");
		CLayout* cLayout = dynamic_cast<CLayout*>(layout);
		if (cLayout != NULL)
		{
			ClutterLayoutManager *layoutManager = cLayout->GetLayoutManager();
			clutter_actor_set_layout_manager(actor, layoutManager);
			g_object_set_data(G_OBJECT(layoutManager), D_LAYOUT_MANAGER_MAP, cLayout);
			return true;
		}

		return false;
	}

	ILayout* CActor::Layout(void)
	{
		ClutterLayoutManager *layoutManager = clutter_actor_get_layout_manager(actor);
		CLayout *layout = static_cast<CLayout*>(g_object_get_data(G_OBJECT(layoutManager), D_LAYOUT_MANAGER_MAP));

		return layout;
	}

	//void CActor::SetOrientation(EOrientation orientation)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::SetOrientation. orientation:" << orientation);
	//	ASSERT(Parent() != NULL || orientation != ORIENTATION_REFER_TO_PARENT);

	//	if (m_orientation == orientation)
	//	{
	//		return;
	//	}
	//	m_orientation = orientation;

	//	t_UpdateOrientation(Orientation(true));
	//}

	//EOrientation CActor::Orientation(bool flagReferParent)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::Orientation. flagReferParent:" << flagReferParent);
	//	if (flagReferParent && m_orientation == ORIENTATION_REFER_TO_PARENT)
	//	{
	//		CActor* cParent = dynamic_cast<CActor*>(Parent());
	//		if (cParent != NULL)
	//		{
	//			return cParent->Orientation(true);
	//		}
	//		else
	//		{
	//			return ORIENTATION_LEFT_TO_RIGHT;
	//		}
	//	}

	//	return m_orientation;
	//}


	void CActor::Show(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		t_OnShow();
		show();
	}

	void CActor::Hide(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		t_OnHide();
		t_FocusUnviewable(true);

		hide();
	}

	bool CActor::FlagShow(void)
	{
		return CLUTTER_ACTOR_IS_VISIBLE(actor);
	}

	void CActor::EnableClipOverflow(bool enable)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] enable(" << enable << ")");
		setCropOverflow(enable);
	}

	bool CActor::IsClipOverflowEnabled(void)
	{
		return getCropOverflow();
	}

	void CActor::SetClipArea(float x, float y, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] x(" << x << ") y(" << y << ") width(" << width << ") height(" << height << ")");
		x = t_1920ConvertMultiResolution(x);
		y = t_1920ConvertMultiResolution(y);
		width = t_1920ConvertMultiResolution(width);
		height = t_1920ConvertMultiResolution(height);
		clutter_actor_set_clip(actor, x, y, width, height);
	}

	void CActor::GetClipArea(float &x, float &y, float &width, float &height)
	{
		clutter_actor_get_clip(actor, &x, &y, &width, &height);
		x = t_MultiResolutionConvert1920(x);
		y = t_MultiResolutionConvert1920(y);
		width = t_MultiResolutionConvert1920(width);
		height = t_MultiResolutionConvert1920(height);
		H_LOG_TRACE(LOGGER, "[" << this << "] x(" << x << ") y(" << y << ") width(" << width << ") height(" << height << ")");
	}

	void CActor::RemoveClipArea(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		clutter_actor_remove_clip(actor);
	}

	bool CActor::FlagClip(void)
	{
		return (clutter_actor_has_clip(actor) != FALSE);
	}

	void CActor::SetAlpha(int alpha)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] alpha(" << alpha << ")");
		ASSERT(alpha >= 0 && alpha <= 255);

		setOpacity(alpha);
	}

	int CActor::Alpha(void)
	{
		return getOpacity();
	}

	void CActor::SetPivotPoint(float xPivot, float yPivot, float zPivot)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] xPivot(" << xPivot << ") yPivot(" << yPivot << ") zPivot(" <<zPivot << ")");
		setPivot(Vector2(xPivot, yPivot));
	}

	void CActor::GetPivotPoint(float &xPivot, float &yPivot, float &zPivot)
	{
		Vector2 pv = getPivot();
		xPivot = (float)pv.x;
		yPivot = (float)pv.y;
		H_LOG_TRACE(LOGGER, "[" << this << "] xPivot(" << xPivot << ") yPivot(" << yPivot << ") zPivot(" <<zPivot << ")");
	}

	void CActor::SetRotation(double xAngle, double yAngle, double zAngle)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] xAngle(" << xAngle << ") yAngle(" << yAngle << ") zAngle(" << zAngle << ")");
		setRotation(Vector3(xAngle, yAngle, zAngle));
	}

	void CActor::GetRotation(double &xAngle, double &yAngle, double &zAngle)
	{
		Vector3 rv = getRotation();
		xAngle = rv.x;
		yAngle = rv.y;
		zAngle = rv.z;
		H_LOG_TRACE(LOGGER, "[" << this << "] xAngle(" << xAngle << ") yAngle(" << yAngle << ") zAngle(" << zAngle << ")");
	}

	void CActor::SetScale(double xFactor, double yFactor, double zFactor)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] xFactor(" << xFactor << ") yFactor(" << yFactor << ") zFactor(" << zFactor << ")");
		setScale(Vector2(xFactor, yFactor));
	}

	void CActor::GetScale(double &xFactor, double &yFactor, double &zFactor)
	{
		Vector2 sv = getScale();
		xFactor = sv.x;
		yFactor = sv.y;
		H_LOG_TRACE(LOGGER, "[" << this << "] xFactor(" << xFactor << ") yFactor(" << yFactor << ") zFactor(" << zFactor << ")");
	}

	void CActor::AddEffect(IEffect* effect)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] effect(" << effect << ")");
		CEffect* cEffect = dynamic_cast<CEffect*>(effect);
		if (cEffect != NULL)
		{
			clutter_actor_add_effect(actor, cEffect->GetEffect());
		}
	}

	void CActor::RemoveEffect(IEffect* effect)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] effect(" << effect << ")");
		CEffect* cEffect = dynamic_cast<CEffect*>(effect);
		if (cEffect != NULL)
		{
			clutter_actor_remove_effect(actor, cEffect->GetEffect());
		}
	}

	void CActor::ClearEffects(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		clutter_actor_clear_effects(actor);
	}

	void CActor::AddChild(ClutterActor *child)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] child(" << child << ")");
		clutter_actor_remove_child(clutter_actor_get_parent(child), child);
		clutter_actor_add_child(actor, child);
	}

	int  CActor::NumOfChildren(void)
	{
		return getChildCount();
	}

	IActor* CActor::GetChild(int index)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ")");
		return dynamic_cast<IActor*>(getChildByIndex(index));
	}

	void CActor::DestroyAllChildren(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		destroyChildren();
	}

	bool CActor::Raise(IActor* sibling)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] sibling(" << sibling << ")");
		ASSERT(NULL == sibling || sibling->Parent() == Parent());

		clutter_actor_set_child_above_sibling(
			clutter_actor_get_parent(actor),
			actor,
			sibling == NULL ? NULL : sibling->Actor());
		return true;
	}

	bool CActor::Lower(IActor* sibling)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] sibling(" << sibling << ")");
		ASSERT(NULL == sibling || sibling->Parent() == Parent());

		clutter_actor_set_child_below_sibling(
			clutter_actor_get_parent(actor),
			actor,
			sibling == NULL ? NULL : sibling->Actor());
		return true;
	}

	//void CActor::Enable(bool flagEnable)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::Enable. enable:" << flagEnable);
	//	if (flagEnable)
	//	{
	//		m_enableMouseEvent(true);
	//	}
	//	else
	//	{
	//		m_enableMouseEvent(false, true);
	//		if (IsFocused())
	//		{
	//			KillFocus();
	//		}
	//	}
	//	m_flagEnabled = flagEnable;
	//}

	//bool CActor::IsEnabled(void)
	//{
	//	return m_flagEnabled;
	//}

	//void CActor::EnablePointerFocus(bool enable)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::EnablePointerFocus. enable:" << enable);
	//	m_enblePointerFocus = enable;
	//	if (enable)
	//	{
	//		m_enableMouseEvent(true);
	//	}
	//	else
	//	{
	//		m_enableMouseEvent(false);
	//	}
	//}

	//bool CActor::IsPointerFocusEnabled(void)
	//{
	//	return m_enblePointerFocus;
	//}

	//void CActor::EnableFocus(bool flagFocusable)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::EnableFocus. enable:" << flagFocusable);
	//	t_flagFocusable = flagFocusable;
	//}

	//bool CActor::IsFocusEnabled(void)
	//{
	//	return IsEnabled() && t_flagFocusable;
	//}

	//bool CActor::SetFocus(void)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::SetFocus. this:" << this);
	//	if (!IsFocusEnabled())
	//	{
	//		return false;
	//	}

	//	CFocusManager* pFocusManager = CFocusManager::GetInstance();

	//	if (pFocusManager)
	//	{
	//		pFocusManager->ChangeFocusBySet(this);
	//	}

	//	return true;
	//}

	//bool CActor::KillFocus(bool followingRule)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::KillFocus. this:" << this);
	//	CFocusManager* pFocusManager = CFocusManager::GetInstance();

	//	if (pFocusManager)
	//	{
	//		pFocusManager->ChangeFocusByKill(this, followingRule);
	//	}

	//	return true;
	//}

	//bool CActor::IsFocused(void)
	//{
	//	return (clutter_actor_has_key_focus(actor) != FALSE);
	//}

	//void CActor::SetTabWindow(EDirection dir, IActor* tabWindow)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::SetTabWindow. direction:" << dir << "window:" << tabWindow);
	//	switch (dir)
	//	{
	//	case DIRECTION_LEFT:
	//		m_leftWindowTab = dynamic_cast<CActor*>(tabWindow);
	//		break;
	//	case DIRECTION_UP:
	//		m_upWindowTab = dynamic_cast<CActor*>(tabWindow);
	//		break;
	//	case DIRECTION_RIGHT:
	//		m_rightWindowTab = dynamic_cast<CActor*>(tabWindow);
	//		break;
	//	case DIRECTION_DOWN:
	//		m_downWindowTab = dynamic_cast<CActor*>(tabWindow);
	//		break;
	//	default:
	//		break;
	//	}
	//}

	//IActor* CActor::TabWindow(EDirection dir)
	//{
	//	H_LOG_TRACE(LOGGER, "CActor::TabWindow. direction:" << dir);
	//	switch (dir)
	//	{
	//	case DIRECTION_LEFT:
	//		return m_leftWindowTab;
	//	case DIRECTION_UP:
	//		return m_upWindowTab;
	//	case DIRECTION_RIGHT:
	//		return m_rightWindowTab;
	//	case DIRECTION_DOWN:
	//		return m_downWindowTab;
	//	default:
	//		return NULL;
	//	}
	//}


	//bool CActor::MoveTab(EDirection direction)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::MoveTab. direction:" << direction);
	//	CActor* nextTab = this;

	//	do
	//	{
	//		nextTab = dynamic_cast<CActor*>(nextTab->TabWindow(direction));

	//	} while (nextTab != NULL && nextTab->IsFocusEnabled() == false);

	//	if (nextTab == NULL)
	//	{
	//		return false;
	//	}

	//	return nextTab->SetFocus();
	//}

	ClutterActor* CActor::Actor(void)
	{
		return getAnimationActor();
	}

	//! Add Focus Listener
	//bool CActor::AddFocusListener(IFocusListener* pAddListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::AddFocusListener.");
	//	ASSERT(NULL != pAddListener);

	//	bool ret = false;
	//	if (m_pFocusListenerSet == NULL)
	//	{
	//		m_pFocusListenerSet = new CFocusListenerSet(this);
	//		ASSERT(m_pFocusListenerSet);
	//	}
	//	ret = m_pFocusListenerSet->Add(pAddListener);

	//	return ret;
	//}
	////! Remove Focus Listener
	//bool CActor::RemoveFocusListener(IFocusListener* pRemoveListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::RemoveFocusListener.");
	//	ASSERT(NULL != pRemoveListener);

	//	bool ret = false;
	//	if (m_pFocusListenerSet == NULL)
	//	{
	//		return false;
	//	}
	//	ret = m_pFocusListenerSet->Remove(pRemoveListener);
	//	if (m_pFocusListenerSet->Empty())
	//	{
	//		delete m_pFocusListenerSet;
	//		m_pFocusListenerSet = NULL;
	//	}
	//	return ret;
	//}

	ClutterActor* CActor::t_CreateActor(void)
	{
		return volt_actor_new();
	}

	//void CActor::t_FocusUnviewable(bool autoFocus)
	//{
	//	CFocusManager* pFocusManager = CFocusManager::GetInstance();

	//	if (pFocusManager)
	//	{
	//		pFocusManager->ChangeFocusByUnviewable(this, autoFocus);
	//	}
	//}

	//void CActor::t_UpdateOrientation(EOrientation orientation)
	//{
	//	int childCnt = NumOfChildren();
	//	for (size_t i = 0; i < childCnt; i++)
	//	{
	//		CActor* child = dynamic_cast<CActor*>(getChildByIndex(i));
	//		if (child != NULL)
	//		{
	//			if (child->Orientation(false) == ORIENTATION_REFER_TO_PARENT)
	//			{
	//				child->t_UpdateOrientation(orientation);
	//			}
	//		}
	//	}
	//}

	//void CActor::t_AddNoticeActor(IActor *pNoticeActor)
	//{
	//	if (NULL == m_pFocusListener)
	//	{
	//		m_pFocusListener = new CActorFocusListener(this);
	//	}

	//	pNoticeActor->AddFocusListener(m_pFocusListener);
	//}

	//bool CActor::OnEvent(IEvent* pEvent)
	//{
	//	if (m_pActionList)
	//	{
	//		TActionList::iterator itor = m_pActionList->begin();
	//		while (itor != m_pActionList->end())
	//		{
	//			bool actionRet = false;
	//			IAction* pAction = *itor;
	//			if (pAction->IsInterestEvent(pEvent))
	//			{
	//				IEvent* pNewEvent = NULL;
	//				actionRet = pAction->Process(pEvent, &pNewEvent);
	//				if (pNewEvent)
	//				{
	//					OnEvent(pNewEvent);
	//					pNewEvent->Release();
	//					pNewEvent = NULL;
	//				}
	//				if (actionRet)
	//				{
	//					break;
	//				}
	//			}
	//			itor++;
	//		}
	//	}

	//	if (pEvent->IsEventType("samsung.tv.halo.input.keypress") || pEvent->IsEventType("samsung.tv.halo.input.keyrelease"))
	//	{
	//		CKeyboardEvent* evt = dynamic_cast<CKeyboardEvent*>(pEvent);
	//		if (evt)
	//		{
	//			m_OnKeyboard(evt);
	//		}
	//	}
	//	else if (pEvent->IsEventType("samsung.tv.halo.input.mouseenter")
	//		|| pEvent->IsEventType("samsung.tv.halo.input.mouseleave")
	//		|| pEvent->IsEventType("samsung.tv.halo.input.mousemotion")
	//		|| pEvent->IsEventType("samsung.tv.halo.input.mousescroll")
	//		|| pEvent->IsEventType("samsung.tv.halo.input.mousepress")
	//		|| pEvent->IsEventType("samsung.tv.halo.input.mouserelease"))
	//	{
	//		CMouseEvent* evt = dynamic_cast<CMouseEvent*>(pEvent);
	//		if (evt)
	//		{
	//			m_OnMouse(evt);
	//		}
	//	}
	//	else if (pEvent->IsEventType("samsung.tv.halo.input.focus"))
	//	{
	//		if (m_pFocusListenerSet)
	//		{
	//			m_pFocusListenerSet->Process(pEvent);
	//		}

	//		CFocusEvent *focusEvent = dynamic_cast<CFocusEvent*>(pEvent);
	//		if (NULL != focusEvent && EVENT_FOCUSIN == focusEvent->FocusEventType())
	//		{
	//			t_NoticeActorFocusIn(this);
	//		}
	//	}
	//	else if (pEvent->IsEventType("samsung.tv.halo.input.mouseclicked") || pEvent->IsEventType("samsung.tv.halo.input.mouselongpress"))
	//	{
	//		if (m_pClickListenerSet)
	//		{
	//			m_pClickListenerSet->Process(pEvent);
	//		}
	//	}
	//	else if (pEvent->IsEventType("samsung.tv.halo.input.drag"))
	//	{
	//		if (m_pDragListenerSet)
	//		{
	//			m_pDragListenerSet->Process(pEvent);
	//		}
	//	}
	//	else if (pEvent->IsEventType("samsung.tv.halo.input.gesture"))
	//	{
	//		if (m_pGestureListenerSet)
	//		{
	//			m_pGestureListenerSet->Process(pEvent);
	//		}
	//	}
	//	else if (pEvent->IsEventType("samsung.tv.halo.input.keylongpress"))
	//	{
	//		if (m_pKeyLongPressListenerSet)
	//		{
	//			m_pKeyLongPressListenerSet->Process(pEvent);
	//		}
	//	}
	//	else if (pEvent->IsEventType("samsung.tv.halo.input.keycombination"))
	//	{
	//		if (m_pKeyCombinationListenerSet)
	//		{
	//			m_pKeyCombinationListenerSet->Process(pEvent);
	//		}
	//	}
	//	else
	//	{
	//		if (m_pSemanticEventListenerSet)
	//		{
	//			m_pSemanticEventListenerSet->Process(pEvent);
	//		}
	//	}
	//	return true;
	//}

	//!Add/Remove mouse listeners
	//bool CActor::AddMouseListener(IMouseListener* pAddListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::AddMouseListener.");
	//	ASSERT(NULL != pAddListener);

	//	bool ret = false;
	//	if (m_pMouseListenerSet == NULL)
	//	{
	//		m_pMouseListenerSet = new CMouseListenerSet(this);
	//		ASSERT(m_pMouseListenerSet);
	//	}
	//	ret = m_pMouseListenerSet->Add(pAddListener);
	//	if (ret)
	//	{
	//		m_enableMouseEvent(true);
	//	}
	//	return ret;
	//}

	//bool CActor::RemoveMouseListener(IMouseListener* pRemoveListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::RemoveMouseListener.");
	//	ASSERT(NULL != pRemoveListener);

	//	bool ret = false;

	//	if (m_pMouseListenerSet == NULL)
	//	{
	//		return false;
	//	}
	//	ret = m_pMouseListenerSet->Remove(pRemoveListener);
	//	if (m_pMouseListenerSet->Empty())
	//	{
	//		delete m_pMouseListenerSet;
	//		m_pMouseListenerSet = NULL;

	//		m_enableMouseEvent(false);
	//	}
	//	return ret;
	//}

	//! Add/Remove Touch Listener
	//bool CActor::AddTouchListener(ITouchListener* pAddListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::AddTouchListener.");
	//	ASSERT(NULL != pAddListener);

	//	return true;
	//}

	//bool CActor::RemoveTouchListener(ITouchListener* pRemoveListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::RemoveTouchListener.");
	//	ASSERT(NULL != pRemoveListener);

	//	return true;
	//}

	////! Add/Remove Keyboard Listener
	//bool CActor::AddKeyboardListener(IKeyboardListener* pAddListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::AddKeyboardListener.");
	//	ASSERT(NULL != pAddListener);

	//	if (m_pKeyboardListenerSet == NULL)
	//	{
	//		m_pKeyboardListenerSet = new CKeyboardListenerSet(this);
	//		ASSERT(m_pKeyboardListenerSet);
	//	}
	//	return m_pKeyboardListenerSet->Add(pAddListener);
	//}

	//bool CActor::RemoveKeyboardListener(IKeyboardListener* pRemoveListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::RemoveKeyboardListener.");
	//	ASSERT(NULL != pRemoveListener);

	//	bool ret = false;
	//	if (m_pKeyboardListenerSet == NULL)
	//	{
	//		return false;
	//	}
	//	ret = m_pKeyboardListenerSet->Remove(pRemoveListener);
	//	if (m_pKeyboardListenerSet->Empty())
	//	{
	//		delete m_pKeyboardListenerSet;
	//		m_pKeyboardListenerSet = NULL;
	//	}
	//	return ret;
	//}

	////! Add/Remove Audio Listener
	//bool CActor::AddAudioListener(IAudioListener* pAddListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::AddAudioListener.");
	//	ASSERT(NULL != pAddListener);

	//	return true;
	//}

	//bool CActor::RemoveAudioListener(IAudioListener* pRemoveListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::RemoveAudioListener.");
	//	ASSERT(NULL != pRemoveListener);

	//	return true;
	//}

	////! Add/Remove RemoteControl Listener
	//bool CActor::AddRemoteControlListener(IRemoteControlListener* pAddListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::AddRemoteControlListener.");
	//	ASSERT(NULL != pAddListener);

	//	return true;
	//}

	//bool CActor::RemoveRemoteControlListener(IRemoteControlListener* pRemoveListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::RemoveRemoteControlListener.");
	//	ASSERT(NULL != pRemoveListener);

	//	return true;
	//}

	////! Add/Remove RemoteControl Listener
	//bool CActor::AddRidgeListener(IRidgeListener* pAddListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::AddRidgeListener.");
	//	ASSERT(NULL != pAddListener);

	//	return true;
	//}

	//bool CActor::RemoveRidgeListener(IRidgeListener* pRemoveListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::RemoveRidgeListener.");
	//	ASSERT(NULL != pRemoveListener);

	//	return true;
	//}

	//bool CActor::AddActorListener(IActorListener *pActorListener)
	//{
	//	H_LOG_TRACE(LOGGER, "[" << std::hex<< this <<"]CActor::AddActorListener");
	//	ASSERT(pActorListener != NULL);

	//	if (NULL == m_pActorListenerSet)
	//	{
	//		m_pActorListenerSet = new CActorListenerSet(this);
	//		ASSERT(NULL != m_pActorListenerSet);
	//	}

	//	m_pActorListenerSet->Add(pActorListener);
	//	return true;
	//}

	//bool CActor::RemoveActorListener(IActorListener *pActorListener)
	//{
	//	H_LOG_TRACE(LOGGER, "[" << std::hex<< this <<"]CActor::RemoveActorListener");
	//	ASSERT(pActorListener != NULL);
	//	ASSERT(NULL != m_pActorListenerSet);

	//	m_pActorListenerSet->Remove(pActorListener);

	//	return true;
	//}

	////! Add/Remove cursor Listener
	//bool CActor::AddCursorStateChangeListener(ICursorListener* pAddListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::AddCursorStateChangeListener.");
	//	ASSERT(NULL != pAddListener);

	//	return true;
	//}

	//bool CActor::RemoveCursorStateChangeListener(ICursorListener* pRemoveListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::RemoveCursorStateChangeListener.");
	//	ASSERT(NULL != pRemoveListener);

	//	return true;
	//}

	////! Add click Listener
	//bool CActor::AddClickListener(IClickListener* pAddListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::AddClickListener.");
	//	ASSERT(NULL != pAddListener);

	//	bool ret = false;
	//	if (m_pClickListenerSet == NULL)
	//	{
	//		m_pClickListenerSet = new CClickListenerSet(this);
	//		ASSERT(m_pClickListenerSet);
	//	}
	//	ret = m_pClickListenerSet->Add(pAddListener);
	//	if (ret)
	//	{
	//		m_enableMouseEvent(true);
	//	}

	//	return ret;
	//}

	////! Remove click listener
	//bool CActor::RemoveClickListener(IClickListener* pRemoveListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::RemoveClickListener.");
	//	ASSERT(NULL != pRemoveListener);

	//	bool ret = false;
	//	if (m_pClickListenerSet == NULL)
	//	{
	//		return false;
	//	}
	//	ret = m_pClickListenerSet->Remove(pRemoveListener);
	//	if (m_pClickListenerSet->Empty())
	//	{
	//		delete m_pClickListenerSet;
	//		m_pClickListenerSet = NULL;

	//		m_enableMouseEvent(false);
	//	}
	//	return ret;
	//}

	////! Add custom Listener
	//bool CActor::AddSemanticEventListener(ISemanticEventListener* pAddListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::AddSemanticEventListener.");
	//	ASSERT(NULL != pAddListener);

	//	bool ret = false;
	//	if (m_pSemanticEventListenerSet == NULL)
	//	{
	//		m_pSemanticEventListenerSet = new CSemanticEventListenerSet(this);
	//		ASSERT(m_pClickListenerSet);
	//	}
	//	ret = m_pSemanticEventListenerSet->Add(pAddListener);
	//	return ret;
	//}

	////! Remove custom Listener
	//bool CActor::RemoveSemanticEventListener(ISemanticEventListener* pRemoveListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::RemoveSemanticEventListener.");
	//	ASSERT(NULL != pRemoveListener);

	//	bool ret = false;
	//	if (m_pSemanticEventListenerSet == NULL)
	//	{
	//		return false;
	//	}
	//	ret = m_pSemanticEventListenerSet->Remove(pRemoveListener);
	//	return ret;
	//}

	//bool CActor::AddAction(IAction* pAction)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::AddAction. action:" << pAction);
	//	ASSERT(NULL != pAction);

	//	if (!m_pActionList)
	//	{
	//		m_pActionList = new TActionList;
	//	}
	//	m_pActionList->push_back(pAction);
	//	ClutterAction *ca = pAction->Action();
	//	if (ca)
	//	{
	//		if (dynamic_cast<IDragAction*>(pAction) != NULL)
	//		{
	//			ASSERT(!m_dragEnabled);
	//			m_dragEnabled = true;
	//			m_enableMouseEvent(true);
	//		}

	//		clutter_actor_add_action(Actor(), ca);
	//	}
	//	
	//	return true;
	//}
	//bool CActor::RemoveAction(IAction* pAction)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::RemoveAction. action:" << pAction);
	//	ASSERT(NULL != pAction);

	//	if (!m_pActionList)
	//	{
	//		return false;
	//	}
	//	TActionList::iterator itor = m_pActionList->begin();
	//	while (itor != m_pActionList->end())
	//	{
	//		if (*itor == pAction)
	//		{
	//			m_pActionList->erase(itor);
	//			ClutterAction *ca = pAction->Action();
	//			if (ca)
	//			{
	//				clutter_actor_remove_action(Actor(), ca);

	//				if (dynamic_cast<IDragAction*>(pAction) != NULL)
	//				{
	//					m_dragEnabled = false;
	//					m_enableMouseEvent(false);
	//				}
	//			}
	//			return true;
	//		}
	//		itor++;
	//	}
	//	return false;
	//}

	//IActor::TActionList* CActor::GetActionList(void)
	//{
	//	return m_pActionList;
	//}

	//! Add drag listener
	//bool CActor::AddDragListener(IDragListener* pAddListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::AddDragListener.");
	//	ASSERT(NULL != pAddListener);

	//	bool ret = false;
	//	if (m_pDragListenerSet == NULL)
	//	{
	//		m_pDragListenerSet = new CDragListenerSet(this);
	//		ASSERT(m_pDragListenerSet);
	//	}
	//	ret = m_pDragListenerSet->Add(pAddListener);
	//	if (ret)
	//	{
	//		m_enableMouseEvent(true);
	//	}
	//	return ret;
	//}

	//bool CActor::RemoveDragListener(IDragListener* pRemoveListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::RemoveDragListener.");
	//	ASSERT(NULL != pRemoveListener);

	//	bool ret = false;
	//	if (m_pDragListenerSet == NULL)
	//	{
	//		return false;
	//	}
	//	ret = m_pDragListenerSet->Remove(pRemoveListener);
	//	if (m_pDragListenerSet->Empty())
	//	{
	//		delete m_pDragListenerSet;
	//		m_pDragListenerSet = NULL;

	//		m_enableMouseEvent(false);
	//	}
	//	return ret;
	//}

	////! Add gesture listener
	//bool CActor::AddGestureListener(IGestureListener* pAddListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::AddGestureListener.");
	//	ASSERT(NULL != pAddListener);

	//	bool ret = false;
	//	if (m_pGestureListenerSet == NULL)
	//	{
	//		m_pGestureListenerSet = new CGestureListenerSet(this);
	//		ASSERT(m_pGestureListenerSet);
	//	}
	//	ret = m_pGestureListenerSet->Add(pAddListener);
	//	return ret;
	//}

	//bool CActor::RemoveGestureListener(IGestureListener* pRemoveListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::RemoveGestureListener.");
	//	ASSERT(NULL != pRemoveListener);

	//	bool ret = false;
	//	if (m_pGestureListenerSet == NULL)
	//	{
	//		return false;
	//	}
	//	ret = m_pGestureListenerSet->Remove(pRemoveListener);
	//	if (m_pGestureListenerSet->Empty())
	//	{
	//		delete m_pGestureListenerSet;
	//		m_pGestureListenerSet = NULL;

	//		m_enableMouseEvent(true);
	//	}
	//	return ret;
	//}

	////! Add key long press listener
	//bool CActor::AddKeyLongPressListener(IKeyLongPressListener* pAddListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::AddKeyLongPressListener.");
	//	ASSERT(NULL != pAddListener);

	//	bool ret = false;
	//	if (m_pKeyLongPressListenerSet == NULL)
	//	{
	//		m_pKeyLongPressListenerSet = new CKeyLongPressListenerSet(this);
	//		ASSERT(m_pKeyLongPressListenerSet);
	//	}
	//	ret = m_pKeyLongPressListenerSet->Add(pAddListener);
	//	return ret;
	//}

	//bool CActor::RemoveKeyLongPressListener(IKeyLongPressListener* pRemoveListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::RemoveKeyLongPressListener.");
	//	ASSERT(NULL != pRemoveListener);

	//	bool ret = false;
	//	if (m_pKeyLongPressListenerSet == NULL)
	//	{
	//		return false;
	//	}
	//	ret = m_pKeyLongPressListenerSet->Remove(pRemoveListener);
	//	if (m_pKeyLongPressListenerSet->Empty())
	//	{
	//		delete m_pKeyLongPressListenerSet;
	//		m_pKeyLongPressListenerSet = NULL;
	//	}
	//	return ret;
	//}

	//bool CActor::AddKeyCombinationListener(IKeyCombinationListener* pAddListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::AddKeyCombinationListener.");
	//	ASSERT(NULL != pAddListener);

	//	bool ret = false;
	//	if (m_pKeyCombinationListenerSet == NULL)
	//	{
	//		m_pKeyCombinationListenerSet = new CKeyCombinationListenerSet(this);
	//		ASSERT(m_pKeyCombinationListenerSet);
	//	}
	//	ret = m_pKeyCombinationListenerSet->Add(pAddListener);
	//	return ret;
	//}

	//bool CActor::RemoveKeyCombinationListener(IKeyCombinationListener* pRemoveListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::RemoveKeyCombinationListener.");
	//	ASSERT(NULL != pRemoveListener);

	//	bool ret = false;
	//	if (m_pKeyCombinationListenerSet == NULL)
	//	{
	//		return false;
	//	}
	//	ret = m_pKeyCombinationListenerSet->Remove(pRemoveListener);
	//	if (m_pKeyCombinationListenerSet->Empty())
	//	{
	//		delete m_pKeyCombinationListenerSet;
	//		m_pKeyCombinationListenerSet = NULL;
	//	}
	//	return ret;
	//}

	//! Add/Remove cursor Listener
	//bool CActor::AddCursorListener(ICursorListener* pAddListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::AddCursorListener.");
	//	ASSERT(NULL != pAddListener);

	//	if (m_pCursorListenerSet == NULL)
	//	{
	//		m_pCursorListenerSet = new CCursorListenerSet(this);
	//		ASSERT(m_pCursorListenerSet);
	//	}
	//	return m_pCursorListenerSet->Add(pAddListener);
	//}

	//bool CActor::RemoveCursorListener(ICursorListener* pRemoveListener)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::RemoveCursorListener.");
	//	ASSERT(NULL != pRemoveListener);

	//	bool ret = false;
	//	if (m_pCursorListenerSet == NULL)
	//	{
	//		return false;
	//	}
	//	ret = m_pCursorListenerSet->Remove(pRemoveListener);
	//	if (m_pCursorListenerSet->Empty())
	//	{
	//		delete m_pCursorListenerSet;
	//		m_pCursorListenerSet = NULL;
	//	}
	//	return ret;
	//}
	
	////! Grab event
	//void CActor::GrabDeviceEvent(IDevice *device)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::GrabDeviceEvent.");
	//	ASSERT(NULL != device);

	//	int id = device->DeviceId();
	//	ClutterDeviceManager *manager = clutter_device_manager_get_default();

	//	ClutterInputDevice *clutterDivice = clutter_device_manager_get_device(manager, id);

	//	clutter_input_device_grab(clutterDivice, actor);

	//}

	//void CActor::UnGrabDeviceEvent(IDevice *device)
	//{
	//	H_LOG_DEBUG(LOGGER, "CActor::UnGrabDeviceEvent.");
	//	ASSERT(NULL != device);

	//	int id = device->DeviceId();
	//	ClutterDeviceManager *manager = clutter_device_manager_get_default();
	//	ClutterInputDevice *clutterDivice = clutter_device_manager_get_device(manager, id);

	//	clutter_input_device_ungrab(clutterDivice);
	//}

	const char* CActor::GetActorType(void)
	{
		return "Actor";
	}

	void CActor::m_Destroy(ClutterActor* actor, CActor *pThis)
	{
		delete pThis;
	}

	//gboolean CActor::m_CapturedEventCb(ClutterActor* actor, ClutterEvent* event, CActor* pThis)
	//{
	//	switch (event->type)
	//	{
	//	case CLUTTER_KEY_PRESS:
	//	case CLUTTER_KEY_RELEASE:
	//	{
	//		CKeyboardEvent evt(event);
	//		pThis->m_OnCapturedKeyboard(&evt);
	//	}
	//		break;
	//	case CLUTTER_ENTER:
	//	case CLUTTER_LEAVE:
	//	case CLUTTER_MOTION:
	//	case CLUTTER_SCROLL:
	//	case CLUTTER_BUTTON_PRESS:
	//	case CLUTTER_BUTTON_RELEASE:
	//	{
	//		CMouseEvent evt(event);
	//		pThis->m_OnCapturedMouse(&evt);
	//	}
	//		break;
	//	default:
	//		break;
	//	}

	//	return CLUTTER_EVENT_PROPAGATE;
	//}

	//gboolean CActor::m_EventCb(ClutterActor* actor, ClutterEvent* event, CActor* pThis)
	//{
	//	switch (event->type)
	//	{
	//	case CLUTTER_KEY_PRESS:
	//	case CLUTTER_KEY_RELEASE:
	//	{
	//		CKeyboardEvent evt(event);
	//		pThis->OnEvent(&evt);
	//	}
	//		break;
	//	case CLUTTER_ENTER:
	//	case CLUTTER_LEAVE:
	//	case CLUTTER_MOTION:
	//	case CLUTTER_SCROLL:
	//	case CLUTTER_BUTTON_PRESS:
	//	case CLUTTER_BUTTON_RELEASE:
	//	{
	//		CMouseEvent evt(event);
	//		pThis->OnEvent(&evt);
	//	}
	//		break;
	//	default:
	//		break;
	//	}

	//	return CLUTTER_EVENT_PROPAGATE;
	//}

	//gboolean CActor::m_KeyFocusInCb(ClutterActor* actor, CActor *pThis)
	//{
	//	CFocusManager* pFocusManager = CFocusManager::GetInstance();

	//	if (pFocusManager)
	//	{
	//		if (pFocusManager->FocusedWindow() != pThis)
	//		{
	//			pFocusManager->SetFocusBySignal(pThis);
	//		}
	//	}

	//	return CLUTTER_EVENT_PROPAGATE;
	//}

	//gboolean CActor::m_KeyFocusOutCb(ClutterActor* actor, CActor *pThis)
	//{
	//	CFocusManager* pFocusManager = CFocusManager::GetInstance();

	//	if (pFocusManager)
	//	{
	//		if (pFocusManager->FocusedWindow() == pThis)
	//		{
	//			pFocusManager->KillFocusBySignal(pThis);
	//		}
	//	}

	//	return CLUTTER_EVENT_PROPAGATE;
	//}

	//bool CActor::m_OnMouse(IMouseEvent* pEvent)
	//{
	//	if (m_pMouseListenerSet)
	//	{
	//		return m_pMouseListenerSet->Process(pEvent, E_HALO_EVENT_ROUTINE_BUBBLE);
	//	}
	//	return false;
	//}

	//bool CActor::m_OnKeyboard(IKeyboardEvent* pEvent)
	//{
	//	if (m_pKeyboardListenerSet)
	//	{
	//		m_pKeyboardListenerSet->Process(pEvent, E_HALO_EVENT_ROUTINE_BUBBLE);
	//	}
	//	if (IsFocused()&& pEvent->IsEventType("samsung.tv.halo.input.keyrelease"))
	//	{
	//		switch (pEvent->GetKeyVal())
	//		{
	//		case CLUTTER_KEY_Left:
	//			MoveTab(DIRECTION_LEFT);
	//			break;
	//		case CLUTTER_KEY_Right:
	//			MoveTab(DIRECTION_RIGHT);
	//			break;
	//		case CLUTTER_KEY_Up:
	//			MoveTab(DIRECTION_UP);
	//			break;
	//		case CLUTTER_KEY_Down:
	//			MoveTab(DIRECTION_DOWN);
	//			break;
	//		default:
	//			break;
	//		}
	//	}
	//	return false;
	//}

	//bool CActor::m_OnRemocon(const IRemoconEvent* pEvent)
	//{
	//	return false;
	//}

	//bool CActor::m_OnTouch(const ITouchEvent* pEvent)
	//{
	//	return false;
	//}

	//bool CActor::m_OnRidge(const IRidgeEvent* pEvent)
	//{
	//	return false;
	//}

	//bool CActor::m_OnMotion(const IMotionEvent* pEvent)
	//{
	//	return false;
	//}

	//bool CActor::m_OnSensor(const ISensorEvent* pEvent)
	//{
	//	return false;
	//}

	//bool CActor::m_OnCursor(const ICursorEvent* pEvent)
	//{
	//	return false;
	//}

	////! Process captured keyboard event
	//bool CActor::m_OnCapturedKeyboard(IKeyboardEvent* pEvent)
	//{
	//	if (m_pKeyboardListenerSet)
	//	{
	//		return m_pKeyboardListenerSet->Process(pEvent, E_HALO_EVENT_ROUTINE_CAPTURED);
	//	}

	//	return false;
	//}

	////add
	//bool CActor::m_OnCapturedMouse(IMouseEvent* pEvent)
	//{
	//	if (m_pMouseListenerSet)
	//	{
	//		return m_pMouseListenerSet->Process(pEvent, E_HALO_EVENT_ROUTINE_CAPTURED);
	//	}

	//	return false;
	//}

	//bool CActor::m_enableMouseEvent(bool flagEnabled, bool enforce)
	//{
	//	if (flagEnabled)
	//	{
	//		if (enforce || m_pMouseListenerSet || m_pClickListenerSet || m_pDragListenerSet || m_pGestureListenerSet || m_enblePointerFocus || m_dragEnabled)
	//		{
	//			clutter_actor_set_reactive(actor, true);
	//			return true;
	//		}
	//	}
	//	else
	//	{
	//		if (enforce || (m_pMouseListenerSet == NULL && m_pClickListenerSet == NULL && m_pDragListenerSet == NULL && m_pGestureListenerSet == NULL && m_enblePointerFocus == false && m_dragEnabled == false))
	//		{
	//			clutter_actor_set_reactive(actor, false);
	//			return true;
	//		}
	//	}

	//	return false;
	//}

	//void CActor::t_NoticeActorFocusIn(IActor *actor)
	//{
	//	if (true == m_flagFirstFocusIn)
	//	{
	//		CActorListenerSet::TActorListenerData data;
	//		data.type = EVENT_FIRST_FOCUSIN;

	//		if (NULL != m_pActorListenerSet)
	//		{
	//			m_pActorListenerSet->Process(&data);
	//		}
	//	}

	//	m_flagFirstFocusIn = false;
	//}
}


