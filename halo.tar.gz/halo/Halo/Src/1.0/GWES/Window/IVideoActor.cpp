#if !defined(WIN32) && !defined(LINUX_BUILD)

#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	IVideoActor* IVideoActor::CreateInstance(IActor* parent, float width, float height, ClutterVideoController type)
	{
		CVideoActor* videoActor = dynamic_cast<CVideoActor*>(Instance::CreateInstance(CLASS_ID_IVIDEOACTOR));
		if (NULL != videoActor)
		{
			videoActor->Initialize(parent, width, height, type);
		}
		return videoActor;
	}

	IVideoActor* IVideoActor::CreateInstance(Widget* parent, float width, float height, ClutterVideoController type)
	{
		CVideoActor* videoActor = dynamic_cast<CVideoActor*>(Instance::CreateInstance(CLASS_ID_IVIDEOACTOR));

		if (NULL != videoActor)
		{
			videoActor->Initialize(parent, width, height, type);
		}
		return videoActor;
	}

	
}

#endif // !WIN32
