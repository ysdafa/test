#include "Halo1_0.h"
//#include "VoltActor.h"

static HALO::util::Logger LOGGER("WidgetExtension");

namespace HALO
{
	bool WidgetHelperListenerSet::Process(TActorListenerData* data)
	{
		Lock();
		bool ret = false;

		if (NULL != data)
		{
			ListenerList::iterator iter = m_list.begin();

			while (iter != m_list.end())
			{
				IActorListener* listener = dynamic_cast<IActorListener*>(*iter);

				if (listener)
				{
					switch (data->type)
					{
					case CWidgetExtension::EVENT_FIRST_FOCUSIN:
						H_LOG_DEBUG(LOGGER, "[" << std::hex << m_owner << "]WidgetExtension::EVENT_FIRST_FOCUSIN Listener--start");
						ret |= listener->OnFirstFocusIn(m_owner);
						H_LOG_DEBUG(LOGGER, "WidgetExtension::EVENT_FIRST_FOCUSIN Listener--end");
						break;
					case CWidgetExtension::EVENT_HIGHCONTRAST_CHANGED:
						H_LOG_DEBUG(LOGGER, "[" << m_owner << "] WidgetExtension::EVENT_HIGHCONTRAST_CHANGED Listener--start flagHighContrast:" << data->param[0]);
						ret |= listener->OnHighContrastChanged(m_owner, (data->param[0] != 0));
						H_LOG_DEBUG(LOGGER, "WidgetExtension::EVENT_HIGHCONTRAST_CHANGED Listener--end");
						break;
					case CWidgetExtension::EVENT_ENLARGE_CHANGED:
						H_LOG_DEBUG(LOGGER, "[" << m_owner << "] WidgetExtension::EVENT_ENLARGE_CHANGED Listener--start flagEnlarge:" << data->param[0]);
						ret |= listener->OnEnlargeChanged(m_owner, (data->param[0] != 0));
						H_LOG_DEBUG(LOGGER, "WidgetExtension::EVENT_ENLARGE_CHANGED Listener--end");
						break;
					default:
						break;
					}
				}

				iter++;
			}
		}

		Unlock();
		return true;
	}

	bool WidgetHelperFocusListener::OnFocusIn(IWidgetExtension* pWindow)
	{
		m_owner->t_NoticeActorFocusIn(dynamic_cast<CWidgetExtension*>(pWindow));
		return true;
	}

	bool WidgetHelperFocusListener::OnFocusOut(IWidgetExtension* pWindow)
	{
		return true;
	}

	CWidgetExtension::CWidgetExtension(void) :
		t_widgetSelf(NULL),
		t_flagFocusable(false),
		m_destroyId(0),
		m_eventId(0),
		m_focusInId(0),
		m_focusOutId(0),
		m_capturedEventId(0),
		m_flagInit(false),
		m_orientation(ORIENTATION_REFER_TO_PARENT),
		m_flagReversible(true),
		m_flagHighContrast(false),
		m_flagEnlarge(false),
		m_flagEnabled(true),
		m_enblePointerFocus(false),
		m_leftWindowTab(NULL),
		m_rightWindowTab(NULL),
		m_upWindowTab(NULL),
		m_downWindowTab(NULL),
		m_pActionList(NULL),
		m_pKeyboardListenerSet(NULL),
		m_pMouseListenerSet(NULL),
		m_pClickListenerSet(NULL),
		m_pFocusListenerSet(NULL),
		m_pSemanticEventListenerSet(NULL),
		m_pDragListenerSet(NULL),
		m_pGestureListenerSet(NULL),
		m_pKeyLongPressListenerSet(NULL),
		m_pKeyCombinationListenerSet(NULL),
		m_pFocusListener(NULL),
		m_pWidgetHelperListenerSet(NULL),
		m_pCursorListenerSet(NULL),
		m_dragEnabled(false),
		m_flagFirstFocusIn(true),
		m_bEnableCovertResolution(true),
		m_origX(FLT_MAX), 
		m_origY(FLT_MAX), 
		m_origWidth(FLT_MAX), 
		m_origHeight(FLT_MAX)
	{
		//H_LOG_TRACE(LOGGER, "WidgetExtension::WidgetExtension()");
	}

	CWidgetExtension::~CWidgetExtension(void)
	{
		//H_LOG_TRACE(LOGGER, "WidgetExtension::~WidgetExtension()");
		/*if (NULL != t_widgetSelf && t_widgetSelf->getAnimationActor())
		{
			g_signal_handler_disconnect(t_widgetSelf->getAnimationActor(), m_eventId);
			g_signal_handler_disconnect(t_widgetSelf->getAnimationActor(), m_focusInId);
			g_signal_handler_disconnect(t_widgetSelf->getAnimationActor(), m_focusOutId);
			g_signal_handler_disconnect(t_widgetSelf->getAnimationActor(), m_capturedEventId);
		}*/

		t_FocusUnviewable(true);

		if (m_pKeyboardListenerSet)
		{
			//delete m_pKeyboardListenerSet;
			if (m_pKeyboardListenerSet->IsLocked())
			{
				m_pKeyboardListenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(m_pKeyboardListenerSet);
			} 
			else
			{
				delete m_pKeyboardListenerSet;
			}

			m_pKeyboardListenerSet = NULL;
		}
		if (m_pMouseListenerSet)
		{
			//delete m_pMouseListenerSet;
			if (m_pMouseListenerSet->IsLocked())
			{
				m_pMouseListenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(m_pMouseListenerSet);
			} 
			else
			{
				delete m_pMouseListenerSet;
			}

			m_pMouseListenerSet = NULL;
		}
		if (m_pClickListenerSet)
		{
			//delete m_pClickListenerSet;
			if (m_pClickListenerSet->IsLocked())
			{
				m_pClickListenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(m_pClickListenerSet);
			} 
			else
			{
				delete m_pClickListenerSet;
			}

			m_pClickListenerSet = NULL;
		}
		if (m_pFocusListenerSet)
		{
			//delete m_pFocusListenerSet;
			if (m_pFocusListenerSet->IsLocked())
			{
				m_pFocusListenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(m_pFocusListenerSet);
			} 
			else
			{
				delete m_pFocusListenerSet;
			}

			m_pFocusListenerSet = NULL;
		}
		if (m_pSemanticEventListenerSet)
		{
			//delete m_pSemanticEventListenerSet;
			if (m_pSemanticEventListenerSet->IsLocked())
			{
				m_pSemanticEventListenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(m_pSemanticEventListenerSet);
			} 
			else
			{
				delete m_pSemanticEventListenerSet;
			}

			m_pSemanticEventListenerSet = NULL;
		}
		if (m_pActionList)
		{
			delete m_pActionList;
			m_pActionList = NULL;
		}

		if (m_pDragListenerSet)
		{
			//delete m_pDragListenerSet;
			if (m_pDragListenerSet->IsLocked())
			{
				m_pDragListenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(m_pDragListenerSet);
			} 
			else
			{
				delete m_pDragListenerSet;
			}

			m_pDragListenerSet = NULL;
		}

		if (m_pGestureListenerSet)
		{
			//delete m_pGestureListenerSet;
			if (m_pGestureListenerSet->IsLocked())
			{
				m_pGestureListenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(m_pGestureListenerSet);
			} 
			else
			{
				delete m_pGestureListenerSet;
			}

			m_pGestureListenerSet = NULL;
		}

		if (m_pKeyLongPressListenerSet)
		{
			//delete m_pKeyLongPressListenerSet;
			if (m_pKeyLongPressListenerSet->IsLocked())
			{
				m_pKeyLongPressListenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(m_pKeyLongPressListenerSet);
			} 
			else
			{
				delete m_pKeyLongPressListenerSet;
			}

			m_pKeyLongPressListenerSet = NULL;
		}
		if (m_pKeyCombinationListenerSet)
		{
			//delete m_pKeyCombinationListenerSet;
			if (m_pKeyCombinationListenerSet->IsLocked())
			{
				m_pKeyCombinationListenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(m_pKeyCombinationListenerSet);
			} 
			else
			{
				delete m_pKeyCombinationListenerSet;
			}

			m_pKeyCombinationListenerSet = NULL;
		}

		if (NULL != m_pFocusListener)
		{
			delete m_pFocusListener;
			m_pFocusListener = NULL;
		}

		if (NULL != m_pWidgetHelperListenerSet)
		{
			//delete m_pWidgetHelperListenerSet;
			if (m_pWidgetHelperListenerSet->IsLocked())
			{
				m_pWidgetHelperListenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(m_pWidgetHelperListenerSet);
			} 
			else
			{
				delete m_pWidgetHelperListenerSet;
			}

			m_pWidgetHelperListenerSet = NULL;
		}
		if (NULL != m_pCursorListenerSet)
		{
			//delete m_pCursorListenerSet;
			if (m_pCursorListenerSet->IsLocked())
			{
				m_pCursorListenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(m_pCursorListenerSet);
			} 
			else
			{
				delete m_pCursorListenerSet;
			}

			m_pCursorListenerSet = NULL;
		}

		t_widgetSelf = NULL;

		if (IEventManager::GetInstance())
		{
			IEventManager::GetInstance()->RemoveFocusTarget((IWidgetExtension*)this);
		}
	}

	bool CWidgetExtension::IsAncestor(IWidgetExtension* window)
	{
		HALO_ASSERT(m_flagInit);
		bool ret = false;

		if (window == NULL)
		{
			return ret;
		}
		else
		{
			Widget* parent = NULL;
			Widget* root = NULL;
			CWidgetExtension* current = dynamic_cast<CWidgetExtension*>(window);
			if (current == NULL)
			{
				return false;
			}

			VoltFullProcessRuntime *runtime = static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

			if (runtime)
			{
				root = dynamic_cast<Widget*>(runtime->GetSceneRoot());
			}

			if (root == NULL)
			{
				IStage* stage = IStage::GetInstance();
				root = dynamic_cast<Widget*>(stage->RootActor());
			}

			//parent = dynamic_cast<WidgetExtension*>(window)->getParent();

			parent = current->t_widgetSelf->getParent();

			while (parent != root)
			{
				if (NULL == parent)
				{
					return false;
				}

				if (this->t_widgetSelf == parent)
				{ 
					ret = true;
					break;
				}
				else
				{
					parent = parent->getParent();
				}
			}

			return ret;
		}
	}

	IWidgetExtension* CWidgetExtension::ParentWidgetExtension(void) const
	{
		if (!t_widgetSelf)
		{
			return NULL;
		}
		Widget* parent = t_widgetSelf->getParent();
		if (parent && parent->getAnimationActor())
		{
			return dynamic_cast<IWidgetExtension*>(D_GET_HALO_WIDGET_EXTENSION(G_OBJECT(parent->getAnimationActor())));
		}
		return NULL;
	}

	void CWidgetExtension::UpdateOrientation(EOrientation orientation)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::UpdateOrientation. orientation:" << (orientation == ORIENTATION_RIGHT_TO_LEFT? "right-to-left":"left-to-right"));
		HALO_ASSERT(orientation != ORIENTATION_REFER_TO_PARENT);

		if (m_orientation != ORIENTATION_REFER_TO_PARENT)
		{
			return;
		}

		//update its position related to parent
		if (t_widgetSelf && IsReversible() == true)
		{
			Widget* parent = t_widgetSelf->getParent();
			if (parent)
			{
				float parentWidth = parent->Widget::getWidth();
				float currentRealX = t_widgetSelf->Widget::getX();
				float currentWidth = t_widgetSelf->Widget::getWidth();
				t_widgetSelf->Widget::setX(parentWidth - currentRealX - currentWidth);
			}
		}


		// update orientation
		t_OnOrientation(orientation);
	}

	void CWidgetExtension::SetOrientation(EOrientation orientation)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::SetOrientation. orientation:" << (orientation == ORIENTATION_RIGHT_TO_LEFT ? "right-to-left" : "left-to-right"));
		HALO_ASSERT(ParentWidgetExtension() != NULL || orientation != ORIENTATION_REFER_TO_PARENT);

		bool bNeedUpdate = true;

		EOrientation currentRealOrientaton = Orientation(true);

		if (currentRealOrientaton == orientation)
		{
			//1. m_orientation != refer_to_parent and m_orientation == orientation
			//2. m_orientation == refer_to_parent and parent's orientation == orientation
			bNeedUpdate = false;
		}
		if (orientation == ORIENTATION_REFER_TO_PARENT)
		{
			CWidgetExtension* cParent = dynamic_cast<CWidgetExtension*>(ParentWidgetExtension());
			if (cParent != NULL && cParent->Orientation(true) == m_orientation)
			{
				//3. orientation == refer_to_parent and m_orientation == parent's orientation
				bNeedUpdate = false;
			}
		}

		//if need update orientation or not, set m_orientation always.
		m_orientation = orientation;

		if (bNeedUpdate)
		{
			t_OnOrientation(Orientation(true));
		}
	}

	EOrientation CWidgetExtension::Orientation(bool flagReferParent)const
	{
		if (flagReferParent && m_orientation == ORIENTATION_REFER_TO_PARENT)
		{
			CWidgetExtension* cParent = dynamic_cast<CWidgetExtension*>(ParentWidgetExtension());
			if (cParent != NULL)
			{
				return cParent->Orientation(true);
			}
			else
			{
				//return ORIENTATION_LEFT_TO_RIGHT;
				return IUtility::GetInstance()?IUtility::GetInstance()->GetOrientation():ORIENTATION_LEFT_TO_RIGHT;
			}
		}

		return m_orientation;
	}

	void CWidgetExtension::t_OnOrientation(EOrientation orientation)
	{
		//Update itself
		t_UpdateOrientation(orientation);

		//Update all children
		if (t_widgetSelf)
		{
			unsigned int childCnt = t_widgetSelf->getChildCount();
			for (size_t i = 0; i < childCnt; i++)
			{
				CWidgetExtension* child = dynamic_cast<CWidgetExtension*>(t_widgetSelf->getChildByIndex(i));
				if (child != NULL && child->Orientation(false) == ORIENTATION_REFER_TO_PARENT)
				{
					child->t_OnOrientation(orientation);
				}
			}
		}

	}

	void CWidgetExtension::EnableHighContrast(const bool enable)
	{
		H_LOG_DEBUG(LOGGER, "[" << this << "] flagHighContrast(" << enable << ")");

		if (m_flagHighContrast == enable)
		{
			return;
		}

		m_flagHighContrast = enable;

		t_OnHighContrast(enable);
	}

	bool CWidgetExtension::IsHighContrastEnabled(void) const
	{
		return m_flagHighContrast;
	}

	void CWidgetExtension::EnableEnlarge(const bool enable)
	{
		H_LOG_DEBUG(LOGGER, "[" << this << "] flagEnlarge(" << enable << ")");

		if (m_flagEnlarge == enable)
		{
			return;
		}

		m_flagEnlarge = enable;

		t_OnEnlarge(enable);
	}

	bool CWidgetExtension::IsEnlargeEnabled(void) const
	{
		return m_flagEnlarge;
	}

	//void WidgetExtension::Show(void)
	//{
	//	H_LOG_DEBUG(LOGGER, "WidgetExtension::Show.");
	//	t_OnShow();
	//	show();
	//}

	//void WidgetExtension::Hide(void)
	//{
	//	H_LOG_DEBUG(LOGGER, "WidgetExtension::Hide.");
	//	t_OnHide();
	//	t_FocusUnviewable(true);

	//	hide();
	//}

	//bool WidgetExtension::FlagShow(void)
	//{
	//	H_LOG_TRACE(LOGGER, "WidgetExtension::FlagShow.");
	//	return CLUTTER_ACTOR_IS_VISIBLE(actor);
	//}

	//void WidgetExtension::EnableClipOverflow(bool enable)
	//{
	//	H_LOG_DEBUG(LOGGER, "WidgetExtension::EnableClipOverflow. enable:" << enable);
	//	setCropOverflow(enable);
	//}

	//bool WidgetExtension::IsClipOverflowEnabled(void)
	//{
	//	H_LOG_TRACE(LOGGER, "WidgetExtension::IsClipOverflowEnabled.");
	//	return getCropOverflow();
	//}

	//void WidgetExtension::SetClipArea(float x, float y, float width, float height)
	//{
	//	H_LOG_DEBUG(LOGGER, "WidgetExtension::SetClipArea. x:" << x << "y:" << y << "width:" << width << "height:" << height);
	//	clutter_actor_set_clip(actor, x, y, width, height);
	//}

	//void WidgetExtension::GetClipArea(float &x, float &y, float &width, float &height)
	//{
	//	H_LOG_TRACE(LOGGER, "WidgetExtension::GetClipArea.");
	//	clutter_actor_get_clip(actor, &x, &y, &width, &height);
	//	H_LOG_TRACE(LOGGER, "WidgetExtension::GetClipArea. x:" << x << "y:" << y << "width:" << width << "height:" << height);
	//}

	//void WidgetExtension::RemoveClipArea(void)
	//{
	//	H_LOG_DEBUG(LOGGER, "WidgetExtension::RemoveClipArea.");
	//	clutter_actor_remove_clip(actor);
	//}

	//bool WidgetExtension::FlagClip(void)
	//{
	//	H_LOG_TRACE(LOGGER, "WidgetExtension::FlagClip.");
	//	return (clutter_actor_has_clip(actor) != FALSE);
	//}

	//void WidgetExtension::SetAlpha(int alpha)
	//{
	//	H_LOG_DEBUG(LOGGER, "WidgetExtension::SetAlpha. alpha:" << alpha);
	//	HALO_ASSERT(alpha >= 0 && alpha <= 255);

	//	setOpacity(alpha);
	//}

	//int WidgetExtension::Alpha(void)
	//{
	//	H_LOG_TRACE(LOGGER, "WidgetExtension::Alpha.");
	//	return getOpacity();
	//}

	//void WidgetExtension::SetPivotPoint(float xPivot, float yPivot, float zPivot)
	//{
	//	H_LOG_DEBUG(LOGGER, "WidgetExtension::SetPivotPoint. xPivot:" << xPivot << "yPivot:" << yPivot << "zPivot:" << zPivot);
	//	setPivot(Vector2(xPivot, yPivot));
	//}

	//void WidgetExtension::GetPivotPoint(float &xPivot, float &yPivot, float &zPivot)
	//{
	//	H_LOG_TRACE(LOGGER, "WidgetExtension::GetPivotPoint.");
	//	Vector2 pv = getPivot();
	//	xPivot = pv.x;
	//	yPivot = pv.y;
	//	H_LOG_TRACE(LOGGER, "WidgetExtension::GetPivotPoint. xPivot:" << xPivot << "yPivot:" << yPivot << "zPivot:" << zPivot);
	//}

	//void WidgetExtension::SetRotation(double xAngle, double yAngle, double zAngle)
	//{
	//	H_LOG_DEBUG(LOGGER, "WidgetExtension::SetRotation. xAngle:" << xAngle << "yAngle:" << yAngle << "zAngle:" << zAngle);
	//	setRotation(Vector3(xAngle, yAngle, zAngle));
	//}

	//void WidgetExtension::GetRotation(double &xAngle, double &yAngle, double &zAngle)
	//{
	//	H_LOG_TRACE(LOGGER, "WidgetExtension::GetRotation.");
	//	Vector3 rv = getRotation();
	//	xAngle = rv.x;
	//	yAngle = rv.y;
	//	zAngle = rv.z;
	//	H_LOG_TRACE(LOGGER, "WidgetExtension::GetRotation. xAngle:" << xAngle << "yAngle:" << yAngle << "zAngle:" << zAngle);
	//}

	//void WidgetExtension::SetScale(double xFactor, double yFactor, double zFactor)
	//{
	//	H_LOG_DEBUG(LOGGER, "WidgetExtension::SetScale. xFactor:" << xFactor << "yFactor:" << yFactor << "zFactor:" << zFactor);
	//	setScale(Vector2(xFactor, yFactor));
	//}

	//void WidgetExtension::GetScale(double &xFactor, double &yFactor, double &zFactor)
	//{
	//	H_LOG_TRACE(LOGGER, "WidgetExtension::GetScale.");
	//	Vector2 sv = getScale();
	//	xFactor = sv.x;
	//	yFactor = sv.y;
	//	H_LOG_TRACE(LOGGER, "WidgetExtension::GetScale. xFactor:" << xFactor << "yFactor:" << yFactor << "zFactor:" << zFactor);
	//}

	//void WidgetExtension::AddEffect(IEffect* effect)
	//{
	//	H_LOG_DEBUG(LOGGER, "WidgetExtension::AddEffect. effect:" << effect);
	//	CEffect* cEffect = dynamic_cast<CEffect*>(effect);
	//	if (cEffect != NULL)
	//	{
	//		clutter_actor_add_effect(actor, cEffect->GetEffect());
	//	}
	//}

	//void WidgetExtension::RemoveEffect(IEffect* effect)
	//{
	//	H_LOG_DEBUG(LOGGER, "WidgetExtension::RemoveEffect. effect:" << effect);
	//	CEffect* cEffect = dynamic_cast<CEffect*>(effect);
	//	if (cEffect != NULL)
	//	{
	//		clutter_actor_remove_effect(actor, cEffect->GetEffect());
	//	}
	//}

	//void WidgetExtension::ClearEffects(void)
	//{
	//	H_LOG_DEBUG(LOGGER, "WidgetExtension::ClearEffects.");
	//	clutter_actor_clear_effects(actor);
	//}

	//void WidgetExtension::AddChild(ClutterActor *child)
	//{
	//	H_LOG_DEBUG(LOGGER, "WidgetExtension::AddChild. child:" << child);
	//	clutter_actor_remove_child(clutter_actor_get_parent(child), child);
	//	clutter_actor_add_child(actor, child);
	//}

	//int  WidgetExtension::NumOfChildren(void)
	//{
	//	return getChildCount();
	//}

	//WidgetExtension* WidgetExtension::GetChild(int index)
	//{
	//	H_LOG_DEBUG(LOGGER, "WidgetExtension::GetChild. index:" << index);
	//	return dynamic_cast<WidgetExtension*>(getChildByIndex(index));
	//}

	//void WidgetExtension::DestroyAllChildren(void)
	//{
	//	H_LOG_DEBUG(LOGGER, "WidgetExtension::DestroyAllChildren.");
	//	destroyChildren();
	//}

	//bool WidgetExtension::Raise(WidgetExtension* sibling)
	//{
	//	H_LOG_DEBUG(LOGGER, "WidgetExtension::Raise. sibling:" << sibling);
	//	HALO_ASSERT(NULL == sibling || sibling->Parent() == Parent());

	//	clutter_actor_set_child_above_sibling(
	//		clutter_actor_get_parent(actor),
	//		actor,
	//		sibling == NULL ? NULL : sibling->Actor());
	//	return true;
	//}

	//bool WidgetExtension::Lower(WidgetExtension* sibling)
	//{
	//	H_LOG_DEBUG(LOGGER, "WidgetExtension::Lower. sibling:" << sibling);
	//	HALO_ASSERT(NULL == sibling || sibling->Parent() == Parent());

	//	clutter_actor_set_child_below_sibling(
	//		clutter_actor_get_parent(actor),
	//		actor,
	//		sibling == NULL ? NULL : sibling->Actor());
	//	return true;
	//}

	void CWidgetExtension::Enable(bool flagEnable)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::Enable. enable:" << flagEnable);
		if (flagEnable)
		{
			m_enableMouseEvent(true);
		}
		else
		{
			m_enableMouseEvent(false, true);
			if (IsFocused())
			{
				KillFocus();
			}
		}
		m_flagEnabled = flagEnable;
	}

	bool CWidgetExtension::IsEnabled(void)
	{
		return m_flagEnabled;
	}

	void CWidgetExtension::EnableReverse(const bool flagEnable)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::EnableReverse. enable:" << flagEnable);
		if (m_flagReversible != flagEnable)
		{
			IWidgetExtension* parentWidgetExtension = ParentWidgetExtension();
			if (parentWidgetExtension)
			{
				if (parentWidgetExtension->Orientation(false) == ORIENTATION_REFER_TO_PARENT)
				{
					if (parentWidgetExtension->Orientation(true) == ORIENTATION_RIGHT_TO_LEFT)
					{
						if (t_widgetSelf)
						{
							if (t_widgetSelf->getParent())
							{
								float parentWidth = t_widgetSelf->getParent()->getWidth();
								float thisWidth = t_widgetSelf->getWidth();
								if (thisWidth && parentWidth)
								{
									float thisWidth = t_widgetSelf->getWidth();
									float oldX = t_widgetSelf->getX();
									oldX = t_MultiResolutionConvert1920(oldX);
									float newX = parentWidth - oldX - thisWidth;
									newX = t_1920ConvertMultiResolution(newX);
									t_widgetSelf->setX(newX);
								}
							}
						}
					}
				}
			}
		}
		m_flagReversible = flagEnable;
	}

	bool CWidgetExtension::IsReversible(void)const
	{
		return m_flagReversible;
	}

	void CWidgetExtension::EnablePointerFocus(bool enable)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::EnablePointerFocus. enable:" << enable);
		m_enblePointerFocus = enable;
		if (enable)
		{
			m_enableMouseEvent(true);
		}
		else
		{
			m_enableMouseEvent(false);
		}
	}

	bool CWidgetExtension::IsPointerFocusEnabled(void)
	{
		return m_enblePointerFocus;
	}

	void CWidgetExtension::EnableFocus(bool flagFocusable)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::EnableFocus. enable:" << flagFocusable);
		t_flagFocusable = flagFocusable;
	}

	bool CWidgetExtension::IsFocusEnabled(void)
	{
		return IsEnabled() && t_flagFocusable;
	}

	bool CWidgetExtension::SetFocus(void)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::SetFocus. this:" << this);
		if (!IsFocusEnabled())
		{
			return false;
		}

		CFocusManager* pFocusManager = CFocusManager::GetInstance();

		if (pFocusManager)
		{
			pFocusManager->ChangeFocusBySet(this);
		}

		return true;
	}

	bool CWidgetExtension::KillFocus(bool followingRule)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::KillFocus. this:" << this);
		CFocusManager* pFocusManager = CFocusManager::GetInstance();

		if (pFocusManager)
		{
			pFocusManager->ChangeFocusByKill(this, followingRule);
		}

		return true;
	}

	bool CWidgetExtension::IsFocused(void)
	{
		HALO_ASSERT(m_flagInit);
		return (clutter_actor_has_key_focus(t_widgetSelf->getAnimationActor()) != FALSE);
	}

	void CWidgetExtension::SetTabWindow(EDirection dir, IWidgetExtension* tabWindow)
	{
		HALO_ASSERT(m_flagInit);
		H_LOG_DEBUG(LOGGER, "WidgetExtension::SetTabWindow. direction:" << dir << "window:" << tabWindow);
		switch (dir)
		{
		case DIRECTION_LEFT:
			if (ParentWidgetExtension() && ParentWidgetExtension()->Orientation(true) == ORIENTATION_RIGHT_TO_LEFT)
			{
				m_rightWindowTab = dynamic_cast<CWidgetExtension*>(tabWindow);
			} 
			else
			{
				m_leftWindowTab = dynamic_cast<CWidgetExtension*>(tabWindow);
			}
			break;
		case DIRECTION_UP:
			m_upWindowTab = dynamic_cast<CWidgetExtension*>(tabWindow);
			break;
		case DIRECTION_RIGHT:
			if (ParentWidgetExtension() && ParentWidgetExtension()->Orientation(true) == ORIENTATION_RIGHT_TO_LEFT)
			{
				m_leftWindowTab = dynamic_cast<CWidgetExtension*>(tabWindow);
			} 
			else
			{
				m_rightWindowTab = dynamic_cast<CWidgetExtension*>(tabWindow);
			}
			break;
		case DIRECTION_DOWN:
			m_downWindowTab = dynamic_cast<CWidgetExtension*>(tabWindow);
			break;
		default:
			break;
		}
	}

	IWidgetExtension* CWidgetExtension::TabWindow(EDirection dir)
	{
		H_LOG_TRACE(LOGGER, "WidgetExtension::TabWindow. direction:" << dir);
		switch (dir)
		{
		case DIRECTION_LEFT:
			{
				return m_leftWindowTab;
			}
		case DIRECTION_UP:
			return m_upWindowTab;
		case DIRECTION_RIGHT:
			{
				return m_rightWindowTab;
			}
		case DIRECTION_DOWN:
			return m_downWindowTab;
		default:
			return NULL;
		}
	}


	bool CWidgetExtension::MoveTab(EDirection direction)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::MoveTab. direction:" << direction);
		CWidgetExtension* nextTab = this;

#ifndef WIN32				
		IAudioUI::GetInstance()->Play(MOVE_PANEL);
#endif

		do
		{
			nextTab = dynamic_cast<CWidgetExtension*>(nextTab->TabWindow(direction));

		} while (nextTab != NULL && nextTab->IsFocusEnabled() == false);

		if (nextTab == NULL)
		{
			return false;
		}

		return nextTab->SetFocus();
	}

	void CWidgetExtension::AddTransition(CTransition *transition)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::AddTransition. transition:" << transition);
		HALO_ASSERT(NULL != transition && true == transition->IsInitialized());

		clutter_actor_add_transition(t_widgetSelf->getAnimationActor(), transition->TransitionName(), transition->Transition());
	}

	void CWidgetExtension::RemoveTransition(CTransition *transition)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::RemoveTransition. transition:" << transition);
		HALO_ASSERT(NULL != transition && true == transition->IsInitialized());

		clutter_actor_remove_transition(t_widgetSelf->getAnimationActor(), transition->TransitionName());
	}

	//ClutterActor* WidgetExtension::Actor(void)
	//{
	//	return getAnimationActor();
	//}

	//! Add Focus Listener
	bool CWidgetExtension::AddFocusListener(IFocusListener* pAddListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::AddFocusListener.");
		HALO_ASSERT(NULL != pAddListener);

		bool ret = false;
		if (m_pFocusListenerSet == NULL)
		{
			m_pFocusListenerSet = new CFocusListenerSet(this);
			HALO_ASSERT(m_pFocusListenerSet);
		}
		ret = m_pFocusListenerSet->Add(pAddListener);

		return ret;
	}
	//! Remove Focus Listener
	bool CWidgetExtension::RemoveFocusListener(IFocusListener* pRemoveListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::RemoveFocusListener.");
		HALO_ASSERT(NULL != pRemoveListener);

		bool ret = false;
		if (m_pFocusListenerSet == NULL)
		{
			return false;
		}
		ret = m_pFocusListenerSet->Remove(pRemoveListener);
		if (m_pFocusListenerSet->Empty())
		{
			delete m_pFocusListenerSet;
			m_pFocusListenerSet = NULL;
		}
		return ret;
	}

	bool CWidgetExtension::t_CreateWidget( void )
	{
		if (!m_flagInit)
		{
			t_widgetSelf = dynamic_cast<Widget*>(this);
			if (!t_widgetSelf)
			{
				return false;
			}
			D_SET_HALO_WIDGET_EXTENSION(G_OBJECT(t_widgetSelf->getAnimationActor()), this);
			m_eventId = g_signal_connect(t_widgetSelf->getAnimationActor(), "event", G_CALLBACK(m_EventCb), this);
			m_focusInId = g_signal_connect(t_widgetSelf->getAnimationActor(), "key-focus-in", G_CALLBACK(m_KeyFocusInCb), this);
			m_focusOutId = g_signal_connect(t_widgetSelf->getAnimationActor(), "key-focus-out", G_CALLBACK(m_KeyFocusOutCb), this);
			m_capturedEventId = g_signal_connect(t_widgetSelf->getAnimationActor(), "captured-event", G_CALLBACK(m_CapturedEventCb), this);

			m_flagHighContrast = IUtility::GetInstance()->IsHighContrastEnabled();
			m_flagEnlarge = IUtility::GetInstance()->IsEnlargeEnabled();

			m_flagInit = true;
			return true;
		}
		return false;
	}

	bool CWidgetExtension::t_AnimationIsValid(CTransition *animation, int animationType)
	{
		return true;

		switch ((EAnimatableValue)(animationType))
		{
		case ACTOR_ANI_POSITION_X:
		case ACTOR_ANI_POSITION_Y:
		case ACTOR_ANI_POSITION_Z:
			if (NULL == dynamic_cast<CTransition*>(animation))
			{
				return false;
			}
			break;

		case ACTOR_ANI_ALPHA:
			if (NULL == dynamic_cast<CTransition*>(animation))
			{
				return false;
			}
			break;

		case ACTOR_ANI_POSITION:
			if (NULL == dynamic_cast<CTransition*>(animation))
			{
				return false;
			}
			break;
		default:
			break;
		}

		return true;
	}

	const char* CWidgetExtension::GetPropertyName(int animationType, GType *valueType)
	{
		switch ((EAnimatableValue)(animationType))
		{
		case ACTOR_ANI_POSITION_X:
			*valueType = G_TYPE_FLOAT;
			return "x";

		case ACTOR_ANI_POSITION_Y:
			*valueType = G_TYPE_FLOAT;
			return "y";

		case ACTOR_ANI_POSITION_Z:
			*valueType = G_TYPE_FLOAT;
			return "z-position";

		case ACTOR_ANI_ALPHA:
			*valueType = G_TYPE_UINT;
			return "opacity";

		case ACTOR_ANI_POSITION:
			*valueType = CLUTTER_TYPE_POINT;
			return "position";

		case ACTOR_ANI_SIZE:
			*valueType = CLUTTER_TYPE_SIZE;
			return "size";

		case ACTOR_ANI_SCALE_X:
			*valueType = G_TYPE_DOUBLE;
			return "scale-x";

		case ACTOR_ANI_SCALE_Y:
			*valueType = G_TYPE_DOUBLE;
			return "scale-y";

		case ACTOR_ANI_SCALE_Z:
			*valueType = G_TYPE_DOUBLE;
			return "scale-z";

		default:
			return NULL;
			break;
		}
	}

	ClutterAnimatable* CWidgetExtension::t_GetAnimatableObject(void)
	{
		return CLUTTER_ANIMATABLE(t_widgetSelf->getAnimationActor());
	}

	void CWidgetExtension::t_FocusUnviewable(bool autoFocus)
	{
		CFocusManager* pFocusManager = CFocusManager::GetInstance();

		if (pFocusManager)
		{
			pFocusManager->ChangeFocusByUnviewable(this, autoFocus);
		}
	}

	void CWidgetExtension::t_UpdateOrientation(EOrientation orientation)
	{
		HALO_ASSERT(m_flagInit);
		unsigned int childCnt = t_widgetSelf->getChildCount();
		for (size_t i = 0; i < childCnt; i++)
		{
			CWidgetExtension* child = dynamic_cast<CWidgetExtension*>(t_widgetSelf->getChildByIndex(i));
			if (child != NULL)
			{
				//Adjust child's position if reversible
				if (child->m_flagReversible && child->t_widgetSelf)
				{
					float parentWidth = t_widgetSelf->getWidth();
					float childWidth = child->t_widgetSelf->getWidth();
					if (childWidth && parentWidth)
					{
						float childX = child->t_widgetSelf->getX();
						childX = t_MultiResolutionConvert1920(childX);
						float temp = parentWidth - childX - childWidth;
						temp = t_1920ConvertMultiResolution(temp);
						child->t_widgetSelf->setX(temp);
					}
				}

				//Adjust tabwindow except child is reversible
				if (child->m_leftWindowTab || child->m_rightWindowTab)
				{
					CWidgetExtension* temp = child->m_leftWindowTab;
					child->m_leftWindowTab = child->m_rightWindowTab;
					child->m_rightWindowTab = temp;
				}
			}
		}
	}

	void CWidgetExtension::t_OnHighContrast(bool flagHighContrast)
	{
		//Update itself
		t_UpdateHighContrast(flagHighContrast);

		//Notice 
		WidgetHelperListenerSet::TActorListenerData data;
		data.type = EVENT_HIGHCONTRAST_CHANGED;
		data.param[0] = flagHighContrast;

		if (NULL != m_pWidgetHelperListenerSet)
		{
			m_pWidgetHelperListenerSet->Process(&data);
		}

		//Update all children
		if (t_widgetSelf)
		{
			unsigned int childCnt = t_widgetSelf->getChildCount();
			for (size_t i = 0; i < childCnt; i++)
			{
				CWidgetExtension* child = dynamic_cast<CWidgetExtension*>(t_widgetSelf->getChildByIndex(i));
				if (child != NULL)
				{
					child->t_OnHighContrast(flagHighContrast);
				}
				else
				{
					H_LOG_WARN(LOGGER, "[" << this << "] Not Halo uielement, can not notify!");
				}
			}
		}
	}

	void CWidgetExtension::t_UpdateHighContrast(bool flagHighContrast)
	{

	}

	void CWidgetExtension::t_OnEnlarge(bool flagEnlarge)
	{
		//Update itself
		t_UpdateEnlarge(flagEnlarge);

		//Notice 
		WidgetHelperListenerSet::TActorListenerData data;
		data.type = EVENT_ENLARGE_CHANGED;
		data.param[0] = flagEnlarge;

		if (NULL != m_pWidgetHelperListenerSet)
		{
			m_pWidgetHelperListenerSet->Process(&data);
		}

		//Update all children
		if (t_widgetSelf)
		{
			unsigned int childCnt = t_widgetSelf->getChildCount();
			for (size_t i = 0; i < childCnt; i++)
			{
				CWidgetExtension* child = dynamic_cast<CWidgetExtension*>(t_widgetSelf->getChildByIndex(i));
				if (child != NULL)
				{
					child->t_OnEnlarge(flagEnlarge);
				}
				else
				{
					H_LOG_WARN(LOGGER, "[" << this << "] Not Halo uielement, can not notify!");
				}
			}
		}
	}

	void CWidgetExtension::t_UpdateEnlarge(bool flagEnlarge)
	{

	}

	void CWidgetExtension::t_AddNoticeActor(IWidgetExtension *pNoticeActor)
	{
		if (NULL == m_pFocusListener)
		{
			m_pFocusListener = new WidgetHelperFocusListener(this);
		}

		pNoticeActor->AddFocusListener(m_pFocusListener);
	}

	ClutterActor* CWidgetExtension::Actor(void)
	{
		if (t_widgetSelf)
		{
			return t_widgetSelf->getAnimationActor();
		}
		return NULL;
	}

	bool CWidgetExtension::OnEvent(IEvent* pEvent)
	{
		if (m_pActionList)
		{
			TActionList::iterator itor = m_pActionList->begin();
			while (itor != m_pActionList->end())
			{
				bool actionRet = false;
				IAction* pAction = *itor;
				if (pAction->IsInterestEvent(pEvent))
				{
					IEvent* pNewEvent = NULL;
					actionRet = pAction->Process(pEvent, &pNewEvent);
					if (pNewEvent)
					{
						OnEvent(pNewEvent);
						pNewEvent->Release();
						pNewEvent = NULL;
					}
					if (actionRet)
					{
						break;
					}
				}
				itor++;
			}
		}

		if (pEvent->IsEventType("samsung.tv.halo.input.keypress") || pEvent->IsEventType("samsung.tv.halo.input.keyrelease"))
		{
			CKeyboardEvent* evt = dynamic_cast<CKeyboardEvent*>(pEvent);
			if (evt)
			{
				m_OnKeyboard(evt);
			}
		}
		else if (pEvent->IsEventType("samsung.tv.halo.input.mouseenter")
			|| pEvent->IsEventType("samsung.tv.halo.input.mouseleave")
			|| pEvent->IsEventType("samsung.tv.halo.input.mousemotion")
			|| pEvent->IsEventType("samsung.tv.halo.input.mousescroll")
			|| pEvent->IsEventType("samsung.tv.halo.input.mousepress")
			|| pEvent->IsEventType("samsung.tv.halo.input.mouserelease"))
		{
			CMouseEvent* evt = dynamic_cast<CMouseEvent*>(pEvent);
			if (evt)
			{
				m_OnMouse(evt);
			}
		}
		else if (pEvent->IsEventType("samsung.tv.halo.input.focus"))
		{
			if (m_pFocusListenerSet)
			{
				m_pFocusListenerSet->Process(pEvent);
			}

			CFocusEvent *focusEvent = dynamic_cast<CFocusEvent*>(pEvent);
			if (NULL != focusEvent && EVENT_FOCUSIN == focusEvent->FocusEventType())
			{
				t_NoticeActorFocusIn(this);
			}
		}
		else if (pEvent->IsEventType("samsung.tv.halo.input.mouseclicked") || pEvent->IsEventType("samsung.tv.halo.input.mouselongpress"))
		{
			if (m_pClickListenerSet)
			{
				m_pClickListenerSet->Process(pEvent);
			}
		}
		else if (pEvent->IsEventType("samsung.tv.halo.input.drag"))
		{
			if (m_pDragListenerSet)
			{
				m_pDragListenerSet->Process(pEvent);
			}
		}
		else if (pEvent->IsEventType("samsung.tv.halo.input.gesture"))
		{
			if (m_pGestureListenerSet)
			{
				m_pGestureListenerSet->Process(pEvent);
			}
		}
		else if (pEvent->IsEventType("samsung.tv.halo.input.keylongpress"))
		{
			if (m_pKeyLongPressListenerSet)
			{
				m_pKeyLongPressListenerSet->Process(pEvent);
			}
		}
		else if (pEvent->IsEventType("samsung.tv.halo.input.keycombination"))
		{
			if (m_pKeyCombinationListenerSet)
			{
				m_pKeyCombinationListenerSet->Process(pEvent);
			}
		}
		else if (pEvent->IsEventType("samsung.tv.halo.input.cursorshow") || pEvent->IsEventType("samsung.tv.halo.input.cursorhide"))
		{
			if (m_pCursorListenerSet)
			{
				m_pCursorListenerSet->Process(pEvent);
			}
		}
		else
		{
			if (m_pSemanticEventListenerSet)
			{
				m_pSemanticEventListenerSet->Process(pEvent);
			}
		}
		return true;
	}

	//!Add/Remove mouse listeners
	bool CWidgetExtension::AddMouseListener(IMouseListener* pAddListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::AddMouseListener.");
		HALO_ASSERT(NULL != pAddListener);

		bool ret = false;
		if (m_pMouseListenerSet == NULL)
		{
			m_pMouseListenerSet = new CMouseListenerSet(this);
			HALO_ASSERT(m_pMouseListenerSet);
		}
		ret = m_pMouseListenerSet->Add(pAddListener);
		if (ret)
		{
			m_enableMouseEvent(true);
		}
		return ret;
	}

	bool CWidgetExtension::RemoveMouseListener(IMouseListener* pRemoveListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::RemoveMouseListener.");
		HALO_ASSERT(NULL != pRemoveListener);

		bool ret = false;

		if (m_pMouseListenerSet == NULL)
		{
			return false;
		}
		ret = m_pMouseListenerSet->Remove(pRemoveListener);
		if (m_pMouseListenerSet->Empty())
		{
			delete m_pMouseListenerSet;
			m_pMouseListenerSet = NULL;

			m_enableMouseEvent(false);
		}
		return ret;
	}

	//! Add/Remove Touch Listener
	bool CWidgetExtension::AddTouchListener(ITouchListener* pAddListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::AddTouchListener.");
		HALO_ASSERT(NULL != pAddListener);

		return true;
	}

	bool CWidgetExtension::RemoveTouchListener(ITouchListener* pRemoveListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::RemoveTouchListener.");
		HALO_ASSERT(NULL != pRemoveListener);

		return true;
	}

	//! Add/Remove Keyboard Listener
	bool CWidgetExtension::AddKeyboardListener(IKeyboardListener* pAddListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::AddKeyboardListener.");
		HALO_ASSERT(NULL != pAddListener);

		if (m_pKeyboardListenerSet == NULL)
		{
			m_pKeyboardListenerSet = new CKeyboardListenerSet(this);
			HALO_ASSERT(m_pKeyboardListenerSet);
		}
		return m_pKeyboardListenerSet->Add(pAddListener);
	}

	bool CWidgetExtension::RemoveKeyboardListener(IKeyboardListener* pRemoveListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::RemoveKeyboardListener.");
		HALO_ASSERT(NULL != pRemoveListener);

		bool ret = false;
		if (m_pKeyboardListenerSet == NULL)
		{
			return false;
		}
		ret = m_pKeyboardListenerSet->Remove(pRemoveListener);
		if (m_pKeyboardListenerSet->Empty())
		{
			delete m_pKeyboardListenerSet;
			m_pKeyboardListenerSet = NULL;
		}
		return ret;
	}

	//! Add/Remove Audio Listener
	bool CWidgetExtension::AddAudioListener(IAudioListener* pAddListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::AddAudioListener.");
		HALO_ASSERT(NULL != pAddListener);

		return true;
	}

	bool CWidgetExtension::RemoveAudioListener(IAudioListener* pRemoveListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::RemoveAudioListener.");
		HALO_ASSERT(NULL != pRemoveListener);

		return true;
	}

	//! Add/Remove RemoteControl Listener
	bool CWidgetExtension::AddRemoteControlListener(IRemoteControlListener* pAddListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::AddRemoteControlListener.");
		HALO_ASSERT(NULL != pAddListener);

		return true;
	}

	bool CWidgetExtension::RemoveRemoteControlListener(IRemoteControlListener* pRemoveListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::RemoveRemoteControlListener.");
		HALO_ASSERT(NULL != pRemoveListener);

		return true;
	}

	//! Add/Remove RemoteControl Listener
	bool CWidgetExtension::AddRidgeListener(IRidgeListener* pAddListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::AddRidgeListener.");
		HALO_ASSERT(NULL != pAddListener);

		return true;
	}

	bool CWidgetExtension::RemoveRidgeListener(IRidgeListener* pRemoveListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::RemoveRidgeListener.");
		HALO_ASSERT(NULL != pRemoveListener);

		return true;
	}

	bool CWidgetExtension::AddActorListener(IActorListener *pActorListener)
	{
		H_LOG_TRACE(LOGGER, "[" << std::hex<< this <<"]WidgetExtension::AddActorListener");
		HALO_ASSERT(pActorListener != NULL);

		if (NULL == m_pWidgetHelperListenerSet)
		{
			m_pWidgetHelperListenerSet = new WidgetHelperListenerSet(this);
			HALO_ASSERT(NULL != m_pWidgetHelperListenerSet);
		}

		m_pWidgetHelperListenerSet->Add(pActorListener);
		return true;
	}

	bool CWidgetExtension::RemoveActorListener(IActorListener *pActorListener)
	{
		H_LOG_TRACE(LOGGER, "[" << std::hex<< this <<"]WidgetExtension::RemoveActorListener");
		HALO_ASSERT(pActorListener != NULL);
		HALO_ASSERT(NULL != m_pWidgetHelperListenerSet);

		m_pWidgetHelperListenerSet->Remove(pActorListener);

		return true;
	}

	//! Add/Remove cursor Listener
	bool CWidgetExtension::AddCursorStateChangeListener(ICursorListener* pAddListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::AddCursorStateChangeListener.");
		HALO_ASSERT(NULL != pAddListener);

		return true;
	}

	bool CWidgetExtension::RemoveCursorStateChangeListener(ICursorListener* pRemoveListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::RemoveCursorStateChangeListener.");
		HALO_ASSERT(NULL != pRemoveListener);

		return true;
	}

	//! Add click Listener
	bool CWidgetExtension::AddClickListener(IClickListener* pAddListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::AddClickListener.");
		HALO_ASSERT(NULL != pAddListener);

		bool ret = false;
		if (m_pClickListenerSet == NULL)
		{
			m_pClickListenerSet = new CClickListenerSet(this);
			HALO_ASSERT(m_pClickListenerSet);
		}
		ret = m_pClickListenerSet->Add(pAddListener);
		if (ret)
		{
			m_enableMouseEvent(true);
		}

		return ret;
	}

	//! Remove click listener
	bool CWidgetExtension::RemoveClickListener(IClickListener* pRemoveListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::RemoveClickListener.");
		HALO_ASSERT(NULL != pRemoveListener);

		bool ret = false;
		if (m_pClickListenerSet == NULL)
		{
			return false;
		}
		ret = m_pClickListenerSet->Remove(pRemoveListener);
		if (m_pClickListenerSet->Empty())
		{
			delete m_pClickListenerSet;
			m_pClickListenerSet = NULL;

			m_enableMouseEvent(false);
		}
		return ret;
	}

	//! Add custom Listener
	bool CWidgetExtension::AddSemanticEventListener(ISemanticEventListener* pAddListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::AddSemanticEventListener.");
		HALO_ASSERT(NULL != pAddListener);

		bool ret = false;
		if (m_pSemanticEventListenerSet == NULL)
		{
			m_pSemanticEventListenerSet = new CSemanticEventListenerSet(this);
			HALO_ASSERT(m_pClickListenerSet);
		}
		ret = m_pSemanticEventListenerSet->Add(pAddListener);
		return ret;
	}

	//! Remove custom Listener
	bool CWidgetExtension::RemoveSemanticEventListener(ISemanticEventListener* pRemoveListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::RemoveSemanticEventListener.");
		HALO_ASSERT(NULL != pRemoveListener);

		bool ret = false;
		if (m_pSemanticEventListenerSet == NULL)
		{
			return false;
		}
		ret = m_pSemanticEventListenerSet->Remove(pRemoveListener);
		return ret;
	}

	bool CWidgetExtension::AddAction(IAction* pAction)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::AddAction. action:" << pAction);
		HALO_ASSERT(NULL != pAction);

		if (!m_pActionList)
		{
			m_pActionList = new TActionList;
		}
		m_pActionList->push_back(pAction);
		ClutterAction *ca = pAction->Action();
		if (ca)
		{
			if (dynamic_cast<IDragAction*>(pAction) != NULL)
			{
				HALO_ASSERT(!m_dragEnabled);
				m_dragEnabled = true;
				m_enableMouseEvent(true);
			}

			clutter_actor_add_action(t_widgetSelf->getAnimationActor(), ca);
		}
		
		return true;
	}
	bool CWidgetExtension::RemoveAction(IAction* pAction)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::RemoveAction. action:" << pAction);
		HALO_ASSERT(NULL != pAction);

		if (!m_pActionList)
		{
			return false;
		}
		TActionList::iterator itor = m_pActionList->begin();
		while (itor != m_pActionList->end())
		{
			if (*itor == pAction)
			{
				m_pActionList->erase(itor);
				ClutterAction *ca = pAction->Action();
				if (ca)
				{
					clutter_actor_remove_action(t_widgetSelf->getAnimationActor(), ca);

					if (dynamic_cast<IDragAction*>(pAction) != NULL)
					{
						m_dragEnabled = false;
						m_enableMouseEvent(false);
					}
				}
				return true;
			}
			itor++;
		}
		return false;
	}

	TActionList* CWidgetExtension::GetActionList(void)
	{
		return m_pActionList;
	}

	//! Add drag listener
	bool CWidgetExtension::AddDragListener(IDragListener* pAddListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::AddDragListener.");
		HALO_ASSERT(NULL != pAddListener);

		bool ret = false;
		if (m_pDragListenerSet == NULL)
		{
			m_pDragListenerSet = new CDragListenerSet(this);
			HALO_ASSERT(m_pDragListenerSet);
		}
		ret = m_pDragListenerSet->Add(pAddListener);
		if (ret)
		{
			m_enableMouseEvent(true);
		}
		return ret;
	}

	bool CWidgetExtension::RemoveDragListener(IDragListener* pRemoveListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::RemoveDragListener.");
		HALO_ASSERT(NULL != pRemoveListener);

		bool ret = false;
		if (m_pDragListenerSet == NULL)
		{
			return false;
		}
		ret = m_pDragListenerSet->Remove(pRemoveListener);
		if (m_pDragListenerSet->Empty())
		{
			delete m_pDragListenerSet;
			m_pDragListenerSet = NULL;

			m_enableMouseEvent(false);
		}
		return ret;
	}

	//! Add gesture listener
	bool CWidgetExtension::AddGestureListener(IGestureListener* pAddListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::AddGestureListener.");
		HALO_ASSERT(NULL != pAddListener);

		bool ret = false;
		if (m_pGestureListenerSet == NULL)
		{
			m_pGestureListenerSet = new CGestureListenerSet(this);
			HALO_ASSERT(m_pGestureListenerSet);
		}
		ret = m_pGestureListenerSet->Add(pAddListener);
		return ret;
	}

	bool CWidgetExtension::RemoveGestureListener(IGestureListener* pRemoveListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::RemoveGestureListener.");
		HALO_ASSERT(NULL != pRemoveListener);

		bool ret = false;
		if (m_pGestureListenerSet == NULL)
		{
			return false;
		}
		ret = m_pGestureListenerSet->Remove(pRemoveListener);
		if (m_pGestureListenerSet->Empty())
		{
			delete m_pGestureListenerSet;
			m_pGestureListenerSet = NULL;

			m_enableMouseEvent(true);
		}
		return ret;
	}

	//! Add key long press listener
	bool CWidgetExtension::AddKeyLongPressListener(IKeyLongPressListener* pAddListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::AddKeyLongPressListener.");
		HALO_ASSERT(NULL != pAddListener);

		bool ret = false;
		if (m_pKeyLongPressListenerSet == NULL)
		{
			m_pKeyLongPressListenerSet = new CKeyLongPressListenerSet(this);
			HALO_ASSERT(m_pKeyLongPressListenerSet);
		}
		ret = m_pKeyLongPressListenerSet->Add(pAddListener);
		return ret;
	}

	bool CWidgetExtension::RemoveKeyLongPressListener(IKeyLongPressListener* pRemoveListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::RemoveKeyLongPressListener.");
		HALO_ASSERT(NULL != pRemoveListener);

		bool ret = false;
		if (m_pKeyLongPressListenerSet == NULL)
		{
			return false;
		}
		ret = m_pKeyLongPressListenerSet->Remove(pRemoveListener);
		if (m_pKeyLongPressListenerSet->Empty())
		{
			delete m_pKeyLongPressListenerSet;
			m_pKeyLongPressListenerSet = NULL;
		}
		return ret;
	}

	bool CWidgetExtension::AddKeyCombinationListener(IKeyCombinationListener* pAddListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::AddKeyCombinationListener.");
		HALO_ASSERT(NULL != pAddListener);

		bool ret = false;
		if (m_pKeyCombinationListenerSet == NULL)
		{
			m_pKeyCombinationListenerSet = new CKeyCombinationListenerSet(this);
			HALO_ASSERT(m_pKeyCombinationListenerSet);
		}
		ret = m_pKeyCombinationListenerSet->Add(pAddListener);
		return ret;
	}

	bool CWidgetExtension::RemoveKeyCombinationListener(IKeyCombinationListener* pRemoveListener)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::RemoveKeyCombinationListener.");
		HALO_ASSERT(NULL != pRemoveListener);

		bool ret = false;
		if (m_pKeyCombinationListenerSet == NULL)
		{
			return false;
		}
		ret = m_pKeyCombinationListenerSet->Remove(pRemoveListener);
		if (m_pKeyCombinationListenerSet->Empty())
		{
			delete m_pKeyCombinationListenerSet;
			m_pKeyCombinationListenerSet = NULL;
		}
		return ret;
	}

	//! Add/Remove cursor Listener
	bool CWidgetExtension::AddCursorListener(ICursorListener* pAddListener)
	{
		H_LOG_DEBUG(LOGGER, "CActor::AddCursorListener.");
		HALO_ASSERT(NULL != pAddListener);

		if (m_pCursorListenerSet == NULL)
		{
			m_pCursorListenerSet = new CCursorListenerSet(this);
			HALO_ASSERT(m_pCursorListenerSet);
		}
		return m_pCursorListenerSet->Add(pAddListener);
	}

	bool CWidgetExtension::RemoveCursorListener(ICursorListener* pRemoveListener)
	{
		H_LOG_DEBUG(LOGGER, "CActor::RemoveCursorListener.");
		HALO_ASSERT(NULL != pRemoveListener);

		bool ret = false;
		if (m_pCursorListenerSet == NULL)
		{
			return false;
		}
		ret = m_pCursorListenerSet->Remove(pRemoveListener);
		if (m_pCursorListenerSet->Empty())
		{
			delete m_pCursorListenerSet;
			m_pCursorListenerSet = NULL;
		}
		return ret;
	}

	//! Grab event
	void CWidgetExtension::GrabDeviceEvent(IDevice *device)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::GrabDeviceEvent.");
		HALO_ASSERT(NULL != device);
		HALO_ASSERT(m_flagInit);

		int id = device->DeviceId();
		ClutterDeviceManager *manager = clutter_device_manager_get_default();

		ClutterInputDevice *clutterDivice = clutter_device_manager_get_device(manager, id);

		clutter_input_device_grab(clutterDivice, t_widgetSelf->getAnimationActor());

	}

	void CWidgetExtension::UnGrabDeviceEvent(IDevice *device)
	{
		H_LOG_DEBUG(LOGGER, "WidgetExtension::UnGrabDeviceEvent.");
		HALO_ASSERT(NULL != device);

		int id = device->DeviceId();
		ClutterDeviceManager *manager = clutter_device_manager_get_default();
		ClutterInputDevice *clutterDivice = clutter_device_manager_get_device(manager, id);

		clutter_input_device_ungrab(clutterDivice);
	}

	//const char* WidgetExtension::GetActorType(void)
	//{
	//	return "Actor";
	//}

	void CWidgetExtension::m_Destroy(ClutterActor* actor, CWidgetExtension *pThis)
	{
		delete pThis;
	}

	gboolean CWidgetExtension::m_CapturedEventCb(ClutterActor* actor, ClutterEvent* event, CWidgetExtension* pThis)
	{
		switch (event->type)
		{
		case CLUTTER_KEY_PRESS:
		case CLUTTER_KEY_RELEASE:
		{
			CKeyboardEvent evt(event);
			pThis->m_OnCapturedKeyboard(&evt);
		}
			break;
		case CLUTTER_ENTER:
		case CLUTTER_LEAVE:
		case CLUTTER_MOTION:
		case CLUTTER_SCROLL:
		case CLUTTER_BUTTON_PRESS:
		case CLUTTER_BUTTON_RELEASE:
		{
			CMouseEvent evt(event);
			pThis->m_OnCapturedMouse(&evt);
		}
			break;
		default:
			break;
		}

		return CLUTTER_EVENT_PROPAGATE;
	}

	gboolean CWidgetExtension::m_EventCb(ClutterActor* actor, ClutterEvent* event, CWidgetExtension* pThis)
	{
		switch (event->type)
		{
		case CLUTTER_KEY_PRESS:
		case CLUTTER_KEY_RELEASE:
		{
			CKeyboardEvent evt(event);
			pThis->OnEvent(&evt);
		}
			break;
		case CLUTTER_ENTER:
		case CLUTTER_LEAVE:
		case CLUTTER_MOTION:
		case CLUTTER_SCROLL:
		case CLUTTER_BUTTON_PRESS:
		case CLUTTER_BUTTON_RELEASE:
		{
			CMouseEvent evt(event);
			pThis->OnEvent(&evt);

			if (event->type == CLUTTER_ENTER && pThis->m_enblePointerFocus == true)
			{
				// For supporting pointer_in focus automatically. 
				pThis->SetFocus();
			}
		}
			break;
		default:
			break;
		}

		return CLUTTER_EVENT_PROPAGATE;
	}

	gboolean CWidgetExtension::m_KeyFocusInCb(ClutterActor* actor, CWidgetExtension *pThis)
	{
		CFocusManager* pFocusManager = CFocusManager::GetInstance();

		if (pFocusManager)
		{
			if (pFocusManager->FocusedWindow() != pThis)
			{
				pFocusManager->SetFocusBySignal(pThis);
			}
		}

		return CLUTTER_EVENT_PROPAGATE;
	}

	gboolean CWidgetExtension::m_KeyFocusOutCb(ClutterActor* actor, CWidgetExtension *pThis)
	{
		CFocusManager* pFocusManager = CFocusManager::GetInstance();

		if (pFocusManager)
		{
			if (pFocusManager->FocusedWindow() == pThis)
			{
				pFocusManager->KillFocusBySignal(pThis);
			}
		}

		return CLUTTER_EVENT_PROPAGATE;
	}

	bool CWidgetExtension::m_OnMouse(IMouseEvent* pEvent)
	{
		if (m_pMouseListenerSet)
		{
			return m_pMouseListenerSet->Process(pEvent, E_HALO_EVENT_ROUTINE_BUBBLE);
		}
		return false;
	}

	bool CWidgetExtension::m_OnKeyboard(IKeyboardEvent* pEvent)
	{
		if (m_pKeyboardListenerSet)
		{
			m_pKeyboardListenerSet->Process(pEvent, E_HALO_EVENT_ROUTINE_BUBBLE);
		}
		if (IsFocused()&& pEvent->IsEventType("samsung.tv.halo.input.keyrelease"))
		{
			switch (pEvent->GetKeyVal())
			{
			case CLUTTER_KEY_Left:
				MoveTab(DIRECTION_LEFT);
				break;
			case CLUTTER_KEY_Right:
				MoveTab(DIRECTION_RIGHT);
				break;
			case CLUTTER_KEY_Up:
				MoveTab(DIRECTION_UP);
				break;
			case CLUTTER_KEY_Down:
				MoveTab(DIRECTION_DOWN);
				break;
#ifndef WIN32				
			case CLUTTER_KEY_Return:
				IAudioUI::GetInstance()->Play(SELECT);
				break;
			case CLUTTER_KEY_Back:
				IAudioUI::GetInstance()->Play(CANCEL);
				break;
#endif
			default:
				break;
			}
		}
		return false;
	}

	bool CWidgetExtension::m_OnRemocon(const IRemoconEvent* pEvent)
	{
		return false;
	}

	bool CWidgetExtension::m_OnTouch(const ITouchEvent* pEvent)
	{
		return false;
	}

	bool CWidgetExtension::m_OnRidge(const IRidgeEvent* pEvent)
	{
		return false;
	}

	bool CWidgetExtension::m_OnMotion(const IMotionEvent* pEvent)
	{
		return false;
	}

	bool CWidgetExtension::m_OnSensor(const ISensorEvent* pEvent)
	{
		return false;
	}

	bool CWidgetExtension::m_OnCursor(const ICursorEvent* pEvent)
	{
		return false;
	}

	//! Process captured keyboard event
	bool CWidgetExtension::m_OnCapturedKeyboard(IKeyboardEvent* pEvent)
	{
		if (m_pKeyboardListenerSet)
		{
			return m_pKeyboardListenerSet->Process(pEvent, E_HALO_EVENT_ROUTINE_CAPTURED);
		}

		return false;
	}

	//add
	bool CWidgetExtension::m_OnCapturedMouse(IMouseEvent* pEvent)
	{
		if (m_pMouseListenerSet)
		{
			return m_pMouseListenerSet->Process(pEvent, E_HALO_EVENT_ROUTINE_CAPTURED);
		}

		return false;
	}

	bool CWidgetExtension::m_enableMouseEvent(bool flagEnabled, bool enforce)
	{
		if (flagEnabled)
		{
			if (enforce || m_pMouseListenerSet || m_pClickListenerSet || m_pDragListenerSet || m_pGestureListenerSet || m_enblePointerFocus || m_dragEnabled)
			{
				clutter_actor_set_reactive(t_widgetSelf->getAnimationActor(), true);
				return true;
			}
		}
		else
		{
			if (enforce || (m_pMouseListenerSet == NULL && m_pClickListenerSet == NULL && m_pDragListenerSet == NULL && m_pGestureListenerSet == NULL && m_enblePointerFocus == false && m_dragEnabled == false))
			{
				clutter_actor_set_reactive(t_widgetSelf->getAnimationActor(), false);
				return true;
			}
		}

		return false;
	}

	void CWidgetExtension::t_NoticeActorFocusIn(CWidgetExtension *actor)
	{
		if (true == m_flagFirstFocusIn)
		{
			WidgetHelperListenerSet::TActorListenerData data;
			data.type = EVENT_FIRST_FOCUSIN;

			if (NULL != m_pWidgetHelperListenerSet)
			{
				m_pWidgetHelperListenerSet->Process(&data);
			}
		}

		m_flagFirstFocusIn = false;
	}

	float CWidgetExtension::t_1920ConvertMultiResolution(float value) const
	{
		float x = value;
		if (m_bEnableCovertResolution)
		{
			//! Multi resolution
			IUtility::EResolution res = IUtility::RESOLUTION_1080;
			res = IUtility::GetInstance()->GetCurrentResolution();		
			if (IUtility::RESOLUTION_720 == res)
			{
				x /= 1.5f;  // radio = 1280.0f/1920.0f
			}
		}

		return (float)(int)(x + 0.5f);
	}

	float CWidgetExtension::t_MultiResolutionConvert1920(float value) const
	{
		float x = value;
		if (m_bEnableCovertResolution)
		{
			//! Multi resolution
			IUtility::EResolution res = IUtility::RESOLUTION_1080;
			res = IUtility::GetInstance()->GetCurrentResolution();		
			if (IUtility::RESOLUTION_720 == res)
			{
				x = 1.5f*x;   // radio = 1920.0f/1280.0f
			}
		}

		return x;
	}

	bool CWidgetExtension::GetResolutionFlag(void)
	{
		return m_bEnableCovertResolution;
	}

	void CWidgetExtension::SetResolutionFlag(bool flag)
	{
		m_bEnableCovertResolution = flag;
	}
}


