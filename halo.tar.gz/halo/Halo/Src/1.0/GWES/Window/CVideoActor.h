#if !defined(WIN32) && !defined(LINUX_BUILD)
#ifndef _HALO_CVIDEOACTOR_H_
#define _HALO_CVIDEOACTOR_H_

namespace HALO
{

	class CVideoActor : virtual public IVideoActor, public CActor
	{
	public:
		CVideoActor(void);			
		virtual ~CVideoActor(void);

		bool Initialize(IActor* parent, float width, float height, ClutterVideoController type);
		bool Initialize(Widget* parent, float width, float height, ClutterVideoController type);
		
		/** Width (pixels) */
		virtual float getWidth() const;
		virtual void setWidth(float width);

		/** Width (height) */
		virtual float getHeight() const;
		virtual void setHeight(float height);

		/** Show & hide */
		virtual void Show(void);
		virtual void Hide(void);

		void SetVideoType(const ClutterVideoController type);
		ClutterVideoController VideoType(void) const;

	public:
	    //These APIs are only for MM source
		void SetUri(const std::string& uri);
		std::string Uri(void) const;	
		int Play(void);	
		int Stop(void);	
		int Pause(void);	
		ClutterVideoControllerState PlayerState(void) const;

		virtual bool AddListener(IVideoActorListener* listener);
		virtual bool RemoveListener(IVideoActorListener* listener);

		enum E_VideoPlayerEventType		
		{			
			EVENT_VIDEO_PLAY_COMPLETE = 0,		//!< return key clicked event			
					
			EVENT_VIDEO_PLAY_MAX,				//!< last button event type identifier.		
		};
					
	protected:
		virtual ClutterActor* t_CreateActor(void);
	
	private:

		static void m_VideoPlayerCompletedCb(ClutterVideo *self, gpointer data);
		
		ClutterVideoController m_videoType;
		std::string m_uri;
		class CVideoActorListenerSet* m_listenerSet;
		int m_videoPlayCompletedId;
	};
}
#endif
#endif
