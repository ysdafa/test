#ifndef WIN32
#ifndef _HALO_CVIDEOACTOR_H_
#define _HALO_CVIDEOACTOR_H_

namespace HALO
{

	class CVideoActor : virtual public IVideoActor, public CActor
	{
	public:
		CVideoActor(void);			
		virtual ~CVideoActor(void);

		bool Initialize(IActor* parent, float width, float height, ClutterVideoController type);
		bool Initialize(Widget* parent, float width, float height, ClutterVideoController type);
		
		/** Width (pixels) */
		virtual float getWidth() const;
		virtual void setWidth(float width);

		/** Width (height) */
		virtual float getHeight() const;
		virtual void setHeight(float height);

		/** Show & hide */
		virtual void Show(void);
		virtual void Hide(void);

		void SetVideoType(const ClutterVideoController type);
		ClutterVideoController VideoType(void) const;

	public:
	    //These APIs are only for MM source
		void SetUri(const std::string& uri);
		std::string Uri(void) const;	
		int Play(void);	
		int Stop(void);	
		int Pause(void);	
		ClutterVideoControllerState PlayerState(void) const;
					
	protected:
		virtual ClutterActor* t_CreateActor(void);
	
	private:
		ClutterVideoController m_videoType;
		std::string m_uri;
	};
}
#endif
#endif
