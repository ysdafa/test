#ifndef _HALO_CSTAGE_H_
#define _HALO_CSTAGE_H_

namespace HALO
{
	class CStage : public IStage
	{
	public:
		CStage();
		
		virtual void SetSize(float width, float height);
		virtual void GetSize(float &width, float &height);
		virtual void UseExternalStage(ClutterActor* stage);
		virtual bool IsUsingExternalStage(void) {return m_usedExternalStage;}

		//!Set cursor show/hide
		virtual void ShowCursor(void);
		virtual void HideCursor(void);
	
	public:
		virtual void Create(float width, float height);
		virtual void Destroy();
		IActor* RootActor(void) { return m_rootActor; }
		ClutterActor* Stage(void) {return m_stage;}

		/******************************************
		void EnableFPSShown(bool enable);
		void SetFPSShownInterval(double sec);
		void SetFPSLabelFont(const char*fontName);
		*******************************************/
		void DlogObjectDump(void);
	private:
		//static void m_StageReDrawCb(ClutterActor* actor, gpointer user_data);

		static void m_DlogObjectDump(ClutterStage* stage);
		static void m_TraverseRecursive(Widget* actor, int layer); 
		static void m_DlogPrint(Widget* widget, int layer);	

#ifdef WIN32
		static void m_ObjectDump_cb (ClutterStage *stage, int printMethod);
#else
		static void m_ObjectDump_cb (ClutterStage *stage, ClutterObjectDumpPrintMethod printMethod);
#endif

	private:
		ClutterActor* m_stage;
		CActor* m_rootActor;
		float m_resWidth;
		float m_resHeight;
		bool m_usedExternalStage;
		/******************************************
		guint m_redrawId;
		int m_fps;
		GTimer *m_fpsTimer;
		TextWidget * m_fpsLabel;
		bool m_enableFPSShown;
		double m_fpsShownInterval;
		ClutterAction *m_dragAction;
		*******************************************/
	};
}


#endif
