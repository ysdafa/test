#include "Halo1_0.h"
#include "VoltFullProcessRuntime.h"
#include "VoltProcessRuntime.h"

#ifndef WIN32
#include <dlog.h>
#endif

/*#ifdef  LOG_TAG
#undef  LOG_TAG
#endif
#define LOG_TAG "HALO_OBJECTDUMP"
#define _DBG(fmt, args...) LOGD(fmt"\n", ##args)*/

namespace HALO
{
	extern CEventManager* g_pEventManager;
	extern gboolean StageEventFilter(const ClutterEvent* event, gpointer user_data);
	extern guint g_preprocessFilter;

	std::vector<guint> g_stageEvents;

	static HALO::util::Logger LOGGER("Stage");

	CStage::CStage() : m_stage(NULL), m_resWidth(1920), m_resHeight(1080), m_usedExternalStage(false)/*, m_redrawId(0), m_fps(0), m_fpsTimer(NULL), m_fpsLabel(NULL), m_enableFPSShown(false), m_fpsShownInterval(0.3), m_dragAction(NULL)*/
	{
		g_stageEvents.clear();
	}

	void CStage::SetSize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CStage::SetSize (" << width << ", " << height << ")");
		clutter_actor_set_size(m_stage, width, height);
	}

	void CStage::GetSize(float &width, float &height)
	{	
		clutter_actor_get_size(m_stage, &width, &height);
		H_LOG_TRACE(LOGGER, "CStage::GetSize (" << width << ", " << height << ")");
	}

	void Quit(void)
	{
		H_LOG_TRACE(LOGGER, "Quit");
		CSystemEvent event;
		event.SetEventType("samsung.tv.halo.system.quit");
		g_pEventManager->SendEventLocal(&event);
	}

	void CStage::UseExternalStage(ClutterActor* stage)
	{
		H_LOG_TRACE(LOGGER, "CStage::UseExternalStage " << stage);
		if (m_stage == stage)
		{
			return;
		}
		else
		{
			Destroy();
		}

		m_stage = stage;
		clutter_event_remove_preprocess_filter(g_preprocessFilter);
		g_preprocessFilter = clutter_event_add_preprocess_filter(CLUTTER_STAGE(m_stage), StageEventFilter, NULL, g_pEventManager);

		GetSize(m_resWidth, m_resHeight);

		m_rootActor = new CActor;
		m_rootActor->Initialize(m_stage, 0, 0);
		
		clutter_actor_show(CLUTTER_ACTOR(m_stage));
		m_rootActor->Show();

		/**************************************************************************************
		m_fpsLabel = new TextWidget(0, 0, " fps:    ", "Sans 20px", nullptr, *CLUTTER_COLOR_Black);
		if (m_fpsLabel != NULL)
		{
			ClutterActor *_actor = m_fpsLabel->getAnimationActor(InvalidAnimation);
			clutter_actor_add_child(m_stage, _actor);
			m_fpsLabel->setColor(*CLUTTER_COLOR_Cyan);
			m_fpsLabel->setOpacity(200);
			if (!m_enableFPSShown)
			{
				m_fpsLabel->hide();
			}

			clutter_actor_set_reactive(_actor, TRUE);
			m_dragAction = clutter_drag_action_new();
			clutter_actor_add_action(_actor, m_dragAction);
		}
		************************************************************************************/

		gulong handler = g_signal_connect(m_stage, "delete-event", G_CALLBACK(Quit), NULL);
		g_stageEvents.push_back(handler);

		/*********************************************************************************
		if (m_enableFPSShown)
		{
			m_redrawId = g_signal_connect(m_stage, "paint", G_CALLBACK(m_StageReDrawCb), this);
		}
		********************************************************************************/

		m_usedExternalStage = true;

		gulong dumpId = g_signal_connect(m_stage, "objectdump", G_CALLBACK(m_ObjectDump_cb), NULL);	
		g_stageEvents.push_back(dumpId);
	}

	void CStage::Create(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CStage::Create " << width << ", " << height);
		if (m_stage != NULL)
		{
			return;
		}

		m_stage = clutter_stage_new();
		g_preprocessFilter = clutter_event_add_preprocess_filter(CLUTTER_STAGE(m_stage), StageEventFilter, NULL, g_pEventManager);

		clutter_actor_set_size(m_stage, width, height);
		m_resWidth = width;
		m_resHeight = height;

		ClutterColor color = {0, 0, 0, 0};

		clutter_stage_set_use_alpha(CLUTTER_STAGE(m_stage), true);
		clutter_actor_set_background_color(m_stage, &color);
		clutter_actor_queue_redraw(m_stage);

		m_rootActor = new CActor;
		m_rootActor->Initialize(m_stage, 0, 0);

		clutter_actor_show(CLUTTER_ACTOR(m_stage));
		m_rootActor->Show();

		/***************************************************************************************
		m_fpsLabel = new TextWidget(0, 0, " fps:    ", "Sans 20px", nullptr, *CLUTTER_COLOR_Black);
		if (m_fpsLabel != NULL)
		{
			ClutterActor *_actor = m_fpsLabel->getAnimationActor(InvalidAnimation);
			clutter_actor_add_child(m_stage, _actor);
			m_fpsLabel->setColor(*CLUTTER_COLOR_Cyan);
			m_fpsLabel->setOpacity(200);
			if (!m_enableFPSShown)
			{
				m_fpsLabel->hide();
			}

			clutter_actor_set_reactive(_actor, TRUE);
			m_dragAction = clutter_drag_action_new();
			clutter_actor_add_action(_actor, m_dragAction);
		}
		**************************************************************************************/
		
		gulong handler = g_signal_connect(m_stage, "delete-event", G_CALLBACK(Quit), NULL);
		g_stageEvents.push_back(handler);

		/**********************************************************
		if (m_enableFPSShown)
		{
			m_redrawId = g_signal_connect(m_stage, "paint", G_CALLBACK(m_StageReDrawCb), this);
		}
		**********************************************************/

		m_usedExternalStage = false;
		//g_signal_connect (m_stage, "destroy", G_CALLBACK (::HaloFinalize), NULL);

		//! Object Dump
		gulong dumpId = g_signal_connect(m_stage, "objectdump", G_CALLBACK(m_ObjectDump_cb), NULL);	
		g_stageEvents.push_back(dumpId);
	}

	void CStage::Destroy()
	{
		H_LOG_TRACE(LOGGER, "CStage::Destroy START");
		if (!m_stage)
		{
			return;
		}

		if (m_stage)
		{
			for (auto iter = g_stageEvents.begin(); iter != g_stageEvents.end(); ++iter)
			{
				g_signal_handler_disconnect(m_stage, *iter);
				H_LOG_TRACE(LOGGER, "remove signal " << *iter);
			}
			g_stageEvents.clear();

			/*************************************************
			if (m_redrawId != 0)
			{
				g_signal_handler_disconnect(m_stage, m_redrawId);
				H_LOG_TRACE(LOGGER, "remove signal " << m_redrawId);
				m_redrawId = 0;
			}
			*************************************************/
		}
		
		/*****************************************************
		if (m_fpsLabel != NULL)
		{
			ClutterActor *_actor = m_fpsLabel->getAnimationActor(InvalidAnimation);
			if (m_dragAction)
			{
				clutter_actor_remove_action(_actor, m_dragAction);
				m_dragAction = NULL;
			}
			delete m_fpsLabel;
			m_fpsLabel = NULL;
		}
		******************************************************/
		m_rootActor->Release();
 		m_rootActor = NULL;

		/*******************************
		if (m_fpsTimer != NULL)
		{
			g_timer_destroy(m_fpsTimer);
			m_fpsTimer = NULL;
		}
		********************************/

		if (!m_usedExternalStage)
		{
			clutter_actor_destroy(CLUTTER_ACTOR(m_stage));
		}
		H_LOG_TRACE(LOGGER, "CStage::Destroy END");
	}

	void CStage::ShowCursor()
	{
		if (NULL != m_stage)
		{
			clutter_stage_show_cursor((ClutterStage*)m_stage);
		}		
	}

	void CStage::HideCursor()
	{
		if (NULL != m_stage)
		{
			clutter_stage_hide_cursor((ClutterStage*)m_stage);
		}		
	}

	/**************************************************************
	void CStage::EnableFPSShown(bool enable)
	{
		H_LOG_TRACE(LOGGER, "CStage::EnableFPSShown START");
		if (NULL == m_stage)
		{
			Create(800, 600);
		}

		m_enableFPSShown = enable;

		if (!enable)
		{
			if (m_redrawId != 0)
			{
				g_signal_handler_disconnect(m_stage, m_redrawId);
				m_redrawId = 0;
			}

			m_fpsLabel->hide();
		}
		else
		{
			m_redrawId = g_signal_connect(m_stage, "paint", G_CALLBACK(m_StageReDrawCb), this);

			m_fpsLabel->show();
		}
	}

	void CStage::SetFPSShownInterval(double sec)
	{
		H_LOG_TRACE(LOGGER, "CStage::SetFPSShownInterval sec = " << sec);
		if (NULL == m_stage)
		{
			Create(800, 600);
		}

		m_fpsShownInterval = sec;

		m_fps = 0;
		if (m_fpsTimer != NULL)
		{
			g_timer_start(m_fpsTimer);
		}
	}

	void CStage::SetFPSLabelFont(const char*fontName)
	{
		H_LOG_TRACE(LOGGER, "CStage::SetFPSLabelFont " << fontName);
		if (NULL == m_stage)
		{
			Create(800, 600);
		}

		m_fpsLabel->setFontName(fontName);
	}
	****************************************************************************/
	
	void CStage::DlogObjectDump(void)
	{
		H_LOG_TRACE(LOGGER, "CStage::DlogObjectDump ");
		m_DlogObjectDump((ClutterStage*)m_stage);
	}
	
	/****************************************************************************
	void CStage::m_StageReDrawCb(ClutterActor* actor, gpointer user_data)
	{
		CStage *stage = (CStage*)user_data;
		if (stage->m_fpsTimer == NULL)
		{
			stage->m_fpsTimer = g_timer_new();
		}

		if (actor == stage->m_stage)
		{
			stage->m_fps += 1;
		}

		if (g_timer_elapsed(stage->m_fpsTimer, NULL) >= stage->m_fpsShownInterval)
		{
			//printf("Interval:%f, m_fps:%3i, fps:%f\n", stage->m_fpsShownInterval, stage->m_fps, 1.0 / stage->m_fpsShownInterval);
			char buf[15] = { 0, };
			SNPRINTF(buf, 14, " fps:%3i ", (int)(stage->m_fps*(1.0 / stage->m_fpsShownInterval)));
			stage->m_fpsLabel->setText(buf);

			stage->m_fps = 0;
			g_timer_start(stage->m_fpsTimer);
		}
	}
	***********************************************************************************/

#ifdef WIN32
	void CStage::m_ObjectDump_cb(ClutterStage *stage, int printMethod)
#else
	void CStage::m_ObjectDump_cb(ClutterStage *stage, ClutterObjectDumpPrintMethod printMethod)
#endif
	{
		//printf("%%%%%%%%%%%%%%%%%%%%CStage::m_ObjectDump_cb printMethod = %d&&&&&&&&&&&&&&&&\n", (int)printMethod);
		H_LOG_TRACE(LOGGER, "CStage::m_ObjectDump_cb(" << stage << ", " << printMethod << ")");
		switch(printMethod)
		{
#ifndef WIN32
		case OBJECT_DUMP_METHOD_FILE:
		   //m_FileObjectDump(stage);
		break;
		case OBJECT_DUMP_METHOD_DLOG:		   
#endif
		default:
			m_DlogObjectDump(stage);
		break;
		}
	}

	void CStage::m_DlogObjectDump(ClutterStage *stage)
	{
		//! Start tag
		std::ostringstream start, end;
		start << std::endl;
		start << ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> START OBJECT DUMP >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" << std::endl;
#ifdef WIN32
		printf(start.str().c_str());
#else
		__dlog_print(LOG_ID_MAIN, DLOG_DEBUG, "HALO_OBJECTDUMP", "%s", start.str().c_str());
#endif

		//! Stage
		gfloat width, height;
		clutter_actor_get_size(CLUTTER_ACTOR(stage), &width, &height);
		const char *name = clutter_actor_get_name(CLUTTER_ACTOR(stage));
		std::ostringstream os;
		//printf("%%%%%%%%%%%%%%%%%%%%   CStage: stage name = %s   &&&&&&&&&&&&&&&&\n", name);
		if (name != NULL)
		{
			os << "[" << "Stage" << ", " << "\"" << name << "\"" << ", " << stage << ", " << "(" << 0 << "," << 0 << "," << width << "," << height  << ")" << "]" << std::endl;
		} 
		else
		{
			os << "[" << "Stage" << ", " << "\"\"" << ", " << stage << ", " << "(" << 0 << "," << 0 << "," << width << "," << height  << ")" << "]" << std::endl;
		}
		
#ifdef WIN32
		printf(os.str().c_str());
#else
		__dlog_print(LOG_ID_MAIN, DLOG_DEBUG, "HALO_OBJECTDUMP", "%s", os.str().c_str());
#endif
//const char *out = os.str().c_str();
//_DBG("%s", (char *)out);


		//! Actors
		VoltFullProcessRuntime *runtime = static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

		SceneRoot* root = runtime->GetSceneRoot();
		ASSERT(root);
		uint count = root->getChildCount();
		int layer = 0;

		//if (root)
		//{
		//	//! Layer 1
		//	for (uint i = 0; i < count; ++i)
		//	{
		//		Widget* actor = dynamic_cast<Widget*>(root->getChildByIndex(i));
		//		m_DlogPrint(actor, layer, i);	
		//		m_TraverseRecursive(actor, layer);
		//	}
		//}
		Widget* widget = dynamic_cast<Widget*>(root);
		m_TraverseRecursive(widget, layer);

		//! End tag
		end << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< END OBJECT DUMP <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl;
#ifdef WIN32
		printf(end.str().c_str());
#else
		__dlog_print(LOG_ID_MAIN, DLOG_DEBUG, "HALO_OBJECTDUMP", "%s", end.str().c_str());
#endif
	}

	void CStage::m_TraverseRecursive(Widget* widget, int layer)
	{
		ASSERT(widget);
		uint count = widget->getChildCount();
		layer++;
		for (uint i = 0; i < count; ++i)
		{
			Widget* child = dynamic_cast<Widget*>(widget->getChildByIndex(i));
			m_DlogPrint(child, layer);
			m_TraverseRecursive(child, layer);
		}
	}

	void CStage::m_DlogPrint(Widget* widget, int layer)
	{
		if (widget == NULL)
		{
			return;
		}
		
		std::ostringstream os;
		for (int j = 0; j < layer; ++j)
		{
			//! 4 space
			os << "    ";
		}			

		ClutterActor* clutterActor = widget->getAnimationActor();
		//! Judge widget if focusable
		bool bFocusable = clutter_actor_get_reactive(clutterActor);
		const char *cFocusable = bFocusable == true ? "FA" : "Non-FA";
		//! Judge widget if focused
		//VoltFullProcessRuntime *runtime = static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());
		//SceneRoot* root = runtime->GetSceneRoot();
		//Widget *focusWidget = root->getKeyFocus();
		//char *cFocused = widget == focusWidget ? "Focused" : "-";
		ClutterStage *stage = CLUTTER_STAGE(IStage::GetInstance()->Stage());
		ClutterActor *focusActor= clutter_stage_get_key_focus(stage); 
		const char *cFocused = clutterActor == focusActor ? "Focused" : "-";

		//! Properties
		const char *clutterName = clutter_actor_get_name(clutterActor);
		float x, y, width, height;
		x = widget->getX();
		y = widget->getY();
		width = widget->getWidth();
		height = widget->getHeight();


		ImageWidget *imageWidget = dynamic_cast<ImageWidget*>(widget);
		TextWidget *textWidget = dynamic_cast<TextWidget*>(widget);
		CActor *actor = dynamic_cast<CActor*>(widget);
		
		//! ImageWidget
		if (imageWidget != NULL)
		{
			std::string source = imageWidget->getSource();
			const char *str = source.data();
			if (str != NULL)
			{
				if (clutterName != NULL)
				{
					os << "[" << "ImageWidget" << ", " << "\"" << clutterName << "\"" << ", " << imageWidget << ", " << "\"" << str << "\"" << ", " << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
				}
				else
				{
					os << "[" << "ImageWidget" << ", " << "\"\"" << ", " << imageWidget << ", " << "\"" << str << "\"" << ", " << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
				}
			} 
			else
			{
				if (clutterName != NULL)
				{
					os << "[" << "ImageWidget" << ", " << "\"" << clutterName << "\"" << ", " << imageWidget << ", " << "\"\"" << ", " << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
				}
				else
				{
					os << "[" << "ImageWidget" << ", " << "\"\"" << ", " << imageWidget << ", " << "\"\"" << ", " << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
				}
			}	
		}
		//! TextWidget
		else if (textWidget != NULL)
		{
			std::string source = textWidget->getText();
			const char *str = source.data();
			if (str != NULL)
			{
				if (clutterName != NULL)
				{
					os << "[" << "TextWidget" << ", " << "\"" << clutterName << "\"" << ", " << textWidget << ", " << "\"" << str << "\"" << ", "  << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
				}
				else
				{
					os << "[" << "TextWidget" << ", " << "\"\"" << ", " << textWidget << ", " << "\"" << str << "\"" << ", "  << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
				}				
			} 
			else
			{
				if (clutterName != NULL)
				{
					os << "[" << "TextWidget" << ", " << "\"" << clutterName << "\"" << ", " << textWidget << ", " << "\"\"" << ", "  << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
				} 
				else
				{
					os << "[" << "TextWidget" << ", " << "\"\"" << ", " << textWidget << ", " << "\"\"" << ", "  << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
				}				
			}				
		}			
		//! CActor and derived class
		else if (actor != NULL)
		{
			const char *name = actor->GetActorType();
		   	if (name != NULL)
			{
				if (strcmp(name, "Text") == 0)
				{
					CText *text = dynamic_cast<CText*>(widget);
					if (text == NULL)
					{
						return;
					}
					if (text->Text())
					{
						if (clutterName != NULL)
						{
							os << "[" << name << ", " << "\"" << clutterName << "\"" << ", " << widget << ", " << "\"" << text->Text() << "\"" << ", " << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
						} 
						else
						{
							os << "[" << name << ", " << "\"\"" << ", " << widget << ", " << "\"" << text->Text() << "\"" << ", " << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
						}						
					}
					else
					{
						if (clutterName != NULL)
						{
							os << "[" << name << ", " << "\"" << clutterName << "\"" << ", " << widget << ", " << "\"\"" << ", "  << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
						} 
						else
						{
							os << "[" << name << ", " << "\"\"" << ", " << widget << ", " << "\"\"" << ", "  << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
						}						
					}
				}
				else if (strcmp(name, "Image") == 0)
				{
					CImage *image = dynamic_cast<CImage*>(widget);
					if (image == NULL)
					{
						return;
					}
					if (image->ImagePath())
					{
						if (clutterName != NULL)
						{
							os << "[" << name << ", " << "\"" << clutterName << "\"" << ", " << widget << ", " << "\"" << image->ImagePath() << "\"" << ", " << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
						} 
						else
						{
							os << "[" << name << ", " << "\"\"" << ", " << widget << ", " << "\"" << image->ImagePath() << "\"" << ", "  << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
						}
						
					}	
					else
					{
						if (clutterName != NULL)
						{
							os << "[" << name << ", " << "\"" << clutterName << "\"" << ", " << widget << ", " << "\"\"" << ", " << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
						} 
						else
						{
							os << "[" << name << ", " << "\"\"" << ", " << widget << ", " << "\"\"" << ", " << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
						}						
					}
				}
				else if (strcmp(name, "CompositeImage") == 0)
				{
					CCompositeImage *image = dynamic_cast<CCompositeImage*>(widget);
					if (image == NULL)
					{
						return;
					}
					if (image->ImagePath() != NULL)
					{
						if (clutterName != NULL)
						{
							os << "[" << name << ", " << "\"" << clutterName << "\"" << ", " << widget << ", " << "\"" << image->ImagePath() << "\"" << ", " << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
						} 
						else
						{
							os << "[" << name << ", " << "\"\"" << ", " << widget << ", " << "\"" << image->ImagePath() << "\"" << ", " << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
						}
						
					}
					else
					{
						if (clutterName != NULL)
						{
							os << "[" << name << ", " << "\"" << clutterName << "\"" << ", " << widget << ", " << "\"\"" << ", " << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
						} 
						else
						{
							os << "[" << name << ", " << "\"\"" << ", " << widget << ", " << "\"\"" << ", "  << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
						}						
					}
				}
				else
				{
					if (clutterName != NULL)
					{
						os << "[" << name << ", " << "\"" << clutterName << "\"" << ", " << widget << ", " << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
					} 
					else
					{
						os << "[" << name << ", " << "\"\"" << ", " << widget << ", " << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
					}					
				}
		   	}
			else
			{
				os << "[" << "\"\"" << ", " << widget << ", "  << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
			}
		}	
		//! Wdiget with name 
		else if (widget && clutterName && strcmp(clutterName, "") != 0)
		{
			os << "[" << "Widget" << ", " << "\"" << clutterName << "\"" << ", " << widget << ", "  << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
		}
		//! Widget but no name
		else if (widget && clutterName && strcmp(clutterName, "") == 0)
		{
			os << "[" << "Widget" << ", " << "\"\"" << ", " << widget << ", "  << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
		}
		else
		{
			os << "[" << "\"\"" << ", " << widget << ", "  << cFocusable << ", " << cFocused << ", " << "(" << x << "," << y << "," << width << "," << height  << ")" << "]" << std::endl;
		}
		
#ifdef WIN32
		printf(os.str().c_str());
#else
		__dlog_print(LOG_ID_MAIN, DLOG_DEBUG, "HALO_OBJECTDUMP", "%s", os.str().c_str());
#endif
//const char *out = os.str().c_str();
//_DBG("%s", (char *)out);
	}
}


