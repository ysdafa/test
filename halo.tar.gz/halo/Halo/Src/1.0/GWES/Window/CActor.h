#ifndef _HALO_CACTOR_H_
#define _HALO_CACTOR_H_

namespace HALO
{
	class CEvent;
	class CKeyboardEvent;
	class CMouseEvent;
	class CTouchEvent;
	class CRemoconEvent;
	class CRidgeEvent;
	class CMotionEvent;
	class CSensorEvent;
	class CCursorEvent;
	class CAnimatable;

	class CActorListenerSet : public ListenerSet
	{
	public:
		struct TActorListenerData
		{
			int type;
			int param[4];
			void* pData;
		};

		CActorListenerSet(CActor* owner) :m_owner(owner){};
		virtual ~CActorListenerSet(void){};

		virtual bool Process(TActorListenerData* data);

	private:
		CActor* m_owner;
	};

	class CActorFocusListener : public IFocusListener
	{
	public:
		CActorFocusListener(class CActor* owner) : m_owner(owner) {}

		virtual bool OnFocusIn(IActor* pWindow);
		virtual bool OnFocusOut(IActor* pWindow);

	protected:

	private:
		class CActor* m_owner;
	};

	class CActor : virtual public IActor, public Widget, public CAnimatable
	{
	public:
		CActor(void);
		virtual ~CActor(void);

		enum EActorListenerType
		{
			EVENT_FIRST_FOCUSIN = 0,
			EVENT_ACTOR_MAX
		};

		bool Initialize(ClutterActor* parent, float width, float height); // For only rootActor
		bool Initialize(Widget* parent, float width, float height);
		bool Initialize(IActor* parent, float width, float height);
		bool Initialize(IActor* parent, const TWindowAttr &attr);

		//! Sets the parent of window to @parent
		void SetParent(IActor* parent);
		//! Return the parent of this window
		IActor* Parent(void) const;

		//! Sets the background color of the window
		virtual void SetBackgroundColor(const ClutterColor &color);

		//! Resize current window
		virtual void Resize(float width, float height);
		//! Gets the size of the window
		void GetSize(float &width, float &height);

		//! Sets the position relative to parent, and (0, 0, 0) presents left-top within parent
		void SetPosition(float x, float y, float z);
		//! Gets the position
		void GetPosition(float &x, float &y, float &z);
		//! Sets the position without changing z position, and (0, 0) presents left-top within parent
		void SetPosition(float x, float y);
		//! Gets the position of x,y
		void GetPosition(float &x, float &y);

		//! Sets the layout manager for this window to @layout
		virtual bool SetLayout(ILayout* layout);
		//! Return the layout manager that is installed on this window
		ILayout* Layout(void);
		//! Sets direction orientation
		virtual void SetOrientation(EOrientation orientation);
		//! Return the direction orientation
		EOrientation Orientation(bool flagReferParent = false);

		//! Shows the window
		virtual void Show(void);
		//! Hides the window and its child windows
		virtual void Hide(void);
		//! Checks whether the window is shown
		bool FlagShow(void);

		//! Sets whether the window should be clipped to the same size as its allocation
		virtual void EnableClipOverflow(bool enable);
		//! Retrieves the value set using EnableCropOverflow() 
		virtual bool IsClipOverflowEnabled(void);
		//! Sets clip area for the window
		void SetClipArea(float x, float y, float width, float height);
		//! Gets clip area for the window
		void GetClipArea(float &x, float &y, float &width, float &height);
		//! Removes clip area from the window
		void RemoveClipArea(void);
		//! Checks whether the window has a clip area or not
		bool FlagClip(void);

		//! Sets the window's opacity, with zero being completely transparent and 255 (0xff) being fully opaque. 
		void SetAlpha(int alpha);
		//! Retrieves the opacity value of a window
		int Alpha(void);

		//! Sets the position of the "pivot-point" around which the scaling and rotation transformations occur. value range (0.0 ~ 1.0)
		void SetPivotPoint(float xPivot, float yPivot, float zPivot);
		//! Gets the position of the "pivot-point"
		void GetPivotPoint(float &xPivot, float &yPivot, float &zPivot);
		//! Sets the rotation angle of a window
		void SetRotation(double xAngle, double yAngle, double zAngle);
		//! Gets the rotation angle of a window
		void GetRotation(double &xAngle, double &yAngle, double &zAngle);
		//! Scales a window with the given factors
		void SetScale(double xFactor, double yFactor, double zFactor);
		//! Retrieves a window's scale factors
		void GetScale(double &xFactor, double &yFactor, double &zFactor);

		//! Adds effect to window
		void AddEffect(IEffect* effect);
		//! Removes effect from window
		void RemoveEffect(IEffect* effect);
		//! Clear all effects that is installed on this window
		void ClearEffects(void);

		void AddChild(ClutterActor *actor);

		bool IsAncestor(IActor* actor);

		//! Retrieves the number of children
		int NumOfChildren(void);
		//! Retrieves the window at the given @index inside the list of children of the window
		IActor* GetChild(int index);
		//! Destroys all children of this window
		void DestroyAllChildren(void);

		//! Sets the window to be above @sibling who must have the same parent, if sibling is NULL, Raises this window to the top of the parent window's stack.
		bool Raise(IActor* sibling);
		//! Sets the window to be below @sibling who must have the same parent, if sibling is NULL, Lowers the window to the bottom of the parent window's stack.
		bool Lower(IActor* sibling);

		//! Sets whether the window can receive input events
		void Enable(bool flagEnable);
		//! Checks whether the window can receive input events
		bool IsEnabled(void);

		//! Focus the window when mouse pointer in if @enable is true
		void EnablePointerFocus(bool enable);
		//! Checks if the window auto focus when mouse pointer in
		bool IsPointerFocusEnabled(void);

		//! Sets whether the window can have focus.
		void EnableFocus(bool flagFocusable);
		//! Checks whether the window can set focus.
		bool IsFocusEnabled(void);

		//! Sets the window is focus-window.
		bool SetFocus(void);
		//! Kill the current-focus window and if @autoFocus is true, the focus will pass to the previous focus window.
		bool KillFocus(bool autoFocus = true);
		//! Checks whether the window is current focus-window.
		bool IsFocused(void);

		//! Sets the tab window at direction @dir
		void SetTabWindow(EDirection dir, IActor* tabWindow);
		//! Retrieves the tab window at direction @dir
		IActor* TabWindow(EDirection dir);
		//! Moves the focus to the window sets as the direction @dir tab window
		virtual bool MoveTab(EDirection dir);

		virtual TActionList* GetActionList(void);

		//! Add Focus Listener
		bool AddFocusListener(IFocusListener* pListener);
		//! Remove Focus Listener
		bool RemoveFocusListener(IFocusListener* pListener);

		virtual void AddTransition(CTransition *transition);
		virtual void RemoveTransition(CTransition *transition);

		//! Grab event
		virtual void GrabDeviceEvent(IDevice *device);
		virtual void UnGrabDeviceEvent(IDevice *device);

		virtual void GetAnimatableValue(int animationType, UValueElement &val);
		virtual void SetPropertyValue(int animationType, UValueElement element);

	public: //for internal use
		virtual ClutterActor* Actor(void);

	public:
		virtual bool OnEvent(IEvent* pEvent);

		//!Add/Remove mouse listeners
		virtual bool AddMouseListener(IMouseListener* pAddListener);
		virtual bool RemoveMouseListener(IMouseListener* pRemoveListener);

		//! Add/Remove Touch Listener
		virtual bool AddTouchListener(ITouchListener* pAddListener);
		virtual bool RemoveTouchListener(ITouchListener* pRemoveListener);

		//! Add/Remove Keyboard Listener
		virtual bool AddKeyboardListener(IKeyboardListener* pAddListener);
		virtual bool RemoveKeyboardListener(IKeyboardListener* pRemoveListener);

		//! Add/Remove Audio Listener
		virtual bool AddAudioListener(IAudioListener* pAddListener);
		virtual bool RemoveAudioListener(IAudioListener* pRemoveListener);

		//! Add/Remove RemoteControl Listener
		virtual bool AddRemoteControlListener(IRemoteControlListener* pAddListener);
		virtual bool RemoveRemoteControlListener(IRemoteControlListener* pRemoveListener);

		//! Add/Remove RemoteControl Listener
		virtual bool AddRidgeListener(IRidgeListener* pAddListener);
		virtual bool RemoveRidgeListener(IRidgeListener* pRemoveListener);

		//! Add/Remove ActorListener
		virtual bool AddActorListener(IActorListener *pActorListener);
		virtual bool RemoveActorListener(IActorListener *pActorListener);

		//! Add/Remove cursor Listener
		virtual bool AddCursorStateChangeListener(ICursorListener* pAddListener);
		virtual bool RemoveCursorStateChangeListener(ICursorListener* pRemoveListener);

		//! Add/Remove click Listener
		virtual bool AddClickListener(IClickListener* pAddListener);
		virtual bool RemoveClickListener(IClickListener* pRemoveListener);

		//! Add/Remove custom Listener
		virtual bool AddSemanticEventListener(ISemanticEventListener* pAddListener);
		virtual bool RemoveSemanticEventListener(ISemanticEventListener* pRemoveListener);

		//! Add/Remove Actions
		virtual bool AddAction(IAction* pAction);
		virtual bool RemoveAction(IAction* pAction);

		//! Add/Remove drag Listener
		virtual bool AddDragListener(IDragListener* pAddListener);
		virtual bool RemoveDragListener(IDragListener* pRemoveListener);

		//! Add/Remove gesture Listener
		virtual bool AddGestureListener(IGestureListener* pAddListener);
		virtual bool RemoveGestureListener(IGestureListener* pRemoveListener);

		//! Add/Remove key long press Listener
		virtual bool AddKeyLongPressListener(IKeyLongPressListener* pAddListener);
		virtual bool RemoveKeyLongPressListener(IKeyLongPressListener* pRemoveListener);

		//! Add/Remove key combination Listener
		virtual bool AddKeyCombinationListener(IKeyCombinationListener* pAddListener);
		virtual bool RemoveKeyCombinationListener(IKeyCombinationListener* pRemoveListener);
		
		virtual const char* GetPropertyName(int animationType, GType *valueType);

		//! Get actor type
		virtual const char* GetActorType(void);

	protected:
		virtual ClutterActor* t_CreateActor(void);
		virtual void t_FocusUnviewable(bool autoFocus = true);

		virtual bool t_AnimationIsValid(CTransition *animation, int animationType);
		virtual ClutterAnimatable *t_GetAnimatableObject(void);

		virtual void t_UpdateOrientation(EOrientation orientation);

		void t_AddNoticeActor(IActor *pNoticeActor);

		virtual void t_OnShow(void) {};
		virtual void t_OnHide(void) {};

		ClutterActor  *t_actor;

		bool  t_flagFocusable;

		void t_NoticeActorFocusIn(IActor *actor);

	private:
		static gboolean m_CapturedEventCb(ClutterActor *actor, ClutterEvent *event, CActor* pThis);
		static gboolean m_EventCb(ClutterActor *actor, ClutterEvent *event, CActor* pThis);
		static gboolean m_KeyFocusInCb(ClutterActor* actor, CActor *pThis);
		static gboolean m_KeyFocusOutCb(ClutterActor* actor, CActor *pThis);

		static void m_Destroy(ClutterActor* actor, CActor *pThis);

		guint m_destroyId;
		guint m_eventId;
		guint m_focusInId;
		guint m_focusOutId;
		guint m_capturedEventId;

		EOrientation m_orientation;
		bool  m_flagEnabled;

		bool m_enblePointerFocus;

		CActor* m_leftWindowTab;
		CActor* m_rightWindowTab;
		CActor* m_upWindowTab;
		CActor* m_downWindowTab;

		TActionList* m_pActionList;

		CKeyboardListenerSet* m_pKeyboardListenerSet;
		CMouseListenerSet* m_pMouseListenerSet;
		CClickListenerSet* m_pClickListenerSet;
		CFocusListenerSet* m_pFocusListenerSet;
		CSemanticEventListenerSet* m_pSemanticEventListenerSet;
		CDragListenerSet* m_pDragListenerSet;
		CGestureListenerSet* m_pGestureListenerSet;
		CKeyLongPressListenerSet* m_pKeyLongPressListenerSet;
		CKeyCombinationListenerSet* m_pKeyCombinationListenerSet;

		CActorFocusListener *m_pFocusListener;
		CActorListenerSet *m_pActorListenerSet;
		
		bool m_dragEnabled;
		bool m_flagFirstFocusIn;
	private:
		virtual bool m_OnMouse(IMouseEvent* pEvent);
		virtual bool m_OnKeyboard(IKeyboardEvent* pEvent);
		virtual bool m_OnRemocon(const IRemoconEvent* pEvent);
		virtual bool m_OnTouch(const ITouchEvent* pEvent);
		virtual bool m_OnRidge(const IRidgeEvent* pEvent);
		virtual bool m_OnMotion(const IMotionEvent* pEvent);
		virtual bool m_OnSensor(const ISensorEvent* pEvent);
		virtual bool m_OnCursor(const ICursorEvent* pEvent);

		virtual bool m_OnCapturedKeyboard(IKeyboardEvent* pEvent);
		virtual bool m_OnCapturedMouse(IMouseEvent* pEvent);

		bool m_enableMouseEvent(bool flagEnabled, bool enforce = false);

	friend class CActorFocusListener;
	};
}


#endif
