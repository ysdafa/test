#ifndef _HALO_CSCROLLPLAYER_H_
#define _HALO_CSCROLLPLAYER_H_

namespace HALO
{
	class CScrollPlayerListener : public IListener
	{
	public:
		virtual void OnItemLoad(class CScrollPlayer *scrollPlayer, int itemIndex){};
		virtual void OnItemUnload(class CScrollPlayer *scrollPlayer, int itemIndex){};
	};

	class CScrollPlayer : public ActorBase, public TransitionListener
	{
	public:
		CScrollPlayer(void);
		virtual ~CScrollPlayer(void);

		typedef struct T_SCROLLPLAYER_ATTR : public TWindowAttr
		{
			int itemNum;
			int timeInterval;
			ClutterScrollDirection scrollDirection;
			int scrollAniDuration;
			ClutterAnimationMode scrollAniMode;

			T_SCROLLPLAYER_ATTR(float width, float height) : TWindowAttr(width, height), itemNum(2), timeInterval(0), scrollDirection(CLUTTER_SCROLL_LEFT),
				scrollAniDuration(500), scrollAniMode(CLUTTER_EASE_IN_OUT_QUAD){}
		}T_ScrollPlayerAttr;

		bool Initialize(IActor* parent, float width, float height);
		bool Initialize(IActor* parent, T_SCROLLPLAYER_ATTR *attr);
		void SetRendererProvider(IRendererProvider* provider);
		
		void SetDataSource(CSingleLineDataSource *dataSource);
		//Set item number
		void SetItemNumber(void);
		//Set time interval 
		void SetTimeInterval(int milliSecond);
		//Set Scroll Direction
		void SetScrollDirection(ClutterScrollDirection direction);
		//start to scroll
		void StartTimer(void);
		//stop scrolling
		void StopTimer(void);
		//load data
		void LoadData(void);

		//add listener
		void SetListener(CScrollPlayerListener* listener);

		//Play scroll animation
		void PlayScroll(void);

		//Set scroll item number
		void SetScrollItemNumber(int scrollItemNumber);

		virtual const char* GetActorType(void);

	protected:
		virtual bool OnStarted(class ITimeLine *animation, void *data) ;
		virtual bool OnCompleted(class ITimeLine *animation, void *data);

	private:

		struct TScrollItem
		{
			int dataIndex;
			TRect rect;
			CActor* window;
			IData* data;
			IRenderer* renderer;
			ITransition *posAni;
		};

		int m_timerInterval;
		ClutterScrollDirection m_scrollDirection;
		float m_width;
		float m_height;
		std::vector<TScrollItem*> m_itemList;
		ISingleLineDataSource* m_dataSource;
		IRendererProvider* m_rendererProvider;

		int m_timerId;
		int m_itemNum;
		int m_scrollItemNum;

		std::vector<int> m_bufferItemIndexList;

		CScrollPlayerListener* m_listener;

		int m_aniCount;

		IRenderer *m_GetRenderer(TScrollItem* item);

		void m_loadItem(TScrollItem* item);

		static int m_Scroll(gpointer data);
	};
}

#endif