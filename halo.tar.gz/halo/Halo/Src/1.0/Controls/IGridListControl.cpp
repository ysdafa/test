#include "Halo.h"
#include "Halo1_0.h"

/*!
 \brief      
 \remarks   
 \param[in]     option    Brief description
 \param[out]    Brief description
 \return     
 \pre    N/A 
 \post   N/A  
 \exception	N/A 
 \par Example:       
 \code       
 \endcode       
 \see       
 \note       
 */
namespace HALO
{
	IGridListControl* IGridListControl::CreateInstance(IActor* parent, const TGridListControlAttr &attr)
	{
		CGridListControl* gridListControl = dynamic_cast<CGridListControl*>(Instance::CreateInstance(CLASS_ID_IGRIDLISTCONTROL));

		if (NULL != gridListControl)
		{
			gridListControl->Initialize(parent, attr);
		}

		return gridListControl;
	}

	IGridListControl* IGridListControl::CreateInstance(Widget* parent, const TGridListControlAttr &attr)
	{
		CGridListControl* gridListControl = dynamic_cast<CGridListControl*>(Instance::CreateInstance(CLASS_ID_IGRIDLISTCONTROL));

		if (NULL != gridListControl)
		{
			gridListControl->Initialize(parent, attr);
		}

		return gridListControl;
	}
}