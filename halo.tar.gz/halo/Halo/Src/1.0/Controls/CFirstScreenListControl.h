#ifndef _CFIRSTSCREENLISTCONTROL_INCLUDE_H_
#define _CFIRSTSCREENLISTCONTROL_INCLUDE_H_

namespace HALO
{
	class CMSubMenuListener
	{
	public:
		virtual void OnSubItemSyncLoad(int mainMenuIndex, TItem *item) {};
		virtual void OnSubItemASyncLoad(int mainMenuIndex, TItem *item) {};
		virtual void OnSubItemUnload(int mainMenuIndex, TItem *item) {};

		virtual void OnFocusChangeStart(int mainMenuIndex, int from, int to) {};
		virtual void OnFocusChangeTo(int mainMenuIndex, int from, int to) {};
	};


	class CMSubMenuList : public CLinearListControl, public TransitionListener
	{
	public:
		CMSubMenuList();
		virtual ~CMSubMenuList(void);

		bool Initialize(IActor *parent, class CFirstScreenListControl *owner, int mainMenuIndex, float enlargeFocusItemSize, float width, float height, float titleHeight = 0, float titleSpace = 0);
		void AddItem(float itemSpace);
		void AddListListener(CMSubMenuListener *listener)
		{
			m_listener = listener;
		}

		void Expand(void);
		bool FlagExpanded(void);

		void Shrink(float scaleRatio);

		void SetDataSource(CSingleLineDataSource *dataSource);

		virtual bool OnNewFrame(class ITimeLine *animation, double currentProgress, void *data);

		virtual const char* GetActorType(void);

	protected:
		virtual bool t_OnMousePointerIn(TItem* item, IMouseEvent* ptrMouseEvent);
		virtual bool t_OnMousePointerOut(TItem* item, IMouseEvent* ptrMouseEvent);
		virtual bool t_OnMouseMoved(TItem* item, IMouseEvent* ptrMouseEvent);
		virtual bool t_MouseButtonPressed(TItem* item, IMouseEvent* ptrMouseEvent);


		virtual bool t_MoveFocusBar(EDirection direction);
		virtual void t_BindDataListToItemList(void);

		virtual TLinearItem* t_AllocLinearItem(void);
		virtual void t_FreeLinearItem(TLinearItem *item);
		virtual void t_GetRealItems(TLinearItem *item, std::vector<TItem*> &itemList);

		virtual void t_GetItemWindowPivotPoint(TItem *item, float &pivotX, float &pivotY, float &pivotZ);

		virtual void t_OnItemDataUnload(TItem *item);
		virtual void t_OnItemDataSyncLoad(TItem *item);
		virtual void t_OnItemDataAsyncLoad(TItem *item);

		virtual void t_FocusChangeStart(const TItem *from, const TItem *to);
		virtual void t_FocusChangeFinish(const TItem *from, const TItem *to);

		virtual TValue2f t_GetRealPointBaseItemGroup(TRect rect, TRect baseOnRect);
		virtual TValue2f t_GetLogicalPosition(TRect rect, TRect baseOnRect);

		virtual TRect t_InitRectOfLoadingItem(TItem *item, int reason);

	private:
		struct TSubMenuItem : public TLinearItem
		{
		public:
			TSubMenuItem(CLinearListControl *inOwner) : TLinearItem(inOwner), leftItem(NULL), rightItem(NULL), xPivot(0.5f), scaleRatio(1.0f), enlarge(0.0f), alphaBak(-1){};

			TSubMenuItem *leftItem;
			TSubMenuItem *rightItem;

			void MouseMoveTo(float x, float y, float enlargeWidth);

			float xPivot;
			float scaleRatio;

			float enlarge;

			int alphaBak;

			void Enlarge(void)
			{
				double ratio = (rect.w + enlarge) / rect.w;
				window->SetPivotPoint(0.0f, 0.0f, 0.5f);
				window->SetScale(ratio, 1.0f, 1.0f);

				if (NULL != window_bg)
				{
					window_bg->SetPivotPoint(0.0f, 0.0f, 0.5f);
					window_bg->SetScale(ratio, 1.0f, 1.0f);
				}
			}

			void ChangeAlpha(int inAlpha)
			{
				if (NULL != window_bg)
				{
					alpha = 255 - inAlpha;
					window_bg->SetAlpha(inAlpha);
					window->SetAlpha(255 - inAlpha);
				}
			}
		};

		int m_focusItemIndex;
		int m_mainMenuIndex;
		float m_enlargeFocusItemSize;

		bool m_flagExpanded;

		float m_mouseX;
		float m_mouseY;

		CSingleLineDataSource *m_dataSource;
		CMSubMenuListener *m_listener;

		CTransition *m_subListExpandAni;
		CTransition *m_alphaAni;

		class CFirstScreenListControl *m_owner;

		friend class CFirstScreenListControl;
	};

	class CFirstScreenListControl : public CLinearListControl, virtual public IFirstScreenListControl, public CMSubMenuListener, public CScrollPlayerListener
	{
	public:
		typedef enum E_FIRST_SCRN_LIST_EVENT_TYPE
		{
			EVENT_FOCUS_CHANGE = 0,				//!< focused item change (focus animation end) event
			EVENT_FOCUS_CHANGE_MOTION_START,	//!< focus change animation starts
			EVENT_ITEM_LOAD,				    //!< item load event
			EVENT_ITEM_UNLOAD,				    //!< item unload event
			EVENT_ITEM_ASYNC_LOAD,				//!< item async load event
			//SubItem
			EVENT_SUB_ITEM_LOAD,				//!< item load event
			EVENT_SUB_ITEM_UNLOAD,				//!< item unload event
			EVENT_SUB_ITEM_ASYNC_LOAD,			//!< item async load event
			//ScrollItem
			EVENT_SCROLL_ITEM_LOAD,				//!< scroll item load event 
			EVENT_SCROLL_ITEM_UNLOAD,			//!< scroll item unload event 
			EVENT_SCROLL_ITEM_ASYNC_LOAD,			//!< scroll item async load event 

			EVENT_MOVE_OUT,						//!< trying to move focus to outward
			EVENT_FIRST_SCRN_EVENT_MAX,			//!< last grid list event type identifier.
		}E_FirstScrnListEventType;

		CFirstScreenListControl();
		virtual ~CFirstScreenListControl();

		bool Initialize(IActor *parent, const TFirstScreenListControlAttr &attr);
		bool Initialize(Widget *parent, const TFirstScreenListControlAttr &attr);

		void AddMainMenuItem(int itemNum, float itemSize, float spaceBetweenItem, char** itemTitles);
		void AddMainMenuItem(int itemNum, float *itemSize, float spaceBetweenItem, char** itemTitles);

		void AddSubItem(int mainMenuIndex, float itemSize, float spaceBetweenItem, float enlargeFocusItemSize, const char* titleContent);
		void SetScrollItemNumber(int mainMenuIndex, int itemNumber);

		void ExpandMainMenu(int mainMenuIndex);

		void ShrinkMainMenu(int mainMenuIndex);

		void SetFocusMargin(TMargin margin);

		void SetMaxMargin(float startMargin, float endMargin);

		void AddListListener(IFirstScreenListListener *listener);

		void SetExpandAnimationDuration(int duration);

		void SetScrollSpeed(float pixPerMillisecond);

		IFirstScreenDataSource * DataSource(void);

		void PlaySubItemLeaveAni(int mainItemIndex, int subItemIndex);

		void PlaySubItemEntranceAni(int mainItemIndex, int subItemIndex);

		virtual const char* GetActorType(void);

	protected:
		virtual bool OnMouseMoved(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnMousePointerIn(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);

		virtual bool t_OnMousePointerIn(TItem* item, IMouseEvent* ptrMouseEvent);
		virtual bool t_OnMousePointerOut(TItem* item, IMouseEvent* ptrMouseEvent);
		virtual bool t_OnMouseMoved(TItem* item, IMouseEvent* ptrMouseEvent);
		virtual bool t_MouseButtonPressed(TItem* item, IMouseEvent* ptrMouseEvent);

		virtual bool t_MoveFocusBar(EDirection direction);
		virtual void t_BindDataListToItemList(void);

		virtual TLinearItem* t_AllocLinearItem(void);
		virtual void t_FreeLinearItem(TLinearItem *item);
		virtual void t_GetRealItems(TLinearItem *item, std::vector<TItem*> &itemList);

		virtual void t_GetItemWindowPivotPoint(TItem *item, float &pivotX, float &pivotY, float &pivotZ);

		virtual void t_OnItemDataUnload(TItem *item);
		virtual void t_OnItemDataSyncLoad(TItem *item);
		virtual void t_OnItemDataAsyncLoad(TItem *item);

		virtual void t_FocusChangeStart(const TItem *from, const TItem *to);
		virtual void t_FocusChangeFinish(const TItem *from, const TItem *to);

		virtual TValue2f t_GetRealPointBaseItemGroup(TRect rect, TRect baseOnRect);
		virtual TValue2f t_GetLogicalPosition(TRect rect, TRect baseOnRect);

		virtual TRect t_InitRectOfLoadingItem(TItem *item, int reason);

		virtual void t_GetInMemoryItemsOfSubClass(TRect visibleArea, std::vector<TItem*> &loadItem, std::vector<TItem*> &unloadItem, std::vector<TItem*> &noChangeItem, int reason);

		//Listener of subMenu
		virtual void OnSubItemSyncLoad(int mainMenuIndex, TItem *item);
		virtual void OnSubItemASyncLoad(int mainMenuIndex, TItem *item);
		virtual void OnSubItemUnload(int mainMenuIndex, TItem *item);

		virtual void OnFocusChangeTo(int mainMenuIndex, int from, int to);

		virtual void t_OnRegisterAnimationCallback(ITimeLine *timeLine, EAniEventType aniCallbackType);

	private:
		struct TMainMenuItem : public TLinearItem
		{
		public:
			TMainMenuItem(CLinearListControl *owner) : TLinearItem(owner), subMenuList(NULL), scrollPlayer(NULL), mainMenuWidth(0.0f), subMenuWidth(0.0f), scrollItemNumber(1), titleContent(NULL){};

			virtual ~TMainMenuItem(void)
			{
				if (NULL != subMenuList)
				{
					subMenuList->Release();
				}

				if (NULL != scrollPlayer)
				{
					scrollPlayer->Release();
				}

				for (int i = 0; i < (int)subItemTitleList.size(); i++)
				{
					delete subItemTitleList[i];
				}
				subItemTitleList.clear();

				if (NULL != titleContent)
				{
					delete titleContent;
				}
			}

			CMSubMenuList *subMenuList;
			CScrollPlayer *scrollPlayer;
			float mainMenuWidth;
			float subMenuWidth;
			int scrollItemNumber;
			char* titleContent;

			CTransition *m_subMenuPosAni;

			std::vector<float> subItemSpaceList;
			std::vector<char *> subItemTitleList;
		};

		CFirstScreenDataSource *m_dataSource;
		class CFirstScreenListControlListenerSet *m_listenerSet;
		float m_enlargeFocusItemSize;
		float m_focusMargin[2];
		float m_maxMargin[2];
		
		float m_mainTitleWidth;
		float m_mainTitleHeight;
		float m_mainTitleSpace;

		float m_subTitleWidth;
		float m_subTitleHeight;
		float m_subTitleSpace;

		int m_curExpanedMainItem;
#ifdef VOLT22_SUPPORT
		IActor* m_mainTitle;
		IActor* m_subTitle;
#else
		IText* m_mainTitle;
		IText* m_subTitle;
#endif
		ITransition* m_mainTitleScaleX;
		ITransition* m_subTitleScaleX;

		CMultiObjectTransition *m_expandShrinkTrans;
		CMultiObjectTransition *m_subItemLeaveEntryTrans;

		float m_itemScrollSpeed;
		int m_expandAniDuration;

		enum ESubItemLeaveStatus
		{
			SUB_ITEM_LEAVING = 0,
			SUB_ITEM_LEAF,
			SUB_ITEM_NORMAL
		};

		ESubItemLeaveStatus m_subItemLeaveStatus;
		TValue2f m_leafSubItemScaleVal;

		void m_SetExpandAniDuration(void);
		void m_SetScrollAniDuration(float scrollDistance);

		int m_ScrollPlayerIndex(CScrollPlayer* player);

		void m_DealMainMenuScrolling(float mouseX, float mouseY);
		void m_StopScrollMainMenu(void);

	public:
		virtual void OnItemLoad(class CScrollPlayer *scrollPlayer, int scrollDataIndex);
		virtual void OnItemUnload(class CScrollPlayer *scrollPlayer, int scrollDataIndex);

	friend class CMSubMenuList;
	};
}

#endif