#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	ISingleLineListControl* ISingleLineListControl::CreateInstance(IActor *parent, const TSingleLineListControlAttr &attr)
	{
		CSingleLineListControl* singleLineList = dynamic_cast<CSingleLineListControl*>(Instance::CreateInstance(CLASS_ID_ISINGLELINELISTCONTROL));

		if (NULL != singleLineList)
		{
			singleLineList->Initialize(parent, attr);
		}

		return singleLineList;
	}

	ISingleLineListControl* ISingleLineListControl::CreateInstance(Widget *parent, const TSingleLineListControlAttr &attr)
	{
		CSingleLineListControl* singleLineList = dynamic_cast<CSingleLineListControl*>(Instance::CreateInstance(CLASS_ID_ISINGLELINELISTCONTROL));

		if (NULL != singleLineList)
		{
			singleLineList->Initialize(parent, attr);
		}

		return singleLineList;
	}
}