#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{

	IText* IText::CreateInstance(IActor* parent, float width, float height)
	{
		CText* text = dynamic_cast<CText*>(Instance::CreateInstance(CLASS_ID_ITEXT));

		if (NULL != text)
		{
			text->Initialize(parent, width, height);
		}

		return text;
	}

	IText* IText::CreateInstance(Widget* parent, float width, float height)
	{
		CText* text = dynamic_cast<CText*>(Instance::CreateInstance(CLASS_ID_ITEXT));

		if (NULL != text)
		{
			text->Initialize(parent, width, height);
		}

		return text;
	}
}