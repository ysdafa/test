#ifndef _HALO_CCATEGORYTAB_H_
#define _HALO_CCATEGORYTAB_H_

namespace HALO
{
	class CCategoryTab : virtual public ICategoryTab, public CActor, public IMouseListener, public IFocusListener, public IKeyboardListener
	{
	private:
		ICompositeImage *m_background;
		IActor *m_tabAreaActor;
		IActor *m_highlightBar;
		IImage *m_leftArrows;
		IImage *m_rightArrows;
		IActor *m_leftBar;
		IActor *m_rightBar;

		std::vector<IButton*> m_tabItemVec;
		std::vector<float> m_tabItemVecWidthFix;
		std::vector<bool> m_tabItemVecHeightFill;
		std::vector<ICompositeImage*> m_tabSpliterVec;

		std::string m_leftArrowsImage;
		std::string m_rightArrowsImage;
		std::string m_spliterImage;
		
		int m_focusIndex;
		int m_focusIndexLast;
		int m_mouseinIndex;

		bool m_enableAlwaysScroll;
		bool m_enableHighlightbar;
		bool m_tabsAlignCenter;
		bool m_enableLooping;
		bool m_enableReverse;
		bool m_enableLeftRightBar;

		float m_tabSpliterWidth, m_tabSpliterHeight;
		float m_marginTop, m_marginBottom, m_marginLeft, m_marginRight;
		float m_tabMargin;
		float m_lastWidth, m_lastHeight;
		float m_tabTextlimitWidth;
		ClutterColor m_tabspliterColor;
		
		std::set<ICategoryTabChangedListener *> m_tabChangedListenerSet;

		std::string m_textFont;
		std::string m_tabImageData[IButton::STATE_ALL + 1];
		int m_tabFontSizeData[IButton::STATE_ALL + 1];
		ClutterColor m_tabTextColorData[IButton::STATE_ALL + 1];
		ClutterColor m_tabColorData[IButton::STATE_ALL + 1];
		bool m_tabTextColorDataFlag[IButton::STATE_ALL + 1];
		bool m_tabColorDataFlag[IButton::STATE_ALL + 1];

		gulong allocationListenerId;

	public:
		CCategoryTab(void);
		~CCategoryTab(void);

		// Create the Category Tab.
		bool Initialize(IActor *parent, float width, float height);
		bool Initialize(Widget *parent, float width, float height);

	public:
		//Listener:
		bool OnMouseButtonPressed(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		bool OnMouseButtonReleased(IActor* pWindow, IMouseEvent* ptrMouseEvent);

		bool OnKeyPressed(IActor* pThis, IKeyboardEvent* event);
		bool OnKeyReleased(IActor* pWindow, IKeyboardEvent* ptrKeyboardEvent);

		bool OnFocusIn(IActor* pWindow);
		bool OnFocusOut(IActor* pWindow);

		bool OnMousePointerIn(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		bool OnMousePointerOut(IActor* pWindow, IMouseEvent* ptrMouseEvent);

	private:
		void m_GetFocusOn(int index);
		void m_MoveTabItems(int from, float distance);
						
		void m_ResizeCategoryTab(void);
		void m_ResizeBackground(void);
		void m_ResizeArrows(void);
		void m_ReplaceArrows(void);
		void m_RefreshArrows(void);
		void m_ResizeTabArea(bool sub);
		void m_ReplaceTabArea(bool sub);
		void m_ResizeHighlightBar(float width, float height);
		void m_ReplaceHighlightBar(int index);
		void m_ResizeSpliters(float width, float height);
		void m_ReplaceSpliters(void);
		void m_ResizeLeftRightBar(float width, float height);
		void m_ReplaceLeftRightBar(float left_x, float right_x, float y);
		void m_ShowSpliter(int index, bool show);
		void m_ShowLeftRightBar(int index, bool show);

		void m_AddSpliter(int number);

		void m_InitTabItemProperties(IButton *tabItem);

		float m_CalTextWidth(const char* text);

		void m_StartTextScroll(int index);
		void m_StopTextScroll(void);

		void m_TabChangedListenerCallBack(void);

		void m_ChangeTabState(int index, ECategoryTabState state);

		void m_AddSizeListener(void);
		void m_RemoveSizeListener(void);
		static void m_OnResize(GObject* object, GParamSpec* paramSpec, gpointer user_data);

		void m_EnableReverse(bool enable);
	
	protected:
			void t_UpdateOrientation(EOrientation orientation);
	
	public:
		void SetMargin(float top, float bottom, float left, float right);
		void SetSpliterSize(float width, float height);
		void SetSpliterColor(const ClutterColor &color);
		void SetSpliterImage(const std::string& image);
		std::string SpliterImage(void) const;
		void EnableLooping(bool enable);
		bool IsLoopingEnabled(void) const;
		void EnableAlignTabsCenter(bool enable);
		bool IsAlignTabsCenterEnabled(void) const;
		

		IButton* TabButtontActor(int index);
		IText* TabTextActor(int index);
		ICompositeImage* TabImageActor(int index);

		void SetTabFont(const std::string& font);
		std::string TabFont(void) const;
		void SetTabFontSize(ECategoryTabState state, int size);
		void SetTabTextColor(ECategoryTabState state, const ClutterColor &color);
		void SetTabImage(ECategoryTabState state, const char* image);
		void SetTabColor(ECategoryTabState state, const ClutterColor &color);

		void SetLeftArrowsSize(float width, float height);
		void SetRightArrowsSize(float width, float height);
		void SetLeftArrowsImage(const std::string& image);
		std::string LeftArrowsImage(void) const;
		void SetRightArrowsImage(const std::string& image);
		std::string RightArrowsImage(void) const;

		void SetBackgroundImage(const std::string& image);
		std::string BackgroundImage(void) const ;
		void SetBackgroundColor(const ClutterColor &color);

		bool IsHightlightBarEnabled(void) const;
		void EnableHightlightBar(bool enable);
		float HighlightBarHeight(void) const;
		void SetHighlightBarHeight(float height);
		void SetHighlightBarColor(const ClutterColor& color);

		float TabTextMargin(void) const;
		void SetTabTextMargin(float margin) ;
		float TabTextLimitWidth(void) const;
		void SetTabTextLimitWidth(float limit);

		bool AddTab(const char* text);
		bool AddTab(const char* text, int index);
		bool AddTab(const char* text, float width, float height);
		bool AddTab(const char* text, float width, float height, int index);

		bool RemoveTab(int index);

		int CurrentTabIndex(void);
		const char* CurrentTabText(void);
		const char* TabText(int index);

		bool ChangeTab(int index);
		int NumberOfTab(void);

		bool AddTabChangedListener(ICategoryTabChangedListener* listener);
		bool RemoveTabChangedListener(ICategoryTabChangedListener* listener);
	};

} /* namespace HALO */
#endif //_HALO_CCATEGORYTAB_H_
