#ifndef _HALO_CCATEGORYTAB_H_
#define _HALO_CCATEGORYTAB_H_

namespace HALO
{
	class CCategoryTabItem : public CActor
	{
	public:
		struct CTItemStateData
		{
			std::string backgroundImagePath;
			ClutterColor backgroundColor;
			std::string iconPath;
			int iconAlpha;//0~255
			std::string textContent;
			int fontSize;
			ClutterColor textColor;
			std::string leftImagePath;
			std::string rightImagePath;
		};
		CTItemStateData m_stateData[ICategoryTab::STATE_ALL];

		ICategoryTab::ECategoryTabState m_curState;
		float m_fixwidth;
		bool m_fillheight;

		ICompositeImage* m_backgroundImage;
		IImage* m_icon;
		IText* m_text;
		ICompositeImage* m_leftImage;
		ICompositeImage* m_rightImage;
		ISelectButton* m_checkbox;
		IDragAction* m_dragAction;

		CCategoryTabItem(void);
		~CCategoryTabItem(void);
		bool Initialize(IActor *parent, float width, float height);
		bool Initialize(Widget *parent, float width, float height);
		IText* TextActor(void) { return m_text; };
		IImage* IconActor(void) { return m_icon; };
		ICompositeImage* BackgroundImageActor(void) { return m_backgroundImage; };
		ICompositeImage* LeftImageActor(void) { return m_leftImage; };
		ICompositeImage* RightImageActor(void) { return m_rightImage; };
		ISelectButton* CheckBoxActor(void) { return m_checkbox; };
		void ChangeState(ICategoryTab::ECategoryTabState state);
	};

	class CCategoryTab : virtual public ICategoryTab, public CActor, public IMouseListener, public IFocusListener, public IKeyboardListener, public ITimeLineListener, public IDragListener
	{
	private:
		ICompositeImage *m_background;
		IActor *m_tabAreaActor;
		IActor *m_highlightBar;
		IImage *m_leftArrows;
		IImage *m_rightArrows;

		std::vector<CCategoryTabItem*> m_tabItemVec;
		std::vector<ICompositeImage*> m_tabSpliterVec;

		float m_tabIconDefaultWidth, m_tabIconDefaultHeight;

		std::string m_leftArrowsImage;
		std::string m_rightArrowsImage;
		std::string m_spliterImage;

		int m_focusIndex;
		int m_focusIndexLast;
		int m_mouseinIndex;
		int m_selectedIndex;
		int m_highlightedIndex;

		bool m_isEnableAlwaysScroll;
		bool m_isEnableHighlightbar;
		bool m_isHighlightbarBottom;
		bool m_tabsAlignCenter;
		bool m_isEnableLooping;
		bool m_isReverse;
		bool m_isEnableChangeTab;
		bool m_useSelfReverse;
		bool m_isEnableKey;
		bool m_isShowCheckBox;
		bool m_isAutoShowLeftRightImage;

		float m_tabSpliterWidth, m_tabSpliterHeight;
		float m_marginTop, m_marginBottom, m_marginLeft, m_marginRight;
		float m_tabLeftMargin, m_tabRightMargin, m_tabIconMargin;
		float m_lastWidth, m_lastHeight;
		float m_tabTextlimitWidth;
		float m_checkboxWidth, m_checkboxHeight, m_checkboxMargin;

		float m_highlightbarFocusHeight, m_highlightbarUnfocusHeight;
		int m_highlightbarEasingDuration;
		int m_highlightbarMoveDuration;
		ClutterAnimationMode m_highlightbarEasingMode;
		ClutterAnimationMode m_highlightbarMoveMode;

		float m_tabLeftImageWidth, m_tabLeftImageHeight, m_tabRightImageWidth, m_tabRightImageHeight;
		float m_tabLeftImageMargin, m_tabRightImageMargin;
		std::string m_tabLeftImagePath;
		std::string m_tabRightImagePath;

		ClutterColor m_tabspliterColor;
		ClutterColor m_highlightbarFocusedColor;
		ClutterColor m_highlightbarUnfocusedColor;
		bool m_highlightbarExpand;

		std::set<ICategoryTabListener *> m_categoryTabListenerSet;

		std::string m_textFont;
		ClutterColor m_defaultTabTextColor[STATE_ALL];
		std::string m_defaultTabBackgroundImage[STATE_ALL];
		ClutterColor m_defaultTabBackgroundColor[STATE_ALL];
		int m_defaultTabFontSize[STATE_ALL];
		std::string m_defaultTabIconImage[STATE_ALL];
		int m_defaultTabIconAlpha[STATE_ALL];

		std::string m_tabCheckImageData[STATE_SELECT_ALL + 1];
		std::string m_tabCheckBoxImageData[STATE_SELECT_ALL + 1];
		int m_tabCheckImageOpacityData[STATE_SELECT_ALL + 1];
		int m_tabCheckBoxImageOpacityData[STATE_SELECT_ALL + 1];

		gulong m_allocationListenerId;
		gulong m_highlightbarSizeListenerId;

		CMultiObjectTransition *m_swapMoveAni;
		CMultiObjectTransition *m_resizeHighlightAni;
		CMultiObjectTransition *m_replaceHighlightAni;
		int m_swapFrom, m_swapTo;
		int m_swapMoveDuration;
		bool m_isSwapMoveAni;
		bool m_isResizeHighlightAni;

		float m_dragX, m_dragY;
		float m_highlightDragX, m_highlightDragY;
		int m_isDragMove;
		bool m_isEnableDragTab;

		float m_tabTargetHeightMin, m_tabTargetHeightMax;

		int m_textscrollDefaultDuration, m_textscrollDefaultDelay, m_textscrollDefaultRepeat, m_textscrollDefaultContinueGap;
		float m_textscrollDefaultSpeed;
		ClutterTextScrollType m_textscrollDefaultType;
		ClutterTimelineDirection m_textscrollDefaultDirection;

	public:
		CCategoryTab(void);
		~CCategoryTab(void);

		// Create the Category Tab.
		bool Initialize(IActor *parent, float width, float height);
		bool Initialize(Widget *parent, float width, float height);

	public:
		//Listener:
		bool OnMouseButtonPressed(IWidgetExtension* pThis, IMouseEvent* event);
		bool OnMouseButtonReleased(IWidgetExtension* pThis, IMouseEvent* event);

		bool OnKeyPressed(IWidgetExtension* pThis, IKeyboardEvent* event);
		bool OnKeyReleased(IWidgetExtension* pWindow, IKeyboardEvent* ptrKeyboardEvent);

		bool OnFocusIn(IWidgetExtension* pWindow);
		bool OnFocusOut(IWidgetExtension* pWindow);

		bool OnMousePointerIn(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);
		bool OnMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);
		bool OnMouseMoved(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);

		bool OnCompleted(class ITimeLine *animation, void *data);

		bool OnDragBegin(IWidgetExtension* pWindow, IDragEvent* pDragEvent);
		bool OnDragEnd(IWidgetExtension* pWindow, IDragEvent* pDragEvent);
		bool OnDragMotion(IWidgetExtension* pWindow, IDragEvent* pDragEvent);
	private:
		void m_GetFocusOn(int index);
		void m_MoveTabItems(int from, float distance);
		void m_ChangeTabItemState(int index, ECategoryTabState state);
		void m_ResetTabItemsState(void);
		void m_ExpandHighlightBar(bool easing = false);
		void m_ShrinkHighlightBar(bool easing = false);
		void m_KeepHighlightBarBottom(void);
		void m_LocationSubTab(int index);
		void m_StopHighlightbarMove(void);
		void m_StartHighlightbarMove(float x, float y);
		void m_StopHighlightbarResize(void);
		void m_StartHighlightbarResize(float width, float height);
		ClutterAnimationMode m_ChangeAnimationMode(ECategoryTabAnimationMode mode);

		void m_ResizeCategoryTab(void);
		void m_ResizeBackground(void);
		void m_ResizeArrows(void);
		void m_ReplaceArrows(void);
		void m_RefreshArrows(void);
		void m_ResizeTabArea(bool sub);
		void m_ReplaceTabArea(bool sub);
		void m_ReplaceSubTab(int fromIndex);
		void m_ResizeHighlightBar(float width, float height, bool easing, float expectYPostion);
		void m_ReplaceHighlightBar(int index, bool easing = false);
		void m_ResizeSpliters(float width, float height);
		void m_ReplaceSpliters(void);
		void m_ShowSpliter(int index, bool show);

		void m_AddSpliter(int number);
		void m_InitTabItemProperties(CCategoryTabItem *tabItem);
		void m_InitTabItemCheckBox(ISelectButton *checkbox);

		int m_GetTabMaxFontSize(void);
		float m_CalTextWidth(const char* text, const std::string& font, int fontsize);

		void m_StartTextScroll(int index);
		void m_StopTextScroll(int index);

		void m_TabChangedListenerCallBack(void);
		void m_TabClickedListenerCallBack(int index);
		void m_TabMouseInListenerCallBack(int index);
		void m_TabMouseOutListenerCallBack(int index);
		void m_TabArrowsClickedListenerCallBack(int index);

		void m_AddSizeListener(void);
		void m_RemoveSizeListener(void);
		static void m_OnResize(GObject* object, GParamSpec* paramSpec, gpointer user_data);
		void m_AddHighlightbarSizeListener(void);
		void m_RemoveHighlightbarSizeListener(void);
		static void m_OnHighlightBarResize(GObject* object, GParamSpec* paramSpec, gpointer user_data);

		void m_EnableReverse(bool enable);

		void m_swapSubTabByPosition(int fromIndex, float fromX, float fromY, float fromWidth, int toIndex, float toX, float toY, float toWidth);

	protected:
		void t_UpdateOrientation(EOrientation orientation);

	public:
		const char* GetActorType(void);

		void SetMargin(float top, float bottom, float left, float right);
		void SetSpliterSize(float width, float height, int index);
		void SetSpliterColor(const ClutterColor &color);
		void SetSpliterImage(const std::string& image);
		std::string SpliterImage(void) const;
		void EnableLooping(bool enable);
		bool IsLoopingEnabled(void) const;
		void EnableAlignTabsCenter(bool enable);
		bool IsAlignTabsCenterEnabled(void) const;
		void EnableTabsKey(bool enable);
		bool IsTabsKeyEnabled(void) const;

		IText* TabTextActor(int index);
		ICompositeImage* TabImageActor(int index);

		void SetTabFont(const std::string& font);
		std::string TabFont(void) const;
		void SetTabFontSize(ECategoryTabState state, int size);
		void SetTabTextColor(ECategoryTabState state, const ClutterColor &color);
		void SetTabImage(ECategoryTabState state, const char* image);
		void SetTabColor(ECategoryTabState state, const ClutterColor &color);
		void SetTabIconImage(ECategoryTabState state, const std::string& image, int alpha, int index);
		void SetTabText(ECategoryTabState state, const char* text, int index);

		void SetLeftArrowsSize(float width, float height);
		void SetRightArrowsSize(float width, float height);
		void SetLeftArrowsImage(const std::string& image);
		std::string LeftArrowsImage(void) const;
		void SetRightArrowsImage(const std::string& image);
		std::string RightArrowsImage(void) const;

		void SetBackgroundImage(const std::string& image);
		std::string BackgroundImage(void) const;
		void SetBackgroundColor(const ClutterColor &color);

		bool IsHightlightBarEnabled(void) const;
		void EnableHighlightBar(bool enable);
		float HighlightBarHeight(void) const;
		void SetHighlightBarHeight(float height);
		void SetHighlightBarColor(const ClutterColor& color);
		void SetHighlightBarFocusedColor(const ClutterColor& color);
		void SetHighlightBarUnfocusedColor(const ClutterColor& color);
		void SetHighlightBarFocusAnimation(float unfocusHeight, float focusHeight, ECategoryTabAnimationMode mode, int time);
		void SetHighlightBarMoveAnimation(ECategoryTabAnimationMode mode, int time);


		float TabTextLeftMargin(void) const;
		void SetTabTextLeftMargin(float margin);
		float TabTextRightMargin(void) const;
		void SetTabTextRightMargin(float margin);
		float TabIconMargin(void) const;
		void SetTabIconMargin(float margin);
		void SetTabIconSize(float width, float height, int index);
		void ShowTabIcon(int index);
		void HideTabIcon(int index);
		bool FlagTabIconShow(int index) const;

		float TabTextLimitWidth(void) const;
		void SetTabTextLimitWidth(float limit);

		bool AddTab(const char* text);
		bool AddTab(const char* text, int index);
		bool AddTab(const char* text, float width, float height);
		bool AddTab(const char* text, float width, float height, int index);

		bool RemoveTab(int index);

		int CurrentTabIndex(void);
		const char* CurrentTabText(void);
		const char* TabText(int index);

		bool ChangeTab(int index);
		int NumberOfTab(void);

		bool AddCategoryTabListener(ICategoryTabListener* listener);
		bool RemoveCategoryTabListener(ICategoryTabListener* listener);

		void EnableChangeTab(bool enable);
		bool IsChangeTabEnabled(void) const;
		void ShowFocus(void);
		void HideFocus(void);
		void SwapSubTab(int fromIndex, int toIndex);
		void SetSwapSubTabDuration(int time);

		void SetTabCheckImage(ECategoryTabSelectState state, const std::string& image);
		void SetTabCheckImageOpacity(ECategoryTabSelectState state, int value);
		void SetTabBoxBackGroudImage(ECategoryTabSelectState state, const std::string& image);
		void SetTabBoxBackGroudImageOpacity(ECategoryTabSelectState state, int value);

		void ShowTabCheckBox(void);
		void HideTabCheckBox(void);
		void SetTabCheckBoxSize(float width, float height);
		void SetTabCheckBoxMargin(float margin);
		void ShowTabLeftImage(int index);
		void ShowTabRightImage(int index);
		void HideTabLeftImage(int index);
		void HideTabRightImage(int index);
		void SetTabLeftImageSize(float width, float height, float margin);
		void SetTabRightImageSize(float width, float height, float margin);
		void SetTabLeftImagePath(const std::string&  path, int index);
		void SetTabRightImagePath(const std::string&  path, int index);
		void EnableHighlightBarBottom(bool enable);
		bool IsHighlightBarBottom(void) const;
		void EnableDragTab(bool enable);
		bool IsEnableDragTab(void) const;
		std::vector<int> GetTabCheckBoxSelectedIndexes(void);
		void SetTabTargetHeight(float targetMin, float targetMax);
		void SetTabChecked(int index, bool enable);
		bool IsTabChecked(int index);

		void EnableAutoShowImagesOnPressTab(bool enable);
		bool IsEnableAutoShowImagesOnPressTab(void) const;
		void GetTabSize(int index, float &width, float &height);
		void GetTabPosition(int index, bool isAbsolute, float &x, float &y);
		void SetTabScrollAttribute(guint duration, gfloat speed, guint delay, gint repeat, ClutterTextScrollType type, ClutterTimelineDirection direction, guint continueGap);
	};

} /* namespace HALO */
#endif //_HALO_CCATEGORYTAB_H_
