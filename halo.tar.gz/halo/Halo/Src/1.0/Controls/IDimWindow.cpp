#include "Halo1_0.h"

namespace HALO
{
	IDimWindow* IDimWindow::CreateInstance(Widget* parent, float width, float height)
	{
		CDimWindow * cDimWin = dynamic_cast<CDimWindow*>(Instance::CreateInstance(CLASS_ID_IDIMWINDOW));
		if (cDimWin)
		{
			cDimWin->Initialize(parent, width, height);
		}

		return cDimWin;
	}
}