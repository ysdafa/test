/*
* DimActor.h
*
*  Created on: Oct 15, 2014
*      Author: lihua5.sun
*/

/* inclusion guard */
#ifndef _DIM_ACTOR_H_
#define _DIM_ACTOR_H_

/* include any dependencies */
#include <clutter/clutter.h>

G_BEGIN_DECLS
/* GObject implementation */

/* declare this function signature to remove compilation errors with -Wall;
* the dim_actor_get_type() function is actually added via the
* G_DEFINE_TYPE macro in the .c file
*/
GType dim_actor_get_type(void);

/* GObject type macros */
/* returns the class type identifier (GType) for DimActor */
#define DIM_ACTOR_TYPE            (dim_actor_get_type ())

/* cast obj to a DimActor object structure*/
#define DIM_ACTOR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DIM_ACTOR_TYPE, DimActor))

/* check whether obj is a DimActor */
#define IS_DIM_ACTOR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DIM_ACTOR_TYPE))

/* cast klass to DimActorClass class structure */
#define DIM_ACTOR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DIM_ACTOR_TYPE, DimActorClass))

/* check whether klass is a member of the DimActorClass */
#define IS_DIM_ACTOR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DIM_ACTOR_TYPE))

/* get the DimActorClass structure for a DimActor obj */
#define DIM_ACTOR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DIM_ACTOR_TYPE, DimActorClass))

typedef struct _DimActorPrivate DimActorPrivate;
typedef struct _DimActor        DimActor;
typedef struct _DimActorClass   DimActorClass;

/* object structure */
struct _DimActor
{
	/*<private>*/
	VoltActor parent_instance;

	/* structure containing private members */
	/*<private>*/
	DimActorPrivate *priv;
};

/* class structure */
struct _DimActorClass
{
	/*<private>*/
	VoltActorClass parent_class;
};

/* public API */

/* constructor - note this returns a ClutterActor instance */
ClutterActor *dim_actor_new(void);

void dim_actor_set_background_color(DimActor *self, const ClutterColor *color);

void dim_actor_add_transparent_area(DimActor *self, float x, float y, float width, float height);

void dim_actor_clear_transparent_area(DimActor *self);

G_END_DECLS

#endif /* _DIM_ACTOR_H_ */