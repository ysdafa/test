#include "Halo1_0.h"

#if !defined(WIN32) && !defined(LINUX_BUILD)
#define HAVE_ECORE_IMF
#endif
#ifdef HAVE_ECORE_IMF
#include <Ecore.h>
#include <Ecore_Evas.h>
#include <Ecore_IMF_Evas.h> 
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <Ecore_X.h>
#endif

namespace HALO
{
	static HALO::util::Logger LOGGER("CRichText");
#ifdef HAVE_ECORE_IMF
	class CIMFContext
	{
		public:
			Ecore_IMF_Context *imf_context;
			bool  focused;
			bool  imf_enable;
			int   preedit_start;
			int   preedit_len;
		private:
			Ecore_Evas	  *m_ecore_evas;
			
		public:
			CIMFContext();
			~CIMFContext();
			
			//! Detroy IMF Context.
			void DestroyIMFContext(CIMFContext *cimf_context);
			//! Set IMF focus and show IME.
			void SetIMFFocused();
			//! Set IMF focus out and hide IME.
			void SetIMFFocusOut();
			//! Change clutter key event to ecore key event.
			bool GetEcoreKeyEvent(ClutterEvent *event, Ecore_IMF_Event *imf_event);
			//! Receive IME Done button press.
			void IMEInputDone();
			//! Receive IME Cancel button press.
			void IMEInputCancel();
			//! create IMF context.
			Ecore_IMF_Context *CreateIMFContext(CRichText *richtext);
		private:		
			//! Commit text to CRichText.
			static void m_OnTextCommit(void *data, Ecore_IMF_Context *ctx, void *event_info);
			//! Put preedit text to CRichText.
			static void m_OnPreeditChanged(void *data, Ecore_IMF_Context *ctx, void *event_info);
			//! Callback on IME state changed event.
			static void m_OnStateChanged(void* data, Ecore_IMF_Context* imf_ctx, int state);
			//! Callback on panel geometry changed event.
			static void m_OnIMEGeometryChanged(void* data, Ecore_IMF_Context* imf_ctx, int value);
	};	
#endif

#define bytes_to_offset(t, p)    (g_utf8_pointer_to_offset ((t), (t) + (p)))
#define	offset_to_byte(t, p)	(g_utf8_offset_to_pointer(t, p) - t)

	TextRenderer::TextRenderer(IActor* parent, CRichText *owner)
	{
		float w, h;
		parent->GetSize(w, h);
		m_text = new CText();
		m_text->Initialize(parent, w, h);

		m_owner = owner;
		m_text->EnableMultiLine(TRUE);
		
		bool editableFlag = m_owner->IsEditableEnabled();
		clutter_actor_set_reactive(CLUTTER_ACTOR(m_text->TextActor()), editableFlag);
		clutter_text_set_editable(m_text->TextActor(), editableFlag);

		clutter_text_set_selectable(m_text->TextActor(), FALSE);
		clutter_text_set_cursor_color(m_text->TextActor(), &m_owner->CursorColor());

		owner->RegisterCommonEventCallback(m_text);
		owner->SetFontInfo(m_text);
		m_text->Show();
	}

	TextRenderer::~TextRenderer()
	{
		if (m_text)
		{
			m_text->Release();
			m_text = NULL;
		}
	}
	
	void TextRenderer::m_KeyFocusInCb(ClutterActor* actor, CActor *pOwner)
	{
		CFocusManager* pFocusManager = CFocusManager::GetInstance();

		if (pFocusManager)
		{
			if (pFocusManager->FocusedWindow() != pOwner)
			{
				pFocusManager->SetFocusBySignal(pOwner);
			}
		}
	}

	void TextRenderer::m_KeyFocusOutCb(ClutterActor* actor, CActor *pThis)
	{
		CFocusManager* pFocusManager = CFocusManager::GetInstance();

		if (pFocusManager)
		{
			if (!clutter_actor_has_key_focus(pThis->Actor()))
			{
				pFocusManager->KillFocusBySignal(pThis);
			}			
		}
	}

	void TextData::Release()
	{
		delete [] textContent;
		textContent = NULL;
		if (attrList != NULL)
		{
			pango_attr_list_unref(attrList);
			attrList = NULL;
		}
		delete this;
	}

	void TextRenderer::Draw(IData *data, IActor* parent, E_DRAW_TYPE drawType)
	{
		TextData* tData = static_cast<TextData*>(data);
		if (drawType == LOAD_DATA_DRAW)
		{
			m_text->SetTextColor(m_owner->TextColor());
			m_text->SetBackgroundColor(m_owner->BackgroundColor());
			m_text->SetText(tData->textContent);
			m_owner->UpdateMultiLineTextFormat(m_text, tData->attrList, tData->alignment);
			float w, h;
			parent->GetSize(w, h);
			clutter_actor_set_width(CLUTTER_ACTOR(m_text->TextActor()), w);
			tData->height = (float)clutter_actor_get_height(CLUTTER_ACTOR(m_text->TextActor()));
			m_owner->RegisterTextChangedEventCallback(m_text);
		}
		else if (drawType == UNLOAD_DATA_DRAW)
		{

		}
	}

	void TextRenderer::Resize(IData *data, IActor* parent, ClutterSize destSize, bool flagAni, int animationDuration)
	{
		m_text->Resize(destSize.width, -1);
		m_text->SetClipArea(0.0f, 0.0f, destSize.width, destSize.height);
	}

	CText* TextRenderer::GetText(void)
	{
		return m_text;
	}

	IRenderer* CRichText::GetRenderer(IData *data, IActor* parent)
	{
		return new TextRenderer(parent, this);
	}

	bool CRichText::OnItemLoaded(class ISingleLineListControl* list, IData *data, int itemIndex)
	{
		return true;
	}

	bool CRichText::OnAsyncItemLoad(class ISingleLineListControl *list, IData *data, int itemIndex)
	{
		return true;
	}

	bool CRichText::OnItemUnloaded(class ISingleLineListControl* list, IData *data, int itemIndex)
	{
		data->SetReady(false);
		return true;
	}

	void CRichText::RegisterCommonEventCallback(CText *text)
	{
		g_signal_connect(text->TextActor(), "key-focus-in", G_CALLBACK(m_KeyFocusInCb), this);
		g_signal_connect(text->TextActor(), "key-focus-out", G_CALLBACK(m_KeyFocusOutCb), this);
		g_signal_connect(text->TextActor(), "button-press-event", G_CALLBACK(m_MousePressEvent), this);//mouse press
		g_signal_connect(text->TextActor(), "button-release-event", G_CALLBACK(m_MouseReleaseEvent), this);//mouse release
		g_signal_connect(text->TextActor(), "motion-event", G_CALLBACK(m_MouseMoveEvent), this);//mouse move
		g_signal_connect(text->TextActor(), "key-press-event", G_CALLBACK(m_KeyPressEvent), this);//key press
		g_signal_connect(text->TextActor(), "key-release-event", G_CALLBACK(m_KeyReleaseEvent), this);//key release
	}

	void CRichText::RegisterTextChangedEventCallback(CText *text)
	{
		g_signal_connect(text->TextActor(), "delete-text", G_CALLBACK(m_DeleteTextEvent), this);//delete text event
		g_signal_connect(text->TextActor(), "insert-text", G_CALLBACK(m_InsertTextEvent), this);//insert text event
		g_signal_connect(text->TextActor(), "text-changed", G_CALLBACK(m_TextChangedEvent), this);//changed text event
	}

	void CRichText::CursorPositionInfo(int& indexPara, int& indexChar)
	{
		indexPara = m_cursorPositionParaIndex;
		indexChar = m_cursorPositionCharIndex;
	}

	void CRichText::SetFontInfo(CText *text)
	{
		if (m_fontName != NULL && m_fontSize >= 0)
		{
			text->SetFont(m_fontName);
			text->SetFontSize(m_fontSize);
		}
		if (m_cursorWidth > 0)
		{
			clutter_text_set_cursor_size(text->TextActor(), m_cursorWidth);
		}
	}

	CRichText::CRichText()
	{
		// TODO Auto-generated constructor stub
		m_enableEditable = true;
		m_enableMultiLine = false;
		m_enableSelectable = true;
		m_enableSelectablePreState = true;
		m_enableHighLight = false;
		m_highlightMoveIndex = 0;
		m_enableEditablePreHLState = true;

		m_mousePressState = false;
		m_cursorWidth = 0;
		m_cursorPos = 0;
		m_cursorColorAlpha = 100;
		m_cursorBlinkInterval = 500;
		m_borderThick = 0;

		m_cursorPositionParaIndex = 0;
		m_cursorPositionCharIndex = 0;
		m_boundPositionParaIndex = 0;
		m_boundPositionCharIndex = 0;
		m_insertEventFlag = false;
		m_backspaceEventFlag = false;
		m_returnEventFlag = false;

		m_selectionColor.alpha = 100;
		m_selectionColor.red = 0;
		m_selectionColor.green = 0;
		m_selectionColor.blue = 125;

		m_cursorColor.alpha = 100;
		m_cursorColor.red = 255;
		m_cursorColor.green = 0;
		m_cursorColor.blue = 0;

		m_highlightColor.alpha = 100;
		m_highlightColor.red = 0;
		m_highlightColor.green = 0;
		m_highlightColor.blue = 255;

		m_textColor.alpha = 255;
		m_textColor.red = 0;
		m_textColor.green = 0;
		m_textColor.blue = 0;

		m_backgroundColor.alpha = 255;
		m_backgroundColor.red = 255;
		m_backgroundColor.green = 255;
		m_backgroundColor.blue = 255;

		m_moveCursorBusyFlag = false;
		m_insertTextFlag = false;
		m_moveHighLightBusyFlag = false;
		m_canvasContent = NULL;
		m_canvasActor = NULL;
		m_copyTextBuf = NULL;
		m_selectionTextBuf = NULL;
		m_getTextBuf = NULL;
		m_fontName = NULL;
		m_fontSize = 0;
		m_textAttrList = NULL;
		m_pangoAttrList = pango_attr_list_new();
		m_pangoAttrListCopy = pango_attr_list_new();
		m_copyEventFlag = false;
		m_focusChangeFlag = false;
		m_hasFocusOutFlag = false;
		m_focusWithOutGrab = false;
		m_pressPositionPara = -1;
		m_pressPositionChar = -1;
#ifdef HAVE_ECORE_IMF
		m_imf_context = NULL;
#endif
	}

	CRichText::~CRichText()
	{
		// TODO Auto-generated destructor stub
		if (m_pangoAttrList != NULL)
		{
			pango_attr_list_unref(m_pangoAttrList);
			m_pangoAttrList = NULL;
		}

		if (m_pangoAttrListCopy != NULL)
		{
			pango_attr_list_unref(m_pangoAttrListCopy);
			m_pangoAttrListCopy = NULL;
		}
		RemoveFocusListener(this);
		RemoveMouseListener(this);
		if (m_textAttrList != NULL)
		{
			pango_attr_list_unref(m_textAttrList);
			m_textAttrList = NULL;
		}

		if (m_enableMultiLine)
		{
			m_ReleaseMultiLine();
		}
		else
		{
			m_ReleaseSingleLine();
		}

		delete [] m_copyTextBuf;
		m_copyTextBuf = NULL;

		delete [] m_selectionTextBuf;
		m_selectionTextBuf = NULL;

		delete [] m_getTextBuf;
		m_getTextBuf = NULL;

		delete [] m_fontName;
		m_fontName = NULL;

#ifdef HAVE_ECORE_IMF
		if (m_imf_context != NULL)
		{
			m_imf_context->DestroyIMFContext(m_imf_context);
			delete m_imf_context;
			m_imf_context = NULL;
		}
#endif	
	}

	bool CRichText::Initialize(IActor *parent, float width, float height)
	{
		Widget *cParent = dynamic_cast<Widget*>(parent);

		return Initialize(cParent, width, height);
	}

	bool CRichText::Initialize(Widget *parent, float width, float height)
	{
		CActor::Initialize(parent, width, height);
		char* buf = new char[1];
		buf[0] = '\0';
		m_InitialSingleLine(buf);
		// get default fontname and fontsize
		int fontlen = strlen(m_text->Font());
		m_fontName = new char[fontlen + 1];
		strncpy(m_fontName, (char*)m_text->Font(), fontlen);
		m_fontName[fontlen] = '\0';
		m_fontSize = m_text->FontSize();
		SetFontInfo(m_text);
		// get cursor width
		m_cursorWidth = (int)clutter_text_get_cursor_size(m_text->TextActor());
		AddFocusListener(this);
		AddMouseListener(this);
#ifdef HAVE_ECORE_IMF
		if (m_imf_context != NULL)
		{
			delete m_imf_context;
			m_imf_context = NULL;
		}
		m_imf_context = new CIMFContext;
#endif
		return true;
	}

	void CRichText::m_InitialSingleLine(const char *text)
	{
		float width = 0;
		float height = 0;
		this->GetSize(width, height);
		m_text = new CText();
		m_text->Initialize(dynamic_cast<Widget*>(this), width, height);
		clutter_actor_add_child(t_actor, m_text->Actor());
		clutter_actor_set_width(CLUTTER_ACTOR(m_text->TextActor()), (gfloat)width);
		m_text->SetTextColor(m_textColor);
		m_text->SetBackgroundColor(m_backgroundColor);
		clutter_actor_set_reactive(CLUTTER_ACTOR(m_text->TextActor()), m_enableEditable);
		clutter_text_set_editable(m_text->TextActor(), m_enableEditable);
		clutter_text_set_selectable(m_text->TextActor(), m_enableSelectable);
		clutter_text_set_single_line_mode(m_text->TextActor(), !m_enableMultiLine);
		clutter_text_set_activatable(m_text->TextActor(), TRUE);
		SetFontInfo(m_text);
		SetText(text); 
		m_textAttrList = pango_attr_list_new();
		clutter_text_set_attributes(m_text->TextActor(), m_textAttrList);

		g_signal_connect(m_text->TextActor(), "button-press-event", G_CALLBACK(m_MousePressEventSingleLine), this);//mouse press
		g_signal_connect(m_text->TextActor(), "button-release-event", G_CALLBACK(m_MouseReleaseEventSingleLine), this);//mouse release
		g_signal_connect(m_text->TextActor(), "motion-event", G_CALLBACK(m_MouseMoveEventSingleLine), this);//mouse move
		g_signal_connect(m_text->TextActor(), "key-press-event", G_CALLBACK(m_KeyPressEventSingleLine), this);//key press
		g_signal_connect(m_text->TextActor(), "key-release-event", G_CALLBACK(m_KeyReleaseEventSingleLine), this);//key release
		g_signal_connect(m_text->TextActor(), "delete-text", G_CALLBACK(m_DeleteTextEventSingleLine), this);//delete text event
		g_signal_connect(m_text->TextActor(), "insert-text", G_CALLBACK(m_InsertTextEventSingleLine), this);//insert text event
		
		clutter_text_set_cursor_color(m_text->TextActor(), &m_cursorColor);
		m_selectionColor.alpha = 255;
		clutter_text_set_selection_color(m_text->TextActor(), &m_selectionColor);
		// cursor blink
		m_cursorBlinkTimerID = clutter_threads_add_timeout(m_cursorBlinkInterval, m_CursorBlink, this);
		m_text->EnableFocus(true);
		//m_text->SetFocus();
		clutter_text_set_cursor_position(m_text->TextActor(), 0);
		clutter_text_set_selection_bound(m_text->TextActor(), 0);
		//m_SetParagraphFocus(m_text->TextActor(), 0, 0);
		m_text->Show();

		g_signal_connect(m_text->TextActor(), "key-focus-in", G_CALLBACK(m_KeyFocusInCb), this);
		g_signal_connect(m_text->TextActor(), "key-focus-out", G_CALLBACK(m_KeyFocusOutCb), this);
	}

	void CRichText::m_ReleaseSingleLine(void)
	{
		if (m_cursorBlinkTimerID > 0)
		{
			g_source_remove(m_cursorBlinkTimerID);
		}

		if (m_textAttrList != NULL)
		{
			pango_attr_list_unref(m_textAttrList);
			m_textAttrList = NULL;
		}

		m_text->Release();
	}

	void CRichText::m_InitialMultiLine(const char *text)
	{
		float width = 0;
		float height = 0;
		this->GetSize(width, height);
		CSingleLineListControl::TSingleLineListControlAttr attr(width, height, TYPE_VERTICAL);
		m_singleLine = new CSingleLineListControl();
		m_singleLine->Initialize((IActor*)this, attr);
		m_singleLine->AddMouseListener(this);
		m_singleLine->AddListListener(this);
		m_singleLine->SetRendererProvider(this);
		m_singleLine->SetAnimationDuration(ISingleLineListControl::ANITYPE_FOCUS_MOVE, 500);
		m_singleLine->SetAnimationDuration(ISingleLineListControl::ANITYPE_LOOP, 500);
		m_singleLine->SetBackgroundColor(m_backgroundColor);
		m_singleLine->HideFocus(false);
		clutter_actor_add_child(t_actor, m_singleLine->Actor());
		clutter_actor_set_clip_to_allocation(t_actor, TRUE);
		clutter_actor_set_background_color(t_actor, &m_backgroundColor);
		m_selectionColor.alpha = 100;
		SetText(text);
		//1. m_canvasActor is the platform to draw m_canvasContent.
		m_canvasActor = clutter_actor_new();
		clutter_actor_add_child(t_actor, m_canvasActor);
		clutter_actor_set_size(m_canvasActor, (gfloat)width, (gfloat)height);
		ClutterColor color;
		color.alpha = 0;
		color.red = 0;
		color.green = 0;
		color.blue = 0;
		clutter_actor_set_background_color(m_canvasActor, &color);
		clutter_actor_set_child_above_sibling(t_actor, m_canvasActor, NULL);
		//2. m_canvasContent is used to draw cairo
		m_canvasContent = clutter_canvas_new();
		clutter_canvas_set_size(CLUTTER_CANVAS(m_canvasContent), (int)width, (int)height);
		clutter_actor_set_content(m_canvasActor, m_canvasContent);
		clutter_actor_set_content_gravity(m_canvasActor, CLUTTER_CONTENT_GRAVITY_CENTER);
		g_object_unref(m_canvasContent);
		// connect our drawing code
		g_signal_connect(m_canvasContent, "draw", G_CALLBACK(m_PaintCanvas), this);
		// invalidate the canvas, so that we can draw before the main loop starts
		clutter_content_invalidate(m_canvasContent);
		// set up a timer that invalidates the canvas draw 0.02 second one time
		m_selectionDrawTimerID = clutter_threads_add_timeout(20, m_InvalidateSelection, m_canvasContent);

		// cursor blink
		m_cursorBlinkTimerID = clutter_threads_add_timeout(m_cursorBlinkInterval, m_CursorBlink, this);

		if(m_singleLine->Renderer(m_cursorPositionParaIndex) != NULL)
		{
			CText* ctext = ((TextRenderer*)m_singleLine->Renderer(m_cursorPositionParaIndex))->GetText();
			if (ctext != NULL)
			{
				//m_SetParagraphFocus(ctext->TextActor(), m_cursorPositionCharIndex, m_cursorPositionCharIndex);
				clutter_text_set_cursor_position(ctext->TextActor(), m_cursorPositionCharIndex);
				clutter_text_set_selection_bound(ctext->TextActor(), m_cursorPositionCharIndex);
			}
		}
	}

	void CRichText::m_ReleaseMultiLine(void)
	{
		m_cursorPositionParaIndex = 0;
		m_cursorPositionCharIndex = 0;
		m_boundPositionParaIndex = 0;
		m_boundPositionCharIndex = 0;

		if (m_cursorBlinkTimerID > 0)
		{
			g_source_remove(m_cursorBlinkTimerID);
			m_cursorBlinkTimerID = 0;
		}
		
		if (m_selectionDrawTimerID > 0)
		{
			g_source_remove(m_selectionDrawTimerID);
			m_selectionDrawTimerID = 0;
		}

		if (m_canvasActor != NULL)
		{
			clutter_actor_destroy(m_canvasActor);
			m_canvasActor = NULL;
		}

		if (m_canvasContent != NULL)
		{
			g_clear_object(&m_canvasContent);
			m_canvasContent = NULL;
		}

		int size = m_pangoAttrListCopyList.size();
		if (size > 0)
		{
			std::list<PangoAttrList*>::iterator iter = m_pangoAttrListCopyList.begin();
			for (; iter != m_pangoAttrListCopyList.end(); ++iter)
			{
				if ((*iter) != NULL)
				{
					pango_attr_list_unref(*iter);
					*iter = NULL;
				}
			}
			m_pangoAttrListCopyList.clear();
		}

		m_singleLine->RemoveMouseListener(this);
		m_singleLine->Release();
	}

	void CRichText::Show(void)
	{
		CActor::Show();
	}

	void CRichText::EnableEditable(bool flagEditable)
	{
		if (m_enableEditable == flagEditable || m_enableHighLight)
		{
			return;
		}
		m_enableEditable = flagEditable;

		if (!m_enableMultiLine)
		{
			if (flagEditable)
			{
				m_enableSelectable = m_enableSelectablePreState;
				clutter_text_set_selectable(m_text->TextActor(), m_enableSelectable);
			}
			else
			{
				m_enableSelectable = false;
				clutter_text_set_selectable(m_text->TextActor(), m_enableSelectable);
			}

			clutter_actor_set_reactive(CLUTTER_ACTOR(m_text->TextActor()), flagEditable);
			clutter_text_set_editable(m_text->TextActor(), flagEditable);
		}
		else
		{
			if (flagEditable)
			{
				m_enableSelectable = m_enableSelectablePreState;
			}
			else
			{
				m_enableSelectable = false;
			}

			int start = -1;
			int end = -1;
			m_singleLine->GetWindowItemRange(start, end);
			if (start < 0 || end < 0)
			{
				return;
			}
			for (int i = start; i <= end; i++)
			{
				if( m_singleLine->Renderer(i) != NULL )
				{
					CText* ctext = ((TextRenderer*)m_singleLine->Renderer(i))->GetText();
					if(ctext != NULL)
					{
						clutter_actor_set_reactive(CLUTTER_ACTOR(ctext->TextActor()), flagEditable);
						clutter_text_set_editable(ctext->TextActor(), flagEditable);
					}
				}
			}
		}
	}
	
	bool CRichText::IsEditableEnabled(void)
	{
		return m_enableEditable;
	}

	void CRichText::EnableMultiLine(bool flagMutliLineMode)
	{
		if (m_enableMultiLine == flagMutliLineMode || m_enableHighLight)
		{
			return;
		}
		m_focusChangeFlag = false;
		if (!m_enableMultiLine)
		{//pre is singleline
			int textLen = strlen(clutter_text_get_text(CLUTTER_TEXT(m_text->TextActor())));
			char* textBuf;
			if (textLen == 0)
			{
				textLen = 1;
				textBuf = new char[1];
				textBuf[0] = '\0';
			}
			else
			{
				textBuf = new char[textLen + 1];
				strncpy(textBuf, clutter_text_get_text(CLUTTER_TEXT(m_text->TextActor())), textLen);
				textBuf[textLen] = '\0';
			}
			 
			if (flagMutliLineMode)
			{//current is multiline
				m_enableMultiLine = flagMutliLineMode;
				m_ReleaseSingleLine();
				m_InitialMultiLine(textBuf);
			}

			delete [] textBuf;
			textBuf = NULL;
		}
		else
		{//pre is multiline
			int textLen = 0;
			int size = m_singleLine->GetDataSource()->Size();
			for (int i = 0; i < size; i++)
			{
				textLen += strlen(((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent);
				textLen += 1;//add '\n' or '\0'
			}
			char* textBuf = new char[textLen/* + 1*/];
			int currentIndex = 0;
			for (int i = 0; i < size; i++)
			{
				char* paraBuf = ((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent;
				int paraLen = strlen(paraBuf);

				strncpy(textBuf + currentIndex, paraBuf, paraLen);
				if (i < (size - 1))
				{// end with '\n'
					textBuf[currentIndex + paraLen] = '\n';
				}
				else if (i == (size - 1))
				{// end with '\0'
					textBuf[currentIndex + paraLen] = '\0';
				}
				currentIndex += (paraLen + 1);
			}

			if (!flagMutliLineMode)
			{//current is singleline
				m_enableMultiLine = flagMutliLineMode;
				m_ReleaseMultiLine();
				m_InitialSingleLine(textBuf);//max count num 1024 ..to do
			}
			delete [] textBuf;
			textBuf = NULL;
		}
	}

	bool CRichText::IsMultiLineEnabled(void)
	{
		return m_enableMultiLine;
	}

	void CRichText::SetText(const char *text)
	{
		if (m_enableHighLight)
		{
			return;
		}
		if (text == NULL)
		{
			return;
		}
		
#ifdef HAVE_ECORE_IMF
		if (m_imf_context != NULL && m_imf_context->imf_context != NULL)
		{
			ecore_imf_context_reset(m_imf_context->imf_context);
		}
#endif
		m_copyEventFlag = false;
		if (!m_enableMultiLine)
		{
			if (m_textAttrList != NULL)
			{
				pango_attr_list_unref(m_textAttrList);
				m_textAttrList = NULL;
				m_textAttrList = pango_attr_list_new();
			}
			if (m_pangoAttrListCopy != NULL)
			{
				pango_attr_list_unref(m_pangoAttrListCopy);
				m_pangoAttrListCopy = NULL;
				m_pangoAttrListCopy = pango_attr_list_new();
			}
			m_text->SetText(text);
			clutter_text_set_cursor_position(m_text->TextActor(), 0);
			clutter_text_set_selection_bound(m_text->TextActor(), 0);
			//m_SetParagraphFocus(m_text->TextActor(), 0, 0);
		}
		else
		{
			float pWidth = 0;
			float pHeight = 0;
			this->GetSize(pWidth, pHeight);

			TRect rect = m_singleLine->VisibleAreaRect();
			if (abs((int)rect.y) > 0)
			{
				m_singleLine->ScrollVisibleArea(0, -rect.y, false);
			}

			bool clearAllFlag = false;
			m_focusChangeFlag = true;
			m_cursorPositionParaIndex = 0;
			m_cursorPositionCharIndex = 0;
			m_boundPositionParaIndex = 0;
			m_boundPositionCharIndex = 0;
			int size = m_singleLine->GetDataSource()->Size();
			m_singleLine->DeleteItem(0, size);

			int textLen = strlen(text);
			int itemCount = 0;
			if (textLen == 0)
			{
				clearAllFlag = true;
				TextData* data = new TextData;
				data->SetDataLoadType(IData::E_LOAD_TYPE_SYNC);
				char* bufNull = new char[1];
				bufNull[0] = '\0';
				data->textContent = bufNull;
				data->index = 0;
				data->attrList = pango_attr_list_new();
				data->alignment = 0;
				////////////////////////////////////////////////////
				CText* textTmp = new CText();
				textTmp->Initialize(dynamic_cast<Widget*>(this), pWidth, pHeight);
				textTmp->EnableMultiLine(TRUE);
				SetFontInfo(textTmp);

				textTmp->SetText(data->textContent);
				clutter_actor_set_width(CLUTTER_ACTOR(textTmp->TextActor()), pWidth);
				data->height = (float)clutter_actor_get_height(CLUTTER_ACTOR(textTmp->TextActor()));
				textTmp->Release();
				textTmp = NULL;
				////////////////////////////////////////////////////
				m_singleLine->GetDataSource()->AddData(data);
				m_singleLine->AddItem(1, data->height);
				itemCount = 1;
			}
			else
			{
				int begin = 0;
				int end = 0;
				for (int i = 0; i < textLen; i++)
				{
					if (text[i] == '\n' || (i == (textLen - 1) && text[i] != '\n'))
					{
						TextData* data = new TextData;
						data->SetDataLoadType(IData::E_LOAD_TYPE_SYNC);
						if (i == (textLen - 1))
						{
							end = i + 1;//current character needs to add
						}
						else
						{
							end = i;
						}
						int len = end - begin;
						char* itemBuf = new char[len + 1];
						strncpy(itemBuf, text + begin, len);
						itemBuf[len] = '\0';
						data->textContent = itemBuf;
						data->index = itemCount;
						data->attrList = pango_attr_list_new();
						data->alignment = 0;
						////////////////////////////////////////////////////
						CText* textTmp = new CText();
						textTmp->Initialize(dynamic_cast<Widget*>(this), pWidth, pHeight);
						textTmp->EnableMultiLine(TRUE);
						SetFontInfo(textTmp);

						textTmp->SetText(itemBuf);
						clutter_actor_set_width(CLUTTER_ACTOR(textTmp->TextActor()), pWidth);
						data->height = (float)clutter_actor_get_height(CLUTTER_ACTOR(textTmp->TextActor()));
						textTmp->Release();
						textTmp = NULL;
						////////////////////////////////////////////////////
						m_singleLine->GetDataSource()->AddData(data);
						m_singleLine->AddItem(1, data->height);
						begin = i + 1;
						itemCount++;
					}
				}
			}

			m_singleLine->LoadData();
			m_singleLine->Show();
			m_singleLine->EnableFocus(true);
			//m_singleLine->SetFocus();
			if (clearAllFlag)
			{
				if (m_singleLine->Renderer(0) != NULL)
				{
					CText* ctext = ((TextRenderer*)m_singleLine->Renderer(0))->GetText();
					clutter_actor_grab_key_focus(CLUTTER_ACTOR(ctext->TextActor()));
				}
			}
			m_focusChangeFlag = false;
		}
	}

	const char* CRichText::Text(void)
	{
		delete [] m_getTextBuf;
		m_getTextBuf = NULL;

		if (!m_enableMultiLine)
		{
			int len = strlen(clutter_text_get_text(CLUTTER_TEXT(m_text->TextActor())));
			m_getTextBuf = new char[len + 1];
			strncpy(m_getTextBuf, clutter_text_get_text(CLUTTER_TEXT(m_text->TextActor())), len);
			m_getTextBuf[len] = '\0';
		}
		else
		{
			int res_len = 0;
			int size = m_singleLine->GetDataSource()->Size();
			for (int i = 0; i < size; i++)//string
			{
				res_len += strlen(((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent);
				res_len += 1;//add '\n'
			}
			m_getTextBuf = new char[res_len];
			int currentIndex = 0;
			for (int i = 0; i < size; i++)
			{
				char* paraBuf = ((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent;
				int paraLen = strlen(paraBuf);
				strncpy(m_getTextBuf + currentIndex, paraBuf, paraLen);
				if (i < (size - 1))
				{
					m_getTextBuf[currentIndex + paraLen] = '\n';
				}
				else if (i == (size - 1))
				{
					m_getTextBuf[currentIndex + paraLen] = '\0';
				}
				currentIndex += (paraLen + 1);
			}
		}
		return m_getTextBuf;
	}

	void CRichText::InsertText(char *text)
	{
		if (m_enableHighLight)
		{
			return;
		}
		if (text == NULL)
		{
			return;
		}
		if (!m_enableMultiLine)
		{
			clutter_text_delete_selection(m_text->TextActor());
			int cursorPos = clutter_text_get_cursor_position(m_text->TextActor());
			clutter_text_insert_text(m_text->TextActor(), text, cursorPos);
			//cursorPos = clutter_text_get_cursor_position(m_text->TextActor());
			//m_SetParagraphFocus(m_text->TextActor(), cursorPos, cursorPos);
		}
		else
		{
			int len_insert = strlen(text);
			int len_insertUTF8 = g_utf8_strlen(text, -1);
			if (len_insert <= 0)
			{
				return;
			}

			float pWidth, pHeight;
			this->GetSize(pWidth, pHeight);
			std::list<int> insertParaLenList;
			int paraLen = 0;
			int insertParaCount = 0;
			for (int i = 0; i < len_insert; i++)
			{
				if (text[i] == '\n' || (text[i] != '\n' && i == (len_insert - 1)))
				{
					if (text[i] == '\n')
					{
						insertParaCount++;
					}

					//reserve every ara len
					if (i < (len_insert - 1))
					{
						insertParaLenList.push_back(paraLen);
					}
					else
					{
						insertParaLenList.push_back(paraLen + 1);
					}
					paraLen = 0;
				}
				else
				{
					paraLen++;
				}
			}

			int selectionStartPara = 0;
			int selectionStartChar = 0;
			int selectionEndPara = 0;
			int selectionEndChar = 0;
			int selectionLen = 0;
			m_GetSelectionBoundData(selectionStartPara, selectionStartChar, selectionEndPara, selectionEndChar, selectionLen);
			//make sure that the selectionStartPara needs to show
			m_MoveCurrentParaToShow(selectionStartPara, selectionStartChar);

			int selectionParaCount = abs(selectionStartPara - selectionEndPara);
			TextData* startData = (TextData*)m_singleLine->GetDataSource()->GetData(selectionStartPara);
			
			if (insertParaCount == 0)
			{//insert just one para
				if (selectionParaCount == 0)
				{//selection range in one para
					const char* startParaBuf = startData->textContent;
					int startParaLen = strlen(startParaBuf);
					int len_res = selectionStartChar + startParaLen - selectionEndChar + len_insert + 1;
					char* buf_res = new char[len_res];
					for (int i = 0; i < selectionStartChar; i++)
					{
						buf_res[i] = startParaBuf[i];
					}
					for (int i = 0; i < len_insert; i++)
					{
						buf_res[selectionStartChar + i] = text[i];
					}
					for (int i = 0; i < (startParaLen - selectionEndChar); i++)
					{
						buf_res[selectionStartChar + len_insert + i] = startParaBuf[selectionEndChar + i];
					}
					buf_res[len_res - 1] = '\0';
					delete [] startData->textContent;
					startData->textContent = NULL;
					startData->textContent = buf_res;

					m_UpdateParagraphAttrList(startData->attrList, selectionStartChar, len_insert, selectionEndChar - selectionStartChar, 0);
					int insertAttrListSize = m_pangoAttrListCopyList.size();
					if (insertAttrListSize == 1 && m_copyEventFlag)
					{
						std::list<PangoAttrList*>::iterator iter = m_pangoAttrListCopyList.begin();
						m_InsertAttrList(m_pangoAttrList, *iter, selectionStartChar, len_insert, true);
					}
					pango_attr_list_unref(startData->attrList);
					startData->attrList = NULL;
					startData->attrList = pango_attr_list_copy(m_pangoAttrList);

					if( m_singleLine->Renderer(selectionStartPara) != NULL )
					{
						CText* ctext = ((TextRenderer*)m_singleLine->Renderer(selectionStartPara))->GetText();
						if (ctext != NULL)
						{
							m_insertTextFlag = true;
							clutter_text_set_text(ctext->TextActor(), buf_res);
							m_insertTextFlag = false;

							clutter_text_set_attributes(ctext->TextActor(), startData->attrList);

							float height = (float)clutter_actor_get_height(CLUTTER_ACTOR(ctext->TextActor()));
							if ((int)height != (int)startData->height)
							{
								m_singleLine->SetItemSpace(selectionStartPara, height);
								startData->height = height;
							}

							int indexTmp = selectionStartChar + len_insert;
							int indexUTF8 = bytes_to_offset(startData->textContent, indexTmp);
							clutter_text_set_cursor_position(ctext->TextActor(), indexUTF8);
							clutter_text_set_selection_bound(ctext->TextActor(), indexUTF8);
							m_cursorPositionCharIndex = indexTmp;
							m_boundPositionCharIndex = indexTmp;
						}
					}
				}
				else
				{//selection range in several paras
					char* buf_startPara = startData->textContent;
					int len_startPara = strlen(buf_startPara);
					TextData* endData = (TextData*)m_singleLine->GetDataSource()->GetData(selectionEndPara);
					char* buf_endPara = endData->textContent;
					int len_endPara = strlen(buf_endPara);

					int newBufLen = selectionStartChar + len_endPara - selectionEndChar + len_insert + 1;
					char *newBuf = new char[newBufLen];
					for (int i = 0; i < selectionStartChar; i++)
					{
						newBuf[i] = buf_startPara[i];
					}
					for (int i = 0; i < len_insert; i++)
					{
						newBuf[selectionStartChar + i] = text[i];
					}
					for (int i = 0; i < (len_endPara - selectionEndChar); i++)
					{
						newBuf[selectionStartChar + len_insert + i] = buf_endPara[selectionEndChar + i];
					}
					newBuf[newBufLen - 1] = '\0';
					delete [] startData->textContent;
					startData->textContent = NULL;
					startData->textContent = newBuf;

					m_UpdateMergedParagraphAttrList(startData->attrList, endData->attrList, selectionStartChar, selectionEndChar, len_insert);
					int insertAttrListSize = m_pangoAttrListCopyList.size();
					if (insertAttrListSize == 1 && m_copyEventFlag)
					{
						std::list<PangoAttrList*>::iterator iter = m_pangoAttrListCopyList.begin();
						m_InsertAttrList(m_pangoAttrList, *iter, selectionStartChar, 0, false);
					}
					pango_attr_list_unref(startData->attrList);
					startData->attrList = NULL;
					startData->attrList = pango_attr_list_copy(m_pangoAttrList);

					if( m_singleLine->Renderer(selectionStartPara) != NULL )
					{
						CText* ctext = ((TextRenderer*)m_singleLine->Renderer(selectionStartPara))->GetText();
						if (ctext != NULL)
						{
							m_insertTextFlag = true;
							clutter_text_set_text(ctext->TextActor(), newBuf);
							m_insertTextFlag = false;

							clutter_text_set_attributes(ctext->TextActor(), startData->attrList);

							float height = (float)clutter_actor_get_height(CLUTTER_ACTOR(ctext->TextActor()));
							if ((int)height != (int)startData->height)
							{
								m_singleLine->SetItemSpace(selectionStartPara, height);
								startData->height = height;
							}
						}
					}
					m_focusChangeFlag = true;
					//delete selection para except the para that the cursor at.
					m_singleLine->DeleteItem(selectionStartPara + 1, selectionParaCount);

					int size = m_singleLine->GetDataSource()->Size();
					for (int i = 0; i < size; i++)
					{
						((TextData*)m_singleLine->GetDataSource()->GetData(i))->index = i;
					}
					m_cursorPositionParaIndex = selectionStartPara;
					m_boundPositionParaIndex = selectionStartPara;
					m_cursorPositionCharIndex = selectionStartChar + len_insert;
					m_boundPositionCharIndex = selectionStartChar + len_insert;
					int indexUTF8 = bytes_to_offset(newBuf, selectionStartChar + len_insert);
					if( m_singleLine->Renderer(m_cursorPositionParaIndex) != NULL )
					{
						CText* newText = ((TextRenderer*)m_singleLine->Renderer(m_cursorPositionParaIndex))->GetText();
						if (newText != NULL)
						{
							//m_SetParagraphFocus(newText->TextActor(), m_cursorPositionCharIndex, m_boundPositionCharIndex);
							if (!clutter_actor_has_key_focus(CLUTTER_ACTOR(newText->TextActor())))
							{
								clutter_actor_grab_key_focus(CLUTTER_ACTOR(newText->TextActor()));
							}
							clutter_text_set_cursor_position(newText->TextActor(), indexUTF8);
							clutter_text_set_selection_bound(newText->TextActor(), indexUTF8);
						}
					}
					m_focusChangeFlag = false;
				}
			}
			else if (insertParaCount > 0)
			{//insert several paras
				if (selectionParaCount == 0)
				{//selection in the same para
					std::list<int>::iterator iterParaLen = insertParaLenList.begin();
					//1. the first para to modify
					char* buf_startPara = startData->textContent;
					int startBufLen = strlen(buf_startPara);
					int newStartParaLen = selectionStartChar + *iterParaLen;
					char* newStartParaBuf = new char[newStartParaLen + 1];
					strncpy(newStartParaBuf, buf_startPara, selectionStartChar);
					strncpy(newStartParaBuf + selectionStartChar, text, *iterParaLen);
					newStartParaBuf[newStartParaLen] = '\0';

					// the selectionStartPara tail buf, needs to combine to the insert last para.
					char* tailParaBuf = new char[startBufLen - selectionEndChar + 1];
					strncpy(tailParaBuf, buf_startPara + selectionEndChar, startBufLen - selectionEndChar);
					tailParaBuf[startBufLen - selectionEndChar] = '\0';

					delete [] startData->textContent;
					startData->textContent = NULL;
					startData->textContent = newStartParaBuf;

					PangoAttrList* lastAttrList;
					lastAttrList = pango_attr_list_copy(startData->attrList);

					// modify the front part of the split para
					m_UpdateParagraphAttrList(startData->attrList, startBufLen, 0, startBufLen - selectionStartChar, 0);
					
					std::list<PangoAttrList*>::iterator iterAttrList;
					int insertAttrListSize = m_pangoAttrListCopyList.size();
					int insertParaSize = insertParaLenList.size();
					bool doCopyFlag = false;// use copy attribute list
					if (m_copyEventFlag && insertAttrListSize == insertParaSize)
					{
						doCopyFlag = true;
						iterAttrList = m_pangoAttrListCopyList.begin();
						m_InsertAttrList(m_pangoAttrList, *iterAttrList, selectionStartChar, 0, false);
					}

					pango_attr_list_unref(startData->attrList);
					startData->attrList = NULL;
					startData->attrList = pango_attr_list_copy(m_pangoAttrList);

					if( m_singleLine->Renderer(selectionStartPara) != NULL )
					{
						CText* ctext = ((TextRenderer*)m_singleLine->Renderer(selectionStartPara))->GetText();
						if (ctext != NULL)
						{
							m_insertTextFlag = true;
							clutter_text_set_text(ctext->TextActor(), startData->textContent);
							m_insertTextFlag = false;

							clutter_text_set_attributes(ctext->TextActor(), startData->attrList);
						}
					}

					CText* textTmp = new CText();
					textTmp->Initialize(dynamic_cast<Widget*>(this), pWidth, pHeight);
					textTmp->EnableMultiLine(TRUE);
					SetFontInfo(textTmp);
					textTmp->SetText(startData->textContent);
					clutter_actor_set_width(CLUTTER_ACTOR(textTmp->TextActor()), pWidth);
					float height = (float)clutter_actor_get_height(CLUTTER_ACTOR(textTmp->TextActor()));
					if ((int)height != (int)startData->height)
					{
						m_singleLine->SetItemSpace(selectionStartPara, height);
						startData->height = height;
					}
					textTmp->Release();
					textTmp = NULL;

					//2. the middle para to insert
					int listSize = insertParaLenList.size();
					int curCount = *iterParaLen;
					++iterParaLen;
					int paraOffset = 1;
					int lastParaInsertLen = 0;
					for (; iterParaLen != insertParaLenList.end(); ++iterParaLen)
					{
						char* insertParaBuf = NULL;
						if (paraOffset < (listSize - 1))
						{
							insertParaBuf = new char[*iterParaLen + 1];
							strncpy(insertParaBuf, text + curCount + 1, *iterParaLen);
							insertParaBuf[*iterParaLen] = '\0';
							curCount += (*iterParaLen + 1);
						}
						else if (paraOffset == (listSize - 1))
						{
							lastParaInsertLen = *iterParaLen;
							insertParaBuf = new char[*iterParaLen + startBufLen - selectionEndChar + 1];
							strncpy(insertParaBuf, text + curCount + 1, *iterParaLen);
							strncpy(insertParaBuf + *iterParaLen, tailParaBuf, startBufLen - selectionEndChar);
							insertParaBuf[*iterParaLen + startBufLen - selectionEndChar] = '\0';
						}

						TextData* data = new TextData;
						data->SetDataLoadType(IData::E_LOAD_TYPE_SYNC);
						data->textContent = insertParaBuf;
						data->index = selectionStartPara + paraOffset;
						data->alignment = 0;

						if (paraOffset < (listSize - 1))
						{
							if (doCopyFlag)
							{
								++iterAttrList;
								data->attrList = pango_attr_list_copy(*iterAttrList);
							}
							else
							{
								data->attrList = pango_attr_list_new();
							}
						}
						else if (paraOffset == (listSize - 1))
						{// the tail part of the split paragraph
							m_UpdateParagraphAttrList(lastAttrList, selectionEndChar, -1, selectionEndChar, lastParaInsertLen);
							if (doCopyFlag)
							{
								++iterAttrList;
								m_InsertAttrList(m_pangoAttrList, *iterAttrList, 0, 0, false);
							}
							data->attrList = pango_attr_list_copy(m_pangoAttrList);
						}

						CText* textTmp = new CText();
						textTmp->Initialize(dynamic_cast<Widget*>(this), pWidth, pHeight);
						textTmp->EnableMultiLine(TRUE);
						SetFontInfo(textTmp);

						textTmp->SetText(data->textContent);
						clutter_actor_set_width(CLUTTER_ACTOR(textTmp->TextActor()), pWidth);
						data->height = (float)clutter_actor_get_height(CLUTTER_ACTOR(textTmp->TextActor()));
						textTmp->Release();
						textTmp = NULL;

						m_singleLine->GetDataSource()->InsertData(selectionStartPara + paraOffset, data);
						m_singleLine->InsertItem(selectionStartPara + paraOffset, 1, data->height);
						m_singleLine->LoadData();
						paraOffset++;
					}
					delete [] tailParaBuf;
					tailParaBuf = NULL;

					pango_attr_list_unref(lastAttrList);
					lastAttrList = NULL;

					m_cursorPositionParaIndex = selectionEndPara + insertParaCount;
					m_cursorPositionCharIndex = lastParaInsertLen;
					m_boundPositionParaIndex = m_cursorPositionParaIndex;
					m_boundPositionCharIndex = m_cursorPositionCharIndex;
					if( m_singleLine->Renderer(m_cursorPositionParaIndex) != NULL )
					{
						CText* newCursorText = ((TextRenderer*)m_singleLine->Renderer(m_cursorPositionParaIndex))->GetText();
						if (newCursorText != NULL)
						{
							TextData* cursorData = (TextData*)m_singleLine->GetDataSource()->GetData(m_cursorPositionParaIndex);
							int indexUTF8 = bytes_to_offset(cursorData->textContent, m_cursorPositionCharIndex);
							m_SetParagraphFocus(newCursorText->TextActor(), indexUTF8, indexUTF8);
						}
					}
				}
				else
				{//select some paras
					// 1. modify the selectionStartPara content, combine the pre selectionStartChar buf and the insert first para buf.
					std::list<int>::iterator iterParaLen = insertParaLenList.begin();
					char* buf_startPara = startData->textContent;
					int startBufLen = strlen(buf_startPara);
					int newStartParaLen = selectionStartChar + *iterParaLen;
					char* newStartParaBuf = new char[newStartParaLen + 1];
					strncpy(newStartParaBuf, buf_startPara, selectionStartChar);
					strncpy(newStartParaBuf + selectionStartChar, text, *iterParaLen);
					newStartParaBuf[newStartParaLen] = '\0';

					delete [] startData->textContent;
					startData->textContent = NULL;
					startData->textContent = newStartParaBuf;

					// modify the front part of the split para
					m_UpdateParagraphAttrList(startData->attrList, startBufLen, 0, startBufLen - selectionStartChar, 0);

					std::list<PangoAttrList*>::iterator iterAttrList;
					int insertAttrListSize = m_pangoAttrListCopyList.size();
					int insertParaSize = insertParaLenList.size();
					bool doCopyFlag = false;// use copy attribute list
					if (m_copyEventFlag && insertAttrListSize == insertParaSize)
					{
						doCopyFlag = true;
						iterAttrList = m_pangoAttrListCopyList.begin();
						m_InsertAttrList(m_pangoAttrList, *iterAttrList, selectionStartChar, 0, false);
					}

					pango_attr_list_unref(startData->attrList);
					startData->attrList = NULL;
					startData->attrList = pango_attr_list_copy(m_pangoAttrList);

					if( m_singleLine->Renderer(selectionStartPara) != NULL )
					{
						CText* ctext = ((TextRenderer*)m_singleLine->Renderer(selectionStartPara))->GetText();
						if (ctext != NULL)
						{
							m_insertTextFlag = true;
							clutter_text_set_text(ctext->TextActor(), startData->textContent);
							m_insertTextFlag = false;

							clutter_text_set_attributes(ctext->TextActor(), startData->attrList);
						}
					}

					CText* textTmp = new CText();
					textTmp->Initialize(dynamic_cast<Widget*>(this), pWidth, pHeight);
					textTmp->EnableMultiLine(TRUE);
					SetFontInfo(textTmp);
					textTmp->SetText(startData->textContent);
					clutter_actor_set_width(CLUTTER_ACTOR(textTmp->TextActor()), pWidth);
					float height = (float)clutter_actor_get_height(CLUTTER_ACTOR(textTmp->TextActor()));
					if ((int)height != (int)startData->height)
					{
						m_singleLine->SetItemSpace(selectionStartPara, height);
						startData->height = height;
					}
					textTmp->Release();
					textTmp = NULL;

					// the buf that the index from the selectionEndChar to the end in selectionEndPara.
					TextData* endData = (TextData*)m_singleLine->GetDataSource()->GetData(selectionEndPara);
					char* buf_endPara = endData->textContent;
					int endBufLen = strlen(buf_endPara);
					char* tailParaBuf = new char[endBufLen - selectionEndChar + 1];
					strncpy(tailParaBuf, buf_endPara + selectionEndChar, endBufLen - selectionEndChar);
					tailParaBuf[endBufLen - selectionEndChar] = '\0';
					PangoAttrList* lastAttrList;
					lastAttrList = pango_attr_list_copy(endData->attrList);

					// 2. delete the para which index > selectionStartPara and index <= selectionEndPara.
					m_singleLine->DeleteItem(selectionStartPara + 1, selectionParaCount);
					
					// 3. insert paras with insert buf, except the first and the last insert para buf.
					int listSize = insertParaLenList.size();
					int curCount = *iterParaLen;
					++iterParaLen;
					int paraOffset = 1;
					int lastParaInsertLen = 0;
					for (; iterParaLen != insertParaLenList.end(); ++iterParaLen)
					{
						char* insertParaBuf = NULL;
						if (paraOffset < (listSize - 1))
						{
							insertParaBuf = new char[*iterParaLen + 1];
							strncpy(insertParaBuf, text + curCount + 1, *iterParaLen);
							insertParaBuf[*iterParaLen] = '\0';
							curCount += (*iterParaLen + 1);
						}
						else if (paraOffset == (listSize - 1))
						{// modify the selectionEndPara content, combine the last insert para buf and the buf which is between selectionEndChar and the the end of the selectionEndPara.
							lastParaInsertLen = *iterParaLen;
							insertParaBuf = new char[*iterParaLen + endBufLen - selectionEndChar + 1];
							strncpy(insertParaBuf, text + curCount + 1, *iterParaLen);
							strncpy(insertParaBuf + *iterParaLen, tailParaBuf, endBufLen - selectionEndChar);
							insertParaBuf[*iterParaLen + endBufLen - selectionEndChar] = '\0';
						}

						TextData* data = new TextData;
						data->SetDataLoadType(IData::E_LOAD_TYPE_SYNC);
						data->textContent = insertParaBuf;
						data->index = selectionStartPara + paraOffset;
						data->alignment = 0;

						if (paraOffset < (listSize - 1))
						{
							if (doCopyFlag)
							{
								++iterAttrList;
								data->attrList = pango_attr_list_copy(*iterAttrList);
							}
							else
							{
								data->attrList = pango_attr_list_new();
							}
						}
						else if (paraOffset == (listSize - 1))
						{// the tail part of the split paragraph
							m_UpdateParagraphAttrList(lastAttrList, selectionEndChar, -1, selectionEndChar, lastParaInsertLen);
							if (doCopyFlag)
							{
								++iterAttrList;
								m_InsertAttrList(m_pangoAttrList, *iterAttrList, 0, 0, false);
							}
							data->attrList = pango_attr_list_copy(m_pangoAttrList);
						}

						CText* textTmp = new CText();
						textTmp->Initialize(dynamic_cast<Widget*>(this), pWidth, pHeight);
						textTmp->EnableMultiLine(TRUE);
						SetFontInfo(textTmp);

						textTmp->SetText(data->textContent);
						clutter_actor_set_width(CLUTTER_ACTOR(textTmp->TextActor()), pWidth);
						data->height = (float)clutter_actor_get_height(CLUTTER_ACTOR(textTmp->TextActor()));
						textTmp->Release();
						textTmp = NULL;

						m_singleLine->GetDataSource()->InsertData(selectionStartPara + paraOffset, data);
						m_singleLine->InsertItem(selectionStartPara + paraOffset, 1, data->height);
						m_singleLine->LoadData();
						paraOffset++;
					}
					delete [] tailParaBuf;
					tailParaBuf = NULL;

					pango_attr_list_unref(lastAttrList);
					lastAttrList = NULL;

					m_cursorPositionParaIndex = selectionStartPara + insertParaCount;
					m_cursorPositionCharIndex = lastParaInsertLen;
					m_boundPositionParaIndex = m_cursorPositionParaIndex;
					m_boundPositionCharIndex = m_cursorPositionCharIndex;
					if( m_singleLine->Renderer(m_cursorPositionParaIndex) != NULL )
					{
						CText* newCursorText = ((TextRenderer*)m_singleLine->Renderer(m_cursorPositionParaIndex))->GetText();
						if (newCursorText != NULL)
						{
							TextData* cursorData = (TextData*)m_singleLine->GetDataSource()->GetData(m_cursorPositionParaIndex);
							int indexUTF8 = bytes_to_offset(cursorData->textContent, m_cursorPositionCharIndex);
							m_SetParagraphFocus(newCursorText->TextActor(), indexUTF8, indexUTF8);
						}
					}
				}
			}

			int size = m_singleLine->GetDataSource()->Size();
			for (int i = 0; i < size; i++)
			{
				((TextData*)m_singleLine->GetDataSource()->GetData(i))->index = i;
			}
		}
	}

	void CRichText::m_DeleteTextEvent(ClutterText *self, gint start_pos, gint end_pos, gpointer user_data)
	{
		CRichText* pThis = (CRichText*)user_data;
		if (pThis->m_backspaceEventFlag || pThis->m_insertEventFlag || pThis->m_insertTextFlag || pThis->m_returnEventFlag)
		{
			return;
		}

		int cursorParaIndex = pThis->m_cursorPositionParaIndex;
		int cursorCharIndex = pThis->m_cursorPositionCharIndex;
		int boundParaIndex = pThis->m_boundPositionParaIndex;
		int boundCharIndex = pThis->m_boundPositionCharIndex;

		int size = pThis->m_singleLine->GetDataSource()->Size();
		if (cursorParaIndex < 0 || cursorParaIndex >(size - 1))
		{
			return;
		}

		if (cursorCharIndex == boundCharIndex && cursorParaIndex == boundParaIndex)
		{//select nothing
			const char* buf = clutter_text_get_text(CLUTTER_TEXT(self));
			int len = strlen(buf);
			TextData* data = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(cursorParaIndex);
			int start = offset_to_byte(data->textContent, start_pos);
			int end = offset_to_byte(data->textContent, end_pos);
			char *itemBuf;
			if (len == 0)
			{
				len = 1;
				itemBuf = new char[len];
				itemBuf[0] = '\0';
			}
			else
			{
				itemBuf = new char[len + 1];
				strncpy(itemBuf, buf, len);
				itemBuf[len] = '\0';
			}
			
			delete [] data->textContent;
			data->textContent = NULL;
			data->textContent = itemBuf;
			float height = (float)clutter_actor_get_height(CLUTTER_ACTOR(self));
			if ((int)height != (int)data->height)
			{
				pThis->m_singleLine->SetItemSpace(cursorParaIndex, height);
				data->height = height;
			}
			int cursorIndex = pThis->m_cursorPositionCharIndex;
			
			pThis->m_cursorPositionCharIndex = start;
			pThis->m_boundPositionCharIndex = start;

			pThis->m_UpdateParagraphAttrList(data->attrList, end, 0, end - start, 0);
			pango_attr_list_unref(data->attrList);
			data->attrList = NULL;
			data->attrList = pango_attr_list_copy(pThis->m_pangoAttrList);

			if (pThis->m_singleLine->Renderer(cursorParaIndex) != NULL)
			{
				CText* ctext = ((TextRenderer*)pThis->m_singleLine->Renderer(cursorParaIndex))->GetText();
				if (ctext != NULL && ctext->TextActor() == self)
				{
					clutter_text_set_attributes(ctext->TextActor(), data->attrList);
				}
			}
		}
	}

	void CRichText::m_InsertTextEvent(ClutterText *self, gchar *new_text, gint new_text_length, gint position, gpointer user_data)
	{
		CRichText* pThis = (CRichText*)user_data;
		
		if (new_text_length == 0)
		{
			if (pThis->m_backspaceEventFlag)
			{
				pThis->m_backspaceEventFlag = false;
			}
			return;
		}

		if (pThis->m_insertEventFlag)
		{
			return;
		}

		if (pThis->m_backspaceEventFlag)
		{
			pThis->m_backspaceEventFlag = false;
			return;
		}

		if (pThis->m_insertTextFlag)
		{
			pThis->m_insertTextFlag = false;
			return;
		}

		if (pThis->m_returnEventFlag)
		{
			pThis->m_returnEventFlag = false;
			return;
		}

		int selectionStartPara = 0;
		int selectionStartChar = 0;
		int selectionEndPara = 0;
		int selectionEndChar = 0;
		int selectionLen = 0;
		pThis->m_GetSelectionBoundData(selectionStartPara, selectionStartChar, selectionEndPara, selectionEndChar, selectionLen);

		if (selectionStartChar == selectionEndChar && selectionStartPara == selectionEndPara)
		{//select nothing
			int len = strlen(clutter_text_get_text(self));
			char* itemBuf = new char[len+1];
			const char* buf = clutter_text_get_text(self);
			strncpy(itemBuf, buf, len);
			itemBuf[len] = '\0';
			TextData* data = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara);
			delete [] data->textContent;
			data->textContent = NULL;
			data->textContent = itemBuf;
			
			float height = (float)clutter_actor_get_height(CLUTTER_ACTOR(self));
			if ((int)height != (int)data->height)
			{
				pThis->m_singleLine->SetItemSpace(selectionStartPara, height);
				data->height = height;
			}
			int cursorIndex = pThis->m_cursorPositionCharIndex;
			pThis->m_cursorPositionCharIndex += new_text_length;
			pThis->m_boundPositionCharIndex += new_text_length;

			pThis->m_UpdateParagraphAttrList(data->attrList, cursorIndex, new_text_length, 0, 0);
			pango_attr_list_unref(data->attrList);
			data->attrList = NULL;
			data->attrList = pango_attr_list_copy(pThis->m_pangoAttrList);
			if (pThis->m_singleLine->Renderer(selectionStartPara) != NULL)
			{
				CText* ctext = ((TextRenderer*)pThis->m_singleLine->Renderer(selectionStartPara))->GetText();
				if (ctext != NULL && ctext->TextActor() == self)
				{
					clutter_text_set_attributes(ctext->TextActor(), data->attrList);
				}
			}
		}
		else
		{
			if (selectionStartPara == selectionEndPara)
			{//select in the same para
				char* buf = ((TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara))->textContent;
				int len = strlen(buf);
				int newBufLen = len + new_text_length - (selectionEndChar - selectionStartChar);
				char* newBuf = new char[newBufLen + 1];
				for (int i = 0; i < selectionStartChar; i++)
				{
					newBuf[i] = buf[i];
				}
				for (int i = 0; i < new_text_length; i++)
				{
					newBuf[selectionStartChar + i] = new_text[i];
				}
				for (int i = 0; i < (len - selectionEndChar); i++)
				{
					newBuf[selectionStartChar + new_text_length + i] = buf[selectionEndChar + i];
				}
				newBuf[newBufLen] = '\0';
				TextData* data = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara);
				delete [] data->textContent;
				data->textContent = NULL;
				data->textContent = newBuf;
				pThis->m_cursorPositionCharIndex = selectionStartChar + new_text_length;
				pThis->m_boundPositionCharIndex = selectionStartChar + new_text_length;
				pThis->m_insertEventFlag = true;
				clutter_text_set_text(CLUTTER_TEXT(self), data->textContent);

				int cursorIndex = selectionStartChar;
				pThis->m_UpdateParagraphAttrList(data->attrList, cursorIndex, new_text_length, selectionEndChar - selectionStartChar, 0);
				pango_attr_list_unref(data->attrList);
				data->attrList = NULL;
				data->attrList = pango_attr_list_copy(pThis->m_pangoAttrList);
				if (pThis->m_singleLine->Renderer(selectionStartPara) != NULL)
				{
					CText* ctext = ((TextRenderer*)pThis->m_singleLine->Renderer(selectionStartPara))->GetText();
					if (ctext != NULL && ctext->TextActor() == self)
					{
						clutter_text_set_attributes(ctext->TextActor(), data->attrList);
					}
				}
			}
			else
			{//select in several para
				int offset = selectionEndPara - selectionStartPara;
				char* buf_startPara = ((TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara))->textContent;
				int len_startPara = strlen(buf_startPara);
				char* buf_endPara = ((TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionEndPara))->textContent;
				int len_endPara = strlen(buf_endPara);

				int newBufLen = selectionStartChar + new_text_length + len_endPara - selectionEndChar;
				char *newBuf = new char[newBufLen + 1];
				for (int i = 0; i < selectionStartChar; i++)
				{
					newBuf[i] = buf_startPara[i];
				}
				for (int i = 0; i < new_text_length; i++)
				{
					newBuf[selectionStartChar + i] = new_text[i];
				}
				for (int i = 0; i < (len_endPara - selectionEndChar); i++)
				{
					newBuf[selectionStartChar + new_text_length + i] = buf_endPara[selectionEndChar + i];
				}
				newBuf[newBufLen] = '\0';

				if (pThis->m_cursorPositionParaIndex < pThis->m_boundPositionParaIndex)
				{//cursor < bound
					TextData* dataHead = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(pThis->m_cursorPositionParaIndex);
					TextData* dataTail = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(pThis->m_boundPositionParaIndex);
					pThis->m_UpdateMergedParagraphAttrList(dataHead->attrList, dataTail->attrList, selectionStartChar, selectionEndChar, new_text_length);
					pango_attr_list_unref(dataHead->attrList);
					dataHead->attrList = NULL;
					dataHead->attrList = pango_attr_list_copy(pThis->m_pangoAttrList);

					delete[] dataHead->textContent;
					dataHead->textContent = NULL;
					dataHead->textContent = newBuf;
					pThis->m_singleLine->DeleteItem(selectionStartPara + 1, offset);//pThis->m_cursorPositionParaIndex 
				}
				else
				{//cursor > bound
					TextData* dataTail = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(pThis->m_cursorPositionParaIndex);
					TextData* dataHead = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(pThis->m_boundPositionParaIndex);
					pThis->m_UpdateMergedParagraphAttrList(dataHead->attrList, dataTail->attrList, selectionStartChar, selectionEndChar, new_text_length);
					pango_attr_list_unref(dataHead->attrList);
					dataHead->attrList = NULL;
					dataHead->attrList = pango_attr_list_copy(pThis->m_pangoAttrList);

					delete[] dataTail->textContent;
					dataTail->textContent = NULL;
					dataTail->textContent = newBuf;
					pThis->m_singleLine->DeleteItem(selectionStartPara, offset);//pThis->m_boundPositionParaIndex
				}

				int size = pThis->m_singleLine->GetDataSource()->Size();
				for (int i = 0; i < size; i++)
				{
					((TextData*)pThis->m_singleLine->GetDataSource()->GetData(i))->index = i;
				}
				pThis->m_cursorPositionParaIndex = selectionStartPara;
				pThis->m_boundPositionParaIndex = selectionStartPara;
				pThis->m_cursorPositionCharIndex = selectionStartChar + new_text_length;
				pThis->m_boundPositionCharIndex = selectionStartChar + new_text_length;
				pThis->m_insertEventFlag = true;
				clutter_text_set_text(CLUTTER_TEXT(self), ((TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara))->textContent);

				if (pThis->m_singleLine->Renderer(pThis->m_cursorPositionParaIndex) != NULL)
				{
					CText* textCurrent = ((TextRenderer*)pThis->m_singleLine->Renderer(pThis->m_cursorPositionParaIndex))->GetText();
					TextData* dataCurrent = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(pThis->m_cursorPositionParaIndex);
					if (textCurrent != NULL && textCurrent->TextActor() == self)
					{
						clutter_text_set_attributes(textCurrent->TextActor(), dataCurrent->attrList);
					}
				}
			}
		}
	}

	void CRichText::m_TextChangedEvent(ClutterText *self, gpointer user_data)
	{
		CRichText* pThis = (CRichText*)user_data;
		if (pThis->m_insertEventFlag)
		{
			float height = (float)clutter_actor_get_height(CLUTTER_ACTOR(self));
			TextData* data = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(pThis->m_cursorPositionParaIndex);
			if ((int)height != (int)data->height)
			{
				pThis->m_singleLine->SetItemSpace(pThis->m_cursorPositionParaIndex, height);
				data->height = height;
			}

			int curPosUTF8 = bytes_to_offset(data->textContent, pThis->m_cursorPositionCharIndex);
			clutter_text_set_cursor_position(self, curPosUTF8);
			clutter_text_set_selection_bound(self, curPosUTF8);

			pThis->m_insertEventFlag = false;
			return;
		}
	}
	void CRichText::m_KeyFocusInCb(ClutterActor* actor, CActor *pThis)
	{
		CFocusManager* pFocusManager = CFocusManager::GetInstance();

		if (pFocusManager)
		{
			if (pFocusManager->FocusedWindow() != pThis)
			{
				pFocusManager->SetFocusBySignal(pThis);
			}
		}
	}

	void CRichText::m_KeyFocusOutCb(ClutterActor* actor, CActor *pThis)
	{
		CFocusManager* pFocusManager = CFocusManager::GetInstance();

		if (pFocusManager)
		{
			if (pFocusManager->FocusedWindow() == pThis)
			{
				pFocusManager->KillFocusBySignal(pThis);
			}
		}
	}

	bool CRichText::m_KeyPressEvent(ClutterActor *actor, ClutterEvent *event, gpointer user_data)
	{
		CRichText* pThis = (CRichText*)user_data;
		if (!pThis->m_enableMultiLine || !pThis->m_enableEditable || pThis->m_enableHighLight)
		{
			return CLUTTER_EVENT_PROPAGATE;
		}
		event->key.source = pThis->t_actor;
		clutter_do_event(event);
		guint keyval = clutter_event_get_key_symbol(event);
		int cursorParaIndex = pThis->m_cursorPositionParaIndex;
		int cursorCharIndex = pThis->m_cursorPositionCharIndex;
		int boundParaIndex = pThis->m_boundPositionParaIndex;
		int boundCharIndex = pThis->m_boundPositionCharIndex;
#ifdef HAVE_ECORE_IMF
		Ecore_IMF_Event inputMethodEvent;
		if (pThis->m_imf_context && pThis->m_imf_context->imf_context && 
			pThis->m_imf_context->GetEcoreKeyEvent(event, &inputMethodEvent))
		{
			if (ecore_imf_context_filter_event(pThis->m_imf_context->imf_context, 
												ECORE_IMF_EVENT_KEY_DOWN, &inputMethodEvent))
			{
				return CLUTTER_EVENT_STOP;
			}
		}
#endif

		int size = pThis->m_singleLine->GetDataSource()->Size();
		if (pThis->m_singleLine->Renderer(cursorParaIndex) == NULL)
		{
			TRect rect = pThis->m_singleLine->VisibleAreaRect();
			float preHeight = 0;
			float offset = 0;
			if (cursorParaIndex >= size)
			{
				return true;
			}

			for (int i = 0; i < cursorParaIndex; i++)
			{
				preHeight += ((TextData*)pThis->m_singleLine->GetDataSource()->GetData(i))->height;
			}

			// when the cursor paragraph is out of the show rect. there is two step to do
			// 1, move it in show rect;
			float pw = 0;
			float ph = 0;
			pThis->GetSize(pw, ph);
			CText* textTmp = new CText();
			textTmp->Initialize(dynamic_cast<Widget*>(pThis), pw, ph);
			textTmp->EnableMultiLine(TRUE);
			pThis->SetFontInfo(textTmp);
			TextData* data = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(cursorParaIndex);
			textTmp->SetText(data->textContent);
			clutter_text_set_attributes(textTmp->TextActor(), data->attrList);
			clutter_actor_set_width(CLUTTER_ACTOR(textTmp->TextActor()), pw);
			PangoLayout *layout = clutter_text_get_layout(textTmp->TextActor());
			PangoRectangle pangoRect = { 0 };
			pango_layout_index_to_pos(layout, cursorCharIndex, &pangoRect);

			float curHeight = data->height;
			if ((preHeight + curHeight) <= rect.y)
			{// the current para is above the show rect top
				offset = -rect.y + (preHeight + (float)pangoRect.y / PANGO_SCALE);
				pThis->m_singleLine->ScrollVisibleArea(0, offset, false);
			}
			else if (preHeight >= (rect.y + rect.h))
			{// the current para is below the show rect bottom
				offset = -rect.y + (preHeight + (float)pangoRect.y / PANGO_SCALE + (float)pangoRect.height / PANGO_SCALE - rect.h);
				pThis->m_singleLine->ScrollVisibleArea(0, offset, false);
			}
			textTmp->Release();
			textTmp = NULL;

			// 2, reset the key event to the cursor paragraph
			if( pThis->m_singleLine->Renderer(cursorParaIndex) != NULL)
			{
				CText* ctext = ((TextRenderer*)pThis->m_singleLine->Renderer(cursorParaIndex))->GetText();
				if (ctext != NULL)
				{
					int indexUTF8 = bytes_to_offset(data->textContent, cursorCharIndex);
					pThis->m_SetParagraphFocus(ctext->TextActor(), indexUTF8, indexUTF8);
					event->key.source = (ClutterActor*)ctext->TextActor();
					clutter_do_event(event);
					event->key.source = actor;
					return true;
				}
			}
			return true;
		}
		else
		{
			float preHeight = 0;
			for (int i = 0; i < cursorParaIndex; i++)
			{
				preHeight += ((TextData*)pThis->m_singleLine->GetDataSource()->GetData(i))->height;
			}
			
			if( pThis->m_singleLine->Renderer(cursorParaIndex) != NULL )
			{
				TRect rect = pThis->m_singleLine->VisibleAreaRect();

				TextData* data = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(cursorParaIndex);
				PangoLayout *layout = clutter_text_get_layout(CLUTTER_TEXT(((TextRenderer*)pThis->m_singleLine->Renderer(cursorParaIndex))->GetText()->TextActor()));
				PangoRectangle cursorRect = { 0 };
				pango_layout_index_to_pos(layout, cursorCharIndex, &cursorRect);

				if (preHeight + (float)cursorRect.y / PANGO_SCALE < rect.y)
				{// 1. the cursor line is partly at the top of the show rect; 2. the cursor line is all above the top of the show rect.
					float offset = preHeight + (float)cursorRect.y / PANGO_SCALE - rect.y;
					pThis->m_singleLine->ScrollVisibleArea(0, offset, false);
				}

				if (preHeight + (float)cursorRect.y / PANGO_SCALE + (float)cursorRect.height / PANGO_SCALE > rect.y + rect.h)
				{// 1. the cursor line is partly at the bottom of the show rect; 2. the cursor line is all below the bottom of the show rect.
					float offset = preHeight + (float)cursorRect.y / PANGO_SCALE + (float)cursorRect.height / PANGO_SCALE - (rect.y + rect.h);
					pThis->m_singleLine->ScrollVisibleArea(0, offset, false);
				}
			}
		}

		int selectionStartPara = 0;
		int selectionStartChar = 0;
		int selectionEndPara = 0;
		int selectionEndChar = 0;
		int selectionLen = 0;
		pThis->m_GetSelectionBoundData(selectionStartPara, selectionStartChar, selectionEndPara, selectionEndChar, selectionLen);
		
		switch (keyval)
		{  
		case CLUTTER_KEY_Delete:

			if (selectionStartPara == selectionEndPara)
			{
				if (selectionStartChar == selectionEndChar)
				{
					int curParaLen = strlen(((TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara))->textContent);
					if (selectionStartChar == curParaLen && selectionStartPara < (size - 1))
					{
						TextData* dataHead = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara);
						const char* buf_head = dataHead->textContent;
						TextData* dataTail = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara + 1);
						const char* buf_tail = dataTail->textContent;
						int len_head = strlen(buf_head);
						int len_tail = strlen(buf_tail);

						int len = len_head + len_tail + 1;
						char* newBuf = new char[len];
						strncpy(newBuf, buf_head, len_head);
						strncpy(newBuf + len_head, buf_tail, len_tail);
						newBuf[len - 1] = '\0';

						// merge the two paragraph format
						pThis->m_UpdateMergedParagraphAttrList(dataHead->attrList, dataTail->attrList, selectionStartChar, 0, 0);
						pango_attr_list_unref(dataHead->attrList);
						dataHead->attrList = NULL;
						dataHead->attrList = pango_attr_list_copy(pThis->m_pangoAttrList);

						//TextData* data = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara);
						delete[] dataHead->textContent;
						dataHead->textContent = NULL;
						dataHead->textContent = newBuf;
						pThis->m_backspaceEventFlag = true;
						clutter_text_set_text(CLUTTER_TEXT(actor), newBuf);
						clutter_text_set_attributes(CLUTTER_TEXT(actor), dataHead->attrList);

						//dataHead = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara);
						float height = (float)clutter_actor_get_height(actor);
						if ((int)height != (int)dataHead->height)
						{
							pThis->m_singleLine->SetItemSpace(selectionStartPara, height);
							dataHead->height = height;
						}

						pThis->m_cursorPositionCharIndex = len_head;
						pThis->m_boundPositionCharIndex = len_head;
						pThis->m_cursorPositionParaIndex = selectionStartPara;
						pThis->m_boundPositionParaIndex = selectionStartPara;

						int curPosUTF8 = bytes_to_offset(dataHead->textContent, len_head);
						clutter_text_set_cursor_position(CLUTTER_TEXT(actor), curPosUTF8);
						clutter_text_set_selection_bound(CLUTTER_TEXT(actor), curPosUTF8);
						pThis->m_singleLine->DeleteItem(selectionStartPara + 1, 1);
						int size = pThis->m_singleLine->GetDataSource()->Size();
						for (int i = 0; i < size; i++)
						{
							((TextData*)pThis->m_singleLine->GetDataSource()->GetData(i))->index = i;
						}
						return CLUTTER_EVENT_STOP;
					}
				}
				else
				{
					TextData* data = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara);
					char* buf = data->textContent;
					int len = strlen(buf);
					int newBufLen = len - (selectionEndChar - selectionStartChar);

					if (newBufLen > 0)
					{
						char *newBuf = new char[newBufLen + 1];

						for (int i = 0; i < selectionStartChar; i++)
						{
							newBuf[i] = buf[i];
						}
						for (int i = 0; i < (len - selectionEndChar); i++)
						{
							newBuf[selectionStartChar + i] = buf[selectionEndChar + i];
						}
						newBuf[newBufLen] = '\0';
						delete [] data->textContent;
						data->textContent = NULL;
						data->textContent = newBuf;
					}
					else if (newBufLen == 0)
					{
						newBufLen = 1;
						char *newBuf = new char[newBufLen];
						newBuf[0] = '\0';
						delete [] data->textContent;
						data->textContent = NULL;
						data->textContent = newBuf;
					}

					pThis->m_UpdateParagraphAttrList(data->attrList, selectionEndChar, 0, selectionEndChar - selectionStartChar, 0);
					pango_attr_list_unref(data->attrList);
					data->attrList = NULL;
					data->attrList = pango_attr_list_copy(pThis->m_pangoAttrList);

					pThis->m_backspaceEventFlag = true;
					clutter_text_set_text(CLUTTER_TEXT(actor), data->textContent);
					clutter_text_set_attributes(CLUTTER_TEXT(actor), data->attrList);

					data = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara);
					float height = (float)clutter_actor_get_height(actor);
					if ((int)height != (int)data->height)
					{
						pThis->m_singleLine->SetItemSpace(selectionStartPara, height);
						data->height = height;
					}
					pThis->m_cursorPositionCharIndex = selectionStartChar;
					pThis->m_boundPositionCharIndex = selectionStartChar;
					int curPosUTF8 = bytes_to_offset(data->textContent, selectionStartChar);
					clutter_text_set_cursor_position(CLUTTER_TEXT(actor), curPosUTF8);
					clutter_text_set_selection_bound(CLUTTER_TEXT(actor), curPosUTF8);
					return CLUTTER_EVENT_STOP;
				}
			}
			else
			{//selection in several para
				int offset = selectionEndPara - selectionStartPara;
				TextData* dataStart = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara);
				char* buf_startPara = dataStart->textContent;
				int len_startPara = strlen(buf_startPara);

				TextData* dataEnd = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionEndPara);
				char* buf_endPara = dataEnd->textContent;
				int len_endPara = strlen(buf_endPara);

				int newBufLen = selectionStartChar + len_endPara - selectionEndChar;
				char *newBuf;
				if (newBufLen == 0)
				{
					newBufLen = 1;
					newBuf = new char[newBufLen];
					newBuf[0] = '\0';
				}
				else
				{
					newBuf = new char[newBufLen + 1];
					for (int i = 0; i < selectionStartChar; i++)
					{
						newBuf[i] = buf_startPara[i];
					}
					for (int i = 0; i < (len_endPara - selectionEndChar); i++)
					{
						newBuf[selectionStartChar + i] = buf_endPara[selectionEndChar + i];
					}
					newBuf[newBufLen] = '\0';
				}

				pThis->m_UpdateMergedParagraphAttrList(dataStart->attrList, dataEnd->attrList, selectionStartChar, selectionEndChar, 0);
				
				if (pThis->m_cursorPositionParaIndex < pThis->m_boundPositionParaIndex)
				{//cursor < bound
					pango_attr_list_unref(dataStart->attrList);
					dataStart->attrList = NULL;
					dataStart->attrList = pango_attr_list_copy(pThis->m_pangoAttrList);

					delete[] dataStart->textContent;
					dataStart->textContent = NULL;
					dataStart->textContent = newBuf;
					pThis->m_backspaceEventFlag = true;
					clutter_text_set_text(CLUTTER_TEXT(actor), dataStart->textContent);
					clutter_text_set_attributes(CLUTTER_TEXT(actor), dataStart->attrList);

					float height = (float)clutter_actor_get_height(actor);
					if ((int)height != (int)dataStart->height)
					{
						pThis->m_singleLine->SetItemSpace(selectionStartPara, height);
						dataStart->height = height;
					}
					pThis->m_singleLine->DeleteItem(selectionStartPara + 1, offset);//pThis->m_cursorPositionParaIndex
				}
				else
				{//cursor > bound
					pango_attr_list_unref(dataEnd->attrList);
					dataEnd->attrList = NULL;
					dataEnd->attrList = pango_attr_list_copy(pThis->m_pangoAttrList);

					delete[] dataEnd->textContent;
					dataEnd->textContent = NULL;
					dataEnd->textContent = newBuf;
					pThis->m_backspaceEventFlag = true;
					clutter_text_set_text(CLUTTER_TEXT(actor), dataEnd->textContent);
					clutter_text_set_attributes(CLUTTER_TEXT(actor), dataEnd->attrList);

					float height = (float)clutter_actor_get_height(actor);
					if ((int)height != (int)dataEnd->height)
					{
						pThis->m_singleLine->SetItemSpace(selectionEndPara, height);
						dataEnd->height = height;
					}
					pThis->m_singleLine->DeleteItem(selectionStartPara, offset);//pThis->m_boundPositionParaIndex
				}

				int size = pThis->m_singleLine->GetDataSource()->Size();
				for (int i = 0; i < size; i++)
				{
					((TextData*)pThis->m_singleLine->GetDataSource()->GetData(i))->index = i;
				}
				pThis->m_cursorPositionParaIndex = selectionStartPara;
				pThis->m_boundPositionParaIndex = selectionStartPara;
				pThis->m_cursorPositionCharIndex = selectionStartChar;
				pThis->m_boundPositionCharIndex = selectionStartChar;
				int curPosUTF8 = bytes_to_offset(dataStart->textContent, selectionStartChar);
				clutter_text_set_cursor_position(CLUTTER_TEXT(actor), curPosUTF8);
				clutter_text_set_selection_bound(CLUTTER_TEXT(actor), curPosUTF8);
				return CLUTTER_EVENT_STOP;
			}
			break;
		case CLUTTER_KEY_BackSpace:
			
			if (selectionStartPara == selectionEndPara)
			{//selection in the same para
				if (selectionStartChar == selectionEndChar)
				{
					if (selectionStartChar == 0 && selectionStartPara > 0)
					{
						TextData* dataHead = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara - 1);
						const char* buf_head = dataHead->textContent;
						TextData* dataTail = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara);
						const char* buf_tail = dataTail->textContent;
						int len_head = strlen(buf_head);
						int len_tail = strlen(buf_tail);

						int len = len_head + len_tail + 1;
						char* newBuf = new char[len];
						strncpy(newBuf, buf_head, len_head);
						strncpy(newBuf + len_head, buf_tail, len_tail);
						newBuf[len - 1] = '\0';

						// merge the two paragraph format
						pThis->m_UpdateMergedParagraphAttrList(dataHead->attrList, dataTail->attrList, len_head, 0, 0);
						pango_attr_list_unref(dataTail->attrList);
						dataTail->attrList = NULL;
						dataTail->attrList = pango_attr_list_copy(pThis->m_pangoAttrList);

						delete[] dataTail->textContent;
						dataTail->textContent = NULL;
						dataTail->textContent = newBuf;
						pThis->m_backspaceEventFlag = true;
						clutter_text_set_text(CLUTTER_TEXT(actor), newBuf);
						clutter_text_set_attributes(CLUTTER_TEXT(actor), dataTail->attrList);

						float height = (float)clutter_actor_get_height(actor);
						if ((int)height != (int)dataTail->height)
						{
							pThis->m_singleLine->SetItemSpace(selectionStartPara, height);
							dataTail->height = height;
						}

						pThis->m_cursorPositionCharIndex = len_head;
						pThis->m_boundPositionCharIndex = len_head;
						pThis->m_cursorPositionParaIndex = selectionStartPara - 1;
						pThis->m_boundPositionParaIndex = selectionStartPara - 1;
						int curPosUTF8 = bytes_to_offset(dataTail->textContent, len_head);
						clutter_text_set_cursor_position(CLUTTER_TEXT(actor), curPosUTF8);
						clutter_text_set_selection_bound(CLUTTER_TEXT(actor), curPosUTF8);
						pThis->m_singleLine->DeleteItem(selectionStartPara - 1, 1);
						int size = pThis->m_singleLine->GetDataSource()->Size();
						for (int i = 0; i < size; i++)
						{
							((TextData*)pThis->m_singleLine->GetDataSource()->GetData(i))->index = i;
						}
						return CLUTTER_EVENT_STOP;
					}
				}
				else
				{
					TextData* data = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara);
					char* buf = data->textContent;
					int len = strlen(buf);
					int newBufLen = len - (selectionEndChar - selectionStartChar);
					
					if (newBufLen > 0)
					{
						char *newBuf = new char[newBufLen + 1];
						
						for (int i = 0; i < selectionStartChar; i++)
						{
							newBuf[i] = buf[i];
						}
						for (int i = 0; i < (len - selectionEndChar); i++)
						{
							newBuf[selectionStartChar + i] = buf[selectionEndChar + i];
						}
						newBuf[newBufLen] = '\0';
						delete [] data->textContent;
						data->textContent = NULL;
						data->textContent = newBuf;
					}
					else if (newBufLen == 0)
					{
						newBufLen = 1;
						char *newBuf = new char[newBufLen];
						newBuf[0] = '\0';
						delete [] data->textContent;
						data->textContent = NULL;
						data->textContent = newBuf;
					}

					pThis->m_UpdateParagraphAttrList(data->attrList, selectionEndChar, 0, selectionEndChar - selectionStartChar, 0);
					pango_attr_list_unref(data->attrList);
					data->attrList = NULL;
					data->attrList = pango_attr_list_copy(pThis->m_pangoAttrList);

					pThis->m_backspaceEventFlag = true;
					clutter_text_set_text(CLUTTER_TEXT(actor), data->textContent);
					clutter_text_set_attributes(CLUTTER_TEXT(actor), data->attrList);

					data = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara);
					float height = (float)clutter_actor_get_height(actor);
					if ((int)height != (int)data->height)
					{
						pThis->m_singleLine->SetItemSpace(selectionStartPara, height);
						data->height = height;
					}
					pThis->m_cursorPositionCharIndex = selectionStartChar;
					pThis->m_boundPositionCharIndex = selectionStartChar;
					int curPosUTF8 = bytes_to_offset(data->textContent, selectionStartChar);
					clutter_text_set_cursor_position(CLUTTER_TEXT(actor), curPosUTF8);
					clutter_text_set_selection_bound(CLUTTER_TEXT(actor), curPosUTF8);
					return CLUTTER_EVENT_STOP;
				}
			}
			else
			{//selection in several para
				int offset = selectionEndPara - selectionStartPara;

				TextData* dataStart = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara);
				char* buf_startPara = dataStart->textContent;
				int len_startPara = strlen(buf_startPara);

				TextData* dataEnd = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionEndPara);
				char* buf_endPara = dataEnd->textContent;
				int len_endPara = strlen(buf_endPara);

				int newBufLen = selectionStartChar + len_endPara - selectionEndChar;
				char *newBuf;
				if (newBufLen == 0)
				{
					newBufLen = 1;
					newBuf = new char[newBufLen];
					newBuf[0] = '\0';
				}
				else
				{
					newBuf = new char[newBufLen + 1];
					for (int i = 0; i < selectionStartChar; i++)
					{
						newBuf[i] = buf_startPara[i];
					}
					for (int i = 0; i < (len_endPara - selectionEndChar); i++)
					{
						newBuf[selectionStartChar + i] = buf_endPara[selectionEndChar + i];
					}
					newBuf[newBufLen] = '\0';
				}

				pThis->m_UpdateMergedParagraphAttrList(dataStart->attrList, dataEnd->attrList, selectionStartChar, selectionEndChar, 0);
				
				if (pThis->m_cursorPositionParaIndex < pThis->m_boundPositionParaIndex)
				{//cursor < bound
					pango_attr_list_unref(dataStart->attrList);
					dataStart->attrList = NULL;
					dataStart->attrList = pango_attr_list_copy(pThis->m_pangoAttrList);

					delete[] dataStart->textContent;
					dataStart->textContent = NULL;
					dataStart->textContent = newBuf;
					pThis->m_backspaceEventFlag = true;
					clutter_text_set_text(CLUTTER_TEXT(actor), dataStart->textContent);
					clutter_text_set_attributes(CLUTTER_TEXT(actor), dataStart->attrList);

					float height = (float)clutter_actor_get_height(actor);
					if ((int)height != (int)dataStart->height)
					{
						pThis->m_singleLine->SetItemSpace(selectionStartPara, height);
						dataStart->height = height;
					}
					pThis->m_singleLine->DeleteItem(selectionStartPara + 1, offset);//pThis->m_cursorPositionParaIndex
				}
				else
				{//cursor > bound
					pango_attr_list_unref(dataEnd->attrList);
					dataEnd->attrList = NULL;
					dataEnd->attrList = pango_attr_list_copy(pThis->m_pangoAttrList);

					delete[] dataEnd->textContent;
					dataEnd->textContent = NULL;
					dataEnd->textContent = newBuf;
					pThis->m_backspaceEventFlag = true;
					clutter_text_set_text(CLUTTER_TEXT(actor), dataEnd->textContent);
					clutter_text_set_attributes(CLUTTER_TEXT(actor), dataEnd->attrList);

					float height = (float)clutter_actor_get_height(actor);
					if ((int)height != (int)dataEnd->height)
					{
						pThis->m_singleLine->SetItemSpace(selectionEndPara, height);
						dataEnd->height = height;
					}
					pThis->m_singleLine->DeleteItem(selectionStartPara, offset);//pThis->m_boundPositionParaIndex
				}

				int size = pThis->m_singleLine->GetDataSource()->Size();
				for (int i = 0; i < size; i++)
				{
					((TextData*)pThis->m_singleLine->GetDataSource()->GetData(i))->index = i;
				}
				pThis->m_cursorPositionParaIndex = selectionStartPara;
				pThis->m_boundPositionParaIndex = selectionStartPara;
				pThis->m_cursorPositionCharIndex = selectionStartChar;
				pThis->m_boundPositionCharIndex = selectionStartChar;

				TextData* cursorData = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara);
				int curPosUTF8 = bytes_to_offset(cursorData->textContent, selectionStartChar);
				clutter_text_set_cursor_position(CLUTTER_TEXT(actor), curPosUTF8);
				clutter_text_set_selection_bound(CLUTTER_TEXT(actor), curPosUTF8);
				return CLUTTER_EVENT_STOP;
			}
			break;
		case CLUTTER_KEY_Return:
			float pWidth, pHeight;
			pThis->GetSize(pWidth, pHeight);

			if (selectionStartPara == selectionEndPara)
			{
				//1. modify the current para
				TextData* curData = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara);
				char* currentBuf = curData->textContent;
				int currentLen = strlen(currentBuf);

				bool curTextNeedsToChangeFlag = true;
				char* nextParaBuf;
				if (selectionStartChar == selectionEndChar)
				{//selection nothing
					if (selectionStartChar == currentLen)
					{
						curTextNeedsToChangeFlag = false;
						nextParaBuf = new char[1];
						nextParaBuf[0] = '\0';
					}
					else
					{
						nextParaBuf = new char[currentLen - selectionStartChar + 1];
						strncpy(nextParaBuf, currentBuf + selectionStartChar, (currentLen - selectionStartChar));
						nextParaBuf[currentLen - selectionStartChar] = '\0';
					}
				}
				else
				{//selection something, split the para and reserve the part from the selectionEndChar to the para end.
					nextParaBuf = new char[currentLen - selectionEndChar + 1];
					strncpy(nextParaBuf, currentBuf + selectionEndChar, (currentLen - selectionEndChar));
					nextParaBuf[currentLen - selectionEndChar] = '\0';
				}

				PangoAttrList* nextAttrList;
				if (curTextNeedsToChangeFlag)
				{
					char* newCurrentBuf = new char[selectionStartChar + 1];
					strncpy(newCurrentBuf, currentBuf, selectionStartChar);
					newCurrentBuf[selectionStartChar] = '\0';

					delete [] curData->textContent;
					curData->textContent = NULL;
					curData->textContent = newCurrentBuf;
					pThis->m_returnEventFlag = true;

					nextAttrList = pango_attr_list_copy(curData->attrList);
					pThis->m_UpdateParagraphAttrList(curData->attrList, currentLen, 0, currentLen - selectionStartChar, 0);
					pango_attr_list_unref(curData->attrList);
					curData->attrList = NULL;
					curData->attrList = pango_attr_list_copy(pThis->m_pangoAttrList);

					if( pThis->m_singleLine->Renderer(selectionStartPara) != NULL )
					{
						CText* curText = ((TextRenderer*)pThis->m_singleLine->Renderer(selectionStartPara))->GetText();
						clutter_text_set_text(curText->TextActor(), curData->textContent);
						clutter_text_set_attributes(curText->TextActor(), curData->attrList);

						float height = (float)clutter_actor_get_height(actor);
						if ((int)height != (int)curData->height)
						{
							pThis->m_singleLine->SetItemSpace(selectionStartPara, height);
							curData->height = height;
						}
					}
				}
				else
				{
					nextAttrList = pango_attr_list_new();
				}
				
				//2. new a next para
				TextData* data = new TextData;
				data->SetDataLoadType(IData::E_LOAD_TYPE_SYNC);
				data->textContent = nextParaBuf;
				data->index = selectionStartPara + 1;
				data->attrList = pango_attr_list_new();
				data->alignment = 0;

				pThis->m_UpdateParagraphAttrList(nextAttrList, selectionEndChar, 0, selectionEndChar, 0);
				pango_attr_list_unref(data->attrList);
				data->attrList = NULL;
				data->attrList = pango_attr_list_copy(pThis->m_pangoAttrList);

				CText* textTmp = new CText();
				textTmp->Initialize(dynamic_cast<Widget*>(pThis), pWidth, pHeight);
				textTmp->EnableMultiLine(TRUE);
				pThis->SetFontInfo(textTmp);

				textTmp->SetText(data->textContent);
				clutter_actor_set_width(CLUTTER_ACTOR(textTmp->TextActor()), pWidth);
				data->height = (float)clutter_actor_get_height(CLUTTER_ACTOR(textTmp->TextActor()));
				textTmp->Release();
				textTmp = NULL;

				pThis->m_singleLine->GetDataSource()->InsertData(selectionStartPara + 1, data);
				pThis->m_singleLine->InsertItem(selectionStartPara + 1, 1, data->height);
				pThis->m_singleLine->LoadData();

			}
			else
			{//del the selection, reserve the selection start para and end para
				//1. modify the current para
				TextData* curData = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionStartPara);
				char* currentBuf = curData->textContent;
				int currentLen = strlen(currentBuf);

				char* newCurrentBuf = new char[selectionStartChar + 1];
				strncpy(newCurrentBuf, currentBuf, selectionStartChar);
				newCurrentBuf[selectionStartChar] = '\0';

				delete curData->textContent;
				curData->textContent = NULL;
				curData->textContent = newCurrentBuf;

				pThis->m_UpdateParagraphAttrList(curData->attrList, currentLen, 0, currentLen - selectionStartChar, 0);
				pango_attr_list_unref(curData->attrList);
				curData->attrList = NULL;
				curData->attrList = pango_attr_list_copy(pThis->m_pangoAttrList);

				pThis->m_returnEventFlag = true;
				if( pThis->m_singleLine->Renderer(selectionStartPara) != NULL )
				{
					CText* startText = ((TextRenderer*)pThis->m_singleLine->Renderer(selectionStartPara))->GetText();
					if (startText != NULL)
					{
						clutter_text_set_text(startText->TextActor(), curData->textContent);
						clutter_text_set_attributes(startText->TextActor(), curData->attrList);

						float height = (float)clutter_actor_get_height(CLUTTER_ACTOR(startText->TextActor()));
						if ((int)height != (int)curData->height)
						{
							pThis->m_singleLine->SetItemSpace(selectionStartPara, height);
							curData->height = height;
						}
					}
				}
				//2. save next para text and modify the para
				TextData* nextData = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(selectionEndPara);
				char* nextParaBuf = nextData->textContent;
				int nextParaLen = strlen(nextParaBuf);
				char* newNextParaBuf = new char[nextParaLen - selectionEndChar + 1];
				strncpy(newNextParaBuf, nextParaBuf + selectionEndChar, (nextParaLen - selectionEndChar));
				newNextParaBuf[nextParaLen - selectionEndChar] = '\0';
				delete [] nextData->textContent;
				nextData->textContent = NULL;
				nextData->textContent = newNextParaBuf;
				pThis->m_returnEventFlag = true;

				pThis->m_UpdateParagraphAttrList(nextData->attrList, selectionEndChar, 0, selectionEndChar, 0);
				pango_attr_list_unref(nextData->attrList);
				nextData->attrList = NULL;
				nextData->attrList = pango_attr_list_copy(pThis->m_pangoAttrList);

				if( pThis->m_singleLine->Renderer(selectionEndPara) != NULL )
				{
					CText* endText = ((TextRenderer*)pThis->m_singleLine->Renderer(selectionEndPara))->GetText();
					clutter_text_set_text(endText->TextActor(), nextData->textContent);
					clutter_text_set_attributes(endText->TextActor(), nextData->attrList);

					float height = (float)clutter_actor_get_height(CLUTTER_ACTOR(endText->TextActor()));
					if ((int)height != (int)nextData->height)
					{
						pThis->m_singleLine->SetItemSpace(selectionEndPara, height);
						nextData->height = height;
					}
				}
				//3. delete the middle para which is selection
				int deleteLen = selectionEndPara - selectionStartPara - 1;
				pThis->m_singleLine->DeleteItem(selectionStartPara + 1, deleteLen);
			}

			size = pThis->m_singleLine->GetDataSource()->Size();
			for (int i = 0; i < size; i++)
			{
				((TextData*)pThis->m_singleLine->GetDataSource()->GetData(i))->index = i;
			}

			pThis->m_cursorPositionParaIndex = selectionStartPara + 1;
			pThis->m_cursorPositionCharIndex = 0;
			pThis->m_boundPositionParaIndex = selectionStartPara + 1;
			pThis->m_boundPositionCharIndex = 0;

			if (pThis->m_singleLine->Renderer(pThis->m_cursorPositionParaIndex) == NULL)
			{
				float pw = 0;
				float ph = 0;
				pThis->GetSize(pw, ph);
				CText* textTmp = new CText();
				textTmp->Initialize(dynamic_cast<Widget*>(pThis), pw, ph);
				textTmp->EnableMultiLine(TRUE);
				pThis->SetFontInfo(textTmp);
				TextData* tmpData = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(pThis->m_cursorPositionParaIndex);
				textTmp->SetText(tmpData->textContent);
				clutter_text_set_attributes(textTmp->TextActor(), tmpData->attrList);
				clutter_actor_set_width(CLUTTER_ACTOR(textTmp->TextActor()), pw);
				PangoLayout *layout = clutter_text_get_layout(textTmp->TextActor());
				PangoRectangle pangoRect = { 0 };
				pango_layout_index_to_pos(layout, pThis->m_cursorPositionParaIndex, &pangoRect);

				float preHeight = 0;
				for (int i = 0; i < pThis->m_cursorPositionParaIndex; i++)
				{
					preHeight += ((TextData*)pThis->m_singleLine->GetDataSource()->GetData(i))->height;
				}
				TRect rect = pThis->m_singleLine->VisibleAreaRect();

				if (preHeight >= (rect.y + rect.h))
				{// the new para is below the show rect bottom
					float offset = -rect.y + (preHeight + (float)pangoRect.y / PANGO_SCALE + (float)pangoRect.height / PANGO_SCALE - rect.h);
					pThis->m_singleLine->ScrollVisibleArea(0, offset, false);
				}
				textTmp->Release();
				textTmp = NULL;
			}
			else
			{
				float preHeight = 0;
				for (int i = 0; i < pThis->m_cursorPositionParaIndex; i++)
				{
					preHeight += ((TextData*)pThis->m_singleLine->GetDataSource()->GetData(i))->height;
				}
				TRect rect = pThis->m_singleLine->VisibleAreaRect();

				TextData* data = (TextData*)pThis->m_singleLine->GetDataSource()->GetData(pThis->m_cursorPositionParaIndex);
				PangoLayout *layout = clutter_text_get_layout(CLUTTER_TEXT(((TextRenderer*)pThis->m_singleLine->Renderer(pThis->m_cursorPositionParaIndex))->GetText()->TextActor()));
				PangoRectangle pangoRect = { 0 };
				pango_layout_index_to_pos(layout, pThis->m_cursorPositionCharIndex, &pangoRect);

				if (preHeight < (rect.y + rect.h) && (preHeight + (float)pangoRect.y / PANGO_SCALE + (float)pangoRect.height / PANGO_SCALE > (rect.y + rect.h)))
				{// the cursor line is partly keep out on the bottom of the show rect
					float offset = preHeight + (float)pangoRect.y / PANGO_SCALE + (float)pangoRect.height / PANGO_SCALE - (rect.y + rect.h);
					pThis->m_singleLine->ScrollVisibleArea(0, offset, false);
				}

			}

			if( pThis->m_singleLine->Renderer(pThis->m_cursorPositionParaIndex) != NULL )
			{
				if (((TextRenderer*)pThis->m_singleLine->Renderer(pThis->m_cursorPositionParaIndex))->GetText() != NULL)
				{
					pThis->m_SetParagraphFocus(((TextRenderer*)pThis->m_singleLine->Renderer(pThis->m_cursorPositionParaIndex))->GetText()->TextActor(), pThis->m_cursorPositionCharIndex, pThis->m_boundPositionCharIndex);
				}
			}
			break;
		case CLUTTER_KEY_Up:
			pThis->MoveCursor(DIRECTION_UP);
			return CLUTTER_EVENT_STOP;
			break;
		case CLUTTER_KEY_Down:
			pThis->MoveCursor(DIRECTION_DOWN);
			return CLUTTER_EVENT_STOP;
			break;
		case CLUTTER_KEY_Left:
			pThis->MoveCursor(DIRECTION_LEFT);
			return CLUTTER_EVENT_STOP;
			break;
		case CLUTTER_KEY_Right:
			pThis->MoveCursor(DIRECTION_RIGHT);
			return CLUTTER_EVENT_STOP;
			break;
#ifdef HAVE_ECORE_IMF
		case CLUTTER_KEY_Select:
			if (pThis->m_imf_context && pThis->m_imf_context->imf_context)
			{
				pThis->m_imf_context->IMEInputDone();
				return CLUTTER_EVENT_STOP;
			}
			break;
		case CLUTTER_KEY_Cancel:
			if (pThis->m_imf_context && pThis->m_imf_context->imf_context)
			{
				pThis->m_imf_context->IMEInputCancel();
				return CLUTTER_EVENT_STOP;
			}
			break;
		case CLUTTER_KEY_Clear:
			if (pThis->m_imf_context && pThis->m_imf_context->imf_context)
			{		
				pThis->SetText("");
				return CLUTTER_EVENT_STOP;
			}
			break;
#endif
		default:
			break;
		}
		return CLUTTER_EVENT_PROPAGATE;
	}

	bool CRichText::m_KeyReleaseEvent(ClutterActor *actor, ClutterEvent *event, gpointer user_data)
	{
#ifdef HAVE_ECORE_IMF

		CRichText  *pThis = (CRichText *)user_data;

		if (pThis == NULL)
		{
			return CLUTTER_EVENT_PROPAGATE;
		}

		Ecore_IMF_Event inputMethodEvent;
		if (pThis->m_imf_context && pThis->m_imf_context->imf_context &&
			pThis->m_imf_context->GetEcoreKeyEvent(event, &inputMethodEvent))
		{
			if (ecore_imf_context_filter_event(pThis->m_imf_context->imf_context, 
												ECORE_IMF_EVENT_KEY_UP, 
												&inputMethodEvent))
			{
				return CLUTTER_EVENT_STOP;
			}
		}
		return CLUTTER_EVENT_PROPAGATE;
#else
		return CLUTTER_EVENT_PROPAGATE;
#endif	
	}
	
	bool CRichText::m_MouseMoveEvent(ClutterActor *actor, ClutterEvent *event, gpointer user_data)
	{
		CRichText* pThis = (CRichText*)user_data;
		
		if (!pThis->m_mousePressState)
		{
			return CLUTTER_EVENT_PROPAGATE;
		}

		if (!pThis->m_enableSelectable)
		{
			return CLUTTER_EVENT_PROPAGATE;
		}

		gfloat event_x, event_y;
		clutter_event_get_coords(event, &event_x, &event_y);
		TRect rect = pThis->m_singleLine->VisibleAreaRect();

		float  view_x, view_y;
		pThis->GetPosition(view_x, view_y);
		float offset_x = event_x - view_x + rect.x;
		float offset_y = event_y - view_y + rect.y;

		int indexPara = 0;
		int indexChar = 0;
		float totalHeight = 0;
		float currentPara_H = 0;
		int itemSize = pThis->m_singleLine->GetDataSource()->Size();
		for (int i = 0; i < itemSize; i++)
		{
			currentPara_H = ((TextData*)pThis->m_singleLine->GetDataSource()->GetData(i))->height;
			if (offset_y >= totalHeight && offset_y < (totalHeight + currentPara_H))
			{
				indexPara = ((TextData*)pThis->m_singleLine->GetDataSource()->GetData(i))->index;

				int offset = clutter_text_coords_to_position(CLUTTER_TEXT(actor), offset_x, offset_y - totalHeight);
				const char* buf = clutter_text_get_text(CLUTTER_TEXT(actor));
				int indexUTF8 = bytes_to_offset(buf, offset);
				indexChar = offset_to_byte(buf, indexUTF8);

				break;
			}
			totalHeight += currentPara_H;
		}
		pThis->m_boundPositionParaIndex = indexPara;
		pThis->m_boundPositionCharIndex = indexChar;
		return CLUTTER_EVENT_PROPAGATE;
	}

	bool CRichText::m_MousePressEvent(ClutterActor *actor, ClutterEvent *event, gpointer user_data)
	{
		CRichText* pThis = (CRichText*)user_data;
		if (!clutter_actor_has_key_focus(actor))
		{
			pThis->m_focusChangeFlag = true;
		}
		else
		{
			pThis->m_focusChangeFlag = false;
		}
		//clutter_actor_grab_key_focus(actor);
		pThis->m_mousePressState = true;
		pThis->m_cursorPositionParaIndex = 0;
		pThis->m_cursorPositionCharIndex = 0;
		pThis->m_boundPositionParaIndex = 0;
		pThis->m_boundPositionCharIndex = 0;
	
		gfloat event_x, event_y;
		clutter_event_get_coords(event, &event_x, &event_y);
		TRect rect = pThis->m_singleLine->VisibleAreaRect();

		float  view_x, view_y;
		pThis->GetPosition(view_x, view_y);
		float offset_x = event_x - view_x + rect.x;
		float offset_y = event_y - view_y + rect.y;

		int indexPara = 0;
		int indexChar = 0;
		float totalHeight = 0;
		float currentPara_H = 0;
		int itemSize = pThis->m_singleLine->GetDataSource()->Size();
		for (int i = 0; i < itemSize; i++)
		{
			currentPara_H = ((TextData*)pThis->m_singleLine->GetDataSource()->GetData(i))->height;
			if (offset_y >= totalHeight && offset_y < (totalHeight + currentPara_H))
			{
				indexPara = ((TextData*)pThis->m_singleLine->GetDataSource()->GetData(i))->index;
				
				int offsetPos = clutter_text_coords_to_position(CLUTTER_TEXT(actor), offset_x, offset_y - totalHeight);
				const char* buf = clutter_text_get_text(CLUTTER_TEXT(actor));
				int indexUTF8 = bytes_to_offset(buf, offsetPos);
				clutter_text_set_cursor_position(CLUTTER_TEXT(actor), indexUTF8);
				clutter_text_set_selection_bound(CLUTTER_TEXT(actor), indexUTF8);

				indexChar = offset_to_byte(buf, indexUTF8);
				// scroll animation, when the current cursor is partly show in the show region.
				PangoRectangle rect_cursor = { 0 };
				if( pThis->m_singleLine->Renderer(indexPara) == NULL )
				{
					break;
				}
				pango_layout_index_to_pos(clutter_text_get_layout(((TextRenderer*)pThis->m_singleLine->Renderer(indexPara))->GetText()->TextActor()), indexChar, &rect_cursor);
				int count = indexPara;
				int heightCount = 0;
				for (int i = 0; i < count; i++)
				{
					heightCount += (int)((TextData*)pThis->m_singleLine->GetDataSource()->GetData(i))->height;
				}	
				
				int newCursor_y = heightCount + rect_cursor.y / PANGO_SCALE - (int)rect.y;
				float par_w, par_h;
				pThis->GetSize(par_w, par_h);
				int offset = 0;
				if (par_h >= newCursor_y && par_h < (newCursor_y + rect_cursor.height / PANGO_SCALE))
				{
					offset = newCursor_y + rect_cursor.height / PANGO_SCALE - (int)par_h;
					pThis->m_singleLine->ScrollVisibleArea(0, (float)offset, false);
					break;
				}

				if (newCursor_y < 0 && (newCursor_y + rect_cursor.height / PANGO_SCALE) > 0)
				{
					pThis->m_singleLine->ScrollVisibleArea(0, (float)newCursor_y, false);
					break;
				}

				break;
			}
			totalHeight += currentPara_H;
		}

		pThis->m_cursorPositionParaIndex = indexPara;
		pThis->m_cursorPositionCharIndex = indexChar;
		pThis->m_boundPositionParaIndex = indexPara;
		pThis->m_boundPositionCharIndex = indexChar;
		clutter_actor_grab_key_focus(actor);

#ifdef HAVE_ECORE_IMF
		if (pThis->m_imf_context && pThis->m_imf_context->imf_context && pThis->m_imf_context->focused &&
			pThis->m_imf_context->preedit_len > 0)
		{
			pThis->m_pressPositionPara = indexPara;
			pThis->m_pressPositionChar = indexChar;
			ecore_imf_context_reset(pThis->m_imf_context->imf_context);
		}
#endif

		return CLUTTER_EVENT_PROPAGATE;
	}
	
	void CRichText::ResetCursorPosition(void)
	{
		if (m_pressPositionPara >= 0)
		{
			m_cursorPositionParaIndex = m_pressPositionPara;
			m_cursorPositionCharIndex = m_pressPositionChar;
			m_boundPositionParaIndex = m_pressPositionPara;
			m_boundPositionCharIndex = m_pressPositionChar;
			m_pressPositionPara = -1;
		}
	}

	bool CRichText::m_MouseReleaseEvent(ClutterActor *actor, ClutterEvent *event, gpointer user_data)
	{
		CRichText* pThis = (CRichText*)user_data;
		pThis->m_mousePressState = false;
		return CLUTTER_EVENT_PROPAGATE;
	}

	void CRichText::m_UpdateSelection(int& x, int& y)
	{
		
	}

	void CRichText::EnableSelectable(bool flagSelectable)
	{
		if (m_enableSelectable == flagSelectable || m_enableHighLight || !m_enableEditable)
		{
			return;
		}
		m_enableSelectable = flagSelectable;
		m_enableSelectablePreState = flagSelectable;

		if (!m_enableMultiLine)
		{
			clutter_text_set_selectable(m_text->TextActor(), flagSelectable);
			if (!flagSelectable)
			{
				int cursorPos = clutter_text_get_cursor_position(m_text->TextActor());
				int boundPos = clutter_text_get_selection_bound(m_text->TextActor());
				if (cursorPos != boundPos)
				{
					clutter_text_set_cursor_position(m_text->TextActor(), boundPos);
				}
			}
		}
		else
		{
			if (!flagSelectable)
			{
				m_boundPositionParaIndex = m_cursorPositionParaIndex;
				m_boundPositionCharIndex = m_cursorPositionCharIndex;
			}
		}
	}

	bool CRichText::IsSelectableEnabled()
	{
		return m_enableSelectable;
	}

	void CRichText::SetSelection(int startPos, int endPos)
	{
		if (!m_enableSelectable)
		{
			return;
		}

		if (!m_enableMultiLine)
		{
			clutter_text_set_selection(CLUTTER_TEXT(m_text->TextActor()), startPos, endPos);
			return;
		}
		else
		{
			int start = startPos < endPos ? startPos : endPos;
			int end = startPos < endPos ? endPos : startPos;
			if (start == end)
			{
				return;
			}
			int indexParaStart = 0;
			int indexParaEnd = 0;
			int indexCharStart = 0;
			int indexCharEnd = 0;
			int lenCount = 0;
			int itemCount = m_singleLine->GetDataSource()->Size();
			for (int i = 0; i < itemCount; i++)
			{
				TextData* data = (TextData*)m_singleLine->GetDataSource()->GetData(i);
				int len = strlen(data->textContent);
				int lenUTF8 = bytes_to_offset(data->textContent, len);
				if (start >= lenCount && start <= (lenUTF8 + lenCount))
				{
					indexParaStart = i;
					indexCharStart = offset_to_byte(data->textContent, start - lenCount);
				}
				if (end >= lenCount && end <= (lenUTF8 + lenCount))
				{
					indexParaEnd = i;
					indexCharEnd = offset_to_byte(data->textContent, end - lenCount);
					break;
				}
				lenCount += lenUTF8;
			}

			m_cursorPositionParaIndex = indexParaStart;
			m_cursorPositionCharIndex = indexCharStart;
			m_boundPositionParaIndex = indexParaEnd;
			m_boundPositionCharIndex = indexCharEnd;
		}
	}

	void CRichText::m_GetSelectionBoundData(int& startPara, int& startChar, int& endPara, int& endChar, int& selectionLen)
	{
		int cursorParaIndex = m_cursorPositionParaIndex;
		int cursorCharIndex = m_cursorPositionCharIndex;
		int boundParaIndex = m_boundPositionParaIndex;
		int boundCharIndex = m_boundPositionCharIndex;

		if (cursorParaIndex < boundParaIndex)
		{
			startPara = cursorParaIndex;
			startChar = cursorCharIndex;
			endPara = boundParaIndex;
			endChar = boundCharIndex;
		}
		else if (cursorParaIndex == boundParaIndex)
		{
			startPara = cursorParaIndex;
			endPara = boundParaIndex;
			startChar = cursorCharIndex <= boundCharIndex ? cursorCharIndex : boundCharIndex;
			endChar = cursorCharIndex <= boundCharIndex ? boundCharIndex : cursorCharIndex;
		}
		else if (cursorParaIndex > boundParaIndex)
		{
			startPara = boundParaIndex;
			startChar = boundCharIndex;
			endPara = cursorParaIndex;
			endChar = cursorCharIndex;
		}

		if (startPara == endPara)
		{
			selectionLen = (endChar - startChar);
		}
		else
		{
			for (int i = startPara; i <= endPara; i++)
			{
				if (i == startPara)
				{
					selectionLen += (strlen(((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent) - startChar);
				}
				else if (i == endPara)
				{
					selectionLen += endChar;
				}
				else
				{
					selectionLen += strlen(((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent);
				}
			}
		}
	}

	char* CRichText::Selection()
	{
		if (!m_enableSelectable)
		{
			return NULL;
		}

		delete [] m_selectionTextBuf;
		m_selectionTextBuf = NULL;

		if (!m_enableMultiLine)
		{
			int len = strlen(clutter_text_get_selection(CLUTTER_TEXT(m_text->TextActor())));
			if (len == 0)
			{
				len = 1;
				m_selectionTextBuf = new char[len];
				m_selectionTextBuf[0] = '\0';
			}
			else
			{
				m_selectionTextBuf = new char[len + 1];
				strncpy(m_selectionTextBuf, clutter_text_get_selection(CLUTTER_TEXT(m_text->TextActor())), len);
				m_selectionTextBuf[len] = '\0';
			}
		}
		else
		{
			int selectionStartPara = 0;
			int selectionStartChar = 0;
			int selectionEndPara = 0;
			int selectionEndChar = 0;
			int selectionLen = 0;
			m_GetSelectionBoundData(selectionStartPara, selectionStartChar, selectionEndPara, selectionEndChar, selectionLen);

			if (selectionStartPara == selectionEndPara && selectionStartChar == selectionEndChar)
			{
				m_selectionTextBuf = new char[1];
				m_selectionTextBuf[0] = '\0';
				return m_selectionTextBuf;
			}
			
			if (selectionStartPara == selectionEndPara)
			{
				m_selectionTextBuf = new char[selectionLen + 1];
				int index = 0;
				for (int i = selectionStartChar; i < selectionEndChar; i++)
				{
					m_selectionTextBuf[index++] = (((TextData*)m_singleLine->GetDataSource()->GetData(selectionStartPara))->textContent)[i];
				}
				m_selectionTextBuf[selectionLen] = '\0';
			}
			else
			{
				// now multi line insert interface has not use, so selection combine as one para
				m_selectionTextBuf = new char[selectionLen + 1 + selectionEndPara - selectionStartPara];
				int index = 0;
				for (int i = selectionStartPara; i <= selectionEndPara; i++)
				{
					int len = strlen(((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent);
					if (i == selectionStartPara)
					{
						for (int t = 0; t < (len - selectionStartChar); t++)
						{
							m_selectionTextBuf[index++] = (((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent)[selectionStartChar + t];
						}
						m_selectionTextBuf[index++] = '\n';
					}
					else if (i == selectionEndPara)
					{
						for (int t = 0; t < selectionEndChar; t++)
						{
							m_selectionTextBuf[index++] = (((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent)[t];
						}
					}
					else
					{
						for (int t = 0; t < len; t++)
						{
							m_selectionTextBuf[index++] = (((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent)[t];
						}
						m_selectionTextBuf[index++] = '\n';
					}
				}
				m_selectionTextBuf[selectionLen + selectionEndPara - selectionStartPara] = '\0';
			}
		}
		return m_selectionTextBuf;
	}

	void CRichText::SetSelectionColor(const ClutterColor color)
	{
		//m_selectionColor.alpha = color.alpha;
		if (!m_enableMultiLine)
		{
			m_selectionColor.alpha = 255;
		}
		else
		{
			m_selectionColor.alpha = 100;
		}
		m_selectionColor.red = color.red;
		m_selectionColor.green = color.green;
		m_selectionColor.blue = color.blue;
		if (!m_enableMultiLine)
		{
			clutter_text_set_selection_color(CLUTTER_TEXT(m_text->TextActor()), &m_selectionColor);
		}
	}

	gboolean CRichText::m_InvalidateSelection(gpointer data_)
	{
		/* invalidate the contents of the canvas */
		clutter_content_invalidate((ClutterContent*)data_);
		/* keep the timeout source */
		return G_SOURCE_CONTINUE;
	}

	gboolean CRichText::m_PaintCanvas(ClutterCanvas *canvas, cairo_t *cr, int width, int height, gpointer user_data)
	{
		CRichText* pThis = (CRichText*)user_data;
		if (pThis->m_enableHighLight)
		{
			pThis->m_DrawHighLight(canvas, cr);
		}
		else 
		{
			if (pThis->m_enableSelectable)
			{
				if (pThis->m_enableMultiLine)
				{
					pThis->m_DrawSelection(canvas, cr);
				}
			}
		}
		return TRUE;
	}

	gboolean CRichText::m_DrawHighLight(ClutterCanvas *canvas, cairo_t *cr)
	{
		PangoRectangle rect_pos = { 0 };
		PangoRectangle rect_start = { 0 };
		PangoRectangle rect_move = { 0 };
		PangoRectangle rect_ink = { 0 };
		PangoRectangle rect_logic = { 0 };
		int lineHeight = 0;
		bool bNeedToDrawFlag = false;
		TRect rect = m_singleLine->VisibleAreaRect();
		int yOffset = (int)-rect.y;

		cairo_save(cr);
		cairo_set_operator(cr, CAIRO_OPERATOR_CLEAR);
		cairo_paint(cr);
		cairo_restore(cr);
		int yPos = 0;
		int indexHL = 0;
		std::list<CTHighlightData>::iterator iterHL = m_highlightData.begin();
		for (; iterHL != m_highlightData.end(); ++iterHL)
		{
			if (indexHL == m_highlightMoveIndex)
			{
				yPos = 0;
				int paraCountPre = ((TextData*)m_singleLine->GetDataSource()->GetData((*iterHL).indexPara))->index;
				for (int i = 0; i < paraCountPre; i++)
				{
					yPos += (int)((TextData*)m_singleLine->GetDataSource()->GetData(i))->height;
				}

				if( m_singleLine->Renderer((*iterHL).indexPara) == NULL )
				{
					break;
				}
				CText* ctext = ((TextRenderer*)m_singleLine->Renderer((*iterHL).indexPara))->GetText();
				if (ctext != NULL)
				{
					int lineIndexStart = 0;
					int lineIndexEnd = 0;
					int lineCount = pango_layout_get_line_count(clutter_text_get_layout(ctext->TextActor()));
					for (int i = 0; i < lineCount; i++)
					{
						PangoLayoutLine *line = pango_layout_get_line(clutter_text_get_layout(ctext->TextActor()), i);
						pango_layout_line_get_extents(line, &rect_ink, &rect_logic);
						if (i == (lineCount - 1))
						{
							if ((*iterHL).indexCharStart >= line->start_index && (*iterHL).indexCharStart <= (line->start_index + line->length))
							{
								break;
							}
						}
						else
						{
							if ((*iterHL).indexCharStart >= line->start_index && (*iterHL).indexCharStart < (line->start_index + line->length))
							{
								break;
							}
						}

						yPos += rect_logic.height / PANGO_SCALE;
					}
					for (int i = 0; i < lineCount; i++)
					{
						PangoLayoutLine *line = pango_layout_get_line(clutter_text_get_layout(ctext->TextActor()), i);
						if (i == (lineCount - 1))
						{
							if ((*iterHL).indexCharStart >= line->start_index && (*iterHL).indexCharStart <= (line->start_index + line->length))
							{
								lineIndexStart = i;
							}
							if ((*iterHL).indexCharEnd >= line->start_index && (*iterHL).indexCharEnd <= (line->start_index + line->length))
							{
								lineIndexEnd = i;
							}
						}
						else
						{
							if ((*iterHL).indexCharStart >= line->start_index && (*iterHL).indexCharStart < (line->start_index + line->length))
							{
								lineIndexStart = i;
							}
							if ((*iterHL).indexCharEnd >= line->start_index && (*iterHL).indexCharEnd < (line->start_index + line->length))
							{
								lineIndexEnd = i;
							}
						}

					}
					for (int i = 0; i < lineCount; i++)
					{
						PangoLayoutLine *line = pango_layout_get_line(clutter_text_get_layout(ctext->TextActor()), i);
						pango_layout_line_get_extents(line, &rect_ink, &rect_logic);
						pango_layout_index_to_pos(clutter_text_get_layout(ctext->TextActor()), line->start_index, &rect_pos);
						if (i == lineIndexStart)
						{
							pango_layout_index_to_pos(clutter_text_get_layout(ctext->TextActor()), (*iterHL).indexCharStart, &rect_start);
							if (i == lineIndexEnd)
							{
								pango_layout_index_to_pos(clutter_text_get_layout(ctext->TextActor()), (*iterHL).indexCharEnd, &rect_move);
								cairo_new_sub_path(cr);
								cairo_rectangle(cr, rect_start.x / PANGO_SCALE, yOffset + yPos, (rect_move.x - rect_start.x) / PANGO_SCALE, rect_logic.height / PANGO_SCALE);
								cairo_close_path(cr);
								cairo_set_source_rgba(cr, (double)m_highlightColor.red / 255, (double)m_highlightColor.green / 255, (double)m_highlightColor.blue / 255, (double)m_highlightColor.alpha / 255);
								cairo_fill(cr);
								return TRUE;
							}
							else if (i != lineIndexEnd)
							{
								cairo_new_sub_path(cr);
								cairo_rectangle(cr, rect_start.x / PANGO_SCALE, yOffset + yPos, (rect_logic.width - rect_start.x + rect_pos.x) / PANGO_SCALE, rect_logic.height / PANGO_SCALE);
								cairo_close_path(cr);
								cairo_set_source_rgba(cr, (double)m_highlightColor.red / 255, (double)m_highlightColor.green / 255, (double)m_highlightColor.blue / 255, (double)m_highlightColor.alpha / 255);
								cairo_fill(cr);
								lineHeight += rect_logic.height / PANGO_SCALE;
								bNeedToDrawFlag = true;
							}
						}
						else if (i > lineIndexStart)
						{
							if (bNeedToDrawFlag && i <= lineIndexEnd)
							{
								if (i < lineIndexEnd)
								{
									cairo_new_sub_path(cr);
									cairo_rectangle(cr, rect_pos.x / PANGO_SCALE, yOffset + lineHeight + yPos, (rect_logic.width) / PANGO_SCALE, rect_logic.height / PANGO_SCALE);
									cairo_close_path(cr);
									cairo_set_source_rgba(cr, (double)m_highlightColor.red / 255, (double)m_highlightColor.green / 255, (double)m_highlightColor.blue / 255, (double)m_highlightColor.alpha / 255);
									cairo_fill(cr);
									lineHeight += rect_logic.height / PANGO_SCALE;
								}
								else if (i == lineIndexEnd)
								{
									pango_layout_index_to_pos(clutter_text_get_layout(ctext->TextActor()), (*iterHL).indexCharEnd, &rect_move);
									cairo_new_sub_path(cr);
									cairo_rectangle(cr, rect_pos.x / PANGO_SCALE, yOffset + lineHeight + yPos, (rect_move.x - rect_pos.x) / PANGO_SCALE, rect_logic.height / PANGO_SCALE);
									cairo_close_path(cr);
									cairo_set_source_rgba(cr, (double)m_highlightColor.red / 255, (double)m_highlightColor.green / 255, (double)m_highlightColor.blue / 255, (double)m_highlightColor.alpha / 255);
									cairo_fill(cr);
									return TRUE;
								}
							}
						}
					}
				}
				return TRUE;
			}
			indexHL++;
		}
		return TRUE;
	}

	gboolean CRichText::m_DrawSelection(ClutterCanvas *canvas, cairo_t *cr)
	{
		if (m_cursorPositionParaIndex < 0 || m_cursorPositionCharIndex < 0 || m_boundPositionParaIndex < 0 || m_boundPositionCharIndex < 0)
		{
			return TRUE;
		}
		if (m_cursorPositionParaIndex == m_boundPositionParaIndex && m_cursorPositionCharIndex == m_boundPositionCharIndex)
		{
			return TRUE;
		}

		cairo_save(cr);
		cairo_set_operator(cr, CAIRO_OPERATOR_CLEAR);
		cairo_paint(cr);
		cairo_restore(cr);

		int startParaIndex = m_cursorPositionParaIndex;
		int moveParaIndex = m_boundPositionParaIndex;
		int startCharIndex = m_cursorPositionCharIndex;
		int moveCharIndex = m_boundPositionCharIndex;
		//make sure the startParaIndex <= moveParaIndex
		if (startParaIndex > moveParaIndex)
		{
			startParaIndex = m_boundPositionParaIndex;
			startCharIndex = m_boundPositionCharIndex;

			moveParaIndex = m_cursorPositionParaIndex;
			moveCharIndex = m_cursorPositionCharIndex;
		}
		else if (startParaIndex == moveParaIndex)
		{
			if (startCharIndex > moveCharIndex)
			{
				startCharIndex = m_cursorPositionCharIndex > m_boundPositionCharIndex ? m_boundPositionCharIndex : m_cursorPositionCharIndex;
				moveCharIndex = m_cursorPositionCharIndex > m_boundPositionCharIndex ? m_cursorPositionCharIndex : m_boundPositionCharIndex;
			}
		}

		PangoRectangle rect_lineStart = { 0 };
		PangoRectangle rect_lineEnd = { 0 };
		float startPara_y = 0;
		float offsetPara = 0;
		for (int i = 0; i < startParaIndex; i++)
		{
			startPara_y += ((TextData*)m_singleLine->GetDataSource()->GetData(i))->height;
		}
		TRect rect = m_singleLine->VisibleAreaRect();
		startPara_y += -rect.y;
		cairo_new_sub_path(cr);
		if (startParaIndex == moveParaIndex)
		{//selection in the same para
			if( m_singleLine->Renderer(startParaIndex) == NULL )
			{
				return true;
			}
			CText* ctext = ((TextRenderer*)m_singleLine->Renderer(startParaIndex))->GetText();
			if (ctext != NULL)
			{
				PangoLayout* layout = clutter_text_get_layout(ctext->TextActor());
				int lineCount = pango_layout_get_line_count(layout);
				int lineIndexStart = 0;
				int lineIndexEnd = 0;
				if (lineCount == 1)
				{
					lineIndexStart = 0;
					lineIndexEnd = 0;
				}
				else if (lineCount > 1)
				{
					for (int i = 0; i < lineCount; i++)
					{
						PangoLayoutLine* line = pango_layout_get_line(layout, i);
						int index_Start = line->start_index;
						int index_End = 0;
						if (i < (lineCount - 1))
						{
							index_End = (line->start_index + line->length);
						}
						else if (i == (lineCount - 1))
						{
							index_End = (line->start_index + line->length + 1);
						}

						if (startCharIndex >= index_Start && startCharIndex < index_End)
						{
							lineIndexStart = i;
						}
						if (moveCharIndex >= index_Start && moveCharIndex < index_End)
						{
							lineIndexEnd = i;
						}
					}
				}

				for (int lineIndex = lineIndexStart; lineIndex <= lineIndexEnd; lineIndex++)
				{
					PangoLayoutLine *line;
					gint n_ranges;
					gint *ranges;
					gint maxindex;
					ClutterActorBox box;
					gfloat y;

					line = pango_layout_get_line_readonly(layout, lineIndex);
					pango_layout_line_get_x_ranges(line, startCharIndex, moveCharIndex, &ranges, &n_ranges);
					PangoRectangle rect_line = { 0 };
					pango_layout_index_to_pos(layout, line->start_index, &rect_line);
					box.y1 = rect_line.y / PANGO_SCALE;
					box.y2 = box.y1 + rect_line.height / PANGO_SCALE;
					double thick_offset = rect_line.height / PANGO_SCALE / 10.0 * m_borderThick;
					for (int i = 0; i < n_ranges; i++)
							{
						gfloat range_x;
						gfloat range_width;

						range_x = ranges[i * 2] / PANGO_SCALE;
						range_width = ((gfloat)ranges[i * 2 + 1] - (gfloat)ranges[i * 2]) / PANGO_SCALE;
						box.x1 = range_x;
						box.x2 = ceilf(range_x + range_width + .5f);
						cairo_rectangle(cr, box.x1, box.y1 + startPara_y + thick_offset / 2.0, box.x2 - box.x1, box.y2 - box.y1 - thick_offset);
					}
				}
			}
		}
		else
		{//selection some para
			//start para
			if( m_singleLine->Renderer(startParaIndex) != NULL )
			{
				CText* ctext = ((TextRenderer*)m_singleLine->Renderer(startParaIndex))->GetText();
				if (ctext != NULL)
				{
					PangoLayout* layoutStart = clutter_text_get_layout(ctext->TextActor());
					int lineCount = pango_layout_get_line_count(layoutStart);
					int lineIndexStart = 0;
					int characterCount = pango_layout_get_character_count(layoutStart);
					int lengthLayout = offset_to_byte(pango_layout_get_text(layoutStart), characterCount);
					for (int i = 0; i < lineCount; i++)
					{
						PangoLayoutLine* line = pango_layout_get_line(layoutStart, i);
						if (i < (lineCount - 1))
						{
							if (startCharIndex >= line->start_index && startCharIndex < (line->start_index + line->length))
							{
								lineIndexStart = i;
								break;
							}
						}
						else
						{
							if (startCharIndex >= line->start_index && startCharIndex <= (line->start_index + line->length))
							{
								lineIndexStart = i;
								break;
							}
						}
					}
					for (int lineIndex = lineIndexStart; lineIndex < lineCount; lineIndex++)
					{
						PangoLayoutLine *line;
						gint n_ranges;
						gint *ranges;
						gint maxindex;
						ClutterActorBox box;
						gfloat y;
						line = pango_layout_get_line_readonly(layoutStart, lineIndex);
						pango_layout_line_get_x_ranges(line, startCharIndex, lengthLayout, &ranges, &n_ranges);
						PangoRectangle rect_line = { 0 };
						pango_layout_index_to_pos(layoutStart, line->start_index, &rect_line);
						box.y1 = rect_line.y / PANGO_SCALE;
						box.y2 = box.y1 + rect_line.height / PANGO_SCALE;
						double thick_offset = rect_line.height / PANGO_SCALE / 10.0 * m_borderThick;
						for (int i = 0; i < n_ranges; i++)
						{
							gfloat range_x;
							gfloat range_width;

							range_x = ranges[i * 2] / PANGO_SCALE;
							range_width = ((gfloat)ranges[i * 2 + 1] - (gfloat)ranges[i * 2]) / PANGO_SCALE;
							box.x1 = range_x;
							box.x2 = ceilf(range_x + range_width + .5f);
							cairo_rectangle(cr, box.x1, box.y1 + startPara_y + thick_offset / 2.0, box.x2 - box.x1, box.y2 - box.y1 - thick_offset);
						}
					}
				}
			}

			offsetPara += ((TextData*)m_singleLine->GetDataSource()->GetData(startParaIndex))->height;

			// middle para
			for (int i = (startParaIndex + 1); i < moveParaIndex; i++)
			{
				if( m_singleLine->Renderer(i) != NULL )
				{
					if (((TextRenderer*)m_singleLine->Renderer(i))->GetText() != NULL)
					{
						PangoLayout* layout = clutter_text_get_layout(((TextRenderer*)m_singleLine->Renderer(i))->GetText()->TextActor());
						int lineCount = pango_layout_get_line_count(layout);
						int characterCount = pango_layout_get_character_count(layout);
						int lengthLayout = offset_to_byte(pango_layout_get_text(layout), characterCount);
						for (int lineIndex = 0; lineIndex < lineCount; lineIndex++)
						{
							PangoLayoutLine *line;
							gint n_ranges;
							gint *ranges;
							gint maxindex;
							ClutterActorBox box;
							gfloat y;
							line = pango_layout_get_line_readonly(layout, lineIndex);
							pango_layout_line_get_x_ranges(line, 0, lengthLayout, &ranges, &n_ranges);
							PangoRectangle rect_line = { 0 };
							pango_layout_index_to_pos(layout, line->start_index, &rect_line);
							box.y1 = rect_line.y / PANGO_SCALE;
							box.y2 = box.y1 + rect_line.height / PANGO_SCALE;
							double thick_offset = rect_line.height / PANGO_SCALE / 10.0 * m_borderThick;
							for (int i = 0; i < n_ranges; i++)
							{
								gfloat range_x;
								gfloat range_width;

								range_x = ranges[i * 2] / PANGO_SCALE;
								range_width = ((gfloat)ranges[i * 2 + 1] - (gfloat)ranges[i * 2]) / PANGO_SCALE;
								box.x1 = range_x;
								box.x2 = ceilf(range_x + range_width + .5f);
								cairo_rectangle(cr, box.x1, box.y1 + startPara_y + offsetPara + thick_offset / 2.0, box.x2 - box.x1, box.y2 - box.y1 - thick_offset);
							}
						}
					}
				}
				offsetPara += ((TextData*)m_singleLine->GetDataSource()->GetData(i))->height;
			}

			// end para
			if( m_singleLine->Renderer(moveParaIndex) != NULL )
			{
				if (((TextRenderer*)m_singleLine->Renderer(moveParaIndex))->GetText() != NULL)
				{
					PangoLayout* layoutEnd = clutter_text_get_layout(((TextRenderer*)m_singleLine->Renderer(moveParaIndex))->GetText()->TextActor());
					int lineCountEnd = pango_layout_get_line_count(layoutEnd);
					int lineIndexEnd = 0;
					for (int i = 0; i < lineCountEnd; i++)
					{
						PangoLayoutLine* line = pango_layout_get_line(layoutEnd, i);
						int index_Start = line->start_index;
						int index_End = 0;
						if (i < (lineCountEnd - 1))
						{
							index_End = (line->start_index + line->length);
						}
						else if (i == (lineCountEnd - 1))
						{
							index_End = (line->start_index + line->length + 1);
						}

						if (moveCharIndex >= index_Start && moveCharIndex < index_End)
						{
							lineIndexEnd = i;
							break;
						}
					}
					for (int lineIndex = 0; lineIndex <= lineIndexEnd; lineIndex++)
					{
						PangoLayoutLine *line;
						gint n_ranges;
						gint *ranges;
						gint maxindex;
						ClutterActorBox box;
						gfloat y;
						line = pango_layout_get_line_readonly(layoutEnd, lineIndex);

						pango_layout_line_get_x_ranges(line, 0, moveCharIndex, &ranges, &n_ranges);
						PangoRectangle rect_line = { 0 };
						pango_layout_index_to_pos(layoutEnd, line->start_index, &rect_line);
						box.y1 = rect_line.y / PANGO_SCALE;
						box.y2 = box.y1 + rect_line.height / PANGO_SCALE;
						double thick_offset = rect_line.height / PANGO_SCALE / 10.0 * m_borderThick;
						for (int i = 0; i < n_ranges; i++)
							{
							gfloat range_x;
							gfloat range_width;

							range_x = ranges[i * 2] / PANGO_SCALE;
							range_width = ((gfloat)ranges[i * 2 + 1] - (gfloat)ranges[i * 2]) / PANGO_SCALE;
							box.x1 = range_x;
							box.x2 = ceilf(range_x + range_width + .5f);
							cairo_rectangle(cr, box.x1, box.y1 + startPara_y + offsetPara + thick_offset / 2.0, box.x2 - box.x1, box.y2 - box.y1 - thick_offset);
						}
						}
					}
				}
			}

		cairo_close_path(cr);
		cairo_set_source_rgba(cr, (double)m_selectionColor.red / 255, (double)m_selectionColor.green / 255, (double)m_selectionColor.blue / 255, (double)m_selectionColor.alpha / 255);
		cairo_fill(cr);
		return TRUE;
	}

	const ClutterColor& CRichText::SelectionColor(void)
	{
		return m_selectionColor;
	}

	void CRichText::SetTextColor(const ClutterColor color)
	{
		m_textColor.alpha = color.alpha;
		m_textColor.red = color.red;
		m_textColor.green = color.green;
		m_textColor.blue = color.blue;
		if (!m_enableMultiLine)
		{
			m_text->SetTextColor(m_textColor);
		}
		else
		{
			int start = -1;
			int end = -1;
			//m_ShowItemRange(start, end);
			m_singleLine->GetWindowItemRange(start, end);
			if (start < 0 || end < 0)
			{
				return;
			}
			for (int i = start; i <= end; i++)
			{
				if( m_singleLine->Renderer(i) != NULL )
				{
					((TextRenderer*)m_singleLine->Renderer(i))->GetText()->SetTextColor(m_textColor);
				}
			}
		}
	}

	const ClutterColor& CRichText::TextColor(void)
	{
		return m_textColor;
	}

	void CRichText::SetBackgroundColor(const ClutterColor color)
	{
		m_backgroundColor.alpha = color.alpha;
		m_backgroundColor.red = color.red;
		m_backgroundColor.green = color.green;
		m_backgroundColor.blue = color.blue;
		if (!m_enableMultiLine)
		{
			m_text->SetBackgroundColor(m_backgroundColor);
		}
		else
		{
			clutter_actor_set_background_color(t_actor, &m_backgroundColor);
			int start = -1;
			int end = -1;
			m_singleLine->GetWindowItemRange(start, end);
			if (start < 0 || end < 0)
			{
				return;
			}
			for (int i = start; i <= end; i++)
			{
				if( m_singleLine->Renderer(i) != NULL )
				{
					CText* ctext = ((TextRenderer*)m_singleLine->Renderer(i))->GetText();
					if(ctext != NULL)
					{
						ctext->SetBackgroundColor(m_backgroundColor);
					}
				}
			}
		}
	}

	const ClutterColor& CRichText::BackgroundColor(void)
	{
		return m_backgroundColor;
	}

	void CRichText::SetCursorColor(const ClutterColor color)
	{
		m_cursorColor.alpha = color.alpha;
		m_cursorColor.red = color.red;
		m_cursorColor.green = color.green;
		m_cursorColor.blue = color.blue;

		m_cursorColorAlpha = color.alpha;

		if (!m_enableMultiLine)
		{
			clutter_text_set_cursor_color(m_text->TextActor(), &m_cursorColor);
		}
		else
		{
			int start = -1;
			int end = -1;
			m_singleLine->GetWindowItemRange(start, end);
			if (start < 0 || end < 0)
			{
				return;
			}
			for (int i = start; i <= end; i++)
			{
				if( m_singleLine->Renderer(i) != NULL )
				{
					CText* ctext = ((TextRenderer*)m_singleLine->Renderer(i))->GetText();
					if (ctext != NULL)
					{
						clutter_text_set_cursor_color(ctext->TextActor(), &m_cursorColor);
					}
				}
			}
		}
	}

	const ClutterColor& CRichText::CursorColor()
	{
		return m_cursorColor;
	}

	void CRichText::SetCursorPosition(int charIndex)
	{
		if (!m_enableMultiLine)
		{
			clutter_text_set_cursor_position(m_text->TextActor(), charIndex);
			clutter_text_set_selection_bound(m_text->TextActor(), charIndex);
		}
		else
		{
			int indexCursorPara = 0;
			int indexCursorChar = 0;
			int lenCount = 0;
			int cursorPos = 0;
			int itemCount = m_singleLine->GetDataSource()->Size();
			for (int i = 0; i < itemCount; i++)
			{
				TextData* data = (TextData*)m_singleLine->GetDataSource()->GetData(i);
				int len = strlen(data->textContent);
				int lenUTF8 = bytes_to_offset(data->textContent, len);

				if (charIndex >= lenCount && charIndex < (lenUTF8 + lenCount))
				{
					indexCursorPara = i;
					cursorPos = charIndex - lenCount;
					indexCursorChar = offset_to_byte(data->textContent, cursorPos);
					break;
				}
				lenCount += lenUTF8;
			}

			m_cursorPositionParaIndex = indexCursorPara;
			m_cursorPositionCharIndex = indexCursorChar;
			m_boundPositionParaIndex = indexCursorPara;
			m_boundPositionCharIndex = indexCursorChar;
			if( m_singleLine->Renderer(m_cursorPositionParaIndex) != NULL )
			{
				CText* ctext = ((TextRenderer*)m_singleLine->Renderer(m_cursorPositionParaIndex))->GetText();
				if (ctext != NULL)
				{
					m_SetParagraphFocus(ctext->TextActor(), cursorPos, cursorPos);
				}
				else
				{
					m_MoveCurrentParaToShow(m_cursorPositionParaIndex, m_cursorPositionCharIndex);
					if( m_singleLine->Renderer(m_cursorPositionParaIndex) != NULL )
					{
						ctext = ((TextRenderer*)m_singleLine->Renderer(m_cursorPositionParaIndex))->GetText();
						if (ctext != NULL)
						{
							m_SetParagraphFocus(ctext->TextActor(), cursorPos, cursorPos);
						}
					}
				}
			}
		}
	}

	int CRichText::CursorPosition()
	{
		if (!m_enableMultiLine)
		{
			int bound = clutter_text_get_selection_bound(m_text->TextActor());
			int cursor = clutter_text_get_cursor_position(m_text->TextActor());
			int len = g_utf8_strlen(clutter_text_get_text(m_text->TextActor()), -1);
			if (len > 0)
			{
				if (bound == -1)
				{
					bound = len;
				}
				if (cursor == -1)
				{
					cursor = len;
				}
			}
			return cursor < bound ? cursor : bound;		
			//return clutter_text_get_cursor_position(m_text->TextActor());
		}
		else
		{
			int selectionStartPara = 0;
			int selectionStartChar = 0;
			int selectionEndPara = 0;
			int selectionEndChar = 0;
			int selectionLen = 0;
			m_GetSelectionBoundData(selectionStartPara, selectionStartChar, selectionEndPara, selectionEndChar, selectionLen);
			
			int count = 0;
			for (int i = 0; i < selectionStartPara; i++)
			{
				int len = g_utf8_strlen(((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent, -1);
				count += len;
			}

			TextData* data = (TextData*)m_singleLine->GetDataSource()->GetData(selectionStartPara);
			int selectionStartCharUTF8 = bytes_to_offset(data->textContent, selectionStartChar);
			return count + selectionStartCharUTF8;
		}
	}

	void CRichText::SetCursorWidth(int width)
	{
		if (m_cursorWidth == width || width <= 0)
		{
			return;
		}
		m_cursorWidth = width;
		if (!m_enableMultiLine)
		{
			clutter_text_set_cursor_size(m_text->TextActor(), (gint)width);
		}
		else
		{
			int start = -1;
			int end = -1;
			//m_ShowItemRange(start, end);
			m_singleLine->GetWindowItemRange(start, end);
			if (start < 0 || end < 0)
			{
				return;
			}
			for (int i = start; i <= end; i++)
			{
				if( m_singleLine->Renderer(i) != NULL )
				{
					CText* ctext = ((TextRenderer*)m_singleLine->Renderer(i))->GetText();
					if (ctext != NULL)
					{
						clutter_text_set_cursor_size(ctext->TextActor(), (gint)width);
					}
				}
			}
		}
	}

	int CRichText::CursorWidth(void)
	{
		return m_cursorWidth;
	}

	void CRichText::m_CursorChangedEvent(ClutterText *actor, gpointer user_data)
	{

	}

	void CRichText::MoveCursor(EDirection dir)
	{
		if (!m_enableEditable || !m_enableSelectable || m_moveCursorBusyFlag || !m_enableMultiLine)
		{
			return;
		}
		m_moveCursorBusyFlag = true;
		int index_Char = m_cursorPositionCharIndex;
		int index_Para = m_cursorPositionParaIndex;
		int paraCount = m_singleLine->GetDataSource()->Size();
		TextData* currentData = (TextData*)m_singleLine->GetDataSource()->GetData(index_Para);
		int paraLen = strlen(currentData->textContent);
		float cur_x, cur_y, cur_h;
		float nex_x, nex_y, nex_h;
		float cacheDis = 0;
		int tmpIndex = 0;
		int newCharIndex = 0;
		int cursorLineIndex = 0;
		int lineCount = 0;
		int currentCursorY = 0;
		PangoRectangle rect_newCursor = { 0 };

		int paraCountHeight = 0;
		for (int i = 0; i < index_Para; i++)
		{
			paraCountHeight += (int)((TextData*)m_singleLine->GetDataSource()->GetData(i))->height;
		}
		TRect rect_area = m_singleLine->VisibleAreaRect();
		float par_w, par_h;
		this->GetSize(par_w, par_h);
		CText* ctextCur = NULL;

#ifdef HAVE_ECORE_IMF
		if (m_imf_context && m_imf_context->imf_context != NULL)
		{
			ecore_imf_context_reset(m_imf_context->imf_context);
		}
#endif

		switch (dir)
		{
		case DIRECTION_UP:
			if( m_singleLine->Renderer(index_Para) == NULL )
			{
				return;
			}
			ctextCur = ((TextRenderer*)m_singleLine->Renderer(index_Para))->GetText();
			if (ctextCur == NULL)
			{
				return;
			}
			lineCount = pango_layout_get_line_count(clutter_text_get_layout(ctextCur->TextActor()));
			for (int i = 0; i < lineCount; i++)
			{
				PangoLayoutLine *line = pango_layout_get_line(clutter_text_get_layout(ctextCur->TextActor()), i);
				if (i == (lineCount - 1))
				{
					if (index_Char >= line->start_index && index_Char <= (line->start_index + line->length))
					{
						cursorLineIndex = i;
						break;
					}
				}
				else
				{
					if (index_Char >= line->start_index && index_Char < (line->start_index + line->length))
					{
						cursorLineIndex = i;
						break;
					}
				}
			}
			if (index_Para == 0 && cursorLineIndex == 0)
			{
				m_moveCursorBusyFlag = false;
				return;
			}

			tmpIndex = bytes_to_offset(currentData->textContent, index_Char);
			clutter_text_position_to_coords(ctextCur->TextActor(), tmpIndex, &cur_x, &cur_y, &cur_h);
			if (cursorLineIndex == 0)
			{
				//next line scroll animation
				pango_layout_index_to_pos(clutter_text_get_layout(ctextCur->TextActor()), index_Char, &rect_newCursor);
				currentCursorY = paraCountHeight + rect_newCursor.y / PANGO_SCALE - (int)rect_area.y;
				if (currentCursorY < 0 && (currentCursorY + rect_newCursor.height / PANGO_SCALE) >= 0)
				{//part of the current cursor is hide
					int offset = currentCursorY - rect_newCursor.height / PANGO_SCALE;
					m_singleLine->ScrollVisibleArea(0, (float)offset, false);
				}
				else if ((currentCursorY - rect_newCursor.height / PANGO_SCALE) < 0 && currentCursorY >= 0)
				{//part of the next line cursor is hide
					int offset = currentCursorY - rect_newCursor.height / PANGO_SCALE;
					m_singleLine->ScrollVisibleArea(0, (float)offset, false);
				}
				//animation end

				//go to up para last line
				index_Para -= 1;
				if( m_singleLine->Renderer(index_Para) == NULL )
				{
					return;
				}
				CText* ctextUp = ((TextRenderer*)m_singleLine->Renderer(index_Para))->GetText();
				//get the last line y to calculate index
				PangoRectangle rect_ink = { 0 };
				PangoRectangle rect_logic = { 0 };

				pango_layout_get_extents(clutter_text_get_layout(ctextUp->TextActor()), &rect_ink, &rect_logic);
				//rect_logic.height is the pre para height
				int tmp = clutter_text_coords_to_position(ctextUp->TextActor(), cur_x, rect_logic.height / PANGO_SCALE);
				TextData* preData = (TextData*)m_singleLine->GetDataSource()->GetData(index_Para);
				int indexUTF8 = bytes_to_offset(preData->textContent, tmp);
				m_SetParagraphFocus(ctextUp->TextActor(), indexUTF8, indexUTF8);
				newCharIndex = offset_to_byte(preData->textContent, indexUTF8);
				m_cursorPositionCharIndex = newCharIndex;
				m_cursorPositionParaIndex = index_Para;
				m_boundPositionCharIndex = m_cursorPositionCharIndex;
				m_boundPositionParaIndex = m_cursorPositionParaIndex;
				break;
			}
			else if (cursorLineIndex > 0)
			{
				//next line scroll animation
				pango_layout_index_to_pos(clutter_text_get_layout(ctextCur->TextActor()), index_Char, &rect_newCursor);
				currentCursorY = paraCountHeight + rect_newCursor.y / PANGO_SCALE - (int)rect_area.y;
				if (currentCursorY < 0 && (currentCursorY + rect_newCursor.height / PANGO_SCALE) >= 0)
				{//part of the current cursor is hide
					int offset = currentCursorY - rect_newCursor.height / PANGO_SCALE;
					m_singleLine->ScrollVisibleArea(0, (float)offset, false);
				}
				else if ((currentCursorY - rect_newCursor.height / PANGO_SCALE) < 0 && currentCursorY >= 0)
				{//part of the next line cursor is hide
					int offset = currentCursorY - rect_newCursor.height / PANGO_SCALE;
					m_singleLine->ScrollVisibleArea(0, (float)offset, false);
				}
				//animation end

				//go to cur para pre line
				PangoLayoutLine *line = pango_layout_get_line(clutter_text_get_layout(ctextCur->TextActor()), cursorLineIndex - 1);
				PangoRectangle rect_ink = { 0 };
				PangoRectangle rect_logic = { 0 };
				pango_layout_line_get_extents(line, &rect_ink, &rect_logic);

				int tmp = clutter_text_coords_to_position(ctextCur->TextActor(), cur_x, cur_y - rect_logic.height / PANGO_SCALE);
				int indexUTF8 = bytes_to_offset(currentData->textContent, tmp);
				clutter_text_set_cursor_position(ctextCur->TextActor(), indexUTF8);
				clutter_text_set_selection_bound(ctextCur->TextActor(), indexUTF8);

				newCharIndex = offset_to_byte(currentData->textContent, indexUTF8);
				m_cursorPositionCharIndex = newCharIndex;
				m_boundPositionCharIndex = m_cursorPositionCharIndex;
				m_boundPositionParaIndex = m_cursorPositionParaIndex;
				break;
			}
		case DIRECTION_DOWN:
			if( m_singleLine->Renderer(index_Para) == NULL )
			{
				return;
			}
			ctextCur = ((TextRenderer*)m_singleLine->Renderer(index_Para))->GetText();
			if (ctextCur == NULL)
			{
				return;
			}
			lineCount = pango_layout_get_line_count(clutter_text_get_layout(ctextCur->TextActor()));
			for (int i = 0; i < lineCount; i++)
			{
				PangoLayoutLine *line = pango_layout_get_line(clutter_text_get_layout(ctextCur->TextActor()), i);

				if (i == (lineCount - 1))
				{//just one line, or the last line
					if (index_Char >= line->start_index && index_Char <= (line->start_index + line->length))
					{
						cursorLineIndex = i;
						break;
					}
				}
				else
				{
					if (index_Char >= line->start_index && index_Char < (line->start_index + line->length))
					{
						cursorLineIndex = i;
						break;
					}
				}
			}

			if (index_Para == (paraCount - 1) && cursorLineIndex == (lineCount - 1))
			{
				m_moveCursorBusyFlag = false;
				return;
			}

			tmpIndex = bytes_to_offset(currentData->textContent, index_Char);
			clutter_text_position_to_coords(ctextCur->TextActor(), tmpIndex, &cur_x, &cur_y, &cur_h);

			if (cursorLineIndex < (lineCount - 1))
			{
				//next line scroll animation
				PangoLayoutLine *currentLine = pango_layout_get_line(clutter_text_get_layout(ctextCur->TextActor()), cursorLineIndex);
				pango_layout_index_to_pos(clutter_text_get_layout(ctextCur->TextActor()), currentLine->start_index, &rect_newCursor);
				currentCursorY = paraCountHeight - (int)rect_area.y + rect_newCursor.y / PANGO_SCALE;
				if (currentCursorY <= (int)rect_area.h && (currentCursorY + rect_newCursor.height / PANGO_SCALE) >(int)rect_area.h)
				{//part of the current cursor is hide
					int offset = currentCursorY + rect_newCursor.height / PANGO_SCALE * 2 - (int)rect_area.h;
					m_singleLine->ScrollVisibleArea(0, (float)offset, false);
				}
				else if ((currentCursorY + rect_newCursor.height / PANGO_SCALE) <= (int)rect_area.h && (currentCursorY + rect_newCursor.height / PANGO_SCALE * 2) > (int)rect_area.h)
				{//part of the next line cursor is hide
					int offset = currentCursorY + rect_newCursor.height / PANGO_SCALE * 2 - (int)rect_area.h;
					m_singleLine->ScrollVisibleArea(0, (float)offset, false);
				}
				//animation end

				int tmp = clutter_text_coords_to_position(ctextCur->TextActor(), cur_x, cur_y + cur_h);
				int indexUTF8 = bytes_to_offset(currentData->textContent, tmp);
				clutter_text_set_cursor_position(ctextCur->TextActor(), indexUTF8);
				clutter_text_set_selection_bound(ctextCur->TextActor(), indexUTF8);

				newCharIndex = offset_to_byte(currentData->textContent, indexUTF8);
				m_cursorPositionCharIndex = newCharIndex;
				m_boundPositionCharIndex = m_cursorPositionCharIndex;
				m_boundPositionParaIndex = m_cursorPositionParaIndex;
				
				break;
			}
			else if (cursorLineIndex == (lineCount - 1))
			{
				//next line scroll animation
				PangoLayoutLine *currentLine = pango_layout_get_line(clutter_text_get_layout(ctextCur->TextActor()), cursorLineIndex);
				pango_layout_index_to_pos(clutter_text_get_layout(ctextCur->TextActor()), currentLine->start_index, &rect_newCursor);
				currentCursorY = paraCountHeight - (int)rect_area.y + rect_newCursor.y / PANGO_SCALE;
				if (currentCursorY <= (int)rect_area.h && (currentCursorY + rect_newCursor.height / PANGO_SCALE) >(int)rect_area.h)
				{//part of the current cursor is hide
					int offset = currentCursorY + rect_newCursor.height / PANGO_SCALE * 2 - (int)rect_area.h;
					m_singleLine->ScrollVisibleArea(0, (float)offset, false);
				}
				else if ((currentCursorY + rect_newCursor.height / PANGO_SCALE) <= (int)rect_area.h && (currentCursorY + rect_newCursor.height / PANGO_SCALE * 2) > (int)rect_area.h)
				{//part of the next line cursor is hide
					int offset = currentCursorY + rect_newCursor.height / PANGO_SCALE * 2 - (int)rect_area.h;
					m_singleLine->ScrollVisibleArea(0, (float)offset, false);
				}
				//animation end

				//go to next para first line
				index_Para += 1;
				if( m_singleLine->Renderer(index_Para) == NULL )
				{
					return;
				}
				CText* ctextNext = ((TextRenderer*)m_singleLine->Renderer(index_Para))->GetText();
				int tmp = clutter_text_coords_to_position(ctextNext->TextActor(), cur_x, 0);
				TextData* nextData = (TextData*)m_singleLine->GetDataSource()->GetData(index_Para);
				int indexUTF8 = bytes_to_offset(nextData->textContent, tmp);
				m_SetParagraphFocus(ctextNext->TextActor(), indexUTF8, indexUTF8);
				newCharIndex = offset_to_byte(nextData->textContent, indexUTF8);

				m_cursorPositionCharIndex = newCharIndex;
				m_cursorPositionParaIndex = index_Para;
				m_boundPositionCharIndex = m_cursorPositionCharIndex;
				m_boundPositionParaIndex = m_cursorPositionParaIndex;
				break;
			}

			break;
		case DIRECTION_LEFT:
			if( m_singleLine->Renderer(index_Para) == NULL )
			{
				return;
			}
			ctextCur = ((TextRenderer*)m_singleLine->Renderer(index_Para))->GetText();
			if (ctextCur == NULL)
			{
				return;
			}
			if (index_Para == 0 && index_Char == 0)
			{
				m_moveCursorBusyFlag = false;
				return;
			}
			
			lineCount = pango_layout_get_line_count(clutter_text_get_layout(ctextCur->TextActor()));
			pango_layout_index_to_pos(clutter_text_get_layout(ctextCur->TextActor()), /*currentLine->start_index*/index_Char, &rect_newCursor);
			currentCursorY = paraCountHeight + rect_newCursor.y / PANGO_SCALE - (int)rect_area.y;
			for (int i = 0; i < lineCount; i++)
			{
				PangoLayoutLine *line = pango_layout_get_line(clutter_text_get_layout(ctextCur->TextActor()), i);
				int start = line->start_index;
				int end = 0;
				if (i == (lineCount - 1))
				{
					end = line->start_index + line->length + 1;
				}
				else
				{
					end = line->start_index + line->length;
				}

				if (index_Char > start && index_Char < end)
				{
					if (currentCursorY < 0 && (currentCursorY + rect_newCursor.height / PANGO_SCALE) >= 0)
					{//part of the current cursor is hide
						int offset = currentCursorY - rect_newCursor.height / PANGO_SCALE;
						m_singleLine->ScrollVisibleArea(0, (float)offset, false);
					}
					break;
				}
				else if (index_Char == 0)
				{
					if ((currentCursorY - rect_newCursor.height / PANGO_SCALE) < 0 && currentCursorY >= 0)
					{//part of the next line cursor is hide
						int offset = currentCursorY - rect_newCursor.height / PANGO_SCALE;
						m_singleLine->ScrollVisibleArea(0, (float)offset, false);
					}
					break;
				}
			}
			
			if (index_Char > 0)
			{
				int indexUTF8 = bytes_to_offset(currentData->textContent, index_Char) - 1;
				clutter_text_set_cursor_position(ctextCur->TextActor(), indexUTF8);
				clutter_text_set_selection_bound(ctextCur->TextActor(), indexUTF8);

				int newCursorIndex = offset_to_byte(currentData->textContent, indexUTF8);
				m_cursorPositionCharIndex = newCursorIndex;
				m_boundPositionCharIndex = m_cursorPositionCharIndex;
				m_boundPositionParaIndex = m_cursorPositionParaIndex;
			}
			else if (index_Char == 0)
			{
				index_Para -= 1;
				if( m_singleLine->Renderer(index_Para) == NULL )
				{
					return;
				}
				CText* ctextUp = ((TextRenderer*)m_singleLine->Renderer(index_Para))->GetText();
				TextData* newData = (TextData*)m_singleLine->GetDataSource()->GetData(index_Para);
				index_Char = strlen(newData->textContent);
				int indexUTF8 = bytes_to_offset(newData->textContent, index_Char);

				m_SetParagraphFocus(ctextUp->TextActor(), indexUTF8, indexUTF8);
				m_cursorPositionCharIndex = index_Char;
				m_cursorPositionParaIndex = index_Para;
				m_boundPositionCharIndex = m_cursorPositionCharIndex;
				m_boundPositionParaIndex = m_cursorPositionParaIndex;
			}
			break;
		case DIRECTION_RIGHT:
			if( m_singleLine->Renderer(index_Para) == NULL )
			{
				return;
			}
			ctextCur = ((TextRenderer*)m_singleLine->Renderer(index_Para))->GetText();
			if (ctextCur == NULL)
			{
				return;
			}
			if (index_Para == (paraCount - 1) && index_Char == (paraLen))
			{
				m_moveCursorBusyFlag = false;
				return;
			}
			
			lineCount = pango_layout_get_line_count(clutter_text_get_layout(ctextCur->TextActor()));
			pango_layout_index_to_pos(clutter_text_get_layout(ctextCur->TextActor()), /*currentLine->start_index*/index_Char, &rect_newCursor);
			currentCursorY = paraCountHeight - (int)rect_area.y + rect_newCursor.y / PANGO_SCALE;
			for (int i = 0; i < lineCount; i++)
			{
				PangoLayoutLine *line = pango_layout_get_line(clutter_text_get_layout(ctextCur->TextActor()), i);
				int start = line->start_index;
				int end = 0;
				if (i == (lineCount - 1))
				{
					end = line->start_index + line->length + 1;
				}
				else
				{
					end = line->start_index + line->length;
				}

				if (index_Char >= start && index_Char < (end - 1))
				{
					if (currentCursorY <= (int)rect_area.h && (currentCursorY + rect_newCursor.height / PANGO_SCALE) >(int)rect_area.h)
					{//part of the current cursor is hide
						int offset = currentCursorY + rect_newCursor.height / PANGO_SCALE * 2 - (int)rect_area.h;
						m_singleLine->ScrollVisibleArea(0, (float)offset, false);
					}
					break;
				}
				else if (index_Char == (end - 1))
				{
					if ((currentCursorY + rect_newCursor.height / PANGO_SCALE) <= (int)rect_area.h && (currentCursorY + rect_newCursor.height / PANGO_SCALE * 2) > (int)rect_area.h)
					{//part of the next line cursor is hide
						int offset = currentCursorY + rect_newCursor.height / PANGO_SCALE * 2 - (int)rect_area.h;
						m_singleLine->ScrollVisibleArea(0, (float)offset, false);
					}
					break;
				}
			}
			
			if (index_Char < (paraLen))
			{
				int indexUTF8 = bytes_to_offset(currentData->textContent, index_Char) + 1;
				clutter_text_set_cursor_position(ctextCur->TextActor(), indexUTF8);
				clutter_text_set_selection_bound(ctextCur->TextActor(), indexUTF8);

				int newCursorIndex = offset_to_byte(currentData->textContent, indexUTF8);
				m_cursorPositionCharIndex = newCursorIndex;
				m_boundPositionCharIndex = m_cursorPositionCharIndex;
				m_boundPositionParaIndex = m_cursorPositionParaIndex;
			}
			else if (index_Char == (paraLen))
			{
				index_Para += 1;
				index_Char = 0;
				if( m_singleLine->Renderer(index_Para) == NULL )
				{
					return;
				}
				CText* ctextNext = ((TextRenderer*)m_singleLine->Renderer(index_Para))->GetText();
				m_SetParagraphFocus(ctextNext->TextActor(), index_Char, index_Char);
				m_cursorPositionCharIndex = index_Char;
				m_cursorPositionParaIndex = index_Para;
				m_boundPositionCharIndex = m_cursorPositionCharIndex;
				m_boundPositionParaIndex = m_cursorPositionParaIndex;
			}
			break;
		default:
			break;
		}
		m_moveCursorBusyFlag = false;
	}
	
	void CRichText::Copy(void)
	{
		if (m_enableHighLight || !m_enableSelectable)
		{
			return;
		}
		if (m_copyTextBuf != NULL)
		{
			delete [] m_copyTextBuf;
			m_copyTextBuf = NULL;
		}
		char* buf = Selection();
		int len = strlen(buf);
		m_copyTextBuf = new char[len + 1];
		strncpy(m_copyTextBuf, buf, len);
		m_copyTextBuf[len] = '\0';

		m_GetSelectionPangoAttrList();
	}

	void CRichText::Cut(void)
	{
		if (m_enableHighLight || !m_enableSelectable)
		{
			return;
		}
		Copy();
		DeleteText();
	}

	void CRichText::Paste(void)
	{
		if (m_enableHighLight || !m_enableSelectable)
		{
			return;
		}
		m_copyEventFlag = true;
		InsertText(m_copyTextBuf);
		m_copyEventFlag = false;
	}
	
	int CRichText::m_CursorBlink(gpointer user_data)
	{
		CRichText* pThis = (CRichText*)user_data;
		if (pThis->m_enableHighLight)
		{
			return true;
		}
		if (!pThis->m_enableMultiLine)
		{
			ClutterColor color;
			clutter_text_get_cursor_color(pThis->m_text->TextActor(), &color);
			if (color.alpha == 0)
			{
				color.alpha = pThis->m_cursorColorAlpha;
			}
			else if (color.alpha > 0)
			{
				color.alpha = 0;
			}
			clutter_text_set_cursor_color(pThis->m_text->TextActor(), &color);
		}
		else
		{
			int cursorParaIndex = pThis->m_cursorPositionParaIndex;
			if( pThis->m_singleLine->Renderer(cursorParaIndex) == NULL )
			{
				return TRUE;
			}
			CText* ctext = ((TextRenderer*)pThis->m_singleLine->Renderer(cursorParaIndex))->GetText();
			if (ctext == NULL)
			{
				return true;
			}
			ClutterColor color;
			clutter_text_get_cursor_color(ctext->TextActor(), &color);
			if (color.alpha == 0)
			{
				color.alpha = pThis->m_cursorColorAlpha;
			}
			else if (color.alpha > 0)
			{
				color.alpha = 0;
			}
			clutter_text_set_cursor_color(ctext->TextActor(), &color);
		}
		
		return true;
	}

	void CRichText::SetCursorBlinkInterval(int interval)
	{
		if (m_cursorBlinkTimerID)
		{
			g_source_remove(m_cursorBlinkTimerID);
		}
		m_cursorBlinkTimerID = clutter_threads_add_timeout(interval, m_CursorBlink, this);
	}

	int CRichText::CursorBlinkInterval(void)
	{
		return m_cursorBlinkInterval;
	}

	void CRichText::SetBorderThickness(int thickness)
	{
		if (thickness >= 0 && thickness <= 10)
		{
			m_borderThick = thickness;
		}
	}

	int CRichText::BorderThickness(void)
	{
		return m_borderThick;
	}

	bool CRichText::OpenFile(const char *filePath)
	{
		/*
		FILE *file;
		long size;
		char *buffer;
		size_t result;
		if ((file = fopen(filePath, "rt")) == NULL)
		{
			printf("fail to open file: %s.\n", filePath);
			return false;
		}

		fseek(file, 0, SEEK_END);
		size = ftell(file);
		rewind(file);

		buffer = (char*)malloc(sizeof(char*)* size);
		if (buffer == NULL)
		{
			fputs("Memory error", stderr);
			return false;
		}

		fread(buffer, 1, sizeof(char)* size, file);

		std::list<CTCharFormatObj> charList;
		std::list<CTParagraphFormatObj> paraList;
		std::list<char> textList;
		CRtfParser::ParseRtfFile(filePath, charList, paraList, textList);
		std::list<CTCharFormatObj>::iterator iterc = charList.begin();
		std::list<CTParagraphFormatObj>::iterator iterp = paraList.begin();
		std::list<char>::iterator iterText = textList.begin();

		m_textBufList.clear();
		for (; iterText != textList.end(); ++iterText)
		{
			m_textBufList.push_back((char)*iterText);//
		}
		m_textBufList.push_back('\0');
		//all new need to release when destroy
		fclose(file);
		free(buffer);

		//1 if multiline, move to the initial state
		//2 get the para offset, add or del para
		//3 set per para with its content
		*/
		return true;
	}

	bool CRichText::SaveFile(const char *filePath)
	{
		/*		FILE *file;
		if ((file = fopen(filePath, "wt")) == NULL)
		{
		printf("fail to open file: %s.\n", filePath);
		return false;
		}
		const char *newchar = clutter_text_get_text(CLUTTER_TEXT(t_text));
		printf("newchar = %d_%d_%d_%s \n", '\0', '\n', newchar[10], newchar);
		//		for(int i=0;i<strlen(newchar);i++)
		//		{
		//			printf("%d ", newchar[i]);
		//		}
		//		printf("\nbuf=");

		std::list<char> rtfTextList;
		int offset = 0;
		int len;
		CRtfParser::BuildRtfFile(newchar, offset, m_charList, m_paraList, rtfTextList, len);

		std::list<char>::iterator iterText = rtfTextList.begin();
		char *rtfTextBuf = (char*)malloc((rtfTextList.size() + 1) * sizeof(char*));
		int i = 0;
		for (; iterText != rtfTextList.end(); ++iterText)
		{
		rtfTextBuf[i++] = (char)*iterText;
		}
		rtfTextBuf[i] = '\0';
		printf("\n***list:%s \n", rtfTextBuf);
		fwrite(rtfTextBuf, sizeof(char)*strlen(rtfTextBuf), 1, file);

		fclose(file);*/
		return true;
	}

	/*CRichText::CTCharFormat::CTCharFormat(void)
	{
		font = NULL;
	}

	CRichText::CTCharFormat::~CTCharFormat(void)
	{
		if (font)
		{
			delete[]font;
			font = NULL;
		}
	}

	CRichText::CTCharFormat::CTCharFormat(const CTCharFormat& charFormat)
	{
		font = NULL;
		size = 16;
		fgColor.blue = 255;
		m_Copy(charFormat);
	}

	CRichText::CTCharFormat& CRichText::CTCharFormat::operator=(const CTCharFormat& charFormat)
	{
		if (this == &charFormat)
		{
			return *this;
		}
		m_Copy(charFormat);
		return *this;
	}

	bool CRichText::CTCharFormat::operator==(CTCharFormat& charFormat)
	{
		bool ret = false;

		ret = this->size == charFormat.size;
		ret &= this->style == charFormat.style;
		ret &= this->fgColor.alpha == charFormat.fgColor.alpha;
		ret &= this->fgColor.red == charFormat.fgColor.red;
		ret &= this->fgColor.green == charFormat.fgColor.green;
		ret &= this->fgColor.blue == charFormat.fgColor.blue;

		ret &= this->bgColor.alpha == charFormat.bgColor.alpha;
		ret &= this->bgColor.red == charFormat.bgColor.red;
		ret &= this->bgColor.green == charFormat.bgColor.green;
		ret &= this->bgColor.blue == charFormat.bgColor.blue;
		return ret;
	}

	bool CRichText::CTCharFormat::operator!=(CTCharFormat& charFormat)
	{
		return !(*this == charFormat);
	}

	void CRichText::CTCharFormat::m_Copy(const CTCharFormat& charFormat)
	{
		size = charFormat.size;
		style = charFormat.style;

		if (charFormat.font == NULL)
		{
			this->font = NULL;
			return;
		}

		if (font)
		{
			delete []font;
			font = NULL;
		}

		unsigned int len = strlen(charFormat.font);
		font = new char[len+1];
		strncpy(font, charFormat.font, len);
		font[len] = 0;
	}

	CRichText::CTParagraphFormat::CTParagraphFormat(void)
	{
		lineGap = 0;
		alignment = -1;
	}

	bool CRichText::CTParagraphFormat::operator==(CTParagraphFormat& paraFormat)
	{
		return (this->lineGap == paraFormat.lineGap && this->alignment == paraFormat.alignment);
	}

	bool CRichText::CTParagraphFormat::operator!=(CTParagraphFormat& paraFormat)
	{
		return !(*this == paraFormat);
	}*/
	
	bool CRichText::OnMouseButtonPressed(IWidgetExtension* pThis, IMouseEvent* event)
	{
		if (!m_enableMultiLine)
		{
			if (!clutter_actor_has_key_focus(CLUTTER_ACTOR(m_text->TextActor())))
			{
				clutter_actor_grab_key_focus(CLUTTER_ACTOR(m_text->TextActor()));
			}
		}
		
		return true;
	}

	bool CRichText::OnMouseButtonReleased(IWidgetExtension* pThis, IMouseEvent* event)
	{
		return true;
	}

	bool CRichText::OnMouseMoved(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		return true;
	}

	bool CRichText::OnKeyPressed(IWidgetExtension* pThis, IKeyboardEvent* event)
	{
		return true;
	}

	bool CRichText::OnKeyReleased(IWidgetExtension* pThis, IKeyboardEvent* event)
	{
		return true;
	}

	bool CRichText::OnMousePointerIn(IWidgetExtension* pThis, IMouseEvent* event)
	{
		return true;
	}

	bool CRichText::OnMousePointerOut(IWidgetExtension* pThis, IMouseEvent* event)
	{
		return true;
	}

	bool CRichText::OnMouseWheel(IWidgetExtension* pThis, IMouseEvent* event)
	{
		if (m_enableHighLight)
		{
			return true;
		}
		ClutterScrollDirection direction;

		CMouseEvent* ev = dynamic_cast<CMouseEvent*>(event);
		if (ev != NULL)
		{
			ClutterEvent *pEvent = ev->Transform();
			if (pEvent == NULL)
			{
				return true;
			}
			direction = clutter_event_get_scroll_direction(pEvent);
			int totalHeight = 0;
			int size = m_singleLine->GetDataSource()->Size();
			for (int i = 0; i < size; i++)
			{
				totalHeight += (int)((TextData*)m_singleLine->GetDataSource()->GetData(i))->height;
			}
			TRect rect = m_singleLine->VisibleAreaRect();
			float par_w, par_h;
			this->GetSize(par_w, par_h);

			int offset = totalHeight - (int)rect.y - (int)par_h;

			int yOffset = 0;

			switch (direction)
			{
			case CLUTTER_SCROLL_UP:
					
				if (rect.y >= 10)
				{
					yOffset = -10;
				}
				else if (rect.y < 10 && rect.y > 0)
				{
					yOffset = -(int)rect.y;
				}
					
				break;
			case CLUTTER_SCROLL_DOWN:
				if (offset >= 10)
				{
					yOffset = 10;
				}
				else if (offset < 10 && offset > 0)
				{
					yOffset = offset;
				}
				break;

			default:
				break;
			}
			m_singleLine->ScrollVisibleArea(0.0, (float)yOffset, false);

			int start = -1;
			int end = -1;
			m_singleLine->GetWindowItemRange(start, end);
			if (start < 0 || end < 0)
			{
				return true;
			}
			if (m_cursorPositionParaIndex >= start && m_cursorPositionParaIndex <= end)
			{
				return true;
			}
			for (int i = start; i <= end; i++)
			{// the cursor paragraph is out of window rect
				if (m_singleLine->Renderer(i) != NULL)
				{
					CText* textGrabFocus = ((TextRenderer*)m_singleLine->Renderer(i))->GetText();
					if (textGrabFocus != NULL)
					{
						m_focusChangeFlag = true;
						clutter_actor_grab_key_focus(CLUTTER_ACTOR(textGrabFocus->TextActor()));
						ClutterColor color;
						clutter_text_get_cursor_color(textGrabFocus->TextActor(), &color);
						color.alpha = 0;
						clutter_text_set_cursor_color(textGrabFocus->TextActor(), &color);
						return true;
					}
				}
			}
		}

		return true;
	}

	PangoAttrList* CRichText::m_UpdateCharSelectFormat(PangoAttrList* attrList, int startIndex, int endIndex, PangoAttrType type, bool& res)
	{
		res = false;
		PangoAttrList* tmpList = pango_attr_list_new();

		PangoAttrIterator* iter = pango_attr_list_get_iterator(attrList);
		GSList *attributes, *l;
		do
		{
			attributes = pango_attr_iterator_get_attrs(iter);

			for (l = attributes; l != NULL; l = l->next)
			{
				PangoAttribute *attr = (PangoAttribute*)l->data;

				if (startIndex >= (int)attr->start_index && endIndex <= (int)attr->end_index && attr->klass->type == type)
				{
					if (startIndex == (int)attr->start_index && endIndex == (int)attr->end_index)
					{
						// discard the attribute
					}
					else
					{
						if (startIndex == (int)attr->start_index)
						{// reserve the back part
							attr->start_index = endIndex;
							pango_attr_list_insert(tmpList, attr);
						}
						else if (endIndex == (int)attr->end_index)
						{// reserve the front part
							attr->end_index = startIndex;
							pango_attr_list_insert(tmpList, attr);
						}
						else
						{// split to two part
							int end = (int)attr->end_index;
							attr->end_index = startIndex;
							pango_attr_list_insert(tmpList, attr);

							PangoAttribute* splitAttr = pango_attribute_copy(attr);
							splitAttr->start_index = endIndex;
							splitAttr->end_index = end;
							pango_attr_list_insert(tmpList, splitAttr);
						}
					}
					res = true;
				}
				else if (attr->klass->type == type && (startIndex < (int)attr->start_index && endIndex <= (int)attr->end_index) && endIndex > (int)attr->start_index)
				{// selection startIndex is at the left of the attr_start, and the endIndex is in the attr_range.
					attr->start_index = startIndex;
					pango_attr_list_insert(tmpList, attr);
					res = true;
				}
				else if (attr->klass->type == type && (startIndex >= (int)attr->start_index && endIndex >(int)attr->end_index) && startIndex < (int)attr->end_index)
				{// selection startIndex is in the attr_range, and the endIndex is at the right of the attr_end.
					attr->end_index = endIndex;
					pango_attr_list_insert(tmpList, attr);
					res = true;
				}
				else if (attr->klass->type == type && (startIndex < (int)attr->start_index && endIndex >(int)attr->end_index))
				{// attr range is in the selection range, reset it.
					attr->start_index = startIndex;
					attr->end_index = endIndex;
					pango_attr_list_insert(tmpList, attr);
					res = true;
				}
				else
				{
					pango_attr_list_insert(tmpList, attr);
				}
			}

			g_slist_free(attributes);
		} while (pango_attr_iterator_next(iter));

		return tmpList;
	}

	bool CRichText::SetCharFormat(ITCharFormat &cf)
	{
		if (m_enableHighLight)
		{
			return true;
		}

		int startIndex = 0;
		int endIndex = 0;
		if (!m_enableMultiLine)
		{
			int cursorIndex = clutter_text_get_cursor_position(CLUTTER_TEXT(m_text->TextActor()));
			int boundIndex = clutter_text_get_selection_bound(CLUTTER_TEXT(m_text->TextActor()));
			if (cursorIndex == boundIndex)
			{
				return true;
			}
			int textLen = strlen(clutter_text_get_text(m_text->TextActor()));
			if (cursorIndex == -1 && textLen > 0)
			{
				cursorIndex = textLen;
			}
			if (boundIndex == -1 && textLen > 0)
			{
				boundIndex = textLen;
			}

			startIndex = cursorIndex < boundIndex ? cursorIndex : boundIndex;
			endIndex = cursorIndex < boundIndex ? boundIndex : cursorIndex;

			if ((cf.style & STYLE_BOLD) == STYLE_BOLD)
			{
				bool flag = false;
				PangoAttrList* list = m_UpdateCharSelectFormat(m_textAttrList, startIndex, endIndex, PANGO_ATTR_WEIGHT, flag);
				if (!flag)
				{
					PangoAttribute* attr_Bold = pango_attr_weight_new(PANGO_WEIGHT_BOLD);
					attr_Bold->start_index = startIndex;
					attr_Bold->end_index = endIndex;
					pango_attr_list_insert(list, attr_Bold);
				}
				// update the newest attr list
				if (m_textAttrList != NULL)
				{
					pango_attr_list_unref(m_textAttrList);
					m_textAttrList = NULL;
				}
				m_textAttrList = pango_attr_list_copy(list);
				clutter_text_set_attributes(m_text->TextActor(), m_textAttrList);
			}
			if ((cf.style & STYLE_ITALIC) == STYLE_ITALIC)
			{
				bool flag = false;
				PangoAttrList* list = m_UpdateCharSelectFormat(m_textAttrList, startIndex, endIndex, PANGO_ATTR_STYLE, flag);
				if (!flag)
				{
					PangoAttribute* attr_Italic = pango_attr_style_new(PANGO_STYLE_ITALIC);
					attr_Italic->start_index = startIndex;
					attr_Italic->end_index = endIndex;
					pango_attr_list_insert(list, attr_Italic);
				}
				// update the newest attr list
				if (m_textAttrList != NULL)
				{
					pango_attr_list_unref(m_textAttrList);
					m_textAttrList = NULL;
				}
				m_textAttrList = pango_attr_list_copy(list);
				clutter_text_set_attributes(m_text->TextActor(), m_textAttrList);
			}
			if ((cf.style & STYLE_UNDERLINE) == STYLE_UNDERLINE)
			{
				bool flag = false;
				PangoAttrList* list = m_UpdateCharSelectFormat(m_textAttrList, startIndex, endIndex, PANGO_ATTR_UNDERLINE, flag);
				if (!flag)
				{
					PangoAttribute* attr_Underline = pango_attr_underline_new(PANGO_UNDERLINE_SINGLE);
					attr_Underline->start_index = startIndex;
					attr_Underline->end_index = endIndex;
					pango_attr_list_insert(list, attr_Underline);
				}
				// update the newest attr list
				if (m_textAttrList != NULL)
				{
					pango_attr_list_unref(m_textAttrList);
					m_textAttrList = NULL;
				}
				m_textAttrList = pango_attr_list_copy(list);
				clutter_text_set_attributes(m_text->TextActor(), m_textAttrList);
			}
		}
		else
		{
			int selectionStartPara = 0;
			int selectionStartChar = 0;
			int selectionEndPara = 0;
			int selectionEndChar = 0;
			int selectionLen = 0;
			m_GetSelectionBoundData(selectionStartPara, selectionStartChar, selectionEndPara, selectionEndChar, selectionLen);

			int preStartParaLen = 0;
			//selectionStartPara
			for (int i = 0; i < selectionStartPara; i++)
			{
				preStartParaLen += strlen(((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent) + 1;
			}
			startIndex = preStartParaLen + selectionStartChar;

			//selectionEndPara
			int preEndParaLen = 0;
			for (int i = 0; i < selectionEndPara; i++)
			{
				preEndParaLen += strlen(((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent) + 1;
			}
			endIndex = preEndParaLen + selectionEndChar;

			if (selectionStartPara == selectionEndPara)
			{
				if(m_singleLine->Renderer(selectionStartPara) != NULL)
				{
					CText* ctext = ((TextRenderer*)m_singleLine->Renderer(selectionStartPara))->GetText();
					if (ctext != NULL)
					{
						TextData* data = (TextData*)m_singleLine->GetDataSource()->GetData(selectionStartPara);
						if ((cf.style & STYLE_BOLD) == STYLE_BOLD)
						{
							bool flag = false;
							PangoAttrList* list = m_UpdateCharSelectFormat(data->attrList, selectionStartChar, selectionEndChar, PANGO_ATTR_WEIGHT, flag);
							if (!flag)
							{
								PangoAttribute* attr_Bold = pango_attr_weight_new(PANGO_WEIGHT_BOLD);
								attr_Bold->start_index = selectionStartChar;
								attr_Bold->end_index = selectionEndChar;
								pango_attr_list_insert(list, attr_Bold);
							}
							// update newest attribute list
							if (data->attrList != NULL)
							{
								pango_attr_list_unref(data->attrList);
								data->attrList = NULL;
							}
							data->attrList = pango_attr_list_copy(list);
							clutter_text_set_attributes(ctext->TextActor(), data->attrList);
						}
						if ((cf.style & STYLE_ITALIC) == STYLE_ITALIC)
						{
							bool flag = false;
							PangoAttrList* list = m_UpdateCharSelectFormat(data->attrList, selectionStartChar, selectionEndChar, PANGO_ATTR_STYLE, flag);
							if (!flag)
							{
								PangoAttribute* attr_Italic = pango_attr_style_new(PANGO_STYLE_ITALIC);
								attr_Italic->start_index = selectionStartChar;
								attr_Italic->end_index = selectionEndChar;
								pango_attr_list_insert(list, attr_Italic);
							}
							// update newest attribute list
							if (data->attrList != NULL)
							{
								pango_attr_list_unref(data->attrList);
								data->attrList = NULL;
							}
							data->attrList = pango_attr_list_copy(list);
							clutter_text_set_attributes(ctext->TextActor(), data->attrList);
						}
						if ((cf.style & STYLE_UNDERLINE) == STYLE_UNDERLINE)
						{
							bool flag = false;
							PangoAttrList* list = m_UpdateCharSelectFormat(data->attrList, selectionStartChar, selectionEndChar, PANGO_ATTR_UNDERLINE, flag);
							if (!flag)
							{
								PangoAttribute* attr_Underline = pango_attr_underline_new(PANGO_UNDERLINE_SINGLE);
								attr_Underline->start_index = selectionStartChar;
								attr_Underline->end_index = selectionEndChar;
								pango_attr_list_insert(list, attr_Underline);
							}
							// update newest attribute list
							if (data->attrList != NULL)
							{
								pango_attr_list_unref(data->attrList);
								data->attrList = NULL;
							}
							data->attrList = pango_attr_list_copy(list);
							clutter_text_set_attributes(ctext->TextActor(), data->attrList);
						}

						float height = (float)clutter_actor_get_height(CLUTTER_ACTOR(ctext->TextActor()));
						if ((int)height != (int)data->height)
						{
							m_singleLine->SetItemSpace(selectionStartPara, height);
							data->height = height;
						}
					}
				}
			}
			else
			{
				int start = 0;
				int end = 0;

				for (int i = selectionStartPara; i <= selectionEndPara; i++)
				{
					int len = strlen(((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent) + 1;
					start = 0;
					end = 0;
					if (i == selectionStartPara)
					{
						start = selectionStartChar;
						end = len;
					}
					else if (i > selectionStartPara && i < selectionEndPara)
					{
						start = 0;
						end = len;
					}
					else if (i == selectionEndPara)
					{
						start = 0;
						end = selectionEndChar;
					}
					if( m_singleLine->Renderer(i) != NULL )
					{
						CText* ctext = ((TextRenderer*)m_singleLine->Renderer(i))->GetText();
						if (ctext != NULL)
						{
							TextData* data = (TextData*)m_singleLine->GetDataSource()->GetData(i);
							if ((cf.style & STYLE_BOLD) == STYLE_BOLD)
							{
								bool flag = false;
								PangoAttrList* list = m_UpdateCharSelectFormat(data->attrList, start, end, PANGO_ATTR_WEIGHT, flag);
								if (!flag)
								{
									PangoAttribute* attr_Bold = pango_attr_weight_new(PANGO_WEIGHT_BOLD);
									attr_Bold->start_index = start;
									attr_Bold->end_index = end;
									pango_attr_list_insert(list, attr_Bold);
								}
								// update newest attribute list
								if (data->attrList != NULL)
								{
									pango_attr_list_unref(data->attrList);
									data->attrList = NULL;
								}
								data->attrList = pango_attr_list_copy(list);
								clutter_text_set_attributes(ctext->TextActor(), data->attrList);
							}
							if ((cf.style & STYLE_ITALIC) == STYLE_ITALIC)
							{
								bool flag = false;
								PangoAttrList* list = m_UpdateCharSelectFormat(data->attrList, start, end, PANGO_ATTR_STYLE, flag);
								if (!flag)
								{
									PangoAttribute* attr_Italic = pango_attr_style_new(PANGO_STYLE_ITALIC);
									attr_Italic->start_index = start;
									attr_Italic->end_index = end;
									pango_attr_list_insert(list, attr_Italic);
								}
								// update newest attribute list
								if (data->attrList != NULL)
								{
									pango_attr_list_unref(data->attrList);
									data->attrList = NULL;
								}
								data->attrList = pango_attr_list_copy(list);
								clutter_text_set_attributes(ctext->TextActor(), data->attrList);
							}
							if ((cf.style & STYLE_UNDERLINE) == STYLE_UNDERLINE)
							{
								bool flag = false;
								PangoAttrList* list = m_UpdateCharSelectFormat(data->attrList, start, end, PANGO_ATTR_UNDERLINE, flag);
								if (!flag)
								{
									PangoAttribute* attr_Underline = pango_attr_underline_new(PANGO_UNDERLINE_SINGLE);
									attr_Underline->start_index = start;
									attr_Underline->end_index = end;
									pango_attr_list_insert(list, attr_Underline);
								}
								// update newest attribute list
								if (data->attrList != NULL)
								{
									pango_attr_list_unref(data->attrList);
									data->attrList = NULL;
								}
								data->attrList = pango_attr_list_copy(list);
								clutter_text_set_attributes(ctext->TextActor(), data->attrList);
							}
							
							float height = (float)clutter_actor_get_height(CLUTTER_ACTOR(ctext->TextActor()));
							if ((int)height != (int)data->height)
							{
								m_singleLine->SetItemSpace(i, height);
								data->height = height;
							}
						}
					}
				}
			}
		}
		return true;
	}
	
	/*bool CRichText::m_ModifyCharFormat(long startIndex, long count, CTCharFormat &cf)
	{
		return true;
	}

	bool CRichText::m_ModifyParagraphFormat(long startIndex, long count, CTParagraphFormat &pf)
	{
		
		return true;
	}

	void CRichText::GetParagraphFormat(CTParagraphFormat& pf)
	{
	}*/

	bool CRichText::SetParagraphFormat(ITParaFormat& pf)
	{
		if (m_enableHighLight || !m_enableMultiLine)
		{
			return true;
		}
		int paraStart = m_cursorPositionParaIndex > m_boundPositionParaIndex ? m_boundPositionParaIndex : m_cursorPositionParaIndex;
		int paraEnd = m_cursorPositionParaIndex > m_boundPositionParaIndex ? m_cursorPositionParaIndex : m_boundPositionParaIndex;

		for (int i = paraStart; i <= paraEnd; i++)
		{
			if( m_singleLine->Renderer(i) != NULL )
			{
				CText* ctext = ((TextRenderer*)m_singleLine->Renderer(i))->GetText();
				TextData* data = (TextData*)m_singleLine->GetDataSource()->GetData(i);
				if (ctext != NULL)
				{
					clutter_text_set_line_alignment(ctext->TextActor(), (PangoAlignment)pf.alignment);
				}
				data->alignment = pf.alignment;
			}
		}

		return true;
	}

	bool CRichText::SetSingleLineTextAlignment(EHAlignment hAlign, EVAlignment vAlign)
	{
		if (m_enableMultiLine || m_text == NULL)
		{
			return false;
		}
		m_text->SetTextAlignment(hAlign, vAlign);
		return true;
	}

	bool CRichText::GetSingleLineTextAlignment(EHAlignment& hAlign, EVAlignment& vAlign)
	{
		if (m_enableMultiLine || m_text == NULL)
		{
			return false;
		}
		m_text->GetTextAlignment(hAlign, vAlign);
		return true;
	}
	
	void CRichText::SetSingleLineTextMaxCount(int count)
	{
		if (m_enableMultiLine || m_text == NULL)
		{
			return;
		}
		m_text->SetMaxTextCount(count);
	}

	void CRichText::m_UpdateParagraphAttrList(PangoAttrList* attrlist, int cursorIndex, int insertTextLen, int deleteTextLen, int preLen)
	{
		if (m_pangoAttrList != NULL)
		{
			pango_attr_list_unref(m_pangoAttrList);
			m_pangoAttrList = NULL;
		}
		m_pangoAttrList = pango_attr_list_new();

		PangoAttrIterator* iter = pango_attr_list_get_iterator(attrlist);
		GSList *attributes, *l;
		do
		{
			attributes = pango_attr_iterator_get_attrs(iter);

			/*int start = -1;
			int end = -1;
			pango_attr_iterator_range(iter, &start, &end);*/

			for (l = attributes; l != NULL; l = l->next)
			{
				PangoAttribute *attr = (PangoAttribute*)l->data;

				if (insertTextLen > 0)
				{
					if (deleteTextLen == 0)
					{
						if ((int)attr->start_index >= cursorIndex)
						{
							attr->start_index += insertTextLen;
							attr->end_index += insertTextLen;
						}
						else if ((int)attr->start_index < cursorIndex && (int)attr->end_index >= cursorIndex)
						{
							attr->end_index += insertTextLen;
						}
						pango_attr_list_insert(m_pangoAttrList, attr);
					}
					else if (deleteTextLen > 0)
					{
						if ((int)attr->end_index <= cursorIndex)
						{// the attr is before the selection start index, do not change
							pango_attr_list_insert(m_pangoAttrList, attr);
						}
						else if ((int)attr->start_index >= (cursorIndex + deleteTextLen))
						{// the attr is after the selection end index
							attr->start_index += (insertTextLen - deleteTextLen);
							attr->end_index += (insertTextLen - deleteTextLen);
							pango_attr_list_insert(m_pangoAttrList, attr);
						}
						else if ((int)attr->start_index >= cursorIndex && (int)attr->end_index <= (cursorIndex + deleteTextLen))
						{// the attr is discard
							// do not insert the attr
						}
						else if ((int)attr->start_index >= cursorIndex && (int)attr->end_index > (cursorIndex + deleteTextLen) && (int)attr->start_index < (cursorIndex + deleteTextLen))
						{// selection the front part of the attr
							attr->start_index = (cursorIndex + insertTextLen);
							int offset = (int)attr->end_index - cursorIndex - deleteTextLen;
							attr->end_index = attr->start_index + offset;
							pango_attr_list_insert(m_pangoAttrList, attr);
						}
						else if ((int)attr->start_index < cursorIndex && (int)attr->end_index <= (cursorIndex + deleteTextLen) && (int)attr->end_index > cursorIndex)
						{// selection the back part of the attr
							//attr->start_index = ;
							attr->end_index = (cursorIndex + insertTextLen);
							pango_attr_list_insert(m_pangoAttrList, attr);
						}
						else if ((int)attr->start_index < cursorIndex && (int)attr->end_index >(cursorIndex + deleteTextLen))
						{// selection the middle part of the attr
							//attr->start_index = ;
							attr->end_index = (cursorIndex - attr->start_index) + (attr->end_index - cursorIndex - deleteTextLen) + insertTextLen + attr->start_index;
							pango_attr_list_insert(m_pangoAttrList, attr);
						}
					}
				}
				else if (insertTextLen == 0)
				{
					if ((int)attr->start_index >= cursorIndex)
					{// delete part is before the current attribute
						attr->start_index -= deleteTextLen;
						attr->end_index -= deleteTextLen;
						pango_attr_list_insert(m_pangoAttrList, attr);
					}
					else if ((int)attr->start_index >= (cursorIndex - deleteTextLen) && (int)attr->start_index < cursorIndex && (int)attr->end_index > cursorIndex)
					{// delete part is in the front part of the current attribute
						int offset = (int)attr->end_index - cursorIndex;
						attr->start_index = cursorIndex - deleteTextLen;
						attr->end_index = attr->start_index + offset;
						pango_attr_list_insert(m_pangoAttrList, attr);
					}
					else if ((int)attr->end_index > (cursorIndex - deleteTextLen) && (int)attr->end_index <= cursorIndex && (int)attr->start_index < (cursorIndex - deleteTextLen))
					{// delete part is in the back part of the current attribute
						attr->end_index = cursorIndex - deleteTextLen;
						pango_attr_list_insert(m_pangoAttrList, attr);
					}
					else if ((int)attr->start_index < (cursorIndex - deleteTextLen) && (int)attr->end_index > cursorIndex)
					{// delete part is in the attribute
						attr->end_index -= deleteTextLen;
						pango_attr_list_insert(m_pangoAttrList, attr);
					}
					else if ((cursorIndex - deleteTextLen) >= (int)attr->end_index)
					{
						pango_attr_list_insert(m_pangoAttrList, attr);
					}
				}
				else if (insertTextLen == -1)
				{
					if ((int)attr->start_index >= cursorIndex)
					{// delete part is before the current attribute
						attr->start_index = attr->start_index - cursorIndex + preLen;
						attr->end_index = attr->end_index - cursorIndex + preLen;
						pango_attr_list_insert(m_pangoAttrList, attr);
					}
					else if ((int)attr->start_index >= (cursorIndex - deleteTextLen) && (int)attr->start_index < cursorIndex && (int)attr->end_index > cursorIndex)
					{// delete part is in the front part of the current attribute
						int offset = (int)attr->end_index - cursorIndex;
						attr->start_index = cursorIndex - deleteTextLen + preLen;
						attr->end_index = attr->start_index + offset;
						pango_attr_list_insert(m_pangoAttrList, attr);
					}
					else if ((int)attr->end_index > (cursorIndex - deleteTextLen) && (int)attr->end_index <= cursorIndex && (int)attr->start_index < (cursorIndex - deleteTextLen))
					{// delete part is in the back part of the current attribute
						attr->start_index += preLen;
						attr->end_index = cursorIndex - deleteTextLen + preLen;
						pango_attr_list_insert(m_pangoAttrList, attr);
					}
					else if ((int)attr->start_index < (cursorIndex - deleteTextLen) && (int)attr->end_index > cursorIndex)
					{// delete part is in the attribute
						attr->start_index += preLen;
						attr->end_index += (preLen - deleteTextLen);
						pango_attr_list_insert(m_pangoAttrList, attr);
					}
				}
			}

			g_slist_free(attributes);
		} while (pango_attr_iterator_next(iter));
		pango_attr_iterator_destroy(iter);
	}

	void CRichText::m_InsertAttrList(PangoAttrList* attrList, PangoAttrList* insertList, int cursorIndex, int insertLen, bool splitFlag)
	{
		//when insert cursor is in the range of the selection attribute, the attribute needs to be splited. 
		if (splitFlag)
		{
			PangoAttrList* tmpAttrList = pango_attr_list_new();

			PangoAttrIterator* iter = pango_attr_list_get_iterator(attrList);
			GSList *attributes, *l;
			do
			{
				attributes = pango_attr_iterator_get_attrs(iter);
				for (l = attributes; l != NULL; l = l->next)
				{
					PangoAttribute *attr = (PangoAttribute*)l->data;
					//int end = (int)attr->end_index;
					if ((int)attr->start_index < cursorIndex && (int)attr->end_index > cursorIndex)
					{
						int end = (int)attr->end_index;
						attr->end_index = cursorIndex;
						pango_attr_list_insert(tmpAttrList, attr);

						PangoAttribute* splitAttr = pango_attribute_copy(attr);
						splitAttr->start_index = cursorIndex + insertLen;
						splitAttr->end_index = end;
						pango_attr_list_insert(tmpAttrList, splitAttr);
					}
					else
					{
						pango_attr_list_insert(tmpAttrList, attr);
					}
				}
				g_slist_free(attributes);
			} while (pango_attr_iterator_next(iter));
			pango_attr_iterator_destroy(iter);

			if (m_pangoAttrList != NULL)
			{
				pango_attr_list_unref(m_pangoAttrList);
				m_pangoAttrList = NULL;
			}
			m_pangoAttrList = pango_attr_list_copy(tmpAttrList);
		}

		PangoAttrIterator* iter = pango_attr_list_get_iterator(insertList);
		GSList *attributes, *l;
		do
		{
			attributes = pango_attr_iterator_get_attrs(iter);
			for (l = attributes; l != NULL; l = l->next)
			{
				PangoAttribute *attr = (PangoAttribute*)l->data;
				attr->start_index += cursorIndex;
				attr->end_index += cursorIndex;
				pango_attr_list_insert(m_pangoAttrList, attr);
			}
			g_slist_free(attributes);
		} while (pango_attr_iterator_next(iter));
		pango_attr_iterator_destroy(iter);
	}

	void CRichText::m_UpdateMergedParagraphAttrList(PangoAttrList* attrListH, PangoAttrList* attrListT, int cursorIndexHead, int cursorIndexTail, int insertTextLen)
	{
		if (m_pangoAttrList != NULL)
		{
			pango_attr_list_unref(m_pangoAttrList);
			m_pangoAttrList = NULL;
		}
		m_pangoAttrList = pango_attr_list_new();

		// save the attribute from 0 to the cursorIndexHead in the head paragraph 
		PangoAttrIterator* iterHead = pango_attr_list_get_iterator(attrListH);
		GSList *attributes, *l;
		do
		{
			attributes = pango_attr_iterator_get_attrs(iterHead);

			/*int start = -1;
			int end = -1;
			pango_attr_iterator_range(iterHead, &start, &end);*/

			for (l = attributes; l != NULL; l = l->next)
			{
				PangoAttribute *attr = (PangoAttribute*)l->data;
				if ((int)attr->end_index <= cursorIndexHead)
				{
					pango_attr_list_insert(m_pangoAttrList, attr);
				}
				else if ((int)attr->start_index < cursorIndexHead && (int)attr->end_index > cursorIndexHead)
				{
					attr->end_index = cursorIndexHead;
					pango_attr_list_insert(m_pangoAttrList, attr);
				}
			}

			g_slist_free(attributes);
		} while (pango_attr_iterator_next(iterHead));
		pango_attr_iterator_destroy(iterHead);

		// save the attribute from cursorIndexTail to the end in the tail paragraph
		int offset = cursorIndexHead + insertTextLen;
		PangoAttrIterator* iterTail = pango_attr_list_get_iterator(attrListT);
		do
		{
			attributes = pango_attr_iterator_get_attrs(iterTail);

			/*int start = -1;
			int end = -1;
			pango_attr_iterator_range(iterTail, &start, &end);*/

			for (l = attributes; l != NULL; l = l->next)
			{
				PangoAttribute *attr = (PangoAttribute*)l->data;
				if ((int)attr->start_index >= cursorIndexTail)
				{
					attr->start_index = offset + attr->start_index - cursorIndexTail;
					attr->end_index = offset + attr->end_index - cursorIndexTail;
					pango_attr_list_insert(m_pangoAttrList, attr);
				}
				else if ((int)attr->start_index < cursorIndexTail && (int)attr->end_index > cursorIndexTail)
				{
					attr->start_index = offset;
					attr->end_index = offset + (attr->end_index - cursorIndexTail);
					pango_attr_list_insert(m_pangoAttrList, attr);
				}
			}

			g_slist_free(attributes);
		} while (pango_attr_iterator_next(iterTail));
		pango_attr_iterator_destroy(iterTail);

	}

	void CRichText::m_GetSelectionPangoAttrList(void)
	{
		if (!m_enableMultiLine)
		{
			int cursorPos = clutter_text_get_cursor_position(m_text->TextActor());
			int boundPos = clutter_text_get_selection_bound(m_text->TextActor());
			if (cursorPos == boundPos)
			{
				return;
			}

			int textLen = strlen(clutter_text_get_text(m_text->TextActor()));
			if (cursorPos == -1 && textLen > 0)
			{
				cursorPos = textLen;
			}
			if (boundPos == -1 && textLen > 0)
			{
				boundPos = textLen;
			}

			int startPos = cursorPos < boundPos ? cursorPos : boundPos;
			int endPos = cursorPos < boundPos ? boundPos : cursorPos;

			PangoAttrList* list = clutter_text_get_attributes(m_text->TextActor());
			if (m_pangoAttrListCopy != NULL)
			{
				pango_attr_list_unref(m_pangoAttrListCopy);
				m_pangoAttrListCopy = NULL;
			}
			m_pangoAttrListCopy = pango_attr_list_new();

			PangoAttrIterator* iterHead = pango_attr_list_get_iterator(list);
			GSList *attributes, *l;
			do
			{
				attributes = pango_attr_iterator_get_attrs(iterHead);

				for (l = attributes; l != NULL; l = l->next)
				{
					PangoAttribute *attr = (PangoAttribute*)l->data;
					if (startPos <= (int)attr->start_index && endPos >= (int)attr->end_index)
					{
						attr->start_index -= startPos;
						attr->end_index -= startPos;
						pango_attr_list_insert(m_pangoAttrListCopy, attr);
					}
					else if (startPos > (int)attr->start_index && endPos < (int)attr->end_index)
					{
						attr->start_index = 0;
						attr->end_index = endPos - startPos;
						pango_attr_list_insert(m_pangoAttrListCopy, attr);
					}
					else if (startPos <= (int)attr->start_index && endPos > (int)attr->start_index && endPos < (int)attr->end_index)
					{
						attr->start_index -= startPos;
						attr->end_index = endPos - startPos;
						pango_attr_list_insert(m_pangoAttrListCopy, attr);
					}
					else if (startPos > (int)attr->start_index && startPos < (int)attr->end_index && endPos >= (int)attr->end_index)
					{
						attr->start_index = 0;
						attr->end_index -= startPos;
						pango_attr_list_insert(m_pangoAttrListCopy, attr);
					}
				}

				g_slist_free(attributes);
			} while (pango_attr_iterator_next(iterHead));
			pango_attr_iterator_destroy(iterHead);
		}
		else
		{
			int selectionStartPara = 0;
			int selectionStartChar = 0;
			int selectionEndPara = 0;
			int selectionEndChar = 0;
			int selectionLen = 0;
			m_GetSelectionBoundData(selectionStartPara, selectionStartChar, selectionEndPara, selectionEndChar, selectionLen);

			if (selectionStartPara == selectionEndPara && selectionStartChar == selectionEndChar)
			{
				return;
			}

			int size = m_pangoAttrListCopyList.size();
			if (size > 0)
			{
				std::list<PangoAttrList*>::iterator iter = m_pangoAttrListCopyList.begin();
				for (; iter != m_pangoAttrListCopyList.end(); ++iter)
				{
					if ((*iter) != NULL)
					{
						pango_attr_list_unref(*iter);
						*iter = NULL;
					}
				}
				m_pangoAttrListCopyList.clear();
			}

			if (selectionStartPara == selectionEndPara)
			{// selection in the same paragraph
				TextData* data = (TextData*)m_singleLine->GetDataSource()->GetData(selectionStartPara);
				int len = strlen(data->textContent);

				PangoAttrList* attrList = pango_attr_list_new();
				PangoAttrIterator* iter = pango_attr_list_get_iterator(data->attrList);
				GSList *attributes, *l;
				do
				{
					attributes = pango_attr_iterator_get_attrs(iter);

					for (l = attributes; l != NULL; l = l->next)
					{
						PangoAttribute *attr = (PangoAttribute*)l->data;
						if (selectionStartChar <= (int)attr->start_index && selectionEndChar >= (int)attr->end_index)
						{
							attr->start_index -= selectionStartChar;
							attr->end_index -= selectionStartChar;
							pango_attr_list_insert(attrList, attr);
						}
						else if (selectionStartChar > (int)attr->start_index && selectionEndChar < (int)attr->end_index)
						{
							attr->start_index = 0;
							attr->end_index = selectionEndChar - selectionStartChar;
							pango_attr_list_insert(attrList, attr);
						}
						else if (selectionStartChar <= (int)attr->start_index && selectionEndChar >(int)attr->start_index && selectionEndChar < (int)attr->end_index)
						{
							attr->start_index -= selectionStartChar;
							attr->end_index = selectionEndChar - selectionStartChar;
							pango_attr_list_insert(attrList, attr);
						}
						else if (selectionStartChar >(int)attr->start_index && selectionStartChar < (int)attr->end_index && selectionEndChar >= (int)attr->end_index)
						{
							attr->start_index = 0;
							attr->end_index -= selectionStartChar;
							pango_attr_list_insert(attrList, attr);
						}
					}

					g_slist_free(attributes);
				} while (pango_attr_iterator_next(iter));
				pango_attr_iterator_destroy(iter);

				m_pangoAttrListCopyList.push_back(attrList);
			}
			else
			{//selection in several paragraphs
				for (int i = selectionStartPara; i <= selectionEndPara; i++)
				{
					TextData* data = (TextData*)m_singleLine->GetDataSource()->GetData(i);
					int len = strlen(data->textContent);
					PangoAttrList* attrList/* = pango_attr_list_new()*/;

					if (i == selectionStartPara)
					{
						attrList = pango_attr_list_new();

						PangoAttrIterator* iter = pango_attr_list_get_iterator(data->attrList);
						GSList *attributes, *l;
						do
						{
							attributes = pango_attr_iterator_get_attrs(iter);

							for (l = attributes; l != NULL; l = l->next)
							{
								PangoAttribute *attr = (PangoAttribute*)l->data;
								if (selectionStartChar <= (int)attr->start_index && len >= (int)attr->end_index)
								{
									attr->start_index -= selectionStartChar;
									attr->end_index -= selectionStartChar;
									pango_attr_list_insert(attrList, attr);
								}
								else if (selectionStartChar > (int)attr->start_index && len < (int)attr->end_index)
								{
									attr->start_index = 0;
									attr->end_index = len - selectionStartChar;
									pango_attr_list_insert(attrList, attr);
								}
								else if (selectionStartChar <= (int)attr->start_index && len > (int)attr->start_index && len < (int)attr->end_index)
								{
									attr->start_index -= selectionStartChar;
									attr->end_index = len - selectionStartChar;
									pango_attr_list_insert(attrList, attr);
								}
								else if (selectionStartChar > (int)attr->start_index && selectionStartChar < (int)attr->end_index && len >= (int)attr->end_index)
								{
									attr->start_index = 0;
									attr->end_index -= selectionStartChar;
									pango_attr_list_insert(attrList, attr);
								}
							}

							g_slist_free(attributes);
						} while (pango_attr_iterator_next(iter));
						pango_attr_iterator_destroy(iter);

					}
					else if (i == selectionEndPara)
					{
						attrList = pango_attr_list_new();

						PangoAttrIterator* iter = pango_attr_list_get_iterator(data->attrList);
						GSList *attributes, *l;
						do
						{
							attributes = pango_attr_iterator_get_attrs(iter);

							for (l = attributes; l != NULL; l = l->next)
							{
								PangoAttribute *attr = (PangoAttribute*)l->data;
								if ((int)attr->start_index < selectionEndChar)
								{
									if ((int)attr->end_index <= selectionEndChar)
									{
										pango_attr_list_insert(attrList, attr);
									}
									else
									{
										attr->end_index = selectionEndChar;
										pango_attr_list_insert(attrList, attr);
									}
								}
							}

							g_slist_free(attributes);
						} while (pango_attr_iterator_next(iter));
						pango_attr_iterator_destroy(iter);
					}
					else
					{
						attrList = pango_attr_list_copy(data->attrList);
					}
					m_pangoAttrListCopyList.push_back(attrList);
				}
			}
		}
	}

	void CRichText::EnableHighlightMove(bool flagEnable)
	{
		if (m_enableHighLight == flagEnable || !m_enableMultiLine)
		{
			return;
		}
		m_enableHighLight = flagEnable;
		if (!flagEnable)
		{
			EnableEditable(m_enableEditablePreHLState);
			return;
		}
		else
		{
			m_enableEditablePreHLState = IsEditableEnabled();
			EnableEditable(false);
		}
		

		/*int para_start = 0;
		int para_end = 0;
		m_ShowItemRange(para_start, para_end);*/
		int size = m_singleLine->GetDataSource()->Size();
		m_highlightData.clear();
		//for (int i = para_start; i <= para_end; i++)
		for (int i = 0; i < size; i++)
		{
			char* buf = ((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent;
			int len = strlen(buf);
			int pos_start = 0;
			int pos_end = 0;
			for (int t = 0; t < len; t++)
			{
				if (buf[t] == ' ')
				{
					pos_end = t;

					if (pos_start >= pos_end)
					{
						pos_start = t + 1;
					}
					else
					{
						CTHighlightData hData;
						hData.indexPara = i;
						hData.indexCharStart = pos_start;
						hData.indexCharEnd = pos_end;
						m_highlightData.push_back(hData);
						pos_start = t + 1;
					}
				}

				if (t == (len - 1) && buf[t] != ' ')
				{
					pos_end = t + 1;
					if (pos_start < pos_end)
					{
						CTHighlightData hData;
						hData.indexPara = i;
						hData.indexCharStart = pos_start;
						hData.indexCharEnd = pos_end;
						m_highlightData.push_back(hData);
					}
				}
			}
		}

		if (m_highlightData.size() <= 0)
		{
			m_enableHighLight = false;
			EnableEditable(m_enableEditablePreHLState);
			return;
		}
		//calculate the highlight index by the current first line
		//m_highlightMoveIndex = ?;

		/*int cursorIndexPara = m_cursorPositionParaIndex;
		int cursorIndexChar = m_cursorPositionCharIndex;*/
		int index_firstShowPara = -1;
		for (int i = 0; i < size; i++)
		{
			if( m_singleLine->Renderer(i) != NULL )
			{
				if (((TextRenderer*)m_singleLine->Renderer(i))->GetText() != NULL)
				{
					index_firstShowPara = ((TextData*)m_singleLine->GetDataSource()->GetData(i))->index;
					break;
				}
			}
		}
		
		if (index_firstShowPara < 0)
		{
			m_enableHighLight = false;
			EnableEditable(m_enableEditablePreHLState);
			return;
		}

		float height = 0;
		for (int i = 0; i < index_firstShowPara; i++)
		{
			height += ((TextData*)m_singleLine->GetDataSource()->GetData(i))->height;
		}

		TRect rect = m_singleLine->VisibleAreaRect();
		float offset = -(rect.y - height);
		m_singleLine->ScrollVisibleArea(0, offset, false);

		/*for (int i = 0; i < m_highlightData.size(); i++)
		{
			if (index_firstShowPara == )
		}*/
		int index = 0;
		std::list<CTHighlightData>::iterator iter = m_highlightData.begin();
		for (; iter != m_highlightData.end(); ++iter)
		{
			if (index_firstShowPara == iter->indexPara)
			{
				break;
			}
			index++;
		}
		m_highlightMoveIndex = index;
	}

	bool CRichText::IsHighlightMoveEnabled(void)
	{
		return m_enableHighLight;
	}

	void CRichText::SetHighlightMoveBgColor(ClutterColor color)
	{
		m_highlightColor = color;
	}

	void CRichText::SetHighlightMoveBgColor(int a, int r, int g, int b)
	{
		m_highlightColor.alpha = a;
		m_highlightColor.red = r;
		m_highlightColor.green = g;
		m_highlightColor.blue = b;
	}

	const ClutterColor& CRichText::HighlightMoveBgColor(void)
	{
		return m_highlightColor;
	}

	void CRichText::GetHighlightMoveBgColor(unsigned char& a, unsigned char& r, unsigned char& g, unsigned char& b)
	{
		a = m_highlightColor.alpha;
		r = m_highlightColor.red;
		g = m_highlightColor.green;
		b = m_highlightColor.blue;
	}

	void CRichText::MoveHighlight(EDirection dir)
	{
		if (!m_enableHighLight || m_moveHighLightBusyFlag || !m_enableMultiLine)
		{
			return;
		}
		if (m_highlightData.size() <= 0)
		{
			return;
		}
		m_moveHighLightBusyFlag = true;
		int index = 0;
		int indexPara = -1;
		int indexChar_start = -1;
		int indexChar_end = -1;
		int lineHeight = -1;
		PangoRectangle rect_ink = { 0 };
		PangoRectangle rect_logic = { 0 };
		int preParaY = 0;
		std::list<CTHighlightData>::iterator iterHL = m_highlightData.begin();
		CText* ctextShow = NULL;
		switch (dir)
		{
		case DIRECTION_UP:
			break;
		case DIRECTION_DOWN:
			break;
		case DIRECTION_LEFT:
			if (m_highlightMoveIndex == 0)
			{
				//m_highlightMoveIndex = (m_highlightData.size() - 1);
			}
			else
			{
				m_highlightMoveIndex--;
			}

			for (; iterHL != m_highlightData.end(); ++iterHL)
			{
				if (lineHeight < 0)
				{
					if( m_singleLine->Renderer((*iterHL).indexPara) != NULL )
					{
						CText* ctext = ((TextRenderer*)m_singleLine->Renderer((*iterHL).indexPara))->GetText();
						if (ctext != NULL)
						{
							PangoLayoutLine *line = pango_layout_get_line(clutter_text_get_layout(ctext->TextActor()), 0);
							pango_layout_line_get_extents(line, &rect_ink, &rect_logic);
							lineHeight = rect_logic.height / PANGO_SCALE;
						}
					}
				}
				if (index == m_highlightMoveIndex)
				{
					indexPara = iterHL->indexPara;
					indexChar_start = iterHL->indexCharStart;
					indexChar_end = iterHL->indexCharEnd;
				}
				if (indexPara >= 0 && lineHeight >= 0)
				{
					break;
				}
				index++;
			}

			if (indexPara < 0 || indexChar_start < 0 || indexChar_end < 0 || lineHeight < 0)
			{
				m_moveHighLightBusyFlag = false;
				return;
			}

			for (int i = 0; i < indexPara; i++)
			{
				preParaY += (int)((TextData*)m_singleLine->GetDataSource()->GetData(i))->height;
			}
			
			if( m_singleLine->Renderer(indexPara) == NULL )
			{
				m_singleLine->ScrollVisibleArea(0, (float)-lineHeight, false);
			}

			if( m_singleLine->Renderer(indexPara) != NULL )
			{
				ctextShow = ((TextRenderer*)m_singleLine->Renderer(indexPara))->GetText();
				if (ctextShow != NULL)
				{
					PangoLayout *layout = clutter_text_get_layout(ctextShow->TextActor());
					int startYPos = 0;
					int endYPos = 0;
					int lineCount = pango_layout_get_line_count(layout);
					// get the start line y in the para
					for (int i = 0; i < lineCount; i++)
					{
						PangoLayoutLine *line = pango_layout_get_line(layout, i);
						pango_layout_line_get_extents(line, &rect_ink, &rect_logic);
						if (i == (lineCount - 1))
						{
							if (indexChar_start >= line->start_index && indexChar_start <= (line->start_index + line->length))
							{
								break;
							}
						}
						else
						{
							if (indexChar_start >= line->start_index && indexChar_start < (line->start_index + line->length))
							{
								break;
							}
						}
						startYPos += rect_logic.height / PANGO_SCALE;
					}
					// get the end line y in the para
					int endLineHeight = 0;
					for (int i = 0; i < lineCount; i++)
					{
						PangoLayoutLine *line = pango_layout_get_line(layout, i);
						pango_layout_line_get_extents(line, &rect_ink, &rect_logic);
						endLineHeight = rect_logic.height / PANGO_SCALE;
						if (i == (lineCount - 1))
						{
							if (indexChar_end >= line->start_index && indexChar_end <= (line->start_index + line->length))
							{
								break;
							}
						}
						else
						{
							if (indexChar_end >= line->start_index && indexChar_end < (line->start_index + line->length))
							{
								break;
							}
						}
						endYPos += rect_logic.height / PANGO_SCALE;
					}

					int startLineYOffset = startYPos + preParaY;
					int endLineYOffset = endYPos + preParaY + endLineHeight;
					//
					int offset_scroll = 0;
					TRect rect = m_singleLine->VisibleAreaRect();
					if ((startLineYOffset - rect.y) < 0 && (endLineYOffset - rect.y) >= 0)
						//if ((startLineYOffset - rect.y) <= rect.h)
					{
						offset_scroll = (startLineYOffset - (int)rect.y);
						m_singleLine->ScrollVisibleArea(0, (float)offset_scroll, false);
					}
				}
			}

			break;
		case DIRECTION_RIGHT:
			if (m_highlightMoveIndex == (m_highlightData.size() - 1))
			{
				//m_highlightMoveIndex = 0;
			}
			else
			{
				m_highlightMoveIndex++;
			}
			
			
			for (; iterHL != m_highlightData.end(); ++iterHL)
			{
				if (lineHeight < 0)
				{
					if( m_singleLine->Renderer((*iterHL).indexPara) != NULL )
					{
						CText* ctext = ((TextRenderer*)m_singleLine->Renderer((*iterHL).indexPara))->GetText();
						if (ctext != NULL)
						{
							PangoLayoutLine *line = pango_layout_get_line(clutter_text_get_layout(ctext->TextActor()), 0);
							pango_layout_line_get_extents(line, &rect_ink, &rect_logic);
							lineHeight = rect_logic.height / PANGO_SCALE;
						}
					}
				}
				if (index == m_highlightMoveIndex)
				{
					indexPara = iterHL->indexPara;
					indexChar_start = iterHL->indexCharStart;
					indexChar_end = iterHL->indexCharEnd;
					break;
				}
				index++;
			}

			if (indexPara < 0 || indexChar_start < 0 || indexChar_end < 0 || lineHeight < 0)
			{
				m_moveHighLightBusyFlag = false;
				return;
			}

			
			for (int i = 0; i < indexPara; i++)
			{
				preParaY += (int)((TextData*)m_singleLine->GetDataSource()->GetData(i))->height;
			}

			if(m_singleLine->Renderer(indexPara) == NULL )
			{
				m_singleLine->ScrollVisibleArea(0, (float)lineHeight, false);
			}

			if( m_singleLine->Renderer(indexPara) != NULL )
			{
				ctextShow = ((TextRenderer*)m_singleLine->Renderer(indexPara))->GetText();
				if (ctextShow != NULL)
				{
					PangoLayout *layout = clutter_text_get_layout(ctextShow->TextActor());
					int startYPos = 0;
					int endYPos = 0;
					int lineCount = pango_layout_get_line_count(layout);
					// get the start line y in the para
					for (int i = 0; i < lineCount; i++)
					{
						PangoLayoutLine *line = pango_layout_get_line(layout, i);
						pango_layout_line_get_extents(line, &rect_ink, &rect_logic);
						if (i == (lineCount - 1))
						{
							if (indexChar_start >= line->start_index && indexChar_start <= (line->start_index + line->length))
							{
								break;
							}
						}
						else
						{
							if (indexChar_start >= line->start_index && indexChar_start < (line->start_index + line->length))
							{
								break;
							}
						}
						startYPos += rect_logic.height / PANGO_SCALE;
					}
					// get the end line y in the para
					int endLineHeight = 0;
					for (int i = 0; i < lineCount; i++)
					{
						PangoLayoutLine *line = pango_layout_get_line(layout, i);
						pango_layout_line_get_extents(line, &rect_ink, &rect_logic);
						endLineHeight = rect_logic.height / PANGO_SCALE;
						if (i == (lineCount - 1))
						{
							if (indexChar_end >= line->start_index && indexChar_end <= (line->start_index + line->length))
							{
								break;
							}
						}
						else
						{
							if (indexChar_end >= line->start_index && indexChar_end < (line->start_index + line->length))
							{
								break;
							}
						}
						endYPos += rect_logic.height / PANGO_SCALE;
					}

					int startLineYOffset = startYPos + preParaY;
					int endLineYOffset = endYPos + preParaY + endLineHeight;
					//
					int offset_scroll = 0;
					TRect rect = m_singleLine->VisibleAreaRect();
					if ((startLineYOffset - rect.y) <= rect.h && (endLineYOffset - rect.y) > rect.h)
						//if ((startLineYOffset - rect.y) <= rect.h)
					{
						offset_scroll = (endLineYOffset - (int)rect.y - (int)rect.h);
						m_singleLine->ScrollVisibleArea(0, (float)offset_scroll, false);
					}
				}
			}
			break;
		default:
			break;
		}
		m_moveHighLightBusyFlag = false;
	}

	void CRichText::m_ShowItemRange(int& start, int& end)
	{// the attr height decide the visibleAreaRect height
		//int startParaIndex = 0;
		//int endParaIndex = 0;
		float  view_x, view_y;
		this->GetPosition(view_x, view_y);
		TRect rect = m_singleLine->VisibleAreaRect();
		//printf("rect=%f, %f\n", rect.y, rect.h);
		
		int size = m_singleLine->GetDataSource()->Size();
		if (size <= 0)
		{
			start = 0;
			end = 0;
			return;
		}

		float offset_top = abs(rect.y);
		for (int i = 0; i < size; i++)
		{
			float h = ((TextData*)m_singleLine->GetDataSource()->GetData(i))->height;
			if (h < offset_top)
			{
				offset_top -= h;
			}
			else
			{
				start = i;
				break;
			}
		}

		float offset_bottom = abs(rect.y) + rect.h;
		for (int i = 0; i < size; i++)
		{
			float h = ((TextData*)m_singleLine->GetDataSource()->GetData(i))->height;
			if (h < offset_bottom)
			{
				offset_bottom -= h;
			}
			else
			{
				end = i;
				break;
			}

			if (i == (size - 1) && h < offset_bottom)
			{
				end = i;
				break;
			}
		}
	}

	void CRichText::SetFont(const char* font)
	{
		HALO_ASSERT(font != NULL);
		if (m_enableHighLight)
		{
			return;
		}
		if (m_fontName != NULL)
		{
			delete [] m_fontName;
			m_fontName = NULL;
		}
		int len = strlen(font);
		m_fontName = new char[len + 1];
		strncpy(m_fontName, font, len);
		m_fontName[len] = '\0';

		if (!m_enableMultiLine)
		{
			SetFontInfo(m_text);
			m_UpdateSingleLineTextFormat();
		}
		else
		{
			int textLen = 0;
			int size = m_singleLine->GetDataSource()->Size();
			for (int i = 0; i < size; i++)
			{
				textLen += strlen(((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent);
				textLen += 1;
			}
			char* textBuf = new char[textLen];
			int currentIndex = 0;
			for (int i = 0; i < size; i++)
			{
				char* paraBuf = ((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent;
				int paraLen = strlen(paraBuf);

				strncpy(textBuf + currentIndex, paraBuf, paraLen);
				if (i < (size - 1))
				{// end with '\n'
					textBuf[currentIndex + paraLen] = '\n';
				}
				else if (i == (size - 1))
				{// end with '\0'
					textBuf[currentIndex + paraLen] = '\0';
				}
				currentIndex += (paraLen + 1);
			}

			TRect rect = m_singleLine->VisibleAreaRect();
			if (abs((int)rect.y) > 0)
			{
				m_singleLine->ScrollVisibleArea(0, -rect.y, false);
			}
			m_ReleaseMultiLine();
			m_InitialMultiLine(textBuf);
			//UpdateMultiLineTextFormat(false, -1);
		}
	}

	const char* CRichText::Font(void)
	{
		if (!m_enableMultiLine)
		{
			return m_text->Font();
		}
		else
		{
			int start = -1;
			int end = -1;
			//m_ShowItemRange(start, end);
			m_singleLine->GetWindowItemRange(start, end);
			if (start < 0 || end < 0)
			{
				return NULL;
			}
			if(m_singleLine->Renderer(start) != NULL )
			{
				return ((TextRenderer*)m_singleLine->Renderer(start))->GetText()->Font();
			}
			else
			{
				return NULL;
			}
		}
	}

	void CRichText::SetFontSize(int size)
	{
		HALO_ASSERT(size >= 0);
		if (m_enableHighLight)
		{
			return;
		}
		m_fontSize = size;
		if (!m_enableMultiLine)
		{
			SetFontInfo(m_text);
			m_UpdateSingleLineTextFormat();
		}
		else
		{
			int textLen = 0;
			int size = m_singleLine->GetDataSource()->Size();
			for (int i = 0; i < size; i++)
			{
				textLen += strlen(((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent);
				textLen += 1;
			}
			char* textBuf = new char[textLen];
			int currentIndex = 0;
			for (int i = 0; i < size; i++)
			{
				char* paraBuf = ((TextData*)m_singleLine->GetDataSource()->GetData(i))->textContent;
				int paraLen = strlen(paraBuf);

				strncpy(textBuf + currentIndex, paraBuf, paraLen);
				if (i < (size - 1))
				{// end with '\n'
					textBuf[currentIndex + paraLen] = '\n';
				}
				else if (i == (size - 1))
				{// end with '\0'
					textBuf[currentIndex + paraLen] = '\0';
				}
				currentIndex += (paraLen + 1);
			}

			TRect rect = m_singleLine->VisibleAreaRect();
			if (abs((int)rect.y) > 0)
			{
				m_singleLine->ScrollVisibleArea(0, -rect.y, false);
			}
			m_ReleaseMultiLine();
			m_InitialMultiLine(textBuf);

			//UpdateMultiLineTextFormat(false, -1);
		}
	}

	int CRichText::FontSize(void)
	{
		return m_fontSize;
	}

	const char* CRichText::GetActorType(void)
	{
		return "RichText";
	}
	
	void CRichText::m_UpdateSingleLineTextFormat()
	{
	}

	void CRichText::UpdateMultiLineTextFormat(CText* text, PangoAttrList* list, int alignment)
	{
		if (text != NULL)
		{
			// char format
			clutter_text_set_attributes(text->TextActor(), list);
			clutter_text_insert_text(text->TextActor(), "", -1);

			// para format
			clutter_text_set_line_alignment(text->TextActor(), (PangoAlignment)alignment);
		}
	}

	void CRichText::m_MoveCurrentParaToShow(int indexPara, int indexChar)
	{
		TRect rect = m_singleLine->VisibleAreaRect();
		int size = m_singleLine->GetDataSource()->Size();
		if (indexPara >= size)
		{
			return;
		}
		float height = 0;
		for (int i = 0; i < indexPara; i++)
		{
			height += ((TextData*)m_singleLine->GetDataSource()->GetData(i))->height;
		}

		if( m_singleLine->Renderer(indexPara) == NULL )
		{
			return;
		}
		CText* ctext = ((TextRenderer*)m_singleLine->Renderer(indexPara))->GetText();
		// if the para is out of the show rect, make the first line of the para to show at the top of the show rect
		if (ctext == NULL)
		{
			float offset = 0;
			if (height <= rect.y)
			{// the para is above the show rect
				offset = height - rect.y;
			}
			else if (height >= (rect.y + rect.h))
			{// the para is below the show rect
				offset = height - rect.y - rect.h + ((TextData*)m_singleLine->GetDataSource()->GetData(indexPara))->height;
			}
			m_singleLine->ScrollVisibleArea(0, (float)offset, false);
		}

		// if the para is in the show rect, make the indexChar line to show whole in the show rect
		if (ctext != NULL)
		{
			PangoLayout *layout = clutter_text_get_layout(ctext->TextActor());
			//int lineIndexStart = 0;
			//int lineIndexEnd = 0;
			PangoRectangle rect_ink = { 0 };
			PangoRectangle rect_logic = { 0 };
			int lineCount = pango_layout_get_line_count(layout);
			float lineHeight = 0;
			float lineYOffset = 0;
			for (int i = 0; i < lineCount; i++)
			{
				PangoLayoutLine *line = pango_layout_get_line(layout, i);
				pango_layout_line_get_extents(line, &rect_ink, &rect_logic);
				if (i == (lineCount - 1))
				{
					if (indexChar >= line->start_index && indexChar <= (line->start_index + line->length))
					{
						lineHeight = (float)rect_logic.height / PANGO_SCALE;
						break;
					}
				}
				else
				{
					if (indexChar >= line->start_index && indexChar < (line->start_index + line->length))
					{
						lineHeight = (float)rect_logic.height / PANGO_SCALE;
						break;
					}
				}
				lineYOffset += rect_logic.height / PANGO_SCALE;
			}
			rect = m_singleLine->VisibleAreaRect();
			float cursorY = (height + lineYOffset) - rect.y;
			if (cursorY < 0)
			{
				m_singleLine->ScrollVisibleArea(0, cursorY, false);
			}
			else if ((cursorY + lineHeight) > rect.h)
			{
				m_singleLine->ScrollVisibleArea(0, (cursorY + lineHeight - rect.h), false);
			}
		}
	}

	void CRichText::DeleteText(void)
	{
		if (!m_enableSelectable)
		{
			return;
		}

		if (!m_enableMultiLine)
		{
			clutter_text_delete_selection(m_text->TextActor());
			int cursorPos = clutter_text_get_cursor_position(m_text->TextActor());
			m_SetParagraphFocus(m_text->TextActor(), cursorPos, cursorPos);
		}
		else
		{
			if (m_cursorPositionParaIndex == m_boundPositionParaIndex && m_cursorPositionCharIndex == m_boundPositionCharIndex)
			{
				return;
			}
			int selectionStartPara = 0;
			int selectionStartChar = 0;
			int selectionEndPara = 0;
			int selectionEndChar = 0;
			int selectionLen = 0;
			m_GetSelectionBoundData(selectionStartPara, selectionStartChar, selectionEndPara, selectionEndChar, selectionLen);

			//make sure that the selectionStartPara needs to show
			m_MoveCurrentParaToShow(selectionStartPara, selectionStartChar);

			int selectionParaCount = abs(selectionStartPara - selectionEndPara);
			//m_insertTextFlag = true;
			TextData* data = (TextData*)m_singleLine->GetDataSource()->GetData(selectionStartPara);
			const char* buf = data->textContent;
			int len = strlen(buf);

			if (selectionParaCount == 0)
			{//selection range in one para
				char* newBuf;
				int newBufLen = selectionStartChar + len - selectionEndChar;

				if (newBufLen == 0)
				{
					newBufLen = 1;
					newBuf = new char[newBufLen];
					newBuf[0] = '\0';
				}
				else
				{
					newBuf = new char[newBufLen + 1];

					for (int i = 0; i < selectionStartChar; i++)
					{
						newBuf[i] = buf[i];
					}
					for (int i = 0; i < (len - selectionEndChar); i++)
					{
						newBuf[selectionStartChar + i] = buf[selectionEndChar + i];
					}
					newBuf[newBufLen] = '\0';
				}

				delete [] data->textContent;
				data->textContent = NULL;
				data->textContent = newBuf;

				m_UpdateParagraphAttrList(data->attrList, selectionEndChar, 0, selectionEndChar - selectionStartChar, 0);
				pango_attr_list_unref(data->attrList);
				data->attrList = NULL;
				data->attrList = pango_attr_list_copy(m_pangoAttrList);

				if( m_singleLine->Renderer(selectionStartPara) != NULL )
				{
					CText* ctext = ((TextRenderer*)m_singleLine->Renderer(selectionStartPara))->GetText();
					if (ctext != NULL)
					{
						m_insertTextFlag = true;
						clutter_text_set_text(ctext->TextActor(), newBuf);
						m_insertTextFlag = false;
						clutter_text_set_attributes(ctext->TextActor(), data->attrList);

						float height = (float)clutter_actor_get_height(CLUTTER_ACTOR(ctext->TextActor()));
						m_singleLine->SetItemSpace(selectionStartPara, height);
						((TextData*)m_singleLine->GetDataSource()->GetData(selectionStartPara))->height = height;
						m_cursorPositionCharIndex = selectionStartChar;
						m_boundPositionCharIndex = selectionStartChar;
						int indexUTF8 = bytes_to_offset(data->textContent, m_cursorPositionCharIndex);
						m_SetParagraphFocus(ctext->TextActor(), indexUTF8, indexUTF8);
					}
				}
			}
			else
			{//selection range in several paras
				TextData* dataStart = (TextData*)m_singleLine->GetDataSource()->GetData(selectionStartPara);
				char* buf_startPara = dataStart->textContent;
				int len_startPara = strlen(buf_startPara);

				TextData* dataEnd = (TextData*)m_singleLine->GetDataSource()->GetData(selectionEndPara);
				char* buf_endPara = dataEnd->textContent;
				int len_endPara = strlen(buf_endPara);

				int newBufLen = selectionStartChar + len_endPara - selectionEndChar;
				char *newBuf;
				if (newBufLen == 0)
				{
					newBufLen = 1;
					newBuf = new char[newBufLen];
					newBuf[0] = '\0';
				}
				else
				{
					newBuf = new char[newBufLen + 1];
					for (int i = 0; i < selectionStartChar; i++)
					{
						newBuf[i] = buf_startPara[i];
					}
					for (int i = 0; i < (len_endPara - selectionEndChar); i++)
					{
						newBuf[selectionStartChar + i] = buf_endPara[selectionEndChar + i];
					}
					newBuf[newBufLen] = '\0';
				}

				delete [] dataStart->textContent;
				dataStart->textContent = NULL;
				dataStart->textContent = newBuf;

				m_UpdateMergedParagraphAttrList(dataStart->attrList, dataEnd->attrList, selectionStartChar, selectionEndChar, 0);
				pango_attr_list_unref(dataStart->attrList);
				dataStart->attrList = NULL;
				dataStart->attrList = pango_attr_list_copy(m_pangoAttrList);

				if( m_singleLine->Renderer(selectionStartPara) != NULL )
				{
					CText* ctext = ((TextRenderer*)m_singleLine->Renderer(selectionStartPara))->GetText();
					if (ctext != NULL)
					{
						m_insertTextFlag = true;
						clutter_text_set_text(ctext->TextActor(), newBuf);
						m_insertTextFlag = false;

						clutter_text_set_attributes(ctext->TextActor(), dataStart->attrList);

						float height = (float)clutter_actor_get_height(CLUTTER_ACTOR(ctext->TextActor()));
						m_singleLine->SetItemSpace(selectionStartPara, height);
						((TextData*)m_singleLine->GetDataSource()->GetData(selectionStartPara))->height = height;
					}
				}
				m_singleLine->DeleteItem(selectionStartPara + 1, selectionParaCount);//m_cursorPositionParaIndex

				int size = m_singleLine->GetDataSource()->Size();
				for (int i = 0; i < size; i++)
				{
					((TextData*)m_singleLine->GetDataSource()->GetData(i))->index = i;
				}
				m_cursorPositionParaIndex = selectionStartPara;
				m_boundPositionParaIndex = selectionStartPara;
				m_cursorPositionCharIndex = selectionStartChar;
				m_boundPositionCharIndex = selectionStartChar;

				if( m_singleLine->Renderer(m_cursorPositionParaIndex) != NULL )
				{
					CText* ctext = ((TextRenderer*)m_singleLine->Renderer(m_cursorPositionParaIndex))->GetText();
					if (ctext != NULL)
					{
						TextData* cursorData = (TextData*)m_singleLine->GetDataSource()->GetData(m_cursorPositionParaIndex);
						int indexUTF8 = bytes_to_offset(cursorData->textContent, m_cursorPositionCharIndex);
						m_SetParagraphFocus(ctext->TextActor(), indexUTF8, indexUTF8);
					}
				}
			}

			int size = m_singleLine->GetDataSource()->Size();
			for (int i = 0; i < size; i++)
			{
				((TextData*)m_singleLine->GetDataSource()->GetData(i))->index = i;
			}
		}
#ifdef HAVE_ECORE_IMF
		if (m_imf_context && m_imf_context->imf_context != NULL)
		{
			ecore_imf_context_reset(m_imf_context->imf_context);
		}
#endif
	}

	gboolean CRichText::m_KeyPressEventSingleLine(ClutterActor *actor, ClutterEvent *event, gpointer user_data)
	{
		CRichText* pThis = (CRichText*)user_data;
		event->key.source = pThis->t_actor;
		clutter_do_event(event);
#ifdef HAVE_ECORE_IMF
		guint keyval = clutter_event_get_key_symbol(event);
		Ecore_IMF_Event inputMethodEvent;
		if (pThis->m_imf_context && pThis->m_imf_context->imf_context && 
			pThis->m_imf_context->GetEcoreKeyEvent(event, &inputMethodEvent))
		{
			if (ecore_imf_context_filter_event(pThis->m_imf_context->imf_context, 
												ECORE_IMF_EVENT_KEY_DOWN, &inputMethodEvent))
			{
				return CLUTTER_EVENT_STOP;
			}
		}
		switch(keyval)
		{
		case CLUTTER_KEY_Return:
			if (pThis->m_imf_context && pThis->m_imf_context->imf_context && pThis->m_imf_context->imf_enable)
			{
				pThis->m_imf_context->SetIMFFocused();
				return CLUTTER_EVENT_STOP;
			}
			break;
		case CLUTTER_KEY_Select:
			if (pThis->m_imf_context && pThis->m_imf_context->imf_context)
			{
				pThis->m_imf_context->IMEInputDone();
				return CLUTTER_EVENT_STOP;
			}
			break;
		case CLUTTER_KEY_Cancel:
			if (pThis->m_imf_context && pThis->m_imf_context->imf_context)
			{
				pThis->m_imf_context->IMEInputCancel();
				return CLUTTER_EVENT_STOP;
			}
			break;
		case CLUTTER_KEY_Clear:
			if (pThis->m_imf_context && pThis->m_imf_context->imf_context)
			{		
				pThis->SetText("");
				return CLUTTER_EVENT_STOP;
			}
			break;
		default:
			break;
		}
#endif
		return CLUTTER_EVENT_PROPAGATE;
	}

	gboolean CRichText::m_KeyReleaseEventSingleLine(ClutterActor *actor, ClutterEvent *event, gpointer user_data)
	{
		CRichText* pThis = (CRichText*)user_data;

		#ifdef HAVE_ECORE_IMF
		
		Ecore_IMF_Event inputMethodEvent;
		
		if (pThis && pThis->m_imf_context && pThis->m_imf_context->imf_context && 
			pThis->m_imf_context->GetEcoreKeyEvent(event, &inputMethodEvent))
		{
			if (ecore_imf_context_filter_event(pThis->m_imf_context->imf_context, 
												ECORE_IMF_EVENT_KEY_UP, &inputMethodEvent))
			{
				return CLUTTER_EVENT_STOP;
			}
		}
	
		#endif
		
		return CLUTTER_EVENT_PROPAGATE;
	}

	gboolean CRichText::m_MouseMoveEventSingleLine(ClutterActor *actor, ClutterEvent *event, gpointer user_data)
	{
		return CLUTTER_EVENT_PROPAGATE;
	}

	gboolean CRichText::m_MousePressEventSingleLine(ClutterActor *actor, ClutterEvent *event, gpointer user_data)
	{
#ifdef HAVE_ECORE_IMF
		CRichText* pThis = (CRichText*)user_data;

		if (pThis && pThis->m_imf_context && pThis->m_imf_context->imf_context && pThis->m_imf_context->focused)
		{
			ecore_imf_context_reset(pThis->m_imf_context->imf_context);
		}
#endif
		clutter_actor_grab_key_focus(actor);
		return CLUTTER_EVENT_PROPAGATE;
	}

	gboolean CRichText::m_MouseReleaseEventSingleLine(ClutterActor *actor, ClutterEvent *event, gpointer user_data)
	{
		return CLUTTER_EVENT_PROPAGATE;
	}

	void CRichText::m_DeleteTextEventSingleLine(ClutterText *self, gint start_pos, gint end_pos, gpointer user_data)
	{
		CRichText* pThis = (CRichText*)user_data;
		const char* buf = clutter_text_get_text(self);
		int len = strlen(buf);
		int offset = end_pos - start_pos;
		//just handle delete
		pThis->m_UpdateParagraphAttrList(pThis->m_textAttrList, end_pos, 0, offset, 0);
		pango_attr_list_unref(pThis->m_textAttrList);
		pThis->m_textAttrList = NULL;
		pThis->m_textAttrList = pango_attr_list_copy(pThis->m_pangoAttrList);
		clutter_text_set_attributes(self, pThis->m_textAttrList);
	}

	void CRichText::m_InsertTextEventSingleLine(ClutterText *self, gchar *new_text, gint new_text_length, gint position, gpointer user_data)
	{
		CRichText* pThis = (CRichText*)user_data;
		const char* buf = clutter_text_get_text(self);
		int len = strlen(buf);
		int cursorIndex = clutter_text_get_cursor_position(self);
		if (cursorIndex == -1)
		{
			cursorIndex = len;
		}

		// just handle insert
		pThis->m_UpdateParagraphAttrList(pThis->m_textAttrList, cursorIndex - new_text_length, new_text_length, 0, 0);
		if (new_text_length > 0 && pThis->m_pangoAttrListCopy != NULL && pThis->m_copyEventFlag)
		{
			pThis->m_InsertAttrList(pThis->m_pangoAttrList, pThis->m_pangoAttrListCopy, cursorIndex - new_text_length, new_text_length, true);
		}

		pango_attr_list_unref(pThis->m_textAttrList);
		pThis->m_textAttrList = NULL;
		pThis->m_textAttrList = pango_attr_list_copy(pThis->m_pangoAttrList);
		clutter_text_set_attributes(self, pThis->m_textAttrList);
	}

	bool CRichText::OnFocusIn(IWidgetExtension* pWindow)
	{
		if (m_hasFocusOutFlag)
		{
			if (m_focusChangeFlag)
			{
				m_focusChangeFlag = false;
				return true;
			}
		}
		else
		{
			m_focusChangeFlag = false;
		}

		if (m_focusWithOutGrab)
		{
			m_focusWithOutGrab = false;
		}

		if (!m_enableMultiLine)
		{
			if (m_text != NULL)
			{
				if (!clutter_actor_has_key_focus(CLUTTER_ACTOR(m_text->TextActor())))
				{
					m_focusWithOutGrab = true;
					clutter_actor_grab_key_focus(CLUTTER_ACTOR(m_text->TextActor()));
					return true;
				}
			}
		}
		else
		{
			if (m_singleLine->Renderer(m_cursorPositionParaIndex) != NULL)
			{
				CText* ctext = ((TextRenderer*)m_singleLine->Renderer(m_cursorPositionParaIndex))->GetText();
				if (ctext != NULL)
				{
					if (!clutter_actor_has_key_focus(CLUTTER_ACTOR(ctext->TextActor())))
					{
						m_focusWithOutGrab = true;
						clutter_actor_grab_key_focus(CLUTTER_ACTOR(ctext->TextActor()));
						return true;
					}
				}
			}
		}
		m_StateChangedListenerCallBack(IInputBox::T_INPUTBOX_STATE::INPUTBOX_STATE_FOCUS);
		H_LOG_TRACE(LOGGER, "CRichText::OnFocusIn() \n");
#ifdef HAVE_ECORE_IMF
		if (m_imf_context)
		{
			m_imf_context->SetIMFFocused();
		}
#endif

		return true;
	}

	bool CRichText::OnFocusOut(IWidgetExtension* pWindow)
	{
		m_hasFocusOutFlag = true;
		if (m_focusChangeFlag)
		{
			return true;
		}
		if (m_focusWithOutGrab)
		{
			return true;
		}
		m_StateChangedListenerCallBack(IInputBox::T_INPUTBOX_STATE::INPUTBOX_STATE_NORMAL);
		H_LOG_TRACE(LOGGER, "CRichText::OnFocusOut() \n");
#ifdef HAVE_ECORE_IMF
		if (m_imf_context)
		{
			m_imf_context->SetIMFFocusOut();
		}
#endif
		return true;
	}

	void CRichText::m_SetParagraphFocus(ClutterText* text, int cursorPos, int boundPos)
	{
		if (!clutter_actor_has_key_focus(CLUTTER_ACTOR(text)))
		{
			m_focusChangeFlag = true;
			clutter_actor_grab_key_focus(CLUTTER_ACTOR(text));
		}
		else
		{
			m_focusChangeFlag = false;
		}
		//clutter_actor_grab_key_focus(CLUTTER_ACTOR(text));
		clutter_text_set_cursor_position(text, cursorPos);
		clutter_text_set_selection_bound(text, boundPos);
	}

	void CRichText::m_StateChangedListenerCallBack(int keyval)
	{
		for (std::set<IRichTextListener *>::iterator iter = m_stateChangedlistener.begin(); iter != m_stateChangedlistener.end(); ++iter)
		{
			HALO_ASSERT(*iter != NULL);
			(*iter)->OnStateChanged(this, keyval);
		}
	}

	bool CRichText::AddStateChangedListener(IRichTextListener* listener)
	{
		HALO_ASSERT(listener != NULL);
		m_stateChangedlistener.insert(listener);
		return true;
	}

	bool CRichText::RemoveStateChangedListener(IRichTextListener* listener)
	{
		HALO_ASSERT(listener != NULL);
		m_stateChangedlistener.erase(listener);
		return true;
	}

#ifdef HAVE_ECORE_IMF
	CIMFContext::CIMFContext()
	{
		imf_context = NULL;
		m_ecore_evas = NULL;
		focused = false;
		preedit_len = 0;
		preedit_start = 0;
		imf_enable = false;		
	}

	CIMFContext::~CIMFContext(void)
	{
		
	}

	void CIMFContext::SetIMFFocusOut()
	{
		H_LOG_TRACE(LOGGER,"SetIMFFocusOut,imf_context="<<imf_context<<",focused="<<focused<<".\n");
		if (imf_context == NULL)
		{
			return;
		}
		if (focused == false)
		{
			return;
		}
	
		focused = false;
		ecore_imf_context_reset(imf_context);
		ecore_imf_context_focus_out(imf_context);
		ecore_imf_context_input_panel_hide(imf_context);
	}

	bool CIMFContext::GetEcoreKeyEvent(ClutterEvent *event,Ecore_IMF_Event *imf_event )
	{		
		ClutterKeyEvent key_event;
		Ecore_IMF_Event_Key_Down *ecore_key_down = NULL;
		Ecore_IMF_Event_Key_Up   *ecore_key_up = NULL;
		if (event == NULL)
		{
			return false;
		}
		if (event->type == CLUTTER_KEY_PRESS)
		{
			key_event = event->key;
			ecore_key_down = &(imf_event->key_down);
			ecore_key_down->keyname = XKeysymToString(XKeycodeToKeysym((Display *)ecore_x_display_get (),key_event.hardware_keycode, 0));

			ecore_key_down->modifiers = (Ecore_IMF_Keyboard_Modifiers)key_event.modifier_state;
			ecore_key_down->locks = (Ecore_IMF_Keyboard_Locks)0;
			ecore_key_down->key = ecore_key_down->keyname;
			ecore_key_down->string = "";
			ecore_key_down->compose = "";
			ecore_key_down->timestamp = key_event.time;

			H_LOG_TRACE(LOGGER, "press_key_name="<<ecore_key_down->keyname<<".\n");
			if (!strcmp (ecore_key_down->keyname, "XF86Back"))
			{
				return false;
			}
		}
		else if (event->type == CLUTTER_KEY_RELEASE)
		{
			key_event = event->key;
			ecore_key_up = &(imf_event->key_up);
			ecore_key_up->keyname = XKeysymToString(XKeycodeToKeysym((Display *)ecore_x_display_get (),key_event.hardware_keycode, 0));
			ecore_key_up->modifiers = (Ecore_IMF_Keyboard_Modifiers)key_event.modifier_state;
			ecore_key_up->locks = (Ecore_IMF_Keyboard_Locks)0;
			ecore_key_up->key = ecore_key_up->keyname;
			ecore_key_up->string = "";
			ecore_key_up->compose = "";
			ecore_key_up->timestamp = key_event.time;
			H_LOG_TRACE(LOGGER, "release_key_name="<<ecore_key_up->keyname<<".\n");

			if (!strcmp (ecore_key_up->keyname, "XF86Back"))
			{
				return false;
			}
		}
		else
		{
			return false;
		}

		return true;
	}



	void CIMFContext::DestroyIMFContext(CIMFContext *cimf_context)
	{
		if (cimf_context->m_ecore_evas != NULL)
		{
			ecore_evas_free(cimf_context->m_ecore_evas);
		}
		if (cimf_context->imf_context != NULL)
		{
			ecore_imf_context_del(cimf_context->imf_context);
		}
		ecore_imf_shutdown();
		//ecore_evas_shutdown();
	}
	void CIMFContext::SetIMFFocused()
	{
		if (imf_enable == false)
		{
			return;
		}
		
		if (imf_context == NULL)
		{
			return;
		}
		if (focused)
		{
			return;
		}
		focused = true;
		ecore_imf_context_focus_out(imf_context);
		ecore_imf_context_focus_in(imf_context);
		ecore_imf_context_input_panel_show(imf_context);
	}
	void CIMFContext::IMEInputDone()
	{
		;
		
	}


	void CIMFContext::IMEInputCancel()
	{
		;
	}
	Ecore_IMF_Context * CIMFContext::CreateIMFContext(CRichText *richtext)
	{
		Ecore_Evas	 *ee;
#if 0		
		if (!ecore_evas_init())
		{
			return NULL;
		}
#endif		
		ecore_imf_init();

		ee = ecore_evas_new(NULL, 0, 0, 10, 10, NULL);
		if (!ee)
		{
			return NULL;
		}
		m_ecore_evas = ee;
		const char *defaultContextID = ecore_imf_context_default_id_get();
		Evas   *evas = ecore_evas_get(ee);
		if (NULL == defaultContextID)
		{
			return NULL;
		}
	
		Ecore_IMF_Context *imf_ctx = ecore_imf_context_add(defaultContextID);
		if (NULL == imf_ctx)
		{
			return NULL;
		}
		ecore_imf_context_client_window_set(imf_ctx, (void *)ecore_evas_window_get(ee));
		ecore_imf_context_client_canvas_set(imf_ctx, evas);
		ecore_imf_context_event_callback_add(imf_ctx, ECORE_IMF_CALLBACK_PREEDIT_CHANGED, m_OnPreeditChanged, richtext);
		ecore_imf_context_event_callback_add(imf_ctx, ECORE_IMF_CALLBACK_COMMIT, m_OnTextCommit, richtext);
	
		ecore_imf_context_input_panel_event_callback_add(imf_ctx, ECORE_IMF_INPUT_PANEL_STATE_EVENT, 
																					m_OnStateChanged, richtext);
		ecore_imf_context_input_panel_event_callback_add(imf_ctx,ECORE_IMF_INPUT_PANEL_GEOMETRY_EVENT,
																			m_OnIMEGeometryChanged,richtext);
		imf_context = imf_ctx;
		return imf_ctx;
	}
	


	void CIMFContext::m_OnTextCommit(void *data, Ecore_IMF_Context *ctx, void *event_info)
	{
		char *commit_str = (char *)event_info;
		CRichText* pThis = (CRichText *)data;
		int len = strlen(commit_str);
		if (data == NULL)
		{
			return;
		}
		if (pThis->GetIMFContext() == NULL)
		{
			return;
		}
		if (pThis->GetIMFContext()->imf_context == NULL)
		{
			return;
		}
		H_LOG_TRACE(LOGGER, "m_OnTextCommit,preedit_len="<<pThis->GetIMFContext()->preedit_len<<".\n");
		H_LOG_TRACE(LOGGER, "m_OnTextCommit,preedit_start="<<pThis->GetIMFContext()->preedit_start<<".\n");
		H_LOG_TRACE(LOGGER, "m_OnTextCommit,commit_str="<<commit_str<<".\n");
		if (pThis->GetIMFContext()->preedit_len > 0)
		{
			//setSelection API can del the pre_compsing text when insert text.
			pThis->SetSelection(pThis->GetIMFContext()->preedit_start, 
								pThis->GetIMFContext()->preedit_start+pThis->GetIMFContext()->preedit_len);
		}
		pThis->GetIMFContext()->preedit_start = 0;
		pThis->GetIMFContext()->preedit_len = 0;
		pThis->InsertText(commit_str);
		pThis->ResetCursorPosition();
	}

	void CIMFContext::m_OnPreeditChanged(void *data, Ecore_IMF_Context *ctx, void *event_info)
	{
		char *preedit_string;
		int cursor_pos;
		Eina_List *attrs = NULL;
		CRichText* pThis = (CRichText *)data;
		if (data == NULL)
		{
			return;
		}
		if (pThis->GetIMFContext() == NULL)
		{
			return;
		}
		if (pThis->GetIMFContext()->imf_context == NULL)
		{
			return;
		}		
		ecore_imf_context_preedit_string_with_attributes_get(ctx, &preedit_string, &attrs, &cursor_pos);
		if (pThis->GetIMFContext()->preedit_len > 0)
		{
			pThis->SetSelection(pThis->GetIMFContext()->preedit_start, 
										pThis->GetIMFContext()->preedit_start+pThis->GetIMFContext()->preedit_len);
		}
		pThis->GetIMFContext()->preedit_start = pThis->CursorPosition();
		if (pThis->IsMultiLineEnabled())
		{
			pThis->GetIMFContext()->preedit_len = strlen(preedit_string);
		}
		else
		{
			pThis->GetIMFContext()->preedit_len = g_utf8_strlen(preedit_string,-1);
		}
		pThis->InsertText(preedit_string);
		free(preedit_string);
		preedit_string = NULL;
	}

	void CIMFContext::m_OnStateChanged(void* data, Ecore_IMF_Context* imf_ctx, int state)
	{
		if (data == NULL)
		{
			return;
		}
		H_LOG_TRACE(LOGGER, "IME state change to "<<state<<". \n");

		CRichText* pThis = (CRichText *)data;
		if (pThis->GetIMFContext() == NULL)
		{
			return;
		}
		if (pThis->GetIMFContext()->imf_context == NULL)
		{
			return;
		}		
		if (state == ECORE_IMF_INPUT_PANEL_STATE_HIDE)
		{
			//pThis->GetIMFContext()->focused = false;
			
		}
		else if (state == ECORE_IMF_INPUT_PANEL_STATE_SHOW)
		{
			;
		}
	}


	void CIMFContext::m_OnIMEGeometryChanged(void* data, Ecore_IMF_Context* imf_ctx, int value)
	{
		int x,y,w,h;
		if (data == NULL)
		{
			return;
		}

		CRichText* pThis = (CRichText *)data;
		if (pThis->GetIMFContext() == NULL)
		{
			return;
		}
		if (pThis->GetIMFContext()->imf_context == NULL)
		{
			return;
		}
		ecore_imf_context_input_panel_geometry_get(imf_ctx, &x,&y,&w,&h);
	}
	CIMFContext *CRichText::GetIMFContext()
	{
		return m_imf_context;
	}
	void CRichText::SetIMEData(const char *imdata)
	{
		if (m_imf_context == NULL)
		{
			return;
		}
		if (m_imf_context->imf_context && imdata)
		{
			ecore_imf_context_input_panel_imdata_set(m_imf_context->imf_context, imdata, strlen(imdata)+1);
		}
	}

	void CRichText::GetIMEData(void *data, void *len)
	{
		if (m_imf_context == NULL)
		{
			return;
		}
		if (m_imf_context->imf_context)
		{
			ecore_imf_context_input_panel_imdata_get(m_imf_context->imf_context,data,(int *)len);
		}
		
	}
	void CRichText::EnableIMFOnFocus(bool is_enable)
	{
		if (m_imf_context == NULL)
		{
			return;
			
		}
		m_imf_context->CreateIMFContext(this);
		m_imf_context->imf_enable = is_enable;
	}

	bool CRichText::IsIMFEnableOnFocus()
	{
		if (m_imf_context == NULL)
		{
			return false;
		}
	
		return m_imf_context->imf_enable;
	}

	void CRichText::ShowIMFContext()
	{
		if (m_imf_context == NULL)
		{
			return;
		}

		if (m_imf_context->imf_context == NULL)
		{
			return;
		}

		ecore_imf_context_input_panel_show(m_imf_context->imf_context);
	}

	void CRichText::HideIMFContext()
	{
		if (m_imf_context == NULL)
		{
			return;
		}

		if (m_imf_context->imf_context == NULL)
		{
			return;
		}

		ecore_imf_context_input_panel_hide(m_imf_context->imf_context);
	}

	void CRichText::FocusInIMFContext()
	{
		if (m_imf_context == NULL)
		{
			return;
		}

		if (m_imf_context->imf_context == NULL)
		{
			m_imf_context->CreateIMFContext(this);
		}
		m_imf_context->focused = true;
		ecore_imf_context_focus_in(m_imf_context->imf_context);
	}

	void CRichText::FocusOutIMFContext()
	{
		if (m_imf_context == NULL)
		{
			return;
		}

		if (m_imf_context->imf_context == NULL)
		{
			return;
		}
		m_imf_context->focused = false;
		ecore_imf_context_focus_out(m_imf_context->imf_context);		
	}
#endif
	/* namespace UIElements */

}

