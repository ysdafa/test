#include "Halo1_0.h"

namespace HALO
{
	static HALO::util::Logger LOGGER("CScroll");
	static const char *THUMB_DRAG_ACTION_NAME = "THUMB_DRAG_ACTION";
	static const char* TRACK_CLICK_ACTION_NAME = "TRACK_CLICK_ACTION";

	const static int INVALIDE_VALUE = -1;

	void static FactorApproximateValue(float &factor)
	{
		HALO_ASSERT(factor >= 0);
		if (factor < 0.005)
		{
			factor = 0;
		}
		else if (factor > 0.995)
		{
			factor = 1.0;
		}
	}

	gboolean CScroll::m_PreButtonLongPress(gpointer data)
	{
		CScroll* scroll = reinterpret_cast<CScroll *>(data);
		scroll->SetValue(scroll->m_currentValue - scroll->m_moveStep);

		return true;
	}

	gboolean CScroll::m_NextButtonLongPress(gpointer data)
	{
		CScroll* scroll = reinterpret_cast<CScroll *>(data);
		scroll->SetValue(scroll->m_currentValue + scroll->m_moveStep);

		return true;
	}

	void CScroll::m_OnPreButtonClicked(ClutterClickAction *action,
		ClutterActor       *actor,
		CScroll *scroll)
	{
		scroll->SetValue(scroll->m_currentValue - scroll->m_moveStep);
	}

	void CScroll::m_OnNextButtonClicked(ClutterClickAction *action,
		ClutterActor       *actor,
		CScroll *scroll)
	{
		scroll->SetValue(scroll->m_currentValue + scroll->m_moveStep);
	}

	void CScroll::m_OnThumbDragMotion(ClutterDragAction   *action,
		ClutterActor        *actor,
		gfloat				delta_x,
		gfloat				delta_y,
		CScroll *scroll)
	{
		scroll->m_ThumbMoved();
	}

	gboolean CScroll::m_OnPreButtonLongPress(ClutterClickAction   *action,
		ClutterActor         *actor,
		ClutterLongPressState state,
		CScroll *scroll)
	{
		switch (state)
		{
		case CLUTTER_LONG_PRESS_QUERY:
			break;
		case CLUTTER_LONG_PRESS_ACTIVATE:
			if (scroll->m_longPressTimerId > 0)
			{
				g_source_remove(scroll->m_longPressTimerId);
				scroll->m_longPressTimerId = 0;
			}
			scroll->m_longPressTimerId = g_timeout_add(scroll->m_timeInterval, (GSourceFunc)m_PreButtonLongPress, scroll);
			break;
		case CLUTTER_LONG_PRESS_CANCEL:
			break;
		}

		return TRUE;
	}

	gboolean CScroll::m_OnNextButtonLongPress(ClutterClickAction   *action,
		ClutterActor         *actor,
		ClutterLongPressState state,
		CScroll *scroll)
	{
		switch (state)
		{
		case CLUTTER_LONG_PRESS_QUERY:
			break;
		case CLUTTER_LONG_PRESS_ACTIVATE:
			if (scroll->m_longPressTimerId > 0)
			{
				g_source_remove(scroll->m_longPressTimerId);
				scroll->m_longPressTimerId = 0;
			}
			scroll->m_longPressTimerId = g_timeout_add(scroll->m_timeInterval, (GSourceFunc)m_NextButtonLongPress, scroll);
			break;
		case CLUTTER_LONG_PRESS_CANCEL:
			break;
		}

		return TRUE;
	}

	void CScroll::m_OnScrollClick(ClutterClickAction *action, ClutterActor *actor, CScroll *scroll)
	{
		gfloat pressX, pressY;
		clutter_click_action_get_coords(action, &pressX, &pressY);

		pressX = scroll->t_MultiResolutionConvert1920(pressX);			// convert to 1920 resolution coordinate
		pressY = scroll->t_MultiResolutionConvert1920(pressY);

		float curX = 0;
		float curY = 0;
		scroll->GetPosition(curX, curY);

		float width = 0;
		float height = 0;
		scroll->GetSize(width, height);

		float preArrowWidth = 0;
		float preArrowHeight = 0;
		scroll->GetPreviousArrowSize(preArrowWidth, preArrowHeight);

		float nextArrowWidth = 0;
		float nextArrowHeight = 0;
		scroll->GetNextArrowSize(nextArrowWidth, nextArrowHeight);

		float thumbWidth = 0;
		float thumbHeight = 0;
		scroll->GetPointingNormalThumbSize(thumbWidth, thumbHeight);

		float factor = 0;
		if (scroll->m_direction == TYPE_HORIZONTAL)
		{
			if (pressX < curX + preArrowWidth + thumbWidth / 2)
			{
				factor = 0;
			}
			else if (pressX > curX + (width - thumbWidth / 2 - nextArrowWidth))
			{
				factor = 1;
			}
			else
			{
				factor = (pressX - curX - preArrowWidth - thumbWidth / 2) / (width - preArrowWidth - nextArrowWidth - thumbWidth);
			}
		}
		else
		{
			if (pressY < curY + preArrowHeight + thumbHeight / 2)
			{
				factor = 0;
			}
			else if (pressY > curY + (height - thumbHeight / 2 - nextArrowHeight))
			{
				factor = 1;
			}
			else
			{
				factor = (pressY - curY - preArrowHeight - thumbHeight / 2) / (height - preArrowHeight - nextArrowHeight - thumbHeight);
			}
		}

		int minValue = scroll->MinValue();
		int maxValue = scroll->MaxValue();

		if (scroll->Orientation(true) == ORIENTATION_LEFT_TO_RIGHT)
		{
			scroll->m_currentValue = minValue + static_cast<int>(factor * (maxValue - minValue));
		}
		else if (scroll->Orientation(true) == ORIENTATION_RIGHT_TO_LEFT)
		{
			scroll->m_currentValue = minValue + static_cast<int>((1 - factor) * (maxValue - minValue));
		}
		else
		{
			HALO_ASSERT(0);
		}

		//ClutterActor* thumb = scroll->m_thumbActor->Actor();
		//ClutterActor* thumb = scroll->m_thumbImage->Actor();
		CWidgetEx* thumb = dynamic_cast<CWidgetEx *>(scroll->m_thumbImage);
		if (thumb == NULL)
		{
			HALO_EXCEPTION(false, "m_thumbImage is not CWidgetEx type.");
			return;
		}
		if (scroll->m_direction == TYPE_HORIZONTAL)
		{
			// to let thumb bar seems seamless with previous/next arrow button
			if (fabs(factor) < 0.0001)
			{
				//clutter_actor_set_x(thumb, nextArrowWidth);
				thumb->setX(0);
			}
			else if (fabs(factor - 1.0) < 0.0001)
			{
				//clutter_actor_set_x(thumb, width - nextArrowWidth - thumbWidth);
				thumb->setX(width - thumbWidth);
			}
			else
			{
				float x = 0;
				if (scroll->Orientation(true) == ORIENTATION_LEFT_TO_RIGHT)
				{
					// re calculate factor, to let thumb bar seems seamless with previous/next arrow button
					x = factor * (width - preArrowWidth - nextArrowWidth - thumbWidth);
				}
				else if (scroll->Orientation(true) == ORIENTATION_RIGHT_TO_LEFT)
				{
					//thumb->setX(pressX);
					x = (1 - factor) * (width - thumbWidth);
				}
				//clutter_actor_set_x(thumb, preArrowWidth + x);
				thumb->setX(x);
			}
		}
		else
		{
			// to let thumb bar seems seamless with previous/next arrow button
			if (fabs(factor) < 0.0001)
			{
				//clutter_actor_set_y(thumb, nextArrowHeight);
				thumb->setY(0);
			}
			else if (fabs(factor - 1.0) < 0.0001)
			{
				//clutter_actor_set_y(thumb, height - nextArrowHeight - thumbHeight);
				thumb->setY(height - thumbHeight);
			}
			else
			{
				float y = factor * (height - preArrowHeight - nextArrowHeight - thumbHeight);
				//clutter_actor_set_y(thumb, preArrowHeight + y);
				thumb->setY(y);
			}
		}

		// call back listeners
		for (std::set<IScrollListener *>::iterator iter = scroll->m_listenerSet.begin(); iter != scroll->m_listenerSet.end(); ++iter)
		{
			HALO_ASSERT(*iter != NULL);
			(*iter)->OnValueChanged(scroll, EValueChangedType::E_TYPE_CLICK);
		}
	}

	CScroll::CScroll() : m_minValue(INVALIDE_VALUE),
		m_maxValue(INVALIDE_VALUE),
		m_currentValue(INVALIDE_VALUE),
		m_direction(TYPE_HORIZONTAL),
		m_active(false),
		m_trackAreaActor(NULL),
		m_trackTopActor(NULL),
		m_trackShadowActor(NULL),
		m_normalTrackTopHeight(0),
		m_rolloverTopTrackHeight(0),
		m_bottomTrackHeight(0),
		//m_thumbActor(NULL),
		//m_thumbImageWidget(NULL),
		m_thumbImage(NULL),
		m_pointingNormalThumbImageWidth(0),
		m_pointingNormalThumbImageHeight(0),
		m_pointingOverThumbImageWidth(0),
		m_pointingOverThumbImageHeight(0),
		m_pointingFocusThumbImageWidth(0),
		m_pointingFocusThumbImageHeight(0),
		m_previousButton(NULL),
		m_nextButton(NULL),
		m_timeInterval(250),
		m_moveStep(1),
		m_longPressTimerId(0)
	{
		H_LOG_TRACE(LOGGER, "CScroll::CScroll()");
		memset(&m_trackTopActor, 0, sizeof(m_trackTopActor));
		memset(&m_bottomTrackColor, 0, sizeof(m_bottomTrackColor));
	}

	CScroll::~CScroll()
	{
		H_LOG_TRACE(LOGGER, "CScroll::~CScroll()");

		m_thumbImage->RemoveMouseListener(this);
		delete m_thumbImage;
		m_thumbImage = NULL;

		m_trackAreaActor->RemoveMouseListener(this);
		delete m_trackAreaActor;
		m_trackAreaActor = NULL;


		// for buttons
		m_previousButton->RemoveMouseListener(this);
		m_nextButton->RemoveMouseListener(this);

		delete m_previousButton;
		m_previousButton = NULL;

		delete m_nextButton;
		m_nextButton = NULL;
	}

	bool CScroll::Initialize(IActor* parent, float width, float height, EDirectionType direction)
	{
		H_LOG_TRACE(LOGGER, "CScroll::Initialize(" << parent << "(IActor *), " << width << ", " << height << ", " << direction << ")");

		Widget* widget = dynamic_cast<Widget *>(parent);
		return Initialize(widget, width, height, direction);
	}

	bool CScroll::Initialize(Widget* parent, float width, float height, EDirectionType direction)
	{
		H_LOG_TRACE(LOGGER, "CScroll::Initialize(" << parent << "(Widget *), " << width << ", " << height << ", " << direction << ")");

		//ASSERT(parent != NULL);
		CActor::Initialize(parent, width, height);
		CActor::SetOrientation(ORIENTATION_LEFT_TO_RIGHT);
		m_direction = direction;

		// background image fills this actor region
		Widget *widget = dynamic_cast<Widget*>(this);
		if (widget != NULL)
		{
			if (m_direction == TYPE_HORIZONTAL)
			{
				m_normalTrackTopHeight = height - m_bottomTrackHeight;

				m_trackAreaActor = ICompositeImage::CreateInstance(widget, width, height);
				//m_trackAreaActor = IActor::CreateInstance(widget, width, height);
				m_trackTopActor = IActor::CreateInstance(m_trackAreaActor, width, m_normalTrackTopHeight);
				m_trackShadowActor = IActor::CreateInstance(m_trackAreaActor, width, m_bottomTrackHeight);
				if (m_trackAreaActor == NULL || m_trackTopActor == NULL || m_trackShadowActor == NULL)
				{
					return false;
				}

				m_trackAreaActor->SetPosition(0, 0);
				m_trackTopActor->SetPosition(0, 0);
				m_trackShadowActor->SetPosition(0, m_normalTrackTopHeight);

			}
			else
			{
				m_normalTrackTopHeight = width - m_bottomTrackHeight;

				m_trackAreaActor = ICompositeImage::CreateInstance(widget, width, height);
				//m_trackAreaActor = IActor::CreateInstance(widget, width, height);
				m_trackTopActor = IActor::CreateInstance(m_trackAreaActor, m_normalTrackTopHeight, height);
				m_trackShadowActor = IActor::CreateInstance(m_trackAreaActor, m_bottomTrackHeight, height);
				if (m_trackAreaActor == NULL || m_trackTopActor == NULL || m_trackShadowActor == NULL)
				{
					return false;
				}

				m_trackAreaActor->SetPosition(0, 0);
				m_trackTopActor->SetPosition(0, 0);
				m_trackShadowActor->SetPosition(m_normalTrackTopHeight, 0);
			}

			//m_thumbActor = IActor::CreateInstance(widget, width, height);
			//if (m_thumbActor == NULL)
			//{
			//	return false;
			//}
			//m_thumbImageWidget = new ImageWidget(0.0f, 0.0f, dynamic_cast<Widget*>(m_thumbActor), nullptr);
			//m_thumbImageWidget->setAsyncLoading(false);
			//m_thumbImageWidget->show();
			m_thumbImage = ICompositeImage::CreateInstance(widget, 0.0f, 0.0f);

			// for buttons
			m_previousButton = IButton::CreateInstance(this, width, height);
			m_nextButton = IButton::CreateInstance(this, width, height);

			// For passing prevent
			if (m_previousButton == NULL || m_nextButton == NULL)
			{
				return false;
			}

			m_previousButton->Resize(0, 0);
			m_nextButton->Resize(0, 0);
			m_previousButton->AddMouseListener(this);
			m_nextButton->AddMouseListener(this);
		}

		ClutterActor* trackAreaActor = m_trackAreaActor->Actor();
		ClutterActor* topTrackActor = m_trackTopActor->Actor();
		ClutterActor* bottomTrackActor = m_trackShadowActor->Actor();
		ClutterActor* thumbActor = m_thumbImage->Actor();

		ClutterActor* prevButtonActor = m_previousButton->Actor();
		ClutterActor* nextButtonActor = m_nextButton->Actor();

		if (m_direction == TYPE_HORIZONTAL)
		{
			clutter_actor_add_constraint(thumbActor,
				clutter_align_constraint_new(trackAreaActor, CLUTTER_ALIGN_Y_AXIS, 0.5));

			// for buttons
			clutter_actor_add_constraint(prevButtonActor,
				clutter_align_constraint_new(trackAreaActor, CLUTTER_ALIGN_Y_AXIS, 0.5));
			clutter_actor_add_constraint(nextButtonActor,
				clutter_align_constraint_new(trackAreaActor, CLUTTER_ALIGN_Y_AXIS, 0.5));
		}
		else
		{
			clutter_actor_add_constraint(thumbActor,
				clutter_align_constraint_new(trackAreaActor, CLUTTER_ALIGN_X_AXIS, 0.5));

			clutter_actor_add_constraint(prevButtonActor,
				clutter_align_constraint_new(trackAreaActor, CLUTTER_ALIGN_X_AXIS, 0.5));
			clutter_actor_add_constraint(nextButtonActor,
				clutter_align_constraint_new(trackAreaActor, CLUTTER_ALIGN_X_AXIS, 0.5));
		}

		clutter_actor_set_x(prevButtonActor, 0);		// others will be set in m_StateChanged()

		// let t_actor to be transparent
		ClutterColor transparentColor;
		clutter_color_init(&transparentColor, 0, 0, 0, 0);
		clutter_actor_set_background_color(t_actor, &transparentColor);				// need it.
		clutter_actor_set_background_color(topTrackActor, &transparentColor);		// need it.
		clutter_actor_set_background_color(bottomTrackActor, &transparentColor);	// need it.

		return false;
	}

	void CScroll::SetMinValue(int minValue)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetMinValue(" << minValue << ")");

		HALO_ASSERT(minValue >= 0);

		m_minValue = minValue;
		m_ValueChanged();
	}

	int CScroll::MinValue(void) const
	{
		H_LOG_TRACE(LOGGER, "CScroll::MinValue()");

		return m_minValue;
	}

	void CScroll::SetMaxValue(int maxValue)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetMaxValue(" << maxValue << ")");

		HALO_ASSERT(maxValue > 0);

		m_maxValue = maxValue;
		m_ValueChanged();
	}

	int CScroll::MaxValue(void) const
	{
		H_LOG_TRACE(LOGGER, "CScroll::MaxValue()");

		return m_maxValue;
	}

	void CScroll::SetValue(int value)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetCurrentValue(" << value << ")");
		if (m_currentValue == value)
		{
			return;
		}

		m_currentValue = value;
		m_ValueChanged();
	}

	int CScroll::Value(void) const
	{
		H_LOG_TRACE(LOGGER, "CScroll::CurrentValue()");

		return m_currentValue;
	}

	void CScroll::SetPreviousArrowImage(IButton::EButtonState state, const std::string& imagePath)
	{
		H_LOG_TRACE(LOGGER, "CScroll::CScroll(" << state << ", " << imagePath << ")");

		m_previousButton->SetBackgroundImage(state, imagePath);
	}

	void CScroll::SetNextArrowImage(IButton::EButtonState state, const std::string& imagePath)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetNextArrowImage(" << state << ", " << imagePath << ")");

		m_nextButton->SetBackgroundImage(state, imagePath);
	}

	void CScroll::SetPreviousArrowSize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetPreviousArrowSize(" << width << ", " << height << ")");

		m_previousButton->Resize(width, height);
		m_SetDragArea();
	}

	void CScroll::GetPreviousArrowSize(float &width, float &height)
	{
		H_LOG_TRACE(LOGGER, "CScroll::GetPreviousArrowSize()");

		m_previousButton->GetSize(width, height);
	}

	void CScroll::SetNextArrowSize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetNextArrowSize(" << width << ", " << height << ")");

		m_nextButton->Resize(width, height);
		m_SetDragArea();
	}

	void CScroll::GetNextArrowSize(float &width, float &height)
	{
		H_LOG_TRACE(LOGGER, "CScroll::GetNextArrowSize()");

		m_nextButton->GetSize(width, height);
	}

	void CScroll::m_ValueChanged()
	{
		if (m_minValue == INVALIDE_VALUE || m_currentValue == INVALIDE_VALUE || m_maxValue == INVALIDE_VALUE)
		{
			return;
		}
		HALO_ASSERT(m_currentValue >= 0);
		HALO_ASSERT(m_currentValue >= m_minValue);
		HALO_ASSERT(m_maxValue >= m_currentValue);
		HALO_ASSERT(m_maxValue > m_minValue);

		float factor = static_cast<float>(m_currentValue - m_minValue) / (m_maxValue - m_minValue);
		//ClutterActor* thumb = m_thumbImage->Actor();
		CWidgetEx *thumb = dynamic_cast<CWidgetEx *>(m_thumbImage);
		if (thumb == nullptr)
		{
			return;
		}

		// 1, move thumb
		if (m_direction == TYPE_HORIZONTAL)
		{
			//gfloat validWidth = clutter_actor_get_width(t_actor) - clutter_actor_get_width(m_previousButton->Actor()) - m_pointingNormalThumbImageWidth - clutter_actor_get_width(m_nextButton->Actor());
			gfloat validWidth = this->getWidth() - t_MultiResolutionConvert1920(m_pointingNormalThumbImageWidth);

			EOrientation orientation = this->Orientation(true);
			HALO_ASSERT(orientation != ORIENTATION_REFER_TO_PARENT);

			float x = 0;
			if (orientation == ORIENTATION_LEFT_TO_RIGHT)
			{
				x = factor * validWidth;
				//clutter_actor_set_x(thumb, x + clutter_actor_get_width(m_previousButton->Actor()));
			}
			else if (orientation == ORIENTATION_RIGHT_TO_LEFT)
			{
				x = (1 - factor) * validWidth;
				//clutter_actor_set_x(thumb, x + clutter_actor_get_width(m_previousButton->Actor()));
			}
			thumb->setX(x);
		}
		else
		{
			//float factor = static_cast<float>(m_currentValue)/(m_maxValue - m_minValue);
			//float y = factor * (clutter_actor_get_height(t_actor) - clutter_actor_get_height(m_previousButton->Actor()) - m_pointingNormalThumbImageHeight - clutter_actor_get_height(m_nextButton->Actor()));
			//clutter_actor_set_y(thumb, y + clutter_actor_get_height(m_previousButton->Actor()));

			float y = factor * (this->getHeight() - t_MultiResolutionConvert1920(m_pointingNormalThumbImageHeight));
			thumb->setY(y);
		}

		// 2, update listeners
		for (std::set<IScrollListener *>::iterator iter = m_listenerSet.begin(); iter != m_listenerSet.end(); ++iter)
		{
			HALO_ASSERT(*iter != NULL);
			(*iter)->OnValueChanged(this, EValueChangedType::E_TYPE_SETVALUE);
		}
	}

	void CScroll::m_ThumbMoved()
	{
		//ClutterActor* thumb = m_thumbImage->Actor();
		CWidgetEx *thumb = dynamic_cast<CWidgetEx *>(m_thumbImage);
		if (thumb == nullptr)
		{
			HALO_EXCEPTION(false, "Can not convert m_thumbImage to CWidgetEx");
			return;
		}
		float factor = 0;
		if (m_direction == TYPE_HORIZONTAL)
		{
			//float currentX = clutter_actor_get_x(thumb->Actor()) - clutter_actor_get_width(m_previousButton->Actor());
			//float trackValidLength = (clutter_actor_get_width(t_actor) - clutter_actor_get_width(m_previousButton->Actor()) - m_pointingNormalThumbImageWidth - clutter_actor_get_width(m_nextButton->Actor()));

			//float currentX = thumb->getX();	// TODO: this return m_origY, which will cause bug: thumb already moved, but m_origY not updated
			float currentX = t_MultiResolutionConvert1920(clutter_actor_get_x(thumb->Actor()));
			float trackValidLength = this->getWidth() - m_pointingNormalThumbImageWidth;
			if (this->Orientation(true) == ORIENTATION_LEFT_TO_RIGHT)
			{
				factor = currentX / trackValidLength;
			}
			else if (this->Orientation(true) == ORIENTATION_RIGHT_TO_LEFT)
			{
				factor = 1 - currentX / trackValidLength;
			}
			else
			{
				HALO_ASSERT(0);
			}
		}
		else
		{
			//float curY = clutter_actor_get_y(thumb) - clutter_actor_get_height(m_previousButton->Actor());
			//float trackValidLength = (clutter_actor_get_height(t_actor) - clutter_actor_get_height(m_previousButton->Actor()) - m_pointingNormalThumbImageHeight - clutter_actor_get_height(m_nextButton->Actor()));

			//float curY = thumb->getY();   // TODO: this return m_origY, which will cause bug: thumb already moved, but m_origY not updated
			float curY = t_MultiResolutionConvert1920(clutter_actor_get_y(thumb->Actor()));
			float trackValidLength = this->getHeight() - m_pointingNormalThumbImageHeight;

			factor = curY / trackValidLength;
		}

		factor = HALO_MIN(factor, 1.0);
		factor = HALO_MAX(factor, 0);
		FactorApproximateValue(factor);

		m_currentValue = m_minValue + static_cast<int>(factor * (m_maxValue - m_minValue));

		for (std::set<IScrollListener *>::iterator iter = m_listenerSet.begin(); iter != m_listenerSet.end(); ++iter)
		{
			HALO_ASSERT(*iter != NULL);
			(*iter)->OnValueChanged(this, EValueChangedType::E_TYPE_DRAG);
		}
	}

	void CScroll::m_SetDragArea()
	{
		if (!m_active)
		{
			return;
		}
		ClutterActor* trackActor = m_trackAreaActor->Actor();
		ClutterActor* thumbActor = m_thumbImage->Actor();
		ClutterActor* prevActor = m_previousButton->Actor();
		ClutterActor* nextActor = m_nextButton->Actor();

		// get drag support for thumb
		ClutterAction* thumbDragAction = clutter_actor_get_action(thumbActor, THUMB_DRAG_ACTION_NAME);
		HALO_ASSERT(thumbDragAction != NULL);

		if (m_direction == TYPE_HORIZONTAL)
		{
			//clutter_actor_set_x(prevActor, 0);
			//float factor = static_cast<float>(m_currentValue - m_minValue) / (m_maxValue - m_minValue);
			float width = clutter_actor_get_width(t_actor);
			//float x = factor * (width - clutter_actor_get_width(m_previousButton->Actor()) - m_pointingNormalThumbImageWidth - clutter_actor_get_width(m_nextButton->Actor()));
			//clutter_actor_set_x(thumbActor, x + clutter_actor_get_width(m_previousButton->Actor()));
			//clutter_actor_set_x(nextActor, clutter_actor_get_width(trackActor) - clutter_actor_get_width(nextActor));

			// set drag action attributes
			clutter_drag_action_set_drag_axis(CLUTTER_DRAG_ACTION(thumbDragAction), CLUTTER_DRAG_X_AXIS);
			ClutterRect rect;
			rect.origin.x = clutter_actor_get_width(prevActor);
			rect.origin.y = 0;
			//rect.size.width = width - m_pointingNormalThumbImageWidth - clutter_actor_get_width(prevActor) - clutter_actor_get_width(nextActor);
			rect.size.width = width - t_1920ConvertMultiResolution(m_pointingNormalThumbImageWidth);
			rect.size.height = clutter_actor_get_height(trackActor);
			clutter_drag_action_set_drag_area(CLUTTER_DRAG_ACTION(thumbDragAction), &rect);
		}
		else
		{
			//clutter_actor_set_x(prevActor, 0);
			//float factor = static_cast<float>(m_currentValue - m_minValue) / (m_maxValue - m_minValue);
			float height = clutter_actor_get_height(t_actor);
			//float y = factor * (height - clutter_actor_get_height(m_previousButton->Actor()) - m_pointingNormalThumbImageHeight - clutter_actor_get_height(m_nextButton->Actor()));
			//clutter_actor_set_y(thumbActor, y + clutter_actor_get_height(m_previousButton->Actor()));
			//clutter_actor_set_y(nextActor, clutter_actor_get_height(trackActor) - clutter_actor_get_height(m_previousButton->Actor()));

			// set drag action attributes
			clutter_drag_action_set_drag_axis(CLUTTER_DRAG_ACTION(thumbDragAction), CLUTTER_DRAG_Y_AXIS);
			ClutterRect rect;
			rect.origin.x = 0;
			rect.origin.y = clutter_actor_get_height(prevActor);
			rect.size.width = clutter_actor_get_height(trackActor);
			//rect.size.height = height - m_pointingNormalThumbImageHeight - clutter_actor_get_height(prevActor) - clutter_actor_get_height(nextActor);
			rect.size.height = height - t_1920ConvertMultiResolution(m_pointingNormalThumbImageHeight);
			clutter_drag_action_set_drag_area(CLUTTER_DRAG_ACTION(thumbDragAction), &rect);
		}
	}

	bool CScroll::AddListener(IScrollListener* listener)
	{
		H_LOG_TRACE(LOGGER, "CScroll::AddListener(" << listener << ")");

		HALO_ASSERT(listener != NULL);

		m_listenerSet.insert(listener);
		return true;
	}

	bool CScroll::RemoveListener(IScrollListener* listener)
	{
		H_LOG_TRACE(LOGGER, "CScroll::RemoveListener(" << listener << ")");

		HALO_ASSERT(listener != NULL);

		m_listenerSet.erase(listener);
		return true;
	}

	void CScroll::SetMinCurMaxValue(int minValue, int curValue, int maxValue)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetMinCurMaxValue(" << minValue << ", " << curValue << ", " << maxValue << ")");
		HALO_ASSERT(minValue >= 0);
		HALO_ASSERT(curValue >= minValue);
		HALO_ASSERT(maxValue >= curValue);

		m_minValue = minValue;
		m_currentValue = curValue;
		m_maxValue = maxValue;

		m_ValueChanged();
	}

	void CScroll::GetMinCurMaxValue(int &minValue, int &curValue, int &maxValue) const
	{
		H_LOG_TRACE(LOGGER, "CScroll::GetMinCurMaxValue()");
		minValue = m_minValue;
		curValue = m_currentValue;
		maxValue = m_maxValue;
	}

	void CScroll::SetLongPressIntervalOnArrowButton(int timeInterval)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetLongPressIntervalOnArrowButton(" << timeInterval << ")");
		m_timeInterval = timeInterval;
	}

	void CScroll::SetMovingStepOnArrowButton(int moveStep)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetMovingStepOnArrowButton(" << moveStep << ")");
		m_moveStep = moveStep;
	}

	void CScroll::SetPointingNormalThumbImage(const std::string& pointingNormalThumbImagePath)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetPointingNormalThumbImage(" << pointingNormalThumbImagePath << ")");

		m_pointingNormalThumbImagePath = pointingNormalThumbImagePath;
		m_thumbImage->SetImage(m_pointingNormalThumbImagePath.c_str());
		//m_thumbImageWidget->SetImage(m_pointingNormalThumbImagePath.c_str());
	}

	std::string CScroll::PointingNormalThumbImage(void) const
	{
		return m_pointingNormalThumbImagePath;
	}

	void CScroll::SetPointingOverThumbImage(const std::string& pointingOverThumbImagePath)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetPointingOverThumbImage(" << pointingOverThumbImagePath << ")");

		m_pointingOverThumbImagePath = pointingOverThumbImagePath;
	}

	std::string CScroll::PointingOverThumbImage(void) const
	{
		return m_pointingOverThumbImagePath;
	}

	void CScroll::SetPointingFocusThumbImage(const std::string& pointingFocusThumbImagePath)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetPointingFocusThumbImage(" << pointingFocusThumbImagePath << ")");

		m_pointingFocusThumbImagePath = pointingFocusThumbImagePath;
	}

	std::string CScroll::PointingFocusThumbImage(void) const
	{
		return m_pointingFocusThumbImagePath;
	}

	void CScroll::SetPointingNormalThumbSize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetPointingNormalThumbSize(" << width << "," << height << ")");

		//m_thumbImageWidget->setWidth(m_pointingNormalThumbImageWidth);
		//m_thumbImageWidget->setHeight(m_pointingNormalThumbImageHeight);
		//m_thumbActor->Resize(m_pointingNormalThumbImageWidth, m_pointingNormalThumbImageHeight);
		m_pointingNormalThumbImageWidth = width;
		m_pointingNormalThumbImageHeight = height;
		m_thumbImage->Resize(width, height);

		m_ValueChanged();
		m_SetDragArea();
	}

	void CScroll::GetPointingNormalThumbSize(float &width, float &height)
	{
		width = m_pointingNormalThumbImageWidth;
		height = m_pointingNormalThumbImageHeight;
	}

	void CScroll::SetPointingOverThumbSize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetPointingOverThumbSize(" << width << "," << height << ")");

		m_pointingOverThumbImageWidth = width;
		m_pointingOverThumbImageHeight = height;
	}

	void CScroll::GetPointingOverThumbSize(float &width, float &height)
	{
		H_LOG_TRACE(LOGGER, "CScroll::GetPointingOverThumbSize. Width: " << m_pointingOverThumbImageWidth << ", Height: " << m_pointingOverThumbImageHeight << ".");

		width = m_pointingOverThumbImageWidth;
		height = m_pointingOverThumbImageHeight;
	}

	void CScroll::SetPointingFocusThumbSize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetPointingFocusThumbSize(" << width << "," << height << ")");

		m_pointingFocusThumbImageWidth = width;
		m_pointingFocusThumbImageHeight = height;
	}

	void CScroll::GetPointingFocusThumbSize(float &width, float &height)
	{
		H_LOG_TRACE(LOGGER, "CScroll::GetPointingFocusThumbSize. Width: " << m_pointingFocusThumbImageWidth << ", height: " << m_pointingFocusThumbImageHeight << ".");

		width = m_pointingFocusThumbImageWidth;
		height = m_pointingFocusThumbImageHeight;
	}
	
	bool CScroll::OnMousePointerIn(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_TRACE(LOGGER, "CScroll::OnMousePointerIn(" << pWindow << ", " << ptrMouseEvent << ")");

		CWidgetEx *trackTop = dynamic_cast<CWidgetEx *>(m_trackTopActor);
		CWidgetEx *trackShadow = dynamic_cast<CWidgetEx *>(m_trackShadowActor);
		CWidgetEx *trackArea = dynamic_cast<CWidgetEx *>(m_trackAreaActor);
		if (trackTop == nullptr || trackShadow == nullptr || trackArea == nullptr)
		{
			HALO_EXCEPTION(false, "dynamic_cast to CWidgetEx failed!");
			return false;
		}

		if (m_direction == TYPE_HORIZONTAL)
		{
			//clutter_actor_set_height(m_trackTopActor->Actor(), m_rolloverTopTrackHeight);
			//clutter_actor_set_height(m_trackAreaActor->Actor(), m_rolloverTopTrackHeight + m_bottomTrackHeight);
			//clutter_actor_set_y(m_trackAreaActor->Actor(), (clutter_actor_get_height(t_actor) - (m_rolloverTopTrackHeight + m_bottomTrackHeight)) / 2);
			//clutter_actor_set_y(m_trackShadowActor->Actor(), m_rolloverTopTrackHeight);
			
			trackTop->setHeight(m_rolloverTopTrackHeight);
			trackShadow->setY(m_rolloverTopTrackHeight);
			trackArea->setHeight(m_rolloverTopTrackHeight + m_bottomTrackHeight);
			float newY = (this->getHeight() - (m_rolloverTopTrackHeight + m_bottomTrackHeight)) / 2;
			trackArea->setY(newY);
		}
		else
		{
			//clutter_actor_set_width(m_trackTopActor->Actor(), m_rolloverTopTrackHeight);
			//clutter_actor_set_width(m_trackAreaActor->Actor(), m_rolloverTopTrackHeight + m_bottomTrackHeight);
			//clutter_actor_set_x(m_trackAreaActor->Actor(), (clutter_actor_get_width(t_actor) - (m_rolloverTopTrackHeight + m_bottomTrackHeight)) / 2);
			//clutter_actor_set_x(m_trackShadowActor->Actor(), m_rolloverTopTrackHeight);

			trackTop->setWidth(m_rolloverTopTrackHeight);
			trackShadow->setX(m_rolloverTopTrackHeight);
			trackArea->setWidth(m_rolloverTopTrackHeight + m_bottomTrackHeight);
			float newX = (this->getWidth() - (m_rolloverTopTrackHeight + m_bottomTrackHeight)) / 2;
			trackArea->setX(newX);
		}

		// pointing on thumb
		if (pWindow == dynamic_cast<CActor *>(m_trackAreaActor))
		{
			//m_thumbImageWidget->setSource(m_pointingOverThumbImagePath);
			//m_thumbImageWidget->setWidth(m_pointingOverThumbImageWidth);
			//m_thumbImageWidget->setHeight(m_pointingOverThumbImageHeight);
			//m_thumbActor->Resize(m_pointingOverThumbImageWidth, m_pointingOverThumbImageHeight);

			m_thumbImage->SetImage(m_pointingOverThumbImagePath.c_str());
			m_thumbImage->Resize(m_pointingOverThumbImageWidth, m_pointingOverThumbImageHeight);
		}
		else if (pWindow == dynamic_cast<CActor *>(m_thumbImage))
		{
			//m_thumbImageWidget->setSource(m_pointingFocusThumbImagePath);
			//m_thumbImageWidget->setWidth(m_pointingFocusThumbImageWidth);
			//m_thumbImageWidget->setHeight(m_pointingFocusThumbImageHeight);
			//m_thumbActor->Resize(m_pointingFocusThumbImageWidth, m_pointingFocusThumbImageHeight);

			m_thumbImage->SetImage(m_pointingFocusThumbImagePath.c_str());
			m_thumbImage->Resize(m_pointingFocusThumbImageWidth, m_pointingFocusThumbImageHeight);
		}

		return true;
	}

	bool CScroll::OnMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_TRACE(LOGGER, "CScroll::OnMousePointerOut(" << pWindow << ", " << ptrMouseEvent << ")");

		CWidgetEx *trackTop = dynamic_cast<CWidgetEx *>(m_trackTopActor);
		CWidgetEx *trackShadow = dynamic_cast<CWidgetEx *>(m_trackShadowActor);
		CWidgetEx *trackArea = dynamic_cast<CWidgetEx *>(m_trackAreaActor);
		if (trackTop == nullptr || trackShadow == nullptr || trackArea == nullptr)
		{
			HALO_EXCEPTION(false, "dynamic_cast to CWidgetEx failed!");
			return false;
		}

		// All actors back to normal
		if (m_direction == TYPE_HORIZONTAL)
		{
			//clutter_actor_set_height(m_trackTopActor->Actor(), m_normalTrackTopHeight);
			//clutter_actor_set_y(m_trackAreaActor->Actor(), 0);
			//clutter_actor_set_y(m_trackShadowActor->Actor(), m_normalTrackTopHeight);

			//clutter_actor_set_height(m_trackAreaActor->Actor(), m_normalTrackTopHeight + m_bottomTrackHeight);
			//clutter_actor_set_y(m_trackAreaActor->Actor(), (clutter_actor_get_height(t_actor) - clutter_actor_get_height(m_trackAreaActor->Actor())) / 2);

			trackTop->setHeight(m_normalTrackTopHeight);
			trackArea->setY(0);
			trackShadow->setY(m_normalTrackTopHeight);

			trackArea->setHeight(m_normalTrackTopHeight + m_bottomTrackHeight);
			float newY = (this->getHeight() - trackArea->getHeight()) / 2;
			trackArea->setY(newY);
		}
		else
		{
			//clutter_actor_set_width(m_trackTopActor->Actor(), m_normalTrackTopHeight);
			//clutter_actor_set_x(m_trackAreaActor->Actor(), 0);
			//clutter_actor_set_x(m_trackShadowActor->Actor(), m_normalTrackTopHeight);

			//clutter_actor_set_width(m_trackAreaActor->Actor(), m_normalTrackTopHeight + m_bottomTrackHeight);
			//clutter_actor_set_x(m_trackAreaActor->Actor(), (clutter_actor_get_width(t_actor) - (m_normalTrackTopHeight + m_bottomTrackHeight)) / 2);

			trackTop->setWidth(m_normalTrackTopHeight);
			trackArea->setX(0);
			trackShadow->setX(m_normalTrackTopHeight);

			trackArea->setWidth(m_normalTrackTopHeight + m_bottomTrackHeight);
			float newX = (this->getWidth() - (m_normalTrackTopHeight + m_bottomTrackHeight)) / 2;
			trackArea->setX(newX);
		}

		//m_thumbImageWidget->setSource(m_pointingNormalThumbImagePath);
		//m_thumbImageWidget->setWidth(m_pointingNormalThumbImageWidth);
		//m_thumbImageWidget->setHeight(m_pointingNormalThumbImageHeight);
		//m_thumbActor->Resize(m_pointingNormalThumbImageWidth, m_pointingNormalThumbImageHeight);
		m_thumbImage->SetImage(m_pointingNormalThumbImagePath.c_str());
		m_thumbImage->Resize(m_pointingNormalThumbImageWidth, m_pointingNormalThumbImageHeight);


		//float factor = static_cast<float>(m_currentValue) / (m_maxValue - m_minValue);
		//if (m_direction == TYPE_HORIZONTAL)
		//{
		//	float refinedX = factor * (clutter_actor_get_width(t_actor) - m_pointingNormalThumbImageWidth);
		//	clutter_actor_set_x(m_thumbActor->Actor(), refinedX);
		//}
		//else
		//{
		//	float refinedY = factor * (clutter_actor_get_height(t_actor) - m_pointingNormalThumbImageHeight);
		//	clutter_actor_set_y(m_thumbActor->Actor(), refinedY);
		//}

		return true;
	}

	bool CScroll::OnMouseButtonPressed(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_TRACE(LOGGER, "CScroll::OnMouseButtonPressed(" << pWindow << ", " << ptrMouseEvent << ")");

		return true;
	}

	bool CScroll::OnMouseButtonReleased(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_TRACE(LOGGER, "CScroll::OnMouseButtonReleased(" << pWindow << ", " << ptrMouseEvent << ")");

		// for long press
		if (pWindow == m_previousButton || pWindow == m_nextButton)
		{
			// close long press timer
			if (m_longPressTimerId > 0)
			{
				g_source_remove(m_longPressTimerId);
				m_longPressTimerId = 0;
				return false;
			}
		}

		return false;
	}

	void CScroll::SetTrackShadowHeight(float bottomTrackHeight)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetTrackShadowHeight(" << bottomTrackHeight << ")");
		m_bottomTrackHeight = bottomTrackHeight;

		CWidgetEx *trackTop = dynamic_cast<CWidgetEx *>(m_trackTopActor);
		CWidgetEx *trackShadow = dynamic_cast<CWidgetEx *>(m_trackShadowActor);
		CWidgetEx *trackArea = dynamic_cast<CWidgetEx *>(m_trackAreaActor);
		if (trackTop == nullptr || trackShadow == nullptr || trackArea == nullptr)
		{
			HALO_EXCEPTION(false, "dynamic_cast to CWidgetEx failed!");
			return;
		}

		if (m_direction == TYPE_HORIZONTAL)
		{
			//m_normalTrackTopHeight = clutter_actor_get_height(m_trackAreaActor->Actor()) - m_bottomTrackHeight;
			//clutter_actor_set_y(m_trackShadowActor->Actor(), m_normalTrackTopHeight);
			//clutter_actor_set_height(m_trackShadowActor->Actor(), bottomTrackHeight);
			m_normalTrackTopHeight = trackArea->getHeight() - m_bottomTrackHeight;
			if (m_normalTrackTopHeight < 0)
			{
				HALO_EXCEPTION(false, "Shadow height is bigger than track!");
			}

			trackTop->setHeight(m_normalTrackTopHeight);
			trackShadow->setY(m_normalTrackTopHeight);
			trackShadow->setHeight(m_bottomTrackHeight);
			//trackShadow->hide();		// can be used for debug
		}
		else
		{
			//m_normalTrackTopHeight = clutter_actor_get_width(m_trackAreaActor->Actor()) - m_bottomTrackHeight;
			//if (m_normalTrackTopHeight < 0)
			//{
			//	HALO_EXCEPTION(false, "Shadow width is bigger than track!");
			//}

			//clutter_actor_set_x(m_trackShadowActor->Actor(), m_normalTrackTopHeight);
			//clutter_actor_set_width(m_trackShadowActor->Actor(), m_bottomTrackHeight);

			m_normalTrackTopHeight = trackArea->getWidth() - m_bottomTrackHeight;
			if (m_normalTrackTopHeight < 0)
			{
				HALO_EXCEPTION(false, "Shadow width is bigger than track!");
				return;
			}

			trackTop->setWidth(m_normalTrackTopHeight);
			trackShadow->setX(m_normalTrackTopHeight);
			trackShadow->setWidth(m_bottomTrackHeight);
		}
	}

	float CScroll::TrackShadowHeight(void) const
	{
		H_LOG_TRACE(LOGGER, "CScroll::RolloverTrackHeight(). RolloverTrackHeight: " << m_rolloverTopTrackHeight);

		return m_bottomTrackHeight;
	}

	void CScroll::SetBackgroundColor(const ClutterColor& topTrackColor)
	{
		// let t_actor to be transparent
		ClutterColor transparentColor;
		clutter_color_init(&transparentColor, 0, 0, 0, 0);
		clutter_actor_set_background_color(t_actor, &transparentColor);	// need it.

		m_topTrackColor = topTrackColor;
		m_trackTopActor->SetBackgroundColor(topTrackColor);
	}

	void CScroll::SetTrackShadowColor(const ClutterColor& bottomTrackColor)
	{
		m_bottomTrackColor = bottomTrackColor;
		m_trackShadowActor->SetBackgroundColor(bottomTrackColor);
	}

	const ClutterColor& CScroll::TrackShadowColor(void) const
	{
		return m_bottomTrackColor;
	}

	void CScroll::SetRolloverTrackHeight(float rolloverTopTrackHeight)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetRolloverTrackHeight(" << rolloverTopTrackHeight << ")");

		m_rolloverTopTrackHeight = rolloverTopTrackHeight;
	}

	float CScroll::RolloverTrackHeight(void) const
	{
		H_LOG_TRACE(LOGGER, "CScroll::RolloverTrackHeight(). RolloverTrackHeight: " << m_rolloverTopTrackHeight);

		return m_rolloverTopTrackHeight;
	}

	HALO::EDirectionType CScroll::DirectionType(void) const
	{
		H_LOG_TRACE(LOGGER, "CScroll::DirectionType(). DirectionType: " << m_direction);

		return m_direction;
	}

	const char* CScroll::GetActorType(void)
	{
		return "Scroll";
	}

	//void CScroll::SetOrientation(EOrientation orientation)
	//{
	//	CActor::SetOrientation(orientation);

	//	m_ValueChanged();
	//}

	void CScroll::SetActive(bool flagActive)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetActive(" << flagActive << ")");
		if (m_active == flagActive)
		{
			return;
		}

		m_active = flagActive;

		ClutterActor* trackAreaActor = m_trackAreaActor->Actor();
		//ClutterActor* thumbActor = m_thumbActor->Actor();
		ClutterActor* thumbActor = m_thumbImage->Actor();

		if (flagActive)
		{
			// Add drag support for thumb
			ClutterAction* thumbDragAction = clutter_drag_action_new();
			clutter_actor_add_action_with_name(thumbActor, THUMB_DRAG_ACTION_NAME, thumbDragAction);
			g_signal_connect(thumbDragAction, "drag-motion", G_CALLBACK(m_OnThumbDragMotion), this);
			clutter_actor_set_reactive(thumbActor, true);
			m_SetDragArea();		// set drag area

			// Add click support for track
			ClutterAction* clickAction = clutter_click_action_new();
			clutter_actor_add_action_with_name(trackAreaActor, TRACK_CLICK_ACTION_NAME, clickAction);
			g_signal_connect(clickAction, "clicked", G_CALLBACK(m_OnScrollClick), this);
			clutter_actor_set_reactive(trackAreaActor, true);

			//ClutterActor* prevButtonActor = m_previousButton->Actor();
			//ClutterActor* nextButtonActor = m_nextButton->Actor();
			//ClutterAction* preClickAction = clutter_click_action_new();
			//clutter_actor_add_action(prevButtonActor, preClickAction);
			//g_signal_connect(preClickAction, "clicked", G_CALLBACK(m_OnPreButtonClicked), this);
			//g_signal_connect(preClickAction, "long-press", G_CALLBACK(m_OnPreButtonLongPress), this);
			//clutter_actor_set_reactive(prevButtonActor, true);

			//ClutterAction* nextClickAction = clutter_click_action_new();
			//clutter_actor_add_action(nextButtonActor, nextClickAction);
			//g_signal_connect(nextClickAction, "clicked", G_CALLBACK(m_OnNextButtonClicked), this);
			//g_signal_connect(nextClickAction, "long-press", G_CALLBACK(m_OnNextButtonLongPress), this);
			//clutter_actor_set_reactive(nextButtonActor, true);

			m_trackAreaActor->AddMouseListener(this);
			m_thumbImage->AddMouseListener(this);
		} 
		else
		{
			clutter_actor_remove_action_by_name(thumbActor, THUMB_DRAG_ACTION_NAME);
			clutter_actor_remove_action_by_name(trackAreaActor, TRACK_CLICK_ACTION_NAME);

			m_trackAreaActor->RemoveMouseListener(this);
			m_thumbImage->RemoveMouseListener(this);
		}
	}

	bool CScroll::FlagActive(void) const
	{
		H_LOG_TRACE(LOGGER, "CScroll::FlagActive()");

		return m_active;
	}

	void CScroll::SetPointingNormalBackgroundImage(const std::string& pointingNormalBackgroundImage)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetPointingNormalBackgroundImage(" << pointingNormalBackgroundImage << ")");

		m_pointingNormalBackgroundImagePath = pointingNormalBackgroundImage;
		m_trackAreaActor->SetImage(m_pointingNormalBackgroundImagePath.c_str());
	}

	std::string CScroll::PointingNormalBackgroundImage(void) const
	{
		return m_pointingNormalBackgroundImagePath;
	}

	void CScroll::SetPointingOverBackgroundImage(const std::string& pointingOverBackgroundImage)
	{
		H_LOG_TRACE(LOGGER, "CScroll::SetPointingOverBackgroundImage(" << pointingOverBackgroundImage << ")");

		m_pointingOverBackgroundImagePath = pointingOverBackgroundImage;
		m_trackAreaActor->SetImage(m_pointingOverBackgroundImagePath.c_str());
	}

	std::string CScroll::PointingOverBackgroundImage(void) const
	{
		return m_pointingOverBackgroundImagePath;
	}

	void CScroll::t_UpdateOrientation(EOrientation orientation)
	{
		HALO_ASSERT(orientation != ORIENTATION_REFER_TO_PARENT);

		m_ValueChanged();
	}

}
