#include "Halo1_0.h"

namespace HALO
{
	CSelectButton::CSelectButton()
	{

	}

	CSelectButton::~CSelectButton()
	{
		m_Destory();
	}

	void CSelectButton::t_Initialize()
	{
		m_IsText = false;
		t_IsChecked = false;
		t_IsEnableSelected = true;
		m_HasBgImage = false;
		t_BoxBgImage = NULL;
		t_CheckImage = NULL;
		m_curState = E_STATE_NORMAL;
		t_text = NULL;
		m_listener = NULL;
		if (NULL != t_BoxBgImage)
		{
			t_BoxBgImage->EnableClipOverflow(true);
		}
		for(int i = 0; i < E_STATE_ALL; i++)
		{
			m_stateData[i].textContent = NULL;
			m_stateData[i].font = NULL;
			ClutterColor c = {0, 0, 0, 255};
			m_stateData[i].color = c;
			m_stateData[i].fontSize = 0;
			int boxbgOpacitty = 100; 
			int checkOpacitty = 100;
		}
		AddKeyboardListener(this);
		AddClickListener(this);
		AddFocusListener(this);
		AddMouseListener(this);
		EnableFocus(true);
		IClickAction* action = IClickAction::CreateInstance(this);
		this->AddAction(action);
		m_action = action;
		EnablePointerFocus(true);
	}

	void CSelectButton::SetItemText( EItemState state, const char* itemText )
	{
		if(state == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				if (m_stateData[i].textContent != NULL)
				{
					delete[] m_stateData[i].textContent;
					m_stateData[i].textContent = NULL;
				}
				m_stateData[i].textContent = new char[strlen(itemText) + 1];
				int len = strlen(itemText) + 1;
				strncpy(m_stateData[i].textContent, itemText, len);
			}
		}
		else
		{
			if (m_stateData[state].textContent != NULL)
			{
				delete[] m_stateData[state].textContent;
				m_stateData[state].textContent = NULL;
			}
			m_stateData[state].textContent = new char[strlen(itemText) + 1];
			strncpy(m_stateData[state].textContent, itemText, strlen(itemText) + 1);
		}
		if (state == E_STATE_ALL || state == m_curState)
		{
			t_text->SetText(m_stateData[m_curState].textContent);
			t_text->Show();
		}
	}

	const char* CSelectButton::ItemText(EItemState state)
	{
		ASSERT(state < E_STATE_ALL);
		return m_stateData[state].textContent;
	}

	void CSelectButton::SetItemTextFontSize( EItemState state, const int fontSize )
	{
		if (state == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				m_stateData[i].fontSize = fontSize;
			}
		}
		else
		{
			m_stateData[state].fontSize = fontSize;
		}
	}

	void CSelectButton::SetItemTextColor( EItemState state, const ClutterColor color )
	{
		if(state == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				m_stateData[i].color = color;
			}
		}
		else
		{
			m_stateData[state].color = color;
		}
		if (state == E_STATE_ALL || state == m_curState)
		{
			t_text->SetTextColor(m_stateData[m_curState].color);
		}
	}

	void CSelectButton::SetTextFont( EItemState state, const char* font )
	{
		ASSERT(font != NULL);
		if(state == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				if (m_stateData[i].font != NULL)
				{
					delete[] m_stateData[i].font;
					m_stateData[i].font = NULL;
				}
				m_stateData[i].font = new char[strlen(font) + 1];
				//! temp for Prevent
				int len = strlen(font) + 1;
				strncpy(m_stateData[i].font, font, len);
			}
		}
		else
		{
			if (m_stateData[state].font != NULL)
			{
				delete[] m_stateData[state].font;
				m_stateData[state].font = NULL;
			}
			m_stateData[state].font = new char[strlen(font) + 1];
			strncpy(m_stateData[state].font, font, strlen(font)+1);
		}
		if (state == E_STATE_ALL || state == m_curState)
		{
			t_text->SetFont(m_stateData[m_curState].font);
		}
	}

	char* CSelectButton::TextFont( EItemState state )
	{
		ASSERT(state < E_STATE_ALL);
		return m_stateData[state].font;
	}

	void CSelectButton::SetId( int itemId )
	{
		m_Id = itemId;
	}

	int CSelectButton::GetId()
	{
		return m_Id;
	}

	void CSelectButton::SetTextAlignment( EHAlignment hAlign, EVAlignment vAlign )
	{
		t_text->SetTextAlignment(hAlign , vAlign);
	}

	void CSelectButton::Show()
	{
		if (m_HasBgImage)
		{
			t_BoxBgImage->SetAlpha(m_stateData[E_STATE_NORMAL].boxbgOpacity);
			t_BoxBgImage->SetImage(m_stateData[E_STATE_NORMAL].bg_imagepath.c_str());
			t_BoxBgImage->Show();
		}
		t_CheckImage->SetAlpha(m_stateData[E_STATE_NORMAL].checkOpacity);
		t_CheckImage->SetImage(m_stateData[E_STATE_NORMAL].check_imagepath.c_str());
		t_CheckImage->Show();
		if (m_IsText)
		{
			t_text->SetText(m_stateData[E_STATE_NORMAL].textContent);
			if (m_stateData[E_STATE_NORMAL].fontSize != 0)
			{
				t_text->SetFontSize(m_stateData[E_STATE_NORMAL].fontSize);
			}
			t_text->Show();
		}
		ParentType::Show();
	}

	void CSelectButton::t_ChangeStateTo( EItemState toState )
	{
		if (toState == m_curState || E_STATE_ALL == toState)
		{
			return;
		}
		m_curState = toState;
		if (m_HasBgImage)
		{
			t_BoxBgImage->SetAlpha(m_stateData[toState].boxbgOpacity);
		}
		t_CheckImage->SetAlpha(m_stateData[toState].checkOpacity);
		m_OnStateChange();
	}

	void CSelectButton::m_OnStateChange()
	{
		if( m_stateData[m_curState].bg_imagepath.empty() && NULL == m_stateData[m_curState].check_imagepath.empty())
		{
			if (m_HasBgImage)
			{
				t_BoxBgImage->Hide();
			}
			t_CheckImage->Hide();
		}

		if (t_BoxBgImage != NULL)
		{
			t_BoxBgImage->SetImage(m_stateData[m_curState].bg_imagepath.c_str());
			t_BoxBgImage->Show();
		}

		if (t_CheckImage != NULL)
		{
			t_CheckImage->SetImage(m_stateData[m_curState].check_imagepath.c_str());
			t_CheckImage->Show();
		}

		if(m_stateData[m_curState].font != NULL)
		{
			t_text->SetFont(m_stateData[m_curState].font);
		}
		if (m_IsText)
		{
			if(m_stateData[m_curState].textContent != NULL)
			{
				t_text->SetTextColor(m_stateData[m_curState].color);
				t_text->SetText(m_stateData[m_curState].textContent);
				if (m_stateData[m_curState].fontSize != 0)
				{
					t_text->SetFontSize(m_stateData[m_curState].fontSize);
				}
				t_text->Show();
			}
		}

	}

	bool CSelectButton::IsChecked()
	{
		return t_IsChecked;
	}

	void CSelectButton::m_Destory()
	{
		t_CheckImage->Release();
		if (NULL != t_BoxBgImage)
		{
			t_BoxBgImage->Release();
		}
		if (t_text != NULL)
		{
			t_text->Release();
		}
		for (int i = 0; i < E_STATE_ALL; i++)
		{
			if (m_stateData[i].textContent != NULL)
			{
				delete[] m_stateData[i].textContent;
			}
			if (m_stateData[i].font != NULL)
			{
				delete[] m_stateData[i].font;
			}
		}
		delete m_action;
		m_action = NULL;
		RemoveMouseListener(this);
		RemoveClickListener(this);
		RemoveFocusListener(this);
		RemoveKeyboardListener(this);
	}

	void CSelectButton::EnableChecked( bool isSelected )
	{
		t_IsEnableSelected = isSelected;
		EItemState state;
		if(isSelected)
		{
			state = E_STATE_NORMAL;
		}
		else
		{
			state = E_STATE_DISABLED;
		}

		CActor::Enable(isSelected);
		t_ChangeStateTo(state);
	}

	const char* CSelectButton::GetActorType(void)
	{
		return "BaseSelectButton";
	}

	bool CSelectButton::OnClicked( IActor* pWindow, IEvent* pClickEvent )
	{
		if (IsChecked())
		{
			SetCheck(false);
		}
		else
		{
			SetCheck(true);
		}
		if (NULL != m_listener)
		{
			m_listener->OnCheckedChanged(this , this->IsChecked());
		}
		return true;
	}

	bool CSelectButton::OnKeyPressed( IActor* pThis, IKeyboardEvent* event )
	{
		int keyValue = event->GetKeyVal();
		if (keyValue == 65293)
		{
			if (IsChecked())
			{
				SetCheck(false);
			}
			else
			{
				SetCheck(true);
			}
			if (NULL != m_listener)
			{
				m_listener->OnCheckedChanged(this , this->IsChecked());
			}
		}
		return true;
	}

	void CSelectButton::AddListener( OnButtonCheckedChangedListener *listener )
	{
		ASSERT(NULL != listener);
		m_listener = listener;
	}

	bool CSelectButton::OnFocusIn( IActor* pWindow )
	{
		if (m_curState == E_STATE_SELECTED)
		{
			return true;
		}
		EItemState state;
		state = E_STATE_FOCUSED;
		t_ChangeStateTo(state);
		return true;
	}

	bool CSelectButton::OnFocusOut( IActor* pWindow )
	{
		if (m_curState == E_STATE_SELECTED)
		{
			return true;
		}
		EItemState state;
		state = E_STATE_NORMAL;
		t_ChangeStateTo(state);
		return true;
	}

	void CSelectButton::SetBoxBackGroudImage( EItemState state, const std::string& iconPath )
	{
		ASSERT(state <= E_STATE_ALL);
		if (m_HasBgImage == false)
		{
			m_HasBgImage = true;
		}
		if (NULL == t_BoxBgImage)
		{
			t_BoxBgImage = IImage::CreateInstance(dynamic_cast<Widget*>(this), t_itemW, t_itemH);
		}
		if (NULL != t_BoxBgImage)
		{
			t_BoxBgImage->EnableClipOverflow(true);
		}
		if(state == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				m_stateData[i].bg_imagepath = iconPath;
			}
		}
		else
		{
			m_stateData[state].bg_imagepath = iconPath;
		}
		if (state == E_STATE_ALL || state == m_curState)
		{
			t_BoxBgImage->SetImage(m_stateData[m_curState].bg_imagepath.c_str());
			t_BoxBgImage->Show();
		}
	}

	void CSelectButton::SetCheckImage( EItemState state, const std::string& iconPath )
	{
		ASSERT(state <= E_STATE_ALL);

		if (NULL == t_CheckImage)
		{
			t_CheckImage = IImage::CreateInstance(dynamic_cast<Widget*>(this), t_itemW, t_itemH);
		}
		
		if(state == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				m_stateData[i].check_imagepath = iconPath;
			}
		}
		else
		{
			m_stateData[state].check_imagepath = iconPath;
		}
		if (state == E_STATE_ALL || state == m_curState)
		{
			t_CheckImage->SetImage(m_stateData[m_curState].check_imagepath.c_str());
			t_CheckImage->Show();
		}
	}

	void CSelectButton::SetCheck( bool isChecked )
	{
		EItemState state;
		t_IsChecked = isChecked;
		if (isChecked)
		{
			state = E_STATE_SELECTED;
			t_ChangeStateTo(state);
		}
		else
		{
			state = E_STATE_NORMAL;
			t_ChangeStateTo(state);
		}
		if (t_CheckImage != NULL && t_BoxBgImage != NULL)
		{
			t_BoxBgImage->Show();
			t_CheckImage->Show();
		}
	}

	bool CSelectButton::Initialize( IActor *parent ,float width, float height )
	{
		if (ParentType::Initialize(parent , width , height) == false)
		{
			return false;
		}
		t_itemH = width;
		t_itemW = height;
		t_Initialize();
		return true;
	}

	bool CSelectButton::Initialize( Widget *parent ,float width, float height )
	{
		if (ParentType::Initialize(parent , width , height) == false)
		{
			return false;
		}
		t_itemH = width;
		t_itemW = height;
		t_Initialize();
		return true;
	}


	bool CSelectButton::OnMousePointerIn( IActor* pWindow, IMouseEvent* ptrMouseEvent )
	{
		SetFocus();
		return true;
	}

	bool CSelectButton::OnMousePointerOut( IActor* pWindow, IMouseEvent* ptrMouseEvent )
	{
		KillFocus();
		return true;
	}

	void CSelectButton::UpdateImageAttr( float x , float y , float w , float h )
	{
		ASSERT(w < t_itemW || h < t_itemH);
		t_BoxBgImage->Resize(w , h);
		t_CheckImage->Resize(w , h);
		t_BoxBgImage->SetPosition(x , y);
		t_CheckImage->SetPosition(x , y);
	}

	void CSelectButton::SetAttachText( float x , float y , float w , float h )
	{
		//ASSERT(w < t_itemW || h < t_itemH);
		t_text = IText::CreateInstance(dynamic_cast<Widget*>(this), w, h);
		if (t_text != NULL)
		{
			t_text->EnableEllipsize(true);
			t_text->SetTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
			t_text->SetPosition(x , y);
			m_IsText = true;
		}	
	}

	void CSelectButton::SetBoxBackGroudImageOpacity( EItemState state, int boxbgOpacity )
	{
		if (!m_HasBgImage)
		{
			return;
		}
		if(state == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				m_stateData[i].boxbgOpacity = boxbgOpacity;
			}
		}
		else
		{
			m_stateData[state].boxbgOpacity = boxbgOpacity;
		}
	}

	void CSelectButton::SetCheckImageOpacity( EItemState state, int checkOpacity )
	{
		if(state == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				m_stateData[i].checkOpacity = checkOpacity;
			}
		}
		else
		{
			m_stateData[state].checkOpacity = checkOpacity;
		}
	}

}
