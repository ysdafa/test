#include "Halo1_0.h"

namespace HALO
{
	CSelectButton::CSelectButton()
	{

	}

	CSelectButton::~CSelectButton()
	{
		m_Destory();
	}

	void CSelectButton::t_Initialize()
	{
		m_IsText = false;
		t_IsChecked = false;
		m_Async = false;
		t_IsEnableSelected = true;
		m_HasBgImage = false;
		m_HasCheckImage = false;
		t_BoxBgImage = NULL;
		t_CheckImage = NULL;
		m_curState = E_STATE_NORMAL;
		t_text = NULL;
		m_listener = NULL;
		t_IsAutoChecked = true;
		for(int i = 0; i < E_STATE_ALL; i++)
		{
			m_stateData[i].textContent = NULL;
			m_stateData[i].font = NULL;
			ClutterColor c = {0, 0, 0, 255};
			m_stateData[i].color = c;
			m_stateData[i].fontSize = 0;
			m_stateData[i].boxbgOpacity = 100;
			m_stateData[i].checkOpacity = 100;
		}
		AddKeyboardListener(this);
		if (t_IsAutoFocused)
		{
			AddFocusListener(this);
			EnableFocus(true);
			EnablePointerFocus(true);
		}
		AddMouseListener(this);
	}

	void CSelectButton::SetItemText( EItemState state, const char* itemText )
	{
		HALO_ASSERT(NULL != itemText);
		if(state == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				if (m_stateData[i].textContent != NULL)
				{
					delete[] m_stateData[i].textContent;
					m_stateData[i].textContent = NULL;
				}
				m_stateData[i].textContent = new char[strlen(itemText) + 1];
				int len = strlen(itemText) + 1;
				strncpy(m_stateData[i].textContent, itemText, len);
			}
		}
		else
		{
			if (m_stateData[state].textContent != NULL)
			{
				delete[] m_stateData[state].textContent;
				m_stateData[state].textContent = NULL;
			}
			m_stateData[state].textContent = new char[strlen(itemText) + 1];
			strncpy(m_stateData[state].textContent, itemText, strlen(itemText) + 1);
		}
		if (state == E_STATE_ALL || state == m_curState)
		{
			t_text->SetText(m_stateData[m_curState].textContent);
			t_text->Show();
		}
	}

	const char* CSelectButton::ItemText(EItemState state)
	{
		ASSERT(state < E_STATE_ALL);
		return m_stateData[state].textContent;
	}

	void CSelectButton::SetItemTextFontSize( EItemState state, const int fontSize )
	{
		if (state == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				m_stateData[i].fontSize = fontSize;
			}
		}
		else
		{
			m_stateData[state].fontSize = fontSize;
		}
	}

	void CSelectButton::SetItemTextColor( EItemState state, const ClutterColor color )
	{
		if(state == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				m_stateData[i].color = color;
			}
		}
		else
		{
			m_stateData[state].color = color;
		}
		if (state == E_STATE_ALL || state == m_curState)
		{
			t_text->SetTextColor(m_stateData[m_curState].color);
		}
	}

	void CSelectButton::SetTextFont( EItemState state, const char* font )
	{
		ASSERT(font != NULL);
		if(state == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				if (m_stateData[i].font != NULL)
				{
					delete[] m_stateData[i].font;
					m_stateData[i].font = NULL;
				}
				m_stateData[i].font = new char[strlen(font) + 1];
				//! temp for Prevent
				int len = strlen(font) + 1;
				strncpy(m_stateData[i].font, font, len);
			}
		}
		else
		{
			if (m_stateData[state].font != NULL)
			{
				delete[] m_stateData[state].font;
				m_stateData[state].font = NULL;
			}
			m_stateData[state].font = new char[strlen(font) + 1];
			strncpy(m_stateData[state].font, font, strlen(font)+1);
		}
		if (state == E_STATE_ALL || state == m_curState)
		{
			t_text->SetFont(m_stateData[m_curState].font);
		}
	}

	char* CSelectButton::TextFont( EItemState state )
	{
		ASSERT(state < E_STATE_ALL);
		return m_stateData[state].font;
	}

	void CSelectButton::SetId( int itemId )
	{
		m_Id = itemId;
	}

	int CSelectButton::GetId()
	{
		return m_Id;
	}

	void CSelectButton::SetTextAlignment( EHAlignment hAlign, EVAlignment vAlign )
	{
		t_text->SetTextAlignment(hAlign , vAlign);
	}

	void CSelectButton::Show()
	{
		if (!m_stateData[E_STATE_NORMAL].bg_imagepath.empty())
		{
			t_BoxBgImage->setOpacity(m_stateData[E_STATE_NORMAL].boxbgOpacity);
			t_BoxBgImage->setSource(m_stateData[E_STATE_NORMAL].bg_imagepath.c_str());
			t_BoxBgImage->show();
		}
		if (!m_stateData[E_STATE_NORMAL].check_imagepath.empty())
		{
			t_CheckImage->setOpacity(m_stateData[E_STATE_NORMAL].checkOpacity);
			t_CheckImage->setSource(m_stateData[E_STATE_NORMAL].check_imagepath.c_str());
			t_CheckImage->show();
		}
		if (m_IsText)
		{
			t_text->SetText(m_stateData[E_STATE_NORMAL].textContent);
			if (m_stateData[E_STATE_NORMAL].fontSize != 0)
			{
				t_text->SetFontSize(m_stateData[E_STATE_NORMAL].fontSize);
			}
			t_text->Show();
		}
		ParentType::Show();
	}

	void CSelectButton::t_ChangeStateTo( EItemState toState )
	{
		if ((toState == m_curState && m_IsFocused ) || E_STATE_ALL == toState)
		{
			return;
		}
		if (m_HasBgImage)
		{
			if (!m_stateData[m_curState].bg_imagepath.empty() && m_stateData[toState].bg_imagepath.empty())
			{
				t_BoxBgImage->hide();
			}

			if ((toState == E_STATE_NORMAL || toState == E_STATE_SELECTED) && m_IsFocused && !m_stateData[E_STATE_FOCUSED].bg_imagepath.empty())
			{
				t_BoxBgImage->setOpacity(m_stateData[E_STATE_FOCUSED].boxbgOpacity);
				t_BoxBgImage->setSource(m_stateData[E_STATE_FOCUSED].bg_imagepath.c_str());
				t_BoxBgImage->show();

			}
			else if (!m_stateData[toState].bg_imagepath.empty())
			{
				t_BoxBgImage->setOpacity(m_stateData[toState].boxbgOpacity);
				t_BoxBgImage->setSource(m_stateData[toState].bg_imagepath.c_str());
				t_BoxBgImage->show();
			}
		}
		if (m_HasCheckImage)
		{
			if (!m_stateData[m_curState].check_imagepath.empty() && m_stateData[toState].check_imagepath.empty())
			{
				t_CheckImage->hide();
			}
			if (t_IsChecked)
			{
				if (m_IsFocused && !m_stateData[E_STATE_FOCUSED].check_imagepath.empty())
				{
					t_CheckImage->setOpacity(m_stateData[E_STATE_FOCUSED].checkOpacity);
					t_CheckImage->setSource(m_stateData[E_STATE_FOCUSED].check_imagepath.c_str());
					t_CheckImage->show();
				}
				else if (!m_IsFocused && !m_stateData[E_STATE_SELECTED].check_imagepath.empty())
				{
					t_CheckImage->setOpacity(m_stateData[E_STATE_SELECTED].checkOpacity);
					t_CheckImage->setSource(m_stateData[E_STATE_SELECTED].check_imagepath.c_str());
					t_CheckImage->show();
				}
			}
			else
			{
				if (!m_stateData[E_STATE_NORMAL].check_imagepath.empty())
				{
					t_CheckImage->setOpacity(m_stateData[E_STATE_NORMAL].checkOpacity);
					t_CheckImage->setSource(m_stateData[E_STATE_NORMAL].check_imagepath.c_str());
					t_CheckImage->show();
				}
				else
				{
					t_CheckImage->hide();
				}
			}
		}
		m_curState = toState;
		m_OnStateChange();
	}

	void CSelectButton::m_OnStateChange()
	{
		if(m_stateData[m_curState].font != NULL)
		{
			t_text->SetFont(m_stateData[m_curState].font);
		}
		if (m_IsText)
		{
			if(m_stateData[m_curState].textContent != NULL)
			{
				t_text->SetTextColor(m_stateData[m_curState].color);
				t_text->SetText(m_stateData[m_curState].textContent);
				if (m_stateData[m_curState].fontSize != 0)
				{
					t_text->SetFontSize(m_stateData[m_curState].fontSize);
				}
				t_text->Show();
			}
		}
	}

	bool CSelectButton::IsChecked()
	{
		return t_IsChecked;
	}

	void CSelectButton::m_Destory()
	{
		delete t_CheckImage;
		t_CheckImage = NULL;
		if (NULL != t_BoxBgImage)
		{
			delete t_BoxBgImage;
			t_BoxBgImage = NULL;
		}
		if (t_text != NULL)
		{
			t_text->Release();
		}
		for (int i = 0; i < E_STATE_ALL; i++)
		{
			if (m_stateData[i].textContent != NULL)
			{
				delete[] m_stateData[i].textContent;
			}
			if (m_stateData[i].font != NULL)
			{
				delete[] m_stateData[i].font;
			}
		}
		RemoveMouseListener(this);
		if (t_IsAutoFocused)
		{
			RemoveFocusListener(this);
		}
		RemoveKeyboardListener(this);
	}

	void CSelectButton::EnableChecked( bool isSelected )
	{
		t_IsEnableSelected = isSelected;
		EItemState state;
		if(isSelected)
		{
			state = E_STATE_NORMAL;
		}
		else
		{
			state = E_STATE_DISABLED;
		}

		CActor::Enable(isSelected);
		t_ChangeStateTo(state);
	}

	const char* CSelectButton::GetActorType(void)
	{
		return "BaseSelectButton";
	}


	bool CSelectButton::OnKeyPressed(IWidgetExtension* pThis, IKeyboardEvent* event)
	{
		if (t_IsAutoChecked)
		{
			int keyValue = event->GetKeyVal();
			if (keyValue == 65293)
			{
				if (IsChecked())
				{
					SetCheck(false);
				}
				else
				{
					SetCheck(true);
				}
				if (NULL != m_listener)
				{
					m_listener->OnCheckedChanged(this , this->IsChecked());
				}
			}
		}
		return true;
	}

	void CSelectButton::AddListener( OnButtonCheckedChangedListener *listener )
	{
		HALO_ASSERT(NULL != listener);
		m_listener = listener;
	}

	bool CSelectButton::OnFocusIn(IWidgetExtension* pWindow )
	{
		m_IsFocused = true;
// 		if (m_curState == E_STATE_SELECTED)
// 		{
// 			return true;
// 		}
		EItemState state;
		state = E_STATE_FOCUSED;
		t_ChangeStateTo(state);
		
		return true;
	}

	bool CSelectButton::OnFocusOut( IWidgetExtension* pWindow )
	{
		m_IsFocused = false;
// 		if (m_curState == E_STATE_SELECTED)
// 		{
// 			return true;
// 		}
		EItemState state;
		state = E_STATE_NORMAL;
		t_ChangeStateTo(state);
		return true;
	}

	void CSelectButton::SetBoxBackGroudImage( EItemState state, const std::string& iconPath )
	{
		HALO_ASSERT(state <= E_STATE_ALL);
		if (m_HasBgImage == false)
		{
			m_HasBgImage = true;
		}
		if (NULL == t_BoxBgImage)
		{
			t_BoxBgImage = new ImageWidget(0, 0 , dynamic_cast<Widget*>(this));
			if (NULL != t_BoxBgImage)
			{
				t_BoxBgImage->setWidth(t_itemW);
				t_BoxBgImage->setHeight(t_itemH);
				t_BoxBgImage->setAsyncLoading(m_Async);
				t_BoxBgImage->setCropOverflow(true);
			}
		}
		if(state == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				m_stateData[i].bg_imagepath = iconPath;
			}
		}
		else
		{
			m_stateData[state].bg_imagepath = iconPath;
		}
		if (state == E_STATE_ALL || state == m_curState)
		{
			t_BoxBgImage->setSource(m_stateData[m_curState].bg_imagepath.c_str());
			t_BoxBgImage->show();
		}
	}

	void CSelectButton::SetCheckImage( EItemState state, const std::string& iconPath )
	{
		if (m_HasCheckImage == false)
		{
			m_HasCheckImage = true;
		}
		
		if (NULL == t_CheckImage)
		{
			t_CheckImage = new ImageWidget(0, 0 , dynamic_cast<Widget*>(this));
			t_CheckImage->setWidth(t_itemW);
			t_CheckImage->setHeight(t_itemH);
			t_CheckImage->setAsyncLoading(m_Async);
		}
		
		if(state == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				m_stateData[i].check_imagepath = iconPath;
			}
		}
		else
		{
			m_stateData[state].check_imagepath = iconPath;
		}
		if (state == E_STATE_ALL || state == m_curState)
		{
			t_CheckImage->setSource(m_stateData[m_curState].check_imagepath.c_str());
			t_CheckImage->show();
		}
	}

	void CSelectButton::SetCheck( bool isChecked )
	{
		EItemState state;
		t_IsChecked = isChecked;
		if (isChecked)
		{
			state = E_STATE_SELECTED;
			t_ChangeStateTo(state);
		}
		else
		{
			state = E_STATE_NORMAL;
			t_ChangeStateTo(state);
		}
		if (!t_IsAutoChecked && NULL != m_listener)
		{
			m_listener->OnCheckedChanged(this , this->IsChecked());
		}
	}

	bool CSelectButton::Initialize( IActor *parent ,float width, float height )
	{
		if (ParentType::Initialize(parent , width , height) == false)
		{
			return false;
		}
		t_itemH = height;
		t_itemW = width;
		t_Initialize();
		return true;
	}

	bool CSelectButton::Initialize( Widget *parent ,float width, float height )
	{
		if (ParentType::Initialize(parent , width , height) == false)
		{
			return false;
		}
		t_itemH = height;
		t_itemW = width;
		t_Initialize();
		return true;
	}


	bool CSelectButton::OnMousePointerIn(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent )
	{
		if (t_IsAutoFocused)
		{
			SetFocus();
		}
		return true;
	}

	bool CSelectButton::OnMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent )
	{
		if (t_IsAutoFocused)
		{
			KillFocus();
		}
		return true;
	}

	void CSelectButton::UpdateImageAttr( float x , float y , float w , float h )
	{
		ASSERT(w < t_itemW || h < t_itemH);
		t_BoxBgImage->setWidth(w);
		t_BoxBgImage->setHeight(h);
		t_CheckImage->setWidth(w);
		t_CheckImage->setHeight(h);
		t_BoxBgImage->setX(x);
		t_BoxBgImage->setY(y);
		t_CheckImage->setX(x);
		t_CheckImage->setY(y);
	}

	void CSelectButton::SetAttachText( float x , float y , float w , float h )
	{
		t_text = IText::CreateInstance(dynamic_cast<Widget*>(this), w, h);
		if (t_text != NULL)
		{
			t_text->EnableEllipsize(true);
			t_text->SetTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
			t_text->SetPosition(x , y);
			m_IsText = true;
		}	
	}

	void CSelectButton::SetBoxBackGroudImageOpacity( EItemState state, int boxbgOpacity )
	{
		if (!m_HasBgImage)
		{
			return;
		}
		if(state == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				m_stateData[i].boxbgOpacity = boxbgOpacity;
			}
		}
		else
		{
			m_stateData[state].boxbgOpacity = boxbgOpacity;
		}
	}

	void CSelectButton::SetCheckImageOpacity( EItemState state, int checkOpacity )
	{
		if(state == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				m_stateData[i].checkOpacity = checkOpacity;
			}
		}
		else
		{
			m_stateData[state].checkOpacity = checkOpacity;
		}
	}

	void CSelectButton::SetAsyncLoading( const bool isAsync )
	{
		m_Async = isAsync;
	}

	bool CSelectButton::AsyncLoading( void ) const
	{
		return m_Async;
	}

	bool CSelectButton::OnMouseButtonPressed( IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent )
	{

		if (t_IsAutoChecked)
		{
			if (IsChecked())
			{
				SetCheck(false);
			}
			else
			{
				SetCheck(true);
			}
			if (NULL != m_listener)
			{
				m_listener->OnCheckedChanged(this , this->IsChecked());
			}
		}
		return true;
	}

	void CSelectButton::SetAutoFocusFlag( bool isAutoFocused )
	{
		t_IsAutoFocused = isAutoFocused;
	}

	void CSelectButton::SetFocusState( bool isFocused )
	{
		m_IsFocused = isFocused;
		EItemState state;
		if (isFocused)
		{
			state = E_STATE_FOCUSED;
			t_ChangeStateTo(state);
		}
		else
		{
			state = E_STATE_NORMAL;
			t_ChangeStateTo(state);
		}
	}

	void CSelectButton::SetAutoCheckFlag( bool isAutoChecked )
	{
		t_IsAutoChecked = isAutoChecked;
	}

	void CSelectButton::Resize( float width, float height )
	{
		ParentType::Resize(width , height);
		if (m_HasBgImage)
		{
			t_BoxBgImage->setHeight(height);
			t_BoxBgImage->setWidth(width);
		}
		if (m_HasCheckImage)
		{
			t_CheckImage->setHeight(height);
			t_CheckImage->setWidth(width);
		}
	}



}
