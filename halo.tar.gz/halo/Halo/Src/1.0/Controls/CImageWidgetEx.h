#ifndef _HALO_IMAGEWIDGETEX_H_
#define _HALO_IMAGEWIDGETEX_H_

namespace HALO
{
	class CImageWidgetEx : public ImageWidget, virtual public CWidgetExtension 
	{
	public:
		CImageWidgetEx(float x, float y, Widget* parent = nullptr, ImageWidgetReadyCallback ready = nullptr);
		CImageWidgetEx(float x, float y, float width, float height, Widget* parent = nullptr, ImageWidgetReadyCallback ready = nullptr);
		virtual ~CImageWidgetEx(void);

		//bool Initialize(ClutterActor* parent, float width, float height); 
		//bool Initialize(Widget* parent, float width, float height);
		//bool Initialize(IActor* parent, float width, float height);

		//Overload for orientation
		/** X position (pixels)*/
		float getX() const;
		void setX(float x);
		float getY() const;
		void setY(float y);
		float getWidth() const;
		void setWidth(float width);
		float getHeight() const;
		void setHeight(float height);
		virtual int addChild(Widget* child, int index);
		virtual Widget* getParent() const;
		virtual void setParent(Widget* newParent);

		//! Get actor type
		virtual const char* GetActorType(void);

		virtual void GetAnimatableValue(int animationType, UValueElement &val);
		virtual void SetPropertyValue(int animationType, UValueElement element);
	};
}


#endif
