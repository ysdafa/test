#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{


	IListItem* IListItem::CreateInstance( IActor* parent, float width, float height )
	{
		CListItem* item = dynamic_cast<CListItem*>(Instance::CreateInstance(CLASS_ID_ILISTITEM));

		if (NULL != item)
		{
			item->Initialize(parent , width , height);
		}

		return item;
	}


	IListSelectItem* IListSelectItem::CreateInstance( IActor* parent, float width, float height )
	{
		CListSelectItem* selectItem = dynamic_cast<CListSelectItem*>(Instance::CreateInstance(CLASS_ID_ILISTSElECTITEM));

		if (NULL != selectItem)
		{
			selectItem->Initialize(parent , width , height);
		}

		return selectItem;
	}

	IExpandableListItem* IExpandableListItem::CreateInstance( IActor* parent, float width, float height )
	{
		CExpandableListItem* expandableListItem = dynamic_cast<CExpandableListItem*>(Instance::CreateInstance(CLASS_ID_IEXPANDABLELISTITEM));

		if (NULL != expandableListItem)
		{
			expandableListItem->Initialize(parent , width , height);
		}

		return expandableListItem;
	}

}