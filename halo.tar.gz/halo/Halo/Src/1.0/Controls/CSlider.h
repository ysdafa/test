#ifndef _HALO_CSLIDER_H_
#define _HALO_CSLIDER_H_

namespace HALO
{
	class CSlider : virtual public ISlider, public CActor
	{
	public:
		//! CSlider constructor
		CSlider(void);

		//! CSlider destructor
		virtual ~CSlider(void);

		//! Create one CSlider instance
		bool Initialize(IActor* parent, float width, float height, EDirectionType direction);
		bool Initialize(Widget* parent, float width, float height, EDirectionType direction);

	public:
		//! Add Listener
		virtual bool AddListener(ISliderListener* listener);

		//! Remove Listener
		virtual bool RemoveListener(ISliderListener* listener);

	public:
		//! Sets the slider minimum and maximum values.
		virtual void SetMinMaxValue(int minValue, int maxValue);
		//! Gets the slider minimum and maximum values.
		virtual void GetMinMaxValue(int& minValue, int& maxValue);

		virtual int Value() const;
		virtual void SetValue(int val);

		virtual void SetThumbImage(IButton::EButtonState state, const std::string& imagePath);
		virtual void SetThumbColor(IButton::EButtonState state, const ClutterColor& color);
		virtual const ClutterColor& ThumbColor(IButton::EButtonState state) const;

		virtual void SetThumbSize(float width, float height);
		virtual void GetThumbSize(float &width, float &height) const;

		virtual void SetFillImage(IImageBuffer* image);
		virtual void SetFillColor(const ClutterColor& color);
		virtual const ClutterColor& FillColor(void);

		virtual void SetBackgroundImage(IImageBuffer* image);
		// IActor::SetBackgroundColor()

		virtual const char* GetActorType(void);

	private:
		void m_ValueChanged();
		void m_ThumbMoved();
		void m_SetDragArea(float width, float height);		// thumb size will effect it

	private:
		EDirectionType m_direction;

		int	m_minValue;
		int m_maxValue;
		int m_currentValue;

		IImage* m_fillImage;
		IImage* m_trackImage;
		IButton* m_thumbButton;

	private:
		std::set<ISliderListener *> m_listenerSet;
		//bool m_dragFlag;

		static void m_OnThumbDragMotion(ClutterDragAction   *action,
			ClutterActor        *actor,
			gfloat				delta_x,
			gfloat				delta_y,
			CSlider				*slider);

		static void m_OnSliderClick(ClutterClickAction   *action,
			ClutterActor        *actor,
			CSlider				*slider);

	private:
		CSlider(const CSlider&);
		CSlider& operator=(const CSlider&);
	};
}

#endif
