#ifndef _HALO_CCOMPOSITEIMAGE_H_
#define _HALO_CCOMPOSITEIMAGE_H_

namespace HALO
{
	class CCompositeImage: public virtual ICompositeImage, public CActor
	{
	public:
		CCompositeImage(void) : m_content(NULL), m_path(NULL) {}
		virtual ~CCompositeImage(void);

		virtual bool Initialize(IActor* parent, float width, float height);
		virtual bool Initialize(Widget* parent, float width, float height);

		virtual void SetImage(const char *imagePath);
		virtual void SetImage(IImageBuffer *buffer);
		virtual const char* ImagePath(void) { return m_path; }
		virtual const char* GetActorType(void);

	private:
		ClutterContent  *m_content;
		const char *m_path;

	};

} /* namespace HALO */
#endif /* _HALO_CCOMPOSITEIMAGE_H_ */
