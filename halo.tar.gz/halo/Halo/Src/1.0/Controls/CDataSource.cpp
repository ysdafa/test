#include "Halo1_0.h"
static HALO::util::Logger LOGGER("DataSource");
namespace HALO
{
	bool IData::IsReady(void) const
	{
		return isReady; 
	}

	void IData::SetReady(const bool readyFlag) 
	{
		isReady = readyFlag; 
	}

	int IData::NumOfWindow(void) const
	{
		return m_numOfWindow; 
	}

	/* CMatrixDataSource*/
	CMatrixDataSource::CMatrixDataSource(int numOfColumns)
	{
		GType * columnTypes = g_new0(GType, numOfColumns);
		gchar** columnNames = g_new0(gchar*, numOfColumns);
		for (int i = 0; i < numOfColumns; i++)
		{
			columnTypes[i] = G_TYPE_POINTER;
			columnNames[i] = g_strdup_printf("Col%d", i);;
		}
		m_model = clutter_list_model_newv(numOfColumns, columnTypes, columnNames);

		g_free(columnTypes);
		for (int i = 0; i < numOfColumns; i++)
		{
			g_free(columnNames[i]);
		}
		g_free(columnNames);

		m_listener = NULL;
	}

	CMatrixDataSource::~CMatrixDataSource(void)
	{
		g_object_unref(m_model);
		m_model = NULL;
	}

	void CMatrixDataSource::AddData(IData *data, int row, int col)
	{
		clutter_model_insert(m_model, row, col, data, -1);
		if (m_listener)
		{
			m_listener->OnDataChanged(DATA_ADDED, row, col);
		}
	}

	IData* CMatrixDataSource::RemoveData(int row, int col)
	{
		return NULL;
	}

	void CMatrixDataSource::DeleteData(int row, int col)
	{

	}

	void CMatrixDataSource::DeleteRow(int row)
	{
		std::vector<IData*> datas;
		datas.resize(ColCount());
		for (int i = 0; i < ColCount(); i++)
		{
			datas.push_back(GetData(row, i));
		}

		clutter_model_remove(m_model, row);
		if (m_listener)
		{
			m_listener->OnDataChanged(DATA_REMOVED, row, -1);
		}

		std::vector<IData*>::iterator it = datas.begin();
		for (; !datas.empty(); )
		{
			delete (*it);
			it = datas.erase(it);
		}
	}

	void CMatrixDataSource::DeleteColumn(int column)
	{

	}

	void CMatrixDataSource::DeleteAll(void)
	{
		while (RowCount())
		{
			DeleteRow(0);
		}
	}

	IData* CMatrixDataSource::GetData(int row, int col)
	{
		ClutterModelIter *iter;
		GValue value = { 0, };
		IData *data = NULL;

		iter = clutter_model_get_iter_at_row(m_model, row);
		clutter_model_iter_get_value(iter, col, &value);
		data = static_cast<IData*>(g_value_get_pointer(&value));

		g_value_unset(&value);
		g_object_unref(iter);

		return data;
	}

	int CMatrixDataSource::RowCount(void)
	{
		return clutter_model_get_n_rows(m_model);
	}

	int CMatrixDataSource::ColCount(void)
	{
		return clutter_model_get_n_columns(m_model);
	}

	void CMatrixDataSource::AddListener(CMatrixDataSourceListener *listener)
	{
		m_listener = listener;
	}

	/* CListDataSource*/
	CSingleLineDataSource::CSingleLineDataSource(void)
	{
		
	}

	CSingleLineDataSource::~CSingleLineDataSource(void)
	{
		for (int i = 0; i < (int)m_dataList.size(); i++)
		{
			if (NULL != m_dataList[i])
			{
				delete m_dataList[i];
			}
		}

		m_dataList.clear();
	}

	void CSingleLineDataSource::AddData(IData *data)
	{
		m_dataList.push_back(data);
	}

	void CSingleLineDataSource::InsertData(int index, IData *data)
	{
		m_dataList.insert(m_dataList.begin() + index, data);
	}

	void CSingleLineDataSource::DeleteData(int itemIndex)
	{
		HALO_ASSERT(itemIndex >= 0 && itemIndex < (int)m_dataList.size());

		m_dataList[itemIndex]->Release();
		m_dataList[itemIndex] = NULL;
		std::vector<IData*>::iterator iter = m_dataList.begin();
		m_dataList.erase(iter + itemIndex);
	}

	void CSingleLineDataSource::DeleteAll(void)
	{
		size_t dataCount = m_dataList.size();
		for (size_t i = 0; i < dataCount; i++)
		{
			m_dataList[i]->Release();
			m_dataList[i] = NULL;
		}
		m_dataList.clear();
	}

	int CSingleLineDataSource::NumOfData(void)
	{
		return m_dataList.size();
	}

	IData* CSingleLineDataSource::GetData(int itemIndex)
	{
		return m_dataList.at(itemIndex);
	}

	int CSingleLineDataSource::Size(void)
	{
		return m_dataList.size();
	}

	CGridDataSource::CGridDataSource(void)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridDataSource::CGridDataSource");

	}

	CGridDataSource::~CGridDataSource(void)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridDataSource::~CGridDataSource");

	}


	void CGridDataSource::AddGroup(int numberOfGroup)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridDataSource::AddGroup with number " << numberOfGroup);

		for (int i = 0; i < numberOfGroup; i++)
		{
			std::vector<IData*> newGroup;
			m_dataList.push_back(newGroup);
		}
	}

	void CGridDataSource::AddData(int groupIndex, IData *data)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridDataSource::AddData to group " << groupIndex << ", with data " << "0x" << std::hex << (int)data);

		HALO_ASSERT(groupIndex >= 0 && groupIndex < (int)m_dataList.size());
		m_dataList.at(groupIndex).push_back(data);
	}

	int CGridDataSource::NumOfGroup(void)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridDataSource::NumOfGroup");
		return m_dataList.size();
	}

	int CGridDataSource::NumOfData(int groupIndex)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridDataSource::NumOfData in group " << groupIndex);
		HALO_ASSERT(groupIndex >= 0 && groupIndex < (int)m_dataList.size());
		return m_dataList.at(groupIndex).size();
	}

	IData* CGridDataSource::GetData(int groupIndex, int itemIndex)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridDataSource::GetData in group " << groupIndex << ", itemIndex " << itemIndex);
		HALO_ASSERT(groupIndex >= 0 && groupIndex < (int)m_dataList.size());
		HALO_ASSERT(itemIndex >= 0 && itemIndex < (int)m_dataList.at(groupIndex).size());

		return m_dataList.at(groupIndex).at(itemIndex);
	}


	void CGridDataSource::DeleteGroup(int groupIndex)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridDataSource::DeleteGroup with groupIndex " << groupIndex);
		HALO_ASSERT(groupIndex >= 0 && groupIndex < (int)m_dataList.size());
		
		while (!m_dataList.at(groupIndex).empty())
		{
			DeleteData(groupIndex, (int)m_dataList.at(groupIndex).size() - 1);
		}
		m_dataList.erase(m_dataList.begin() + groupIndex);
	}

	void CGridDataSource::DeleteData(int groupIndex, int itemIndex)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridDataSource::DeleteData with index (" << groupIndex << ", " << itemIndex << ")");
		HALO_ASSERT(groupIndex >= 0 && groupIndex < (int)m_dataList.size());
		HALO_ASSERT(itemIndex >= 0 && itemIndex < (int)m_dataList.at(groupIndex).size());

		m_listener->OnDataChanged(DATA_REMOVED, groupIndex, itemIndex);

		m_dataList[groupIndex][itemIndex]->Release();
		m_dataList.at(groupIndex).erase(m_dataList.at(groupIndex).begin() + itemIndex);
	}

	void CGridDataSource::DeleteAll(void)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridDataSource::DeleteAll");
		while (!m_dataList.empty())
		{
			DeleteGroup((int)m_dataList.size() - 1);
		}
		m_dataList.clear();
	}

	void CGridDataSource::InsertData(IData* data, int groupIndex, int itemIndex)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridDataSource::InsertData to index (" << groupIndex << ", " << itemIndex << "), with data 0x" << std::hex << (int)data);
		HALO_ASSERT(groupIndex >= 0 && groupIndex < (int)m_dataList.size());
		HALO_ASSERT(itemIndex >= 0 && itemIndex < (int)m_dataList.at(groupIndex).size());

		m_dataList.at(groupIndex).insert(m_dataList[groupIndex].begin() + itemIndex, data);
	}

	void CGridDataSource::SetListener(CGridDataSourceListener* listener)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridDataSource::SetListener with " << listener);

		HALO_ASSERT(listener != NULL);
		m_listener = listener;
	}


	void CFirstScreenDataSource::AddMainMenuData(IData *data)
	{
		TMainMenuItem *mainItem = new TMainMenuItem;
		mainItem->mainMenuData = data;

		dataList.push_back(mainItem);
	}

	void CFirstScreenDataSource::AddScrollDataInMainMenu(IData *data, int mainMenuIndex)
	{
		HALO_ASSERT(mainMenuIndex < (int)dataList.size());

		TMainMenuItem *mainItem = dataList[mainMenuIndex];
		mainItem->scrollDataSource.AddData(data);
	}

	void CFirstScreenDataSource::AddSubMenuData(IData *data, int mainMenuIndex)
	{
		HALO_ASSERT(mainMenuIndex < (int)dataList.size());

		TMainMenuItem *mainItem = dataList[mainMenuIndex];
		mainItem->subMenuDataSource.AddData(data);
	}

	void CFirstScreenDataSource::DeleteSubMenuData(int mainMenuIndex, int subMenuItemIndex)
	{

	}

	IData* CFirstScreenDataSource::MainMenuData(int menuItemIndex)
	{
		return dataList[menuItemIndex]->mainMenuData;
	}

	CSingleLineDataSource* CFirstScreenDataSource::ScrollDataSource(int menuItemIndex)
	{
		return &(dataList[menuItemIndex]->scrollDataSource);
	}

	CSingleLineDataSource* CFirstScreenDataSource::SubMenuDataSource(int menuItemIndex)
	{
		return &(dataList[menuItemIndex]->subMenuDataSource);
	}

	IData* CFirstScreenDataSource::ScrollData(int menuItemIndex, int scrollDataIndex)
	{
		return dataList[menuItemIndex]->scrollDataSource.GetData(scrollDataIndex);
	}

	IData* CFirstScreenDataSource::SubMenuData(int menuItemIndex, int subMenuItemIndex)
	{
		return dataList[menuItemIndex]->subMenuDataSource.GetData(subMenuItemIndex);
	}

	int CFirstScreenDataSource::NumOfMainMenuData(void)
	{
		return (int)dataList.size();
	}

	int CFirstScreenDataSource::NumOfScrollData(int menuItemIndex)
	{
		return (int)dataList[menuItemIndex]->scrollDataSource.Size();
	}

	int CFirstScreenDataSource::NumOfSubData(int menuItemIndex)
	{
		return (int)dataList[menuItemIndex]->subMenuDataSource.Size();
	}
}