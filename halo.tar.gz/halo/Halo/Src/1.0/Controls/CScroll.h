#ifndef _HALO_CSCROLL_H_
#define _HALO_CSCROLL_H_

namespace HALO
{
	class CScroll : virtual public IScroll, public CActor, public IMouseListener
	{
	public:
		CScroll();

		virtual ~CScroll();

		// Create scroll, default style is TYPE_VERTICAL
		virtual bool Initialize(IActor* parent, float width, float height, EDirectionType direction);
		virtual bool Initialize(Widget* parent, float width, float height, EDirectionType direction);

	public:
		//! Add Listener
		virtual bool AddListener(IScrollListener* listener);

		//! Remove Listener
		virtual bool RemoveListener(IScrollListener* listener);

	private:
		//! The callback function when mouse pointer in.
		virtual bool OnMousePointerIn(IActor* pWindow, IMouseEvent* ptrMouseEvent);

		//! The callback function when mouse pointer out.
		virtual bool OnMousePointerOut(IActor* pWindow, IMouseEvent* ptrMouseEvent);

		virtual bool OnMouseButtonPressed(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnMouseButtonReleased(IActor* pWindow, IMouseEvent* ptrMouseEvent);

	public:
		// Implement interface IScroll
		virtual EDirectionType DirectionType(void) const;

		//! Sets the minimum value of SCScroll window.
		virtual void SetMinValue(int minValue);
		//! Get min value
		virtual int MinValue(void) const;

		//! Sets the maximum value of SCScroll bar.
		virtual void SetMaxValue(int maxValue);
		//! Get max value
		virtual int MaxValue(void) const;

		//! Update Scrollbar position 
		virtual void SetValue(int value);
		//! Get Scrollbar position 
		virtual int Value(void) const;

		virtual void SetMinCurMaxValue(int minValue, int curValue, int maxValue);
		virtual void GetMinCurMaxValue(int &minValue, int &curValue, int &maxValue) const;

		virtual void SetActive(bool flagActive);
		virtual bool FlagActive(void) const;

		// Override SetTopTrackColor
		virtual void SetBackgroundColor(const ClutterColor& topTrackColor);

		// track shadow area: normal/over state
		virtual void SetTrackShadowColor(const ClutterColor& bottomTrackColor);
		virtual const ClutterColor& TrackShadowColor(void) const;

		virtual void SetTrackShadowHeight(float bottomTrackHeight);
		virtual float TrackShadowHeight(void) const;

		// background image: pointing normal
		virtual void SetPointingNormalBackgroundImage(const std::string& pointingNormalBackgroundImage);
		virtual std::string PointingNormalBackgroundImage(void) const;

		// background image: pointing over state
		virtual void SetPointingOverBackgroundImage(const std::string& pointingOverBackgroundImage);
		virtual std::string PointingOverBackgroundImage(void) const;

		virtual void SetRolloverTrackHeight(float height);
		virtual float RolloverTrackHeight(void) const;

		// Thumb Image: pointing normal
		virtual void SetPointingNormalThumbImage(const std::string& pointingNormalThumbImagePath);
		virtual std::string PointingNormalThumbImage(void) const;

		virtual void SetPointingNormalThumbSize(float width, float height);
		virtual void GetPointingNormalThumbSize(float &width, float &height);

		// Thumb Image: pointing over
		virtual void SetPointingOverThumbImage(const std::string& pointingOverThumbImagePath);
		virtual std::string PointingOverThumbImage(void) const;

		virtual void SetPointingOverThumbSize(float width, float height);
		virtual void GetPointingOverThumbSize(float &width, float &height);

		// Thumb Image: pointing focus
		virtual void SetPointingFocusThumbImage(const std::string& pointingFocusThumbImagePath);
		virtual std::string PointingFocusThumbImage(void) const;

		virtual void SetPointingFocusThumbSize(float width, float height);
		virtual void GetPointingFocusThumbSize(float &width, float &height);

	public:
		//override CActor::SetOrientation
		//virtual void SetOrientation(EOrientation orientation);

	public:
		virtual void SetPreviousArrowImage(IButton::EButtonState state, const std::string& imagePath);
		virtual void SetPreviousArrowSize(float width, float height);
		virtual void GetPreviousArrowSize(float &width, float &height);

		virtual void SetNextArrowImage(IButton::EButtonState state, const std::string& imagePath);
		virtual void SetNextArrowSize(float width, float height);
		virtual void GetNextArrowSize(float &width, float &height);

		virtual void SetLongPressIntervalOnArrowButton(int timeInterval);
		virtual void SetMovingStepOnArrowButton(int moveStep);

		virtual const char* GetActorType(void);

	protected:
		//! Override for CActor::SetOrientation(EOrientation orientation)
		virtual void t_UpdateOrientation(EOrientation orientation);

	private:
		void m_ValueChanged();
		void m_ThumbMoved();

	private:
		int m_minValue;
		int m_maxValue;
		int m_currentValue;
		EDirectionType m_direction;
		bool m_active;

		ICompositeImage *m_trackAreaActor;
		//IActor *m_trackAreaActor;
		IActor *m_trackTopActor;
		IActor *m_trackShadowActor;

		float m_normalTrackTopHeight;		// normal state
		float m_rolloverTopTrackHeight;		// rollover/focus state
		ClutterColor m_topTrackColor;

		float m_bottomTrackHeight;
		ClutterColor m_bottomTrackColor;

		//IActor *m_thumbActor;
		//ImageWidget *m_thumbImageWidget;
		ICompositeImage *m_thumbImage;

		std::string m_pointingNormalBackgroundImagePath;
		std::string m_pointingOverBackgroundImagePath;

		float m_pointingNormalThumbImageWidth;
		float m_pointingNormalThumbImageHeight;
		std::string m_pointingNormalThumbImagePath;

		float m_pointingOverThumbImageWidth;
		float m_pointingOverThumbImageHeight;
		std::string m_pointingOverThumbImagePath;

		float m_pointingFocusThumbImageWidth;
		float m_pointingFocusThumbImageHeight;
		std::string m_pointingFocusThumbImagePath;

	private:
		IButton* m_previousButton;
		IButton* m_nextButton;

		// for long press
		int m_timeInterval;
		int m_moveStep;
		guint m_longPressTimerId;


	private:
		void m_SetDragArea();
		std::set<IScrollListener *> m_listenerSet;

	private:
		static void m_OnThumbDragMotion (ClutterDragAction   *action,
			ClutterActor        *actor,
			gfloat				delta_x,
			gfloat				delta_y,
			CScroll				*scroll);

		static void m_OnPreButtonClicked(ClutterClickAction *action,
			ClutterActor		*actor,
			CScroll				*scroll);

		static void m_OnNextButtonClicked(ClutterClickAction *action,
			ClutterActor       *actor,
			CScroll *scroll);

		static gboolean m_OnPreButtonLongPress(ClutterClickAction   *action,
			ClutterActor			*actor,
			ClutterLongPressState	state,
			CScroll					*scroll);

		static gboolean m_OnNextButtonLongPress(ClutterClickAction   *action,
			ClutterActor			*actor,
			ClutterLongPressState	state,
			CScroll					*scroll);

		static gboolean m_PreButtonLongPress(gpointer data);
		static gboolean m_NextButtonLongPress(gpointer data);

		static void m_OnScrollClick(ClutterClickAction   *action,
			ClutterActor        *actor,
			CScroll				*scroll);

	private:
		CScroll(const CScroll&);
		CScroll& operator=(const CScroll&);
	};

}

#endif
