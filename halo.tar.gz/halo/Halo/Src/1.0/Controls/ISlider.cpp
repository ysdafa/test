#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	ISlider* ISlider::CreateInstance(IActor* parent, float width, float height, EDirectionType direction)
	{
		CSlider* slider = dynamic_cast<CSlider*>(Instance::CreateInstance(CLASS_ID_ISLIDER));
		ASSERT(slider != NULL);

		if (slider != NULL)
		{
			slider->Initialize(parent, width, height, direction);  
		}

		return slider;
	}

	ISlider* ISlider::CreateInstance(Widget* parent, float width, float height, EDirectionType direction)
	{
		CSlider* slider = dynamic_cast<CSlider*>(Instance::CreateInstance(CLASS_ID_ISLIDER));
		ASSERT(slider != NULL);

		if (slider != NULL)
		{
			slider->Initialize(parent, width, height, direction);
		}

		return slider;
	}

}