#include "Halo1_0.h"

namespace HALO
{
	CCheckBoxGroup::CCheckBoxGroup()
	{

	}

	CCheckBoxGroup::~CCheckBoxGroup()
	{
		m_Destory();
	}

	void CCheckBoxGroup::m_Destory()
	{
		m_CheckSate.clear();
	}


	const char* CCheckBoxGroup::GetActorType(void)
	{
		return "CheckBoxGroup";
	}

	void CCheckBoxGroup::t_ProcessSelect( class ISelectButton* button , bool ischecked )
	{
	
	}

	bool CCheckBoxGroup::Initialize()
	{
		return t_Initialize();
	}

	std::vector<int> CCheckBoxGroup::GetSelectedItemIndexes()
	{
		m_CheckSate.clear();
		for (int index = 0; index < t_itemNum; index++)
		{
			if (t_itemList[index]->IsChecked())
			{
				m_CheckSate.push_back(t_itemList[index]->GetId());
			}
		}
		return m_CheckSate;
	}

}




