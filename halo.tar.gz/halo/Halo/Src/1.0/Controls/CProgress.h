#ifndef _HALO_CPROGRESS_H_
#define _HALO_CPROGRESS_H_

namespace HALO
{
	class CProgress : virtual public IProgress, public CActor, public IMouseListener, public IFocusListener
	{
	public:
		CProgress();

		virtual ~CProgress();

		virtual bool Initialize(IActor* parent, float width, float height, EDirectionType direction);
		virtual bool Initialize(Widget* parent, float width, float height, EDirectionType direction);

	public:
		//! The callback function when mouse pointer in.
		virtual bool OnMousePointerIn(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);

		//! The callback function when mouse pointer out.
		virtual bool OnMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);

		virtual bool OnFocusIn(IWidgetExtension* pWindow);

		virtual bool OnFocusOut(IWidgetExtension* pWindow);

		//! Add Listener
		virtual bool AddListener(IProgressListener* listener);

		//! Remove Listener
		virtual bool RemoveListener(IProgressListener* listener);

	public:
		//! Sets the progress bar image.
		virtual void SetProgressImage(IImageBuffer* image);
		virtual void SetProgressColor(const ClutterColor& color);
		//virtual const ClutterColor& ProgressColor(void);

		//! Sets the background bar image.
		virtual void SetBackgroundImage(IImageBuffer* image);
		virtual void SetBackgroundColor(const ClutterColor& color);
		//virtual const ClutterColor& BackgroundColor(void);

		virtual void SetMinValue(int minValue);
		virtual int MinValue(void) const;

		virtual void SetMaxValue(int maxValue);
		virtual int MaxValue(void) const;

		//! Sets current progress value.
		virtual void SetValue(int value);
		//! Gets current progress value.
		virtual int Value(void) const;

		//! Set the scroll to move on reverse direction (right to left / bottom to top) when the flag is true.
		virtual void SetReverse(bool flagReverse);
		//! Get the reverse scroll flag
		virtual bool FlagReverse(void) const;

		virtual void SetNormalThumbImage(const std::string& normalThumbImagePath);
		virtual std::string NormalThumbImage(void) const;

		virtual void SetFocusThumbImage(const std::string& focusThumbImagePath);
		virtual std::string FocusThumbImage(void) const;

		virtual void SetThumbSize(float width, float height);
		virtual void GetThumbSize(float &width, float &height) const;

		virtual void SetActive(bool flagActive);
		virtual bool FlagActive(void) const;

	public:
		virtual const char* GetActorType(void);

		//! Resize current window
		virtual void Resize(float width, float height);

	protected:
		//! Override for CActor::SetOrientation(EOrientation orientation)
		//virtual void t_UpdateOrientation(EOrientation orientation);

	private:
		EDirectionType m_direction;
		bool m_reverseFlag;

		IImage* m_bgImage;
		IImage* m_progressImage;

		//IActor *m_thumbActor;
		//ImageWidget *m_thumbImageWidget;
		ICompositeImage *m_thumbImage;

		std::string m_normalThumbImage;
		std::string m_focusThumbImage;
		bool m_active;

		int m_minValue;
		int m_value;
		int m_maxValue;

		std::set<IProgressListener *> m_listenerSet;

	private:
		void m_ValueChanged();
		void m_ThumbMoved();
		void m_OnProgressClick(float x, float y);
		void m_SetDragArea();		// thumb size will effect it;

	private:
		void m_SetAlignConstraint();

		static void m_OnThumbDragMotion(ClutterDragAction   *action,
			ClutterActor        *actor,
			gfloat				delta_x,
			gfloat				delta_y,
			CProgress			*progress);

		static void m_OnProgressClicked(ClutterClickAction   *action,
			ClutterActor        *actor,
			CProgress			*progress);
		
	private:
		CProgress(const CProgress&);
		CProgress& operator=(const CProgress&);
	};
}

#endif
