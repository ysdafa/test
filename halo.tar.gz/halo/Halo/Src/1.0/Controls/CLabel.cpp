#include "Halo1_0.h"

namespace HALO
{
	static HALO::util::Logger LOGGER("CLabel");

	CLabel::~CLabel()
	{
		H_LOG_TRACE(LOGGER, "CLabel::~CLabel()");

		delete m_text;
		m_text = NULL;

		delete m_image;
		m_image = NULL;
	}

	bool CLabel::Initialize(IActor* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CLabel::Initialize(" << parent << ", " << width << ", " << height << ")");
		Widget *cParent = dynamic_cast<Widget*>(parent);

		return Initialize(cParent, width, height);
	}

	bool CLabel::Initialize(Widget* parent, float width, float height)
	{
		//ASSERT(parent != NULL);
		CActor::Initialize(parent, width, height);

		Widget *widget = dynamic_cast<Widget*>(this);
		if (widget != NULL)
		{
			m_image = IImage::CreateInstance(widget, width, height);
			m_text = IText::CreateInstance(widget, width, height);
			m_text->EnableEllipsize(true);
		}

		return true;
	}

	void CLabel::SetImage( IImageBuffer* imageBuffer )
	{
		H_LOG_TRACE(LOGGER, "CLabel::SetImage(" << imageBuffer << ")");

		ASSERT(imageBuffer != NULL);

		m_image->SetImage(imageBuffer);
	}

	void CLabel::SetText( const char* text )
	{
		H_LOG_TRACE(LOGGER, "CLabel::SetText(" << text << ")");

		ASSERT(text != NULL);

		m_text->SetText(text);
	}

	const char* CLabel::Text( void ) const
	{
		H_LOG_TRACE(LOGGER, "CLabel::Text()");

		return m_text->Text();
	}

	void CLabel::SetTextColor( const ClutterColor& color )
	{
		H_LOG_TRACE(LOGGER, "CLabel::SetTextColor()");

		m_text->SetTextColor(color);
	}

	const ClutterColor& CLabel::TextColor( void )
	{
		H_LOG_TRACE(LOGGER, "CLabel::TextColor()");

		return m_text->TextColor();
	}

	void CLabel::SetFontSize( int size )
	{
		H_LOG_TRACE(LOGGER, "CLabel::SetFontSize(" << size << ")");

		m_text->SetFontSize(size);
	}

	int CLabel::FontSize( void ) const
	{
		H_LOG_TRACE(LOGGER, "CLabel::FontSize()");

		return m_text->FontSize();
	}

	IText* CLabel::TextActor( void )
	{
		H_LOG_TRACE(LOGGER, "CLabel::TextActor()");

		return m_text;
	}

	IImage* CLabel::ImageActor( void )
	{
		H_LOG_TRACE(LOGGER, "CLabel::ImageActor()");

		return m_image;
	}

	void CLabel::SetTextFont( const char* font )
	{
		H_LOG_TRACE(LOGGER, "CLabel::SetTextFont(" << font << ")");

		ASSERT(font != NULL);

		m_text->SetFont(font);
	}

	const char* CLabel::TextFont() const
	{
		H_LOG_TRACE(LOGGER, "CLabel::TextFont()");

		return m_text->Font();
	}

	void CLabel::EnableMultiLine(bool flagMutliLineMode)
	{
		H_LOG_TRACE(LOGGER, "CLabel::EnableMultiLine(" << flagMutliLineMode << ")");

		m_text->EnableMultiLine(flagMutliLineMode);
	}

	bool CLabel::IsMultiLineEnabled(void)
	{
		H_LOG_TRACE(LOGGER, "CLabel::IsMultiLineEnabled()");

		return m_text->IsMultiLineEnabled();
	}

	const char* CLabel::GetActorType(void)
	{
		return "Label";
	}

}