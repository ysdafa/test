#include "Halo1_0.h"

namespace HALO
{
	IThumbnail* IThumbnail::CreateInstance(Widget* parent, float width, float height, EThumbnailStyles styles, EThumbnailStyles visibleStyles, const TThumbnailAttr& attr)
	{
		CThumbnail* thumbnail = dynamic_cast<CThumbnail*>(Instance::CreateInstance(CLASS_ID_ITHUMBNAIL));

		if (NULL != thumbnail)
		{
			thumbnail->Initialize(parent, width, height, styles, visibleStyles, attr);
		}

		return thumbnail;
	}
}