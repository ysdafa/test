#include "Halo1_0.h"

#define TEST_DEBUG	1

#if 1 == TEST_DEBUG
#define TEST(x) (x)
#else
#define TEST(x)
#endif

#ifdef WIN32
#include <windows.h> 
#endif

#define HALO_MIN(a,b)            (((a) < (b)) ? (a) : (b))

static HALO::util::Logger LOGGER("SingleLineListControl");

namespace HALO
{
	class CSingleLineListControlListenerSet : public ListenerSet
	{
	public:
		struct TSingleLineListListenerData
		{
			TSingleLineListListenerData(void) : pData(NULL) {};
			int type;
			int param[4];
			void* pData;
		};

		CSingleLineListControlListenerSet(CSingleLineListControl* owner) :m_owner(owner){};
		virtual ~CSingleLineListControlListenerSet(void){};

		virtual bool Process(TSingleLineListListenerData* data);

	private:
		CSingleLineListControl* m_owner;
	};

	bool CSingleLineListControlListenerSet::Process(TSingleLineListListenerData* data)
	{
		bool ret = false;
		Lock();

		if (NULL != data)
		{
			ListenerList::iterator iter = m_list.begin();

			while (iter != m_list.end())
			{
				ISingleLineListControlListener* listener = (ISingleLineListControlListener*)(*iter);

				switch (data->type)
				{
				case CSingleLineListControl::EVENT_FOCUS_CHANGE:
					H_LOG_DEBUG(LOGGER, "[" << m_owner << "]CSingleLineListControl::EVENT_FOCUS_CHANGE (" << data->param[0] << "," << data->param[1] << ")Listener--start");
					ret |= listener->OnFocusChanged(m_owner, data->param[0], data->param[1]);
					H_LOG_DEBUG(LOGGER, "CSingleLineListControl::EVENT_FOCUS_CHANGE Listener--end");
					break;
				case CSingleLineListControl::EVENT_FOCUS_CHANGE_MOTION_START:
					H_LOG_DEBUG(LOGGER, "[" << m_owner << "]CSingleLineListControl::EVENT_FOCUS_CHANGE_MOTION_START (" << data->param[0] << "," << data->param[1] << "," << data->param[2] << "," << data->param[3] << ")Listener--start");
					ret |= listener->OnFocusChangeMotionStart(m_owner, data->param[0], data->param[1]);
					H_LOG_DEBUG(LOGGER, "CSingleLineListControl::EVENT_FOCUS_CHANGE_MOTION_START Listener--end");
					break;
				case CSingleLineListControl::EVENT_ITEM_LOAD:
					H_LOG_DEBUG(LOGGER, "[" << m_owner << "]CSingleLineListControl::EVENT_ITEM_LOAD (" << data->param[0] << "," << data->param[1] << ")Listener--start");
					ret |= listener->OnItemLoaded(m_owner, (IData*)(data->pData), data->param[0]);
					H_LOG_DEBUG(LOGGER, "CSingleLineListControl::EVENT_ITEM_LOAD Listener--end");
					break;
				case CSingleLineListControl::EVENT_ITEM_ASYNC_LOAD:
					H_LOG_DEBUG(LOGGER, "[" << m_owner << "]CSingleLineListControl::EVENT_ITEM_ASYNC_LOAD (" << data->param[0] << "," << data->param[1] << ")Listener--start");
					ret |= listener->OnAsyncItemLoad(m_owner, (IData*)(data->pData), data->param[0]);
					H_LOG_DEBUG(LOGGER, "CSingleLineListControl::EVENT_ITEM_ASYNC_LOAD Listener--end");
					break;
				case CSingleLineListControl::EVENT_ITEM_UNLOAD:
					H_LOG_DEBUG(LOGGER, "[" << m_owner << "]CSingleLineListControl::EVENT_ITEM_UNLOAD (" << data->param[0] << "," << data->param[1] << ")Listener--start");
					ret |= listener->OnItemUnloaded(m_owner, (IData*)(data->pData), data->param[0]);
					H_LOG_DEBUG(LOGGER, "CSingleLineListControl::EVENT_ITEM_UNLOAD Listener--end");
					break;
				case CSingleLineListControl::EVENT_MOVE_OUT:
					H_LOG_DEBUG(LOGGER, "[" << m_owner << "]CSingleLineListControl::EVENT_MOVE_OUT (" << data->param[0] << "," << data->param[1] << ")Listener--start");
					ret |= listener->OnMoveOut(m_owner, (EDirection)data->param[0], data->param[1]);
					H_LOG_DEBUG(LOGGER, "CSingleLineListControl::EVENT_MOVE_OUT Listener--end");
					break;

				case CSingleLineListControl::EVENT_ITEM_CLICKED:
					H_LOG_DEBUG(LOGGER, "[" << m_owner << "]CSingleLineListControl::EVENT_ITEM_CLICKED (" << data->param[0] << "," << data->param[1] << ")Listener--start");
					ret |= listener->OnItemClicked(m_owner, data->param[0]);
					H_LOG_DEBUG(LOGGER, "CSingleLineListControl::EVENT_ITEM_CLICKED Listener--end");
					break;

				case CSingleLineListControl::EVENT_ENTER_KEY_LONG_PRESSED:
					H_LOG_DEBUG(LOGGER, "[" << m_owner << "]CSingleLineListControl::EVENT_ENTER_KEY_LONG_PRESSED (" << data->param[0] << ")Listener--start");
					ret |= listener->OnEnterKeyLongPressed(m_owner, data->param[0]);
					H_LOG_DEBUG(LOGGER, "CSingleLineListControl::EVENT_ENTER_KEY_LONG_PRESSED Listener--end");
					break;

				default:
					break;
				}
				if (m_list.empty())
				{
					break;
				}
				
				iter++;
			}
		}

		Unlock();
		return ret;
	}

	CSingleLineListControl::CSingleLineListControl()
	{
		H_LOG_0_PARAM(FATAL, LOGGER);
		m_curFocusItem = 0;

		m_frontBufferCnt = 1;
		m_backBufferCnt = 1;

		m_dataSource = NULL;

		m_listenerSet = NULL;

		m_currentClickedItemIndex = -1;

		m_flagUseMarginWhenFocusEdgeItem = true;

		m_xFactor = m_yFactor = m_zFactor = 0.0f;

		m_flagAutoFix = true;
	}

	CSingleLineListControl::~CSingleLineListControl()
	{
		H_LOG_0_PARAM(FATAL, LOGGER);
		t_StopAnimation(LIST_ANI_TYPE_MAX);

		//delete m_listenerSet;
		if (m_listenerSet)
		{
			if (m_listenerSet->IsLocked())
			{
				m_listenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(m_listenerSet);
			} 
			else
			{
				delete m_listenerSet;
			}
			m_listenerSet = NULL;
		}
		

		m_curFocusItem = -1;
	}

	bool CSingleLineListControl::Initialize(IActor *parent, const TSingleLineListControlAttr &attr)
	{
		TLinearListControlAttr linearAttr(attr.width, attr.height, attr.type);
		CLinearListControl::t_Initialize(parent, linearAttr);

		m_dataSource = new CSingleLineDataSource;
		t_type = attr.type;

		m_listenerSet = new class CSingleLineListControlListenerSet(this);

		return true;
	}

	bool CSingleLineListControl::Initialize(Widget *parent, const TSingleLineListControlAttr &attr)
	{
		TLinearListControlAttr linearAttr(attr.width, attr.height, attr.type);
		CLinearListControl::t_Initialize(parent, linearAttr);

		m_dataSource = new CSingleLineDataSource;
		t_type = attr.type;

		m_listenerSet = new class CSingleLineListControlListenerSet(this);

		return true;
	}

	ISingleLineDataSource * CSingleLineListControl::GetDataSource(void)
	{
		return m_dataSource;
	}

	IRenderer* CSingleLineListControl::Renderer(int itemIndex)
	{
		TItem *item = t_itemList[itemIndex];

		if (NULL != item)
		{
			return item->renderer;
		}
		else
		{
			return NULL;
		}
	}

	void CSingleLineListControl::SetFocusItemIndex(const int itemIndex)
	{
		H_LOG_1_PARAM(FATAL, LOGGER, itemIndex);
		m_curFocusItem = itemIndex;
		m_SetFocus(itemIndex, false, false);
	}

	int CSingleLineListControl::FocusItemIndex(void) const
	{
		return m_curFocusItem;
	}

	void CSingleLineListControl::t_UpdateOrientation(EOrientation orientation)
	{
		for (size_t i = 0; i < t_itemList.size(); i++)
		{
			TItem *item = t_itemList.at(i);
			t_RefreshItemPosition(item);
		}

		CDataListControl::t_UpdateOrientation(orientation);
	}

	bool CSingleLineListControl::t_MoveFocusBar(EDirection direction)
	{
		if (false == t_flagShowFocusBar)
		{
			return false;
		}

		if (TYPE_HORIZONTAL == t_type)
		{
			if (ORIENTATION_RIGHT_TO_LEFT == Orientation(true))
			{
				if (DIRECTION_LEFT == direction)
				{
					m_MoveNext();
				}
				else if (DIRECTION_RIGHT == direction)
				{
					m_MovePrev();
				}
				else
				{
					if (NULL != m_listenerSet)
					{
						CSingleLineListControlListenerSet::TSingleLineListListenerData data;
						data.type = EVENT_MOVE_OUT;
						data.param[0] = direction;
						data.param[1] = m_curFocusItem;

						m_listenerSet->Process(&data);
					}
				}
			}
			else
			{
				if (DIRECTION_LEFT == direction)
				{
					m_MovePrev();
				}
				else if (DIRECTION_RIGHT == direction)
				{
					m_MoveNext();
				}
				else
				{
					if (NULL != m_listenerSet)
					{
						CSingleLineListControlListenerSet::TSingleLineListListenerData data;
						data.type = EVENT_MOVE_OUT;
						data.param[0] = direction;
						data.param[1] = m_curFocusItem;

						m_listenerSet->Process(&data);
					}
				}
			}
		}
		else
		{
			if (DIRECTION_UP == direction)
			{
				m_MovePrev();
			}
			else if (DIRECTION_DOWN == direction)
			{
				m_MoveNext();
			}
			else
			{
				if (NULL != m_listenerSet)
				{
					CSingleLineListControlListenerSet::TSingleLineListListenerData data;
					data.type = EVENT_MOVE_OUT;
					data.param[0] = direction;
					data.param[1] = m_curFocusItem;

					m_listenerSet->Process(&data);
				}
			}
		}

		return true;
	}

	int CSingleLineListControl::NumofItem(void)
	{
		return t_itemList.size();
	}

	void CSingleLineListControl::AddItem(int itemNum, float *itemSpaceArray, float itemGap /* = 0.0f */)
	{
		H_LOG_3_PARAM(FATAL, LOGGER, itemNum, itemSpaceArray, itemGap);
		HALO_ASSERT(itemNum > 0);
		HALO_ASSERT(itemSpaceArray != NULL);
		if (t_type == TYPE_HORIZONTAL)
		{
			for (int i = 0; i < itemNum; i++)
			{
				HALO_ASSERT(itemSpaceArray[i] > 0);
			}
		}
		else if (t_type == TYPE_VERTICAL)
		{
			for (int i = 0; i < itemNum; i++)
			{
				HALO_ASSERT(itemSpaceArray[i] > 0);
			}
		}

		t_AddItem(itemNum, itemSpaceArray, itemGap);
	}

	void CSingleLineListControl::AddItem(int itemNum, float itemSpace, float itemGap /* = 0.0f */)
	{
		H_LOG_3_PARAM(FATAL, LOGGER, itemNum, itemSpace, itemGap);
		HALO_ASSERT(itemNum > 0);
		HALO_ASSERT(itemSpace > 0);
		if (t_type == TYPE_HORIZONTAL)
		{
			HALO_ASSERT(itemSpace <= t_listWidth);
		}
		else if (t_type == TYPE_VERTICAL)
		{
			HALO_ASSERT(itemSpace <= t_listHeight);
		}
		float *itemSpaceArray = new float[itemNum];
		if (NULL == itemSpaceArray)
		{
			return;
		}

		memset(itemSpaceArray, 0, itemNum * sizeof(float));

		for (int i = 0; i < itemNum; i++)
		{
			itemSpaceArray[i] = itemSpace;
		}

		t_AddItem(itemNum, itemSpaceArray, itemGap);

		delete[] itemSpaceArray;
	}

	void CSingleLineListControl::InsertItem(int insertPosition, int itemNum, float *itemSpaceArray)
	{
		H_LOG_3_PARAM(FATAL, LOGGER, insertPosition, itemNum, itemSpaceArray);
		t_InsertItem(insertPosition, itemNum, itemSpaceArray);
	}

	void CSingleLineListControl::InsertItem(int insertPosition, int itemNum, float itemSpace)
	{
		H_LOG_3_PARAM(FATAL, LOGGER, insertPosition, itemNum, itemSpace);
		float *itemSpaceArray = new float[itemNum];
		if (NULL == itemSpaceArray)
		{
			return;
		}

		memset(itemSpaceArray, 0, itemNum * sizeof(float));

		for (int i = 0; i < itemNum; i++)
		{
			itemSpaceArray[i] = itemSpace;
		}

		t_InsertItem(insertPosition, itemNum, itemSpaceArray);

		delete[] itemSpaceArray;
	}

	void CSingleLineListControl::DeleteItem(int fromItem, int deleteItemNum)
	{
		H_LOG_2_PARAM(FATAL, LOGGER, fromItem, deleteItemNum);
		int toItem = fromItem + deleteItemNum - 1;
		if (m_curFocusItem >= fromItem && m_curFocusItem <= toItem)
		{
			t_focusedItem = NULL;
		}

		t_DelelteItem(fromItem, deleteItemNum);

		if (m_curFocusItem >= fromItem && m_curFocusItem <= toItem)
		{
			m_SetFocus(fromItem, false, false);
		}
	}

	void CSingleLineListControl::SetAnimationDuration(ESingleLineAniType aniType, int duration)
	{
		H_LOG_2_PARAM(FATAL, LOGGER, aniType, duration);
		switch (aniType)
		{
		case ANITYPE_FOCUS_MOVE:
			t_SetFocusMoveAniDuration(duration);
			break;

		case ANITYPE_LOOP:
			t_SetLoopAniDuration(duration);
			break;

		default:
			break;
		}
	}

	void CSingleLineListControl::SetItemSpace(int itemIndex, float itemSpace)
	{
		H_LOG_2_PARAM(FATAL, LOGGER, itemIndex, itemSpace);
		HALO_ASSERT(itemIndex >= 0 && itemIndex < (int)t_itemList.size());
		HALO_ASSERT(itemSpace > 0);
		if (t_type == TYPE_HORIZONTAL)
		{
			HALO_ASSERT(itemSpace <= t_listWidth);
		}
		else if (t_type == TYPE_VERTICAL)
		{
			HALO_ASSERT(itemSpace <= t_listHeight);
		}

		t_SetItemSpace(itemIndex, itemSpace);
	}

	void CSingleLineListControl::SetItemSpace(int numOfChangeItem, int itemIndex[], float itemSpace[])
	{
		H_LOG_3_PARAM(FATAL, LOGGER, numOfChangeItem, itemIndex, itemSpace);
	}

	bool CSingleLineListControl::IsSetMarginWhenFocusEdgeItem(void) const
	{
		H_LOG_0_PARAM(FATAL, LOGGER);
		return m_flagUseMarginWhenFocusEdgeItem;
	}

	void CSingleLineListControl::EnableMarginWhenFocusEdgeItem(const bool flagEnable)
	{
		H_LOG_1_PARAM(FATAL, LOGGER, flagEnable);
		m_flagUseMarginWhenFocusEdgeItem = flagEnable;
	}

	void CSingleLineListControl::SetMargin(TMargin margin)
	{
		H_LOG_FATAL(LOGGER, "[0x" << this << "] margin(" << margin.left << ", " << margin.right << ", " << margin.top << ", " << margin.bottom << ")");
		m_margin = margin;

		m_refreshStatus |= REFRESH_WINDOW;

		if (true == FlagShow())
		{
			m_RefreshListInfo();
		}
	}

	void CSingleLineListControl::t_BindDataListToItemList(void)
	{
		HALO_ASSERT(t_itemList.size() == m_dataSource->Size());

		m_flagAutoFix = false;

		for (int i = 0; i < m_dataSource->Size() && i < (int)t_itemList.size(); i++)
		{
			if (NULL == t_itemList[i]->data)
			{
				t_itemList[i]->data = m_dataSource->GetData(i);
			}
		}

		t_UpdateInMemoryItems(false);

		for (int i = 0; i < (int)t_itemList.size(); i++)
		{
			t_RefreshItemPosition(t_itemList[i]);
		}

		if (0 != (int)t_itemList.size() && 0 <= m_curFocusItem)
		{
			m_SetFocus(m_curFocusItem, false, false);
		}

		if (0 < (int)t_itemList.size())
		{
			TItem *lastItem = t_itemList.at(t_itemList.size() - 1);

			if (NULL != lastItem)
			{
				if (TYPE_VERTICAL == t_type)
				{
					t_SetItemGroupSize(t_listWidth, lastItem->rect.y + lastItem->rect.h);//reset group size for initialize
				}
				else
				{
					t_SetItemGroupSize(lastItem->rect.x + lastItem->rect.w, t_listHeight);//reset group size for initialize
				}
			}
		}

		m_flagAutoFix = true;
	}

	void CSingleLineListControl::t_OnItemGroupScrollStart(void)
	{

	}

	void CSingleLineListControl::t_OnItemGroupScrollEnd(void)
	{

	}

	void CSingleLineListControl::t_GetInMemoryItems(TRect lastVisibleArea, TRect visibleArea, std::vector<TItem*> &loadItem, std::vector<TItem*> &unloadItem, std::vector<TItem*> &noChangeItem, int reason)
	{
		if (SCROLL_ITEMGROUP == reason)
		{
			if (true == m_ReCalcFocusItemIndex(visibleArea))
			{
				TSingleLineItem *newFocusItem = dynamic_cast<TSingleLineItem*>(t_itemList[m_curFocusItem]);

				if (false == t_flagShowFocusBar)
				{
					t_focusedItemBak = newFocusItem;
				}
				else
				{
					t_focusedItem = newFocusItem;
				}
			}
		}

		CLinearListControl::t_GetInMemoryItems(lastVisibleArea, visibleArea, loadItem, unloadItem, noChangeItem, reason);
	}

	void CSingleLineListControl::t_GetItemWindowPivotPoint(TItem *item, float &pivotX, float &pivotY, float &pivotZ)
	{
		TLinearItem *singleItem = (TLinearItem*)(item);

		if (TYPE_VERTICAL == t_type)
		{
			pivotX = 0.5f;
			pivotZ = 0.0f;

			if (0 == singleItem->index)
			{
				pivotY = 0.0f;
			}
			else if ((int)t_itemList.size() - 1 == singleItem->index)
			{
				pivotY = 1.0f;
			}
			else
			{
				pivotY = 0.5f;
			}
		}
		else
		{
			pivotY = 0.5f;
			pivotZ = 0.0f;

			if (0 == singleItem->index)
			{
				pivotX = 0.0f;
			}
			else if ((int)t_itemList.size() - 1 == singleItem->index)
			{
				pivotX = 1.0f;
			}
			else
			{
				pivotX = 0.5f;
			}
		}
	}

	void CSingleLineListControl::t_OnItemDataUnload(TItem *item)
	{
		TSingleLineItem *singleItem = (TSingleLineItem*)(item);

		if (m_listenerSet)
		{
			CSingleLineListControlListenerSet::TSingleLineListListenerData data;
			data.type = EVENT_ITEM_UNLOAD;
			data.param[0] = singleItem->index;
			data.pData = item->data;
			m_listenerSet->Process(&data);
		}
	}

	void CSingleLineListControl::t_OnItemDataSyncLoad(TItem *item)
	{
		TLinearItem *singleItem = (TLinearItem*)(item);

		if (m_listenerSet)
		{
			CSingleLineListControlListenerSet::TSingleLineListListenerData data;
			data.type = EVENT_ITEM_LOAD;
			data.param[0] = singleItem->index;
			data.pData = item->data;
			m_listenerSet->Process(&data);
		}
	}

	void CSingleLineListControl::t_OnItemDataAsyncLoad(TItem *item)
	{
		TLinearItem* singleItem = (TLinearItem*)item;
		//To do
	}

	void CSingleLineListControl::t_OnRendererDraw(TItem *item)
	{
		HALO_ASSERT(item != NULL);

		if (!t_flagAutoHighContrast)
		{
			return;
		}

		TSingleLineItem *singleLineItem = (TSingleLineItem*)(item);
		if (NULL != item->renderer)
		{
			IThumbnail *thumb = item->renderer->Thumbnail();
			if (NULL != thumb)
			{
				IThumbnail::THighContrastAttr attr;
				attr.backgroundColor = (singleLineItem->index) % 2 ? Color(0x25, 0x25, 0x25, 255) : Color(0x0d, 0x0d, 0x0d, 255);
				attr.textColor = Color(0xff, 0xff, 0xff, 255);
				attr.highlightTextColor = Color(0xfb, 0xba, 0x2d, 255);
				thumb->SetHighContrastInfo(attr);
			}
		}
	}

	void CSingleLineListControl::t_FocusChangeStart(const TItem *from, const TItem *to)
	{
		const TSingleLineItem *fromItem = dynamic_cast<const TSingleLineItem*>(from);
		const TSingleLineItem *toItem = dynamic_cast<const TSingleLineItem*>(to);

		if (t_flagShadowEffect)
		{
			if (NULL != fromItem)
			{
				IActor * fromWin = fromItem->window;
				if (fromWin)
				{
					fromWin->RemoveEffect(t_shadowEffect);
				}
			}
		}

		CSingleLineListControlListenerSet::TSingleLineListListenerData data;
		data.type = EVENT_FOCUS_CHANGE_MOTION_START;

		if (NULL == fromItem)
		{
			data.param[0] = -1;
		}
		else
		{
			data.param[0] = fromItem->index;
		}

		if (NULL == toItem)
		{
			data.param[1] = -1;
		}
		else
		{
			data.param[1] = toItem->index;
		}

		m_listenerSet->Process(&data);
	}

	void CSingleLineListControl::t_FocusChangeFinish(const TItem *from, const TItem *to)
	{
		const TSingleLineItem *fromItem = dynamic_cast<const TSingleLineItem*>(from);
		const TSingleLineItem *toItem = dynamic_cast<const TSingleLineItem*>(to);

		if (t_flagShadowEffect)
		{
			if (NULL != toItem)
			{
				IActor * toWin = toItem->window;
				if (toWin)
				{
					if (true == t_flagShowFocusBar)
					{
						toWin->AddEffect(t_shadowEffect);
					}
				}
			}
		}

		CSingleLineListControlListenerSet::TSingleLineListListenerData data;
		data.type = EVENT_FOCUS_CHANGE;

		if (NULL == fromItem)
		{
			data.param[0] = -1;
		}
		else
		{
			data.param[0] = fromItem->index;
		}

		if (NULL == toItem)
		{
			data.param[1] = -1;
		}
		else
		{
			data.param[1] = toItem->index;
		}

		m_listenerSet->Process(&data);

		if (true == m_flagAutoFix 
			&& 
			NULL != toItem && NULL != fromItem
		#ifndef WIN32
			&&
			true == IUtility::GetInstance()->IsCursorVisible()
		#endif
			)
		{
			IDeviceManager *deviceInstance = IDeviceManager::GetInstance();
			if (NULL != deviceInstance)
			{
				IMouseDevice *mouseDevice = deviceInstance->GetMouseDevice();

				if (NULL != mouseDevice)
				{
					ClutterPoint point;
					mouseDevice->GetMousePoint(&point);

					float mouseX = point.x;
					float mouseY = point.y;
					//Only auto scroll when mouse hit the item beside the focusedItem.
					TLinearItem *hitItem = NULL;

					int windowStart = -1, windowEnd = -1;
					GetWindowItemRange(windowStart, windowEnd);

					if ((int)t_itemList.size() - 1 > toItem->index
						&&
						windowEnd - 1 == toItem->index)
					{
						if (fromItem->index < toItem->index)
						{
							hitItem = t_itemList.at(toItem->index + 1);
						}
					}
					else if (0 < toItem->index
						&&
						windowStart + 1 == toItem->index)
					{
						if (fromItem->index > toItem->index)
						{
							hitItem = t_itemList.at(toItem->index - 1);
						}
					}

					if (NULL != hitItem && NULL != hitItem->window)
					{
						Vector3 pos = hitItem->window->getAbsolutePosition();
						if (pos.x <= mouseX && pos.x + hitItem->rect.w >= mouseX
							&&
							pos.y <= mouseY && pos.y + hitItem->rect.h >= mouseY)
						{
							m_SetFocus(hitItem->index, false, true);
						}
					}
				}
			}
		}
	}

	bool CSingleLineListControl::t_OnMousePointerIn(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		if (true == t_flagShowFocusBar)
		{
			if (-1 == m_currentClickedItemIndex)
			{
				TSingleLineItem *singleItem = dynamic_cast<TSingleLineItem*>(item);
				HALO_ASSERT(NULL != singleItem);

				if (m_curFocusItem == singleItem->index)
				{
					if (NULL != t_focusedItem && NULL != t_focusedItem->window && t_flagShadowEffect)
					{
						t_focusedItem->window->AddEffect(t_shadowEffect);
					}

					if (NULL != t_focusedItem && NULL != t_focusedItem->renderer && NULL != t_focusedItem->renderer->Thumbnail())
					{
						// Start Auto scroll of lost focus item
						IThumbnail *thumb = t_focusedItem->renderer->Thumbnail();

						if (thumb->VisibleThumbnailStyles() & IThumbnail::THUMB_STYLE_TEXT)
						{
							thumb->EnableAttachTextAutoScroll(true);
						}
						if (thumb->VisibleThumbnailStyles() & IThumbnail::THUMB_STYLE_INFO)
						{
							int infoTextNum = thumb->InformationTextNumber();
							for (int i = 0; i < infoTextNum; i++)
							{
								thumb->EnableInformationTextAutoScroll(i, true);
							}
						}
					}

					t_ScaleUpFocuedItem(NULL);
				}
				else
				{
					m_SetFocus(singleItem->index, false, true);
				}
			}
		}

		return true;
	}

	bool CSingleLineListControl::t_OnMouseMoved(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		if (true == t_flagShowFocusBar)
		{
			if (-1 == m_currentClickedItemIndex)
			{
				TSingleLineItem *singleItem = dynamic_cast<TSingleLineItem*>(item);
				if (NULL != singleItem && m_curFocusItem != singleItem->index)
				{
					m_SetFocus(singleItem->index, false, true);
				}
			}
		}

		return true;
	}

	bool CSingleLineListControl::t_OnMousePointerOut(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		TSingleLineItem *singleLineItem = dynamic_cast<TSingleLineItem*>(item);
		HALO_ASSERT(NULL != singleLineItem);

		if (m_curFocusItem == singleLineItem->index && NULL != t_focusedItem && NULL != t_focusedItem->window)
		{
			t_focusedItem->window->RemoveEffect(t_shadowEffect);

			t_ScaleDownFocuedItem(NULL);

			if (NULL != singleLineItem && NULL != singleLineItem->renderer && NULL != singleLineItem->renderer->Thumbnail())
			{
				IThumbnail *thumb = singleLineItem->renderer->Thumbnail();
				// Stop Auto scroll of lost focus item
				if (thumb->VisibleThumbnailStyles() & IThumbnail::THUMB_STYLE_TEXT)
				{
					thumb->EnableAttachTextAutoScroll(false);
				}
				if (thumb->VisibleThumbnailStyles() & IThumbnail::THUMB_STYLE_INFO)
				{
					int infoTextNum = thumb->InformationTextNumber();
					for (int i = 0; i < infoTextNum; i++)
					{
						thumb->EnableInformationTextAutoScroll(i, false);
					}
				}
			}
		}

		return true;
	}

	bool CSingleLineListControl::t_MouseButtonPressed(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		const TSingleLineItem *pressedItem = dynamic_cast<const TSingleLineItem*>(item);

		if (NULL != pressedItem)
		{
			m_currentClickedItemIndex = pressedItem->index;

			if (NULL != pressedItem->window)
			{
				pressedItem->window->GetScale(m_xFactor, m_yFactor, m_zFactor);
				pressedItem->window->SetScale(1.02, 1.02, m_zFactor);
			}
		}

		return true;
	}
	
	bool CSingleLineListControl::t_MouseButtonRelease(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		if (0 <= m_currentClickedItemIndex)
		{
			const TSingleLineItem *pressedItem = dynamic_cast<TSingleLineItem*>(t_itemList[m_currentClickedItemIndex]);

			if (pressedItem == NULL)
			{
				return false;
			}
			
			if (NULL != pressedItem->window)
			{
				pressedItem->window->SetScale(m_xFactor, m_yFactor, m_zFactor);
			}

			CSingleLineListControlListenerSet::TSingleLineListListenerData data;
			data.type = EVENT_ITEM_CLICKED;
			data.param[0] = pressedItem->index;

			m_listenerSet->Process(&data);

			m_currentClickedItemIndex = -1;
		}

		return true;
	}
	
	bool CSingleLineListControl::t_MouseClicked(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		TSingleLineItem* singleItem = dynamic_cast<TSingleLineItem*>(item);

		CSingleLineListControlListenerSet::TSingleLineListListenerData data;
		data.type = EVENT_ITEM_CLICKED;
		data.param[0] = (NULL == singleItem) ? -1 : singleItem->index;

		m_listenerSet->Process(&data);

		return true;
	}

	bool CSingleLineListControl::t_MouseWheel(IMouseEvent* ptrMouseEvent)
	{
		if (NULL == t_focusedItem)
		{
			return true;
		}

		ClutterScrollDirection direction = ptrMouseEvent->ScrollDirection();

		int nextFocusItem = -1;

		if (ClutterScrollDirection::CLUTTER_SCROLL_UP == direction)
		{
			if (0 != m_curFocusItem)
			{
				nextFocusItem = m_curFocusItem - 1;
			} 
		}
		else if (ClutterScrollDirection::CLUTTER_SCROLL_DOWN == direction)
		{
			if (t_itemList.size() - 1 > m_curFocusItem)
			{
				nextFocusItem = m_curFocusItem + 1;
			}
		}

		if (0 <= nextFocusItem)
		{
			TLinearItem *destItem = t_itemList.at(nextFocusItem);
			TValue2f destItemGroupPos(t_itemGroupRect.x, t_itemGroupRect.y);

			if (TYPE_HORIZONTAL == t_type)
			{
				destItemGroupPos.val[0] += t_focusedItem->rect.x - destItem->rect.x;
			}
			else
			{
				destItemGroupPos.val[1] += t_focusedItem->rect.y - destItem->rect.y;
			}

			m_SetFocus(nextFocusItem, true, true, &destItemGroupPos);
		}

		return true;
	}

	void CSingleLineListControl::t_OnItemInMemoryScrolled(TItem *item)
	{

	}

	TValue2f CSingleLineListControl::t_GetRealPointBaseItemGroup(TRect rect, TRect baseOnRect)
	{
		TValue2f value;

		if (ORIENTATION_LEFT_TO_RIGHT == Orientation(true))
		{
			value.Set(rect.x, rect.y);
		}
		else
		{
			value.Set(baseOnRect.w - rect.x - rect.w, rect.y);
		}

		return value;
	}

	TValue2f CSingleLineListControl::t_GetLogicalPosition(TRect rect, TRect baseOnRect)
	{
		TValue2f point(rect.x, rect.y);
		return point;
	}

	TRect CSingleLineListControl::t_InitRectOfLoadingItem(TItem *item, int reason)
	{
		return item->rect;
	}

	CLinearListControl::TLinearItem* CSingleLineListControl::t_AllocLinearItem(void)
	{
		return new TSingleLineItem(this);
	}

	void CSingleLineListControl::t_FreeLinearItem(TLinearItem *item)
	{
		TSingleLineItem *singleItem = (TSingleLineItem*)item;
		delete singleItem;
	}

	void CSingleLineListControl::t_GetRealItems(TLinearItem *item, std::vector<TItem*> &itemList)
	{
		itemList.push_back(item);
	}

	bool CSingleLineListControl::t_OnEnterKeyLongPressed(void)
	{
		CSingleLineListControlListenerSet::TSingleLineListListenerData data;
		data.type = EVENT_ENTER_KEY_LONG_PRESSED;
		data.param[0] = m_curFocusItem;
		m_listenerSet->Process(&data);

		return true;
	}

	bool CSingleLineListControl::t_GetItemsNeedFoveaAni(const TItem *hitItem, std::vector<TItem*> &itemArray, TValue2f cursorCenter, float cursorRadius)
	{
		const TSingleLineItem *singleItem = dynamic_cast<const TSingleLineItem*>(hitItem);
		bool flagHited = false;

		HALO_ASSERT(NULL != singleItem);

		if (TYPE_VERTICAL == t_type)
		{
			t_cursorRadius = t_itemGroupRect.h / (int)t_itemList.size();

			for (int i = singleItem->index - 1; i >= 0; i--)
			{
				TItem *curItem = t_itemList[i];

				if (NULL != curItem->renderer)
				{
					TValue2f itemCenter = t_GetRealPointBaseItemGroup(curItem->rect, t_itemGroupRect);
					itemCenter.val[0] += curItem->rect.w / 2.0f;
					itemCenter.val[1] += curItem->rect.h / 2.0f;

					float itemRadius = curItem->rect.h / 2.0f;

					float distance = sqrt((cursorCenter.val[0] - itemCenter.val[0]) * (cursorCenter.val[0] - itemCenter.val[0]) + (cursorCenter.val[1] - itemCenter.val[1]) * (cursorCenter.val[1] - itemCenter.val[1]));

					if (distance < itemRadius + t_cursorRadius)
					{
						flagHited = true;
						itemArray.push_back(curItem);
					}
					else
					{
						break;
					}
				}
			}

			for (int i = singleItem->index; i < (int)t_itemList.size(); i++)
			{
				TItem *curItem = t_itemList[i];

				if (NULL != curItem->renderer)
				{
					TValue2f itemCenter = t_GetRealPointBaseItemGroup(curItem->rect, t_itemGroupRect);
					itemCenter.val[0] += curItem->rect.w / 2.0f;
					itemCenter.val[1] += curItem->rect.h / 2.0f;

					float itemRadius = curItem->rect.h / 2.0f;

					float distance = sqrt((cursorCenter.val[0] - itemCenter.val[0]) * (cursorCenter.val[0] - itemCenter.val[0]) + (cursorCenter.val[1] - itemCenter.val[1]) * (cursorCenter.val[1] - itemCenter.val[1]));

					if (distance < itemRadius + t_cursorRadius)
					{
						flagHited = true;
						itemArray.push_back(curItem);
					}
					else
					{
						break;
					}
				}
			}
		}
		else
		{
			t_cursorRadius = t_itemGroupRect.w / (int)t_itemList.size();

			for (int i = singleItem->index - 1; i >= 0; i--)
			{
				TItem *curItem = t_itemList[i];

				if (NULL != curItem->renderer)
				{
					TValue2f itemCenter = t_GetRealPointBaseItemGroup(curItem->rect, t_itemGroupRect);
					itemCenter.val[0] += curItem->rect.w / 2.0f;
					itemCenter.val[1] += curItem->rect.h / 2.0f;

					float itemRadius = curItem->rect.w / 2.0f;

					float distance = sqrt((cursorCenter.val[0] - itemCenter.val[0]) * (cursorCenter.val[0] - itemCenter.val[0]) + (cursorCenter.val[1] - itemCenter.val[1]) * (cursorCenter.val[1] - itemCenter.val[1]));

					if (distance < itemRadius + t_cursorRadius)
					{
						flagHited = true;
						itemArray.push_back(curItem);
					}
					else
					{
						break;
					}
				}
			}

			for (int i = singleItem->index; i < (int)t_itemList.size(); i++)
			{
				TItem *curItem = t_itemList[i];

				if (NULL != curItem->renderer)
				{
					TValue2f itemCenter = t_GetRealPointBaseItemGroup(curItem->rect, t_itemGroupRect);
					itemCenter.val[0] += curItem->rect.w / 2.0f;
					itemCenter.val[1] += curItem->rect.h / 2.0f;

					float itemRadius = curItem->rect.w / 2.0f;

					float distance = sqrt((cursorCenter.val[0] - itemCenter.val[0]) * (cursorCenter.val[0] - itemCenter.val[0]) + (cursorCenter.val[1] - itemCenter.val[1]) * (cursorCenter.val[1] - itemCenter.val[1]));

					if (distance < itemRadius + t_cursorRadius)
					{
						flagHited = true;
						itemArray.push_back(curItem);
					}
					else
					{
						break;
					}
				}
			}
		}

		return flagHited;
	}

	CSingleLineListControl::TSingleLineItem::~TSingleLineItem(void)
	{
		if (NULL != data)
		{
			owner->m_dataSource->DeleteData(index);
		}
	}

	void CSingleLineListControl::m_MoveNext(void)
	{
		if (m_dataSource->Size() - 1 != m_curFocusItem)
		{
			m_SetFocus(m_curFocusItem + 1, true, true);
		}
		else
		{
			TRect rect = t_itemList[0]->rect;

			int newFocusItem = 0;

			TRect focusImgDest;
			focusImgDest.Set(0.0f, 0.0f, rect.w, rect.h);

			TPoint focusBarOutOffset;
			TPoint itemGroupOutOffset;

			if (TYPE_VERTICAL == t_type)
			{
				focusBarOutOffset.Set(0.0f, 30.0f);
				itemGroupOutOffset.Set(0.0f, -300.0f);
			}
			else
			{
				focusBarOutOffset.Set(30.0f, 0.0f);
				itemGroupOutOffset.Set(-300.0f, 0.0f);
			}

			if (true == t_FadeInOut(t_itemList[0], focusImgDest, focusBarOutOffset, itemGroupOutOffset))
			{
				m_curFocusItem = newFocusItem;
			}
		}
	}

	void CSingleLineListControl::m_MovePrev(void)
	{
		if (0 != m_curFocusItem)
		{
			m_SetFocus(m_curFocusItem - 1, true, true);
		}
		else
		{
			TRect rect = t_itemList[(int)t_itemList.size() - 1]->rect;

			int newFocusItem = m_dataSource->Size() - 1;

			TRect focusImgDest;
			focusImgDest.Set(0.0f, 0.0f, rect.w, rect.h);

			TPoint focusBarOutOffset;
			TPoint itemGroupOutOffset;

			if (TYPE_VERTICAL == t_type)
			{
				focusBarOutOffset.Set(0.0f, -30.0f);
				itemGroupOutOffset.Set(0.0f, 300.0f);
			}
			else
			{
				focusBarOutOffset.Set(-30.0f, 0.0f);
				itemGroupOutOffset.Set(300.0f, 0.0f);
			}

			if (true == t_FadeInOut(t_itemList[(int)t_itemList.size() - 1], focusImgDest, focusBarOutOffset, itemGroupOutOffset))
			{
				m_curFocusItem = newFocusItem;
			}
		}
	}

	void CSingleLineListControl::m_SetFocus(int focusItemIndex, bool flagFocusBarAni, bool flagScrollAni, TValue2f *newItemGroupPos /* = NULL */)
	{
		if (focusItemIndex < 0 || focusItemIndex >(int)t_itemList.size() - 1)
		{
			return;
		}

		TLinearItem *newItem = t_itemList[focusItemIndex];

		TRect focusImgRect;
		focusImgRect.x = 0;
		focusImgRect.y = 0;
		focusImgRect.w = newItem->rect.w;
		focusImgRect.h = newItem->rect.h;

		float expandSpaceToStart = 0.0f;
		float expandSpaceToEnd = 0.0f;

		if (true == m_flagUseMarginWhenFocusEdgeItem)
		{
			TRect windowRect = t_WindowRect();
			if (NULL != newItemGroupPos)
			{
				windowRect.x = -newItemGroupPos->val[0];
				windowRect.y = -newItemGroupPos->val[1];
			}

			if (0 != focusItemIndex)
			{
				TLinearItem *prevItem = t_itemList[focusItemIndex - 1];

				if (TYPE_VERTICAL == t_type)
				{
					if (newItem->rect.y < windowRect.y + prevItem->rect.h / 2.0f)
					{
						expandSpaceToStart = prevItem->rect.h / 2.0f;
					}
				}
				else
				{
					if (newItem->rect.x < windowRect.x + prevItem->rect.w / 2.0f)
					{
						expandSpaceToStart = prevItem->rect.w / 2.0f;
					}
				}
			}

			if ((int)t_itemList.size() - 1 > focusItemIndex)
			{
				TLinearItem *nextItem = t_itemList[focusItemIndex + 1];

				if (TYPE_VERTICAL == t_type)
				{
					if (newItem->rect.y + newItem->rect.h > windowRect.y + windowRect.h - nextItem->rect.h / 2.0f)
					{
						expandSpaceToEnd = nextItem->rect.h / 2.0f;
					}
				}
				else
				{
					if (newItem->rect.x + newItem->rect.w > windowRect.x + windowRect.w - nextItem->rect.w / 2.0f)
					{
						expandSpaceToEnd = nextItem->rect.w / 2.0f;
					}
				}
			}
		}

		bool flagResult;

		if ((0.0f != expandSpaceToStart && 0.0f != expandSpaceToEnd)
			||
			(0.0f == expandSpaceToStart && 0.0f == expandSpaceToEnd))
		{
			flagResult = t_SetFocusBar(focusImgRect, newItem->rect, newItem, flagFocusBarAni, flagScrollAni, newItemGroupPos);
		}
		else
		{
			TRect destFocusBarRect = newItem->rect;

			if (TYPE_VERTICAL == t_type)
			{
				if (0.0f != expandSpaceToStart)
				{
					destFocusBarRect.y -= expandSpaceToStart;
					focusImgRect.y += expandSpaceToStart;

					if (NULL != newItemGroupPos)
					{
						if (newItemGroupPos->val[1] + destFocusBarRect.y < t_focusRangeRect.y)
						{
							newItemGroupPos->val[1] = t_focusRangeRect.y - destFocusBarRect.y;
						}

						if (newItemGroupPos->val[1] + t_itemGroupRect.h < t_focusRangeRect.y + t_focusRangeRect.h)
						{
							newItemGroupPos->val[1] = t_focusRangeRect.y + t_focusRangeRect.h - t_itemGroupRect.h;
						}
					}
				}
				else if (0.0f != expandSpaceToEnd)
				{
					destFocusBarRect.h += expandSpaceToEnd;

					if (NULL != newItemGroupPos)
					{
						if (newItemGroupPos->val[1] + destFocusBarRect.y + destFocusBarRect.h > t_focusRangeRect.y + t_focusRangeRect.h)
						{
							newItemGroupPos->val[1] = (t_focusRangeRect.y + t_focusRangeRect.h) - (destFocusBarRect.y + destFocusBarRect.h);
						}
					}
				}
			}
			else
			{
				if (0.0f != expandSpaceToStart)
				{
					destFocusBarRect.x -= expandSpaceToStart;
					focusImgRect.x += expandSpaceToStart;

					if (NULL != newItemGroupPos)
					{
						if (newItemGroupPos->val[0] + destFocusBarRect.x < t_focusRangeRect.x)
						{
							newItemGroupPos->val[0] = t_focusRangeRect.x - destFocusBarRect.x;
						}

						if (newItemGroupPos->val[0] + t_itemGroupRect.w < t_focusRangeRect.x + t_focusRangeRect.w)
						{
							newItemGroupPos->val[0] = t_focusRangeRect.x + t_focusRangeRect.w - t_itemGroupRect.w;
						}
					}
				}
				else if (0.0f != expandSpaceToEnd)
				{
					destFocusBarRect.w += expandSpaceToEnd;

					if (NULL != newItemGroupPos)
					{
						if (newItemGroupPos->val[0] + destFocusBarRect.x + destFocusBarRect.w > t_focusRangeRect.x + t_focusRangeRect.w)
						{
							newItemGroupPos->val[0] = (t_focusRangeRect.x + t_focusRangeRect.w) - (destFocusBarRect.x + destFocusBarRect.w);
						}
					}
				}
			}

			flagResult = t_SetFocusBar(focusImgRect, destFocusBarRect, newItem, flagFocusBarAni, flagScrollAni, newItemGroupPos);
		}

		if (true == flagResult)
		{
			m_curFocusItem = focusItemIndex;
		}
	}

	void CSingleLineListControl::m_RefreshListInfo(void)
	{
		if (0 != (m_refreshStatus & REFRESH_WINDOW))
		{
			CDataListControl::SetPosition((float)m_margin.left, (float)m_margin.top);
			CDataListControl::Resize(t_listWidth - (m_margin.left + m_margin.right),
								 t_listHeight - (m_margin.top + m_margin.bottom));

			m_refreshStatus &= ~((int)REFRESH_WINDOW);
		}

		if (0 != (m_refreshStatus & REFRESH_ITEM_GROUP)
			||
			0 != (m_refreshStatus & REFRESH_WINDOW))
		{
			m_refreshStatus &= ~((int)REFRESH_ITEM_GROUP);
		}
	}

	bool CSingleLineListControl::m_ReCalcFocusItemIndex(const TRect newVisibleArea)
	{
		HALO_ASSERT(0 <= m_curFocusItem && (int)t_itemList.size() > m_curFocusItem);

		TLinearItem *curFocusItem = t_itemList[m_curFocusItem];

		float curFocusStart, curFocusEnd;
		float visibleStart;
		float focusRangeStart, focusRangeEnd;

		if (TYPE_VERTICAL == t_type)
		{
			curFocusStart = curFocusItem->rect.y;
			curFocusEnd = curFocusItem->rect.y + curFocusItem->rect.h;

			visibleStart = newVisibleArea.y;

			focusRangeStart = t_focusRangeRect.y;
			focusRangeEnd = t_focusRangeRect.y + t_focusRangeRect.h;
		}
		else
		{
			curFocusStart = curFocusItem->rect.x;
			curFocusEnd = curFocusItem->rect.x + curFocusItem->rect.w;

			visibleStart = newVisibleArea.x;

			focusRangeStart = t_focusRangeRect.x;
			focusRangeEnd = t_focusRangeRect.x + t_focusRangeRect.w;
		}

		if (curFocusStart < visibleStart + focusRangeStart)
		{
			for (int i = m_curFocusItem; i < (int)t_itemList.size(); i++)
			{
				TLinearItem *item = t_itemList[i];

				if (item->ElementStartPosition() >= visibleStart + focusRangeStart && item->ElementEndPosition() <= visibleStart + focusRangeEnd)
				{
					m_curFocusItem = i;
					return true;
				}
			}
		}
		else if (curFocusEnd > visibleStart + focusRangeEnd)
		{
			for (int i = m_curFocusItem; i >= 0; i--)
			{
				TLinearItem *item = t_itemList[i];

				if (item->ElementStartPosition() >= visibleStart + focusRangeStart && item->ElementEndPosition() <= visibleStart + focusRangeEnd)
				{
					m_curFocusItem = i;
					return true;
				}
			}
		}

		return false;
	}

	void CSingleLineListControl::AddListListener(ISingleLineListControlListener *listener)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);
		HALO_ASSERT(listener != NULL);

		m_listenerSet->Add(listener);
	}

	void CSingleLineListControl::UpdateUI(int itemIndex)
	{
		t_UpdateUI(t_itemList.at(itemIndex));
	}

	void CSingleLineListControl::EnableAutoFixMouse(const bool flagAutoFix)
	{
		H_LOG_1_PARAM(FATAL, LOGGER, flagAutoFix);
		m_flagAutoFix = flagAutoFix;
	}

	bool CSingleLineListControl::IsAutoFixMouse(void) const
	{
		return m_flagAutoFix;
	}

	void CSingleLineListControl::UpdateItem(int itemIndex)
	{
		H_LOG_1_PARAM(FATAL, LOGGER, itemIndex);
		HALO_ASSERT(itemIndex >= 0 && itemIndex < (int)t_itemList.size());

		TSingleLineItem *item = dynamic_cast<TSingleLineItem*>(t_itemList[itemIndex]);

		if (NULL != item)
		{
			item->data = m_dataSource->GetData(itemIndex);
			t_UpdateItem(item);
		}
	}

	void CSingleLineListControl::UpdateAllItems(void)
	{
		H_LOG_0_PARAM(FATAL, LOGGER);

		int minCount = HALO_MIN((int)t_itemList.size(), m_dataSource->NumOfData());

		for (int i = 0; i < minCount; i++)
		{
			UpdateItem(i);
		}
	}


	const char* CSingleLineListControl::GetActorType(void)
	{
		return "SingleLineListControl";
	}
}
