#ifndef _HALO_CDATASOURCE_H_
#define _HALO_CDATASOURCE_H_

namespace HALO
{
	typedef enum E_DATASOURCE_LISTENER_TYPE
	{
		DATA_ADDED = 0,
		DATA_REMOVED,
		DATA_CHANGED
	}EDataSourceListenerType;

	class CMatrixDataSourceListener
	{
	public:
		//typedef struct T_DATA_INFO
		//{
		//	bool flagMatrix;
		//	union UInfo
		//	{
		//		struct TPos
		//		{
		//			int row;
		//			int col;
		//		}pos;

		//		int itemIndex;
		//	}info;
		//}TDataInfo;
		virtual bool OnDataChanged(EDataSourceListenerType type, int row, int col) = 0;
	};

	class CMatrixDataSource : public IMatrixDataSource
	{
	public:
		CMatrixDataSource(int numOfColumns);
		virtual ~CMatrixDataSource(void);
		virtual void AddData(IData *data, int row, int col);
		virtual IData* RemoveData(int row, int col);
		virtual void DeleteData(int row, int col);
		virtual void DeleteRow(int row);
		virtual void DeleteColumn(int column);
		virtual void DeleteAll(void);

		IData* GetData(int row, int col);
		int RowCount(void);
		int ColCount(void);

		void AddListener(CMatrixDataSourceListener *listener);
	private:
		ClutterModel *m_model;

		CMatrixDataSourceListener *m_listener;
	};

	class CSingleLineDataSource : public ISingleLineDataSource
	{
	public:
		CSingleLineDataSource(void);
		virtual ~CSingleLineDataSource(void);
		//! Adds @data to the end of data source list
		void AddData(IData *data);
		void InsertData(int index, IData *data);
		//! Deletes data at @index from data source list
		void DeleteData(int itemIndex);
		void DeleteAll(void);
		int NumOfData(void);
		IData* GetData(int itemIndex);
		int Size(void);

	private:
		//CMatrixDataSource *m_data;
		std::vector<IData *> m_dataList;
	};


	class CGridDataSourceListener : public IListener
	{
	public:
		virtual bool OnDataChanged(EDataSourceListenerType type, int groupIndex, int dataIndex) = 0;
	};

	class CGridDataSource : public IGridDataSource
	{
	public:
		CGridDataSource(void);
		virtual ~CGridDataSource(void);
		void AddGroup(int numberOfGroup);
		void DeleteGroup(int groupIndex);
		//! Adds @data to the end of data source list
		void AddData(int groupIndex, IData *data);
		//! Removes data at @index from data source list
		void DeleteData(int groupIndex, int itemIndex);

		void DeleteAll(void);

		IData* GetData(int groupIndex, int itemIndex);

		int NumOfGroup(void);
		int NumOfData(int groupIndex);

		void InsertData(IData* data, int groupIndex, int itemIndex);

		void SetListener(CGridDataSourceListener* listener);
	private:
		std::vector< std::vector<IData*> > m_dataList;

		CGridDataSourceListener* m_listener;
	};

	class CFirstScreenDataSource : public IFirstScreenDataSource
	{
	public:
		virtual ~CFirstScreenDataSource(void)
		{
			for (int i = 0; i < (int)dataList.size(); i++)
			{
				delete dataList[i];
			}

			dataList.clear();
		}

		virtual void AddMainMenuData(IData *data);
		virtual void AddScrollDataInMainMenu(IData *data, int mainMenuIndex);
		virtual void AddSubMenuData(IData *data, int mainMenuIndex);

		virtual void DeleteSubMenuData(int mainMenuIndex, int subMenuItemIndex);

		virtual IData* MainMenuData(int menuItemIndex);
		virtual CSingleLineDataSource* ScrollDataSource(int menuItemIndex);
		virtual CSingleLineDataSource* SubMenuDataSource(int menuItemIndex);

		virtual IData* ScrollData(int menuItemIndex, int scrollDataIndex);
		virtual IData* SubMenuData(int menuItemIndex, int subMenuItemIndex);

		virtual int NumOfMainMenuData(void);
		virtual int NumOfScrollData(int menuItemIndex);
		virtual int NumOfSubData(int menuItemIndex);

	protected:

	private:
		struct TMainMenuItem
		{
			virtual ~TMainMenuItem(void)
			{
				delete mainMenuData;
			}

			IData *mainMenuData;
			CSingleLineDataSource scrollDataSource;
			CSingleLineDataSource subMenuDataSource;
		};

		std::vector<TMainMenuItem*> dataList;
	};
}

#endif // _HALO_CDATASOURCE_H_