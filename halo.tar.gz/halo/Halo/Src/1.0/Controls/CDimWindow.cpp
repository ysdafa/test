#include "Halo1_0.h"
#include "VoltActor.h"
#include "DimActor.h"
#include "VoltFullProcessRuntime.h"
#include "VoltProcessRuntime.h"

namespace HALO
{
	CDimWindow::CDimWindow(void)
	{
	}

	CDimWindow::~CDimWindow(void)
	{
	}

	bool CDimWindow::Initialize(Widget* parent, float width, float height)
	{
		VoltFullProcessRuntime *runtime = static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());
		SceneRoot* root = runtime->GetSceneRoot();
		if (NULL == parent) { parent = root; }
		if (-1 == width) { width = root->getWidth(); }
		if (-1 == height) { height = root->getHeight(); }

		CActor::Initialize(parent, width, height);

		clutter_actor_set_reactive(t_actor, TRUE);

		return true;
	}

	void CDimWindow::SetBackgroundColor(const ClutterColor &color)
	{
		ASSERT(t_actor != NULL);

		dim_actor_set_background_color(DIM_ACTOR(t_actor), &color);
	}

	void CDimWindow::AddTransparentArea(float x, float y, float width, float height)
	{
		ASSERT(t_actor != NULL);

		dim_actor_add_transparent_area(DIM_ACTOR(t_actor), x, y, width, height);
	}

	void CDimWindow::ClearTransparentArea(void)
	{
		ASSERT(t_actor != NULL);

		dim_actor_clear_transparent_area(DIM_ACTOR(t_actor));
	}

	ClutterActor* CDimWindow::t_CreateActor(void)
	{
		return dim_actor_new();
	}

}

