#ifndef _CBASESELECTBUTTON_GROUP_H_
#define _CBASESELECTBUTTON_GROUP_H_

namespace HALO
{

	class CSelectButtonGroup : virtual public ISelectButtonGroup , public CActor, public OnButtonCheckedChangedListener, public IFocusListener
	{
	public:
		CSelectButtonGroup();

		virtual ~CSelectButtonGroup();

		//virtual bool Initialize(IActor *parent , EGroupLayoutStyle estyle , float itemW, float itemH,  int rowNum, int columnNum);
		//Add item to group.
		virtual int AddButton(ISelectButton *checkContorl);

		virtual void RemoveButton(ISelectButton *checkContorl);
		//get the item in group by item id;
		virtual ISelectButton* GetItemById(int itemId);
		//set the default focus by item id.
		virtual void SetDefaultFocus(int itemId);

		virtual void SetDefaultSelectedItem(int itemId);
		//Get the item number in group.
		virtual int NumofItem();

		virtual bool AddListener(OnCheckedChangedListener *listener);

		virtual bool RemoveListener(OnCheckedChangedListener *listener);

		virtual const char* GetActorType(void);
	protected:
		class CSelectButtonGroupListenerSet *t_pSelectButtonGroupListenerSet;

		std::vector<ISelectButton*> t_itemList;

		int t_itemNum;

		float t_itemW;

		float t_itemH;

		float t_groupW;

		float t_groupH;

		virtual bool t_Initialize();

		virtual void OnCheckedChanged(class ISelectButton* button , bool ischecked);

		virtual void t_ProcessSelect(class ISelectButton* button , bool ischecked) = 0;

	private:
		int m_itemIndex;

		void m_Destory();
	};

}
#endif