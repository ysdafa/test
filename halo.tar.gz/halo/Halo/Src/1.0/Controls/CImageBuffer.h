#ifndef _HALO_CIMAGEBUFFER_H_
#define _HALO_CIMAGEBUFFER_H_

struct _GdkPixbuf;

namespace HALO
{

	class CImageBuffer: public virtual IImageBuffer
	{
	public:
		CImageBuffer(void) :m_pixbuf(NULL) , m_croppedBuf(NULL){}
		virtual ~CImageBuffer(void);

		bool Initialize(const char *fileName);
		bool Initialize(const char *data, int len);
		bool Initialize(IImageBuffer *buffer);

		void SetClipArea(int x, int y, int width, int height);

		int OriginalWidth(void);
		int OriginalHeight(void);

		int Width(void);
		int Height(void);
		int BytesPerLine(void);
		bool HasAlphaChannel(void);

		guchar* GetPixels(void);

		virtual bool IsReady(void);

		IImageBuffer* Clone(void);

		bool SaveToFile(const char *fileName, const char *format = 0);


	private:
		_GdkPixbuf      *m_pixbuf;
		_GdkPixbuf      *m_croppedBuf;

	};

}
#endif //_HALO_CIMAGEBUFFER_H_
