#ifndef _CLINEARLISTCONTROL_H_
#define _CLINEARLISTCONTROL_H_

namespace HALO
{
	class CLinearListControl : public CDataListControl
	{
	public:
		void GetWindowItemRange(int &startItemIndex, int &endItemIndex);
		EDirectionType ScrollDirection(void)
		{
			return t_type;
		}

		static void CompareIndexRange(int oldStart, int oldEnd, int newStart, int newEnd, int maxIndex, std::vector<int> &loadItem, std::vector<int> &unloadItem, std::vector<int> &noChangeItem);

		virtual const char* GetActorType(void);
	protected:
		struct TLinearListControlAttr : public TDataListControlAttr
		{
			TLinearListControlAttr(float inWidth, float inHeight, EDirectionType inType) : TDataListControlAttr(inWidth, inHeight), type(inType), titleHeight(0), titleSpace(0) {};
			EDirectionType type;
			float titleHeight;
			float titleSpace;
		};

		CLinearListControl(void);
		virtual ~CLinearListControl(void);

		bool t_Initialize(IActor *parent, const TLinearListControlAttr &attr);
		bool t_Initialize(Widget *parent, const TLinearListControlAttr &attr);

		void t_AddItem(int itemNum, float *itemSpaceArray, float spaceBetweenItem = 0);
		void t_InsertItem(int insertPosition, int itemNum, float *itemSpaceArray);
		TRect t_DelelteItem(int fromItem, int deleteItemNum);

		void t_SetItemSpace(int itemIndex, float itemSpace, CMultiObjectTransition *trans = NULL);
		void t_SetItemSpace(int numOfChangeItem, int itemIndex[], float itemSpace[], CMultiObjectTransition *trans = NULL);

		void t_GetInMemoryItems(TRect lastVisibleArea, TRect visibleArea, std::vector<TItem*> &loadItem, std::vector<TItem*> &unloadItem, std::vector<TItem*> &noChangeItem, int reason = -1);

		virtual void t_GetInMemoryItemsOfSubClass(TRect visibleArea, std::vector<TItem*> &loadItem, std::vector<TItem*> &unloadItem, std::vector<TItem*> &noChangeItem, int reason) {};

	protected:

		EDirectionType t_type;

		struct TLinearItem : public TItem
		{
			TLinearItem(CLinearListControl *inOwner) : owner(inOwner) {};

			int index;
			CLinearListControl *owner;
			float spaceToNext;

			float ElementStartPosition(void)
			{
				if (TYPE_VERTICAL == owner->t_type)
				{
					return rect.y;
				}
				else
				{
					return rect.x;
				}
			}

			float ElementEndPosition(void)
			{
				if (TYPE_VERTICAL == owner->t_type)
				{
					return rect.y + rect.h;
				}
				else
				{
					return rect.x + rect.w;
				}
			}
		};

		std::vector<TLinearItem*> t_itemList;

		virtual TLinearItem* t_AllocLinearItem(void) = 0;
		virtual void t_FreeLinearItem(TLinearItem *item) = 0;

		virtual void t_GetRealItems(TLinearItem *item, std::vector<TItem*> &itemList) = 0;

	private:
		float m_itemGroupSpace;

		int m_windowStartItem;
		int m_windowEndItem;

		float m_titleHeight;
		float m_titleSpace;

		void m_GetItemChangeInfo(int oldStart, int oldEnd, int newStart, int newEnd, std::vector<TItem*> &loadItem, std::vector<TItem*> &unloadItem, std::vector<TItem*> &noChangeItem);
		int m_ItemIndexCrossByLine(float linePos, bool flagStartLine);
	};
}

#endif
