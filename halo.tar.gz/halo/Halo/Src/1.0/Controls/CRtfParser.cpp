#include "Halo1_0.h"
#include "CRtfParser.h"
#include <ctype.h>
#include <cstdlib>

#define STRING_TEXT_START "{\\rtf1\\ansi\\deff3\\adeflang1025"
#define STRING_PARA_START "\\pard\\plain \\s0\\ql\\nowidctlpar\\ltrpar\\cf0\\kerning1\\dbch\\af7\\langfe2052\\dbch\\af8\\afs24\\alang1081\\loch\\f4\\fs24\\lang1033"
#define D_MAX_SIZE  256
// RTF parser error codes
#define ecOK 0                      // Everything's fine!
#define ecStackUnderflow    1       // Unmatched '}'
#define ecStackOverflow     2       // Too many '{' -- memory exhausted
#define ecUnmatchedBrace    3       // RTF ended during an open group.
#define ecInvalidHex        4       // invalid hex character found in data
#define ecBadTable          5       // RTF table (sym or prop) invalid
#define ecAssertion         6       // Assertion failure
#define ecEndOfFile         7       // End of file reached while reading RTF


static const char RTF_CTRL_FONTSTYLE_BOLD[] =        {'b', '\0'};
static const char RTF_CTRL_FONTSTYLE_NON_BOLD[] =    {'b', '0', '\0'};
static const char RTF_CTRL_FONTSTYLE_ITALIC[] =      {'i', '\0'};
static const char RTF_CTRL_FONTSTYLE_NON_ITALIC[] =  {'i', '0', '\0'};
static const char RTF_CTRL_FONTSTYLE_UNDERLINE[] =   {'u', 'l', '\0'};
//static const char RTF_CTRL_FONTSTYLE_NON_UNDERLINE[]={'u', 'l', '0', '\0'};
static const char RTF_CTRL_FONTSTYLE_NON_UNDERLINE[]={'u', 'l', 'n', 'o', 'n', 'e', '\0'};
static const char RTF_CTRL_FONTSTYLE_STRIKE[] =      {'s', 't', 'r', 'i', 'k', 'e', '\0'};
static const char RTF_CTRL_FONTSTYLE_NON_STRIKE[] =  {'s', 't', 'r', 'i', 'k', 'e', '0', '\0'};
static const char RTF_CTRL_FONT_SIZE[] =             {'f', 's', '\0'};
static const char RTF_CTRL_FONT_FORMAT[] =           {'f', '\0'};
static const char RTF_CTRL_LINE_SPACE[] =            {'m', 'l', 'g', '\0'};
static const char RTF_CTRL_LINE_ALIGNMENT[] =        {'a', 'l', 'i', 'g', 'n', '\0'};
static const char RTF_CTRL_NEW_PARAGRAPH[] =         {'p', 'a', 'r', '\0'};
static const char RTF_CTRL_DEF_PARAGRAPH_ATTR[] =    {'p', 'a', 'r', 'd', '\0'};
static const char RTF_CTRL_FOREGROUND_COLOR[] =      {'c', 'f', '\0'};
static const char RTF_CTRL_BACKGROUND_COLOR[] =      {'c', 'b', '\0'};
static const char RTF_CTRL_CHARACTER_BACKSLASH =		'\\';
static const char RTF_CTRL_CHARACTER_SPACE =			' ';

static const char RTF_CTRL_PARAGRAPH_ALIGN_LEFT[]=  	  {'\\', 'q', 'l'};
static const char RTF_CTRL_PARAGRAPH_ALIGN_RIGHT[]= 	  {'\\', 'q', 'r'};
static const char RTF_CTRL_PARAGRAPH_ALIGN_CENTER[]= 	  {'\\', 'q', 'c'};
static const char RTF_CTRL_CHAR_FONTSTYLE_BOLD[]=         {'\\', 'b', '\0'};
static const char RTF_CTRL_CHAR_FONTSTYLE_ITALIC[]=       {'\\', 'i', '\0'};
static const char RTF_CTRL_CHAR_FONTSTYLE_UNDERLINE[] =   {'\\', 'u', 'l', '\0'};

namespace HALO
{
	//
	// %%Function: main
	//
	// Main loop. Initialize and parse RTF.
	//

	CRtfParser::PROP CRtfParser::rgprop[ipropMax] = {
		actnByte, propChp, offsetof(CHP, fBold),       // ipropBold
		actnByte, propChp, offsetof(CHP, fItalic),     // ipropItalic
		actnByte, propChp, offsetof(CHP, fUnderline),  // ipropUnderline
		actnWord, propPap, offsetof(PAP, xaLeft),      // ipropLeftInd
		actnWord, propPap, offsetof(PAP, xaRight),     // ipropRightInd
		actnWord, propPap, offsetof(PAP, xaFirst),     // ipropFirstInd
		actnWord, propSep, offsetof(SEP, cCols),       // ipropCols
		actnWord, propSep, offsetof(SEP, xaPgn),       // ipropPgnX
		actnWord, propSep, offsetof(SEP, yaPgn),       // ipropPgnY
		actnWord, propDop, offsetof(DOP, xaPage),      // ipropXaPage
		actnWord, propDop, offsetof(DOP, yaPage),      // ipropYaPage
		actnWord, propDop, offsetof(DOP, xaLeft),      // ipropXaLeft
		actnWord, propDop, offsetof(DOP, xaRight),     // ipropXaRight
		actnWord, propDop, offsetof(DOP, yaTop),       // ipropYaTop
		actnWord, propDop, offsetof(DOP, yaBottom),    // ipropYaBottom
		actnWord, propDop, offsetof(DOP, pgnStart),    // ipropPgnStart
		actnByte, propSep, offsetof(SEP, sbk),         // ipropSbk
		actnByte, propSep, offsetof(SEP, pgnFormat),   // ipropPgnFormat
		actnByte, propDop, offsetof(DOP, fFacingp),    // ipropFacingp
		actnByte, propDop, offsetof(DOP, fLandscape),  // ipropLandscape
		actnByte, propPap, offsetof(PAP, just),        // ipropJust
		actnSpec, propPap, 0,                          // ipropPard
		actnSpec, propChp, 0,                          // ipropPlain
		actnSpec, propSep, 0,                          // ipropSectd
		};

	CRtfParser::SYM CRtfParser::rgsymRtf[] = {
					//  keyword     dflt    fPassDflt   kwd         idx
						"b",        1,      false,     kwdProp,    ipropBold,
						"ul",        1,      false,     kwdProp,    ipropUnderline,//"u"
						"i",        1,      false,     kwdProp,    ipropItalic,
						"li",       0,      false,     kwdProp,    ipropLeftInd,
						"ri",       0,      false,     kwdProp,    ipropRightInd,
						"fi",       0,      false,     kwdProp,    ipropFirstInd,
						"cols",     1,      false,     kwdProp,    ipropCols,
						"sbknone",  sbkNon, false,      kwdProp,    ipropSbk,
						"sbkcol",   sbkCol, false,      kwdProp,    ipropSbk,
						"sbkeven",  sbkEvn, false,      kwdProp,    ipropSbk,
						"sbkodd",   sbkOdd, false,      kwdProp,    ipropSbk,
						"sbkpage",  sbkPg,  false,      kwdProp,    ipropSbk,
						"pgnx",     0,      false,     kwdProp,    ipropPgnX,
						"pgny",     0,      false,     kwdProp,    ipropPgnY,
						"pgndec",   pgDec,  false,      kwdProp,    ipropPgnFormat,
						"pgnucrm",  pgURom, false,      kwdProp,    ipropPgnFormat,
						"pgnlcrm",  pgLRom, false,      kwdProp,    ipropPgnFormat,
						"pgnucltr", pgULtr, false,      kwdProp,    ipropPgnFormat,
						"pgnlcltr", pgLLtr, false,      kwdProp,    ipropPgnFormat,
						"qc",       justC,  false,      kwdProp,    ipropJust,
						"ql",       justL,  false,      kwdProp,    ipropJust,
						"qr",       justR,  false,      kwdProp,    ipropJust,
						"qj",       justF,  false,      kwdProp,    ipropJust,
						"paperw",   12240,  false,     kwdProp,    ipropXaPage,
						"paperh",   15480,  false,     kwdProp,    ipropYaPage,
						"margl",    1800,   false,     kwdProp,    ipropXaLeft,
						"margr",    1800,   false,     kwdProp,    ipropXaRight,
						"margt",    1440,   false,     kwdProp,    ipropYaTop,
						"margb",    1440,   false,     kwdProp,    ipropYaBottom,
						"pgnstart", 1,      false,      kwdProp,    ipropPgnStart,
						"facingp",  1,      false,      kwdProp,    ipropFacingp,
						"landscape",1,      false,      kwdProp,    ipropLandscape,
						"par",      0,      false,     kwdChar,    0x0a,
						"\0x0a",    0,      false,     kwdChar,    0x0a,
						"\0x0d",    0,      false,     kwdChar,    0x0a,
						"tab",      0,      false,     kwdChar,    0x09,
						"ldblquote",0,      false,     kwdChar,    '"',
						"rdblquote",0,      false,     kwdChar,    '"',
						"bin",      0,      false,     kwdSpec,    ipfnBin,
						"*",        0,      false,     kwdSpec,    ipfnSkipDest,
						"'",        0,      false,     kwdSpec,    ipfnHex,
						"author",   0,      false,     kwdDest,    idestSkip,
						"buptim",   0,      false,     kwdDest,    idestSkip,
						"colortbl", 0,      false,     kwdDest,    idestSkip,
						"comment",  0,      false,     kwdDest,    idestSkip,
						"creatim",  0,      false,     kwdDest,    idestSkip,
						"doccomm",  0,      false,     kwdDest,    idestSkip,
						"fonttbl",  0,      false,     kwdDest,    idestSkip,
						"footer",   0,      false,     kwdDest,    idestSkip,
						"footerf",  0,      false,     kwdDest,    idestSkip,
						"footerl",  0,      false,     kwdDest,    idestSkip,
						"footerr",  0,      false,     kwdDest,    idestSkip,
						"footnote", 0,      false,     kwdDest,    idestSkip,
						"ftncn",    0,      false,     kwdDest,    idestSkip,
						"ftnsep",   0,      false,     kwdDest,    idestSkip,
						"ftnsepc",  0,      false,     kwdDest,    idestSkip,
						"header",   0,      false,     kwdDest,    idestSkip,
						"headerf",  0,      false,     kwdDest,    idestSkip,
						"headerl",  0,      false,     kwdDest,    idestSkip,
						"headerr",  0,      false,     kwdDest,    idestSkip,
						"info",     0,      false,     kwdDest,    idestSkip,
						"keywords", 0,      false,     kwdDest,    idestSkip,
						"operator", 0,      false,     kwdDest,    idestSkip,
						"pict",     0,      false,     kwdDest,    idestSkip,
						"printim",  0,      false,     kwdDest,    idestSkip,
						"private1", 0,      false,     kwdDest,    idestSkip,
						"revtim",   0,      false,     kwdDest,    idestSkip,
						"rxe",      0,      false,     kwdDest,    idestSkip,
						"stylesheet",   0,      false,     kwdDest,    idestSkip,
						"subject",  0,      false,     kwdDest,    idestSkip,
						"tc",       0,      false,     kwdDest,    idestSkip,
						"title",    0,      false,     kwdDest,    idestSkip,
						"txe",      0,      false,     kwdDest,    idestSkip,
						"xe",       0,      false,     kwdDest,    idestSkip,
						"{",        0,      false,     kwdChar,    '{',
						"}",        0,      false,     kwdChar,    '}',
						"\\",       0,      false,     kwdChar,    '\\'
						};
	int CRtfParser::isymMax;
	int CRtfParser::cGroup;
	bool CRtfParser::fSkipDestIfUnk;
	long CRtfParser::cbBin;
	long CRtfParser::lParam;
	CRtfParser::E_RDS CRtfParser::rds;
	CRtfParser::E_RIS CRtfParser::ris;
	CRtfParser::CHP CRtfParser::chp;
	CRtfParser::PAP CRtfParser::pap;
	CRtfParser::SEP CRtfParser::sep;
	CRtfParser::DOP CRtfParser::dop;
	CRtfParser::SAVE *CRtfParser::psave;
	FILE *CRtfParser::fpIn;

	//std::list<CRichText::CTCharFormatObj> CRtfParser::tCharList;
	//std::list<CRichText::CTParagraphFormatObj> CRtfParser::tParaList;
	int CRtfParser::sameProCount;
	int CRtfParser::paraLength;
	bool CRtfParser::flagTextContent;
	std::list<char> CRtfParser::rtfParserList;
	std::list<char> CRtfParser::rtfBuildList;

	bool CRtfParser::Initial(void)
	{
		return true;
	}

	//void CRtfParser::ParseRtfFile(const char * filePath, std::list<CRichText::CTCharFormatObj>& resCharList, std::list<CRichText::CTParagraphFormatObj>& resParaList, std::list<char> &textList)
	//{
	//	tCharList.clear();
	//	tParaList.clear();
	//	rtfParserList.clear();
	//	FILE *fp;
	//	int ec;
	//	isymMax = sizeof(rgsymRtf) / sizeof(SYM);
	//	//printf("_%s_%d_ \n", filePath, isymMax);
	//	fp = fpIn = fopen(filePath, "r");
	//	if (!fp)
	//	{
	//		//printf ("Can't open test file!\n");
	//		return;
	//	}
	//	//if ((ec = ecRtfParse(fp)) != ecOK)
	//	//	printf("error %d parsing rtf\n", ec);
	//	//else
	//	//	printf("Parsed RTF file OK \n");

	//	resCharList = tCharList;
	//	resParaList = tParaList;
	//	textList = rtfParserList;

	//	fclose(fp);
	//}

	//
	// %%Function: ecRtfParse
	//
	// Step 1:
	// Isolate RTF keywords and send them to ecParseRtfKeyword;
	// Push and pop state at the start and end of RTF groups;
	// Send text to ecParseChar for further processing.
	//

	int CRtfParser::ecRtfParse(FILE *fp)
	{
		int ch;
		int ec;
		int cNibble = 2;
		int b = 0;
		while ((ch = getc(fp)) != EOF)
		{
			if (cGroup < 0)
			{
				return ecStackUnderflow;
			}
			if (ris == risBin)                      // if we're parsing binary data, handle it directly
			{
				if ((ec = ecParseChar(ch)) != ecOK)
				{
					return ec;
				}
			}
			else
			{
				switch (ch)
				{
				case '{':
					if ((ec = ecPushRtfState()) != ecOK)
					{
						return ec;
					}
					break;
				case '}':
					if ((ec = ecPopRtfState()) != ecOK)
					{
						return ec;
					}
					break;
				case '\\':
					if ((ec = ecParseRtfKeyword(fp)) != ecOK)
					{
						return ec;
					}
					break;
				case 0x0d:
				case 0x0a:          // cr and lf are noise characters...
					break;
				default:
					if (ris == risNorm)
					{
						if ((ec = ecParseChar(ch)) != ecOK)
						{
							return ec;
						}
					}
					else
					{               // parsing hex data
						if (ris != risHex)
						{
							return ecAssertion;
						}
						b = b << 4;
						if (isdigit(ch))
							b += (char) ch - '0';
						else
						{
							if (islower(ch))
							{
								if (ch < 'a' || ch > 'f')
								{
									return ecInvalidHex;
								}
								b += (char) ch - 'a';
							}
							else
							{
								if (ch < 'A' || ch > 'F')
								{
									return ecInvalidHex;
								}
								b += (char) ch - 'A';
							}
						}
						cNibble--;
						if (!cNibble)
						{
							if ((ec = ecParseChar(b)) != ecOK)
							{
								return ec;
							}
							cNibble = 2;
							b = 0;
							ris = risNorm;
						}
					}                   // end else (ris != risNorm)
					break;
				}       // switch
			}           // else (ris != risBin)
		}               // while
		if (cGroup < 0)
		{
			return ecStackUnderflow;
		}
		if (cGroup > 0)
		{
			return ecUnmatchedBrace;
		}
		return ecOK;
	}

	//
	// %%Function: ecPushRtfState
	//
	// Save relevant info on a linked list of SAVE structures.
	//

	int CRtfParser::ecPushRtfState(void)
	{
		SAVE *psaveNew = (SAVE *)malloc(sizeof(SAVE));
		if (!psaveNew)
		{
			return ecStackOverflow;
		}

		psaveNew -> pNext = psave;
		psaveNew -> chp = chp;
		psaveNew -> pap = pap;
		psaveNew -> sep = sep;
		psaveNew -> dop = dop;
		psaveNew -> rds = rds;
		psaveNew -> ris = ris;

		ris = risNorm;
		psave = psaveNew;
		psave->chp.fBold = 0;
		psave->chp.fItalic = 0;
		psave->chp.fUnderline = 0;
		cGroup++;
		sameProCount = 0;
	//	printf("{");
		return ecOK;
	}

	//
	// %%Function: ecPopRtfState
	//
	// If we're ending a destination (that is, the destination is changing),
	// call ecEndGroupAction.
	// Always restore relevant info from the top of the SAVE list.
	//

	int CRtfParser::ecPopRtfState(void)
	{
		//SAVE *psaveOld;
		//int ec;

		//if (!psave)
		//{
		//	return ecStackUnderflow;
		//}

		//if (rds != psave->rds)
		//{
		//	if ((ec = ecEndGroupAction(rds)) != ecOK)
		//	{
		//		return ec;
		//	}
		//}
		//chp = psave->chp;
		//pap = psave->pap;
		//sep = psave->sep;
		//dop = psave->dop;
		//rds = psave->rds;
		//ris = psave->ris;

		//if(flagTextContent)
		//{
		//	CRichText::CTCharFormatObj *tmpCharFormatObj = new CRichText::CTCharFormatObj();
		//	tmpCharFormatObj->charFormat.font = NULL;
		//	tmpCharFormatObj->charFormat.style = 0;
		//	if(chp.fBold == 1)
		//	{
		//		tmpCharFormatObj->charFormat.style |= STYLE_BOLD;
		//	}
		//	if(chp.fItalic == 1)
		//	{
		//		tmpCharFormatObj->charFormat.style |= STYLE_ITALIC;
		//	}
		//	if(chp.fUnderline == 1)
		//	{
		//		tmpCharFormatObj->charFormat.style |= STYLE_UNDERLINE;
		//	}

		//	if(sameProCount > 0)
		//	{
		//		tmpCharFormatObj->count = sameProCount;
		//		paraLength += sameProCount;
		//		//printf("-%d,%d-", tmpCharFormatObj->count, tmpCharFormatObj->charFormat.style);
		//		m_CharFormatListAppendMerge(tCharList, *tmpCharFormatObj);
		//	}
		//	delete tmpCharFormatObj;
		//	tmpCharFormatObj = NULL;
		//}

		//psaveOld = psave;
		//psave = psave->pNext;
		//cGroup--;
		//sameProCount = 0;
		////printf("}\n");
		//free(psaveOld);
		return ecOK;
	}

	//
	// %%Function: ecParseRtfKeyword
	//
	// Step 2:
	// get a control word (and its associated value) and
	// call ecTranslateKeyword to dispatch the control.
	//

	int CRtfParser::ecParseRtfKeyword(FILE *fp)
	{
		int ch;
		bool fParam = false;
		bool fNeg = false;
		int param = 0;
		char *pch;
		char szKeyword[30];
		char szParameter[20];

		szKeyword[0] = '\0';
		szParameter[0] = '\0';
		if ((ch = getc(fp)) == EOF)
		{
			return ecEndOfFile;
		}
		if (!isalpha(ch))           // a control symbol; no delimiter.
		{
			szKeyword[0] = (char) ch;
			szKeyword[1] = '\0';
			return ecTranslateKeyword(szKeyword, 0, fParam);
		}
		for (pch = szKeyword; isalpha(ch); ch = getc(fp))
		{
			*pch++ = (char) ch;
		}
		*pch = '\0';

		if(strcmp(szKeyword, RTF_CTRL_DEF_PARAGRAPH_ATTR) == 0)
		{
			flagTextContent = true;
			paraLength = 0;
		}
		else if(strcmp(szKeyword, RTF_CTRL_NEW_PARAGRAPH) == 0)
		{
			//CRichText::CTParagraphFormatObj *tmpParaFormatObj = new CRichText::CTParagraphFormatObj();
			//tmpParaFormatObj->paraFormat.alignment = psave->pap.just;
			//tmpParaFormatObj->count = paraLength + 1;
			//m_ParaFormatListAppendMerge(tParaList, *tmpParaFormatObj);
			//flagTextContent = false;

			////we have to add '\n' at the end of the para in clutterText, so we have to add the last charFormat count of the parathe to suit
			//CRichText::CTCharFormatObj tmpCharFormatObj = tCharList.back();
			//tmpCharFormatObj.count += 1;
			//tCharList.pop_back();
			//tCharList.push_back(tmpCharFormatObj);

			//delete tmpParaFormatObj;
			//tmpParaFormatObj = NULL;
		}

		if (ch == '-')
		{
			fNeg  = true;
			if ((ch = getc(fp)) == EOF)
			{
				return ecEndOfFile;
			}
		}
		if (isdigit(ch))
		{
			fParam = true;         // a digit after the control means we have a parameter
			for (pch = szParameter; isdigit(ch); ch = getc(fp))
			{
				*pch++ = (char) ch;
			}
			*pch = '\0';
			param = atoi(szParameter);
			if (fNeg)
			{
				param = -param;
			}
			lParam = atol(szParameter);
			if (fNeg)
			{
				param = -param;
			}
		}
		if (ch != ' ')
		{
			ungetc(ch, fp);
		}
		return ecTranslateKeyword(szKeyword, param, fParam);
	}

	//
	// %%Function: ecParseChar
	//
	// Route the character to the appropriate destination stream.
	//

	int CRtfParser::ecParseChar(int ch)
	{
		if (ris == risBin && --cbBin <= 0)
		{
			ris = risNorm;
		}
		switch (rds)
		{
		case rdsSkip:
			// Toss this character.
			return ecOK;
		case rdsNorm:
			// Output a character. Properties are valid at this point.
			sameProCount++;
			if(flagTextContent)
			{
				rtfParserList.push_back((char)ch);
			}
			return ecPrintChar(ch);
		default:
			// handle other destinations....
			return ecOK;
		}
	}

	//
	// %%Function: ecPrintChar
	//
	// Send a character to the output file.
	//

	int CRtfParser::ecPrintChar(int ch)
	{
		// unfortunately, we don't do a whole lot here as far as layout goes...
		putchar(ch);
		return ecOK;
	}

	//
	// %%Function: ecApplyPropChange
	//
	// Set the property identified by _iprop_ to the value _val_.
	//
	//

	int CRtfParser::ecApplyPropChange(IPROP iprop, int val)
	{
		char *pb;

		if (rds == rdsSkip)                 // If we're skipping text,
		{
			return ecOK;                    // don't do anything.
		}

		switch (rgprop[iprop].prop)
		{
		case propDop:
			pb = (char *)&dop;
			break;
		case propSep:
			pb = (char *)&sep;
			break;
		case propPap:
			pb = (char *)&pap;
			break;
		case propChp:
			pb = (char *)&chp;
			break;
		default:
			if (rgprop[iprop].actn != actnSpec)
			{
				return ecBadTable;
			}
			break;
		}
		switch (rgprop[iprop].actn)
		{
		case actnByte:
			pb[rgprop[iprop].offset] = (unsigned char) val;
			break;
		case actnWord:
			(*(int *) (pb+rgprop[iprop].offset)) = val;
			break;
		case actnSpec:
			return ecParseSpecialProperty(iprop, val);
			break;
		default:
			return ecBadTable;
		}
		return ecOK;
	}

	//
	// %%Function: ecParseSpecialProperty
	//
	// Set a property that requires code to evaluate.
	//

	int CRtfParser::ecParseSpecialProperty(IPROP iprop, int val)
	{
		switch (iprop)
		{
		case ipropPard:
			memset(&pap, 0, sizeof(pap));
			return ecOK;
		case ipropPlain:
			memset(&chp, 0, sizeof(chp));
			return ecOK;
		case ipropSectd:
			memset(&sep, 0, sizeof(sep));
			return ecOK;
		default:
			return ecBadTable;
		}
		return ecBadTable;
	}

	//
	// %%Function: ecTranslateKeyword.
	//
	// Step 3.
	// Search rgsymRtf for szKeyword and evaluate it appropriately.
	//
	// Inputs:
	// szKeyword:   The RTF control to evaluate.
	// param:       The parameter of the RTF control.
	// fParam:      fTrue if the control had a parameter; (that is, if param is valid)
	//              fFalse if it did not.
	//

	int CRtfParser::ecTranslateKeyword(char *szKeyword, int param, bool fParam)
	{
		int isym;

		// search for szKeyword in rgsymRtf
		for (isym = 0; isym < isymMax; isym++)
		{
			if (strcmp(szKeyword, rgsymRtf[isym].szKeyword) == 0)
			{
				break;
			}
		}
		if (isym == isymMax)            // control word not found
		{
			if (fSkipDestIfUnk)         // if this is a new destination
			{
				rds = rdsSkip;          // skip the destination
			}
										// else just discard it
			fSkipDestIfUnk = false;
			return ecOK;
		}

		// found it!  use kwd and idx to determine what to do with it.

		if(flagTextContent)
		{
			if(strcmp(szKeyword, rgsymRtf[2].szKeyword) == 0 && !fParam)// "i"
			{
				psave->chp.fItalic = 1;
				//printf("_i1_");
			}
			if(strcmp(szKeyword, rgsymRtf[0].szKeyword) == 0 && !fParam)// "b"
			{
				psave->chp.fBold = 1;
				//printf("_b1_");
			}
			if(strcmp(szKeyword, rgsymRtf[1].szKeyword) == 0)//"ul"
			{
				psave->chp.fUnderline = 1;
				//printf("_u1_");
			}
			if(strcmp(szKeyword, rgsymRtf[19].szKeyword) == 0)//"qc"
			{
				psave->pap.just = justC;
			}
			if(strcmp(szKeyword, rgsymRtf[20].szKeyword) == 0)//"ql"
			{
				psave->pap.just = justL;
			}
			if(strcmp(szKeyword, rgsymRtf[21].szKeyword) == 0)//"qr"
			{
				psave->pap.just = justR;
			}
			if(strcmp(szKeyword, rgsymRtf[22].szKeyword) == 0)//"qj"
			{
				psave->pap.just = justF;
			}
		}

		fSkipDestIfUnk = false;
		switch (rgsymRtf[isym].kwd)
		{
		case kwdProp:
			if (rgsymRtf[isym].fPassDflt || !fParam)
			{
				param = rgsymRtf[isym].dflt;
			}
			return ecApplyPropChange((IPROP)rgsymRtf[isym].idx, param);
		case kwdChar:
			return ecParseChar(rgsymRtf[isym].idx);
		case kwdDest:
			return ecChangeDest((E_IDEST)rgsymRtf[isym].idx);
		case kwdSpec:
			return ecParseSpecialKeyword((E_IPFN)rgsymRtf[isym].idx);
		default:
			return ecBadTable;
		}
		return ecBadTable;
	}

	//
	// %%Function: ecChangeDest
	//
	// Change to the destination specified by idest.
	// There's usually more to do here than this...
	//

	int CRtfParser::ecChangeDest(E_IDEST idest)
	{
		if (rds == rdsSkip)             // if we're skipping text,
		{
			return ecOK;                // don't do anything
		}


		rds = rdsSkip;
		//switch (idest)
		//{
		//default:
		//	rds = rdsSkip;              // when in doubt, skip it...
		//	break;
		//}
		return ecOK;
	}

	//
	// %%Function: ecEndGroupAction
	//
	// The destination specified by rds is coming to a close.
	// If there's any cleanup that needs to be done, do it now.
	//

	int CRtfParser::ecEndGroupAction(E_RDS rds)
	{
		return ecOK;
	}

	//
	// %%Function: ecParseSpecialKeyword
	//
	// Evaluate an RTF control that needs special processing.
	//

	int CRtfParser::ecParseSpecialKeyword(E_IPFN ipfn)
	{
		if (rds == rdsSkip && ipfn != ipfnBin)  // if we're skipping, and it's not
		{
			return ecOK;                        // the \bin keyword, ignore it.
		}
		switch (ipfn)
		{
		case ipfnBin:
			ris = risBin;
			cbBin = lParam;
			break;
		case ipfnSkipDest:
			fSkipDestIfUnk = false;
			break;
		case ipfnHex:
			ris = risHex;
			break;
		default:
			return ecBadTable;
		}
		return ecOK;
	}

	/*int CRtfParser::m_CharFormatListAppendMerge(std::list<CRichText::CTCharFormatObj>& tCharList, CRichText::CTCharFormatObj& stCharFormat)
	{
		if (tCharList.empty() && stCharFormat.count > 0)
		{
			tCharList.push_back(stCharFormat);
			return 0;
		}
		CRichText::CTCharFormatObj& stCharFormatTemp = tCharList.back();
		if (stCharFormatTemp.charFormat == stCharFormat.charFormat)
		{
			stCharFormatTemp.count += stCharFormat.count;
		}
		else
		{
			if(stCharFormat.count > 0)
			{
				tCharList.push_back(stCharFormat);
			}
		}
		return 0;
	}*/

	/*int CRtfParser::m_ParaFormatListAppendMerge(std::list<CRichText::CTParagraphFormatObj>& tParaList, CRichText::CTParagraphFormatObj& stParaFormat)
	{
		if (tParaList.empty())
		{
			printf("\n<---1--->\n");
			tParaList.push_back(stParaFormat);
			return 0;
		}
		CRichText::CTParagraphFormatObj& stParaFormatTemp = tParaList.back();
		if (stParaFormatTemp.paraFormat == stParaFormat.paraFormat)
		{
			stParaFormatTemp.count += stParaFormat.count;
		}
		else
		{
			printf("\n<---2--->\n");
			tParaList.push_back(stParaFormat);
		}
		tParaList.push_back(stParaFormat);
		return 0;

	}*/

//	int CRtfParser::m_ProduceParaText(CRichText::CTParagraphFormat& stParaFormatCurrent, CRichText::CTParagraphFormat& stParaFormatPrev, char* stRTFBuffer, unsigned int uiRTFBuffersize)
//	{
//		if (NULL == stRTFBuffer || uiRTFBuffersize == 0)
//		{
//			return -1;
//		}
//
//		//unsigned int j = 0;
//	   // const unsigned int uiBufSize = 32;
//		//char strBuf[uiBufSize] = {0};
//		unsigned int iLength = 0;
//		unsigned int iIndex = 0;
//
////		PCMem::Set(stRTFBuffer, 0, uiRTFBuffersize * sizeof(PTWChar));
//		memset(stRTFBuffer, 0, uiRTFBuffersize * sizeof(char));
//
//		//line gap
////		if (stParaFormatCurrent.lineGap != stParaFormatPrev.lineGap)
////		{
//////			iLength = PCWString::Length((const PTWChar*)RTF_CTRL_LINE_SPACE);
////			iLength = strlen((const char*)RTF_CTRL_LINE_SPACE);
////	        if (iIndex + iLength < uiRTFBuffersize - 1)
////	        {
//////	            PCWString::Concate(stRTFBuffer, (const PTWChar*)RTF_CTRL_LINE_SPACE , iLength);
////	            strcat(stRTFBuffer, (const char*)RTF_CTRL_LINE_SPACE);
////	    		iIndex += iLength;
////	        }
////			m_ConvertNumToString(stParaFormatCurrent.lineGap, strBuf);
////
////			j = 0;
////			while ('\0' != strBuf[j] && iIndex < uiRTFBuffersize - 1)
////			{
////				stRTFBuffer[iIndex++] = strBuf[j++];
////			}
////		}
//
//		iLength = 3;
//		//alignment
////		if (stParaFormatCurrent.alignment != stParaFormatPrev.alignment)
////		{
//			int val_align = stParaFormatCurrent.alignment;
//			switch(val_align)
//			{
//			case justL:
//				if (iIndex + iLength < uiRTFBuffersize - 1)
//				{
//					stRTFBuffer[iIndex++] = '\\';
//					stRTFBuffer[iIndex++] = 'q';
//					stRTFBuffer[iIndex++] = 'l';
////					strcat(stRTFBuffer, "ql");
////					iIndex += iLength;
//				}
//				break;
//			case justC:
//				if (iIndex + iLength < uiRTFBuffersize - 1)
//				{
//					stRTFBuffer[iIndex++] = '\\';
//					stRTFBuffer[iIndex++] = 'q';
//					stRTFBuffer[iIndex++] = 'c';
////					strcat(stRTFBuffer, "qc");
////					iIndex += iLength;
//				}
//				break;
//			case justR:
//				if (iIndex + iLength < uiRTFBuffersize - 1)
//				{
//					stRTFBuffer[iIndex++] = '\\';
//					stRTFBuffer[iIndex++] = 'q';
//					stRTFBuffer[iIndex++] = 'r';
////					strcat(stRTFBuffer, "qr");
////					iIndex += iLength;
//				}
//				break;
//			default:
//				if (iIndex + iLength < uiRTFBuffersize - 1)
//				{
//					stRTFBuffer[iIndex++] = '\\';
//					stRTFBuffer[iIndex++] = 'q';
//					stRTFBuffer[iIndex++] = 'l';
//				}
//				break;
//			}
//	      //  if (iIndex + iLength < uiRTFBuffersize - 1)
//	      //  {
//	    		//PCWString::Concate(stRTFBuffer, (const PTWChar*)RTF_CTRL_LINE_ALIGNMENT , iLength);
//	    		//strcat(stRTFBuffer, key_align);
//	    		//iIndex += iLength;
//	      //  }
//	        //printf("\n***---align = %s \n", stRTFBuffer);
//			//m_ConvertNumToString(stParaFormatCurrent.alignment, strBuf);
//
////			j = 0;
////			while ('\0' != strBuf[j] && iIndex < uiRTFBuffersize - 1)
////			{
////				stRTFBuffer[iIndex++] = strBuf[j++];
////			}
////		}
//		return 0;
//	}

//	int CRtfParser::m_ProduceCharText(CRichText::CTCharFormat& stCharFormatCurrent, CRichText::CTCharFormat& stCharFormatPrev, char* stRTFBuffer, unsigned int uiRTFBuffersize)
//	{
//		if (NULL == stRTFBuffer || uiRTFBuffersize == 0)
//		{
//			return -1;
//		}
//
////		PCMem::Set(stRTFBuffer, 0, uiRTFBuffersize * sizeof(PTWChar));
//		memset(stRTFBuffer, 0, uiRTFBuffersize * sizeof(char));
//
//	    //const unsigned int uiBufSize = 32;
//		//char strBuf[uiBufSize] = {0};
//		unsigned int iIndex = 0;
//		//unsigned int iLength = 0;
//		//unsigned int j = 0;
//		//char strBufStyle[uiBufSize] = {0};
//		//font
//		if (NULL != stCharFormatCurrent.fontFilePath)
//		{
//			if (stCharFormatPrev.fontFilePath == NULL || 0 != strcmp(stCharFormatPrev.fontFilePath, stCharFormatCurrent.fontFilePath))
//			{
//				j =  strlen(stCharFormatCurrent.fontFilePath);
////				iLength = PCWString::Length((const PTWChar*)RTF_CTRL_FONT_FORMAT);
//				strlen((const char*)RTF_CTRL_FONT_FORMAT);
//				if (iIndex + iLength + j + 2 < uiRTFBuffersize - 1)
//				{
////					PCWString::Concate(stRTFBuffer, (const PTWChar*)RTF_CTRL_FONT_FORMAT, iLength);
//					strcat(stRTFBuffer, (const char*)RTF_CTRL_FONT_FORMAT);
//					iIndex += iLength;
//					stRTFBuffer[iIndex++] = '(';
////					PCWString::Concate(stRTFBuffer, stCharFormatCurrent.fontFilePath, j);
//					strcat(stRTFBuffer, stCharFormatCurrent.fontFilePath);
//					iIndex += j;
//					stRTFBuffer[iIndex++] = ')';
//				}
//				else
//				{
//					return -1;
//				}
//			}
//		}
//		else
//		{
//			return -1;
//		}
//
//		//font size
//		if (0 != stCharFormatCurrent.size)
//		{
//			if (stCharFormatCurrent.size != stCharFormatPrev.size)
//			{
//				if (m_ConvertNumToString(stCharFormatCurrent.size, strBuf))
//				{
//					j = 0;
////					iLength = PCWString::Length((const PTWChar*)RTF_CTRL_FONT_SIZE);
//					strlen((const char*)RTF_CTRL_FONT_SIZE);
//					if (iIndex + iLength < uiRTFBuffersize - 1)
//					{
////						PCWString::Concate(stRTFBuffer, (const PTWChar*)RTF_CTRL_FONT_SIZE, iLength);
//						strcat(stRTFBuffer, (const char*)RTF_CTRL_FONT_SIZE);
//						iIndex += iLength;
//					}
//
//					while ('\0' != strBuf[j] && iIndex < uiRTFBuffersize - 1)
//					{
//						stRTFBuffer[iIndex++] = strBuf[j++];
//					}
//				}
//			}
//		}
//
//		stRTFBuffer[iIndex++] = '{';
//		uiRTFBuffersize++;
//
////		if (stCharFormatCurrent.style != stCharFormatPrev.style)
////		{
//		m_ProduceCharFormatStyle(stCharFormatCurrent.style, stCharFormatPrev.style, RTF_CTRL_CHAR_FONTSTYLE_BOLD, stRTFBuffer, uiRTFBuffersize, iIndex);
//
//			//m_ProduceCharFormatStyle(stCharFormatCurrent.style, stCharFormatPrev.style, STYLE_BOLD, RTF_CTRL_CHAR_FONTSTYLE_BOLD, stRTFBuffer, uiRTFBuffersize, iIndex);
//			//m_ProduceCharFormatStyle(stCharFormatCurrent.style, stCharFormatPrev.style, STYLE_ITALIC, RTF_CTRL_CHAR_FONTSTYLE_ITALIC, stRTFBuffer, uiRTFBuffersize, iIndex);
//			//m_ProduceCharFormatStyle(stCharFormatCurrent.style, stCharFormatPrev.style, STYLE_UNDERLINE, RTF_CTRL_CHAR_FONTSTYLE_UNDERLINE, stRTFBuffer, uiRTFBuffersize, iIndex);
//			//m_ProduceCharFormatStyle(stCharFormatCurrent.style, stCharFormatPrev.style, STYLE_STRIKE, RTF_CTRL_FONTSTYLE_STRIKE, stRTFBuffer, uiRTFBuffersize, iIndex);
////		}
//
////		m_ProduceCharFormatColor(stCharFormatCurrent.fgColor, stCharFormatPrev.fgColor, RTF_CTRL_FOREGROUND_COLOR, stRTFBuffer, uiRTFBuffersize, iIndex);
////		m_ProduceCharFormatColor(stCharFormatCurrent.bgColor, stCharFormatPrev.bgColor, RTF_CTRL_BACKGROUND_COLOR, stRTFBuffer, uiRTFBuffersize, iIndex);
//		return 0;
//	}

//	int CRtfParser::m_ProduceCharFormatStyle(unsigned long &ulCurrentStyle, unsigned long &ulPreviousStyle, const char* pRTFCtrl, char* stRTFBuffer, unsigned int uiRTFBuffersize, unsigned int &iIndex)
//	{
////		if ((ulCurrentStyle & eFontStyle) != (ulPreviousStyle & eFontStyle))
////		{
//			int bold = ulCurrentStyle & STYLE_BOLD;
//			int italic= ulCurrentStyle & STYLE_ITALIC;
//			int unline = ulCurrentStyle & STYLE_UNDERLINE;
//			//printf("\n=%d_%d,%d,%d=\n", ulCurrentStyle, bold, italic, unline);
//
//			if(bold == STYLE_BOLD)
//			{
//				unsigned int iLength = strlen(RTF_CTRL_CHAR_FONTSTYLE_BOLD);
//				//strcat(stRTFBuffer, RTF_CTRL_CHAR_FONTSTYLE_BOLD);
//				strncat(stRTFBuffer, RTF_CTRL_CHAR_FONTSTYLE_BOLD, iLength);
//				iIndex += iLength;
////				stRTFBuffer[iIndex++] = '0';
//			}
//			if(italic == STYLE_ITALIC)
//			{
//				unsigned int iLength = strlen(RTF_CTRL_CHAR_FONTSTYLE_ITALIC);
//				//strcat(stRTFBuffer, RTF_CTRL_CHAR_FONTSTYLE_ITALIC);
//				strncat(stRTFBuffer, RTF_CTRL_CHAR_FONTSTYLE_ITALIC, iLength);
//				iIndex += iLength;
////				stRTFBuffer[iIndex++] = '0';
//			}
//			if(unline == STYLE_UNDERLINE)
//			{
//				unsigned int iLength = strlen(RTF_CTRL_CHAR_FONTSTYLE_UNDERLINE);
//				//strcat(stRTFBuffer, RTF_CTRL_CHAR_FONTSTYLE_UNDERLINE);
//				strncat(stRTFBuffer, RTF_CTRL_CHAR_FONTSTYLE_UNDERLINE, iLength);
//				iIndex += iLength;
////				stRTFBuffer[iIndex++] = '0';
//			}
//
//			unsigned int iLength = strlen(pRTFCtrl);
//			if (iIndex + iLength < uiRTFBuffersize - 1)
//			{
//				if ((ulCurrentStyle & eFontStyle) == 0)
//				{
//					if ((iIndex + iLength + 1) < (uiRTFBuffersize - 1))
//					{
////						PCWString::Concate(stRTFBuffer, pRTFCtrl, iLength);
//						//printf("\n=%s=\n", pRTFCtrl);
//						strcat(stRTFBuffer, pRTFCtrl);
//						iIndex += iLength;
//						stRTFBuffer[iIndex++] = '0';
//					}
//					else
//					{
//						return -1;
//					}
//				}
//				else
//				{
////					PCWString::Concate(stRTFBuffer, pRTFCtrl, iLength);
//					strcat(stRTFBuffer, pRTFCtrl);
//					iIndex += iLength;
//				}
//			}
//			else
//			{
//				return -1;
//			}
////		}
//		return 0;
//	}

//	int CRtfParser::m_ProduceCharFormatColor(ClutterColor currentColor, ClutterColor previousColor, const char* pRTFCtrl, char* stRTFBuffer, unsigned int uiRTFBuffersize, unsigned int &iIndex)
//	{
////		if (previousColor[0] != currentColor[0]
////			|| previousColor[1] != currentColor[1]
////			|| previousColor[2] != currentColor[2]
////			|| previousColor[3] != currentColor[3])
////		{
////			unsigned int iLength = PCWString::Length(pRTFCtrl);
////			if (iIndex + iLength < uiRTFBuffersize - 1)
////			{
////				PCWString::Concate(stRTFBuffer, pRTFCtrl, iLength);
////				iIndex += iLength;
////			}
////
////			for (unsigned int j = 0; j < 4; ++j)
////			{
////			    const unsigned int uiBufSize = 32;
////				PTWChar strBuf[uiBufSize] = {0};
////				m_ConvertNumToString(currentColor[j], strBuf, true);
////				if (iIndex + 3 < uiRTFBuffersize - 1)
////				{
////					PCWString::Concate(stRTFBuffer, strBuf, 3);
////					iIndex += 3;
////				}
////			}
////		}
//		return 0;
//	}

//	int CRtfParser::m_ParseCharFormatStyle(char* pRTFText, unsigned int &i, CRichText::CTCharFormatObj& stCharFormat, E_FONTSTYLE eStyle)
//	{
//		if (L'0' == pRTFText[i])
//		{
//			++i;
//			stCharFormat.charFormat.style &= ~eStyle;
//		}
//		else
//		{
//			stCharFormat.charFormat.style |= eStyle;
//		}
//		return 0;
//	}
//
//	int CRtfParser::m_ParseCharFormatColor(char* pRTFText, unsigned int &i, ClutterColor color)
//	{
////		unsigned int iPos = 0;
////
////		CColorAttr iColor = 0;
////
////		while (pRTFText[i] > 0x2F && pRTFText[i] < 0x3A && iPos < 12)
////		{
////			iColor = iColor * 10 + pRTFText[i] - L'0';
////			++iPos;
////			++i;
////
////			if (0 == iPos % 3)
////			{
////				color[(iPos / 3) - 1] = iColor;
////				iColor = 0;
////			}
////		}
//		return 0;
//	}
//
//	bool CRtfParser::BuildRtfFile(const char * charbuf, int offset, std::list<CRichText::CTCharFormatObj> charList, std::list<CRichText::CTParagraphFormatObj> paraList, std::list<char> &textList, int &textBufLen)
//	{
//		std::list<CRichText::CTCharFormatObj>::iterator iterChar = charList.begin();
//		std::list<CRichText::CTParagraphFormatObj>::iterator iterPara = paraList.begin();
//		if(iterChar == charList.end())
//		{
//			return 0;
//		}
//		CRichText::CTCharFormatObj curCharFormatObj = *iterChar;
//		if(iterPara == paraList.end())
//		{
//			return 0;
//		}
//		CRichText::CTParagraphFormatObj curParaFormatObj = *iterPara;
//
//		CRichText::CTCharFormat preCharFormat;
//		CRichText::CTParagraphFormat preParaFormat;
//		unsigned int uiOriginalTextOffset = offset;
//
//		unsigned int iLength = 0;
//		unsigned int iRTFIndex = 0;
//		unsigned int iTextIndex = 0;
//		unsigned int iTextLength = strlen(charbuf);
//		bool bChangeFlag = false;
//		unsigned int iTempIndex = 0;
//		char *strRtfText = (char*)malloc(D_MAX_SIZE*sizeof(char));
//		char *strBuf = (char*)malloc(D_MAX_SIZE*sizeof(char));
//		memset(strBuf, 0, D_MAX_SIZE*sizeof(char));
//		const char *pText = charbuf + offset;
//
//		int len = strlen(STRING_TEXT_START);
//		char *strRtfStart = (char*)malloc(sizeof(char)* len);
//		memset(strRtfStart, 0, sizeof(char)* len);
//		//strcpy(strRtfStart, STRING_TEXT_START);
//		strncpy(strRtfStart, STRING_TEXT_START, len);
//
//		unsigned int len_rtfStart = strlen(strRtfStart);
//		for(iRTFIndex=0; iRTFIndex<len_rtfStart; iRTFIndex++)
//		{
//			textList.push_back((char)strRtfStart[iRTFIndex]);
//		}
//
//		int len_paraStart = strlen(STRING_PARA_START);
//		char *strParaStart = (char*)malloc(sizeof(char)* len_paraStart);
//		memset(strParaStart, 0, sizeof(char)* len_paraStart);
//		//strcpy(strParaStart, STRING_PARA_START);
//		strncpy(strParaStart, STRING_PARA_START, len_paraStart);
//
//		for (iTextIndex = 0; iTextIndex < iTextLength;)
//		{
//			bChangeFlag = false;
//
//			iTempIndex = 0;
//
////			strRtfText[0] = '\0';
//			memset(strRtfText, 0, D_MAX_SIZE*sizeof(char));
//
//			//int tmpcount = iterPara->count;
//			//para keyword start
//			if (curParaFormatObj.count == iterPara->count)
//			{
//				m_ProduceParaText(curParaFormatObj.paraFormat, preParaFormat, strBuf, D_MAX_SIZE);
//				iLength = strlen(strBuf);
//				if ((iLength > 0) && ((strlen(strRtfText) + iLength) < D_MAX_SIZE))
//				{
//					bChangeFlag = true;
//
//					//add /pard...
//					//strcat(strRtfText, strParaStart);
//					strncat(strRtfText, strParaStart, len_paraStart);
//					iTempIndex += strlen(strParaStart);
//					//strcat(strRtfText, strBuf);
//					strncat(strRtfText, strBuf, iLength);
//					iTempIndex += iLength;
//					strRtfText[iTempIndex] = '\0';
//				}
//				//printf("*%s*", strRtfText);
//			}
//
//			//char keyword start
//			if (curCharFormatObj.count == iterChar->count)
//			{
//				m_ProduceCharText(curCharFormatObj.charFormat, preCharFormat, strBuf, D_MAX_SIZE);
//				iLength = strlen(strBuf);
//				if (iLength > 0 && ((strlen(strRtfText) + iLength) < D_MAX_SIZE))
//				{
//					bChangeFlag = true;
//					//strcat(strRtfText, strBuf);
//					strncat(strRtfText, strBuf, iLength);
//					iTempIndex += iLength;
//					strRtfText[iTempIndex] = '\0';
//				}
//				//printf("-%s-", strRtfText);
//			}
//
//			if (bChangeFlag)
//			{
//				iLength = strlen(strRtfText);
//				if (iLength > 0)
//				{
//					for (unsigned int k = 0; k < iLength; ++k)
//					{
//						textList.push_back((char)strRtfText[k]);
//					}
//					textList.push_back('\n');
//				}
//			}
//
//			while (pText[iTextIndex] != '\0' && curParaFormatObj.count > 0 && curCharFormatObj.count > 0)
//			{
//				if(pText[iTextIndex] != '\n')
//				{
//					textList.push_back((char)pText[iTextIndex]);
//					//printf("%c", pText[iTextIndex]);
//				}
//				offset = uiOriginalTextOffset + iTextIndex;
//				curParaFormatObj.count--;
//				curCharFormatObj.count--;
//				
//				bChangeFlag = false;
//				++iTextIndex;
//			}
//
//			if (curCharFormatObj.count == 0)
//			{
//				textList.push_back('}');
//				//printf("}");
//				++iterChar;
//				if (iterChar == charList.end())
//				{
//					//end
//					//return 0;
//				}
//				else
//				{
//					preCharFormat = curCharFormatObj.charFormat;
//					curCharFormatObj = *iterChar;
//				}
//			}
//
//			if (curParaFormatObj.count == 0)
//			{
//				textList.push_back('\\');
//				textList.push_back('p');
//				textList.push_back('a');
//				textList.push_back('r');
//				textList.push_back(' ');
//				//printf("\par ");
//				++iterPara;
//				if (iterPara == paraList.end())
//				{
//					//end
//					textList.push_back('}');
//					free(strRtfText);
//					strRtfText = NULL;
//
//					free(strBuf);
//					strBuf = NULL;
//
//					free(strRtfStart);
//					strRtfStart = NULL;
//
//					free(strParaStart);
//					strParaStart = NULL;
//
//					return 0;
//				}
//				preParaFormat = curParaFormatObj.paraFormat;
//				curParaFormatObj = *iterPara;
//			}
//
//			if (pText[iTextIndex] == '\0')
//			{
//				//end
//				free(strRtfText);
//				strRtfText = NULL;
//
//				free(strBuf);
//				strBuf = NULL;
//
//				free(strRtfStart);
//				strRtfStart = NULL;
//
//				free(strParaStart);
//				strParaStart = NULL;
//
//				return 0;
//			}
//		}
//		textList = rtfBuildList;
//
//		free(strRtfText);
//		strRtfText = NULL;
//
//		free(strBuf);
//		strBuf = NULL;
//
//		free(strRtfStart);
//		strRtfStart = NULL;
//
//		free(strParaStart);
//		strParaStart = NULL;
//
//		return 0;
//	}

}
