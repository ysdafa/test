#include "Halo1_0.h"

static HALO::util::Logger LOGGER("CMultiImage");

namespace HALO
{

	CMultiImage::CMultiImage(void)
	{

	}

	CMultiImage::~CMultiImage(void)
	{
		H_LOG_TRACE(LOGGER, "CMultiImage::~CMultiImage.");
	}

	bool CMultiImage::Initialize(IActor* parent, float width, float height)
	{
		Widget * widget = dynamic_cast<Widget*>(parent);
		Initialize(widget, width, height);

		return true;
	}

	bool CMultiImage::Initialize(Widget* parent, float width, float height)
	{
		CImage::Initialize(parent, width, height);

		ClutterSize size = {width, height};
		clutter_group_content_set_content_size(CLUTTER_GROUP_CONTENT(t_content), &size);

		return true;
	}

	ClutterContent * CMultiImage::t_CreateContent()
	{
		return clutter_group_content_new();
	}

	void CMultiImage::AddIcon(const char* path, TRect icon_rect, int opacity)
	{
		IconInfo icon;
		IImageBuffer *buffer = IImageBuffer::CreateInstance(path);
		icon.image = clutter_image_new();
		clutter_image_set_data(CLUTTER_IMAGE(icon.image),
			buffer->GetPixels(),
			buffer->HasAlphaChannel() ? COGL_PIXEL_FORMAT_RGBA_8888 : COGL_PIXEL_FORMAT_RGB_888,
			buffer->Width(),
			buffer->Height(),
			buffer->BytesPerLine(),
			NULL);
		buffer->Release();
		ClutterActorBox box = { 
			icon_rect.x,
			icon_rect.y,
			icon_rect.x + icon_rect.w,
			icon_rect.y + icon_rect.h };
		icon.id = clutter_group_content_add_image(CLUTTER_GROUP_CONTENT(t_content), CLUTTER_IMAGE(icon.image), box, opacity);

		m_icons.push_back(icon);
	}

	bool CMultiImage::SetIcon(int index, const char*path)
	{
		ASSERT(index >= 0 && index < m_icons.size());

		IImageBuffer *buffer = IImageBuffer::CreateInstance(path);
		clutter_image_set_data(CLUTTER_IMAGE(m_icons[index].image),
			buffer->GetPixels(),
			buffer->HasAlphaChannel() ? COGL_PIXEL_FORMAT_RGBA_8888 : COGL_PIXEL_FORMAT_RGB_888,
			buffer->Width(),
			buffer->Height(),
			buffer->BytesPerLine(),
			NULL);
		buffer->Release();
		gboolean ret = clutter_group_content_replace_image_withid(CLUTTER_GROUP_CONTENT(t_content), CLUTTER_IMAGE(m_icons[index].image), m_icons[index].id);

		return (ret != FALSE ? true : false);
	}

	int CMultiImage::IconCount(void)
	{
		return m_icons.size();
	}

	void CMultiImage::GetIconRect(int index, TRect &icon_rect)
	{
		ASSERT(index >= 0 && index < m_icons.size());

		ClutterActorBox box;
		clutter_group_content_get_image_box_withid(CLUTTER_GROUP_CONTENT(t_content), m_icons[index].id, &box);

		icon_rect.x = box.x1;
		icon_rect.y = box.y1;
		icon_rect.w = box.x2 - box.x1;
		icon_rect.h = box.y2 - box.y1;
	}

}

 /* namespace HALO */
