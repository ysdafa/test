#include "Halo1_0.h"

static HALO::util::Logger LOGGER("CMultiImage");

namespace HALO
{

	CMultiImage::CMultiImage(void)
	{

	}

	CMultiImage::~CMultiImage(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
	}

	bool CMultiImage::Initialize(IActor* parent, float width, float height)
	{
		Widget * widget = dynamic_cast<Widget*>(parent);
		Initialize(widget, width, height);

		return true;
	}

	bool CMultiImage::Initialize(Widget* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] parent("<<parent<< ") width(" << width <<") height(" <<height <<")");
		CImage::Initialize(parent, width, height);

		ClutterSize size = {width, height};
		clutter_group_content_set_content_size(CLUTTER_GROUP_CONTENT(t_content), &size);

		return true;
	}

	ClutterContent * CMultiImage::t_CreateContent()
	{
		return clutter_group_content_new();
	}

	void CMultiImage::AddIcon(const char* path, TRect icon_rect, int opacity)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] path(" << path << ") icon_rect(x:" << icon_rect.x <<",y:"<<icon_rect.y <<",width:" <<icon_rect.w <<",height:" << icon_rect.h << ") opacity(" << opacity << ")");
		HALO_ASSERT(path != NULL);

		IconInfo icon;
		IImageBuffer *buffer = IImageBuffer::CreateInstance(path);
		icon.image = clutter_image_new();
		if (buffer)
		{
			if (buffer->IsReady())
			{
				clutter_image_set_data(CLUTTER_IMAGE(icon.image),
					buffer->GetPixels(),
					buffer->HasAlphaChannel() ? COGL_PIXEL_FORMAT_RGBA_8888 : COGL_PIXEL_FORMAT_RGB_888,
					buffer->Width(),
					buffer->Height(),
					buffer->BytesPerLine(),
					NULL);
			}
			buffer->Release();
		}

		ClutterActorBox box = { 
			icon_rect.x,
			icon_rect.y,
			icon_rect.x + icon_rect.w,
			icon_rect.y + icon_rect.h };
		icon.id = clutter_group_content_add_image(CLUTTER_GROUP_CONTENT(t_content), CLUTTER_IMAGE(icon.image), box, opacity);
		icon.opacity = opacity;

		m_icons.push_back(icon);
	}

	void CMultiImage::AddIcon(IImageBuffer *buffer, TRect icon_rect, int opacity)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] buffer(" << buffer << ") icon_rect(x:" << icon_rect.x << ",y:" << icon_rect.y << ",width:" << icon_rect.w << ",height:" << icon_rect.h << ") opacity(" << opacity << ")");
		HALO_ASSERT(buffer != NULL);

		IconInfo icon;
		icon.image = clutter_image_new();
		if (buffer->IsReady())
		{
			clutter_image_set_data(CLUTTER_IMAGE(icon.image),
				buffer->GetPixels(),
				buffer->HasAlphaChannel() ? COGL_PIXEL_FORMAT_RGBA_8888 : COGL_PIXEL_FORMAT_RGB_888,
				buffer->Width(),
				buffer->Height(),
				buffer->BytesPerLine(),
				NULL);
		}

		ClutterActorBox box = {
			icon_rect.x,
			icon_rect.y,
			icon_rect.x + icon_rect.w,
			icon_rect.y + icon_rect.h };
		icon.id = clutter_group_content_add_image(CLUTTER_GROUP_CONTENT(t_content), CLUTTER_IMAGE(icon.image), box, opacity);
		icon.opacity = opacity;

		m_icons.push_back(icon);
	}

	void CMultiImage::AddIcon(ClutterContent *image, TRect icon_rect, int opacity)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] image(" << image << ") icon_rect(x:" << icon_rect.x << ",y:" << icon_rect.y << ",width:" << icon_rect.w << ",height:" << icon_rect.h << ") opacity(" << opacity << ")");
		HALO_ASSERT(image != NULL);

		IconInfo icon;
		icon.image = image;
		ClutterActorBox box = {
			icon_rect.x,
			icon_rect.y,
			icon_rect.x + icon_rect.w,
			icon_rect.y + icon_rect.h };
		icon.id = clutter_group_content_add_image(CLUTTER_GROUP_CONTENT(t_content), CLUTTER_IMAGE(icon.image), box, opacity);
		icon.opacity = opacity;

		m_icons.push_back(icon);
	}



	bool CMultiImage::SetIcon(int index, const char*path, int opacity)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") path(" << path << ") opacity(" << opacity << ")");
		HALO_ASSERT(index >= 0 && index < (int)m_icons.size());
		HALO_ASSERT(path != NULL);

		IImageBuffer *buffer = IImageBuffer::CreateInstance(path);
		if (buffer)
		{
			if (buffer->IsReady())
			{
				clutter_image_set_data(CLUTTER_IMAGE(m_icons[index].image),
					buffer->GetPixels(),
					buffer->HasAlphaChannel() ? COGL_PIXEL_FORMAT_RGBA_8888 : COGL_PIXEL_FORMAT_RGB_888,
					buffer->Width(),
					buffer->Height(),
					buffer->BytesPerLine(),
					NULL);
			}
			buffer->Release();
		}
		gboolean ret = clutter_group_content_replace_image_withid(CLUTTER_GROUP_CONTENT(t_content), CLUTTER_IMAGE(m_icons[index].image), m_icons[index].id);
		if (m_icons[index].opacity != opacity)
		{
			m_icons[index].opacity = opacity;
			clutter_group_content_set_image_opacity_withid(CLUTTER_GROUP_CONTENT(t_content), m_icons[index].id, opacity);
		}

		return (ret != FALSE ? true : false);
	}

	bool CMultiImage::SetIcon(int index, IImageBuffer *buffer, int opacity)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") buffer(" << buffer << ") opacity(" << opacity << ")");
		HALO_ASSERT(index >= 0 && index < m_icons.size());
		HALO_ASSERT(buffer != NULL);

		if (buffer->IsReady())
		{
			clutter_image_set_data(CLUTTER_IMAGE(m_icons[index].image),
				buffer->GetPixels(),
				buffer->HasAlphaChannel() ? COGL_PIXEL_FORMAT_RGBA_8888 : COGL_PIXEL_FORMAT_RGB_888,
				buffer->Width(),
				buffer->Height(),
				buffer->BytesPerLine(),
				NULL);
		}
		gboolean ret = clutter_group_content_replace_image_withid(CLUTTER_GROUP_CONTENT(t_content), CLUTTER_IMAGE(m_icons[index].image), m_icons[index].id);
		if (m_icons[index].opacity != opacity)
		{
			m_icons[index].opacity = opacity;
			clutter_group_content_set_image_opacity_withid(CLUTTER_GROUP_CONTENT(t_content), m_icons[index].id, opacity);
		}

		return (ret != FALSE ? true : false);
	}

	bool CMultiImage::SetIcon(int index, ClutterContent *image, int opacity)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") image(" << image << ") opacity(" << opacity << ")");
		HALO_ASSERT(index >= 0 && index < m_icons.size());
		HALO_ASSERT(image != NULL);

		m_icons[index].image = image;
		gboolean ret = clutter_group_content_replace_image_withid(CLUTTER_GROUP_CONTENT(t_content), CLUTTER_IMAGE(m_icons[index].image), m_icons[index].id);
		if (m_icons[index].opacity != opacity)
		{
			m_icons[index].opacity = opacity;
			clutter_group_content_set_image_opacity_withid(CLUTTER_GROUP_CONTENT(t_content), m_icons[index].id, opacity);
		}

		return (ret != FALSE ? true : false);
	}

	void CMultiImage::RemoveIcon(int index)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index  << ")");
		HALO_ASSERT(index >= 0 && index < m_icons.size());

		clutter_group_content_remove_image_withid(CLUTTER_GROUP_CONTENT(t_content), m_icons[index].id);
		m_icons.erase(m_icons.begin() + index);
	}

	int CMultiImage::IconCount(void)
	{
		return m_icons.size();
	}

	void CMultiImage::GetIconRect(int index, TRect &icon_rect)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ")");
		HALO_ASSERT(index >= 0 && index < (int)m_icons.size());

		ClutterActorBox box;
		clutter_group_content_get_image_box_withid(CLUTTER_GROUP_CONTENT(t_content), m_icons[index].id, &box);

		icon_rect.x = box.x1;
		icon_rect.y = box.y1;
		icon_rect.w = box.x2 - box.x1;
		icon_rect.h = box.y2 - box.y1;
	}

}

 /* namespace HALO */
