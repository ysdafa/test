#ifndef _CDataListControl_1_0_H_
#define _CDataListControl_1_0_H_

#include <deque>

namespace HALO
{
	class CAsyncTaskListener : public ITaskListener
	{
	public: //Async task listener
		virtual void* OnStart(void* params);
		virtual bool OnUpdate(void* result);
		virtual bool OnFinish(void* result);
		virtual bool OnCancel(void);

		CAsyncTaskListener(class CDataListControl *owner) : m_owner(owner){}
		~CAsyncTaskListener(){}

	private:
		class CDataListControl *m_owner;
	};

	class CMActor : public ActorBase, public IMouseListener, public IDragListener
	{
	public:
		CMActor(class TItem* owner, class CDataListControl* control) : pListControl(control), pOwner(owner), dragAction(NULL){};
		virtual ~CMActor(void);

		bool Initialize(IActor* parent, float width, float height);

		void ScaleTo(float xRatio, float yRatio, CMultiObjectTransition *transGroup);
		void SetOwner(TItem* owner);

		void EnableDrag(bool flagEnable);

		CDataListControl* pListControl;
		TItem* pOwner;

		IDragAction* dragAction;

		virtual bool OnMousePointerIn(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnMousePointerOut(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnMouseMoved(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnMouseButtonPressed(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnMouseButtonReleased(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnMouseClicked(IActor* pWindow, IMouseEvent* ptrMouseEvent);

		virtual bool OnDragBegin(IActor* pWindow, IDragEvent* pDragEvent);
		virtual bool OnDragEnd(IActor* pWindow, IDragEvent* pDragEvent);
		virtual bool OnDragHold(IActor* pWindow, IDragEvent* pDragEvent);

		virtual const char* GetActorType(void);
	};

	class TItem 
	{
	public:
		TItem() : rect(), alpha(255), window(NULL), window_bg(NULL), data(NULL), renderer(NULL), renderer_bg(NULL), flagEnable(true), flagCheckBoxSelected(false), visibleThumbStyle(0), disVisibleThumbStyle(0), radius(0.0f)
		{
			
		}
		virtual ~TItem()
		{
			if (NULL != renderer)
			{
				delete renderer;
				renderer = NULL;
			}
			if (NULL != renderer_bg)
			{
				delete renderer_bg;
				renderer_bg = NULL;
			}
			if (NULL != window)
			{
				delete window;
				window = NULL;
			}
			if (NULL != window_bg)
			{
				delete window_bg;
				window = NULL;
			}
		}

		TRect rect;
		int alpha;
		CMActor *window;
		CMActor *window_bg;
		void *data;
		IRenderer* renderer;
		IRenderer* renderer_bg;
		bool flagEnable;

		int visibleThumbStyle;
		int disVisibleThumbStyle;

		bool flagCheckBoxSelected;

		float radius;//virtual boundary
	};

	class CMScrollBarMouseListener : public IMouseListener
	{
	public:
		CMScrollBarMouseListener(CDataListControl* owner) : m_pOwner(owner)
		{

		}
		//! The callback function when mouse pointer in.
		virtual bool OnMousePointerIn(IActor* pWindow, IMouseEvent* ptrMouseEvent);

		//! The callback function when mouse pointer out.
		virtual bool OnMousePointerOut(IActor* pWindow, IMouseEvent* ptrMouseEvent);
	private:
		CDataListControl* m_pOwner;
	};

	class CMScrollAreaListener : public IMouseListener
	{
	public:
		CMScrollAreaListener(class CDataListControl* owner) {m_owner = owner;}

	protected:
		bool OnMouseMoved(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		bool OnMousePointerOut(IActor* pWindow, IMouseEvent* ptrMouseEvent);

	private:
		class CDataListControl *m_owner;
	};

	class CDataListControl : virtual public IDataListControl, public ActorBase, public ITaskListener, public IKeyLongPressListener, public IScrollListener, public ISystemEventListener
	{
	public:

		enum E_REFRESH_VISIBLEITEM_REASON
		{
			BIND_ITEM_DATA = 0,
			STYLE_ANIMATION,
			SCROLL_ITEMGROUP,
			REASON_MAX
		};

		CDataListControl(void);
		virtual ~CDataListControl(void);

		virtual void EnableUnload(bool flagEnable);

		virtual void LoadData(void);

		//IDataSource * GetDataSource(void);
		void SetRendererProvider(IRendererProvider *rendererProvider);
		void SetFocusImage(IImageBuffer* imageBuffer, float xOffset, float yOffset);
		void SetFocusImage(const char* imageName, float xOffset, float yOffset);
		void EnlargeFocusedItem(float widthDiff, float heightDiff);
		void GetEnlargeSizeOfFocusedItem(float &widthDiff, float &heightDiff);
		void SetFocusMargin(TMargin margin);
		void GetFocusMargin(TMargin &margin);
		bool MoveFocus(EDirection direction);
		TRect VisibleAreaRect(void);

		bool ShowFocus(bool flagAnimation);

		bool HideFocus(bool flagAnimation);

		bool IsDirectionScrollable(EDirection dir);

		void ScrollVisibleArea(float xOffset, float yOffset, bool flagAni);

		void ScrollVisibleArea(TRect toRect, bool flagAni = true);

		void EnableLoopLeft(const bool flagLoop);
		
		bool IsLoopLeftEnabled(void) const;

		void EnableLoopRight(const bool flagLoop);

		bool IsLoopRightEnabled(void) const;

		void AttachScrollBar(IScroll* scroll);

		void SetColorOfDimWindow(int alpha, int red, int green, int blue);

		void Dim(bool flagShowDimWindow);

		void SetChangeMount(const float changeMount);
		float ChangeMount(void);

		void SetCursorScrollArea(float totalSpace, float inShowAreaSpace);
		void GetCursorScrollArea(float &totalSpace, float &inShowAreaSpace);

		virtual const char* GetActorType(void);

		virtual void EnableShadowEffect(const bool flagShadowEffect);
		virtual bool IsShadowEffectEnabled(void) const;

		virtual void EnableFoveaEffect(const bool flagFoveaAni);
		virtual bool IsFoveaEffectEnabled(void) const;

	public: //Async task listener

		virtual void* OnStart(void* params);
		virtual bool OnUpdate(void* result);
		virtual bool OnFinish(void* result);
		virtual bool OnCancel(void* params);

	public:
		//! The callback function when key long pressed.
		virtual bool OnKeyLongPress(IActor* pWindow, IKeyboardEvent* pKeyboardEvent);

		virtual bool OnCursorVisible(IEvent* pEvent);

		virtual bool OnCursorHidden(IEvent* pEvent);
	public:
		//! The callback function for scroll listener.
		virtual bool OnValueChanged(IScroll* scroll, EValueChangedType type);

	protected:
		virtual void t_UpdateOrientation(EOrientation orientation);

	protected:
		virtual bool t_Initialize(IActor *parent, const TDataListControlAttr &attr);
		virtual bool t_Initialize(Widget *parent, const TDataListControlAttr &attr);

		virtual bool t_MoveFocusBar(EDirection direction) = 0;
		virtual void t_BindDataListToItemList(void) = 0;

		virtual bool t_OnMousePointerIn(TItem* item, IMouseEvent* ptrMouseEvent) {return false;}
		virtual bool t_OnMousePointerOut(TItem* item, IMouseEvent* ptrMouseEvent) {return false;}
		virtual bool t_OnMouseMoved(TItem* item, IMouseEvent* ptrMouseEvent) {return false;}
		virtual bool t_MouseButtonPressed(TItem* item, IMouseEvent* ptrMouseEvent) {return false;}
		virtual bool t_MouseButtonRelease(TItem* item, IMouseEvent* ptrMouseEvent) {return false;}
		virtual bool t_MouseClicked(TItem* item, IMouseEvent* ptrMouseEvent) {return false;}

		virtual bool t_OnDragBegin(TItem* item, IDragEvent* pDragEvent){ return false; }
		virtual bool t_OnDragEnd(TItem* item, IDragEvent* pDragEvent){ return false; }
		virtual bool t_OnDragHold(TItem* item, IDragEvent* pDragEvent){ return false; }

		virtual bool t_OnEnterKeyLongPressed(void) { return false; }

		virtual bool t_OnScrollBarValueChanged(IScroll *scroll){ return false; }

		virtual bool t_GetItemsNeedFoveaAni(const TItem *hitItem, std::vector<TItem*> &itemArray, TValue2f cursorCenter, float cursorRadius) {return false;}

		virtual EDirectionType t_GetScrollDirection(void) {return TYPE_HORIZONTAL;}
		
		enum CTListStauts
		{
			STATUS_NORMAL = 0,
			STATUS_FADE_OUT,
			STATUS_FADE_IN,
			STATUS_MAX
		};

		TRect t_focusRangeRect;
		float t_listWidth;
		float t_listHeight;
		IActor* t_itemGroup;

		TRect t_itemGroupRect;
		TValue2f t_lastItemGroupPos;

		TItem *t_focusedItem;
		TItem *t_focusedItemBak;

		bool t_flagShowFocusBar;
		bool t_flagShowFocusAfterScroll;

		bool t_flagEditable;

		bool t_flagLoopLeft;

		bool t_flagLoopRight;

		IRendererProvider *t_rendererProvider;

		IKeyLongPressAction *m_keyLongPressAction;

		std::set<TItem*> t_inMemoryItemSet;

		bool t_flagMouse;

		float t_cursorRadius;

		bool t_flagShadowEffect;
		IShadowEffect *t_shadowEffect;

		enum ETransitionType
		{
			ITEM_GROUP_POS_TRANS = 1,
			ITEM_GROUP_ALPHA_TRANS = (ITEM_GROUP_POS_TRANS << 1),
			ITEM_ALPHA_TRANS = (ITEM_GROUP_ALPHA_TRANS << 1),
			ITEM_SIZE_TRANS	= (ITEM_ALPHA_TRANS << 1),
			ITEM_POSITION_TRANS = (ITEM_SIZE_TRANS << 1),
			ITEM_SCALEX_TRANS = (ITEM_POSITION_TRANS << 1),
			ITEM_SCALEY_TRANS = (ITEM_SCALEX_TRANS << 1)
		};

		enum EAniEventType
		{
			ANI_START = 0,
			ANI_VIA,
			ANI_FINISH,
			ANI_NEWFRAME,
			ANI_STOP
		};

		std::map<CMultiObjectTransition*, long> m_multiObjTransInfoMap;

		enum EListAnimationType
		{
			ITEM_SCROLL_ANI = 1,
			ITEM_STYLE_ANI = ITEM_SCROLL_ANI << 1,
			FOCUS_MOVE_ANI = ITEM_STYLE_ANI << 1,
			LOOP_ANI = FOCUS_MOVE_ANI << 1,
			LIST_ANI_TYPE_MAX
		};

		void t_StopAnimation(int listAniType);

		bool t_IsOnAnimation(int listAniType);

		void t_RegisterMultiObjTransition(CMultiObjectTransition *trans, long transType);

		void t_TransformLayout(int fromLayout, int toLayout, std::vector<TItem*> itemList, std::vector<TRect> rectList, const TRect &destItemGroupRect, int reason, bool flagAni = true);

		bool t_SetFocusBar(TItem *item, bool flagFocusBarAni, bool flagScrollAni);
		bool t_SetFocusBar(TRect &focusImgRect, TItem *item, bool flagFocusBarAni, bool flagScrollAni);
		bool t_SetFocusBar(TRect &focusImgRect, TRect &focusItemRect, TItem *item, bool flagFocusBarAni, bool flagScrollAni);

		void t_SetVisibleArea(TRect visibleAreaRect, IActor *rectBaseOn);

		void t_UpdateInMemoryItems(bool flagUnloadRightNow, int reason = -1);

		void t_SetItemGroupSize(float width, float height);

		void t_RefreshItemPosition(TItem *item, CMultiObjectTransition *trans = NULL);

		bool t_FadeInOut(TItem *item, TRect &focusImgDest,
				TPoint &focusBarOutOffset, TPoint &itemGroupOutOffset,
				bool flagAni = true);

		void t_UpdateUI(TItem *item);

		void t_SetAnimationDuration(int duration);

		void t_SetFocusMoveAniDuration(int duration)
		{
			m_focusMoveAni->SetDuration(duration);
		}

		void t_SetFocusMoveAniMode(ClutterAnimationMode mode)
		{
			m_focusMoveAni->SetMode(mode);
		}

		void t_SetLoopAniDuration(int duration)
		{
			m_loopAni->SetDuration(duration);
		}

		void t_SetLoopAniMode(ClutterAnimationMode mode)
		{
			m_loopAni->SetMode(mode);
		}

		void t_SetTransStyleAniDuration(int duration)
		{
			m_transStyleAni->SetDuration(duration);
		}

		void t_SetTransStyleAniMode(ClutterAnimationMode mode)
		{
			m_transStyleAni->SetMode(mode);
		}

		void t_SetAnimationMode(ClutterAnimationMode mode);

		TRect t_WindowRect(void);

		virtual void t_OnStyleAnimationFinish(void){};

		virtual void t_OnItemGroupScrollStart(void){};
		virtual void t_OnItemGroupScrollEnd(void){};
		//The item in memory only scrolled, not loaded or unloaded.
		virtual void t_OnItemInMemoryScrolled(TItem *item){};

		virtual void t_GetItemWindowPivotPoint(TItem *item, float &pivotX, float &pivotY, float &pivotZ) = 0;

		virtual void t_GetInMemoryItems(TRect lastVisibleArea, TRect visibleArea, std::vector<TItem*> &loadItem, std::vector<TItem*> &unloadItem, std::vector<TItem*> &noChangeItem, int reason = -1) = 0;

		virtual void t_OnItemDataUnload(TItem *item) = 0;
		virtual void t_OnItemDataSyncLoad(TItem *item) = 0;
		virtual void t_OnItemDataAsyncLoad(TItem *item) = 0;

		virtual void t_FocusChangeStart(const TItem *from, const TItem *to) = 0;
		virtual void t_FocusChangeFinish(const TItem *from, const TItem *to) = 0;

		virtual TValue2f t_GetRealPointBaseItemGroup(TRect rect, TRect baseOnRect) = 0;
		virtual TValue2f t_GetLogicalPosition(TRect rect, TRect baseOnRect) = 0;

		virtual TRect t_InitRectOfLoadingItem(TItem *item, int reason) = 0;

		void t_ScaleDownFocuedItem(CMultiObjectTransition *transGroup);

		void t_ScaleUpFocuedItem(CMultiObjectTransition *transGroup);

		virtual void t_OnRegisterAnimationCallback(ITimeLine *timeLine, EAniEventType aniCallbackType){};

		void t_UpdateItem(TItem* item);

	private:
		CTListStauts m_listStatus;

		bool m_flagEnableUnload;

		TRect m_lastVisibleArea;

		IActor *m_showAreaWindow;

		IActor *m_focusBar;
		ICompositeImage *m_focusImage;

		float m_focusImageOffsetX;
		float m_focusImageOffsetY;

		CMultiObjectTransition *m_focusMoveAni;
		CMultiObjectTransition *m_loopAni;

		CMultiObjectTransition *m_focusShowHideAni;

		CMultiObjectTransition *m_transStyleAni;

		CMultiObjectTransition *m_itemScrollAni;

		std::map<TItem* , CAsyncTask *> m_asyncTaskMap;

		class CDataListControlAniListener *m_itemScrollAniListener;
		class CDataListControlAniListener *m_itemStyleAniListener;

		class CDataListControlAniListener *m_focusMoveAniListener;
		class CDataListControlAniListener *m_loopAniListener;

		class CDataListControlAniListener *m_registerAniListener;

		std::deque<CMActor*> m_windowQueue;

		struct CTScrollInfo
		{
			CTScrollInfo() : reason(-1) {};
			int reason;
			std::vector<TItem*> unloadItems;
			std::vector<TItem*> loadItems;
			std::vector<TItem*> scrollItems; //Only scroll, no load or unload
		};

		std::deque<CTScrollInfo*> m_scrollInfoQueue;

		bool m_flagLoadItemBeforeScroll;

		struct CTFocusChangeInfo
		{
			CTFocusChangeInfo(TItem *fromIn, TItem *toIn) : from(fromIn), to(toIn) {}
			TItem *from;
			TItem *to;
		};

		std::deque<CTFocusChangeInfo> m_focusQueue;

		TRect m_focusImgRect;
		TRect m_focusItemRect;

		TRect m_windowRect;

		struct CTFadeInInfo
		{
			TRect focusItemStart;
			TRect focusItemEnd;
			TRect focusImgEnd;
			TPoint itemStart;
			bool flagItemScroll;
		};

		CTFadeInInfo m_fadeInInfo;

		unsigned int m_maxScrollSpeed;

		float m_enlargeWidth;
		float m_enlargeHeight;

		IScroll* m_scrollBar;
		ITransition* m_scrollBarAlphaAni;
		int m_scrollBarTimer;
		int m_scrollBarTimerInterval;
		CMScrollBarMouseListener* m_scrollBarMouserListener;

		ClutterColor *m_dimWindowColor;
		IDimWindow *m_dimWindow;

		bool m_flagShowHidingFocusBar;

		bool m_flagFoveaAni;

		float m_ChangeMount;
		float m_cursorScrollSpace;
		float m_cursorScrollInShowAreaSpace;
		EDirectionType m_scrollType;

		CMScrollAreaListener *m_scrollActorListener;

		IActor *m_leftScrollAreaActor;
		IActor *m_rightScrollAreaActor;

		bool m_Create(float listWidth, float listHeight);

		bool m_SetFocus(TItem *destItem, TRect focusImgRect, TRect focusItemRect);

		bool m_GetItemGroupRect(TRect &focusItemRect, TPoint &destRect);

		void m_FadeOut(TRect &focusItemDest, TPoint &itemDest);
		void m_FadeIn(bool flagAni);
		void m_FocusBarFadeIn(void);
		void m_ItemGroupFadeIn(void);

		void m_UpdateInMemoryItems(bool flagUnloadRightNow, bool flagLoadRightNow, bool flagNoChangeNotifyRightNow, int reason = -1);

		void m_DealScrollEventQueue(void);

		void m_OnFocusMoveAniEvent(EAniEventType eventType, void *detail);
		void m_OnLoopAniEvent(EAniEventType eventType, void *detail);

		void m_OnItemScrollAni(EAniEventType eventType, void *detail);
		void m_OnItemStyleAni(EAniEventType eventType, void *detail, void *data);

		void m_UnloadItem(TItem *item);

		void m_LoadItem(TItem *item, int reason);

		CMActor* m_GetWindow(TItem *item, int reason);

		bool m_RegisterMultiObjTransition(CMultiObjectTransition *trans, long transType);

		void m_FocusChangeStart(const TItem *from, const TItem *to);
		void m_FocusChangeFinish(const TItem *from, const TItem *to);
		IRenderer *m_GetRenderer(TItem* item, int index);

		static int m_ScrollBarTimeOut(gpointer data);

		void m_StartScrollBarAlphaOutTimer(void);
		void m_StopScrollBarAlphaOutTimer(void);

		void m_ShowScrollBar(bool flagAni);
		void m_HideScrollBar(bool flagAni);

		bool m_DoFoveaAnimation(TItem *item, IMouseEvent* ptrMouseEvent);

		void m_DoCursorScroll(IActor* pWindow, IMouseEvent* ptrMouseEvent);

		friend class CDataListControlAniListener;
		friend class CAsyncTaskListener;
		friend class CMActor;
		friend class CMScrollBarMouseListener;
		friend class CMScrollAreaListener;
	};

	class CDataListControlAniListener : public TransitionListener
	{
	public:
		CDataListControlAniListener(CDataListControl *owner, int index) : m_owner(owner), m_listenerIndex(index){};

		virtual bool OnStarted(ITimeLine *animation, void *data);
		virtual bool OnVia(ITimeLine *animation, void *data);
		virtual bool OnCompleted(ITimeLine *animation, void *data);
		virtual bool OnStoped(class ITimeLine *animation, bool flagFinished, void *data);
		virtual bool OnNewFrame(class ITimeLine *animation, double currentProgress, void *data);

		virtual ~CDataListControlAniListener(void){}

	protected:

	private:
		CDataListControl *m_owner;
		int m_listenerIndex;

		bool m_IfAnimationEvent(ITimeLine *timeLine, CDataListControl::EAniEventType eventType, void *detail, void *data);
	};
}

#endif
