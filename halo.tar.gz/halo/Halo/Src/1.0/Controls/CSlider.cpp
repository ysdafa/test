#include "Halo1_0.h"

namespace HALO
{
	static HALO::util::Logger LOGGER("CSlider");
	static const char* DRAG_ACTION_NAME = "drag-action-name";

	CSlider::CSlider(void) :m_minValue(0),
		m_maxValue(100),
		m_currentValue(0),
		m_thumbButton(NULL),
		m_fillImage(NULL),
		m_trackImage(NULL)
	{
		H_LOG_TRACE(LOGGER, "CSlider::CSlider()");
		
	}

	CSlider::~CSlider( void )
	{
		H_LOG_TRACE(LOGGER, "CSlider::~CSlider()");

		//m_thumbButton->RemoveMouseListener(this);

		delete m_thumbButton;
		m_thumbButton = NULL;

		delete m_fillImage;
		m_fillImage = NULL;

		delete m_trackImage;
		m_trackImage = NULL;
	}

	bool CSlider::Initialize(IActor* parent, float width, float height, EDirectionType direction)
	{
		H_LOG_TRACE(LOGGER, "CSlider::Initialize(" << parent << ", " << width << ", " << height << ", " << direction << ")");

		Widget* widget = dynamic_cast<Widget *>(parent);
		return Initialize(widget, width, height, direction);
	}

	bool CSlider::Initialize(Widget* parent, float width, float height, EDirectionType direction)
	{
		H_LOG_TRACE(LOGGER, "CSlider::Initialize(" << parent << ", " << width << ", " << height << ", " << direction << ")");

		//ASSERT(parent != NULL);
		CActor::Initialize(parent, width, height);

		Widget *widget = dynamic_cast<Widget*>(this);
		if (widget != NULL)
		{
			// background image fills this actor region
			m_trackImage = IImage::CreateInstance(widget, width, height);
			m_fillImage = IImage::CreateInstance(widget, width, height);
			m_thumbButton = IButton::CreateInstance(this, 50, 50);

			// For passing prevent
			if (m_trackImage == NULL || m_fillImage == NULL || m_thumbButton == NULL)
			{
				return false;
			}

			//m_thumbButton->AddMouseListener(this);
		}

		m_direction = direction;

		ClutterActor* thumbActor = m_thumbButton->Actor();
		ClutterActor* fillActor = m_fillImage->Actor();
		ClutterActor* trackActor = m_trackImage->Actor();

		if (m_direction == TYPE_HORIZONTAL)
		{
			clutter_actor_add_constraint(thumbActor,
				clutter_align_constraint_new(trackActor, CLUTTER_ALIGN_Y_AXIS, 0.5));

			gfloat x = static_cast<float>(m_currentValue - m_minValue) / (m_maxValue - m_minValue) * clutter_actor_get_width(trackActor);
			clutter_actor_set_x(thumbActor, x);

			clutter_actor_add_constraint(fillActor,
				clutter_snap_constraint_new(thumbActor, CLUTTER_SNAP_EDGE_RIGHT, CLUTTER_SNAP_EDGE_LEFT, 0));
		}
		else
		{
			clutter_actor_add_constraint(thumbActor,
				clutter_align_constraint_new(trackActor, CLUTTER_ALIGN_X_AXIS, 0.5));

			gfloat y = static_cast<float>(m_maxValue - m_currentValue) / (m_maxValue - m_minValue) * clutter_actor_get_height(trackActor);
			clutter_actor_set_y(thumbActor, y);

			clutter_actor_add_constraint(fillActor,
				clutter_snap_constraint_new(thumbActor, CLUTTER_SNAP_EDGE_TOP, CLUTTER_SNAP_EDGE_BOTTOM, 0));
		}

		// Add drag support for thumb, the rectangle area will be set in SetThumbSize()
		ClutterAction* thumbDragAction = clutter_drag_action_new();
		clutter_actor_add_action_with_name(thumbActor, DRAG_ACTION_NAME, thumbDragAction);
		g_signal_connect(thumbDragAction, "drag-motion", G_CALLBACK(m_OnThumbDragMotion), this);
		clutter_actor_set_reactive(thumbActor, true);
		m_SetDragArea(50, 50);

		// Add click support
		ClutterAction* clickAction = clutter_click_action_new();
		clutter_actor_add_action(trackActor, clickAction);
		g_signal_connect(clickAction, "clicked", G_CALLBACK(m_OnSliderClick), this);
		clutter_actor_set_reactive(trackActor, true);

		return true;
	}


	void CSlider::SetMinMaxValue(int minValue, int maxValue)
	{
		H_LOG_TRACE(LOGGER, "CSlider::SetMinMaxValue(" << minValue << ", " << maxValue << ")");

		// TODO: add ASSERT
		ASSERT(minValue >= 0);
		ASSERT(maxValue > minValue);

		m_minValue = minValue;
		m_maxValue = maxValue;

		// safe guard
		if (m_currentValue < m_minValue)
		{
			m_currentValue = m_minValue;
		}

		if (m_currentValue > m_maxValue)
		{
			m_currentValue = m_maxValue;
		}

		m_ValueChanged();
	}

	void CSlider::GetMinMaxValue(int& minValue, int& maxValue)
	{
		H_LOG_TRACE(LOGGER, "CSlider::GetMinMaxValue()");

		minValue = m_minValue;
		maxValue = m_maxValue;
	}

	int CSlider::Value() const
	{
		H_LOG_TRACE(LOGGER, "CSlider::Value()");

		return m_currentValue;
	}

	void CSlider::SetValue( int value )
	{
		H_LOG_TRACE(LOGGER, "CSlider::SetValue(" << value << ")");

		ASSERT(value >= m_minValue && value <= m_maxValue);

		if (value < m_minValue)
		{
			value = m_minValue;
		}
		if (value > m_maxValue)
		{
			value = m_maxValue;
		}

		if (m_currentValue == value)
		{
			return;
		}

		m_currentValue = value;

		m_ValueChanged();
	}

	void CSlider::SetFillImage( IImageBuffer* image )
	{
		H_LOG_TRACE(LOGGER, "CSlider::SetFillImage(" << image << ")");

		ASSERT(image != NULL);

		m_fillImage->SetImage(image);
	}

	void CSlider::SetBackgroundImage( IImageBuffer* image )
	{
		H_LOG_TRACE(LOGGER, "CSlider::SetBackgroundImage(" << image << ")");

		ASSERT(image != NULL);

		m_trackImage->SetImage(image);
	}	

	void CSlider::m_ValueChanged()
	{
		H_LOG_TRACE(LOGGER, "CSlider::m_ValueChanged()");

		ClutterActor* thumb = m_thumbButton->Actor();

		if(m_direction == TYPE_HORIZONTAL)
		{
			float factor = static_cast<float>(m_currentValue - m_minValue)/(m_maxValue - m_minValue);
			gfloat validWidth = clutter_actor_get_width(t_actor) - clutter_actor_get_width(thumb);
			gfloat x = factor * validWidth;
			clutter_actor_set_x(thumb, x);
		} 
		else
		{
			float factor = static_cast<float>(m_maxValue - m_currentValue)/(m_maxValue - m_minValue);
			gfloat validHeight = clutter_actor_get_height(t_actor) - clutter_actor_get_height(thumb);
			gfloat y = factor * validHeight;
			clutter_actor_set_y(thumb, y);
		}

		for (std::set<ISliderListener *>::iterator iter = m_listenerSet.begin(); iter != m_listenerSet.end(); ++iter)
		{
			ASSERT(*iter != NULL);
			(*iter)->OnValueChanged(this);
		}
	}

	void CSlider::m_ThumbMoved()
	{
		H_LOG_TRACE(LOGGER, "CSlider::m_ThumbMoved()");

		ClutterActor* thumb = m_thumbButton->Actor();
		if(m_direction == TYPE_HORIZONTAL)
		{
			float cruX = clutter_actor_get_x(thumb) ;
			float validWidth = clutter_actor_get_width(t_actor) - clutter_actor_get_width(thumb);
			float factor = cruX / validWidth;
			m_currentValue = m_minValue + static_cast<int>(factor * (m_maxValue - m_minValue));
		} 
		else
		{
			float curY = clutter_actor_get_y(thumb);
			float validHeight = clutter_actor_get_height(t_actor) - clutter_actor_get_height(thumb);
			float factor = 1 - (curY / validHeight);
			m_currentValue = m_minValue + static_cast<int>(factor * (m_maxValue - m_minValue));
		}

		for (std::set<ISliderListener *>::iterator iter = m_listenerSet.begin(); iter != m_listenerSet.end(); ++iter)
		{
			ASSERT(*iter != NULL);
			(*iter)->OnValueChanged(this);
		}
	}

	void CSlider::m_OnThumbDragMotion(ClutterDragAction *action, ClutterActor *actor, gfloat delta_x, gfloat delta_y, CSlider	*slider)
	{
		slider->m_ThumbMoved();
		//slider->m_dragFlag = false;
	}

	void CSlider::SetThumbImage(IButton::EButtonState state, const std::string& imagePath)
	{
		H_LOG_TRACE(LOGGER, "CSlider::SetThumbImage(" << state << ", " << imagePath << ")");

		m_thumbButton->SetBackgroundImage(state, imagePath);
	}

	void CSlider::SetThumbSize( float width, float height )
	{
		H_LOG_TRACE(LOGGER, "CSlider::SetThumbSize(" << width << ", " << height << ")");

		ASSERT(width > 0);
		ASSERT(height > 0);

		m_thumbButton->Resize(width, height);

		// do it here, since we need clutter_actor_get_width(thumbActor)
		m_SetDragArea(width, height);
	}

	void CSlider::GetThumbSize( float &width, float &height ) const
	{
		H_LOG_TRACE(LOGGER, "CSlider::GetThumbSize()");

		m_thumbButton->GetSize(width, height);
	}

	bool CSlider::AddListener(ISliderListener* listener)
	{
		H_LOG_TRACE(LOGGER, "CSlider::AddListener(" << listener << ")");

		ASSERT(listener != NULL);

		m_listenerSet.insert(listener);
		return true;
	}

	bool CSlider::RemoveListener(ISliderListener* listener)
	{
		H_LOG_TRACE(LOGGER, "CSlider::RemoveListener(" << listener << ")");

		ASSERT(listener != NULL);

		m_listenerSet.erase(listener);
		return true;
	}

	void CSlider::SetThumbColor(IButton::EButtonState state, const ClutterColor& color)
	{
		H_LOG_TRACE(LOGGER, "CSlider::SetThumbColor(" << state << ", " << &color << ")");


	}

	const ClutterColor& CSlider::ThumbColor(IButton::EButtonState state) const
	{
		H_LOG_TRACE(LOGGER, "CSlider::ThumbColor(" << state << ")");

		return *clutter_color_new(0, 0, 0, 0);
	}

	void CSlider::SetFillColor(const ClutterColor& color)
	{
		H_LOG_TRACE(LOGGER, "CSlider::SetFillColor(" << &color << ")");


	}

	const ClutterColor& CSlider::FillColor(void)
	{
		H_LOG_TRACE(LOGGER, "CSlider::FillColor()");

		return *clutter_color_new(0, 0, 0, 0);
	}

	void CSlider::m_SetDragArea(float width, float height)
	{
		ClutterActor* thumbActor = m_thumbButton->Actor();
		ClutterActor* tintActor = m_fillImage->Actor();
		ClutterActor* trackActor = m_trackImage->Actor();

		ClutterAction* thumbDragAction = clutter_actor_get_action(thumbActor, DRAG_ACTION_NAME);
		ASSERT(thumbDragAction != NULL);

		if (m_direction == TYPE_HORIZONTAL)
		{
			// set drag action attributes
			clutter_drag_action_set_drag_axis(CLUTTER_DRAG_ACTION(thumbDragAction), CLUTTER_DRAG_X_AXIS);
			ClutterRect rect;
			rect.origin.x = 0;
			rect.origin.y = 0;
			rect.size.width = clutter_actor_get_width(trackActor) - width;
			rect.size.height = clutter_actor_get_height(trackActor);
			clutter_drag_action_set_drag_area(CLUTTER_DRAG_ACTION(thumbDragAction), &rect);
		}
		else
		{
			// set drag action attributes
			clutter_drag_action_set_drag_axis(CLUTTER_DRAG_ACTION(thumbDragAction), CLUTTER_DRAG_Y_AXIS);
			ClutterRect rect;
			rect.origin.x = 0;
			rect.origin.y = 0;
			rect.size.width = clutter_actor_get_width(trackActor);
			rect.size.height = clutter_actor_get_height(trackActor) - height;
			clutter_drag_action_set_drag_area(CLUTTER_DRAG_ACTION(thumbDragAction), &rect);
		}
	}

	void CSlider::m_OnSliderClick(ClutterClickAction *action, ClutterActor *actor, CSlider *slider)
	{
			gfloat pressX, pressY;
			clutter_click_action_get_coords(action, &pressX, &pressY);

			float curX = 0;
			float curY = 0;
			slider->GetPosition(curX, curY);

			float width = 0;
			float height = 0;
			slider->GetSize(width, height);

			float thumbWidth = 0;
			float thumbHeight = 0;
			slider->GetThumbSize(thumbWidth, thumbHeight);

			float factor = 0;
			if (slider->m_direction == TYPE_HORIZONTAL)
			{
				factor = (pressX - curX) / (width - thumbWidth);
			}
			else
			{
				factor = 1 - (pressY - curY) / (height - thumbHeight);
			}

			if (factor > 0.995)
			{
				factor = 1.0;
			}

			int minValue, maxValue;
			slider->GetMinMaxValue(minValue, maxValue);
			int curValue = minValue + static_cast<int>(factor * (maxValue - minValue));

			slider->SetValue(curValue);
	}

	const char* CSlider::GetActorType(void)
	{
		return "Slider";
	}
}
