#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	IFirstScreenListControl* IFirstScreenListControl::CreateInstance(IActor *parent, const TFirstScreenListControlAttr &attr)
	{
		CFirstScreenListControl* firstScrnList = dynamic_cast<CFirstScreenListControl*>(Instance::CreateInstance(CLASS_ID_IFIRSTSCREENLISTCONTROL));

		if (NULL != firstScrnList)
		{
			firstScrnList->Initialize(parent, attr);
		}

		return firstScrnList;
	}

	IFirstScreenListControl* IFirstScreenListControl::CreateInstance(Widget *parent, const TFirstScreenListControlAttr &attr)
	{
		CFirstScreenListControl* firstScrnList = dynamic_cast<CFirstScreenListControl*>(Instance::CreateInstance(CLASS_ID_IFIRSTSCREENLISTCONTROL));

		if (NULL != firstScrnList)
		{
			firstScrnList->Initialize(parent, attr);
		}

		return firstScrnList;
	}
}