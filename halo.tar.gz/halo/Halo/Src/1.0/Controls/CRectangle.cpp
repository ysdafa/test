#include "Halo1_0.h"

namespace HALO
{
	static HALO::util::Logger LOGGER("CRectangle");

	CRectangle::CRectangle() : m_topBorder(NULL), 
		m_leftBorder(NULL), 
		m_bottomBorder(NULL),
		m_rightBorder(NULL),
		m_topBorderThickness(0),
		m_leftBorderThickness(0),
		m_bottomBorderThickness(0),
		m_rightBorderThickness(0)
	{
		H_LOG_TRACE(LOGGER, "CRectangle::CRectangle()");

		clutter_color_init(&m_borderColor, 0, 0, 0, 0);
	}

	CRectangle::~CRectangle()
	{
		H_LOG_TRACE(LOGGER, "CRectangle::~CRectangle()");

		clutter_actor_destroy(m_topBorder);
		clutter_actor_destroy(m_leftBorder);
		clutter_actor_destroy(m_bottomBorder);
		clutter_actor_destroy(m_rightBorder);
	}

	bool CRectangle::Initialize(IActor* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CRectangle::Initialize(" << parent << ", " << width << ", " << height << ")");
		Widget *widget = dynamic_cast<Widget *>(parent);

		return Initialize(widget, width, height);
	}

	bool CRectangle::Initialize(Widget* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CRectangle::Initialize(" << parent << ", " << width << ", " << height << ")");

		//ASSERT(parent != NULL);
		CActor::Initialize(parent, width, height);

		m_topBorder = clutter_actor_new();
		clutter_actor_add_child(t_actor, m_topBorder);

		m_leftBorder = clutter_actor_new();
		clutter_actor_add_child(t_actor, m_leftBorder);

		m_bottomBorder = clutter_actor_new();
		clutter_actor_add_child(t_actor, m_bottomBorder);

		m_rightBorder = clutter_actor_new();
		clutter_actor_add_child(t_actor, m_rightBorder);

		return true;
	}

	void CRectangle::Resize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CRectangle::Resize()");

		ASSERT(width - m_leftBorderThickness - m_rightBorderThickness > 0);
		ASSERT(height - m_topBorderThickness - m_bottomBorderThickness > 0);

		clutter_actor_set_size(t_actor, 
			width - m_leftBorderThickness - m_rightBorderThickness, 
			height - m_topBorderThickness - m_bottomBorderThickness);

		// m_topBorder and m_leftBorder need not to change position
		
		clutter_actor_set_width(m_topBorder, width);		// m_topBorder height not changed
		clutter_actor_set_height(m_leftBorder, height - m_topBorderThickness - m_bottomBorderThickness);	// width not changed

		clutter_actor_set_position(m_bottomBorder, -m_leftBorderThickness, clutter_actor_get_height(t_actor));
		clutter_actor_set_size(m_bottomBorder, width, m_bottomBorderThickness);

		clutter_actor_set_position(m_rightBorder, clutter_actor_get_width(t_actor), 0);
		clutter_actor_set_size(m_rightBorder, m_rightBorderThickness, clutter_actor_get_height(t_actor));
	}

	const ClutterColor& CRectangle::BorderColor() const
	{
		H_LOG_TRACE(LOGGER, "CRectangle::BorderColor()");

		return m_borderColor;
	}

	void CRectangle::SetBorderColor( const ClutterColor& color )
	{
		H_LOG_TRACE(LOGGER, "CRectangle::SetBorderColor()");

		m_borderColor = color;
		clutter_actor_set_background_color(m_topBorder, &color);
		clutter_actor_set_background_color(m_leftBorder, &color);
		clutter_actor_set_background_color(m_bottomBorder, &color);
		clutter_actor_set_background_color(m_rightBorder, &color);
	}

	void CRectangle::SetBorderThickness(float topThickness, float leftThickness, float bottomThichness, float rightThickness)
	{
		H_LOG_TRACE(LOGGER, "CRectangle::SetBorderThickness(" << topThickness << ", " << leftThickness << ", " << bottomThichness << ", " << rightThickness << ")");

		ASSERT(topThickness >= 0);
		ASSERT(leftThickness >= 0);
		ASSERT(bottomThichness >= 0);
		ASSERT(rightThickness >= 0);

		//float curWidth = m_leftBorderThickness + clutter_actor_get_width(t_actor) + m_rightBorderThickness;
		//float curHeight = m_topBorderThickness + clutter_actor_get_height(t_actor) + m_bottomBorderThickness;
		float deltaWidth = (m_leftBorderThickness - leftThickness) + (m_rightBorderThickness - rightThickness);
		float newWidth = clutter_actor_get_width(t_actor) + deltaWidth;
		float deltaHeight = (m_topBorderThickness - topThickness) + (m_bottomBorderThickness  - bottomThichness);
		float newHeight = clutter_actor_get_height(t_actor) + deltaHeight;
		ASSERT(newWidth > 0);
		ASSERT(newHeight > 0);
		clutter_actor_set_width(t_actor, newWidth);
		clutter_actor_set_height(t_actor, newHeight);

		float newX = clutter_actor_get_x(t_actor) - m_leftBorderThickness + leftThickness;
		float newY = clutter_actor_get_y(t_actor) - m_topBorderThickness + topThickness;
		clutter_actor_set_x(t_actor, newX);
		clutter_actor_set_y(t_actor, newY);


		clutter_actor_set_position(m_topBorder, -leftThickness, -topThickness);
		clutter_actor_set_size(m_topBorder, leftThickness + clutter_actor_get_width(t_actor) + rightThickness, topThickness);

		clutter_actor_set_position(m_leftBorder, -leftThickness, 0);
		clutter_actor_set_size(m_leftBorder, leftThickness, clutter_actor_get_height(t_actor));

		clutter_actor_set_position(m_bottomBorder, -leftThickness, clutter_actor_get_height(t_actor));
		clutter_actor_set_size(m_bottomBorder, leftThickness + clutter_actor_get_width(t_actor) + rightThickness, bottomThichness);

		clutter_actor_set_position(m_rightBorder, clutter_actor_get_width(t_actor), 0);
		clutter_actor_set_size(m_rightBorder, rightThickness, clutter_actor_get_height(t_actor));

		m_topBorderThickness = topThickness;
		m_leftBorderThickness = leftThickness;
		m_bottomBorderThickness = bottomThichness;
		m_rightBorderThickness = rightThickness;
	}

	void CRectangle::GetBorderThickness(float &topThickness, float &leftThickness, float &bottomThichness, float &rightThickness)
	{
		H_LOG_TRACE(LOGGER, "CRectangle::GetBorderThickness()");

		topThickness = m_topBorderThickness;
		leftThickness = m_leftBorderThickness;
		bottomThichness = m_bottomBorderThickness;
		rightThickness = m_rightBorderThickness;
	}

	void CRectangle::GetSize(float &width, float &height)
	{
		H_LOG_TRACE(LOGGER, "CRectangle::GetSize()");

		width = m_leftBorderThickness + clutter_actor_get_width(t_actor) + m_rightBorderThickness;
		height = m_topBorderThickness + clutter_actor_get_height(t_actor) + m_bottomBorderThickness;
	}

	void CRectangle::GetPosition(float &x, float &y)
	{
		H_LOG_TRACE(LOGGER, "CRectangle::GetPosition(&x, &y)");

		x = clutter_actor_get_x(t_actor) - m_leftBorderThickness;
		y = clutter_actor_get_y(t_actor) - m_topBorderThickness;
	}

	void CRectangle::SetPosition(float x, float y)
	{
		H_LOG_TRACE(LOGGER, "CRectangle::SetPosition(" << x << ", " << y << ")");

		clutter_actor_set_position(t_actor, x + m_leftBorderThickness, y + m_topBorderThickness);
	}


	void CRectangle::SetPosition(float x, float y, float z)
	{
		H_LOG_TRACE(LOGGER, "CRectangle::SetPosition(" << x << ", " << y << ", " << z << ")");

		clutter_actor_set_position(t_actor, x - m_leftBorderThickness, y - m_topBorderThickness);
		setDepth(z);
	}

	void CRectangle::GetPosition(float &x, float &y, float &z)
	{
		H_LOG_TRACE(LOGGER, "CRectangle::GetPosition(&x, &y, &z)");

		x = clutter_actor_get_x(t_actor) - m_leftBorderThickness;
		y = clutter_actor_get_y(t_actor) - m_topBorderThickness;
		z = getDepth();
	}

	const char* CRectangle::GetActorType(void)
	{
		return "Rectangle";
	}
}