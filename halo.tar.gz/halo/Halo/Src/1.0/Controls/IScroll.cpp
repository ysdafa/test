#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{

	IScroll* IScroll::CreateInstance(IActor* parent, float width, float height, EDirectionType direction)
	{
		CScroll* scroll = dynamic_cast<CScroll*>(Instance::CreateInstance(CLASS_ID_ISCROLL));
		HALO_ASSERT(scroll != NULL);

		if (NULL != scroll)
		{
			scroll->Initialize(parent, width, height, direction);
		}

		return scroll;
	}

	IScroll* IScroll::CreateInstance(Widget* parent, float width, float height, EDirectionType direction)
	{
		CScroll* scroll = dynamic_cast<CScroll*>(Instance::CreateInstance(CLASS_ID_ISCROLL));
		HALO_ASSERT(scroll != NULL);

		if (NULL != scroll)
		{
			scroll->Initialize(parent, width, height, direction);
		}

		return scroll;
	}

}