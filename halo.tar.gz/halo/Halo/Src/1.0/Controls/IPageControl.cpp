#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	IPageControl* IPageControl::CreateInstance(IActor* parent, float width, float height)
	{
		CPageControl* pageControl = dynamic_cast<CPageControl*>(Instance::CreateInstance(CLASS_ID_IPAGECONTROL));
		HALO_ASSERT(pageControl != NULL);
			
		if (NULL != pageControl)
		{
			pageControl->Initialize(parent, width, height);
		}

		return pageControl;
	}

	IPageControl* IPageControl::CreateInstance(Widget* parent, float width, float height)
	{
		CPageControl* pageControl = dynamic_cast<CPageControl*>(Instance::CreateInstance(CLASS_ID_IPAGECONTROL));
		HALO_ASSERT(pageControl != NULL);

		if (NULL != pageControl)
		{
			pageControl->Initialize(parent, width, height);
		}

		return pageControl;
	}

}