#ifndef _HALO_CRTFPARSER_H_
#define _HALO_CRTFPARSER_H_

#include "Halo1_0.h"
#include <list>
#include <vector>

namespace HALO
{
	class CRtfParser
	{
	public:
		//! CHaracter Properties.
		typedef struct T_CHAR_PROP
		{
			char fBold;
			char fUnderline;
			char fItalic;
		} CHP;                  
		//! Para alignment type.
		typedef enum {justL, justC, justR, justF } E_JUST;
		//! Paragraph Properties.
		typedef struct T_PARA_PROP
		{
			int xaLeft;                 // left indent in twips
			int xaRight;                // right indent in twips
			int xaFirst;                // first line indent in twips
			E_JUST just;                  // justification
		} PAP;                  

		typedef enum {sbkNon, sbkCol, sbkEvn, sbkOdd, sbkPg} E_SBK;
		typedef enum {pgDec, pgURom, pgLRom, pgULtr, pgLLtr} E_PGN;
		//! Section Properties
		typedef struct T_SECT_PROP
		{
			int cCols;                  // number of columns
			E_SBK sbk;                    // section break type
			int xaPgn;                  // x position of page number in twips
			int yaPgn;                  // y position of page number in twips
			E_PGN pgnFormat;              // how the page number is formatted
		} SEP;                  
		//! Document Properties
		typedef struct T_DOC_PROP
		{
			int xaPage;                 // page width in twips
			int yaPage;                 // page height in twips
			int xaLeft;                 // left margin in twips
			int yaTop;                  // top margin in twips
			int xaRight;                // right margin in twips
			int yaBottom;               // bottom margin in twips
			int pgnStart;               // starting page number in twips
			char fFacingp;              // facing pages enabled?
			char fLandscape;            // landscape or portrait??
		} DOP;                  

		typedef enum { rdsNorm, rdsSkip } E_RDS;              // Rtf Destination State
		typedef enum { risNorm, risBin, risHex } E_RIS;       // Rtf Internal State

		//! Property save structure
		typedef struct T_SAVE             
		{
			struct T_SAVE *pNext;         // next save
			CHP chp;
			PAP pap;
			SEP sep;
			DOP dop;
			E_RDS rds;
			E_RIS ris;
		} SAVE;

		// What types of properties are there?
		typedef enum {ipropBold, ipropItalic, ipropUnderline, ipropLeftInd,
					  ipropRightInd, ipropFirstInd, ipropCols, ipropPgnX,
					  ipropPgnY, ipropXaPage, ipropYaPage, ipropXaLeft,
					  ipropXaRight, ipropYaTop, ipropYaBottom, ipropPgnStart,
					  ipropSbk, ipropPgnFormat, ipropFacingp, ipropLandscape,
					  ipropJust, ipropPard, ipropPlain, ipropSectd,
					  ipropMax } IPROP;

		typedef enum {actnSpec, actnByte, actnWord} E_ACTN;
		typedef enum {propChp, propPap, propSep, propDop} E_PROPTYPE;

		//! Struct of property.
		typedef struct T_PROPMOD
		{
			E_ACTN actn;              // size of value
			E_PROPTYPE prop;          // structure containing value
			int  offset;            // offset of value from base of structure
		} PROP;

		typedef enum {ipfnBin, ipfnHex, ipfnSkipDest } E_IPFN;
		typedef enum {idestPict, idestSkip } E_IDEST;
		typedef enum {kwdChar, kwdDest, kwdProp, kwdSpec} E_KWD;

		//! Struct of kwd symbol.
		typedef struct T_SYMBOL
		{
			char *szKeyword;        // RTF keyword
			int  dflt;              // defaul#include "rtfactn.c"t value to use
			bool fPassDflt;         // true to use default value from this table
			E_KWD  kwd;               // base action to take
			int  idx;               // index into property table if kwd == kwdProp
									// index into destination table if kwd == kwdDest
									// character to print if kwd == kwdChar
		} SYM;

		//! Struct of fontstyle.
		enum  E_FONTSTYLE
		{
			STYLE_NONE        = 0x0000, /*!< NONE */
			STYLE_ITALIC      = 0x0001, /*!< ITALIC */
			STYLE_BOLD        = 0x0002, /*!< BOLD with bold weight */
			STYLE_BACKSLANT   = 0x0004,	/*!< BACKSLANT*/
			STYLE_BORDERED    = 0x0008,	/*!< BORDERED*/
			STYLE_BOLD_FILTER = 0x0010, /*!< BOLD using bold filter */
			STYLE_UNDERLINE	  = 0x0020, /*!< UNDERLINE */
			STYLE_STRIKE	  = 0x0040, /*!< STRIKE */
		};
		static bool Initial(void);
		/*static void ParseRtfFile(const char * filePath, std::list<CRichText::CTCharFormatObj>& charList, std::list<CRichText::CTParagraphFormatObj>& paraList, std::list<char> &textBuf);
		bool BuildRtfFile(const char * charbuf, int offset, std::list<CRichText::CTCharFormatObj> charList, std::list<CRichText::CTParagraphFormatObj> paraList, std::list<char> &textList, int &textBufLen);*/

	private:
		static int ecRtfParse(FILE *fp);
		static int ecPushRtfState(void);
		static int ecPopRtfState(void);
		static int ecParseRtfKeyword(FILE *fp);
		static int ecParseChar(int c);
		static int ecTranslateKeyword(char *szKeyword, int param, bool fParam);
		static int ecPrintChar(int ch);
		static int ecEndGroupAction(E_RDS rds);
		static int ecApplyPropChange(IPROP iprop, int val);
		static int ecChangeDest(E_IDEST idest);
		static int ecParseSpecialKeyword(E_IPFN ipfn);
		static int ecParseSpecialProperty(IPROP iprop, int val);
		static int ecParseHexByte(void);

		static unsigned int m_ConvertStringToNum(const char* rtfText, unsigned int& iPos);
		static bool m_ConvertNumToString(unsigned int uiNum, char* rtfText, const bool bFormat = false);

		/*static int m_CharFormatListAppendMerge(std::list<CRichText::CTCharFormatObj>& charList, CRichText::CTCharFormatObj& stCharFormat);
		static int m_ParaFormatListAppendMerge(std::list<CRichText::CTParagraphFormatObj>& paraList, CRichText::CTParagraphFormatObj& stParaFormat);

		int m_ProduceParaText(CRichText::CTParagraphFormat& stParaFormatCurrent, CRichText::CTParagraphFormat& stParaFormatPrev, char* stRTFBuffer, unsigned int uiRTFBuffersize);
		int m_ProduceCharText(CRichText::CTCharFormat& stCharFormatCurrent, CRichText::CTCharFormat& stCharFormatPrev, char* stRTFBuffer, unsigned int uiRTFBuffersize);
		static int m_ProduceCharFormatStyle(unsigned long &CurrentStyle, unsigned long &PreviousStyle, const char* pRTFCtrl, char* stRTFBuffer, unsigned int uiRTFBuffersize, unsigned int &iIndex);
		static int m_ProduceCharFormatColor(ClutterColor currentColor, ClutterColor previousColor, const char* pRTFCtrl, char* stRTFBuffer, unsigned int uiRTFBuffersize, unsigned int &iIndex);

		static int m_ParseCharFormatStyle(char* pRTFText, unsigned int &i, CRichText::CTCharFormatObj& stCharFormat, E_FONTSTYLE eStyle);
		static int m_ParseCharFormatColor(char* pRTFText, unsigned int &i, ClutterColor color);*/

	private:
		static int cGroup;
		static bool fSkipDestIfUnk;
		static long cbBin;
		static long lParam;

		static E_RDS rds;
		static E_RIS ris;

		static CHP chp;
		static PAP pap;
		static SEP sep;
		static DOP dop;

		static SAVE *psave;
		static FILE *fpIn;
		static PROP rgprop[ipropMax];
		static SYM rgsymRtf[];
		static int isymMax;
		//static std::list<CRichText::CTCharFormatObj> tCharList;
		//static std::list<CRichText::CTParagraphFormatObj> tParaList;
		static int sameProCount;
		static int paraLength;
		static bool flagTextContent;
		static std::list<char> rtfParserList;
		static std::list<char> rtfBuildList;

	};
}


#endif /* _HALO_CRTFPARSER_H_ */
