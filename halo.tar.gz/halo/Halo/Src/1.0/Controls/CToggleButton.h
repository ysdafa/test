#ifndef _CTOGGLE_BUTTON_H_
#define _CTOGGLE_BUTTON_H_

namespace HALO
{

	class CToggleButton : virtual public IToggleButton, public CActor , public IKeyboardListener, public IFocusListener, public IClickListener, public IMouseListener, public IDragListener
	{
	typedef CActor ParentType;
	public:
		CToggleButton();

		virtual ~CToggleButton();

		virtual bool Initialize(IActor *parent , const TToggleButtonAttr &attr);

		virtual void SetCheckImage(ECheckState state , IImageBuffer* imageBuffer, float width ,float height);

		virtual void SetImage(EItemState state , IImageBuffer* imageBuffer);

		virtual void SetText(ECheckState state ,const char* text);

		virtual const char* ItemText(ECheckState state);

		virtual void SetTextFontSize(ECheckState state, const int fontSize);

		virtual void AddListener(ToggleButtonListener *listeners);

		virtual void RemoveListener();

		virtual void SetCheck(bool isChecked);

		virtual bool IsChecked();

		virtual void EnableChecked(bool isEnableChecked);
		
		virtual void Show(bool isOpened);

		virtual void SetAnimationProperty(ClutterAnimationMode animationMode , int aniDuration);
	
		virtual const char* GetActorType(void);
	protected:
		virtual bool OnFocusIn(IActor* pWindow);

		virtual bool OnFocusOut(IActor* pWindow);

		virtual bool OnClicked(IActor* pWindow, IEvent* pClickEvent);

		virtual bool OnKeyPressed(IActor* pThis, IKeyboardEvent* event);
		
		virtual bool OnMousePointerIn( IActor* pWindow, IMouseEvent* ptrMouseEvent );

		virtual bool OnMousePointerOut( IActor* pWindow, IMouseEvent* ptrMouseEvent );

		virtual bool OnDragBegin(IActor* pWindow, IDragEvent* pDragEvent);

		virtual bool OnDragEnd(IActor* pWindow, IDragEvent* pDragEvent);

		virtual bool OnDragMotion(IActor* pWindow, IDragEvent* pDragEvent);
	private:
		struct CTItemStateData
		{
			CImageBuffer* imageBuffer;
		};
		CTItemStateData m_itemStateData[E_STATE_ALL];

		struct CTCheckStateData
		{
			CImageBuffer* imageBuffer;
			float boxW;
			float boxH;
			char* textContent;
			int fontSize;
		};
		CTCheckStateData m_checkStateData[E_STATE_OFF + 1];

		IAction* m_action;

		IAction* m_daction;

		IImage *m_ItemImage;

		IImage *m_CheckImage;

		IText  *m_text;

		ITransition *m_posAni;

		bool m_IsChecked;

		bool m_IsEnableSelected;

		bool m_UseClick;

		bool m_IsMotion;
		ToggleButtonListener *m_listener;

		int m_curCheckState;

		int m_curItemState;

		int m_aniDuration;

		float m_width;
		float m_height;
		float m_boxW;
		float m_boxH;
		float m_xPos;
		float m_yPos;
		float sx;
		float ex;

		void m_Destory();
		void m_CreateAction();
		void m_InitializeState();
		void m_ChangeItemStateTo(EItemState state);
		void m_ChangeCheckStateTo(ECheckState state);
		void m_OnItemStateChange();
		void m_update();
		void m_ProcessOn();
		void m_ProcessOff();

	};

}
#endif
