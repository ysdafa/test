#ifndef _CSINGLELINELISTCONTROL_H_
#define _CSINGLELINELISTCONTROL_H_

namespace HALO
{
	class CSingleLineListControl : virtual public ISingleLineListControl, public CLinearListControl
	{
	public:
		CSingleLineListControl();
		virtual ~CSingleLineListControl();

		bool Initialize(IActor *parent, const TSingleLineListControlAttr &attr);
		bool Initialize(Widget *parent, const TSingleLineListControlAttr &attr);

		enum ESingleLineListEventType
		{			 
			EVENT_FOCUS_CHANGE = 0,				//!< focused item change (focus animation end) event
			EVENT_FOCUS_CHANGE_MOTION_START,	//!< focus change animation starts
			EVENT_ITEM_LOAD,				    //!< item load event
			EVENT_ITEM_UNLOAD,				    //!< item unload event
			EVENT_ITEM_ASYNC_LOAD,				//!< item async load event
			EVENT_MOVE_OUT,						//!< trying to move focus to outward
			EVENT_ITEM_CLICKED,					//!< the callback of item click.
			EVENT_ENTER_KEY_LONG_PRESSED,		//!< the "Enter" key has been long pressed

			EVENT_SINGLLINELIST_MAX,			//!< last grid list event type identifier.
		};

		virtual int NumofItem(void);
		virtual void AddItem(int itemNum, float *itemSpaceArray, float itemGap = 0.0f);
		virtual void AddItem(int itemNum, float itemSpace, float itemGap = 0.0f);
		virtual void InsertItem(int insertPosition, int itemNum, float *itemSpaceArray);
		virtual void InsertItem(int insertPosition, int itemNum, float itemSpace);
		virtual void DeleteItem(int fromItem, int deleteItemNum);
		virtual void SetAnimationDuration(ESingleLineAniType aniType, int duration);
		virtual void AddListListener(ISingleLineListControlListener *listener);
		virtual void SetMargin(TMargin margin);

		virtual void SetItemSpace(int itemIndex, float itemSpace);
		virtual void SetItemSpace(int numOfChangeItem, int itemIndex[], float itemSpace[]);

		bool IsSetMarginWhenFocusEdgeItem(void) const;

		void EnableMarginWhenFocusEdgeItem(const bool flagEnable);

		ISingleLineDataSource * GetDataSource(void);

		IRenderer *Renderer(int itemIndex);

		void SetFocusItemIndex(const int itemIndex);
		int FocusItemIndex(void) const;
		void UpdateUI(int itemIndex);

		void EnableAutoFixMouse(const bool flagAutoFix);
		bool IsAutoFixMouse(void) const;

		virtual void UpdateItem(int itemIndex);

		virtual void UpdateAllItems(void);

		virtual const char* GetActorType(void);
		/* End */

	protected:
		virtual void t_UpdateOrientation(EOrientation orientation);

		virtual bool t_MoveFocusBar(EDirection direction);

		virtual void t_BindDataListToItemList(void);

		void t_OnItemGroupScrollStart(void);
		void t_OnItemGroupScrollEnd(void);

		void t_GetInMemoryItems(TRect lastVisibleArea, TRect visibleArea, std::vector<TItem*> &loadItem, std::vector<TItem*> &unloadItem, std::vector<TItem*> &noChangeItem, int reason = -1);
		void t_GetItemWindowPivotPoint(TItem *item, float &pivotX, float &pivotY, float &pivotZ);

		void t_OnItemDataUnload(TItem *item);
		void t_OnItemDataSyncLoad(TItem *item);
		void t_OnItemDataAsyncLoad(TItem *item);
		void t_OnRendererDraw(TItem *item);

		void t_FocusChangeStart(const TItem *from, const TItem *to);
		void t_FocusChangeFinish(const TItem *from, const TItem *to);

		bool t_OnMousePointerIn(TItem* item, IMouseEvent* ptrMouseEvent);
		bool t_OnMousePointerOut(TItem* item, IMouseEvent* ptrMouseEvent);
		bool t_OnMouseMoved(TItem* item, IMouseEvent* ptrMouseEvent);
		bool t_MouseButtonPressed(TItem* item, IMouseEvent* ptrMouseEvent);
		bool t_MouseButtonRelease(TItem* item, IMouseEvent* ptrMouseEvent);
		bool t_MouseClicked(TItem* item, IMouseEvent* ptrMouseEvent);
		bool t_MouseWheel(IMouseEvent* ptrMouseEvent);

		void t_OnItemInMemoryScrolled(TItem *item);

		TValue2f t_GetRealPointBaseItemGroup(TRect rect, TRect baseOnRect);
		TValue2f t_GetLogicalPosition(TRect rect, TRect baseOnRect);

		TRect t_InitRectOfLoadingItem(TItem *item, int reason);

		struct TSingleLineItem : public TLinearItem
		{
			TSingleLineItem(CSingleLineListControl *inOwner) : TLinearItem(inOwner), owner(inOwner) {};
			virtual ~TSingleLineItem(void);

			CSingleLineListControl *owner;
		};

		TLinearItem* t_AllocLinearItem(void);
		void t_FreeLinearItem(TLinearItem *item);

		void t_GetRealItems(TLinearItem *item, std::vector<TItem*> &itemList);

		virtual bool t_OnEnterKeyLongPressed(void);

		virtual bool t_GetItemsNeedFoveaAni(const TItem *hitItem, std::vector<TItem*> &itemArray, TValue2f cursorCenter, float cursorRadius);

		virtual EDirectionType t_GetScrollDirection(void)
		{
			return t_type;
		}

	private:

		CSingleLineDataSource *m_dataSource;
		enum CTRefreshStatus
		{
			REFRESH_WINDOW = 1,
			REFRESH_ITEM_GROUP = REFRESH_WINDOW << 1,
		};

		TMargin m_margin;

		int m_refreshStatus;

		class CSingleLineListControlListenerSet* m_listenerSet;
		//int m_itemNum;

		int m_frontBufferCnt;
		int m_backBufferCnt;

		int m_curFocusItem;

		bool m_flagUseMarginWhenFocusEdgeItem;

		int m_currentClickedItemIndex;
		double m_xFactor, m_yFactor, m_zFactor;

		bool m_flagAutoFix;

		void m_MoveNext(void);
		void m_MovePrev(void);

		void m_SetFocus(int focusItemIndex, bool flagFocusBarAni, bool flagScrollAni, TValue2f *newItemGroupPos = NULL);
		void m_RefreshListInfo(void);

		bool m_ReCalcFocusItemIndex(const TRect newVisibleArea);
	};
}

#endif
