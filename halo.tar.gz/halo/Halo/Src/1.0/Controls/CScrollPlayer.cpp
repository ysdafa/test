#include "Halo1_0.h"

namespace HALO
{
	CScrollPlayer::CScrollPlayer(void) : m_timerInterval(0), m_scrollDirection(CLUTTER_SCROLL_LEFT), m_dataSource(NULL), m_timerId(-1), m_itemNum(0), m_scrollItemNum(0)
	{
		m_scrollTrans = NULL;
	}

	CScrollPlayer::~CScrollPlayer(void)
	{
		if (NULL != m_scrollTrans)
		{
			if (true == m_scrollTrans->IsPlaying())
			{
				m_scrollTrans->Stop();
			}

			delete m_scrollTrans;
		}
		
		StopTimer();

		for (int i = 0; i < (int)m_itemList.size(); i++)
		{
			TScrollItem* item = m_itemList.at(i);
			delete item->window;
			delete item->renderer;
			delete item;
		}

		m_itemList.clear();
	}

	bool CScrollPlayer::Initialize(IActor* parent, T_SCROLLPLAYER_ATTR *attr)
	{
		bool ret = ActorBase::Initialize(parent, attr->width, attr->height);
		if (ret)
		{
			m_width = attr->width;
			m_height = attr->height;
			m_itemNum = attr->itemNum;
			m_scrollItemNum = m_itemNum;//in default, scroll one page.
			m_timerInterval = attr->timeInterval;
			m_scrollDirection = attr->scrollDirection;
			m_listener = NULL;

			m_scrollTrans = new CMultiObjectTransition;
			m_scrollTrans->Initialize();
			m_scrollTrans->SetDuration(attr->scrollAniDuration);
			m_scrollTrans->SetMode(attr->scrollAniMode);
			m_scrollTrans->AddListener(this, NULL);

			float itemWidth = m_width / m_itemNum;
			//create items with buffer 1
			for (int i = 0; i < m_itemNum + m_scrollItemNum; i++)
			{
				TScrollItem* item = new TScrollItem;
				item->window = new ActorBase;
				item->window->Initialize((IActor*)this, itemWidth, m_height);
				item->window->SetPosition(i*itemWidth, 0.0f);
				item->window->Show();
				item->data = NULL;
				item->dataIndex = i;
				item->renderer = NULL;

				item->rect.Set(i*itemWidth, 0.0f, itemWidth, m_height);
				m_scrollTrans->AddAnimatableObject(item->window, IActor::ACTOR_ANI_POSITION_X);

				m_itemList.push_back(item);
				if (i>=m_itemNum)
				{
					m_bufferItemIndexList.push_back(i);
				}
			}

			m_rendererProvider = NULL;
			SetClipArea(0.0f, 0.0f, attr->width, attr->height);
		}
		return ret;
	}

	bool CScrollPlayer::Initialize(IActor* parent, float width, float height)
	{
		T_SCROLLPLAYER_ATTR attr(width, height);
		return Initialize(parent, &attr);
	}

	void CScrollPlayer::StartTimer(void)
	{
		if (m_timerInterval > 0)
		{
			m_timerId = clutter_threads_add_timeout(m_timerInterval, m_Scroll, this);
		}
	}

	void CScrollPlayer::StopTimer(void)
	{
		if (m_timerId > 0)
		{
			g_source_remove(m_timerId);
		}
	}

	void CScrollPlayer::SetTimeInterval(int milliSecond)
	{
		m_timerInterval = milliSecond;
	}

	void CScrollPlayer::SetScrollDirection(ClutterScrollDirection direction)
	{
		m_scrollDirection = direction;
	}

	void CScrollPlayer::LoadData(void)
	{		
		for (int i = 0; i < m_dataSource->Size() && i < (int)m_itemList.size(); i++)
		{
			m_itemList[i]->data = m_dataSource->GetData(i);
		}

		for (int i = 0; i < (int)m_itemList.size(); i++)
		{
			TScrollItem* item = m_itemList.at(i);
			m_loadItem(item);
		}
	}

	void CScrollPlayer::SetListener(CScrollPlayerListener* listener)
	{
		HALO_ASSERT(listener != NULL);
		m_listener = listener;
	}

	int CScrollPlayer::m_Scroll(gpointer data)
	{
		CScrollPlayer* pThis = (CScrollPlayer*)data;
		pThis->PlayScroll();

		return 1;
	}

	bool CScrollPlayer::OnCompleted(class ITimeLine *animation, void *data)
	{
		for (size_t i = 0; i < m_bufferItemIndexList.size(); i++)
		{
			int bufferItemIndex = m_bufferItemIndexList.at(i);
			TScrollItem* oldBufferItem = m_itemList.at(bufferItemIndex);
			bufferItemIndex = (bufferItemIndex + m_scrollItemNum) % m_itemList.size();//update buffer item index
			m_bufferItemIndexList.at(i) = bufferItemIndex;
			TScrollItem* newBufferItem = m_itemList.at(bufferItemIndex);
			newBufferItem->rect.x = m_width + i * newBufferItem->rect.w;
			newBufferItem->window->SetPosition(newBufferItem->rect.x, newBufferItem->rect.y);//reset buffer item position
			int bufferDataIndex = oldBufferItem->dataIndex;
			bufferDataIndex = (bufferDataIndex + m_scrollItemNum) % m_dataSource->Size();//update buffer item data index

			if (newBufferItem->dataIndex == bufferDataIndex)//if the same, no need to update
			{
				continue;
			}
			else
			{
				m_listener->OnItemUnload(this, newBufferItem->dataIndex);
				newBufferItem->dataIndex = bufferDataIndex;
				newBufferItem->data = m_dataSource->GetData(bufferDataIndex);
				m_loadItem(newBufferItem);
			}
		}

		return true;
	}

	bool CScrollPlayer::OnStarted(class ITimeLine *animation, void *data)
	{
		return true;
	}

	void CScrollPlayer::SetRendererProvider(IRendererProvider* provider)
	{
		HALO_ASSERT(provider != NULL);
		m_rendererProvider = provider;
	}

	void CScrollPlayer::SetDataSource(CSingleLineDataSource *dataSource)
	{
		m_dataSource = dataSource;
	}

	IRenderer * CScrollPlayer::m_GetRenderer(TScrollItem* item)
	{
		if (m_rendererProvider == NULL)
		{
			return NULL;
		}
		if (item->renderer == NULL)
		{
			item->renderer = m_rendererProvider->GetRenderer((IData*)item->data, item->window);
		}

		return item->renderer;
	}

	void CScrollPlayer::m_loadItem(TScrollItem* item)
	{
		IData *data = item->data;

		if (data->IsReady())
		{
			IRenderer* re1 = m_GetRenderer(item);
			if (re1 != NULL)
			{
				re1->Draw(data, item->window, IRenderer::LOAD_DATA_DRAW);
			}
		}
		else
		{
			switch (data->DataLoadType())
			{
			case IData::E_LOAD_TYPE_SYNC:
			{
				//m_Listener->IfDataLoaded(this, data, singleItem->index);
				m_listener->OnItemLoad(this, item->dataIndex);
				IRenderer* re = m_GetRenderer(item);
				if (re != NULL)
					re->Draw(data, item->window, IRenderer::LOAD_DATA_DRAW);
				break;
			}
			case IData::E_LOAD_TYPE_ASYNC:
			{
				break;
			}
			case IData::E_LOAD_TYPE_SYNC_ASYNC:
			{
				break;
			}
			default:
				break;
			}
		}
	}

	void CScrollPlayer::SetItemNumber(void)
	{

	}

	const char* CScrollPlayer::GetActorType(void)
	{
		return "ScrollPlayer";
	}

	void CScrollPlayer::PlayScroll(void)
	{
		int itemNum = m_itemList.size();
		float itemWidth = m_width / m_itemNum;
		for (int i = 0; i < itemNum; i++)
		{
			TScrollItem* item = m_itemList.at(i);
			item->rect.x -= itemWidth * m_scrollItemNum;

			TValue1f dest(item->rect.x);
			m_scrollTrans->SetDestination(item->window, IActor::ACTOR_ANI_POSITION_X, &dest);
		}

		m_scrollTrans->Play();
	}

	void CScrollPlayer::SetScrollItemNumber(int scrollItemNumber)
	{
		m_scrollItemNum = scrollItemNumber;
	}

	void CScrollPlayer::UpdateItem(int dataIndex)
	{
		HALO_ASSERT(dataIndex >= 0 && dataIndex < m_dataSource->Size());
		if (m_itemList.empty())
		{
			return;
		}

		//calculate the item's index which contains the data to be updated.
		int beginIndex = m_itemList.front()->dataIndex;
		int destItemIndex;
		if (dataIndex >= beginIndex && dataIndex < beginIndex + (int)m_itemList.size())
		{
			destItemIndex = dataIndex - beginIndex;
		}
		else if (dataIndex < beginIndex)
		{
			if (m_dataSource->Size() == m_itemList.size())
			{
				destItemIndex = dataIndex - beginIndex + m_itemList.size();
			}
			else
			{
				return;
			}
		}
		else
		{
			return;
		}

		m_loadItem(m_itemList.at(destItemIndex));//redraw the item with new data.
	}

}


