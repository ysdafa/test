#include "Halo1_0.h"
namespace HALO
{

	void CListItemDecorator::SetUIElementStyle( int style )
	{
		t_style = style;
	}

	void CProgressDecorator::Enable(bool flagEnable)
	{
		m_progress->Enable(flagEnable);
	}

	void CProgressDecorator::LoadData()
	{
		m_progress->SetBackgroundImage(m_bgImage);
		m_progress->SetProgressImage(m_progressImage);
		m_progress->SetReverse(m_reverseFlag);
		m_progress->SetBackgroundColor(m_bgColor);
	}

	void CProgressDecorator::UnLoadData()
	{

	}

	void CProgressDecorator::Create( TRect* rect  , IActor* parent)
	{
		TProgressAttr* progressAttr = ((TProgressAttr*)rect);

		m_progress = IProgress::CreateInstance(parent, progressAttr->w, progressAttr->h, progressAttr->direction);
		m_progress->SetPosition(progressAttr->x , progressAttr->y );
		m_MinValue = progressAttr->minValue;
		m_MaxValue = progressAttr->maxValue;
		m_progressType = progressAttr->direction;
		m_reverseFlag = progressAttr->flagReverse;
		m_bgColor = progressAttr->bgcolor;
		m_bgImage = progressAttr->backgroudImage;
		m_progressImage = progressAttr->progressImage;
		//m_progress->SetMinMaxValue(m_MinValue , m_MaxValue);
	}

	void CProgressDecorator::SetValue( int value )
	{
		m_progress->SetValue(value);
	}

	CProgressDecorator::~CProgressDecorator()
	{
		if ( NULL != m_progress )
		{
			delete m_progress;
			m_progress = NULL;
		}
		if ( NULL != m_bgImage )
		{
			delete m_bgImage;
			m_bgImage = NULL;
		}
		if ( NULL != m_progressImage )
		{
			delete m_progressImage;
			m_progressImage = NULL;
		}
	}

	void CTextDecorator::Enable(bool flagEnable)
	{
		m_text->Enable(flagEnable);
	}

	void CTextDecorator::LoadData()
	{
		m_text->SetFontSize(m_fontSize);
		m_text->SetTextAlignment(m_hAlignment , m_vAlignment);
		m_text->SetTextColor(m_textColor);
		m_text->SetText(m_contentText);	
	}

	void CTextDecorator::UnLoadData()
	{

	}

	void CTextDecorator::Create( TRect* rect  , IActor* parent)
	{
		TTextAttr* textAttr = ((TTextAttr*)rect);
		m_text = IText::CreateInstance(parent , textAttr->w , textAttr->h);
		m_text->SetPosition(textAttr->x , textAttr->y);
		m_fontSize = textAttr->fontSize;
		m_hAlignment = textAttr->hAlign;
		m_vAlignment = textAttr->vAlign;
		m_textColor = textAttr->color;
		m_contentText = textAttr->contentText;
	}

	CTextDecorator::~CTextDecorator()
	{
		if ( NULL != m_contentText )
		{
			delete m_contentText;
			m_contentText = NULL;
		}
		if ( NULL != m_text )
		{
			delete m_text;
			m_text = NULL;
		}
	}


	void CImageDecorator::Enable(bool flagEnable)
	{
		m_image->Enable(flagEnable);
	}

	void CImageDecorator::LoadData()
	{
		m_image->SetFillMode(m_gravity);
		m_image->SetImage(m_imageBuffer);
	}

	void CImageDecorator::UnLoadData()
	{

	}

	void CImageDecorator::Create( TRect* rect  , IActor* parent)
	{
		TImageAttr* imageAttr = ((TImageAttr*)rect);
		m_image = IImage::CreateInstance(parent , imageAttr->w , imageAttr->h);
		m_image->SetPosition(imageAttr->x , imageAttr->y);
		m_imageBuffer = imageAttr->imagebuffer;
		m_gravity = imageAttr->gravity;
	}

	void CImageDecorator::SetImageBuffer( IImageBuffer *buffer )
	{
		m_image->SetImage(buffer);
	}

	CImageDecorator::~CImageDecorator()
	{
		if ( NULL != m_image )
		{
			delete m_image;
			m_image = NULL;
		}

		if ( NULL != m_imageBuffer )
		{
			delete m_imageBuffer;
			m_imageBuffer = NULL;
		}
	}



}