#ifndef _HALO_CIMAGE_H_
#define _HALO_CIMAGE_H_

namespace HALO
{
	class CImage: public virtual IImage, public CActor
	{
	public:
		CImage(void) : t_content(NULL), m_imageBuffer(NULL), m_flagCreatedInternally(false), m_path(NULL){}
		virtual ~CImage(void);

		virtual bool Initialize(IActor* parent, float width, float height);
		virtual bool Initialize(Widget* parent, float width, float height);

		void SetImage(const char *imagePath);
		void SetImage(IImageBuffer *buffer);

		IImageBuffer* ImageBuffer(void);

		void SetFillMode(ClutterContentGravity gravity);
		ClutterContentGravity FillMode(void);
		virtual const char* ImagePath(void) { return m_path; }
		virtual const char* GetActorType(void);
	protected:
		virtual ClutterContent  *t_CreateContent();
		ClutterContent  *t_content;

	private:
		IImageBuffer *m_imageBuffer;
		bool m_flagCreatedInternally;
		const char *m_path;

		void m_DestroyImage(void);
	};

} /* namespace HALO */
#endif /* _HALO_CIMAGE_H_ */
