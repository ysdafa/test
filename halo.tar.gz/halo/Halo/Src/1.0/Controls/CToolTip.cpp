#include "Halo1_0.h"

namespace HALO
{
	static HALO::util::Logger LOGGER("CToolTip");

	CToolTip::CToolTip()
	{
		m_frame = NULL;
		m_popup = NULL;
		m_tail = NULL;
		m_text = NULL;

		m_tailSideRatio = 0.2f;
		m_textRatio = 1.0f;
	}

	CToolTip::~CToolTip()
	{
		if (m_text != NULL)
		{
			m_text->Release();
		}
		if (m_tail != NULL)
		{
			m_tail->Release();
		}
		if (m_popup != NULL)
		{
			m_popup->Release();
		}
		if (m_frame != NULL)
		{
			m_frame->Release();
		}
	}

	bool CToolTip::Initialize(IActor *parent, float width, float height)
	{
		Widget *cParent = dynamic_cast<Widget*>(parent);

		return Initialize(cParent, width, height);
	}

	bool CToolTip::Initialize(Widget *parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::Initialize a ToolTip");
		CActor::Initialize(parent, width, height);
		Widget *widget = dynamic_cast<Widget*>(this);
		if (widget != NULL)
		{
			m_showTimerId = -1;

			ClutterColor c = { 64, 64, 64, 0 };
			m_frame = IActor::CreateInstance(widget, width, height);
			m_frame->SetBackgroundColor(c);
			m_frame->SetPosition(0, 0);
			m_frame->EnableReverse(false);

			m_tailPosition = POSITION_START;
			m_tailSide = SIDE_DOWN;
			m_enablePositionCustom = false;
			m_enableReverse = false;
			m_tailPositionLength = 0;
			m_frameWidth = 0;

			m_tailWidth = 10;
			m_tailHeight = 10;
			m_tailOffset = 0;
			m_tail = ICompositeImage::CreateInstance(widget, m_tailWidth, m_tailHeight);
			m_tail->EnableReverse(false);

			m_CalPopupSize();
			m_popup = ICompositeImage::CreateInstance(widget, m_popupWidth, m_popupHeight);
			m_popup->EnableReverse(false);

			m_text = IText::CreateInstance(m_popup, m_popupWidth, m_popupHeight);
			m_text->SetTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
			m_text->EnableMultiLine(true);
			m_text->SetFont("Sans 30px");
		}
		EnableFocus(false);
		EnablePointerFocus(false);
		return true;
	}

	void CToolTip::m_CalPopupSize(void)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::calPopupSize");
		this->GetSize(m_popupWidth, m_popupHeight);
		switch (m_tailSide)
		{
		case SIDE_UP:
		case SIDE_DOWN:
			//reduce tail
			m_popupHeight -= m_tailHeight;
			//reduce frame
			m_popupWidth -= m_frameWidth * 2;
			m_popupHeight -= m_frameWidth;
			break;
		case SIDE_LEFT:
		case SIDE_RIGHT:
			//reduce tail
			m_popupWidth -= m_tailWidth;
			//reduce frame
			m_popupWidth -= m_frameWidth;
			m_popupHeight -= m_frameWidth * 2;
			break;
		}
	}

	void CToolTip::m_CalFrameSize(float& width, float& height)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::m_CalFrameSize");
		this->GetSize(width, height);
		switch (m_tailSide)
		{
		case SIDE_UP:
		case SIDE_DOWN:
			height = m_popupHeight + m_frameWidth * 2;
			break;
		case SIDE_LEFT:
		case SIDE_RIGHT:
			width = m_popupWidth + m_frameWidth * 2;
			break;
		}
	}

	void CToolTip::Resize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::Resize, width:" << width << "height:" << height);
		this->CActor::Resize(width, height);
		m_RefreshBalloon();
	}

	void CToolTip::SetTailSize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::SetTailSize, width:" << width << "height:" << height);
		m_tailWidth = width > m_popupWidth ? m_popupWidth : width;
		m_tailHeight = height > m_popupHeight ? m_popupHeight : height;
		m_tail->Resize(m_tailWidth, m_tailHeight);
		m_RefreshBalloon();
	}

	void CToolTip::SetTailOffset(float offset)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::SetTailOffset(offset), offset:" << offset);
		m_tailOffset = offset;
	}

	float CToolTip::TailOffset(void) const
	{
		H_LOG_TRACE(LOGGER, "CToolTip::TailOffset.");
		return m_tailOffset;
	}

	void CToolTip::SetTailPosition(EToolTipTailSide side, EToolTipTailPosition position, float offset)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::SetTailOffset(side, position, offset) :" << side << "," << position << "," << offset);
		SetTailOffset(offset);
		SetTailPosition(side, position);
	}

	void CToolTip::SetTailPosition(EToolTipTailSide side, EToolTipTailPosition position)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::SetTailOffset(side, position) :" << side << "," << position);
		m_enablePositionCustom = false;
		m_tailSide = side;
		m_tailPosition = position;
		m_RefreshBalloon();
		m_RefreshTail();
	}

	void CToolTip::SetTailPosition(EToolTipTailSide side, float length, float offset)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::SetTailOffset(side, length, offset) :" << side << "," << length << "," << offset);
		SetTailOffset(offset);
		SetTailPosition(side, length);
	}

	void CToolTip::SetTailPosition(EToolTipTailSide side, float length)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::SetTailOffset(side, length) :" << side << "," << length);
		m_enablePositionCustom = true;
		m_tailSide = side;
		m_tailPositionLength = length;
		m_RefreshBalloon();
		m_RefreshTail();
	}

	void CToolTip::m_RefreshBalloon(void)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::RefreshBalloon");
		//calculate popup size
		m_CalPopupSize();
		m_popup->Resize(m_popupWidth, m_popupHeight);
		m_text->Resize(m_popupWidth * m_textRatio, m_popupHeight * m_textRatio);

		//calculate popup position
		float popupX = 0, popupY = 0;
		m_CalPopupPosition(popupX, popupY);
		//popup_x = popup_x - m_frameWidth;
		//popup_y = popup_y - m_frameWidth;
		m_popup->SetPosition(popupX, popupY);

		//calculate frame size;
		float frameWidth = 0, frameHeight = 0;
		m_CalFrameSize(frameWidth, frameHeight);
		m_frame->Resize(frameWidth, frameHeight);

		float frameX = 0, frameY = 0;
		m_CalFramePosition(frameX, frameY);
		m_frame->SetPosition(frameX, frameY);

		//calculate tail position
		float tailX = 0, tailY = 0;
		m_CalTailPosition(tailX, tailY);
		m_tail->SetPosition(tailX, tailY);

		//calculate label position
		float textX, textY = 0;
		m_CalTextPosition(textX, textY);
		m_text->SetPosition(textX, textY);
	}

	void CToolTip::m_CalPopupPosition(float& x, float& y)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::calPopupPosition");
		x = 0;
		y = 0;
		if (m_enableReverse)
		{
			switch (m_tailSide)
			{
			case SIDE_UP:
				y = m_tailHeight;
				x = m_frameWidth;
				break;
			case SIDE_DOWN:
				x = m_frameWidth;
				y = m_frameWidth;
				break;
			case SIDE_LEFT:
				x = m_frameWidth;
				y = m_frameWidth;
				break;
			case SIDE_RIGHT:
				x = m_tailWidth;
				y = m_frameWidth;
				break;
			}
		}
		else
		{
			switch (m_tailSide)
			{
			case SIDE_UP:
				y = m_tailHeight;
				x = m_frameWidth;
				break;
			case SIDE_DOWN:
				x = m_frameWidth;
				y = m_frameWidth;
				break;
			case SIDE_LEFT:
				x = m_tailWidth;
				y = m_frameWidth;
				break;
			case SIDE_RIGHT:
				x = m_frameWidth;
				y = m_frameWidth;
				break;
			}
		}		
	}

	void CToolTip::m_CalFramePosition(float& x, float& y)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::m_CalFramePosition");
		x = 0;
		y = 0;
		float actorWidth = 0, actorHeight = 0, frameWidth=0, frameHeight = 0;
		this->GetSize(actorWidth, actorHeight);
		m_frame->GetSize(frameWidth, frameHeight);
		if (m_enableReverse)
		{
			switch (m_tailSide)
			{
			case SIDE_UP:
				y = actorHeight - frameHeight;
				break;
			case SIDE_RIGHT:
				x = actorWidth - frameWidth;
				break;
			case SIDE_DOWN:
			case SIDE_LEFT:
				break;
			}
		}
		else
		{
			switch (m_tailSide)
			{
			case SIDE_UP:
				y = actorHeight - frameHeight;
				break;
			case SIDE_LEFT:
				x = actorWidth - frameWidth;
				break;
			case SIDE_DOWN:
			case SIDE_RIGHT:
				break;
			}
		}		
	}

	void CToolTip::m_CalTailPosition(float& x, float& y)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::calTailPosition");
		x = 0;
		y = 0;
		if (m_enableReverse)
		{
			switch (m_tailSide)
			{
			case SIDE_UP:
				x = m_frameWidth;
				y = -m_tailOffset;
				break;
			case SIDE_DOWN:
				x = m_frameWidth;
				y = m_popupHeight + m_tailOffset + m_frameWidth;
				break;
			case SIDE_LEFT:
				x = m_popupWidth + m_tailOffset + m_frameWidth;
				y = m_frameWidth;
				break;
			case SIDE_RIGHT:
				x = -m_tailOffset;
				y = m_frameWidth;
				break;
			}

			if (m_enablePositionCustom)
			{
				if (m_tailSide == SIDE_DOWN || m_tailSide == SIDE_UP)
				{
					x += (m_popupWidth - m_tailPositionLength - m_tailWidth);
				}
				else
				{
					y += m_tailPositionLength;
				}
			}
			else
			{
				switch (m_tailPosition)
				{
				case POSITION_START:
					if (m_tailSide == SIDE_DOWN || m_tailSide == SIDE_UP)
					{
						x += (m_popupWidth - (m_popupWidth - m_tailWidth) * m_tailSideRatio - m_tailWidth);
					}
					else
					{
						y += (m_popupHeight - m_tailHeight) * m_tailSideRatio;
					}
					break;
				case POSITION_END:
					if (m_tailSide == SIDE_DOWN || m_tailSide == SIDE_UP)
					{
						x += (m_popupWidth - (m_popupWidth - (m_popupWidth - m_tailWidth) * m_tailSideRatio) - m_tailWidth);
					}
					else
					{
						y += m_popupHeight - (m_popupHeight - m_tailHeight) * m_tailSideRatio;
					}
					break;
				case POSITION_CENTER:
					if (m_tailSide == SIDE_DOWN || m_tailSide == SIDE_UP)
					{
						x += (m_popupWidth - m_tailWidth) / 2;
					}
					else
					{
						y += (m_popupHeight - m_tailHeight) / 2;
					}
					break;
				}
			}
		}
		else
		{
			switch (m_tailSide)
			{
			case SIDE_UP:
				x = m_frameWidth;
				y = -m_tailOffset;
				break;
			case SIDE_DOWN:
				x = m_frameWidth;
				y = m_popupHeight + m_tailOffset + m_frameWidth;
				break;
			case SIDE_LEFT:
				x = -m_tailOffset;
				y = m_frameWidth;
				break;
			case SIDE_RIGHT:
				x = m_popupWidth + m_tailOffset + m_frameWidth;
				y = m_frameWidth;
				break;
			}

			if (m_enablePositionCustom)
			{
				if (m_tailSide == SIDE_DOWN || m_tailSide == SIDE_UP)
				{
					x += m_tailPositionLength;
				}
				else
				{
					y += m_tailPositionLength;
				}
			}
			else
			{
				switch (m_tailPosition)
				{
				case POSITION_START:
					if (m_tailSide == SIDE_DOWN || m_tailSide == SIDE_UP)
					{
						x += (m_popupWidth - m_tailWidth) * m_tailSideRatio;
					}
					else
					{
						y += (m_popupHeight - m_tailHeight) * m_tailSideRatio;
					}
					break;
				case POSITION_END:
					if (m_tailSide == SIDE_DOWN || m_tailSide == SIDE_UP)
					{
						x += m_popupWidth - (m_popupWidth - m_tailWidth) * m_tailSideRatio;
					}
					else
					{
						y += m_popupHeight - (m_popupHeight - m_tailHeight) * m_tailSideRatio;
					}
					break;
				case POSITION_CENTER:
					if (m_tailSide == SIDE_DOWN || m_tailSide == SIDE_UP)
					{
						x += (m_popupWidth - m_tailWidth) / 2;
					}
					else
					{
						y += (m_popupHeight - m_tailHeight) / 2;
					}
					break;
				}
			}
		}
	}

	void CToolTip::m_CalTextPosition(float& x, float& y)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::calTextPosition");
		m_text->GetSize(x, y);
		x = (m_popupWidth - x) * 0.5f;
		y = (m_popupHeight - y) * 0.5f;
	}
	
	void CToolTip::SetPopupImage(const std::string& image)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::SetPopupImage:" << image.c_str());
		m_popup->SetImage(image.c_str());
	}

	std::string CToolTip::PopupImage(void) const
	{
		H_LOG_TRACE(LOGGER, "CToolTip::PopupImageString.");
		return m_popup->ImagePath();
	}

	void CToolTip::SetTailImage(const std::string& image)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::SetTailImage:" << image.c_str());
		m_tail->SetImage(image.c_str());
	}

	std::string CToolTip::TailImage(void) const
	{
		H_LOG_TRACE(LOGGER, "CToolTip::TailImage.");
		return m_tail->ImagePath();
	}

	void CToolTip::SetText(const std::string& text)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::SetText:" << text.c_str());
		m_text->SetText(text.c_str());
	}

	std::string CToolTip::Text(void) const
	{
		H_LOG_TRACE(LOGGER, "CToolTip::Text." );
		return m_text->Text();
	}

	void CToolTip::SetFont(const std::string& font)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::SetFont:" << font.c_str());
		m_text->SetFont(font.c_str());
	}

	std::string CToolTip::Font(void) const
	{
		H_LOG_TRACE(LOGGER, "CToolTip::Font.");
		return m_text->Font();
	}

	void CToolTip::SetFontSize(int size)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::SetFontSize:" << size);
		m_text->SetFontSize(size);
	}

	int CToolTip::FontSize(void) const
	{
		H_LOG_TRACE(LOGGER, "CToolTip::FontSize.");
		return m_text->FontSize();
	}

	void CToolTip::SetTextColor(const ClutterColor& color)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::SetTextColor");
		m_text->SetTextColor(color);
	}

	void CToolTip::SetTextBackgroundColor(const ClutterColor& color)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::SetTextBackgroundColor");
		m_text->SetBackgroundColor(color);
	}

	IText* CToolTip::TextActor(void)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::TextActor");
		return m_text;
	}

	void CToolTip::SetFrameColor(const ClutterColor& color)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::SetFrameColor");
		m_frame->SetBackgroundColor(color);
	}

	void CToolTip::SetFrameWidth(float width)
	{
		H_LOG_TRACE(LOGGER, "CToolTip::SetFrameWidth:" << width);
		m_frameWidth = width;
		m_RefreshBalloon();
	}

	float CToolTip::FrameWidth(void) const
	{
		H_LOG_TRACE(LOGGER, "CToolTip::FrameWidth.");
		return m_frameWidth;
	}

	void CToolTip::m_EnableReverse(bool enable)
	{
		if (enable == m_enableReverse)
		{
			return;
		}
		m_enableReverse = enable;
		m_RefreshBalloon();
		m_RefreshTail();
	}

	void CToolTip::SetUpTailImage(const std::string& image)
	{
		m_upTailImage = image;
		if (m_tailSide == SIDE_UP)
		{
			m_tail->SetImage(m_upTailImage.c_str());
		}
	}
	
	std::string CToolTip::UpTailImage(void) const
	{
		return m_upTailImage;
	}

	void CToolTip::SetDownTailImage(const std::string& image)
	{
		m_downTailImage = image;
		if (m_tailSide == SIDE_DOWN)
		{
			m_tail->SetImage(m_downTailImage.c_str());
		}
	}

	std::string CToolTip::DownTailImage(void) const
	{
		return m_downTailImage;
	}

	void CToolTip::SetLeftTailImage(const std::string& image)
	{
		m_leftTailImage = image;
		if (m_tailSide == SIDE_LEFT)
		{
			m_tail->SetImage(m_leftTailImage.c_str());
		}
	}

	std::string CToolTip::LeftTailImage(void) const
	{
		return m_leftTailImage;
	}

	void CToolTip::SetRightTailImage(const std::string& image)
	{
		m_rightTailImage = image;
		if (m_tailSide == SIDE_RIGHT)
		{
			m_tail->SetImage(m_rightTailImage.c_str());
		}
	}

	std::string CToolTip::RightTailImage(void) const
	{
		{
			return m_rightTailImage;
		}
	}

	void CToolTip::m_RefreshTail(void)
	{
		if (m_enableReverse)
		{
			switch (m_tailSide)
			{
			case SIDE_UP:
				if ((int)m_upTailImage.length() > 0)
				{
					m_tail->SetImage(m_upTailImage.c_str());
				}				
				break;
			case SIDE_DOWN:
				if ((int)m_downTailImage.length() > 0)
				{
					m_tail->SetImage(m_downTailImage.c_str());
				}
				break;
			case SIDE_LEFT:
				if ((int)m_rightTailImage.length() > 0)
				{
					m_tail->SetImage(m_rightTailImage.c_str());
				}
				break;
			case SIDE_RIGHT:
				if ((int)m_leftTailImage.length() > 0)
				{
					m_tail->SetImage(m_leftTailImage.c_str());
				}
				break;
			}
		}
		else
		{
			switch (m_tailSide)
			{
			case SIDE_UP:
				if ((int)m_upTailImage.length() > 0)
				{
					m_tail->SetImage(m_upTailImage.c_str());
				}
				break;
			case SIDE_DOWN:
				if ((int)m_downTailImage.length() > 0)
				{
					m_tail->SetImage(m_downTailImage.c_str());
				}
				break;
			case SIDE_LEFT:
				if ((int)m_leftTailImage.length() > 0)
				{
					m_tail->SetImage(m_leftTailImage.c_str());
				}
				break;
			case SIDE_RIGHT:
				if ((int)m_rightTailImage.length() > 0)
				{
					m_tail->SetImage(m_rightTailImage.c_str());
				}
				break;
			}
		}		
	}
}

void CToolTip::t_UpdateOrientation(EOrientation orientation)
{
	if (orientation == ORIENTATION_RIGHT_TO_LEFT)
	{
		m_EnableReverse(true);
	}
	else
	{
		m_EnableReverse(false);
	}
	CActor::t_UpdateOrientation(orientation);
}

void CToolTip::t_OnShow(void)
{
	t_NoticeActorFocusIn(this);
}

void CToolTip::SetShowTime(guint time)
{
	if (m_showTimerId > 0)
	{
		//destroy last timer before
		g_source_remove(m_showTimerId);
	}

	if (time <= 0)
	{
		m_showTimerId = -1;
		m_showTime = -1;
	}
	else
	{
		//Open auto hide
		m_showTime = time;
		m_showTimerId = g_timeout_add(m_showTime, (GSourceFunc)m_HideTooltip, this);
	}
}

guint CToolTip::ShowTime() const
{
	return m_showTime;
}

gboolean CToolTip::m_HideTooltip(gpointer data)
{
	CToolTip* tip = reinterpret_cast<CToolTip *>(data);
	if (tip)
	{
		tip->Hide();
	}
	return false;
}