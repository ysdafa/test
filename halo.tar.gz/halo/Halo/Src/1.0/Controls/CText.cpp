#include "Halo1_0.h"

#define FONT_DEFAULT "Sans 20px"
namespace HALO
{
	CText::CText()
	{
		// TODO Auto-generated constructor stub
		m_shadowAttr.shadowFlag = false;
		clutter_color_init(&m_shadowAttr.shadowColor, 0, 0, 0, 0);
		m_shadowAttr.shadowXPos = 0;
		m_shadowAttr.shadowYPos = 0;
		m_shadowPaintId = 0;
		m_hAlignment = HALIGN_LEFT;
		m_vAlignment = VALIGN_TOP;
		m_fontSize = 0;
		m_enableEllipsize = false;

		m_animationScaleAttr.scaled_size = 30;
		m_animationScaleAttr.duration = 200;
		m_animationScaleAttr.delay = 20;
		m_animationScaleAttr.ani_mode = CLUTTER_LINEAR;

		m_animationScrollAttr.type = CLUTTER_TEXT_SCROLL_START_OUTSIDE_STOP_OUTSIDE;
		m_animationScrollAttr.direction = CLUTTER_TIMELINE_BACKWARD;
		m_animationScrollAttr.delay = 500;
		m_animationScrollAttr.duration = 5000;
		m_animationScrollAttr.repeat = 1;
		m_animationScrollAttr.continueGap = 0;
		m_textScale = NULL;
		m_textScroll = NULL;
		m_text = NULL;
		m_pangoAttrList = NULL;
		m_pangoAttrState = 0;
		m_rowGap = 0;
		m_textAllocationBox.x1 = 0;
		m_textAllocationBox.y1 = 0;

		m_IsScrollStartFlag = false;
		m_hasScrollStartFlag = false;
		m_preScrollStartMultiLineFlag = false;
		m_preScrollStartEllipsisFlag = false;
	}

	CText::~CText()
	{
		// TODO Auto-generated destructor stub
		if (m_shadowPaintId)
		{
			g_signal_handler_disconnect(CLUTTER_ACTOR(m_text), m_shadowPaintId);
		}
		if (m_textScale != NULL)
		{
			clutter_actor_destroy(CLUTTER_ACTOR(m_textScale));
			m_textScale = NULL;
		}
		if (m_textScroll != NULL)
		{
			clutter_actor_destroy(m_textScroll);
			m_textScroll = NULL;
		}
		if (m_text != NULL)
		{
			clutter_actor_destroy(CLUTTER_ACTOR(m_text));
			m_text = NULL;
		}
		if (m_pangoAttrList != NULL)
		{
			pango_attr_list_unref(m_pangoAttrList);
			m_pangoAttrList = NULL;
		}
	}

	bool CText::Initialize(IActor *parent, float width, float height)
	{
		Widget *cParent = dynamic_cast<Widget*>(parent);

		return Initialize(cParent, width, height);
	}

	bool CText::Initialize(Widget *parent, float width, float height)
	{
		CActor::Initialize(parent, width, height);
		m_text = (ClutterText*)clutter_text_new();
		clutter_actor_add_child(t_actor, CLUTTER_ACTOR(m_text));
		clutter_text_set_editable(m_text, FALSE);
		clutter_text_set_single_line_mode(m_text, TRUE);
		if (height != -1)
		{
			clutter_actor_set_clip_to_allocation(t_actor, TRUE);
		}
		
		m_textLayout = clutter_bin_layout_new(CLUTTER_BIN_ALIGNMENT_FILL, CLUTTER_BIN_ALIGNMENT_START);
		clutter_actor_set_layout_manager(t_actor, m_textLayout);
		clutter_actor_set_x_expand(CLUTTER_ACTOR(m_text), TRUE);
		clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_FILL);
		clutter_actor_set_y_expand(CLUTTER_ACTOR(m_text), TRUE);
		clutter_actor_set_y_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_START);

		SetTextAlignment(HALIGN_LEFT, VALIGN_TOP);
		clutter_text_set_font_name(m_text, FONT_DEFAULT);
		m_fontSize = FontSize();
			
		return true;
	}

	void CText::SetScaleAttribute(guint scaled_size, guint duration, guint delay, ClutterAnimationMode ani_mode)
	{
		ASSERT((int)scaled_size >= 0);
		ASSERT((int)duration >= 0);
		ASSERT((int)delay >= 0);

		m_animationScaleAttr.scaled_size = scaled_size;
		m_animationScaleAttr.duration = duration;
		m_animationScaleAttr.delay = delay;
		m_animationScaleAttr.ani_mode = ani_mode;

		if (m_textScale != NULL)
		{
			clutter_actor_destroy(CLUTTER_ACTOR(m_textScale));
			m_textScale = NULL;
		}
		m_textScale = clutter_text_scaling_animation_group_new_full( m_animationScaleAttr.scaled_size, m_animationScaleAttr.duration, m_animationScaleAttr.delay, m_animationScaleAttr.ani_mode);		
		clutter_text_scaling_animation_add_actor_in_group(m_textScale, CLUTTER_TEXT(m_text));

		m_updateTextSize();
	}

	void CText::SetScaleSize(guint scale_size)
	{
		m_animationScaleAttr.scaled_size = scale_size;
		clutter_text_scaling_animation_set_scaled_size(CLUTTER_TEXT_SCALING_ANIMATION(m_textScale), m_animationScaleAttr.scaled_size);
	}

	void CText::StartScaleText()
	{
		m_updateTextSize();

		clutter_text_scaling_animation_set_scaled_size(CLUTTER_TEXT_SCALING_ANIMATION(m_textScale), m_animationScaleAttr.scaled_size);
		clutter_text_scaling_animation_start(CLUTTER_TEXT_SCALING_ANIMATION(m_textScale));
	}

	void CText::StopScaleText()
	{
		m_updateTextSize();

		clutter_text_scaling_animation_set_scaled_size(CLUTTER_TEXT_SCALING_ANIMATION(m_textScale), m_fontSize);
		clutter_text_scaling_animation_start(CLUTTER_TEXT_SCALING_ANIMATION(m_textScale));
	}

	void CText::SetScrollAttribute(guint duration, guint delay, gint repeat, ClutterTextScrollType type, ClutterTimelineDirection direction, guint continueGap)
	{
		m_animationScrollAttr.duration = duration;
		m_animationScrollAttr.delay = delay;
		m_animationScrollAttr.repeat = repeat;
		m_animationScrollAttr.type = type;
		m_animationScrollAttr.direction = direction;
		m_animationScrollAttr.continueGap = continueGap;
	}

	void CText::StartScrollText(void)
	{
		m_hasScrollStartFlag = true;
		PangoLayout *layoutCopy = pango_layout_copy(clutter_text_get_layout(m_text));
		int parentW = (int)this->getWidth();
		int parentH = (int)this->getHeight();

		if (clutter_text_get_single_line_mode(m_text))
		{//single-line limit
			pango_layout_set_width(layoutCopy, -1);
			pango_layout_set_height(layoutCopy, -1);
			int textW, textH;
			pango_layout_get_size(layoutCopy, &textW, &textH);
			textW = textW / PANGO_SCALE;
			if (textW <= parentW)
			{
				return;
			}
		}
		else
		{//multi-line limit
			pango_layout_set_ellipsize(layoutCopy, PANGO_ELLIPSIZE_NONE);
			pango_layout_set_width(layoutCopy, parentW * PANGO_SCALE);
			pango_layout_set_height(layoutCopy, -1);
			int textW, textH;
			pango_layout_get_size(layoutCopy, &textW, &textH);
			textH = textH / PANGO_SCALE;
			if (textH <= parentH)
			{
				return;
			}
		}

		m_IsScrollStartFlag = true;

		// if multi-line, set to single-line
		if (!clutter_text_get_single_line_mode(m_text))
		{
			m_preScrollStartMultiLineFlag = true;
			EnableMultiLine(false);
		}
		// if enable ellipsize, disable ellipsize
		if (m_enableEllipsize)
		{
			m_preScrollStartEllipsisFlag = true;
			EnableEllipsize(false);
		}

		gboolean flag = clutter_actor_has_allocation(CLUTTER_ACTOR(m_text));
		float ori_x = clutter_actor_get_x(CLUTTER_ACTOR(m_text));
		float ori_y = clutter_actor_get_y(CLUTTER_ACTOR(m_text));

		clutter_text_set_line_alignment(m_text, PANGO_ALIGN_LEFT);
		clutter_actor_set_layout_manager(CLUTTER_ACTOR(m_text), NULL);
		clutter_actor_set_x_expand(CLUTTER_ACTOR(m_text), FALSE);
		clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_START);
		clutter_actor_set_y_expand(CLUTTER_ACTOR(m_text), FALSE);
		clutter_actor_set_y_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_START);
		
		if (!flag)
		{
			clutter_actor_set_position(CLUTTER_ACTOR(m_text), m_textAllocationBox.x1, m_textAllocationBox.y1);
		}
		else
		{
			clutter_actor_set_position(CLUTTER_ACTOR(m_text), ori_x, ori_y);
		}
		
		if (!m_textScroll == NULL)
		{
			clutter_actor_destroy(m_textScroll);
			m_textScroll = NULL;
		}
		m_textScroll = clutter_text_scroll_new(CLUTTER_ACTOR(m_text), t_actor);

		clutter_text_scroll_set_duration(CLUTTER_TEXT_SCROLL(m_textScroll), m_animationScrollAttr.duration);
		clutter_text_scroll_set_delay(CLUTTER_TEXT_SCROLL(m_textScroll), m_animationScrollAttr.delay);
		clutter_text_scroll_set_repeat_count(CLUTTER_TEXT_SCROLL(m_textScroll), m_animationScrollAttr.repeat);
		clutter_text_scroll_set_scroll_type(CLUTTER_TEXT_SCROLL(m_textScroll), m_animationScrollAttr.type);
		clutter_text_scroll_set_direction(CLUTTER_TEXT_SCROLL(m_textScroll), m_animationScrollAttr.direction);
		if (m_animationScrollAttr.type == CLUTTER_TEXT_SCROLL_CONTINUOUS_SCROLL)
		{
			clutter_text_scroll_set_continuous_scroll_gap(CLUTTER_TEXT_SCROLL(m_textScroll), m_animationScrollAttr.continueGap);
		}
		else
		{
			clutter_text_scroll_set_continuous_scroll_gap(CLUTTER_TEXT_SCROLL(m_textScroll), 0);
		}

		clutter_text_scroll_start(CLUTTER_TEXT_SCROLL(m_textScroll));
	}

	void CText::StopScrollText(void)
	{
		if (m_textScroll == NULL)
		{
			return;
		}

		if (m_hasScrollStartFlag)
		{
			m_hasScrollStartFlag = false;
		}

		if (!m_IsScrollStartFlag)
		{
			return;
		}
		else
		{
			m_IsScrollStartFlag = false;
		}

		clutter_text_scroll_stop(CLUTTER_TEXT_SCROLL(m_textScroll));

		clutter_actor_set_layout_manager(CLUTTER_ACTOR(m_text), m_textLayout);
		clutter_actor_set_x_expand(CLUTTER_ACTOR(m_text), TRUE);
		clutter_actor_set_y_expand(CLUTTER_ACTOR(m_text), TRUE);
		clutter_actor_set_position(CLUTTER_ACTOR(m_text), 0, 0);

		SetTextAlignment(m_hAlignment, m_vAlignment);

		
		// if enable ellipsize, disable ellipsize
		if (m_preScrollStartEllipsisFlag)
		{
			m_preScrollStartEllipsisFlag = false;
			EnableEllipsize(true);
		}

		// if multi-line, set to single-line
		if (m_preScrollStartMultiLineFlag)
		{
			m_preScrollStartMultiLineFlag = false;
			EnableMultiLine(true);
		}

		gboolean hasClip = clutter_actor_has_clip(t_actor);
		if (hasClip)
		{
			clutter_actor_remove_clip(t_actor);
		}
	}

	void CText::SetText(const char* text)
	{
		bool savedScrollFlag = m_hasScrollStartFlag;
		if (m_hasScrollStartFlag)
		{
			StopScrollText();
		}
		m_hasScrollStartFlag = savedScrollFlag;

		clutter_text_set_text(m_text, text);

		m_updateTextSize();
		
		if (m_pangoAttrState > 0)
		{
			m_updateTextAttribute();
		}

		if (m_hasScrollStartFlag)
		{
			StartScrollText();
		}
	}

	const char* CText::Text(void)
	{
		return clutter_text_get_text(m_text);
	}

	void CText::SetTextColor(const ClutterColor& color)
	{
		clutter_text_set_color(m_text, &color);
	}

	const ClutterColor& CText::TextColor(void)
	{
		clutter_text_get_color(m_text, &m_textColor);
		return m_textColor;
	}

	void CText::SetFont(const char* font)
	{
		//ASSERT(font != NULL);

		//if font is null, use default font
		if (font != NULL)
		{
			clutter_text_set_font_name(m_text, font);
		}
		else
		{
			clutter_text_set_font_name(m_text, FONT_DEFAULT);
		}	
		m_updateTextSize();
	}

	const char* CText::Font(void)
	{
		return clutter_text_get_font_name(m_text);
	}

	void CText::SetTextAlignment(EHAlignment hAlign, EVAlignment vAlign)
	{
		if (!clutter_actor_get_x_expand(CLUTTER_ACTOR(m_text)))
		{
			clutter_actor_set_x_expand(CLUTTER_ACTOR(m_text), TRUE);
		}

		if (!clutter_actor_get_y_expand(CLUTTER_ACTOR(m_text)))
		{
			clutter_actor_set_y_expand(CLUTTER_ACTOR(m_text), TRUE);
		}

		float parentW = this->getWidth();
		float textW = clutter_actor_get_width(CLUTTER_ACTOR(m_text));

		gfloat pivot_x = 0;
		gfloat pivot_y = 0;
		switch(hAlign)
		{
		case HALIGN_LEFT:
			clutter_text_set_line_alignment(m_text, PANGO_ALIGN_LEFT);
			if (clutter_text_get_single_line_mode(m_text))
			{
				if (textW >= parentW)
				{
					clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_FILL);
				}
				else
				{
					clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_START);
				}
			}
			else
			{
				clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_FILL);
			}
			pivot_x = 0;
			break;
		case HALIGN_CENTER:
			clutter_text_set_line_alignment(m_text, PANGO_ALIGN_CENTER);
			if (clutter_text_get_single_line_mode(m_text))
			{
				if (textW >= parentW)
				{
					clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_FILL);
				}
				else
				{
					clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_CENTER);
				}
			}
			else
			{
				clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_FILL);
			}
			pivot_x = 0.5;
			break;
		case HALIGN_RIGHT:
			clutter_text_set_line_alignment(m_text, PANGO_ALIGN_RIGHT);
			if (clutter_text_get_single_line_mode(m_text))
			{
				if (textW >= parentW)
				{
					clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_FILL);
				}
				else
				{
					clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_END);
				}
			}
			else
			{
				clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_FILL);
			}
			pivot_x = 1.0;
			break;
		default:
			ASSERT(0 && "Invalide HAlignment Parameter");
			break;
		}
		m_hAlignment = hAlign;

		switch(vAlign)
		{
		case VALIGN_TOP:
			clutter_actor_set_y_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_START);
			pivot_y = 0;
			break;
		case VALIGN_MIDDLE:
			clutter_actor_set_y_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_CENTER);
			pivot_y = 0.5;
			break;
		case VALIGN_BOTTOM:
			clutter_actor_set_y_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_END);
			pivot_y = 1.0;
			break;
		default:
			ASSERT(0 && "Invalide VAlignment Parameter");
			break;
		}
		m_vAlignment = vAlign;
		clutter_actor_set_pivot_point(CLUTTER_ACTOR(m_text), pivot_x, pivot_y);

		if (!clutter_text_get_single_line_mode(m_text) && m_rowGap > 0)
		{// when row gap is > 0, text layout will resize it.
			float parentW = this->getWidth();

			PangoLayout* layout = clutter_text_get_layout(m_text);
			pango_layout_set_spacing(layout, m_rowGap * PANGO_SCALE);
			pango_layout_set_width(layout, int(parentW * PANGO_SCALE));
			int pw, ph;
			pango_layout_get_size(layout, &pw, &ph);

			clutter_actor_set_width(CLUTTER_ACTOR(m_text), parentW);
			clutter_actor_set_height(CLUTTER_ACTOR(m_text), float(ph / PANGO_SCALE));
		}
	}

	void CText::EnableMultiLine(bool flagMultiLineMode)
	{
		if (!clutter_text_get_single_line_mode(m_text) == flagMultiLineMode)
		{
			return;
		}
		clutter_text_set_single_line_mode(m_text, !flagMultiLineMode);

		if (!flagMultiLineMode)
		{
			clutter_text_set_line_wrap(m_text, FALSE);
		}
		else
		{
			clutter_text_set_line_wrap(m_text, TRUE);
			clutter_text_set_line_wrap_mode(m_text, PANGO_WRAP_WORD_CHAR);
		}

		m_updateTextSize();
	}

	bool CText::IsMultiLineEnabled(void)
	{
		return !clutter_text_get_single_line_mode(m_text);
	}

	void CText::SetRowGap(int gap)
	{
		m_rowGap = gap;
		
		if (!clutter_text_get_single_line_mode(m_text) && m_rowGap > 0)
		{
			float parentW = this->getWidth();
			PangoLayout* layout = clutter_text_get_layout(m_text);
			pango_layout_set_spacing(layout, gap * PANGO_SCALE);

			if (!m_enableEllipsize)
			{
				int pw, ph;
				pango_layout_get_size(layout, &pw, &ph);
				clutter_actor_set_width(CLUTTER_ACTOR(m_text), parentW);
				clutter_actor_set_height(CLUTTER_ACTOR(m_text), (gfloat)(ph / PANGO_SCALE));
			}
			else
			{
				pango_layout_set_ellipsize(layout, PANGO_ELLIPSIZE_NONE);
				int pw, ph;
				pango_layout_get_size(layout, &pw, &ph);
				
				pango_layout_set_ellipsize(layout, PANGO_ELLIPSIZE_END);
				pango_layout_set_width(layout, int(parentW * PANGO_SCALE));
				pango_layout_set_height(layout, ph);

				clutter_actor_set_width(CLUTTER_ACTOR(m_text), parentW);
				clutter_actor_set_height(CLUTTER_ACTOR(m_text), float(ph / PANGO_SCALE));
			}
		}
	}

	int CText::RowGap(void)
	{
		return m_rowGap;
	}

	void CText::SetMaxTextCount(int textCount)
	{
		clutter_text_set_max_length(m_text, (gint)textCount);
	}

	int CText::MaxTextCount(void)
	{
		return clutter_text_get_max_length(m_text);
	}

	void CText::SetFontSize(int size)
	{
		ASSERT(size > 0);
		PangoFontDescription *fontdes = pango_font_description_from_string(clutter_text_get_font_name(m_text));
		gboolean absoluteFlag = pango_font_description_get_size_is_absolute(fontdes);
		if (!absoluteFlag)
		{
			pango_font_description_set_size(fontdes, (gint)size *PANGO_SCALE);
		}
		else
		{
			pango_font_description_set_absolute_size(fontdes, size * PANGO_SCALE);
		}
		clutter_text_set_font_description(m_text, fontdes);
		pango_font_description_free(fontdes);
		m_fontSize = size;

		m_updateTextSize();
	}

	int CText::FontSize(void)
	{
		PangoFontDescription *fontdes = pango_font_description_from_string(clutter_text_get_font_name(m_text));
		int size = pango_font_description_get_size(fontdes) / PANGO_SCALE;
		pango_font_description_free(fontdes);
		return size;
	}

	void CText::GetTextAlignment(EHAlignment& hAlign, EVAlignment& vAlign)
	{
		hAlign = m_hAlignment;
		vAlign = m_vAlignment;
	}

	void CText::EnableShadow(bool flagEnable)
	{
		if(!m_shadowAttr.shadowFlag && flagEnable)
		{
			m_shadowAttr.shadowFlag = true;
			m_shadowPaintId = g_signal_connect(CLUTTER_ACTOR(m_text), "paint", G_CALLBACK(m_shadow_text_paint), this);
		}

		if(m_shadowAttr.shadowFlag && !flagEnable)
		{
			m_shadowAttr.shadowFlag = false;
			g_signal_handler_disconnect(CLUTTER_ACTOR(m_text), m_shadowPaintId);
		}
		clutter_actor_queue_relayout(CLUTTER_ACTOR(m_text));
	}

	bool CText::IsShadowEnabled(void)
	{
		return m_shadowAttr.shadowFlag;
	}

	void CText::SetShadowPosition(int x, int y)
	{
		m_shadowAttr.shadowXPos = x;
		m_shadowAttr.shadowYPos = y;
	}

	void CText::GetShadowPosition(int& x, int& y)
	{
		x = m_shadowAttr.shadowXPos;
		y = m_shadowAttr.shadowYPos;
	}

	void CText::SetShadowColor(int r, int g, int b, int a)
	{
		clutter_color_init(&m_shadowAttr.shadowColor, (guint8)r, (guint8)g, (guint8)b, (guint8)a);
	}

	void CText::SetShadowColor(ClutterColor color)
	{
		m_shadowAttr.shadowColor = color;
	}

	void CText::GetShadowColor(int& r, int& g, int& b, int& a)
	{
		a = m_shadowAttr.shadowColor.alpha;
		r = m_shadowAttr.shadowColor.red;
		g = m_shadowAttr.shadowColor.green;
		b = m_shadowAttr.shadowColor.blue;
	}

	const ClutterColor& CText::ShadowColor(void)
	{
		return m_shadowAttr.shadowColor;
	}

	void CText::m_shadow_text_paint (ClutterActor *actor, gpointer user_data)
	{
		CText* pThis = (CText*)user_data;
		PangoLayout *layout;
		CoglColor color;
		
		/* Get the PangoLayout that the Text actor is going to paint */
		layout = clutter_text_get_layout (pThis->m_text);
		float parentW = pThis->getWidth();
		if (clutter_text_get_single_line_mode(pThis->m_text))
		{
			float width = (float)pango_layout_get_width(layout) / PANGO_SCALE;

			if (pThis->m_enableEllipsize)
			{
				if (width > parentW)
				{
					pango_layout_set_width(layout, (int)parentW * PANGO_SCALE);
				}
			}
			else
			{
				pango_layout_set_width(layout, -1);
			}
		}

		/* Create a #ccc color and premultiply it */
		cogl_color_init_from_4ub (&color, pThis->m_shadowAttr.shadowColor.red, pThis->m_shadowAttr.shadowColor.green, pThis->m_shadowAttr.shadowColor.blue, pThis->m_shadowAttr.shadowColor.alpha);
		cogl_color_premultiply (&color);

		/* Finally, render the Text layout at a given offset using the color */
		cogl_pango_render_layout (layout, pThis->m_shadowAttr.shadowXPos, pThis->m_shadowAttr.shadowYPos, &color, 0);
	}

	ClutterText* CText::TextActor(void)
	{
		return m_text;
	}

	void CText::SetPosition(float x, float y)
	{
		clutter_actor_set_position(t_actor, (gfloat)x, (gfloat)y);
	}

	void CText::Resize(float width, float height)
	{
		if (clutter_text_get_single_line_mode(m_text))
		{
			clutter_actor_set_size(CLUTTER_ACTOR(m_text), -1, -1);
		}
		else
		{
			clutter_actor_set_size(CLUTTER_ACTOR(m_text), (gfloat)width, -1);
		}
		CActor::Resize(width, height);
	}

	void CText::EnableEllipsize(bool flagEnable)
	{
		if (m_enableEllipsize == flagEnable)
		{
			return;
		}

		m_enableEllipsize = flagEnable;
		float parentW, parentH;
		this->GetSize(parentW, parentH);
		float width = clutter_actor_get_width(CLUTTER_ACTOR(m_text));
		float height = clutter_actor_get_height(CLUTTER_ACTOR(m_text));

		if (m_enableEllipsize)
		{
			if (!clutter_text_get_single_line_mode(m_text) && m_rowGap > 0)
			{
				clutter_text_set_ellipsize(m_text, PANGO_ELLIPSIZE_END);

				PangoLayout* layout = clutter_text_get_layout(m_text);
				pango_layout_set_spacing(layout, m_rowGap * PANGO_SCALE);

				pango_layout_set_width(layout, int(parentW * PANGO_SCALE));
				int pw, ph;
				pango_layout_get_size(layout, &pw, &ph);

				clutter_actor_set_width(CLUTTER_ACTOR(m_text), parentW);
				clutter_actor_set_height(CLUTTER_ACTOR(m_text), float(ph / PANGO_SCALE));

				return;
			}

			if (clutter_text_get_single_line_mode(m_text))
			{
				if (width >= parentW)
				{
					clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_FILL);
				}
				else
				{
					if (m_hAlignment == HALIGN_LEFT)
					{
						clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_START);
					}
					else if (m_hAlignment == HALIGN_CENTER)
					{
						clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_CENTER);
					}
					else if (m_hAlignment == HALIGN_RIGHT)
					{
						clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_END);
					}
				}
			}

			if (width > parentW)
			{
				clutter_actor_set_width(CLUTTER_ACTOR(m_text), parentW);
			}

			if (height > parentH)
			{
				clutter_actor_set_height(CLUTTER_ACTOR(m_text), parentH);
			}
			clutter_text_set_ellipsize(m_text, PANGO_ELLIPSIZE_END);
		}
		else
		{
			if (clutter_text_get_single_line_mode(m_text))
			{
				gboolean flag = clutter_actor_has_allocation(CLUTTER_ACTOR(m_text));
				if (flag)
				{
					clutter_actor_get_allocation_box(CLUTTER_ACTOR(m_text), &m_textAllocationBox);
				}

				ClutterActorAlign xAlign = clutter_actor_get_x_align(CLUTTER_ACTOR(m_text));
				if (xAlign == CLUTTER_ACTOR_ALIGN_FILL)
				{
					clutter_actor_set_x_expand(CLUTTER_ACTOR(m_text), FALSE);
					clutter_actor_set_size(CLUTTER_ACTOR(m_text), -1, -1);
					clutter_actor_set_x_expand(CLUTTER_ACTOR(m_text), TRUE);
				}
				else
				{
					clutter_actor_set_size(CLUTTER_ACTOR(m_text), -1, -1);
				}
				
				int textW = clutter_actor_get_width(CLUTTER_ACTOR(m_text));
				if (textW >= parentW)
				{
					clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_FILL);
				}
				else
				{
					if (m_hAlignment == HALIGN_LEFT)
					{
						clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_START);
					}
					else if (m_hAlignment == HALIGN_CENTER)
					{
						clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_CENTER);
					}
					else if (m_hAlignment == HALIGN_RIGHT)
					{
						clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_END);
					}
				}
			}
			else
			{
				if (!clutter_text_get_single_line_mode(m_text) && m_rowGap > 0)
				{
					clutter_text_set_ellipsize(m_text, PANGO_ELLIPSIZE_NONE);

					PangoLayout* layout = clutter_text_get_layout(m_text);
					pango_layout_set_spacing(layout, m_rowGap * PANGO_SCALE);
					
					pango_layout_set_width(layout, int(parentW * PANGO_SCALE));
					int pw, ph;
					pango_layout_get_size(layout, &pw, &ph);

					clutter_actor_set_width(CLUTTER_ACTOR(m_text), parentW);
					clutter_actor_set_height(CLUTTER_ACTOR(m_text), float(ph / PANGO_SCALE));
					return;
				}

				if (width > parentW)
				{
					clutter_actor_set_width(CLUTTER_ACTOR(m_text), parentW);
				}

				if (height > parentH)
				{
					clutter_actor_set_height(CLUTTER_ACTOR(m_text), parentH);
				}
			}
			clutter_text_set_ellipsize(m_text, PANGO_ELLIPSIZE_NONE);
		}
	}

	bool CText::IsEllipsizeEnable()
	{
		return m_enableEllipsize;
	}

	void CText::m_updateTextSize()
	{
		float parentW, parentH;
		this->GetSize(parentW, parentH);
		
		if (!clutter_text_get_single_line_mode(m_text))
		{
			if (m_rowGap == 0)
			{
				clutter_actor_set_width(CLUTTER_ACTOR(m_text), parentW);
				clutter_actor_set_height(CLUTTER_ACTOR(m_text), -1);
			}
			else if (m_rowGap > 0)
			{
				PangoLayout* layout = clutter_text_get_layout(m_text);
				pango_layout_set_spacing(layout, m_rowGap * PANGO_SCALE);
				if (!m_enableEllipsize)
				{
					pango_layout_set_width(layout, int(parentW * PANGO_SCALE));
					int pw, ph;
					pango_layout_get_size(layout, &pw, &ph);

					clutter_actor_set_width(CLUTTER_ACTOR(m_text), parentW);
					clutter_actor_set_height(CLUTTER_ACTOR(m_text), float(ph / PANGO_SCALE));
				}
				else
				{
					pango_layout_set_ellipsize(layout, PANGO_ELLIPSIZE_NONE);
					pango_layout_set_width(layout, int(parentW * PANGO_SCALE));
					int pw, ph;
					pango_layout_get_size(layout, &pw, &ph);

					pango_layout_set_ellipsize(layout, PANGO_ELLIPSIZE_END);
					pango_layout_set_width(layout, int(parentW * PANGO_SCALE));
					pango_layout_set_height(layout, ph);

					clutter_actor_set_width(CLUTTER_ACTOR(m_text), parentW);
					clutter_actor_set_height(CLUTTER_ACTOR(m_text), float(ph / PANGO_SCALE));
				}
			}

			clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_FILL);
		}
		else
		{
			clutter_actor_get_allocation_box(CLUTTER_ACTOR(m_text), &m_textAllocationBox);
			
			ClutterActorAlign xAlign = clutter_actor_get_x_align(CLUTTER_ACTOR(m_text));
			if (xAlign == CLUTTER_ACTOR_ALIGN_FILL)
			{
				clutter_actor_set_x_expand(CLUTTER_ACTOR(m_text), FALSE);
				clutter_actor_set_size(CLUTTER_ACTOR(m_text), -1, -1);
				clutter_actor_set_x_expand(CLUTTER_ACTOR(m_text), TRUE);
			}
			else
			{
				clutter_actor_set_size(CLUTTER_ACTOR(m_text), -1, -1);
			}

			float textW = clutter_actor_get_width(CLUTTER_ACTOR(m_text));
			if (textW >= parentW)
			{
				clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_FILL);
			}
			else
			{
				if (m_hAlignment == HALIGN_LEFT)
				{
					clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_START);
				}
				else if (m_hAlignment == HALIGN_CENTER)
				{
					clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_CENTER);
				}
				else if (m_hAlignment == HALIGN_RIGHT)
				{
					clutter_actor_set_x_align(CLUTTER_ACTOR(m_text), CLUTTER_ACTOR_ALIGN_END);
				}
			}
		}
	}

	bool CText::SetCharFormat(T_STYLE style)
	{
		m_pangoAttrState = (int)style;
		m_updateTextAttribute();
		return true;
	}

	void CText::m_updateTextAttribute()
	{
		if (m_pangoAttrList != NULL)
		{
			pango_attr_list_unref(m_pangoAttrList);
			m_pangoAttrList = NULL;
		}
		
		int textLen = strlen(clutter_text_get_text(m_text));

		if (m_pangoAttrState == STYLE_BOLD)
		{
			m_pangoAttrList = pango_attr_list_new();

			PangoAttribute* attr_Bold = pango_attr_weight_new(PANGO_WEIGHT_BOLD);
			attr_Bold->start_index = 0;
			attr_Bold->end_index = textLen;
			pango_attr_list_insert(m_pangoAttrList, attr_Bold);
			clutter_text_set_attributes(m_text, m_pangoAttrList);
		}
		else if (m_pangoAttrState == STYLE_ITALIC)
		{
			m_pangoAttrList = pango_attr_list_new();

			PangoAttribute* attr_Italic = pango_attr_style_new(PANGO_STYLE_ITALIC);
			attr_Italic->start_index = 0;
			attr_Italic->end_index = textLen;
			pango_attr_list_insert(m_pangoAttrList, attr_Italic);
			clutter_text_set_attributes(m_text, m_pangoAttrList);
		}
		else if (m_pangoAttrState == STYLE_UNDERLINE)
		{
			m_pangoAttrList = pango_attr_list_new();

			PangoAttribute* attr_UnderLine = pango_attr_underline_new(PANGO_UNDERLINE_SINGLE);
			attr_UnderLine->start_index = 0;
			attr_UnderLine->end_index = textLen;
			pango_attr_list_insert(m_pangoAttrList, attr_UnderLine);
			clutter_text_set_attributes(m_text, m_pangoAttrList);
		}
		else if (m_pangoAttrState == STYLE_NONE)
		{
			clutter_text_set_attributes(m_text, NULL);
		}
	}

	float CText::PreferredHeight(float width)
	{
		float minHeight;
		clutter_actor_get_preferred_height(CLUTTER_ACTOR(m_text), width, &minHeight, NULL);
		return minHeight;
	}

	const char* CText::GetActorType(void)
	{
		return "Text";
	}
	
	int CText::LineCount(void)
	{
		int count = 0;
		PangoLayout* layout = clutter_text_get_layout(m_text);
		count = pango_layout_get_line_count(layout);
		return count;
	}

	int CText::LineHeight(int index)
	{
		PangoLayout* layout = clutter_text_get_layout(m_text);
		int count = pango_layout_get_line_count(layout);
		if (index >= count)
		{
			return 0;
		}
		PangoLayoutLine* line = pango_layout_get_line(layout, index);
		PangoRectangle rect_ink = { 0 };
		PangoRectangle rect_logic = { 0 };
		pango_layout_line_get_extents(line, &rect_ink, &rect_logic);
		return rect_logic.height / PANGO_SCALE;
	}
	/* namespace UIElements */

}

