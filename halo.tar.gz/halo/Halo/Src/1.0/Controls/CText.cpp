#include "Halo1_0.h"

#define FONT_DEFAULT "Sans 20px"
namespace HALO
{
	static HALO::util::Logger LOGGER("CText");
	CText::CText()
	{
		// TODO Auto-generated constructor stub
		m_shadowAttr.shadowFlag = false;
		clutter_color_init(&m_shadowAttr.shadowColor, 0, 0, 0, 0);
		m_shadowAttr.shadowXPos = 0;
		m_shadowAttr.shadowYPos = 0;
		m_shadowPaintId = 0;
		m_hAlignment = HALIGN_LEFT;
		m_vAlignment = VALIGN_TOP;
		m_fontSize = 0;
		m_enableEllipsize = false;

		m_animationScaleAttr.scaled_size = 30;
		m_animationScaleAttr.duration = 200;
		m_animationScaleAttr.delay = 20;
		m_animationScaleAttr.ani_mode = CLUTTER_LINEAR;

		m_animationScrollAttr.type = CLUTTER_TEXT_SCROLL_START_OUTSIDE_STOP_OUTSIDE;
		m_animationScrollAttr.direction = CLUTTER_TIMELINE_BACKWARD;
		m_animationScrollAttr.delay = 500;
		m_animationScrollAttr.duration = 5000;
		m_animationScrollAttr.speed = 0.1f;
		m_animationScrollAttr.repeat = 1;
		m_animationScrollAttr.continueGap = 0;
		m_textScale = NULL;
		m_textScroll = NULL;
		m_text = NULL;
		m_pangoAttrList = NULL;
		m_pangoAttrState = 0;
		m_rowGap = 0;

		m_IsScrollStartFlag = false;
		m_truthMultiLineFlag = false;
		m_truthEllipsizeFlag = false;
		m_truthHasStartScrollFlag = false;
	}

	CText::~CText()
	{
		// TODO Auto-generated destructor stub
		if (m_shadowPaintId)
		{
			g_signal_handler_disconnect(CLUTTER_ACTOR(m_text), m_shadowPaintId);
		}
		if (m_textScale != NULL)
		{
			clutter_actor_destroy(CLUTTER_ACTOR(m_textScale));
			m_textScale = NULL;
		}
		if (m_textScroll != NULL)
		{
			clutter_actor_destroy(m_textScroll);
			m_textScroll = NULL;
		}
		if (m_text != NULL)
		{
			clutter_actor_destroy(CLUTTER_ACTOR(m_text));
			m_text = NULL;
		}
		if (m_pangoAttrList != NULL)
		{
			pango_attr_list_unref(m_pangoAttrList);
			m_pangoAttrList = NULL;
		}
	}

	bool CText::Initialize(IActor *parent, float width, float height)
	{
		Widget *cParent = dynamic_cast<Widget*>(parent);

		return Initialize(cParent, width, height);
	}

	bool CText::Initialize(Widget *parent, float width, float height)
	{
		CActor::Initialize(parent, width, height);
		m_text = (ClutterText*)clutter_text_new();
		clutter_actor_add_child(t_actor, CLUTTER_ACTOR(m_text));
		clutter_text_set_editable(m_text, FALSE);
		clutter_text_set_single_line_mode(m_text, TRUE);
		if (height != -1)
		{
			clutter_actor_set_clip_to_allocation(t_actor, TRUE);
		}
		
		std::string str = FONT_DEFAULT;
		std::string fontName = t_CurentToMultiResolution(str);
		clutter_text_set_font_name(m_text, fontName.c_str());
		m_fontSize = FontSize();

		t_orientation = Orientation(true);
			
		return true;
	}

	void CText::SetScaleAttribute(guint scaled_size, guint duration, guint delay, ClutterAnimationMode ani_mode)
	{
		HALO_ASSERT((int)scaled_size >= 0);
		HALO_ASSERT((int)duration >= 0);
		HALO_ASSERT((int)delay >= 0);

		H_LOG_TRACE(LOGGER, "[" << this << "], scaled_size = " << scaled_size << ", duration = " << duration << ", delay = " << delay << ", ani_mode = " << ani_mode << ".***");

		m_animationScaleAttr.scaled_size = scaled_size;
		m_animationScaleAttr.duration = duration;
		m_animationScaleAttr.delay = delay;
		m_animationScaleAttr.ani_mode = ani_mode;

		if (m_textScale != NULL)
		{
			clutter_actor_destroy(CLUTTER_ACTOR(m_textScale));
			m_textScale = NULL;
		}
		m_textScale = clutter_text_scaling_animation_group_new_full( m_animationScaleAttr.scaled_size, m_animationScaleAttr.duration, m_animationScaleAttr.delay, m_animationScaleAttr.ani_mode);		
		clutter_text_scaling_animation_add_actor_in_group(m_textScale, CLUTTER_TEXT(m_text));

		m_updateTextSize();
	}

	void CText::SetScaleSize(guint scale_size)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "], scale_size = " << scale_size << ".***");

		m_animationScaleAttr.scaled_size = scale_size;
		clutter_text_scaling_animation_set_scaled_size(CLUTTER_TEXT_SCALING_ANIMATION(m_textScale), m_animationScaleAttr.scaled_size);
	}

	void CText::StartScaleText()
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");

		clutter_text_scaling_animation_set_scaled_size(CLUTTER_TEXT_SCALING_ANIMATION(m_textScale), m_animationScaleAttr.scaled_size);
		clutter_text_scaling_animation_start(CLUTTER_TEXT_SCALING_ANIMATION(m_textScale));

		m_updateTextSize();
	}

	void CText::StopScaleText()
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");

		clutter_text_scaling_animation_set_scaled_size(CLUTTER_TEXT_SCALING_ANIMATION(m_textScale), m_fontSize);
		clutter_text_scaling_animation_start(CLUTTER_TEXT_SCALING_ANIMATION(m_textScale));

		m_updateTextSize();
	}

	void CText::SetScrollAttribute(guint duration, gfloat speed, guint delay, gint repeat, ClutterTextScrollType type, ClutterTimelineDirection direction, guint continueGap)
	{
		m_animationScrollAttr.duration = duration;
		m_animationScrollAttr.speed = speed;
		m_animationScrollAttr.delay = delay;
		m_animationScrollAttr.repeat = repeat;
		m_animationScrollAttr.type = type;
		m_animationScrollAttr.direction = direction;
		m_animationScrollAttr.continueGap = continueGap;
	}

	void CText::GetScrollAttribute(guint& duration, gfloat& speed, guint& delay, gint& repeat, ClutterTextScrollType& type, ClutterTimelineDirection& direction, guint& continueGap)
	{
		duration = m_animationScrollAttr.duration;
		speed = m_animationScrollAttr.speed;
		delay = m_animationScrollAttr.delay;
		repeat = m_animationScrollAttr.repeat;
		type = m_animationScrollAttr.type;
		direction = m_animationScrollAttr.direction;
		continueGap = m_animationScrollAttr.continueGap;
	}

	void CText::StartScrollText(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		if (m_truthHasStartScrollFlag)
		{
			return;
		}
		m_truthHasStartScrollFlag = true;
		m_startScrollText();
	}

	void CText::m_startScrollText(void)
	{
		PangoLayout *layoutCopy = pango_layout_copy(clutter_text_get_layout(m_text));
		int parentW = (int)this->getWidth();
		int parentH = (int)this->getHeight();
		H_LOG_TRACE(LOGGER, "[" << this << "] ---parentW = ( " << parentW << " ), parentH = ( " << parentH << " )");
		if (clutter_text_get_single_line_mode(m_text))
		{//single-line limit
			pango_layout_set_width(layoutCopy, -1);
			pango_layout_set_height(layoutCopy, -1);
			int textW, textH;
			pango_layout_get_size(layoutCopy, &textW, &textH);
			textW = textW / PANGO_SCALE;
			H_LOG_TRACE(LOGGER, "[" << this << "] ---singleLine textW = ( " << textW << " ) ");
			if (textW <= parentW)
			{
				return;
			}
		}
		else
		{//multi-line limit
			pango_layout_set_ellipsize(layoutCopy, PANGO_ELLIPSIZE_NONE);
			int lineCount = 0;
			lineCount = pango_layout_get_line_count(layoutCopy);
			H_LOG_TRACE(LOGGER, "[" << this << "] ---multiLine lineCount = ( " << lineCount << " )");
			if (lineCount == 1)
			{
				pango_layout_set_width(layoutCopy, -1);
				pango_layout_set_height(layoutCopy, -1);
				int textW, textH;
				pango_layout_get_size(layoutCopy, &textW, &textH);
				textW = textW / PANGO_SCALE;
				H_LOG_TRACE(LOGGER, "[" << this << "] ---multiLine textW = " << textW << ", parentW = " << parentW << "***\n");
				if (textW <= parentW)
				{
					return;
				}
			}
			else
			{
				pango_layout_set_width(layoutCopy, parentW * PANGO_SCALE);
				pango_layout_set_height(layoutCopy, -1);
				int textW, textH;
				pango_layout_get_size(layoutCopy, &textW, &textH);
				textH = textH / PANGO_SCALE;
				H_LOG_TRACE(LOGGER, "[" << this << "] ---multiLine textH = " << textH << ", parentH = " << parentH << "***\n");
				if (textH <= parentH)
				{
					return;
				}
			}
		}

		m_IsScrollStartFlag = true;

		m_enable_MultiLine(false);
		m_enable_Ellipsize(false);
		
		if (m_textScroll != NULL)
		{
			clutter_actor_destroy(m_textScroll);
			m_textScroll = NULL;
		}
		m_textScroll = clutter_text_scroll_new(CLUTTER_ACTOR(m_text), t_actor);

		clutter_text_scroll_set_duration(CLUTTER_TEXT_SCROLL(m_textScroll), m_animationScrollAttr.duration);
		clutter_text_scroll_set_speed(CLUTTER_TEXT_SCROLL(m_textScroll), m_animationScrollAttr.speed);
		clutter_text_scroll_set_delay(CLUTTER_TEXT_SCROLL(m_textScroll), m_animationScrollAttr.delay);
		clutter_text_scroll_set_repeat_count(CLUTTER_TEXT_SCROLL(m_textScroll), m_animationScrollAttr.repeat);
		clutter_text_scroll_set_scroll_type(CLUTTER_TEXT_SCROLL(m_textScroll), m_animationScrollAttr.type);
		clutter_text_scroll_set_direction(CLUTTER_TEXT_SCROLL(m_textScroll), m_animationScrollAttr.direction);
		if (m_animationScrollAttr.type == CLUTTER_TEXT_SCROLL_CONTINUOUS_SCROLL)
		{
			clutter_text_scroll_set_continuous_scroll_gap(CLUTTER_TEXT_SCROLL(m_textScroll), m_animationScrollAttr.continueGap);
		}
		else
		{
			clutter_text_scroll_set_continuous_scroll_gap(CLUTTER_TEXT_SCROLL(m_textScroll), 0);
		}

		clutter_text_scroll_start(CLUTTER_TEXT_SCROLL(m_textScroll));
	}

	void CText::StopScrollText(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		m_truthHasStartScrollFlag = false;
		m_stopScrollText();
	}

	void CText::m_stopScrollText(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		if (m_textScroll == NULL)
		{
			return;
		}

		if (!m_IsScrollStartFlag)
		{
			return;
		}
		else
		{
			m_IsScrollStartFlag = false;
		}

		clutter_text_scroll_stop(CLUTTER_TEXT_SCROLL(m_textScroll));

		m_updateTextSize();
		
		if (m_truthEllipsizeFlag)
		{
			m_enable_Ellipsize(true);
		}
		else
		{
			m_enable_Ellipsize(false);
		}

		if (m_truthMultiLineFlag)
		{
			m_enable_MultiLine(true);
		}
		else
		{
			m_enable_MultiLine(false);
		}

		gboolean hasClip = clutter_actor_has_clip(t_actor);
		if (hasClip)
		{
			clutter_actor_remove_clip(t_actor);
		}
	}

	void CText::SetText(const char* text)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] CText::SetText (" << text << ") \n");
		if (strcmp(clutter_text_get_text(m_text), text) == 0)
		{
			return;
		}

		if (m_truthHasStartScrollFlag)
		{
			m_stopScrollText();
		}

		clutter_text_set_text(m_text, text);
		
		if (m_pangoAttrState > 0)
		{
			m_updateTextAttribute();
		}

		m_updateTextSize();

		if (m_truthHasStartScrollFlag)
		{
			m_startScrollText();
		}
	}

	const char* CText::Text(void)
	{
		return clutter_text_get_text(m_text);
	}

	void CText::SetTextColor(const ClutterColor& color)
	{
		clutter_text_set_color(m_text, &color);
	}

	const ClutterColor& CText::TextColor(void)
	{
		clutter_text_get_color(m_text, &m_textColor);
		return m_textColor;
	}

	void CText::SetFont(const char* font)
	{		
		if (font == NULL)
		{
			//if font is null, use default font
			std::string str = FONT_DEFAULT;
			m_font = t_CurentToMultiResolution(str);
			clutter_text_set_font_name(m_text, m_font.c_str());
			return;
		}

		H_LOG_TRACE(LOGGER, "[" << this << "] CText::SetFont (" << font << ") \n");
		
		if (strcmp(clutter_text_get_font_name(m_text), font) == 0)
		{
			return;
		}

		if (m_truthHasStartScrollFlag)
		{
			m_stopScrollText();
		}

		if (font != NULL)
		{
			std::string str = font;
			m_font = t_CurentToMultiResolution(str);
			clutter_text_set_font_name(m_text, m_font.c_str());
		}
			
		m_updateTextSize();

		if (m_truthHasStartScrollFlag)
		{
			m_startScrollText();
		}
	}

	const char* CText::Font(void)
	{		
		return m_font.c_str();
	}

	void CText::SetTextAlignment(EHAlignment hAlign, EVAlignment vAlign)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] CText::SetTextAlignment  h(" << hAlign << "), " << " v(" << vAlign << ")");
		
		float parentW = this->getWidth();
		float textW = clutter_actor_get_width(CLUTTER_ACTOR(m_text));

		float parentH = this->getHeight();
		float textH = clutter_actor_get_height(CLUTTER_ACTOR(m_text));

		gfloat pivot_x = 0;
		gfloat pivot_y = 0;
		switch(hAlign)
		{
		case HALIGN_LEFT:
			clutter_text_set_line_alignment(m_text, PANGO_ALIGN_LEFT);
			clutter_actor_set_x(CLUTTER_ACTOR(m_text), 0);
			pivot_x = 0;
			break;
		case HALIGN_CENTER:
			clutter_text_set_line_alignment(m_text, PANGO_ALIGN_CENTER);
			if (textW >= parentW)
			{
				clutter_actor_set_x(CLUTTER_ACTOR(m_text), 0);
			}
			else
			{
				gfloat off_x = (parentW - textW) / 2.0f;
				clutter_actor_set_x(CLUTTER_ACTOR(m_text), off_x);
			}
			pivot_x = 0.5;
			break;
		case HALIGN_RIGHT:
			clutter_text_set_line_alignment(m_text, PANGO_ALIGN_RIGHT);
			if (textW >= parentW)
			{
				clutter_actor_set_x(CLUTTER_ACTOR(m_text), 0);
			}
			else
			{
				gfloat off_x = parentW - textW;
				clutter_actor_set_x(CLUTTER_ACTOR(m_text), off_x);
			}
			pivot_x = 1.0;
			break;
		default:
			HALO_ASSERT(0 && "Invalide HAlignment Parameter");
			break;
		}
		m_hAlignment = hAlign;

		switch(vAlign)
		{
		case VALIGN_TOP:
			clutter_actor_set_y(CLUTTER_ACTOR(m_text), 0);
			pivot_y = 0;
			break;
		case VALIGN_MIDDLE:
			if (textH >= parentH)
			{
				clutter_actor_set_y(CLUTTER_ACTOR(m_text), 0);
			}
			else
			{
				gfloat off_y = (parentH - textH) / 2.0f;
				clutter_actor_set_y(CLUTTER_ACTOR(m_text), off_y);
			}
			pivot_y = 0.5;
			break;
		case VALIGN_BOTTOM:
			if (textH >= parentH)
			{
				clutter_actor_set_y(CLUTTER_ACTOR(m_text), 0);
			}
			else
			{
				gfloat off_y = parentH - textH;
				clutter_actor_set_y(CLUTTER_ACTOR(m_text), off_y);
			}
			pivot_y = 1.0;
			break;
		default:
			HALO_ASSERT(0 && "Invalide VAlignment Parameter");
			break;
		}
		m_vAlignment = vAlign;
		clutter_actor_set_pivot_point(CLUTTER_ACTOR(m_text), pivot_x, pivot_y);
	}

	void CText::EnableMultiLine(bool flagMultiLineMode)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] CText::EnableMultiLine (" << flagMultiLineMode << ") \n");
		m_truthMultiLineFlag = flagMultiLineMode;
		m_enable_MultiLine(flagMultiLineMode);
	}

	void CText::m_enable_MultiLine(bool flagMultiLineMode)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] CText::m_enable_MultiLine (" << flagMultiLineMode << ") \n");
		if (!clutter_text_get_single_line_mode(m_text) == flagMultiLineMode)
		{
			return;
		}
		clutter_text_set_single_line_mode(m_text, !flagMultiLineMode);

		if (!flagMultiLineMode)
		{
			clutter_text_set_line_wrap(m_text, FALSE);
		}
		else
		{
			clutter_text_set_line_wrap(m_text, TRUE);
			clutter_text_set_line_wrap_mode(m_text, PANGO_WRAP_WORD_CHAR);
		}

		m_updateTextSize();
	}

	bool CText::IsMultiLineEnabled(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] CText::m_truthMultiLineFlag (" << m_truthMultiLineFlag << ") \n");
		return m_truthMultiLineFlag;
	}

	void CText::SetRowGap(int gap)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] CText::SetRowGap (" << gap << ") \n");
		m_rowGap = gap;
		
		m_updateTextSize();
	}

	int CText::RowGap(void)
	{
		return m_rowGap;
	}

	void CText::SetMaxTextCount(int textCount)
	{
		clutter_text_set_max_length(m_text, (gint)textCount);
	}

	int CText::MaxTextCount(void)
	{
		return clutter_text_get_max_length(m_text);
	}

	void CText::SetFontSize(int size)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] FontSize (" << size << ") \n");
		HALO_ASSERT(size > 0);

		if (m_truthHasStartScrollFlag)
		{
			H_LOG_TRACE(LOGGER, "[" << this << "] stopScrollText()");
			m_stopScrollText();
		}

		size = t_1920ConvertMultiResolution(size);
		
		PangoFontDescription *fontdes = pango_font_description_from_string(clutter_text_get_font_name(m_text));
		gboolean absoluteFlag = pango_font_description_get_size_is_absolute(fontdes);
		if (!absoluteFlag)
		{
			pango_font_description_set_size(fontdes, (gint)size *PANGO_SCALE);
		}
		else
		{
			pango_font_description_set_absolute_size(fontdes, size * PANGO_SCALE);
		}
		clutter_text_set_font_description(m_text, fontdes);
		pango_font_description_free(fontdes);
		m_fontSize = size;

		m_updateTextSize();

		if (m_truthHasStartScrollFlag)
		{
			H_LOG_TRACE(LOGGER, "[" << this << "] startScrollText()");
			m_startScrollText();
		}
	}

	int CText::FontSize(void)
	{
		PangoFontDescription *fontdes = pango_font_description_from_string(clutter_text_get_font_name(m_text));
		int size = pango_font_description_get_size(fontdes) / PANGO_SCALE;
		pango_font_description_free(fontdes);
		size = t_MultiResolutionConvert1920(size);
		
		return size;
	}

	void CText::GetTextAlignment(EHAlignment& hAlign, EVAlignment& vAlign)
	{
		hAlign = m_hAlignment;
		vAlign = m_vAlignment;
	}

	void CText::EnableShadow(bool flagEnable)
	{
		if(!m_shadowAttr.shadowFlag && flagEnable)
		{
			m_shadowAttr.shadowFlag = true;
			m_shadowPaintId = g_signal_connect(CLUTTER_ACTOR(m_text), "paint", G_CALLBACK(m_shadow_text_paint), this);
		}

		if(m_shadowAttr.shadowFlag && !flagEnable)
		{
			m_shadowAttr.shadowFlag = false;
			g_signal_handler_disconnect(CLUTTER_ACTOR(m_text), m_shadowPaintId);
		}
		clutter_actor_queue_relayout(CLUTTER_ACTOR(m_text));
	}

	bool CText::IsShadowEnabled(void)
	{
		return m_shadowAttr.shadowFlag;
	}

	void CText::SetShadowPosition(int x, int y)
	{
		m_shadowAttr.shadowXPos = x;
		m_shadowAttr.shadowYPos = y;
	}

	void CText::GetShadowPosition(int& x, int& y)
	{
		x = m_shadowAttr.shadowXPos;
		y = m_shadowAttr.shadowYPos;
	}

	void CText::SetShadowColor(int r, int g, int b, int a)
	{
		clutter_color_init(&m_shadowAttr.shadowColor, (guint8)r, (guint8)g, (guint8)b, (guint8)a);
	}

	void CText::SetShadowColor(ClutterColor color)
	{
		m_shadowAttr.shadowColor = color;
	}

	void CText::GetShadowColor(int& r, int& g, int& b, int& a)
	{
		a = m_shadowAttr.shadowColor.alpha;
		r = m_shadowAttr.shadowColor.red;
		g = m_shadowAttr.shadowColor.green;
		b = m_shadowAttr.shadowColor.blue;
	}

	const ClutterColor& CText::ShadowColor(void)
	{
		return m_shadowAttr.shadowColor;
	}

	void CText::m_shadow_text_paint (ClutterActor *actor, gpointer user_data)
	{
		CText* pThis = (CText*)user_data;
		PangoLayout *layout;
		CoglColor color;
		
		/* Get the PangoLayout that the Text actor is going to paint */
		layout = clutter_text_get_layout (pThis->m_text);
		float parentW = pThis->getWidth();
		if (clutter_text_get_single_line_mode(pThis->m_text))
		{
			float width = (float)pango_layout_get_width(layout) / PANGO_SCALE;

			if (pThis->m_enableEllipsize)
			{
				if (width > parentW)
				{
					pango_layout_set_width(layout, (int)parentW * PANGO_SCALE);
				}
			}
			else
			{
				pango_layout_set_width(layout, -1);
			}
		}

		/* Create a #ccc color and premultiply it */
		cogl_color_init_from_4ub (&color, pThis->m_shadowAttr.shadowColor.red, pThis->m_shadowAttr.shadowColor.green, pThis->m_shadowAttr.shadowColor.blue, pThis->m_shadowAttr.shadowColor.alpha);
		cogl_color_premultiply (&color);

		/* Finally, render the Text layout at a given offset using the color */
		cogl_pango_render_layout (layout, pThis->m_shadowAttr.shadowXPos, pThis->m_shadowAttr.shadowYPos, &color, 0);
	}

	ClutterText* CText::TextActor(void)
	{
		return m_text;
	}

	void CText::Resize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] CText::Resize w(" << width << "),  h(" << height << ")" );

		if (m_truthHasStartScrollFlag)
		{
			m_stopScrollText();
		}

		CActor::Resize(width, height);

		m_updateTextSize();

		if (m_truthHasStartScrollFlag)
		{
			m_startScrollText();
		}
	}

	void CText::EnableEllipsize(bool flagEnable)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] CText::flagEnable (" << flagEnable << ")\n");
		m_truthEllipsizeFlag = flagEnable;
		m_enable_Ellipsize(flagEnable);
	}

	void CText::m_enable_Ellipsize(bool flagEnable)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] CText::flagEnable (" << flagEnable << ")\n");
		if (m_enableEllipsize == flagEnable)
		{
			return;
		}

		m_enableEllipsize = flagEnable;
		float parentW, parentH;
		this->GetSize(parentW, parentH);
		float width = clutter_actor_get_width(CLUTTER_ACTOR(m_text));
		float height = clutter_actor_get_height(CLUTTER_ACTOR(m_text));

		if (m_enableEllipsize)
		{
			if (width > parentW)
			{
				clutter_actor_set_width(CLUTTER_ACTOR(m_text), parentW);
			}

			if (height > parentH)
			{
				clutter_actor_set_height(CLUTTER_ACTOR(m_text), parentH);
			}
			clutter_text_set_ellipsize(m_text, PANGO_ELLIPSIZE_END);
		}
		else
		{
			if (clutter_text_get_single_line_mode(m_text))
			{
				clutter_actor_set_size(CLUTTER_ACTOR(m_text), -1, -1);
			}
			else
			{
				if (width > parentW)
				{
					clutter_actor_set_width(CLUTTER_ACTOR(m_text), parentW);
				}

				if (height > parentH)
				{
					clutter_actor_set_height(CLUTTER_ACTOR(m_text), parentH);
				}
			}
			clutter_text_set_ellipsize(m_text, PANGO_ELLIPSIZE_NONE);
		}
		m_updateTextPosition();
	}

	bool CText::IsEllipsizeEnable()
	{
		return m_truthEllipsizeFlag;
	}

	void CText::m_updateTextSize()
	{
		float parentW, parentH;
		this->GetSize(parentW, parentH);
		
		// reset rowgap for multiline
		clutter_text_set_ellipsize(m_text, PANGO_ELLIPSIZE_NONE);
		clutter_text_set_layout_spacing(m_text, m_rowGap);
		clutter_text_set_ellipsize(m_text, PANGO_ELLIPSIZE_END);
		
		clutter_actor_set_size(CLUTTER_ACTOR(m_text), -1, -1);
		gfloat textW = clutter_actor_get_width(CLUTTER_ACTOR(m_text));
		gfloat textHT = clutter_actor_get_height(CLUTTER_ACTOR(m_text));

		if (m_truthMultiLineFlag)
		{
			if (textW > parentW)
			{
				clutter_actor_set_width(CLUTTER_ACTOR(m_text), parentW);
				gfloat textH = clutter_actor_get_height(CLUTTER_ACTOR(m_text));
				if (m_truthEllipsizeFlag)
				{
					if (textH > parentH)
					{
						clutter_actor_set_height(CLUTTER_ACTOR(m_text), parentH);
					}
				}
			}
		}
		else
		{
			if (m_truthEllipsizeFlag)
			{
				if (textW > parentW)
				{
					clutter_actor_set_width(CLUTTER_ACTOR(m_text), parentW);
				}
			}
		}

		m_updateTextPosition();
	}

	bool CText::SetCharFormat(T_STYLE style)
	{
		m_pangoAttrState = (int)style;
		m_updateTextAttribute();
		return true;
	}

	void CText::m_updateTextAttribute()
	{
		if (m_pangoAttrList != NULL)
		{
			pango_attr_list_unref(m_pangoAttrList);
			m_pangoAttrList = NULL;
		}
		
		int textLen = strlen(clutter_text_get_text(m_text));

		if (m_pangoAttrState == STYLE_BOLD)
		{
			m_pangoAttrList = pango_attr_list_new();

			PangoAttribute* attr_Bold = pango_attr_weight_new(PANGO_WEIGHT_BOLD);
			attr_Bold->start_index = 0;
			attr_Bold->end_index = textLen;
			pango_attr_list_insert(m_pangoAttrList, attr_Bold);
			clutter_text_set_attributes(m_text, m_pangoAttrList);
		}
		else if (m_pangoAttrState == STYLE_ITALIC)
		{
			m_pangoAttrList = pango_attr_list_new();

			PangoAttribute* attr_Italic = pango_attr_style_new(PANGO_STYLE_ITALIC);
			attr_Italic->start_index = 0;
			attr_Italic->end_index = textLen;
			pango_attr_list_insert(m_pangoAttrList, attr_Italic);
			clutter_text_set_attributes(m_text, m_pangoAttrList);
		}
		else if (m_pangoAttrState == STYLE_UNDERLINE)
		{
			m_pangoAttrList = pango_attr_list_new();

			PangoAttribute* attr_UnderLine = pango_attr_underline_new(PANGO_UNDERLINE_SINGLE);
			attr_UnderLine->start_index = 0;
			attr_UnderLine->end_index = textLen;
			pango_attr_list_insert(m_pangoAttrList, attr_UnderLine);
			clutter_text_set_attributes(m_text, m_pangoAttrList);
		}
		else if (m_pangoAttrState == STYLE_NONE)
		{
			clutter_text_set_attributes(m_text, NULL);
		}

		m_updateTextSize();
	}

	float CText::PreferredHeight(float width)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] CText::PreferredHeight (" << width << ")\n");
		float minHeight;
		clutter_actor_get_preferred_height(CLUTTER_ACTOR(m_text), width, &minHeight, NULL);
		return minHeight;
	}

	const char* CText::GetActorType(void)
	{
		return "Text";
	}
	
	int CText::LineCount(void)
	{
		int count = 0;
		PangoLayout* layout = clutter_text_get_layout(m_text);
		count = pango_layout_get_line_count(layout);
		return count;
	}

	int CText::LineHeight(int index)
	{
		PangoLayout* layout = clutter_text_get_layout(m_text);
		int count = pango_layout_get_line_count(layout);
		if (index >= count)
		{
			return 0;
		}
		PangoLayoutLine* line = pango_layout_get_line(layout, index);
		PangoRectangle rect_ink = { 0 };
		PangoRectangle rect_logic = { 0 };
		pango_layout_line_get_extents(line, &rect_ink, &rect_logic);
		return rect_logic.height / PANGO_SCALE;
	}

	void CText::t_UpdateOrientation(EOrientation orientation)
	{
		H_LOG_TRACE(LOGGER, "Ctext::t_UpdateOrientation() orientation = " << orientation);
		if (t_orientation == orientation)
		{
			return;
		}
		else
		{
			t_orientation = orientation;
			if (m_hAlignment == HALIGN_LEFT)
			{
				SetTextAlignment(HALIGN_RIGHT, m_vAlignment);
			}
			else if (m_hAlignment == HALIGN_RIGHT)
			{
				SetTextAlignment(HALIGN_LEFT, m_vAlignment);
			}

			if (m_truthHasStartScrollFlag)
			{
				m_stopScrollText();
			}

			if (m_animationScrollAttr.direction == CLUTTER_TIMELINE_FORWARD)
			{
				m_animationScrollAttr.direction = CLUTTER_TIMELINE_BACKWARD;
			}
			else if (m_animationScrollAttr.direction == CLUTTER_TIMELINE_BACKWARD)
			{
				m_animationScrollAttr.direction = CLUTTER_TIMELINE_FORWARD;
			}

			if (m_truthHasStartScrollFlag)
			{
				m_startScrollText();
			}
		}
		CActor::t_UpdateOrientation(orientation);
	}
	/* namespace UIElements */

	std::string CText::t_CurentToMultiResolution(std::string& fontName)
	{
		bool flag = GetResolutionFlag();
		if (flag == true)
		{
			PangoFontDescription *fontdes = pango_font_description_from_string(fontName.c_str());
			gint fontSize = pango_font_description_get_size(fontdes) / PANGO_SCALE;
	
			//! Multi resolution
			IUtility::EResolution res = IUtility::RESOLUTION_1080;
			res = IUtility::GetInstance()->GetCurrentResolution();		
			if (IUtility::RESOLUTION_720 == res)
			{
				fontSize /= 1.5f;  // radio = 1280.0f/1920.0f
			}
			
	
			gboolean absoluteFlag = pango_font_description_get_size_is_absolute(fontdes);
			if (!absoluteFlag)
			{
				pango_font_description_set_size(fontdes, fontSize *PANGO_SCALE);
			}
			else
			{
				pango_font_description_set_absolute_size(fontdes, fontSize * PANGO_SCALE);
			}
	
			std::string newFontName = pango_font_description_to_string(fontdes);
			//clutter_text_set_font_name(CLUTTER_TEXT(getAnimationActor(TextColor)), newFontName.c_str());
	
			pango_font_description_free(fontdes);		

			return newFontName.c_str();
		}
		else
		{
			return fontName.c_str();
		}
	}

	std::string CText::t_MultiResolutionToCurent(std::string& fontName)
	{
		bool flag = GetResolutionFlag();

		if (flag == true)
		{
			PangoFontDescription *fontdes = pango_font_description_from_string(fontName.c_str());
			gint fontSize = pango_font_description_get_size(fontdes) / PANGO_SCALE;

			//! Multi resolution
			IUtility::EResolution res = IUtility::RESOLUTION_1080;
			res = IUtility::GetInstance()->GetCurrentResolution();		
			if (IUtility::RESOLUTION_720 == res)
			{
				fontSize = 1.5f*fontSize;  // radio = 1920.0f/1280.0f
			}			

			gboolean absoluteFlag = pango_font_description_get_size_is_absolute(fontdes);
			if (!absoluteFlag)
			{
				pango_font_description_set_size(fontdes, fontSize *PANGO_SCALE);
			}
			else
			{
				pango_font_description_set_absolute_size(fontdes, fontSize * PANGO_SCALE);
			}

			std::string newFontName = pango_font_description_to_string(fontdes);
			//clutter_text_set_font_name(CLUTTER_TEXT(getAnimationActor(TextColor)), newFontName.c_str());

			pango_font_description_free(fontdes);

			return newFontName.c_str();
		}
		else
		{
			return fontName.c_str();
		}
	}

	void CText::m_updateTextPosition(void)
	{
		float parentW = this->getWidth();
		float textW = clutter_actor_get_width(CLUTTER_ACTOR(m_text));

		float parentH = this->getHeight();
		float textH = clutter_actor_get_height(CLUTTER_ACTOR(m_text));

		if (m_hAlignment == HALIGN_LEFT)
		{
			clutter_actor_set_x(CLUTTER_ACTOR(m_text), 0);
		}
		else if (m_hAlignment == HALIGN_CENTER)
		{
			if (textW >= parentW)
			{
				clutter_actor_set_x(CLUTTER_ACTOR(m_text), 0);
			}
			else
			{
				gfloat off_x = (parentW - textW) / 2.0f;
				clutter_actor_set_x(CLUTTER_ACTOR(m_text), off_x);
			}
		}
		else if (m_hAlignment == HALIGN_RIGHT)
		{
			if (textW >= parentW)
			{
				clutter_actor_set_x(CLUTTER_ACTOR(m_text), 0);
			}
			else
			{
				gfloat off_x = parentW - textW;
				clutter_actor_set_x(CLUTTER_ACTOR(m_text), off_x);
			}
		}

		if (m_vAlignment == VALIGN_TOP)
		{
			clutter_actor_set_y(CLUTTER_ACTOR(m_text), 0);
		}
		else if (m_vAlignment == VALIGN_MIDDLE)
		{
			if (textH >= parentH)
			{
				clutter_actor_set_y(CLUTTER_ACTOR(m_text), 0);
			}
			else
			{
				gfloat off_y = (parentH - textH) / 2.0f;
				clutter_actor_set_y(CLUTTER_ACTOR(m_text), off_y);
			}
		}
		else if (m_vAlignment == VALIGN_BOTTOM)
		{
			if (textH >= parentH)
			{
				clutter_actor_set_y(CLUTTER_ACTOR(m_text), 0);
			}
			else
			{
				gfloat off_y = parentH - textH;
				clutter_actor_set_y(CLUTTER_ACTOR(m_text), off_y);
			}
		}
	}

}

