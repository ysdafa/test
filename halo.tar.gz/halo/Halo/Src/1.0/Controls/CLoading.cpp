#include "Halo.h"
#include "Halo1_0.h"
#include "COSDInfo.h"

#define FONT_DEFAULT "Sans 20px"
static HALO::util::Logger LOGGER("Loading");

namespace HALO
{
	CLoading::CLoading(): m_timeLine(NULL), m_image(NULL), m_text(NULL), m_imagePath(NULL), m_imageName(NULL), 
		m_fontName(NULL), m_count(1), m_x(0.0), m_y(0.0), m_imgWidth(0.0), m_imgHeight(0.0), m_textWidth(0.0), 
		m_textHeight(0.0), m_fps(1), m_fontSize(0), m_gap(0), m_flagCreated(false)
	{
		m_timelineEvents.clear();
		clutter_color_init(&m_color, 125, 125, 125, 0);
	}

	CLoading::~CLoading()
	{
		m_Destroy();
	}

	bool CLoading::Initialize(IActor *parent ,const TLoadingAttr &attr)
	{
		Widget *cParent = dynamic_cast<Widget*>(parent);

		return Initialize(cParent, attr);
	}

	bool CLoading::Initialize(Widget *parent ,const TLoadingAttr &attr)
	{
		H_LOG_TRACE(LOGGER, "CLoading::Initialize attr.imageNum = %d, attr.fps = %d" << attr.imageNum << attr.fps);
		m_InitAttr(attr);
		CActor::Initialize(parent, 0, 0);
	
		//! Root window
		Widget *widget = dynamic_cast<Widget*>(this);
		ASSERT(widget);
		SetPosition(m_x, m_y);	

		//! Image
		m_image = IImage::CreateInstance(widget, m_imgWidth, m_imgHeight);
		ASSERT(m_image);
		m_InitImage(attr.path, attr.name);

		//! Text
		if (attr.text != NULL)
		{
			m_text = ILabel::CreateInstance(widget, m_textWidth, m_textHeight);
			ASSERT(m_text);
			m_InitText(attr.text);	
			m_text->Hide();
		}
		
		//! Timeline
		m_InitTimeline();

		m_flagCreated = true;

		//SetBackgroundColor(*clutter_color_init(&c, 255, 255, 255, 0));

		return true;
	}
	void CLoading::Play()
	{
		H_LOG_TRACE(LOGGER, "CLoading::Play...");
		ASSERT(true == IsInitialized());
		ASSERT(NULL != m_timeLine);

		Show();
		clutter_timeline_start(m_timeLine);
		m_image->Show();
		if (m_text != NULL)
		{
			m_text->Show();
		}

		t_NoticeActorFocusIn(this);
	}

	void CLoading::Pause()
	{
		H_LOG_TRACE(LOGGER, "CLoading::Pause...");
		ASSERT(true == IsInitialized());
		ASSERT(NULL != m_timeLine);

		Show();
		clutter_timeline_pause(m_timeLine);
		m_image->Show();
		if (m_text != NULL)
		{
			m_text->Show();
		}
	}

	void CLoading::Stop()
	{
		H_LOG_TRACE(LOGGER, "CLoading::Stop...");
		ASSERT(true == IsInitialized());
		ASSERT(NULL != m_timeLine);

		clutter_timeline_stop(m_timeLine);		
		m_image->Hide();
		if (m_text != NULL)
		{
			m_text->Hide();
		}	
		Hide();
	}

	void CLoading::SetText(const std::string& text)
	{
		H_LOG_TRACE(LOGGER, "CLoading::SetText(" << text.c_str() << ")");

		if (m_text == NULL)
		{
			m_text = ILabel::CreateInstance(dynamic_cast<Widget*>(this), m_textWidth, m_textHeight);
			ASSERT(m_text);
			m_InitText(text.c_str());
		}
		else
		{
			m_text->SetText(text.c_str());
		}			
	}

	std::string CLoading::Text(void) const
	{
		H_LOG_TRACE(LOGGER, "CLoading::Text.");
		std::string str;
		if (m_text != NULL)
		{
			str = m_text->Text();
		}

		return str;
	}

	void CLoading::SetTextColor(const ClutterColor textcolor)
	{
		H_LOG_TRACE(LOGGER, "CLoading::SetTextColor r = %d, g = %d, b = %d, a = %d" << textcolor.red << textcolor.green << textcolor.blue << textcolor.alpha);
		if (m_text != NULL)
		{
			m_text->SetTextColor(textcolor);
		}
	}

	const ClutterColor& CLoading::TextColor(void)
	{
		H_LOG_TRACE(LOGGER, "CLoading::TextColor.");
		if (m_text != NULL)
		{
			return m_text->TextColor();
		}

		return m_color;
	}

	void CLoading::SetTextFont(const std::string& font)
	{
		H_LOG_TRACE(LOGGER, "CLoading::SetTextFont(" << font << ")");
		if (m_text != NULL)
		{
			m_text->SetTextFont(font.c_str());
		}		
	}

	std::string CLoading::TextFont(void) const
	{
		H_LOG_TRACE(LOGGER, "CLoading::TextFont.");
		std::string str;
		if (m_text != NULL)
		{
			str = m_text->TextFont();
		}

		return str;
	}

	void CLoading::SetFontSize(int size)
	{
		H_LOG_TRACE(LOGGER, "CLoading::SetFontSize(" << size << ")");
		if (m_text != NULL)
		{
			m_text->SetFontSize(size);
		}
	}

	int CLoading::FontSize(void) const
	{
		H_LOG_TRACE(LOGGER, "CLoading::FontSize.");
		return m_fontSize;		
	}

	void CLoading::SetFPS(int fps)
	{
		H_LOG_TRACE(LOGGER, "CLoading::SetFPS(" << fps << ")");
		ASSERT(fps > 0);
		m_fps = fps;

		int interval = 1000/m_fps;
		int duration = interval*m_count;	

		if (true == IsPlaying())
		{
			clutter_timeline_stop(m_timeLine);
			for (int i = 0; i < m_count; ++i)
			{
				char mark[10] = {0};
				//sprintf_s(mark, "%d", i);
				SNPRINTF(mark, sizeof(mark), "%d", i);
				clutter_timeline_remove_marker(m_timeLine, mark);
			}
			clutter_timeline_set_duration(m_timeLine, duration);
			for (int i = 0; i < m_count; ++i)
			{
				char mark[10] = {0};
				//sprintf_s(mark, "%d", i);
				SNPRINTF(mark, sizeof(mark), "%d", i);
				clutter_timeline_add_marker_at_time(m_timeLine, mark, i*interval);
			}
			clutter_timeline_start(m_timeLine);
		}
		else
		{
			for (int i = 0; i < m_count; ++i)
			{
				char mark[10] = {0};
				//sprintf_s(mark, "%d", i);
				SNPRINTF(mark, sizeof(mark), "%d", i);
				clutter_timeline_remove_marker(m_timeLine, mark);
			}
			clutter_timeline_set_duration(m_timeLine, duration);
			for (int i = 0; i < m_count; ++i)
			{
				char mark[10] = {0};
				//sprintf_s(mark, "%d", i);
				SNPRINTF(mark, sizeof(mark), "%d", i);
				clutter_timeline_add_marker_at_time(m_timeLine, mark, i*interval);
			}
		}	
	}

	int CLoading::FPS(void) const
	{
		H_LOG_TRACE(LOGGER, "CLoading::FPS.");
		return m_fps;
	}

	void CLoading::SetGap(int gap)
	{
		H_LOG_TRACE(LOGGER, "CLoading::SetGap.");
		m_gap = gap;
		if (m_text != NULL)
		{
			if (m_gap >= 0)
			{
				m_text->SetPosition((m_imgWidth - m_textWidth)/2, -(m_textHeight + m_gap));
			}
			else
			{
				m_text->SetPosition((m_imgWidth - m_textWidth)/2, m_imgHeight - m_gap);
			}
		}
	}

	int CLoading::Gap(void) const
	{
		H_LOG_TRACE(LOGGER, "CLoading::Gap.");
		return m_gap;
	}
	bool CLoading::IsPlaying(void)
	{
		H_LOG_TRACE(LOGGER, "CLoading::IsPlaying");
		ASSERT(true == IsInitialized());
		ASSERT(NULL != m_timeLine);

		return clutter_timeline_is_playing(m_timeLine) != FALSE;
	}

	const char* CLoading::GetActorType(void)
	{
		return "Loading";
	}
	
	void CLoading::m_InitAttr(const TLoadingAttr &attr)
	{
		m_count = attr.imageNum;
		ASSERT(m_count > 0);
		m_x = attr.x;
		m_y = attr.y;
		m_imgWidth = attr.imageWidth;
		m_imgHeight = attr.imageHeight;
		m_textWidth = attr.textWidth;
		m_textHeight = attr.textHeight;
		m_fps = attr.fps;
		ASSERT(m_fps > 0);
		m_fontSize = attr.fontSize;
		m_gap = attr.gap;
		m_fontName = attr.fontName;
		m_color = attr.color;		
	}

	void CLoading::m_InitImage(const char *path, char **name)
	{
		int iLen = strlen(path);
		m_imagePath = new char[iLen+1];
		strncpy(m_imagePath, path, iLen+1);		

		m_image ->SetPosition(0, 0);

		m_imageName = new char*[m_count];
		for (int i = 0; i < m_count; i++)
		{
			int nLen = strlen(name[i]);
			m_imageName[i] = new char[nLen+1];
			strncpy(m_imageName[i], name[i], nLen+1);
		}
	}

	void CLoading::m_InitText(const char *text)
	{
		//! Text if exited
		if (NULL != m_text)
		{			
			if (m_gap >= 0)
			{
				m_text->SetPosition((m_imgWidth - m_textWidth)/2, -(m_textHeight + m_gap));
			}
			else
			{
				m_text->SetPosition((m_imgWidth - m_textWidth)/2, m_imgHeight - m_gap);				
			}
			m_text->SetText(text);			
			if (m_fontName)
			{
				m_text->SetTextFont(m_fontName);				
			} 
			else
			{
				m_text->SetTextFont(FONT_DEFAULT);
			}	
			if (m_fontSize > 0)
			{
				m_text->SetFontSize(m_fontSize);
			}

			ClutterColor c = {125, 125, 125, 0};
			m_text->SetTextColor(m_color);
			m_text->SetBackgroundColor(*clutter_color_init(&c, 0, 0, 0, 0));
			m_text->TextActor()->SetTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
		}
	}

	void CLoading::m_InitTimeline(void)
	{
		int interval = 1000/m_fps;
		int duration = interval*m_count;
		m_timeLine = clutter_timeline_new(duration);		
		for (int i = 0; i < m_count; ++i)
		{
			char mark[10] = {0};
			//sprintf_s(mark, "%d", i);
			SNPRINTF(mark, sizeof(mark), "%d", i);
			clutter_timeline_add_marker_at_time(m_timeLine, mark, i*interval);
		}	

		clutter_timeline_set_loop(m_timeLine, true);

		guint sID = g_signal_connect (m_timeLine, "started", G_CALLBACK(m_StartCallback), this);
		guint eID = g_signal_connect (m_timeLine, "stopped", G_CALLBACK(m_EndCallback), this);
		guint mID = g_signal_connect (m_timeLine, "marker-reached", G_CALLBACK(m_MarkReachedCallback), this);
		m_timelineEvents.push_back(sID);
		m_timelineEvents.push_back(eID);
		m_timelineEvents.push_back(mID);
	}
	
	void CLoading::m_StartCallback(ClutterTimeline *timeline, gpointer user_data)
	{
		H_LOG_TRACE(LOGGER, "CLoading::t_StartCallback");		
	}

	void CLoading::m_EndCallback(ClutterTimeline *timeline, gpointer user_data)
	{
		H_LOG_TRACE(LOGGER, "CLoading::t_EndCallback");
	}

	void CLoading::m_MarkReachedCallback(ClutterTimeline *timeline, gchar *marker_name, gint msecs, gpointer user_data)
	{
		H_LOG_TRACE(LOGGER, "CLoading::t_MarkReachedCallback(" << timeline << ", " << marker_name << ", " << msecs << ", " << user_data << ")");
		CLoading *pThis = (CLoading *)(user_data);

		int interval = 1000/pThis->m_fps;
		int index = msecs/interval;

		char imagePath[100] = {0};
		//sprintf_s(imagePath, "%s%s", pThis->m_imagePath, pThis->m_imageName[index]);
		SNPRINTF(imagePath, sizeof(imagePath), "%s%s", pThis->m_imagePath, pThis->m_imageName[index]);

		pThis->m_image->SetImage(imagePath);

		pThis->m_image->Show();
	}

	void CLoading::m_Destroy()
	{
		TimelineEventList::iterator iter;
		for (iter = m_timelineEvents.begin(); iter != m_timelineEvents.end(); ++iter)
		{
			g_signal_handler_disconnect(m_timeLine, *iter);
		}
		m_timelineEvents.clear();

		if (true == IsPlaying())
		{
			Stop();
		}

		if (m_image)
		{
			m_image->Release();
		}

		if (m_text)
		{
			m_text->Release();
		}

		if (m_imagePath != NULL)
		{
			delete [] m_imagePath;
		}

		if (m_imageName != NULL)
		{
			for (int i = 0; i < m_count; ++i)
			{
				if (m_imageName[i])
				{
					delete [] m_imageName[i];
				}
			}
			delete [] m_imageName;
		}		
	}


}