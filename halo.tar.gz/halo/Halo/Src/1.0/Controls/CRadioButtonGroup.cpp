#include "Halo1_0.h"

namespace HALO
{
	const char* CRadioButtonGroup::GetActorType(void)
	{
		return "RadioButtonGroup";
	}

	void CRadioButtonGroup::t_ProcessSelect( class ISelectButton* button , bool ischecked )
	{
		m_selectedId = button->GetId();
		//t_listener->OnCheckChanged(this ,button->GetId() ,ischecked , button);
		if (ischecked == false)
		{
			return;
		}
		else
		{
			for (int index = 0; index < t_itemNum ; index++)
			{
				if (button != t_itemList[index])
				{
					t_itemList[index]->SetCheck(false);
				}
			}	
		}
	}

	bool CRadioButtonGroup::Initialize()
	{
		m_selectedId = 0;
		return t_Initialize();
	}

	int CRadioButtonGroup::GetSelectedItemIndex()
	{
		return m_selectedId;
	}

}
