#ifndef _HALO_CLABEL_H_
#define _HALO_CLABEL_H_

namespace HALO
{
	class CLabel : virtual public ILabel, public CActor
	{
	public:
		//! Default Constructor of class CLabel
		CLabel(void) : m_text(NULL), m_image(NULL){}
		//! Destructor of class CLabel
		virtual ~CLabel();

		virtual bool Initialize(IActor* parent, float width, float height);
		virtual bool Initialize(Widget* parent, float width, float height);

	public:
		// interface ILabel
		//! Set an image buffer to label
		virtual void SetImage(IImageBuffer* imageBuffer);

		//! Set label's text
		virtual void SetText(const char* text);

		//! Get label's text
		virtual const char* Text(void) const;

		//! Set text color
		virtual void SetTextColor(const ClutterColor& color);

		//! Get text color
		virtual const ClutterColor& TextColor(void);

		//! Set text font
		virtual void SetTextFont(const char* font);
		virtual const char* TextFont() const;

		//! Set font size
		virtual void SetFontSize(int size);

		//! Get font size
		virtual int FontSize(void) const;

		virtual void EnableMultiLine(bool flagMutliLineMode);

		//! Get text single-line or multi-line state.
		virtual bool IsMultiLineEnabled(void);

		virtual const char* GetActorType(void);

	public:
		//! Get IText actor instance
		virtual IText* TextActor(void);

		//! Get IImage actor instance
		virtual IImage* ImageActor(void);

	private:
		IText* m_text;
		IImage* m_image;
	};

}

#endif
