#include "Halo1_0.h"

namespace HALO
{
	static HALO::util::Logger LOGGER("CPageControl");

	CPageControl::CPageControl() : m_currentPage(0), 
		m_indicatorGap(60),
		m_bHideForSinglePage(false),
		m_pageIndicatorImageWidth(20),
		m_pageIndicatorImageHeight(20),
		m_pageIndicatorImageBuffer(NULL),
		m_highlightPageIndicatorImageBuffer(NULL)
	{
		H_LOG_TRACE(LOGGER, "CPageControl::CPageControl()");

	}

	CPageControl::~CPageControl()
	{
		H_LOG_TRACE(LOGGER, "CPageControl::~CPageControl()");

	}

	bool CPageControl::Initialize(IActor* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CPageControl::Initialize(" << parent << ", " << width << ", " << height << ")");

		Widget* widget = dynamic_cast<Widget *>(parent);
		return Initialize(widget, width, height);
	}

	bool CPageControl::Initialize(Widget* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CPageControl::Initialize(" << parent << ", " << width << ", " << height << ")");

		ASSERT(width > 0);
		ASSERT(height > 0);

		CActor::Initialize(parent, width, height);

		IImage *image = IImage::CreateInstance(static_cast<IActor *>(this), 20, 20);
		if (image != NULL)
		{
			m_indicatorImages.push_back(image);
		}

		return true;
	}

	int CPageControl::CurrentPage() const
	{
		H_LOG_TRACE(LOGGER, "CPageControl::CurrentPage()");
		ASSERT(m_currentPage >= 0);

		return m_currentPage;
	}

	void CPageControl::SetCurrentPage(int currentPage)
	{
		H_LOG_TRACE(LOGGER, "CPageControl::SetCurrentPage(" << currentPage << ")");
		ASSERT(currentPage >= 0);

		m_currentPage = currentPage;
		//m_currentPage = min(m_currentPage, m_indicatorImages.size() - 1);
		//H_LOG_TRACE(LOGGER, "Real CPageControl::SetCurrentPage(" << currentPage << ")");

		m_StateChanged();
	}

	int CPageControl::NumberOfPages() const
	{
		H_LOG_TRACE(LOGGER, "CPageControl::NumberOfPages()");

		return m_indicatorImages.size();
	}

	void CPageControl::SetNumberOfPages(int numPages)
	{
		H_LOG_TRACE(LOGGER, "CPageControl::SetNumberOfPages(" << numPages << ")");
		ASSERT(numPages > 0);

		int deltaCount = numPages - static_cast<int>(m_indicatorImages.size());
		if (deltaCount > 0)
		{
			for (int i = 0; i < deltaCount; ++i)
			{
				IImage *image = IImage::CreateInstance(static_cast<IActor *>(this), 20, 20);
				if (image != NULL)
				{
					m_indicatorImages.push_back(image);
				}
			}
		}
		else
		{
			deltaCount = -deltaCount;
			for (int i = 0; i < deltaCount; ++i)
			{
				IImage *image = m_indicatorImages.back();
				m_indicatorImages.pop_back();
				image->Release();
			}
		}

		m_StateChanged();
	}

	void CPageControl::SetHideForSinglePageFlag(bool hideFlag)
	{
		H_LOG_TRACE(LOGGER, "CPageControl::SetHideForSinglePageFlag(" << hideFlag << ")");

		m_bHideForSinglePage = hideFlag;
		m_StateChanged();
	}

	bool CPageControl::FlagHideForSinglePage()
	{
		H_LOG_TRACE(LOGGER, "CPageControl::FlagHideForSinglePage()");

		return m_bHideForSinglePage;
	}

	void CPageControl::SetPageIndicatorImage(IImageBuffer *imageBuffer)
	{
		H_LOG_TRACE(LOGGER, "CPageControl::SetPageIndicatorImage(" << imageBuffer << ")");

		m_pageIndicatorImageBuffer = imageBuffer;
		m_StateChanged();
	}

	void CPageControl::SetHighlightPageIndicatorImage(IImageBuffer *imageBuffer)
	{
		H_LOG_TRACE(LOGGER, "CPageControl::SetHighlightPageIndicatorImage(" << imageBuffer << ")");

		m_highlightPageIndicatorImageBuffer = imageBuffer;
		m_StateChanged();
	}

	void CPageControl::SetPageIndicatorGap(float indicatorGap)
	{
		H_LOG_TRACE(LOGGER, "CPageControl::SetPageIndicatorGap(" << indicatorGap << ")");

		m_indicatorGap = indicatorGap;
		m_StateChanged();
	}

	float CPageControl::PageIndicatorGap(void)
	{
		H_LOG_TRACE(LOGGER, "CPageControl::PageIndicatorGap()");

		return m_indicatorGap;
	}

	void CPageControl::SetPageIndicatorImageSize(float width, float height)
	{
		m_pageIndicatorImageWidth = width;
		m_pageIndicatorImageHeight = height;
		m_StateChanged();
	}

	void CPageControl::PageIndicatorImageSize(float &width, float &height)
	{
		width = m_pageIndicatorImageWidth;
		height = m_pageIndicatorImageHeight;
	}

	const char* CPageControl::GetActorType(void)
	{
		return "PageControl";
	}
	
	void CPageControl::m_StateChanged()
	{
		std::size_t indicatorsNum = m_indicatorImages.size();

		if (m_bHideForSinglePage && indicatorsNum == 1)
		{
			(m_indicatorImages[0])->Hide();			// hide if single page
			return;
		}

		(m_indicatorImages[0])->Show();				// show restore
		for (std::size_t i = 0; i < indicatorsNum; ++i)
		{
			if (i == m_currentPage)
			{
				if (m_highlightPageIndicatorImageBuffer)
				{
					(m_indicatorImages[i])->SetImage(m_highlightPageIndicatorImageBuffer);
				}
			}
			else
			{
				if (m_pageIndicatorImageBuffer)
				{
					(m_indicatorImages[i])->SetImage(m_pageIndicatorImageBuffer);
				}
			}

			(m_indicatorImages[i])->Resize(m_pageIndicatorImageWidth, m_pageIndicatorImageHeight);
		}

		if (indicatorsNum == 1)
		{
			float width = 0;
			float height = 0;
			this->GetSize(width, height);
			(m_indicatorImages[0])->SetPosition(width / 2 - m_pageIndicatorImageWidth / 2, height / 2 - m_pageIndicatorImageHeight/2);
		}
		else
		{
			// page indicators have width
			float x = ((clutter_actor_get_width(t_actor) - ((indicatorsNum - 1)* m_indicatorGap + indicatorsNum*m_pageIndicatorImageWidth))) / 2;
			float y = (clutter_actor_get_height(t_actor) - m_pageIndicatorImageHeight) / 2;

			for (std::size_t i = 0; i < indicatorsNum; ++i)
			{
				IImage *image = m_indicatorImages[i];
				image->SetPosition(x, y);
				x = x + m_indicatorGap + m_pageIndicatorImageWidth;
			}
		}
	}

}