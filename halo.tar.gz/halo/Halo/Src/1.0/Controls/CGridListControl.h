#ifndef _HALO_CGRIDLISTCONTROL_H_
#define _HALO_CGRIDLISTCONTROL_H_

namespace HALO
{
	class CGridListControl : virtual public IGridListControl, public CDataListControl, public CGridDataSourceListener
	{
	public:

		CGridListControl(void);
		virtual ~CGridListControl(void);

		virtual bool Initialize(IActor *parent, const TGridListControlAttr &attr);
		virtual bool Initialize(Widget *parent, const TGridListControlAttr &attr);

		virtual IGridDataSource * DataSource(void);	

		virtual bool AddListListener(IGridListControlListener *listener);

		virtual bool RemoveListListener(IGridListControlListener* listener);

		//! add given number of group to control
		virtual void AddGroup(int numberOfGroup);

		//! add a number of style to control
		virtual bool AddStyleToAllGroup(int numOfStyle);

		virtual int CurrentStyle(void);

		//! Add a column to given group in given style, return column index
		virtual int AddColumn(int groupIndex, int styleIndex, float columnWidth);

		//! Add a row to given column in given group of given style
		virtual bool AddRowToColumn(int groupIndex, int styleIndex, int columnIndex, float rowHeight);

		//! Add a row to all column in given group of given style
		virtual bool AddRowToAllColumn(int groupIndex, int styleIndex, float rowHeight);

		//! Merge an item in given group of given style with given row and column range it will occupy.
		virtual bool MergeCells(int groupIndex, int styleIndex, int startRow, int startCol, int endRow, int endCol);

		//! Set style to given group as its current style
		virtual bool SetStyle(int styleIndex);

		//! transform current style to target style
		virtual void TransformStyle(int toStyleIndex);

		//! Set given group's title
		virtual void AttachGroupTitle(int groupIndex, IText* titleActor);

		//! Set given group's title(widget)
		void AttachGroupTitle(int groupIndex, Widget* titleWidget);

		//! Set focus to given item index in given group index
		virtual TValue2f SetFocusItemIndex(int groupIndex, int itemIndex, bool flagAni = true);

		void SetFocusItemIndex(int groupIndex, int itemIndex, bool flagAlignTop, bool flagAni);

		//! Get current focused item's group index and itemIndex
		virtual void GetFocusItemIndex(int &groupIndex, int &itemIndex);

		virtual void EnableItem(int groupIndex, int itemIndex, bool flagEnable);

		virtual bool IsItemEnabled(int groupIndex, int itemIndex);

		virtual void SetAnimationDuration(EAniType anitype, int duration);

		virtual void SetAnimationMode(EAniType anitype, ClutterAnimationMode mode);

		virtual void EnableEdit(const bool flagEditable);

		virtual bool IsEditEnabled(void) const;

		virtual int ColumnCount(int groupIndex, int styleIndex);

		virtual void UpdateItem(int groupIndex, int itemIndex);

		virtual void UpdateAllItems(int groupIndex);

		virtual void SetBufferColumnSize(int left, int right);

		virtual void ClearDataSource(int groupIndex);

		bool IsSetMarginWhenFocusEdgeItem(void) const;

		void EnableMarginWhenFocusEdgeItem(const bool flagEnable);

		void SetCheckToThumbnailOfGroup(int groupIndex, bool flagChecked);
		void SetCheckToThumbnailOfItem(int groupIndex, int itemIndex, bool flagChecked);
		bool IsThumbnailChecked(int groupIndex, int itemIndex);

		void EnableThumbnailStyleOfGroup(int groupIndex, IThumbnail::EThumbnailStyle style, bool flagEnable, bool flagAni);
		void EnableThumbnailStyleOfItem(int groupIndex, int itemIndex, IThumbnail::EThumbnailStyle style, bool flagEnable, bool flagAni);
		bool IsThumbnailStyleEnabled(int groupIndex, int itemIndex, IThumbnail::EThumbnailStyle style);

		void SelectThumbnailCheckBoxOfGroup(int groupIndex, bool flagSelect);
		void SelectThumbnailCheckBoxOfItem(int groupIndex, int itemIndex, bool flagSelect);
		bool IsThumbnailCheckBoxSelected(int groupIndex, int itemIndex);

		int GetThumbnailStyleOfItem(int groupIndex, int itemIndex);

		EDirectionType ScrollDirection(void);

		virtual IRenderer* Renderer(int groupIndex, int itemIndex);

		virtual void GetOnScreenRange(int &startGroupIndex, int &startItemIndex, int &endGroupIndex, int &endItemIndex);

		virtual int ItemCount(int groupIndex);

		virtual void EnableStraightPathOnFocusMoving(const bool flagStraightPath);

		virtual bool IsStraightPathOnFocusMovingEnabled(void) const;

		virtual void EnableRolloverEffect(const bool flagRolloverEffect);

		virtual bool IsRolloverEffectEnabled(void) const;

		virtual const char* GetActorType(void);

		typedef enum E_GRID_LIST_EVENT_TYPE
		{			 
			EVENT_FOCUS_CHANGE = 0,				//!< focused item change (focus animation end) event
			EVENT_FOCUS_CHANGE_MOTION_START,	//!< focus change animation starts
			EVENT_ITEM_LOAD,				    //!< item load event
			EVENT_ITEM_UNLOAD,				    //!< item unload event
			EVENT_ITEM_ASYNC_LOAD,				//!< item async load event
			EVENT_ITEM_INDEX_CHANGE,			//!< item index change event
			EVENT_MOVE_OUT,						//!< trying to move focus to outward
			EVENT_ITEM_CLICKED,					//!< the callback of item click.
			EVENT_ENTER_KEY_LONG_PRESSED,				//!< the "Enter" key has been long pressed

			EVENT_GRIDLIST_MAX,					//!< last grid list event type identifier.
		}E_GridListEventType;

	public: //for bridge use
		void StartScrollTimer(void);

		void StopScrollTimer(void);

		void SetTimerInterval(const int timeInterval);

		int TimerInterval(void) const;

		int GroupCount(void);

		void EnableMouseWheel(bool flagEnable, bool flagAni);

		void PageMove(bool flagPrev, bool flagAni = true);

	public: //data source listener call back
		virtual bool OnDataChanged(EDataSourceListenerType type, int groupIndex, int dataIndex);

	protected:
		virtual void t_UpdateOrientation(EOrientation orientation);

	protected:
		virtual bool t_CreateDerivedObject(IActor *parent, TDataListControlAttr *attr);
		virtual bool t_MoveFocusBar(EDirection direction);
		virtual void t_BindDataListToItemList();

		virtual void t_GetInMemoryItems(TRect lastVisibleArea, TRect visibleArea, std::vector<TItem*> &loadItem, std::vector<TItem*> &unloadItem, std::vector<TItem*> &noChangeItem, int reason = -1);
		virtual void t_OnItemGroupScrollStart(void);
		virtual void t_OnItemGroupScrollEnd(void);

		virtual void t_GetItemWindowPivotPoint(TItem *item, float &pivotX, float &pivotY, float &pivotZ);

		virtual void t_OnItemDataUnload(TItem *item);
		virtual void t_OnItemDataSyncLoad(TItem *item);
		virtual void t_OnItemDataAsyncLoad(TItem *item);

		virtual void t_OnRendererDraw(TItem *item);

		virtual void t_FocusChangeStart(const TItem *from, const TItem *to);
		virtual void t_FocusChangeFinish(const TItem *from, const TItem *to);

		//The item in memory only scrolled, not loaded or unloaded.
		virtual void t_OnItemInMemoryScrolled(TItem *item);

		virtual TValue2f t_GetRealPointBaseItemGroup(TRect rect, TRect baseOnRect);
		virtual TValue2f t_GetLogicalPosition(TRect rect, TRect baseOnRect);

		TRect t_InitRectOfLoadingItem(TItem *item, int reason);

		virtual bool t_OnMousePointerIn(TItem* item, IMouseEvent* ptrMouseEvent);
		virtual bool t_OnMousePointerOut(TItem* item, IMouseEvent* ptrMouseEvent);
		virtual bool t_OnMouseMoved(TItem* item, IMouseEvent* ptrMouseEvent);
		virtual bool t_MouseButtonPressed(TItem* item, IMouseEvent* ptrMouseEvent);
		virtual bool t_MouseButtonRelease(TItem* item, IMouseEvent* ptrMouseEvent);
		virtual bool t_MouseClicked(TItem* item, IMouseEvent* ptrMouseEvent);
		virtual bool t_MouseWheel(IMouseEvent* ptrMouseEvent);

		virtual void t_OnStyleAnimationFinish(void);

		virtual bool t_OnDragBegin(TItem* item, IDragEvent* pDragEvent);

		virtual bool t_OnDragEnd(TItem* item, IDragEvent* pDragEvent);

		virtual bool t_OnDragHold(TItem* item, IDragEvent* pDragEvent);

		virtual bool t_OnEnterKeyLongPressed(void);

		virtual void t_OnRegisterAnimationCallback(ITimeLine *timeLine, EAniEventType aniCallbackType);

		virtual bool t_GetItemsNeedFoveaAni(const TItem *hitItem, std::vector<TItem*> &itemArray, TValue2f cursorCenter, float cursorRadius);

		virtual EDirectionType t_GetScrollDirection(void)
		{
			return m_scrollDirectionType;
		}

	private:

		typedef enum E_MERGE_STATE
		{
			STATE_NORMAL = 0,
			STATE_MERGE_RESIZE,
			STATE_MERGE_HIDDEN,
			STATE_MERGE_MAX
		}E_MergeState;

		struct TCell
		{
			int itemIndex;

			TRect rect;

			int columnIndex;

			int indexInColumn;
			E_MergeState mergeState;
			int fromColumnIndex;
			int fromRowIndex;
			int toColumnIndex;
			int toRowIndex;
		};

		struct TGridListItem : public TItem
		{
			int groupIndex;
			int styleIndex;
			int indexInGroup;
		};

		struct TColumn
		{
			virtual ~TColumn()
			{
				for (int i = 0; i < (int)cellList.size(); i++)
				{
					delete cellList[i];
				}

				cellList.clear();
			}

			float space;
			int indexInGroup;

			float startPos;
			float endPos;

			float usedLength;

			int startItemIndex;
			int endItemIndex;

			std::vector<TCell*> cellList;
		};

		struct TStyle
		{
			virtual ~TStyle()
			{
				for (int i = 0; i < (int)columnList.size(); i++)
				{
					delete columnList[i];
				}

				columnList.clear();

				rectList.clear();
			}

			int styleIndex;

			float startPos;
			float endPos;
			std::vector<TColumn*> columnList;

			std::vector<TRect> rectList;

			std::map<int, TCell*> itemIndexToCell;

			float cursorRadius;

			void ResetPosition(float positionOffset);
		};

		struct TGroup
		{
			virtual ~TGroup()
			{
				for (int i = 0; i < (int)styleList.size(); i++)
				{
					delete styleList[i];
				}
				styleList.clear();

				for (int i = 0; i < (int)itemList.size(); i++)
				{
					delete itemList[i];
				}
				itemList.clear();

				if (title != NULL)
				{
					delete title;
				}
			}

			int currentStyle;//current style index
			int lastStyle;	 //last style index

			std::vector<TStyle*> styleList;
			std::vector<TGridListItem*> itemList;

			IActor* title;
		};

		struct TRange
		{
			int startGroupIndex;
			int startColumnIndex;
			
			int endGroupIndex;
			int endColumnIndex;
			
			int startGroupInScrn;
			int startColumnInScrn;

			int endGroupInScrn;
			int endColumnInScrn;

			int startItemIndexInScrn;
			int endItemIndexInScrn;

			TRange(void) :startGroupIndex(0), startColumnIndex(0), endGroupIndex(0), endColumnIndex(0){}
			TRange(int a, int b, int c, int d) : startGroupIndex(a), startColumnIndex(b), endGroupIndex(c), endColumnIndex(d){}
		};

		std::vector<TGroup*> m_groupList;

		CGridDataSource* m_dataSource;

		bool m_flagRightToLeft; //horizontal layout flag

		float m_titleSpace; //space between group's title and content

		float m_groupSpace; //space between groups

		float m_cellSpace;  //space between cells

		float m_focusRangeOffset[2];

		float m_styleAniOffset;

		class CGridListControlListenerSet* m_listenerSet;

		TRange m_onScreenRange;//records current on screen group and column index

		int m_focusGroupIndex;
		int m_focusItemIndex;

		bool m_focusItemChangedFlag;

		struct TAniInfo
		{
			TAniInfo(void) : duration(100), mode(CLUTTER_LINEAR) {}
			int duration;
			ClutterAnimationMode mode;
		};
		TAniInfo m_aniInfoList[ANITYPE_MAX];
		
		GTimeVal m_start_time;
		bool m_canMove;
		bool m_isSunken;
		double m_xFactor, m_yFactor, m_zFactor;

		float m_mouseToItemX;
		float m_mouseToItemY;

		int m_dragItemIndex;
		int m_dropItemIndex;

		int m_leftBufferColumnNum;
		int m_rightBufferColumnNum;

		CMultiObjectTransition *m_dragItemTrans;
		CMultiObjectTransition *m_itemScaleTrans;

		bool m_flagItemDraged;

		bool m_flagUseMarginWhenFocusEdgeItem;
		
		float m_refXForFocusMoving;
		float m_refYForFocusMoving;

		bool m_flagStraightPath;

		bool m_flagRolloverEffect;
		EDirectionType m_scrollDirectionType;

		int m_timerInterval;

		int m_timerId;

		int m_lastRandomGroupIndex;
		int m_lastRandomItemIndex;

		bool m_flagEnableWheel;
		bool m_flagWheelWithAnimation;

		void m_InitItemIndex(void);

		void m_AddRowToColumn(int groupIndex, int styleIndex, int columnIndex, float rowHeight);

		void m_SetFocus(int groupIndex, int itemIndex, bool flagFocusBarAni, bool flagScrollAni, TValue2f *newItemGroupPos = NULL);

		bool m_ReCalcFocusItemIndex(const TRect newVisibleArea);

		TCell* m_GetCellByItemIndex(int groupIndex, int itemIndex);

		void m_SetGridItemIndex(int groupIndex, int itemIndex, TGridListItem *item);

		bool m_MoveFocus(EDirection direction, int fromGroupIndex, int fromItemIndex);

		void m_GetNearestItem(TCell* focusedCell, int destGroupIndex, int destColumnIndex, int &destItemIndex);

		int m_ColumnNumberInGroup(int groupIndex);

		void m_FindOnScreenRange(TRect visibleArea, TRange &newRange, bool flagItemRectAllInArea = false);

		void m_MoveItem(int groupIndex, int fromItemIndex, int toItemIndex);

		void m_GetItemsInRange(TRange range, int reason, std::set<TItem*> &itemList);

		TCell* m_FindCellBellow(TCell* fromCell, int destGroupIndex, int destColumnIndex);

		int m_NextColumnIndex(const bool flagPrev, const int curColumnIndex, int &curGroupIndex);

		static int m_ScrollThumbnailImage(gpointer data);

		void m_GetRandomItemFromOnScreenRange(int &groupIndex, int &itemIndex);

		friend class CThumbnail;
	};
}


#endif
