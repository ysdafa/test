#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{

	IMultiImage* IMultiImage::CreateInstance(IActor* parent, float width, float height)
	{
		CMultiImage* multiImage = dynamic_cast<CMultiImage*>(Instance::CreateInstance(CLASS_ID_IMULTIIMAGE));

		if (NULL != multiImage)
		{
			multiImage->Initialize(parent, width, height);
		}

		return multiImage;
	}

	IMultiImage* IMultiImage::CreateInstance(Widget* parent, float width, float height)
	{
		CMultiImage* multiImage = dynamic_cast<CMultiImage*>(Instance::CreateInstance(CLASS_ID_IMULTIIMAGE));

		if (NULL != multiImage)
		{
			multiImage->Initialize(parent, width, height);
		}

		return multiImage;
	}

}