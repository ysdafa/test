#include "Halo1_0.h"

static HALO::util::Logger LOGGER("CImage");

namespace HALO
{
	CImage::~CImage(void)
	{
		H_LOG_TRACE(LOGGER, "CImage::~CImage.");
		m_DestroyImage();

		if (NULL != t_content)
		{
			//g_object_unref(&m_content);
			t_content = NULL;
		}
	}

	bool CImage::Initialize(IActor* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CImage::Initialize. with IActor type parent:" << parent);
		CActor::Initialize(parent, width, height);

		t_content = t_CreateContent();
		clutter_actor_set_content(t_actor, t_content);

		return true;
	}

	bool CImage::Initialize(Widget* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CImage::Initialize. with Widget type parent:" << parent);
		CActor::Initialize(parent, width, height);

		t_content = t_CreateContent();
		clutter_actor_set_content(t_actor, t_content);

		return true;
	}

	void CImage::SetImage(const char* imagePath)
	{
		H_LOG_DEBUG(LOGGER, "CImage::SetImage. imagePath:" << imagePath);
		ASSERT(imagePath != NULL);

		m_DestroyImage();

		m_imageBuffer = IImageBuffer::CreateInstance(imagePath);

		if (m_imageBuffer != NULL)
		{
			clutter_image_set_data(CLUTTER_IMAGE(t_content),
				m_imageBuffer->GetPixels(),
				m_imageBuffer->HasAlphaChannel() ? COGL_PIXEL_FORMAT_RGBA_8888 : COGL_PIXEL_FORMAT_RGB_888,
				m_imageBuffer->Width(),
				m_imageBuffer->Height(),
				m_imageBuffer->BytesPerLine(),
				NULL);
		}

		m_flagCreatedInternally = true;
	}

	void CImage::SetImage(IImageBuffer *buffer)
	{
		H_LOG_DEBUG(LOGGER, "CImage::SetImage. imageBuffer:" << buffer);
		ASSERT(buffer != NULL);
		
		m_DestroyImage();

		m_imageBuffer = buffer;

		clutter_image_set_data(CLUTTER_IMAGE(t_content),
			m_imageBuffer->GetPixels(),
			m_imageBuffer->HasAlphaChannel() ? COGL_PIXEL_FORMAT_RGBA_8888 : COGL_PIXEL_FORMAT_RGB_888,
			m_imageBuffer->Width(),
			m_imageBuffer->Height(),
			m_imageBuffer->BytesPerLine(),
			NULL);

		m_flagCreatedInternally = false;
	}

	IImageBuffer* CImage::ImageBuffer(void)
	{
		return m_imageBuffer;
	}

	void CImage::SetFillMode(ClutterContentGravity gravity)
	{
		H_LOG_DEBUG(LOGGER, "CImage::SetFillMode. gravity:" << gravity);
		clutter_actor_set_content_gravity(t_actor, gravity);
	}

	ClutterContentGravity CImage::FillMode(void)
	{
		return clutter_actor_get_content_gravity(t_actor);
	}

	const char* CImage::GetActorType(void)
	{
		return "Image";
	}
	
	ClutterContent* CImage::t_CreateContent()
	{
		return clutter_image_new();
	}

	void CImage::m_DestroyImage(void)
	{
		if (m_imageBuffer == NULL)
		{
			return;
		}

		if (m_flagCreatedInternally == true)
		{
			m_imageBuffer->Release();
		}

		m_imageBuffer = NULL;
	}

}

 /* namespace HALO */
