#include "Halo1_0.h"

static HALO::util::Logger LOGGER("CImage");

namespace HALO
{
	CImage::~CImage(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		m_DestroyImage();

		if (NULL != t_content)
		{
			//g_object_unref(&m_content);
			t_content = NULL;
		}
	}

	bool CImage::Initialize(IActor* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] parent:IActor(" << parent << ") width(" << width << ") height(" << height << ")");
		CActor::Initialize(parent, width, height);

		t_content = t_CreateContent();
		clutter_actor_set_content(t_actor, t_content);

		return true;
	}

	bool CImage::Initialize(Widget* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] parent:Widget(" << parent << ") width(" << width << ") height(" << height << ")");
		CActor::Initialize(parent, width, height);

		t_content = t_CreateContent();
		clutter_actor_set_content(t_actor, t_content);

		return true;
	}

	void CImage::SetImage(const char* imagePath)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] imagePath(" << imagePath << ")");
		HALO_ASSERT(imagePath != NULL);

		m_DestroyImage();

		m_imageBuffer = IImageBuffer::CreateInstance(imagePath);

		if (m_imageBuffer != NULL && m_imageBuffer->IsReady())
		{
			clutter_image_set_data(CLUTTER_IMAGE(t_content),
				m_imageBuffer->GetPixels(),
				m_imageBuffer->HasAlphaChannel() ? COGL_PIXEL_FORMAT_RGBA_8888 : COGL_PIXEL_FORMAT_RGB_888,
				m_imageBuffer->Width(),
				m_imageBuffer->Height(),
				m_imageBuffer->BytesPerLine(),
				NULL);
		}

		m_flagCreatedInternally = true;
	}

	void CImage::SetImage(IImageBuffer *buffer)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] buffer(" << buffer << ")");
		HALO_ASSERT(buffer != NULL);
		
		m_DestroyImage();

		m_imageBuffer = buffer;

		if (buffer->IsReady())
		{
			clutter_image_set_data(CLUTTER_IMAGE(t_content),
				m_imageBuffer->GetPixels(),
				m_imageBuffer->HasAlphaChannel() ? COGL_PIXEL_FORMAT_RGBA_8888 : COGL_PIXEL_FORMAT_RGB_888,
				m_imageBuffer->Width(),
				m_imageBuffer->Height(),
				m_imageBuffer->BytesPerLine(),
				NULL);
		}

		m_flagCreatedInternally = false;
	}

	IImageBuffer* CImage::ImageBuffer(void)
	{
		return m_imageBuffer;
	}

	void CImage::SetFillMode(ClutterContentGravity gravity)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] fillMode(" << gravity << ")");
		clutter_actor_set_content_gravity(t_actor, gravity);
	}

	ClutterContentGravity CImage::FillMode(void)
	{
		return clutter_actor_get_content_gravity(t_actor);
	}

	const char* CImage::GetActorType(void)
	{
		return "Image";
	}
	
	ClutterContent* CImage::t_CreateContent()
	{
		return clutter_image_new();
	}

	void CImage::m_DestroyImage(void)
	{
		if (m_imageBuffer == NULL)
		{
			return;
		}

		if (m_flagCreatedInternally == true)
		{
			m_imageBuffer->Release();
		}

		m_imageBuffer = NULL;
	}

}

 /* namespace HALO */
