#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	IRadioButtonGroup* IRadioButtonGroup::CreateInstance()
	{
		CRadioButtonGroup* buttonGroup = dynamic_cast<CRadioButtonGroup*>(Instance::CreateInstance(CLASS_ID_IRADIOBUTTONGROUP));

		if (NULL != buttonGroup)
		{
			buttonGroup->Initialize();
		}

		return buttonGroup;
	}
}