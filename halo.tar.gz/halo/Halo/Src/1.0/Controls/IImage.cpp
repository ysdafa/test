#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{

	IImage* IImage::CreateInstance(IActor* parent, float width, float height)
	{
		CImage* image = dynamic_cast<CImage*>(Instance::CreateInstance(CLASS_ID_IIMAGE));

		if (NULL != image)
		{
			image->Initialize(parent, width, height);
		}

		return image;
	}

	IImage* IImage::CreateInstance(Widget* parent, float width, float height)
	{
		CImage* image = dynamic_cast<CImage*>(Instance::CreateInstance(CLASS_ID_IIMAGE));

		if (NULL != image)
		{
			image->Initialize(parent, width, height);
		}

		return image;
	}

}