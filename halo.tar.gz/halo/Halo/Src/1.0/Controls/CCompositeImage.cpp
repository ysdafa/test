#include "Halo1_0.h"

static HALO::util::Logger LOGGER("CCompositeImage");

namespace HALO
{
	CCompositeImage::~CCompositeImage(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		if (NULL != m_content)
		{
			g_object_unref(&m_content);
			m_content = NULL;
		}
	}

	bool CCompositeImage::Initialize(IActor* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] parent:IActor(" << parent << ") width(" << width << ") height(" << height << ")");
		CActor::Initialize(parent, width, height);

		m_content = clutter_imagecomposite_new();
		clutter_actor_set_content(t_actor, m_content);

		return true;
	}

	bool CCompositeImage::Initialize(Widget* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] parent:Widget(" << parent << ") width(" << width << ") height(" << height << ")");
		CActor::Initialize(parent, width, height);

		m_content = clutter_imagecomposite_new();
		clutter_actor_set_content(t_actor, m_content);

		return true;
	}


	void CCompositeImage::SetImage(const char* imagePath)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] imagePath(" << imagePath);
		HALO_ASSERT(imagePath != NULL);
		
		//m_DestroyImageBuffer();

		IImageBuffer *imageBuffer = IImageBuffer::CreateInstance(imagePath);

		if (imageBuffer != NULL)
		{
			if (imageBuffer->IsReady())
			{
				clutter_imagecomposite_set_data(CLUTTER_IMAGE_COMPOSITE(m_content),
				imageBuffer->GetPixels(),
				imageBuffer->HasAlphaChannel() ? COGL_PIXEL_FORMAT_RGBA_8888 : COGL_PIXEL_FORMAT_RGB_888,
				imageBuffer->Width(),
				imageBuffer->Height(),
				imageBuffer->BytesPerLine(),
				NULL);
			}
			imageBuffer->Release();
		}
	}

	void CCompositeImage::SetImage(IImageBuffer *buffer)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] buffer(" << buffer << ")");
		HALO_ASSERT(buffer != NULL);

		if (buffer->IsReady())
		{
			clutter_imagecomposite_set_data(CLUTTER_IMAGE_COMPOSITE(m_content),
				buffer->GetPixels(),
				buffer->HasAlphaChannel() ? COGL_PIXEL_FORMAT_RGBA_8888 : COGL_PIXEL_FORMAT_RGB_888,
				buffer->Width(),
				buffer->Height(),
				buffer->BytesPerLine(),
				NULL);
		}
	}

	const char* CCompositeImage::GetActorType(void)
	{
		return "CompositeImage";
	}

}




 /* namespace HALO */
