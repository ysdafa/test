#include "Halo1_0.h"
#include <math.h>

static HALO::util::Logger LOGGER("DataListControl");
#define SAFE_DELETE(x) if(NULL != x) delete (x)
#define SAFE_RELEASE(x) if(NULL != x) (x)->Release()

namespace HALO
{
	CMActor::~CMActor(void)
	{
		if (NULL != dragAction)
		{
			if (pListControl->t_flagEditable == true)
			{
				RemoveAction(dragAction);
			}
			dragAction->Release();
			dragAction = NULL;
		}
	}

	bool CMActor::Initialize(IActor* parent, float width, float height)
	{
		H_LOG_2_PARAM(TRACE, LOGGER, width, height);
		bool ret = ActorBase::Initialize(parent, width, height);
		//EnableFocus(true);
		//EnablePointerFocus(true);
		AddMouseListener(this);

		dragAction = IDragAction::CreateInstance(this);
		AddDragListener(this);

		return ret;
	}

	void CMActor::ScaleTo(float xRatio, float yRatio, CMultiObjectTransition *transGroup)
	{
		H_LOG_TRACE(LOGGER, "[" << this <<"]CMActor::ScaleTo xRatio: " << xRatio << ", yRatio: " << yRatio << "with animation duration: " << (NULL == transGroup ? 0 : transGroup->Duration()));
		if (NULL == transGroup)
		{
			double x, y, z;
			GetScale(x, y, z);
			ActorBase::SetScale((double)xRatio, (double)yRatio, z);
		}
		else
		{
			TValue1f destScale;

			destScale.Set(xRatio);
			transGroup->SetDestination(this, IActor::ACTOR_ANI_SCALE_X, &destScale);

			destScale.Set(yRatio);
			transGroup->SetDestination(this, IActor::ACTOR_ANI_SCALE_Y, &destScale);
		}
	}

	bool CMActor::OnMousePointerIn(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_1_PARAM(TRACE, LOGGER, pOwner);
		
		if (pOwner == NULL)
		{
			return false;
		}

		if (pOwner->flagEnable == false)
		{
			return false;
		}

		if (false == pListControl->m_flagDealMouseEvent)
		{
			return false;
		}

		if (true == pListControl->t_IsOnAnimation(CDataListControl::LIST_ANI_TYPE_MAX))
		{
			return false;
		}

		pListControl->m_StopScrollBarAlphaOutTimer();

		pListControl->m_ShowScrollBar(true);
		
		pListControl->t_OnMousePointerIn(pOwner, ptrMouseEvent);

		return true;
	}

	bool CMActor::OnMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_1_PARAM(TRACE, LOGGER, pOwner);

		if (pOwner == NULL)
		{
			return false;
		}

		if (pOwner->flagEnable == false)
		{
			H_LOG_TRACE(LOGGER, "CMActor::OnMousePointerOut return false for pOwner->flagEnable is false.");
			return false;
		}

		if (false == pListControl->m_flagDealMouseEvent)
		{
			return false;
		}

		if (true == pListControl->t_IsOnAnimation(CDataListControl::LIST_ANI_TYPE_MAX))
		{
			H_LOG_TRACE(LOGGER, "CMActor::OnMousePointerOut return false for pListControl IsOnAnimation");
			return false;
		}

		//if (pOwner->window == NULL)
		//{
		//	H_LOG_TRACE(LOGGER, "CMActor::OnMousePointerOut return false for pOwner->window is NULL.");
		//	return false;
		//}

		//when mouse move out, restart the timer.
		pListControl->m_StartScrollBarAlphaOutTimer();

		pListControl->t_OnMousePointerOut(pOwner, ptrMouseEvent);

		return true;
	}

	bool CMActor::OnMouseMoved(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_1_PARAM(TRACE, LOGGER, pOwner);

		if (pOwner == NULL)
		{
			return false;
		}

		if (pOwner->flagEnable == false)
		{
			return false;
		}

		if (false == pListControl->m_flagDealMouseEvent)
		{
			return false;
		}

		if (true == pListControl->t_IsOnAnimation(CDataListControl::LIST_ANI_TYPE_MAX))
		{
			return false;
		}
		
		if (true == pListControl->IsFoveaEffectEnabled())
		{
			pListControl->m_DoFoveaAnimation(pOwner, ptrMouseEvent);
		}
		
		pListControl->t_OnMouseMoved(pOwner, ptrMouseEvent);

		pListControl->m_StopScrollBarAlphaOutTimer();

		pListControl->m_ShowScrollBar(true);

		return true;
	}

	bool CMActor::OnMouseButtonPressed(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_1_PARAM(TRACE, LOGGER, pOwner);
		
		if (pOwner == NULL)
		{
			return false;
		}

		if (pOwner->flagEnable == false)
		{
			return false;
		}

		if (false == pListControl->m_flagDealMouseEvent)
		{
			return false;
		}

		if (true == pListControl->t_IsOnAnimation(CDataListControl::LIST_ANI_TYPE_MAX))
		{
			return false;
		}

		return pListControl->t_MouseButtonPressed(pOwner, ptrMouseEvent);
	}

	bool CMActor::OnMouseButtonReleased(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_1_PARAM(TRACE, LOGGER, pOwner);

		if (pOwner == NULL)
		{
			return false;
		}

		if (pOwner->flagEnable == false)
		{
			return false;
		}

		if (false == pListControl->m_flagDealMouseEvent)
		{
			return false;
		}

		if (true == pListControl->t_IsOnAnimation(CDataListControl::LIST_ANI_TYPE_MAX))
		{
			return false;
		}

		if (pOwner->flagEnable == false)
		{
			return false;
		}

		return pListControl->t_MouseButtonRelease(pOwner, ptrMouseEvent);
	}

	bool CMActor::OnMouseClicked(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_1_PARAM(TRACE, LOGGER, pOwner);
		
		if (pOwner == NULL)
		{
			return false;
		}

		if (pOwner->flagEnable == false)
		{
			return false;
		}

		if (false == pListControl->m_flagDealMouseEvent)
		{
			return false;
		}

		if (true == pListControl->t_IsOnAnimation(CDataListControl::LIST_ANI_TYPE_MAX))
		{
			return false;
		}

		return pListControl->t_MouseClicked(pOwner, ptrMouseEvent);
	}



	void CMActor::SetOwner(TItem* owner)
	{
		H_LOG_1_PARAM(TRACE, LOGGER, owner);

		pOwner = owner;
	}

	bool CMActor::OnDragBegin(IWidgetExtension* pWindow, IDragEvent* pDragEvent)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);
		
		if (pOwner == NULL)
		{
			return false;
		}

		if (pOwner->flagEnable == false)
		{
			return false;
		}

		TValue2f realValue = pListControl->t_GetRealPointBaseItemGroup(pOwner->rect, pListControl->t_itemGroupRect);

		IActor* dragActor = dynamic_cast<IActor*>(pWindow);
		if(dragActor != NULL)
		{
			dragActor->SetPosition(realValue.val[0], realValue.val[1]);
			dragActor->SetRotation(0.0, 0.0, 0.0);
		}
		return pListControl->t_OnDragBegin(pOwner, pDragEvent);
	}

	bool CMActor::OnDragEnd(IWidgetExtension* pWindow, IDragEvent* pDragEvent)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);

		if (pOwner == NULL)
		{
			return false;
		}

		if (pOwner->flagEnable == false)
		{
			return false;
		}
		return pListControl->t_OnDragEnd(pOwner, pDragEvent);
	}

	bool CMActor::OnDragHold(IWidgetExtension* pWindow, IDragEvent* pDragEvent)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);

		if (pOwner == NULL)
		{
			return false;
		}

		if (pOwner->flagEnable == false)
		{
			return false;
		}
		return pListControl->t_OnDragHold(pOwner, pDragEvent);
	}

	void CMActor::EnableDrag(bool flagEnable)
	{
		H_LOG_1_PARAM(TRACE, LOGGER, flagEnable);
		
		if (flagEnable)
		{
			AddAction(dragAction);
		}
		else
		{
			RemoveAction(dragAction);
		}
	}

	const char* CMActor::GetActorType(void)
	{
		return "GridListItem";
	}

	void* CAsyncTaskListener::OnStart(void* params)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);

		TItem* item = (TItem*)params;
		m_owner->t_OnItemDataAsyncLoad(item);
		return params;
	}

	bool CAsyncTaskListener::OnUpdate(void* result)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);

		if (result == NULL)
		{
			return false;
		}
		TItem* item = (TItem*)result;
		IData *data = (IData *)item->data;

		for (int i = 0; i < data->NumOfWindow(); i++)
		{
			IRenderer* render = m_owner->m_GetRenderer(item, i);
			render->Update(data, item->window);
		}

		return true;
	}

	bool CAsyncTaskListener::OnFinish(void* result)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);

		if (result == NULL)
		{
			return false;
		}
		TItem* item = (TItem*)result;
		IData *data = (IData*)item->data;

		for (int i = 0; i < data->NumOfWindow(); i++)
		{
			data->curUsingSubData = i;
			IRenderer *render = m_owner->m_GetRenderer(item, i);
			render->Draw(data, item->window, IRenderer::UNLOAD_DATA_DRAW);
		}

		return true;
	}

	bool CAsyncTaskListener::OnCancel(void)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);
		return false;
	}

	bool CMScrollAreaListener::OnMouseMoved(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		m_owner->m_DoCursorScroll(pWindow, ptrMouseEvent);
		return false;
	}

	bool CMScrollAreaListener::OnMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		if (true == m_owner->m_itemScrollAni->IsPlaying())
		{
			m_owner->m_itemScrollAni->Stop();
		}
		
		return false;
	}

	void* CDataListControl::OnStart(void* params)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);

		TItem* item = (TItem*)params;
		t_OnItemDataAsyncLoad(item);
		return params;
	}

	bool CDataListControl::OnUpdate(void* result)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);
		if (result == NULL)
		{
			return false;
		}
		TItem* item = (TItem*)result;
		IData *data = (IData *)item->data;
		for (int i = 0; i < data->NumOfWindow(); i++)
		{
			IRenderer* render = m_GetRenderer(item, i);
			render->Update(data, item->window);
		}
		return true;
	}

	bool CDataListControl::OnFinish(void* result)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);

		if (result == NULL)
		{
			return false;
		}
		TItem* item = (TItem*)result;
		IData *data = (IData*)item->data;

		for (int i = 0; i < data->NumOfWindow(); i++)
		{
			data->curUsingSubData = i;
			IRenderer *render = m_GetRenderer(item, i);
			render->Draw(data, item->window, IRenderer::UNLOAD_DATA_DRAW);
		}

		return true;
	}

	bool CDataListControl::OnCancel(void* params)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);
		return false;
	}

	bool CDataListControlAniListener::OnStarted(class ITimeLine *animation, void *data)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);
		m_IfAnimationEvent(animation, CDataListControl::ANI_START, NULL, data);
		return true;
	}

	bool CDataListControlAniListener::OnVia(ITimeLine *animation, void *data)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);
		m_IfAnimationEvent(animation, CDataListControl::ANI_VIA, NULL, data);
		return true;
	}

	bool CDataListControlAniListener::OnCompleted(class ITimeLine *animation, void *data)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);
		m_IfAnimationEvent(animation, CDataListControl::ANI_FINISH, NULL, data);
		return true;
	}

	bool CDataListControlAniListener::OnStoped(class ITimeLine *animation, bool flagFinished, void *data)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);
		m_IfAnimationEvent(animation, CDataListControl::ANI_STOP, &flagFinished, data);
		return true;
	}

	bool CDataListControlAniListener::OnNewFrame(class ITimeLine *animation, double currentProgress, void *data)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);
		m_IfAnimationEvent(animation, CDataListControl::ANI_NEWFRAME, NULL, data);
		return true;
	}

	bool CDataListControlAniListener::m_IfAnimationEvent(ITimeLine *timeLine, CDataListControl::EAniEventType eventType, void *detail, void *data)
	{
		H_LOG_2_PARAM(TRACE, LOGGER, eventType, m_listenerIndex);
		if (true == m_owner->t_flagIsReleasing)
		{
			return false;
		}

		if (CDataListControl::ITEM_SCROLL_ANI == m_listenerIndex)
		{
			m_owner->m_OnItemScrollAni(eventType, detail);
		}
		else if (CDataListControl::ITEM_STYLE_ANI == m_listenerIndex)
		{
			m_owner->m_OnItemStyleAni(eventType, detail, data);
		}
		else if (CDataListControl::FOCUS_MOVE_ANI == m_listenerIndex)
		{
			m_owner->m_OnFocusMoveAniEvent(eventType, detail);
		}
		else if (CDataListControl::LOOP_ANI == m_listenerIndex)
		{
			m_owner->m_OnLoopAniEvent(eventType, detail);
		}
		else if (CDataListControl::CURSOR_SHOW_HIDE_ANI == m_listenerIndex)
		{
			m_owner->m_OnCursorShowHideAniEvent(eventType, detail);
		}
		else if (CDataListControl::LIST_ANI_TYPE_MAX == m_listenerIndex)
		{
			m_owner->t_OnRegisterAnimationCallback(timeLine, eventType);
		}

		return true;
	}
	
	CDataListControl::CDataListControl(void)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);
		m_itemScrollAniListener = NULL;
		m_itemStyleAniListener = NULL;

		m_focusMoveAniListener = NULL;
		m_cursorShowHideAniListener = NULL;
		m_loopAniListener = NULL;

		m_registerAniListener = NULL;

		m_itemScrollAni = NULL;

		m_focusBar = NULL;
		m_focusImage = NULL;
		m_focusImageOffsetX = 0.0f;
		m_focusImageOffsetY = 0.0f;

		t_flagShowFocusBar = false;
		t_flagShowFocusAfterScroll = false;

		t_flagLoopLeft = t_flagLoopRight = true;

		t_flagEditable = false;

		m_scrollBar = NULL;

		m_scrollBarTimer = -1;

		m_scrollBarAlphaAni = NULL;

		m_scrollBarTimerInterval = 2000;

		m_scrollBarMouserListener = NULL;

		m_listStatus = STATUS_NORMAL;

		m_dimWindow = NULL;
		m_dimWindowColor = NULL;

		m_flagShowHidingFocusBar = false;
		t_flagMouse = false;

		m_flagFoveaAni = true;
		t_cursorRadius = 0.0f;

		m_ChangeMount = 1.0f;
		m_cursorScrollSpace = 0.0f;
		m_cursorScrollInShowAreaSpace = 0.0f;
		m_scrollType = TYPE_HORIZONTAL;

		m_leftScrollAreaActor = NULL;
		m_rightScrollAreaActor = NULL;

		m_scrollActorListener = NULL;

		t_flagShadowEffect = true;
		t_shadowEffect = NULL;

		m_flagDealMouseEvent = true;

		m_focusImgRectBak = NULL;
		m_focusItemRectBak = NULL;
		m_itemGroupPosBak = NULL;

		m_cursorShowHideAni = NULL;
		t_flagAutoHighContrast = true;

		m_focusBarColor = NULL;

		t_flagIsReleasing = false;
	}

	CDataListControl::~CDataListControl(void)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);
		t_flagIsReleasing = true;

		SAFE_RELEASE(m_itemScrollAni);
		SAFE_DELETE(m_itemScrollAniListener);

		for (; false == m_windowQueue.empty(); m_windowQueue.pop_front())
		{
			delete m_windowQueue.front();
		}

		SAFE_RELEASE(m_focusImage);
		SAFE_RELEASE(m_focusBar);
		SAFE_DELETE(m_focusBarColor);

		for (; false == m_scrollInfoQueue.empty(); m_scrollInfoQueue.pop_front())
		{
			delete m_scrollInfoQueue.front();
		}

		SAFE_RELEASE(m_cursorShowHideAni);
		SAFE_DELETE(m_cursorShowHideAniListener);
		SAFE_RELEASE(m_focusMoveAni);
		SAFE_DELETE(m_focusMoveAniListener);

		SAFE_RELEASE(m_loopAni);
		SAFE_DELETE(m_loopAniListener);

		SAFE_RELEASE(m_transStyleAni);
		SAFE_DELETE(m_itemStyleAniListener);

		SAFE_RELEASE(m_focusShowHideAni);

		SAFE_DELETE(m_registerAniListener);

		SAFE_DELETE(m_dimWindowColor);
		SAFE_RELEASE(m_dimWindow);
		
		RemoveKeyLongPressListener(this);
		if (m_keyLongPressAction != NULL)
		{
			m_keyLongPressAction->RemoveLongPressKey(CLUTTER_KEY_Return);
			RemoveAction(m_keyLongPressAction);
			m_keyLongPressAction->Release();
		}

		m_StopScrollBarAlphaOutTimer();
		if (m_scrollBar != NULL)
		{		
			m_scrollBar->RemoveMouseListener(m_scrollBarMouserListener);
		}
		if (m_scrollBarMouserListener != NULL)
		{
			delete m_scrollBarMouserListener;
		}
		SAFE_RELEASE(m_scrollBarAlphaAni);
		SAFE_RELEASE(m_scrollBar);

		SAFE_DELETE(m_scrollActorListener);

		SAFE_RELEASE(m_leftScrollAreaActor);
		SAFE_RELEASE(m_rightScrollAreaActor);

		SAFE_DELETE(m_focusImgRectBak);
		SAFE_DELETE(m_focusItemRectBak);
		SAFE_DELETE(m_itemGroupPosBak);

		if (t_shadowEffect != NULL)
		{
			t_shadowEffect->Release();
		}

		IEventManager *em = IEventManager::GetInstance();
		if (NULL != em)
		{
			em->RemoveSystemEventListener(this);
		}
	}

	void CDataListControl::EnableUnload(bool flagEnable)
	{
		H_LOG_1_PARAM(TRACE, LOGGER, flagEnable);
		m_flagEnableUnload = flagEnable;
	}

	void CDataListControl::LoadData(void)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);
		t_BindDataListToItemList();

		TValue2f realValue = t_GetRealPointBaseItemGroup(t_itemGroupRect, m_windowRect);
		t_itemGroup->SetPosition(realValue.val[0], realValue.val[1]);

		if (m_focusBar != NULL && NULL == m_focusBarColor)
		{
			m_focusBar->Raise(NULL);
		}
	}

	bool CDataListControl::MoveFocus(EDirection direction)
	{
		H_LOG_1_PARAM(FATAL, LOGGER, direction);

		if (t_IsOnAnimation(ITEM_STYLE_ANI | LOOP_ANI))
		{
			H_LOG_INFO(LOGGER, "When playing style transform animation or loop animation, focus moving was skipped.\n");
			return false;
		}

		return t_MoveFocusBar(direction);
	}

	TRect CDataListControl::VisibleAreaRect(void)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);

		TRect visibleRect;
		visibleRect.x = -t_itemGroupRect.x;
		visibleRect.y = -t_itemGroupRect.y;
		visibleRect.w = t_listWidth;
		visibleRect.h = t_listHeight;

		return visibleRect;
	}

	void CDataListControl::SetRendererProvider(IRendererProvider *rendererProvider)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);
		HALO_ASSERT(rendererProvider != NULL);
		t_rendererProvider = rendererProvider;
	}

	void CDataListControl::SetFocusImage(IImageBuffer* imageBuffer, float xOffset, float yOffset)
	{
		H_LOG_3_PARAM(FATAL, LOGGER, imageBuffer, xOffset, yOffset);
		HALO_ASSERT(NULL != imageBuffer);

		m_focusImageOffsetX = xOffset;
		m_focusImageOffsetY = yOffset;

		if (NULL != m_focusBar)
		{
			float width, height;
			m_focusBar->GetSize(width, height);

			if (NULL != t_focusedItem && NULL != t_focusedItem->renderer && NULL != t_focusedItem->renderer->Thumbnail())
			{
				m_focusImage = ICompositeImage::CreateInstance(m_focusBar, width - xOffset - xOffset, height - yOffset - yOffset);
			}
			else
			{
				m_focusImage = ICompositeImage::CreateInstance(m_focusBar, width + m_enlargeWidth - xOffset - xOffset, height + m_enlargeHeight - yOffset - yOffset);
			}
			
			m_focusImage->SetPosition(xOffset, yOffset);
			m_focusImage->SetImage(imageBuffer);
			IDeviceManager *dm = IDeviceManager::GetInstance();
			(dm->IsCursorVisible() && !IUtility::GetInstance()->IsHighContrastEnabled()) ? m_focusImage->Hide() : m_focusImage->Show();

			m_focusMoveAni->AddAnimatableObject(m_focusImage, IActor::ACTOR_ANI_POSITION);
			m_focusMoveAni->AddAnimatableObject(m_focusImage, IActor::ACTOR_ANI_SIZE);

			m_loopAni->AddAnimatableObject(m_focusImage, IActor::ACTOR_ANI_SIZE);
		}
	}

	void CDataListControl::SetFocusImage(const char* imageName, float xOffset, float yOffset)
	{
		H_LOG_3_PARAM(FATAL, LOGGER, imageName, xOffset, yOffset);
		HALO_ASSERT(NULL != imageName);

		m_focusImageOffsetX = xOffset;
		m_focusImageOffsetY = yOffset;
		m_focusImageName = imageName;

		if (NULL != m_focusBar)
		{
			float width, height;
			m_focusBar->GetSize(width, height);

			if (m_focusImage == NULL)
			{
				if (NULL != t_focusedItem && NULL != t_focusedItem->renderer && NULL != t_focusedItem->renderer->Thumbnail())
				{
					m_focusImage = ICompositeImage::CreateInstance(m_focusBar, width - 2 * m_focusImageOffsetX, height - 2 * m_focusImageOffsetY);
				}
				else
				{
					m_focusImage = ICompositeImage::CreateInstance(m_focusBar, width + m_enlargeWidth - 2 * m_focusImageOffsetX, height + m_enlargeHeight - 2 * m_focusImageOffsetY);
				}

				if (NULL != m_focusImage)
				{
					m_focusImage->EnableReverse(false);
					m_focusImage->Resize(width - 2 * m_focusImageOffsetX, height - 2 * m_focusImageOffsetY);
				}
				else
				{
					return;
				}

				m_focusMoveAni->AddAnimatableObject(m_focusImage, IActor::ACTOR_ANI_POSITION);
				m_focusMoveAni->AddAnimatableObject(m_focusImage, IActor::ACTOR_ANI_SIZE);

				m_cursorShowHideAni->AddAnimatableObject(m_focusImage, IActor::ACTOR_ANI_POSITION);
				m_cursorShowHideAni->AddAnimatableObject(m_focusImage, IActor::ACTOR_ANI_SIZE);

				m_loopAni->AddAnimatableObject(m_focusImage, IActor::ACTOR_ANI_SIZE);
			}			

			m_focusImage->SetPosition(m_focusImageOffsetX, m_focusImageOffsetY);
			m_focusImage->SetImage(m_focusImageName.c_str());
			IDeviceManager *dm = IDeviceManager::GetInstance();
			(dm->IsCursorVisible() && !IUtility::GetInstance()->IsHighContrastEnabled()) ? m_focusImage->Hide() : m_focusImage->Show();
		}
	}

	void CDataListControl::SetFocusBarColor(int alpha, int red, int green, int blue)
	{
		m_focusBarColor = new ClutterColor;

		clutter_color_init(m_focusBarColor, red, green, blue, alpha);

		if (NULL != m_focusBar)
		{
			m_focusBar->SetBackgroundColor(*m_focusBarColor);
			m_focusBar->Lower(NULL);
		}
	}

	void CDataListControl::EnlargeFocusedItem(float widthDiff, float heightDiff)
	{
		H_LOG_2_PARAM(FATAL, LOGGER, widthDiff, heightDiff);

		m_enlargeWidth = widthDiff;
		m_enlargeHeight = heightDiff;

		ActorBase::SetClipArea(-widthDiff / 2.0f, -heightDiff / 2.0f, t_listWidth + widthDiff, t_listHeight + heightDiff);

		if (NULL != t_focusedItem && NULL != t_focusedItem->window && true == t_flagShowFocusBar)
		{
			t_ScaleUpFocuedItem(NULL);
		}

		if (NULL != m_focusImage && (NULL == t_focusedItem || NULL == t_focusedItem->renderer || NULL == t_focusedItem->renderer->Thumbnail()))
		{
			float width, height;
			m_focusBar->GetSize(width, height);
			m_focusImage->Resize(width + m_enlargeWidth - 2 * m_focusImageOffsetX, height + m_enlargeHeight - 2 * m_focusImageOffsetY);
		}
	}

	void CDataListControl::GetEnlargeSizeOfFocusedItem(float &widthDiff, float &heightDiff)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);

		widthDiff = m_enlargeWidth;
		heightDiff = m_enlargeHeight;
	}


	void CDataListControl::SetFocusMargin(TMargin margin)
	{
		H_LOG_FATAL(LOGGER, "["<< this <<"]CDataListControl::SetFocusMargin with margin top:" << margin.top << ", bottom:" << margin.bottom << ", left:" << margin.left << ", right:" << margin.right);
	}

	const char* CDataListControl::GetActorType(void)
	{
		return "DataListControl";
	}

	void CDataListControl::EnableShadowEffect(const bool flagShadowEffect)
	{
		H_LOG_1_PARAM(FATAL, LOGGER, flagShadowEffect);

		if (t_flagShadowEffect == flagShadowEffect)
		{
			return;
		}

		t_flagShadowEffect = flagShadowEffect;

		if (t_focusedItem != NULL && t_focusedItem->window != NULL)
		{
			if (t_flagShadowEffect)
			{
				t_focusedItem->window->AddEffect(t_shadowEffect);
			}
			else
			{
				t_focusedItem->window->RemoveEffect(t_shadowEffect);
			}
		}

	}

	bool CDataListControl::IsShadowEffectEnabled(void) const
	{
		H_LOG_0_PARAM(TRACE, LOGGER);

		return t_flagShadowEffect;
	}

	void CDataListControl::EnableFoveaEffect(const bool flagFoveaAni)
	{
		H_LOG_1_PARAM(FATAL, LOGGER, flagFoveaAni);
		m_flagFoveaAni = flagFoveaAni;
	}

	bool CDataListControl::IsFoveaEffectEnabled(void) const
	{
		H_LOG_0_PARAM(TRACE, LOGGER);
		return m_flagFoveaAni;
	}

	void CDataListControl::EnableAutoHighContrast(const bool flagAutoHighContrast)
	{
		H_LOG_1_PARAM(FATAL, LOGGER, flagAutoHighContrast);
		if (t_flagAutoHighContrast == flagAutoHighContrast)
		{
			return;
		}
		
		t_flagAutoHighContrast = flagAutoHighContrast;
	}

	bool CDataListControl::IsAutoHighContrastEnabled(void) const
	{
		return t_flagAutoHighContrast;
	}

	void CDataListControl::EnableDealMouseEvent(const bool flagDeal)
	{
		H_LOG_1_PARAM(FATAL, LOGGER, flagDeal);
		m_flagDealMouseEvent = flagDeal;
	}

	bool CDataListControl::IsControlDealMouseEvent(void) const
	{
		return m_flagDealMouseEvent;
	}

	bool CDataListControl::m_Create(float listWidth, float listHeight)
	{
		ActorBase::SetClipArea(0.0f, 0.0f, listWidth, listHeight);
		EnableReverse(false);

		m_showAreaWindow = IActor::CreateInstance(dynamic_cast<IActor*>(this), listWidth, listHeight);
		m_showAreaWindow->SetClipArea(0.0f, 0.0f, listWidth, listHeight);
		m_showAreaWindow->EnableReverse(false);
		m_showAreaWindow->AddMouseListener(this);
		m_showAreaWindow->Show();

		m_flagLoadItemBeforeScroll = true;

		t_listWidth = listWidth;
		t_listHeight = listHeight;

		t_focusRangeRect.Set(0, 0, listWidth, listHeight);

		t_itemGroup = IActor::CreateInstance(m_showAreaWindow, 0, 0);

		if(t_itemGroup != NULL)
		{
			t_itemGroup->EnableReverse(false);
			t_itemGroup->Show();
		}

		m_focusMoveAni = new CMultiObjectTransition;
		m_focusMoveAni->Initialize();
		m_focusMoveAniListener = new CDataListControlAniListener(this, FOCUS_MOVE_ANI);
		m_focusMoveAni->AddListener(m_focusMoveAniListener, NULL);
		m_RegisterMultiObjTransition(m_focusMoveAni, ITEM_GROUP_POS_TRANS | ITEM_SCALEX_TRANS | ITEM_SCALEY_TRANS);

		m_loopAni = new CMultiObjectTransition;
		m_loopAni->Initialize();
		m_loopAniListener = new CDataListControlAniListener(this, LOOP_ANI);
		m_loopAni->AddListener(m_loopAniListener, NULL);
		m_RegisterMultiObjTransition(m_loopAni, ITEM_GROUP_ALPHA_TRANS | ITEM_GROUP_POS_TRANS | ITEM_SCALEX_TRANS | ITEM_SCALEY_TRANS);

		m_focusShowHideAni = new CMultiObjectTransition;
		m_focusShowHideAni->Initialize();
		m_RegisterMultiObjTransition(m_focusShowHideAni, ITEM_SCALEX_TRANS | ITEM_SCALEY_TRANS);

		m_transStyleAni = new CMultiObjectTransition;
		m_transStyleAni->Initialize();
		m_RegisterMultiObjTransition(m_transStyleAni, ITEM_POSITION_TRANS | ITEM_SIZE_TRANS | ITEM_GROUP_POS_TRANS);
		m_itemStyleAniListener = new CDataListControlAniListener(this, ITEM_STYLE_ANI);
		m_transStyleAni->AddListener(m_itemStyleAniListener, NULL);

		m_itemScrollAni = new CMultiObjectTransition;
		m_itemScrollAni->Initialize();
		m_RegisterMultiObjTransition(m_itemScrollAni, ITEM_GROUP_POS_TRANS | ITEM_SCALEX_TRANS | ITEM_SCALEY_TRANS);
		m_itemScrollAniListener = new CDataListControlAniListener(this, ITEM_SCROLL_ANI);
		m_itemScrollAni->AddListener(m_itemScrollAniListener, NULL);

		m_cursorShowHideAni = new CMultiObjectTransition;
		m_cursorShowHideAni->Initialize();
		m_cursorShowHideAniListener = new CDataListControlAniListener(this, CURSOR_SHOW_HIDE_ANI);
		m_cursorShowHideAni->AddListener(m_cursorShowHideAniListener, NULL);
		m_RegisterMultiObjTransition(m_cursorShowHideAni, ITEM_POSITION_TRANS | ITEM_SIZE_TRANS);

		m_registerAniListener = new CDataListControlAniListener(this, LIST_ANI_TYPE_MAX);

		m_windowRect.Set(0.0f, 0.0f, t_listWidth, t_listHeight);

		m_keyLongPressAction = IKeyLongPressAction::CreateInstance(this);
		if (m_keyLongPressAction != NULL)
		{
			m_keyLongPressAction->AddLongPressKey(CLUTTER_KEY_Return);
			AddAction(m_keyLongPressAction);
			AddKeyLongPressListener(this);
		}

		t_shadowEffect = IShadowEffect::CreateInstance(-15, 35, -30, 30);

		IEventManager *em = IEventManager::GetInstance();
		if (em != NULL)
		{
			em->AddSystemEventListener(this);
		}

		return true;
	}

	bool CDataListControl::t_Initialize(IActor *parent, const TDataListControlAttr &attr)
	{
		m_enlargeWidth = 0;
		m_enlargeHeight = 0;
		m_flagEnableUnload = true;

		t_focusedItem = NULL;
		t_focusedItemBak = NULL;

		ActorBase::Initialize(parent, 0, 0);
		return m_Create(attr.width, attr.height);
	}

	bool CDataListControl::t_Initialize(Widget *parent, const TDataListControlAttr &attr)
	{
		m_enlargeWidth = 0;
		m_enlargeHeight = 0;
		m_flagEnableUnload = true;

		t_focusedItem = NULL;
		t_focusedItemBak = NULL;

		ActorBase::Initialize(parent, 0, 0);
		return m_Create(attr.width, attr.height);
	}

	void CDataListControl::t_SetAnimationDuration(int duration)
	{
		t_SetFocusMoveAniDuration(duration);
	}

	void CDataListControl::t_SetAnimationMode(ClutterAnimationMode mode)
	{
	}

	void CDataListControl::t_RegisterMultiObjTransition(CMultiObjectTransition *trans, long transType)
	{
		HALO_ASSERT(NULL != trans && true == trans->IsInitialized());

		bool flagNewTrans = m_RegisterMultiObjTransition(trans, transType);

		if (true == flagNewTrans)
		{
			trans->AddListener(m_registerAniListener, NULL);
		}
	}

	void CDataListControl::t_TransformLayout(int fromLayout, int toLayout, std::vector<TItem*> itemList, std::vector<TRect> rectList, const TRect &destItemGroupRect, int reason, bool flagAni /* = true */)
	{
		HALO_ASSERT(itemList.size() == rectList.size());

		t_itemGroupRect = destItemGroupRect;

		for (int i = 0; i < (int)rectList.size(); i++)
		{
			TItem *item = itemList[i];
			item->rect = rectList[i];
		}

		t_UpdateInMemoryItems(false, reason);

		for (int i = 0; i < (int)itemList.size(); i++)
		{
			TItem *item = itemList[i];
			t_RefreshItemPosition(item, m_transStyleAni);

			if (NULL != item->window)
			{
				IRenderer *renderer = m_GetRenderer(item, 0);
				renderer->OnTransformStyle((IData*)item->data, item->window, fromLayout, toLayout, item->rect.w, item->rect.h, true, (false == flagAni ? 0 : m_transStyleAni->Duration()));

				IThumbnail *thumb = renderer->Thumbnail();
				if (NULL != thumb)
				{
					thumb->EnableThumbnailStyles(true, item->visibleThumbStyle, false);
					thumb->EnableThumbnailStyles(false, item->disVisibleThumbStyle, false);
				}
			}
		}

		HideFocus(true);

		TValue2f dest = t_GetRealPointBaseItemGroup(t_itemGroupRect, m_windowRect);
		m_transStyleAni->SetDestination(t_itemGroup, IActor::ACTOR_ANI_POSITION, &dest);
		m_transStyleAni->Play();
	}

	bool CDataListControl::t_SetFocusBar(TItem *item, bool flagFocusBarAni, bool flagScrollAni)
	{
		TRect destItemRect;
		TRect destImgRect;

		if (NULL != item)
		{
			destItemRect = item->rect;

			destImgRect.w = destItemRect.w;
			destImgRect.h = destItemRect.h;
		}
		
		return t_SetFocusBar(destImgRect, destItemRect, item, flagFocusBarAni, flagScrollAni);
	}

	bool CDataListControl::t_SetFocusBar(TRect &focusImgRect, TItem *item, bool flagFocusBarAni, bool flagScrollAni)
	{
		return t_SetFocusBar(focusImgRect, item->rect, item, flagFocusBarAni, flagScrollAni);
	}

	bool CDataListControl::t_SetFocusBar(TRect &focusImgRect, TRect &focusItemRect, TItem *item, bool flagFocusBarAni, bool flagScrollAni, TValue2f *newItemGroupPos /* = NULL */)
	{
		if (true == t_IsOnAnimation(ITEM_STYLE_ANI | LOOP_ANI))
		{
			return false;
		}

		if (NULL != newItemGroupPos)
		{
			if (newItemGroupPos->val[0] != t_itemGroupRect.x || newItemGroupPos->val[1] != t_itemGroupRect.y)
			{
				if (newItemGroupPos->val[0] + focusItemRect.x < t_focusRangeRect.x || newItemGroupPos->val[0] + focusItemRect.x + focusItemRect.w > t_focusRangeRect.x + t_focusRangeRect.w
					||
					newItemGroupPos->val[1] + focusItemRect.y < t_focusRangeRect.y || newItemGroupPos->val[1] + focusItemRect.y + focusItemRect.h > t_focusRangeRect.y + t_focusRangeRect.h)
				{
					return false;
				}

				if (newItemGroupPos->val[0] > t_focusRangeRect.x || newItemGroupPos->val[0] + t_itemGroupRect.w < t_focusRangeRect.x + t_focusRangeRect.w
					||
					newItemGroupPos->val[1] > t_focusRangeRect.y || newItemGroupPos->val[1] + t_itemGroupRect.h < t_focusRangeRect.y + t_focusRangeRect.h)
				{
					newItemGroupPos = NULL;
				}
			}
		}

		if (NULL == m_focusBar)
		{
			m_focusBar = IActor::CreateInstance(t_itemGroup, focusImgRect.w, focusImgRect.h);

			if(m_focusBar != NULL)
			{
				m_focusBar->EnableReverse(false);

				m_focusShowHideAni->AddAnimatableObject(m_focusBar, IActor::ACTOR_ANI_ALPHA);

				m_focusMoveAni->AddAnimatableObject(m_focusBar, IActor::ACTOR_ANI_POSITION);
				m_focusMoveAni->AddAnimatableObject(m_focusBar, IActor::ACTOR_ANI_SIZE);
				m_focusMoveAni->AddAnimatableObject(m_focusBar, IActor::ACTOR_ANI_ALPHA);

				m_loopAni->AddAnimatableObject(m_focusBar, IActor::ACTOR_ANI_POSITION);
				m_loopAni->AddAnimatableObject(m_focusBar, IActor::ACTOR_ANI_SIZE);
				m_loopAni->AddAnimatableObject(m_focusBar, IActor::ACTOR_ANI_ALPHA);

				m_focusBar->SetAlpha(0);
				m_focusBar->Show();

				if (NULL == m_focusBarColor)
				{
					m_focusBar->Raise(NULL);
				}
			}

			if (NULL != m_focusBarColor)
			{
				m_focusBar->SetBackgroundColor(*m_focusBarColor);
			}
			else
			{
				if (NULL == m_focusImage)
				{
					if (!m_focusImageName.empty())
					{
						SetFocusImage(m_focusImageName.c_str(), m_focusImageOffsetX, m_focusImageOffsetY);
					}
				}
			}
		}

		if (false == t_flagShowFocusBar)
		{
			t_focusedItemBak = item;

			if (NULL == m_focusImgRectBak)
			{
				m_focusImgRectBak = new TRect;
				HALO_ASSERT(NULL != m_focusImgRectBak);
			}
			
			if (NULL == m_focusItemRectBak)
			{
				m_focusItemRectBak = new TRect;
				HALO_ASSERT(NULL != m_focusItemRectBak);
			}

			*m_focusImgRectBak = focusImgRect;
			*m_focusItemRectBak = focusItemRect;

			if (NULL != newItemGroupPos)
			{
				if (NULL == m_itemGroupPosBak)
				{
					m_itemGroupPosBak = new TValue2f;
				}
				
				*m_itemGroupPosBak = *newItemGroupPos;
			}
			
		}
		else
		{
			CTFocusChangeInfo focusChangeInfo(t_focusedItem, item);
			m_focusQueue.push_back(focusChangeInfo);

			bool flagScrollItem = false;

			if (NULL != item)
			{
				flagScrollItem = m_SetFocus(item, focusImgRect, focusItemRect, newItemGroupPos);
			}

			if (t_focusedItem != item)
			{
				if (NULL != t_focusedItem && NULL != t_focusedItem->window)
				{
					t_ScaleDownFocuedItem(m_focusMoveAni);
				}

				t_focusedItem = item;

				if (NULL != t_focusedItem && NULL != t_focusedItem->window)
				{
					float w, h;
					t_focusedItem->window->GetSize(w, h);

					t_ScaleUpFocuedItem(m_focusMoveAni);
				}
			}

			if (NULL != m_focusBar && true == m_focusBar->FlagShow() && NULL == m_focusBarColor)
			{
				m_focusBar->Raise(NULL);
			}

			bool flagAni = true;

			if (true == flagScrollItem)
			{
				flagAni = flagScrollAni;
				
				//if the list going to scroll, stop the timer and show the scroll bar.
				m_StopScrollBarAlphaOutTimer();			
				m_ShowScrollBar(true);
			}
			else
			{
				flagAni = flagFocusBarAni;
			}

			if (false == flagAni)
			{
				m_focusMoveAni->JumpToDestination();
			}
			else
			{
				m_focusMoveAni->Play();
			}
		}

		return true;
	}

	void CDataListControl::t_SetVisibleArea(TRect visibleAreaRect, IActor *rectBaseOn)
	{
		std::map<IActor*, TPoint> rootTree;

		float offsetX = 0.0f, offsetY = 0.0f;
		GetPosition(offsetX, offsetY);

		for (IActor *curWindow = Parent(); NULL != curWindow; curWindow = curWindow->Parent())
		{
			TPoint point(offsetX, offsetY);
			rootTree.insert(std::make_pair(curWindow, point));

			float x, y;
			curWindow->GetPosition(x, y);

			offsetX += x;
			offsetY += y;
		}

		rectBaseOn->GetPosition(offsetX, offsetY);

		for (IActor *curWindow = rectBaseOn->Parent(); NULL != curWindow; curWindow = curWindow->Parent())
		{
			if (rootTree.find(curWindow) != rootTree.end())
			{
				TPoint point = rootTree[curWindow];
				offsetX -= point.x;
				offsetY -= point.y;

				break;
			}
			else
			{
				float x, y;
				curWindow->GetPosition(x, y);

				offsetX += x;
				offsetY += y;
			}
		}

		m_windowRect.x = visibleAreaRect.x + offsetX;
		m_windowRect.y = visibleAreaRect.y + offsetY;
		m_windowRect.w = visibleAreaRect.w;
		m_windowRect.h = visibleAreaRect.h;
	}

	void CDataListControl::t_UpdateInMemoryItems(bool flagUnloadRightNow, int reason /*= -1*/)
	{
		m_UpdateInMemoryItems(flagUnloadRightNow, true, true, reason);
		//m_UpdateInMemoryItems(true, true, true, reason);
	}

	void CDataListControl::t_SetItemGroupSize(float width, float height)
	{
		t_itemGroupRect.w = width;
		t_itemGroupRect.h = height;

		TValue2f realValue = t_GetRealPointBaseItemGroup(t_itemGroupRect, m_windowRect);
		t_itemGroup->SetPosition(realValue.val[0], realValue.val[1]);
	}

	void CDataListControl::t_RefreshItemPosition(TItem *item, CMultiObjectTransition *trans /* = NULL */)
	{
		TValue2f realValue = t_GetRealPointBaseItemGroup(item->rect, t_itemGroupRect);

		if (NULL != item->window_bg)
		{
			if (NULL == trans)
			{
				item->window_bg->SetPosition(realValue.val[0], realValue.val[1]);
			}
			else
			{
				TValue2f dest(realValue.val[0], realValue.val[1]);
				trans->SetDestination(item->window_bg, IActor::ACTOR_ANI_POSITION, &dest);
			}

			float w, h;
			item->window_bg->GetSize(w, h);

			if (w != item->rect.w || h != item->rect.h)
			{
				if (NULL == trans)
				{
					item->window_bg->Resize(item->rect.w, item->rect.h);
				}
				else
				{
					TValue2f dest(item->rect.w, item->rect.h);
					trans->SetDestination(item->window_bg, IActor::ACTOR_ANI_SIZE, &dest);
				}

				IData *data = (IData*)(item->data);
				ClutterSize destSize;
				destSize.width = item->rect.w;
				destSize.height = item->rect.h;
				m_GetRenderer(item, 1)->Resize(data, item->window_bg, destSize, true, (NULL == trans ? 0 : trans->Duration()));
			}
		}

		if (NULL != item->window)
		{
			if (NULL == trans)
			{
				item->window->SetPosition(realValue.val[0], realValue.val[1]);
			}
			else
			{
				TValue2f dest(realValue.val[0], realValue.val[1]);
				trans->SetDestination(item->window, IActor::ACTOR_ANI_POSITION, &dest);
			}

			float w, h;
			item->window->GetSize(w, h);

			if (w != item->rect.w || h != item->rect.h)
			{
				if (NULL == trans)
				{
					item->window->Resize(item->rect.w, item->rect.h);
				}
				else
				{
					TValue2f dest(item->rect.w, item->rect.h);
					trans->SetDestination(item->window, IActor::ACTOR_ANI_SIZE, &dest);
				}

				IData *data = (IData*)(item->data);
				ClutterSize destSize;
				destSize.width = item->rect.w;
				destSize.height = item->rect.h;
				m_GetRenderer(item, 0)->Resize(data, item->window, destSize, true, (NULL == trans ? 0 : trans->Duration()));
			}

			int alpha = item->window->Alpha();
			if (alpha != item->alpha)
			{
				if (NULL == trans)
				{
					item->window->SetAlpha(item->alpha);
				}
				else
				{
					TValue1i dest(item->alpha);
					trans->SetDestination(item->window, IActor::ACTOR_ANI_ALPHA, &dest);
				}
			}
		}
	}

	bool CDataListControl::t_FadeInOut(TItem *item, TRect &focusImgDest,
					TPoint &focusBarOutOffset, TPoint &itemGroupOutOffset,
					bool flagAni/* = true*/)
	{
		if (true == t_IsOnAnimation(ITEM_STYLE_ANI | FOCUS_MOVE_ANI | LOOP_ANI))
		{
			return false;
		}

		if (false == flagAni)
		{
			return t_SetFocusBar(focusImgDest, item, flagAni, flagAni);
		}
		else
		{
			if (NULL != m_focusBar)
			{
				m_focusBar->SetParent(m_showAreaWindow);

				if (NULL == m_focusBarColor)
				{
					m_focusBar->Raise(NULL);
				}
				else
				{
					m_focusBar->Lower(NULL);
				}
			}

			TRect focusRectBaseOnRoot = m_focusItemRect;
			focusRectBaseOnRoot.x += t_itemGroupRect.x;
			focusRectBaseOnRoot.y += t_itemGroupRect.y;

			TValue2f realValue = t_GetRealPointBaseItemGroup(focusRectBaseOnRoot, m_windowRect);

			if (NULL != m_focusBar)
			{
				m_focusBar->SetPosition(realValue.val[0], realValue.val[1]);
			}

			m_fadeInInfo.focusImgEnd = focusImgDest;

			TRect m_focusFadeOutDestRect = m_focusItemRect;
			m_focusFadeOutDestRect.x = m_focusItemRect.x + focusBarOutOffset.x + t_itemGroupRect.x;
			m_focusFadeOutDestRect.y = m_focusItemRect.y + focusBarOutOffset.y + t_itemGroupRect.y;

			TPoint itemFadeOutDest;
			itemFadeOutDest.Set(t_itemGroupRect.x, t_itemGroupRect.y);
			itemFadeOutDest.x = t_itemGroupRect.x + itemGroupOutOffset.x;
			itemFadeOutDest.y = t_itemGroupRect.y + itemGroupOutOffset.y;

			TPoint itemGroupPos;
			m_fadeInInfo.flagItemScroll = m_GetItemGroupRect(item->rect, itemGroupPos);
			t_itemGroupRect.x = itemGroupPos.x;
			t_itemGroupRect.y = itemGroupPos.y;

			TRect focusBarDest = item->rect;
			focusBarDest.x += t_itemGroupRect.x;
			focusBarDest.y += t_itemGroupRect.y;

			m_fadeInInfo.focusItemStart = focusBarDest;
			m_fadeInInfo.focusItemStart.x = focusBarDest.x - focusBarOutOffset.x;
			m_fadeInInfo.focusItemStart.y = focusBarDest.y - focusBarOutOffset.y;

			m_fadeInInfo.focusItemEnd = focusBarDest;

			if (true == m_fadeInInfo.flagItemScroll)
			{
				m_fadeInInfo.itemStart.x = t_itemGroupRect.x - itemGroupOutOffset.x;
				m_fadeInInfo.itemStart.y = t_itemGroupRect.y - itemGroupOutOffset.y;
			}
			else
			{
				m_fadeInInfo.itemStart.x = t_itemGroupRect.x;
				m_fadeInInfo.itemStart.y = t_itemGroupRect.y;
			}

			CTFocusChangeInfo focusChangeInfo(t_focusedItem, item);
			m_focusQueue.push_back(focusChangeInfo);

			m_focusItemRect = item->rect;
			
			t_ScaleDownFocuedItem(m_loopAni);

			m_UpdateInMemoryItems(false, true, true);
			m_FadeOut(m_focusFadeOutDestRect, itemFadeOutDest);

			//m_focusedItem->pOwner->ScaleDownWindow(m_aniDuration);
			t_focusedItem = item;
		}

		return true;
	}

	bool CDataListControl::m_SetFocus(TItem *destItem, TRect focusImgRect, TRect focusItemRect, TValue2f *newItemGroupPos)
	{
		bool flagResizeFocusImg = false;

		if (m_focusImgRect.w != focusImgRect.w || m_focusImgRect.h != focusImgRect.h)
		{
			flagResizeFocusImg = true;
		}

		m_focusImgRect = focusImgRect;
		m_focusItemRect = focusItemRect;

		focusImgRect.x += focusItemRect.x;
		focusImgRect.y += focusItemRect.y;

		TValue2f destPoint = t_GetRealPointBaseItemGroup(focusImgRect, t_itemGroupRect);
		bool flagScrollItem = false;

		if (NULL != newItemGroupPos)
		{
			flagScrollItem = true;
			t_itemGroupRect.x = newItemGroupPos->val[0];
			t_itemGroupRect.y = newItemGroupPos->val[1];
		}
		else
		{
			TPoint itemGroupPos(t_itemGroupRect.x, t_itemGroupRect.y);
			flagScrollItem = m_GetItemGroupRect(focusItemRect, itemGroupPos);

			t_itemGroupRect.x = itemGroupPos.x;
			t_itemGroupRect.y = itemGroupPos.y;
		}

		TValue2f destItemGroupPoint = t_GetRealPointBaseItemGroup(t_itemGroupRect, m_windowRect);

		if (true == flagScrollItem)
		{
			m_UpdateInMemoryItems(false, true, true);
			m_focusMoveAni->SetDestination(t_itemGroup, IActor::ACTOR_ANI_POSITION, &destItemGroupPoint);
		}

		if (true == flagResizeFocusImg)
		{
			TValue2f val;

			if (NULL != destItem && NULL != destItem->renderer && NULL != destItem->renderer->Thumbnail())
			{
				val.Set(focusImgRect.w, focusImgRect.h);
				m_focusMoveAni->SetDestination(m_focusBar, IActor::ACTOR_ANI_SIZE, &val);
			}
			else
			{
				val.Set(focusImgRect.w + m_enlargeWidth, focusImgRect.h + m_enlargeHeight);
				m_focusMoveAni->SetDestination(m_focusBar, IActor::ACTOR_ANI_SIZE, &val);
			}

			if (NULL != m_focusImage)
			{
				if (NULL != destItem && NULL != destItem->renderer && NULL != destItem->renderer->Thumbnail())
				{
					val.Set(focusImgRect.w - m_focusImageOffsetX - m_focusImageOffsetX, focusImgRect.h - m_focusImageOffsetY - m_focusImageOffsetY);
				}
				else
				{
					val.Set(focusImgRect.w + m_enlargeWidth - m_focusImageOffsetX - m_focusImageOffsetX, focusImgRect.h + m_enlargeHeight - m_focusImageOffsetY - m_focusImageOffsetY);
				}

				m_focusMoveAni->SetDestination(m_focusImage, IActor::ACTOR_ANI_SIZE, &val);
			}
		}

		if (NULL == destItem || NULL == destItem->renderer || NULL == destItem->renderer->Thumbnail())
		{
			destPoint.val[0] -= m_enlargeWidth / 2.0f;
			destPoint.val[1] -= m_enlargeHeight / 2.0f;
		}

		m_focusMoveAni->SetDestination(m_focusBar, IActor::ACTOR_ANI_POSITION, &destPoint);

		return flagScrollItem;
	}

	bool CDataListControl::m_GetItemGroupRect(TRect &focusItemRect, TPoint &destRect)
	{
		bool flagItemGroupNeedScroll = false;

		TRect focusBarRectBaseOnList = focusItemRect;
		focusBarRectBaseOnList.x += t_itemGroupRect.x;
		focusBarRectBaseOnList.y += t_itemGroupRect.y;

		destRect.Set(t_itemGroupRect.x, t_itemGroupRect.y);

		if (focusBarRectBaseOnList.x < t_focusRangeRect.x)
		{
			destRect.x += t_focusRangeRect.x - focusBarRectBaseOnList.x;
			flagItemGroupNeedScroll = true;
		}
		else if (focusBarRectBaseOnList.x + focusBarRectBaseOnList.w > t_focusRangeRect.x + t_focusRangeRect.w)
		{
			destRect.x += (t_focusRangeRect.x + t_focusRangeRect.w) - (focusBarRectBaseOnList.x + focusBarRectBaseOnList.w);
			flagItemGroupNeedScroll = true;
		}

		if (focusBarRectBaseOnList.y < t_focusRangeRect.y)
		{
			destRect.y += t_focusRangeRect.y - focusBarRectBaseOnList.y;
			flagItemGroupNeedScroll = true;
		}
		else if (focusBarRectBaseOnList.y + focusBarRectBaseOnList.h > t_focusRangeRect.y + t_focusRangeRect.h)
		{
			destRect.y += (t_focusRangeRect.y + t_focusRangeRect.h) - (focusBarRectBaseOnList.y + focusBarRectBaseOnList.h);
			flagItemGroupNeedScroll = true;
		}

		return flagItemGroupNeedScroll;
	}

	void CDataListControl::m_FadeOut(TRect &focusItemDest, TPoint &itemDest)
	{
		m_listStatus = STATUS_FADE_OUT;

		TValue1i destAlpha(0);
		m_loopAni->SetDestination(m_focusBar, IActor::ACTOR_ANI_ALPHA, &destAlpha);

		TValue2f realValue = t_GetRealPointBaseItemGroup(focusItemDest, m_windowRect);
		m_loopAni->SetDestination(m_focusBar, IActor::ACTOR_ANI_POSITION, &realValue);

		if (true == m_fadeInInfo.flagItemScroll)
		{
			m_loopAni->SetDestination(t_itemGroup, IActor::ACTOR_ANI_ALPHA, &destAlpha);

			TRect itemFadeOutDestRect(itemDest.x, itemDest.y, t_itemGroupRect.w, t_itemGroupRect.h);
			realValue = t_GetRealPointBaseItemGroup(itemFadeOutDestRect, m_windowRect);
			m_loopAni->SetDestination(t_itemGroup, IActor::ACTOR_ANI_POSITION, &realValue);
		}

		m_loopAni->Play();
	}

	void CDataListControl::m_FadeIn(bool flagAni)
	{
		m_ItemGroupFadeIn();
		m_FocusBarFadeIn();

		if (true == flagAni)
		{
			m_loopAni->Play();
		}
		else
		{
			m_loopAni->JumpToDestination();
		}
	}

	void CDataListControl::m_FocusBarFadeIn(void)
	{
		TRect focusBarStart = m_fadeInInfo.focusItemStart;
		TRect focusBarEnd = m_fadeInInfo.focusItemEnd;
		TRect focusImgEnd = m_fadeInInfo.focusImgEnd;

		TValue2f realValue = t_GetRealPointBaseItemGroup(focusBarStart, m_windowRect);

		if (NULL != m_focusBar)
		{
			m_focusBar->SetPosition(realValue.val[0], realValue.val[1]);
		}

		realValue = t_GetRealPointBaseItemGroup(focusBarEnd, m_windowRect);
		m_loopAni->SetDestination(m_focusBar, IActor::ACTOR_ANI_POSITION, &realValue);

		TValue1i destAlpha(255);
		m_loopAni->SetDestination(m_focusBar, IActor::ACTOR_ANI_ALPHA, &destAlpha);

		if (m_focusImgRect.w != focusImgEnd.w || m_focusImgRect.h != focusImgEnd.h)
		{
			m_focusImgRect.w = focusImgEnd.w;
			m_focusImgRect.h = focusImgEnd.h;

			TValue2f destFocusSize(focusImgEnd.w, focusImgEnd.h);
			m_loopAni->SetDestination(m_focusBar, IActor::ACTOR_ANI_SIZE, &destFocusSize);

			if (NULL != m_focusImage)
			{
				if (NULL != t_focusedItem && NULL != t_focusedItem->renderer && NULL != t_focusedItem->renderer->Thumbnail())
				{
					destFocusSize.Set(focusImgEnd.w - m_focusImageOffsetX - m_focusImageOffsetX, focusImgEnd.h - m_focusImageOffsetY - m_focusImageOffsetY);
				}
				else
				{
					destFocusSize.Set(focusImgEnd.w + m_enlargeWidth - m_focusImageOffsetX - m_focusImageOffsetX, focusImgEnd.h + m_enlargeHeight - m_focusImageOffsetY - m_focusImageOffsetY);
				}

				m_loopAni->SetDestination(m_focusImage, IActor::ACTOR_ANI_SIZE, &destFocusSize);
			}
		}

		t_ScaleUpFocuedItem(m_loopAni);
	}

	void CDataListControl::m_ItemGroupFadeIn(void)
	{
		TPoint &itemStart = m_fadeInInfo.itemStart;

		TRect itemGroupRect(itemStart.x, itemStart.y, t_itemGroupRect.w, t_itemGroupRect.h);

		TValue2f realValue = t_GetRealPointBaseItemGroup(itemGroupRect, m_windowRect);
		t_itemGroup->SetPosition(realValue.val[0], realValue.val[1]);

		realValue = t_GetRealPointBaseItemGroup(t_itemGroupRect, m_windowRect);

		m_loopAni->SetDestination(t_itemGroup, IActor::ACTOR_ANI_POSITION, &realValue);

		TValue1i destAlpha(255);
		m_loopAni->SetDestination(t_itemGroup, IActor::ACTOR_ANI_ALPHA, &destAlpha);
	}

	void CDataListControl::m_UpdateInMemoryItems(bool flagUnloadRightNow, bool flagLoadRightNow, bool flagNoChangeNotifyRightNow, int reason /* = -1 */)
	{
		std::set<int> visibleItems;

		TRect windowRect;

		if ((int)SCROLL_ITEMGROUP == reason)
		{
			float x, y;
			t_itemGroup->GetPosition(x, y);

			TRect realItemGroupRect(x, y, t_itemGroupRect.w, t_itemGroupRect.h);
			TValue2f logicalPos = t_GetLogicalPosition(realItemGroupRect, m_windowRect);

			windowRect.Set(-logicalPos.val[0], -logicalPos.val[1], (float)t_listWidth, (float)t_listHeight);
		}
		else
		{
			windowRect.Set(-t_itemGroupRect.x, -t_itemGroupRect.y, (float)t_listWidth, (float)t_listHeight);
		}

		std::vector<TItem*> loadItem;
		std::vector<TItem*> unloadItem;
		std::vector<TItem*> scrollItem;

		t_GetInMemoryItems(m_lastVisibleArea, windowRect, loadItem, unloadItem, scrollItem, reason);
		m_lastVisibleArea = windowRect;

		CTScrollInfo *info = NULL;

		if (false == flagUnloadRightNow || false == flagLoadRightNow || false == flagNoChangeNotifyRightNow)
		{
			info = new CTScrollInfo;
			info->reason = reason;
			info->itemGroupPos.Set(t_itemGroupRect.x, t_itemGroupRect.y);
		}

		for (int i = 0; i < (int)unloadItem.size(); i++)
		{
			TItem *item = unloadItem[i];

			if (true == flagUnloadRightNow)
			{
				t_UnloadItem(item);
			}
			else
			{
				info->unloadItems.push_back(item);
			}
		}

		for (int i = 0; i < (int)loadItem.size(); i++)
		{
			TItem *item = loadItem[i];

			if (true == flagLoadRightNow)
			{
				t_LoadItem(item, reason);
			}
			else
			{
				info->loadItems.push_back(item);
			}
		}

		for (int i = 0; i < (int)scrollItem.size(); i++)
		{
			TItem *item = scrollItem[i];

			if (true == flagNoChangeNotifyRightNow)
			{
				t_OnItemInMemoryScrolled(item);
			}
			else
			{
				info->scrollItems.push_back(item);
			}
		}

		if (NULL != info)
		{
			m_scrollInfoQueue.push_back(info);
		}
	}

	void CDataListControl::m_DealScrollEventQueue(int dealEventCount)
	{
		CTScrollInfo *destScrollInfo = NULL;
		for (; false == m_scrollInfoQueue.empty() && 0 < dealEventCount; dealEventCount--)
		{
			if (NULL != destScrollInfo)
			{
				delete destScrollInfo;
			}
			
			destScrollInfo = m_scrollInfoQueue.front();

			int unloadItemCnt = destScrollInfo->unloadItems.size();

			for (int i = 0; i < unloadItemCnt; i++)
			{
				t_UnloadItem(destScrollInfo->unloadItems[i]);
			}
			destScrollInfo->unloadItems.clear();

			int loadItemCnt = destScrollInfo->loadItems.size();
			for (int i = 0; i < loadItemCnt; i++)
			{
				t_LoadItem(destScrollInfo->loadItems[i], destScrollInfo->reason);
			}
			destScrollInfo->loadItems.clear();

			int scrollItemCnt = destScrollInfo->scrollItems.size();
			for (int i = 0; i < scrollItemCnt; i++)
			{
				t_OnItemInMemoryScrolled(destScrollInfo->scrollItems[i]);
			}
			destScrollInfo->scrollItems.clear();

			m_scrollInfoQueue.pop_front();
		}

		if (NULL != destScrollInfo)
		{
			if (NULL != m_scrollBar)
			{
				float ratio;

				if (TYPE_HORIZONTAL == m_scrollBar->DirectionType())
				{
					ratio = -destScrollInfo->itemGroupPos.val[0] / (t_itemGroupRect.w - t_listWidth);
				}
				else
				{
					ratio = -destScrollInfo->itemGroupPos.val[1] / (t_itemGroupRect.h - t_listHeight);
				}

				int destValue = (int)((m_scrollBar->MaxValue() - m_scrollBar->MinValue()) * ratio);
				m_scrollBar->SetValue(destValue);

				m_StartScrollBarAlphaOutTimer();
			}

			delete destScrollInfo;
		}
	}

	void CDataListControl::m_OnFocusMoveAniEvent(EAniEventType eventType, void *detail)
	{
		switch (eventType)
		{
		case ANI_STOP:
			{
				if (true == m_flagShowHidingFocusBar)
				{
					m_flagShowHidingFocusBar = false;
				}
				
				int scrollInfoQueueSize = (int)m_scrollInfoQueue.size();
				int focusQueueSize = m_focusQueue.size();
				for (int i = 0; i < focusQueueSize; i++)
				{
					CTFocusChangeInfo changeInfo = m_focusQueue.front();
					m_focusQueue.pop_front();

					TItem *from = changeInfo.from;
					TItem *to = changeInfo.to;
					m_FocusChangeFinish(from, to);
				}

				if (false == t_IsOnAnimation(ITEM_STYLE_ANI))
				{
					m_DealScrollEventQueue(scrollInfoQueueSize);
				}
				IDeviceManager *dm = IDeviceManager::GetInstance();
				if (dm->IsCursorVisible() && !IUtility::GetInstance()->IsHighContrastEnabled())
				{
					if (m_focusImage)
					{
						m_focusImage->Hide();
					}
				}
			}
			break;

		case ANI_START:
			{
				if (!m_focusQueue.empty())
				{
					m_FocusChangeStart(m_focusQueue.front().from, m_focusQueue.front().to);
				}
						  
				break;
			}

		case ANI_VIA:
			{
				if(!m_focusQueue.empty())
				{
					CTFocusChangeInfo changeInfo = m_focusQueue.front();
					m_focusQueue.pop_front();

					TItem *from = changeInfo.from;
					TItem *to = changeInfo.to;
					m_FocusChangeFinish(from, to);

					if (false == m_focusQueue.empty())
					{
						m_FocusChangeStart(m_focusQueue.front().from, m_focusQueue.front().to);
					}
				}
			}
			break;

		default:
			break;
		}
	}

	void CDataListControl::m_OnLoopAniEvent(EAniEventType eventType, void *detail)
	{
		switch (eventType)
		{
		case ANI_STOP:
			{
				bool flagFinish = *((bool*)detail);

				if (true == flagFinish)
				{
					if (STATUS_FADE_OUT == m_listStatus)
					{
						m_listStatus = STATUS_FADE_IN;
						m_FadeIn(true);
					} 
					else
					{
						HALO_ASSERT(STATUS_FADE_IN == m_listStatus);
						m_DealScrollEventQueue((int)m_scrollInfoQueue.size());

						TRect focusRect = m_fadeInInfo.focusItemEnd;
						TRect focusImgEnd = m_fadeInInfo.focusImgEnd;

						if (NULL != m_focusBar)
						{
							m_focusBar->SetParent(t_itemGroup);

							if (NULL == m_focusBarColor)
							{
								m_focusBar->Raise(NULL);
							}
							else
							{
								m_focusBar->Lower(NULL);
							}

							focusRect.x += focusImgEnd.x - t_itemGroupRect.x;
							focusRect.y += focusImgEnd.y - t_itemGroupRect.y;

							TValue2f realPos = t_GetRealPointBaseItemGroup(focusRect, t_itemGroupRect);
							m_focusBar->SetPosition(realPos.val[0], realPos.val[1]);
						}

						m_listStatus = STATUS_NORMAL;

						int focusQueueSize = m_focusQueue.size();
						for (int i = 0; i < focusQueueSize; i++)
						{
							CTFocusChangeInfo changeInfo = m_focusQueue.front();
							m_focusQueue.pop_front();

							TItem *from = changeInfo.from;
							TItem *to = changeInfo.to;
							m_FocusChangeFinish(from, to);
						}
					}
				}
				else
				{
					if (STATUS_FADE_OUT == m_listStatus)
					{
						m_listStatus = STATUS_FADE_IN;
					}
					
					m_FadeIn(false);
				}
			}
			break;

		case ANI_START:
			{
				if (STATUS_FADE_OUT == m_listStatus)
				{
					m_FocusChangeStart(m_focusQueue.front().from, m_focusQueue.front().to);
				}
				break;	
			}
			break;

		case ANI_VIA:
			{
			}
			break;

		default:
			break;
		}
	}

	void CDataListControl::m_OnItemScrollAni(EAniEventType eventType, void *detail)
	{
		switch (eventType)
		{
		case ANI_NEWFRAME:
			{
				m_UpdateInMemoryItems(true, true, true, SCROLL_ITEMGROUP);
			}
			break;

		case ANI_FINISH:
			{
				m_UpdateInMemoryItems(true, true, true, SCROLL_ITEMGROUP);

				if (true == t_flagShowFocusAfterScroll)
				{
					t_flagShowFocusAfterScroll = false;
					ShowFocus(true);
				}
				break;
			}

		case ANI_START:
			{
				if (true == t_flagShowFocusBar)
				{
					t_flagShowFocusAfterScroll = true;
					HideFocus(false);
				}
				break;
			}

		case ANI_STOP:
			{
				if (STATUS_FADE_OUT != m_listStatus && STATUS_FADE_IN != m_listStatus)
				{
					float x, y;
					t_itemGroup->GetPosition(x, y);

					if (x != t_itemGroupRect.x || y != t_itemGroupRect.y)
					{
						t_itemGroupRect.x = x;
						t_itemGroupRect.y = y;
					}
				}

				if (true == t_flagShowFocusAfterScroll)
				{
					t_flagShowFocusAfterScroll = false;
					ShowFocus(false);
				}
				break;
			}

		default:
			break;
		}
	}

	void CDataListControl::m_OnCursorShowHideAniEvent(EAniEventType eventType, void *detail)
	{
		switch (eventType)
		{
		case ANI_START:
			break;
		case ANI_STOP:
			{
				IDeviceManager *dm = IDeviceManager::GetInstance();
				if (dm->IsCursorVisible() && !IUtility::GetInstance()->IsHighContrastEnabled())
				{
					if (m_focusImage)
					{
						m_focusImage->Hide();
					}
				}
				else
				{
					if (NULL != t_focusedItem && NULL != t_focusedItem->renderer && NULL != t_focusedItem->renderer->Thumbnail())
					{
						IThumbnail *thumb = t_focusedItem->renderer->Thumbnail();
						// Stop Auto scroll of lost focus item
						if (thumb->VisibleThumbnailStyles() & IThumbnail::THUMB_STYLE_TEXT)
						{
							thumb->EnableAttachTextAutoScroll(true);
						}
						if (thumb->VisibleThumbnailStyles() & IThumbnail::THUMB_STYLE_INFO)
						{
							int infoTextNum = thumb->InformationTextNumber();
							for (int i = 0; i < infoTextNum; i++)
							{
								thumb->EnableInformationTextAutoScroll(i, true);
							}
						}
					}
				}

			}
			break;
		default:
			break;
		}

	}


	void CDataListControl::t_UnloadItem(TItem *item)
	{
		t_OnItemDataUnload(item);
		t_inMemoryItemSet.erase(item);

		if (NULL == item->window)
		{
			return;
		}

		if (true == m_flagEnableUnload)
		{
			item->window->ScaleTo(1.0f, 1.0f, NULL);
			item->window->Hide();
			item->window->SetOwner(NULL);
			m_windowQueue.push_back(item->window);
			if (NULL != item->window_bg)
			{
				m_windowQueue.push_back(item->window_bg);
			}

			IData *data = (IData*)(item->data);
			if (item->renderer != NULL)
			{
				data->curUsingSubData = 0;
				item->renderer->Draw(data, item->window, IRenderer::UNLOAD_DATA_DRAW);

				IThumbnail *thumb = item->renderer->Thumbnail();
				if (NULL != thumb)
				{
					item->flagCheckBoxSelected = thumb->IsChecked();
				}

				delete item->renderer;
				item->renderer = NULL;
			}
			if (item->renderer_bg != NULL)
			{
				data->curUsingSubData = 1;
				item->renderer_bg->Draw(data, item->window, IRenderer::UNLOAD_DATA_DRAW);

				delete item->renderer_bg;
				item->renderer_bg = NULL;
			}

			item->window = NULL;
			item->window_bg = NULL;
		}
	}

	void CDataListControl::t_LoadItem(TItem *item, int reason)
	{
		t_inMemoryItemSet.insert(item);
		//HALO_ASSERT(NULL == item->window);
		if (item->window != NULL)
		{
			return;
		}

		if (item->data == NULL)
		{
			return;
		}
		
		item->window = m_GetWindow(item, reason);
		item->window->Show();

		IData *data = (IData*)(item->data);

		if (2 == data->NumOfWindow())
		{
			item->window_bg = m_GetWindow(item, reason);
			item->window_bg->Show();
			item->window_bg->SetAlpha(0);
		}

		if (data->IsReady())
		{
			for (int i = 0; i < data->NumOfWindow(); i++)
			{
				data->curUsingSubData = i;

				IRenderer *renderer = m_GetRenderer(item, i);
				renderer->Draw(data, item->window, IRenderer::LOAD_DATA_DRAW);
			}
		}
		else
		{
			switch (data->DataLoadType())
			{
			case IData::E_LOAD_TYPE_SYNC:
				//m_Listener->IfDataLoaded(this, data, singleItem->index);
				t_OnItemDataSyncLoad(item);

				if (2 == data->NumOfWindow())
				{
					IData *realData = (IData*)data;
					realData->curUsingSubData = 0;
				}

				for (int i = 0; i < data->NumOfWindow(); i++)
				{
					data->curUsingSubData = i;

					if (0 == i)
					{
						m_GetRenderer(item, i)->Draw(data, item->window, IRenderer::LOAD_DATA_DRAW);
					}
					else
					{
						m_GetRenderer(item, i)->Draw(data, item->window_bg, IRenderer::LOAD_DATA_DRAW);
					}
				}
				t_OnRendererDraw(item);
				break;
			case IData::E_LOAD_TYPE_ASYNC:
			{
				IAsyncTask *asyncTask = IAsyncTask::CreateInstance(item);
				if (NULL != asyncTask)
				{
					m_asyncTaskMap.insert(std::make_pair(item, (CAsyncTask*)asyncTask));
					//CAsyncTaskListener *listener = new CAsyncTaskListener(this);
					//asyncTask->SetTaskListener(listener);
					asyncTask->SetTaskListener(this);
					asyncTask->Execute();
				}
				break;
			}
			case IData::E_LOAD_TYPE_SYNC_ASYNC:
			{	
				t_OnItemDataSyncLoad(item);

				for (int i = 0; i < data->NumOfWindow(); i++)
				{
					data->curUsingSubData = i;

					if (0 == i)
					{
						m_GetRenderer(item, i)->Draw(data, item->window, IRenderer::LOAD_DATA_DRAW);
					}
					else
					{
						m_GetRenderer(item, i)->Draw(data, item->window_bg, IRenderer::LOAD_DATA_DRAW);
					}
				}

				IAsyncTask *asyncTask = IAsyncTask::CreateInstance(item);
				if (asyncTask)
				{
					m_asyncTaskMap.insert(std::make_pair(item, (CAsyncTask*)asyncTask));
					//CAsyncTaskListener *listener = new CAsyncTaskListener(this);
					//asyncTask->SetTaskListener(listener);
					asyncTask->SetTaskListener(this);
					asyncTask->Execute();
				}				
				break;
			}
			default:
				break;
			}
		}
	}

	CMActor* CDataListControl::m_GetWindow(TItem *item, int reason)
	{
		CMActor *window = NULL;

		if (0 != m_windowQueue.size())
		{
			window = m_windowQueue.front();
			window->SetOwner(item);
			m_windowQueue.pop_front();
		}
		else
		{
			window = new CMActor(item, this);
			window->Initialize(t_itemGroup, item->rect.w, item->rect.h);
			window->EnableReverse(false);

			if (t_flagEditable)
			{
				window->EnableDrag(true);
			}

			for (std::map<CMultiObjectTransition*, long>::iterator x = m_multiObjTransInfoMap.begin(); x != m_multiObjTransInfoMap.end(); ++x)
			{
				long transType = x->second;

				if (0 != (x->second & ITEM_ALPHA_TRANS))
				{
					x->first->AddAnimatableObject(window, IActor::ACTOR_ANI_ALPHA);
				}
				
				if (0 != (x->second & ITEM_SIZE_TRANS))
				{
					x->first->AddAnimatableObject(window, IActor::ACTOR_ANI_SIZE);
				}

				if (0 != (x->second & ITEM_POSITION_TRANS))
				{
					x->first->AddAnimatableObject(window, IActor::ACTOR_ANI_POSITION);
				}

				if (0 != (x->second & ITEM_SCALEX_TRANS))
				{
					x->first->AddAnimatableObject(window, IActor::ACTOR_ANI_SCALE_X);
				}

				if (0 != (x->second & ITEM_SCALEY_TRANS))
				{
					x->first->AddAnimatableObject(window, IActor::ACTOR_ANI_SCALE_Y);
				}
			}
		}

		float pivotX, pivotY, pivotZ;
		t_GetItemWindowPivotPoint(item, pivotX, pivotY, pivotZ);
		window->SetPivotPoint(pivotX, pivotY, pivotZ);

		TRect rect = t_InitRectOfLoadingItem(item, reason);
		TValue2f realValue = t_GetRealPointBaseItemGroup(rect, t_itemGroupRect);
		window->SetPosition(realValue.val[0], realValue.val[1]);
		window->Resize(rect.w, rect.h);

		return window;
	}

	bool CDataListControl::m_RegisterMultiObjTransition(CMultiObjectTransition *trans, long transType)
	{
		bool newTrans = false;
		std::map<CMultiObjectTransition*, long>::iterator x = m_multiObjTransInfoMap.find(trans);

		if (m_multiObjTransInfoMap.end() == x)
		{
			newTrans = true;
			m_multiObjTransInfoMap.insert(std::make_pair(trans, transType));
		}
		else
		{
			x->second = x->second | transType;
		}

		if (0 != (transType & ITEM_GROUP_POS_TRANS))
		{
			trans->AddAnimatableObject(t_itemGroup, IActor::ACTOR_ANI_POSITION);
		}

		if (0 != (transType & ITEM_GROUP_ALPHA_TRANS))
		{
			trans->AddAnimatableObject(t_itemGroup, IActor::ACTOR_ANI_ALPHA);
		}

		return newTrans;
	}

	void CDataListControl::m_FocusChangeStart(const TItem *from, const TItem *to)
	{
		if (NULL != from && NULL != from->window)
		{
			m_GetRenderer((TItem*)from, 0)->Draw((IData*)from->data, from->window, IRenderer::FOCUS_CHANGE_START_FROM_DRAW);
		}

		if (NULL != to && NULL != to->window)
		{
			m_GetRenderer((TItem*)to, 0)->Draw((IData*)to->data, to->window, IRenderer::FOCUS_CHANGE_START_TO_DRAW);
		}

		if (NULL != from && NULL != from->renderer && NULL != from->renderer->Thumbnail())
		{
			IThumbnail *thumb = from->renderer->Thumbnail();
			// Stop Auto scroll of lost focus item
			if (thumb->VisibleThumbnailStyles() & IThumbnail::THUMB_STYLE_TEXT)
			{
				thumb->EnableAttachTextAutoScroll(false);
			}
			if (thumb->VisibleThumbnailStyles() & IThumbnail::THUMB_STYLE_INFO)
			{
				int infoTextNum = thumb->InformationTextNumber();
				for (int i = 0; i < infoTextNum; i++)
				{
					thumb->EnableInformationTextAutoScroll(i, false);
				}
			}
		}

		t_FocusChangeStart(from, to);
	}

	void CDataListControl::m_FocusChangeFinish(const TItem *from, const TItem *to)
	{
		if (NULL != from && NULL != from->window)
		{
			m_GetRenderer((TItem*)from, 0)->Draw((IData*)from->data, from->window, IRenderer::FOCUS_CHANGE_FINISH_FROM_DRAW);
		}

		if (NULL != to && NULL != to->window)
		{
			IRenderer* render = m_GetRenderer((TItem*)to, 0);
			render->Draw((IData*)to->data, to->window, IRenderer::FOCUS_CHANGE_FINISH_TO_DRAW);
			if(render->Thumbnail() != NULL)
			{
				render->Thumbnail()->PlayTTSText();

			}
		}

		if (NULL != to && NULL != to->renderer && NULL != to->renderer->Thumbnail())
		{
			// Start Auto scroll of lost focus item
			IThumbnail *thumb = to->renderer->Thumbnail();

			if (thumb->VisibleThumbnailStyles() & IThumbnail::THUMB_STYLE_TEXT)
			{
				thumb->EnableAttachTextAutoScroll(true);
			}
			if (thumb->VisibleThumbnailStyles() & IThumbnail::THUMB_STYLE_INFO)
			{
				int infoTextNum = thumb->InformationTextNumber();
				for (int i = 0; i < infoTextNum; i++)
				{
					thumb->EnableInformationTextAutoScroll(i, true);
				}
			}
		}

		t_FocusChangeFinish(from, to);
	}

	void CDataListControl::GetFocusMargin(TMargin &margin)
	{

	}

	bool CDataListControl::ShowFocus(bool flagAnimation)
	{
		H_LOG_1_PARAM(FATAL, LOGGER, flagAnimation);

		if (true == t_flagShowFocusBar)
		{
			return false;
		}

		t_StopAnimation(LIST_ANI_TYPE_MAX);

		t_flagShowFocusBar = true;
		m_flagShowHidingFocusBar = true;

		if (NULL == t_focusedItem)
		{
			if (NULL != m_focusImgRectBak && NULL != m_focusItemRectBak)
			{
				if (NULL != m_itemGroupPosBak && (m_itemGroupPosBak->val[0] != t_itemGroupRect.x || m_itemGroupPosBak->val[1] != t_itemGroupRect.y))
				{
					t_SetFocusBar(*m_focusImgRectBak, *m_focusItemRectBak, t_focusedItemBak, flagAnimation, flagAnimation, m_itemGroupPosBak);
				}
				else
				{
					t_SetFocusBar(*m_focusImgRectBak, *m_focusItemRectBak, t_focusedItemBak, flagAnimation, flagAnimation);
				}
			}
			else
			{
				t_SetFocusBar(t_focusedItemBak, flagAnimation, flagAnimation);
			}
		}
		else
		{
			t_SetFocusBar(t_focusedItem, flagAnimation, flagAnimation);
		}

		if (NULL != m_focusBar)
		{
			TValue1i destAlpha(255);
			m_focusShowHideAni->SetDestination(m_focusBar, IActor::ACTOR_ANI_ALPHA, &destAlpha);

			if (true == flagAnimation)
			{
				m_focusShowHideAni->Play();
			}
			else
			{
				m_focusShowHideAni->JumpToDestination();
			}
		}

		return true;
	}

	bool CDataListControl::HideFocus(bool flagAnimation)
	{
		H_LOG_1_PARAM(FATAL, LOGGER, flagAnimation);
		if (false == t_flagShowFocusBar)
		{
			return false;
		}

		t_StopAnimation(LIST_ANI_TYPE_MAX);

		m_flagShowHidingFocusBar = true;

		t_focusedItemBak = t_focusedItem;

		if (NULL == m_focusImgRectBak)
		{
			m_focusImgRectBak = new TRect;
			HALO_ASSERT(NULL != m_focusImgRectBak);
		}

		if (NULL == m_focusItemRectBak)
		{
			m_focusItemRectBak = new TRect;
			HALO_ASSERT(NULL != m_focusItemRectBak);
		}

		if (NULL == m_itemGroupPosBak)
		{
			m_itemGroupPosBak = new TValue2f;
			HALO_ASSERT(NULL != m_itemGroupPosBak);
		}

		*m_focusImgRectBak = m_focusImgRect;
		*m_focusItemRectBak = m_focusItemRect;
		m_itemGroupPosBak->Set(t_itemGroupRect.x, t_itemGroupRect.y);

		t_SetFocusBar(NULL, flagAnimation, flagAnimation);

		t_flagShowFocusBar = false;

		if (NULL != m_focusBar)
		{
			TValue1i destAlpha(0);
			m_focusShowHideAni->SetDestination(m_focusBar, IActor::ACTOR_ANI_ALPHA, &destAlpha);

			if (true == flagAnimation)
			{
				m_focusShowHideAni->Play();
			}
			else
			{
				m_focusShowHideAni->JumpToDestination();
			}
		}

		return true;
	}

	bool CDataListControl::IsDirectionScrollable(EDirection dir)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);

		return false;
	}

	void CDataListControl::ScrollVisibleArea(float xOffset, float yOffset, bool flagAni)
	{
		H_LOG_3_PARAM(TRACE, LOGGER, xOffset, yOffset, flagAni);

		if (xOffset == 0 && yOffset == 0)
		{
			return;
		}

		t_lastItemGroupPos.val[0] = t_itemGroupRect.x;
		t_lastItemGroupPos.val[1] = t_itemGroupRect.y;

		t_itemGroupRect.x -= xOffset;
		t_itemGroupRect.y -= yOffset;

		TValue2f point = t_GetRealPointBaseItemGroup(t_itemGroupRect, m_windowRect);
		m_itemScrollAni->SetDestination(t_itemGroup, IActor::ACTOR_ANI_POSITION, &point);

		if (true == flagAni)
		{
			m_itemScrollAni->Play();
		}
		else
		{
			m_itemScrollAni->JumpToDestination();
		}
	}

	void CDataListControl::ScrollVisibleArea(TRect toRect, bool flagAni /* = true */)
	{
		H_LOG_TRACE(LOGGER, "["<< this <<"]CDataListControl::ScrollVisibleArea toRect:(" << toRect.x << "," << toRect.y << "," << toRect.w << "," << toRect.h << ")");
		if (t_itemGroupRect.x == -toRect.x && t_itemGroupRect.y == -toRect.y)
		{
			return;
		}

		t_lastItemGroupPos.val[0] = t_itemGroupRect.x;
		t_lastItemGroupPos.val[1] = t_itemGroupRect.y;

		t_itemGroupRect.x = -toRect.x;
		t_itemGroupRect.y = -toRect.y;

		TValue2f point = t_GetRealPointBaseItemGroup(t_itemGroupRect, m_windowRect);
		m_itemScrollAni->SetDestination(t_itemGroup, IActor::ACTOR_ANI_POSITION, &point);

		if (true == flagAni)
		{
			m_itemScrollAni->Play();
		}
		else
		{
			m_itemScrollAni->JumpToDestination();
		}

		HideFocus(flagAni);
	}

	void CDataListControl::t_UpdateUI(TItem *item)
	{
		std::map<TItem*, CAsyncTask *>::iterator iter = m_asyncTaskMap.find(item);
		if (iter != m_asyncTaskMap.end())
		{
			iter->second->Update(item);
		}
	}

	TRect CDataListControl::t_WindowRect(void)
	{
		TRect windowRect;
		windowRect.x = -t_itemGroupRect.x;
		windowRect.y = -t_itemGroupRect.y;
		windowRect.w = m_windowRect.w;
		windowRect.h = m_windowRect.h;
		
		return windowRect;
	}
	
	IRenderer * CDataListControl::m_GetRenderer(TItem* item, int index)
	{
		if (0 == index)
		{
			if (item->renderer == NULL)
			{
				item->renderer = t_rendererProvider->GetRenderer((IData*)item->data, item->window);

				IThumbnail *thumb = item->renderer->Thumbnail();
				if (NULL != thumb)
				{
					thumb->EnableThumbnailStyles(true, item->visibleThumbStyle, false);
					thumb->EnableThumbnailStyles(false, item->disVisibleThumbStyle, false);

					if (true == item->flagCheckBoxSelected)
					{
						thumb->SetChecked(true);
					}
					else
					{
						thumb->SetChecked(false);
					}
				}
			}

			return item->renderer;
		}
		else
		{
			if (item->renderer_bg == NULL)
			{
				item->renderer_bg = t_rendererProvider->GetRenderer((IData*)item->data, item->window_bg);
			}

			return item->renderer_bg;
		}
	}

	void CDataListControl::m_OnItemStyleAni(EAniEventType eventType, void *detail, void* data)
	{
		switch (eventType)
		{
		case ANI_FINISH:
		{
			t_OnStyleAnimationFinish();
			ShowFocus(true);

			m_DealScrollEventQueue((int)m_scrollInfoQueue.size());
			break;
		}

		case ANI_START:
		{
			break;
		}

		default:
			break;
		}
	}

	void CDataListControl::t_StopAnimation(int listAniType)
	{
		if (LIST_ANI_TYPE_MAX == listAniType)
		{
			listAniType = ITEM_SCROLL_ANI | FOCUS_MOVE_ANI | LOOP_ANI | ITEM_STYLE_ANI | CURSOR_SHOW_HIDE_ANI;
		}

		if (0 != (ITEM_SCROLL_ANI & listAniType))
		{
			m_itemScrollAni->StopAndJump(true);
		}

		if (0 != (FOCUS_MOVE_ANI & listAniType))
		{
			m_focusMoveAni->StopAndJump(true);
		}

		if (0 != (LOOP_ANI & listAniType))
		{
			m_loopAni->StopAndJump(true);
		}

		if (0 != (ITEM_STYLE_ANI & listAniType))
		{
			m_transStyleAni->StopAndJump(true);
		}

		if (0 != (CURSOR_SHOW_HIDE_ANI & listAniType))
		{
			m_cursorShowHideAni->StopAndJump(true);
		}
	}

	bool CDataListControl::t_IsOnAnimation(int listAniType)
	{
		bool ret = false;

		if (LIST_ANI_TYPE_MAX == listAniType)
		{
			listAniType = ITEM_SCROLL_ANI | FOCUS_MOVE_ANI | LOOP_ANI | ITEM_STYLE_ANI;
		}

		if (0 != (ITEM_SCROLL_ANI & listAniType))
		{
			ret = ret || (true == m_itemScrollAni->IsPlaying());
		}

		if (0 != (FOCUS_MOVE_ANI & listAniType))
		{
			if (false == m_flagShowHidingFocusBar)
			{
				ret = ret || (true == m_focusMoveAni->IsPlaying());
			}
		}
		
		if (0 != (LOOP_ANI & listAniType))
		{
			ret = ret || (STATUS_NORMAL != m_listStatus);
		}

		if (0 != (ITEM_STYLE_ANI & listAniType))
		{
			ret = ret || (true == m_transStyleAni->IsPlaying());
		}

		if (0 != (CURSOR_SHOW_HIDE_ANI & listAniType))
		{
			ret = ret || (true == m_cursorShowHideAni->IsPlaying());
		}
		
		return ret;
	}

	void CDataListControl::t_ScaleDownFocuedItem(CMultiObjectTransition *transGroup)
	{
		IThumbnail* thumb = NULL;
		if (NULL != t_focusedItem)
		{
			if (NULL != t_focusedItem->renderer && NULL != (thumb = t_focusedItem->renderer->Thumbnail()))
			{   
				bool aniFlag;
				if (t_flagMouse)
				{
					aniFlag = false;
				}
				else
				{
					aniFlag =  (NULL != transGroup);
				}
				thumb->Scale(TValue2f(1.0f, 1.0f), 1.0f, aniFlag);
				thumb->SetHighlighted(false, aniFlag);
			}
			else if (NULL != t_focusedItem->window)
			{
				t_focusedItem->window->ScaleTo(1.0, 1.0, transGroup);
			}
		}
	}

	void CDataListControl::t_ScaleUpFocuedItem(CMultiObjectTransition *transGroup)
	{
		if (NULL != t_focusedItem && NULL != t_focusedItem->window)
		{
			float w, h;
			t_focusedItem->window->GetSize(w, h);
			t_focusedItem->window->Raise(NULL);

			if (NULL == m_focusBarColor)
			{
				m_focusBar->Raise(NULL);
			}

			IThumbnail* thumb = NULL;
			if (NULL != t_focusedItem->renderer && NULL != (thumb = t_focusedItem->renderer->Thumbnail()))
			{
				bool aniFlag;
				if (t_flagMouse)
				{
					aniFlag = false;
				}
				else
				{
					aniFlag =  (NULL != transGroup);
				}

				CThumbnail *cThumb = dynamic_cast<CThumbnail*>(thumb);
				if (cThumb != NULL)
				{
					cThumb->enableFontScale(true);
					//thumb->Scale(TValue2f((w + m_enlargeWidth) / w, (h + m_enlargeHeight) / h), 1.3f, aniFlag);
					float infoBoxFactor = cThumb->GetFoveaInfoBoxScaleFactor() + 1.0f;
					float imageFactor = cThumb->GetFoveaImageScaleFactor() + 1.0f;
					H_LOG_TRACE(LOGGER, "t_ScaleUpFocuedItem :" << aniFlag);
					thumb->Scale(TValue2f(imageFactor,imageFactor), infoBoxFactor, aniFlag);
				}

				thumb->SetHighlighted(true, aniFlag);
			}
			else
			{
				t_focusedItem->window->ScaleTo((w + m_enlargeWidth) / w, (h + m_enlargeHeight) / h, transGroup);
			}
		}

		
	}

	bool CDataListControl::OnKeyLongPress(IWidgetExtension* pWindow, IKeyboardEvent* pKeyboardEvent)
	{
		int keyValue = pKeyboardEvent->GetKeyVal();
		H_LOG_1_PARAM(FATAL, LOGGER, keyValue);

		if (keyValue == CLUTTER_KEY_Return)
		{
			t_OnEnterKeyLongPressed();
		}
		return true;
	}

	bool CDataListControl::OnCursorVisible(IEvent* pEvent)
	{
		H_LOG_0_PARAM(FATAL, LOGGER);

		if (IUtility::GetInstance()->IsHighContrastEnabled())
		{
			return false;
		}

		// Cursor state change to visible
		if (m_focusImage && m_cursorShowHideAni)
		{
			TValue2f destSize;
			destSize.Set(0, 0);
			m_cursorShowHideAni->SetDestination(m_focusImage, IActor::ACTOR_ANI_SIZE, &destSize);
			TValue2f destPos;
			destPos.Set(m_focusImgRect.w / 2, m_focusImgRect.h / 2);
			m_cursorShowHideAni->SetDestination(m_focusImage, IActor::ACTOR_ANI_POSITION, &destPos);

			m_cursorShowHideAni->Play();
		}

		return true;
	}

	bool CDataListControl::OnCursorHidden(IEvent* pEvent)
	{
		H_LOG_0_PARAM(FATAL, LOGGER);

		if (IUtility::GetInstance()->IsHighContrastEnabled())
		{
			return false;
		}
		
		// Cursor state change to hidden
		if (m_focusImage && m_cursorShowHideAni)
		{
			m_focusImage->Resize(0.0f, 0.0f);
			m_focusImage->SetPosition(m_focusImgRect.w / 2, m_focusImgRect.h / 2);
			m_focusImage->Show();

			t_ScaleUpFocuedItem(m_focusMoveAni);

			TValue2f destSize;
			destSize.Set(m_focusImgRect.w - m_focusImageOffsetX * 2, m_focusImgRect.h - m_focusImageOffsetY * 2);
			m_cursorShowHideAni->SetDestination(m_focusImage, IActor::ACTOR_ANI_SIZE, &destSize);
			TValue2f destPos;
			destPos.Set(m_focusImageOffsetX, m_focusImageOffsetY);
			m_cursorShowHideAni->SetDestination(m_focusImage, IActor::ACTOR_ANI_POSITION, &destPos);
			m_cursorShowHideAni->Play();
		}

		return true;
	}

	void CDataListControl::t_UpdateItem(TItem* item)
	{
		if (item->window == NULL)
		{
			return;
		}
		IRenderer* render = m_GetRenderer(item, 0);
		render->Draw((IData*)item->data, item->window, IRenderer::UPDATE_DATA_DRAW);
	}

	void CDataListControl::EnableLoopLeft(const bool flagLoop)
	{
		H_LOG_1_PARAM(FATAL, LOGGER, flagLoop);
		t_flagLoopLeft = flagLoop;
	}

	bool CDataListControl::IsLoopLeftEnabled(void) const
	{
		H_LOG_0_PARAM(TRACE, LOGGER);
		return t_flagLoopLeft;
	}

	void CDataListControl::EnableLoopRight(const bool flagLoop)
	{
		H_LOG_1_PARAM(FATAL, LOGGER, flagLoop);
		t_flagLoopRight = flagLoop;
	}

	bool CDataListControl::IsLoopRightEnabled(void) const
	{
		H_LOG_0_PARAM(TRACE, LOGGER);
		return t_flagLoopRight;
	}

	void CDataListControl::AttachScrollBar(IScroll* scroll)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);

		HALO_ASSERT(scroll != NULL);
		HALO_EXCEPTION(m_scrollBar == NULL, "There is a scroll bar attached already!");

		m_scrollBar = scroll;
		m_scrollBar->AddListener(this);
		m_scrollBar->SetParent(this);
		m_scrollBar->SetAlpha(0);
		m_scrollBar->SetOrientation(Orientation(true));
		
		m_scrollBarAlphaAni = ITransition::CreateInstance();
		if (m_scrollBarAlphaAni != NULL)
		{
			m_scrollBar->BindTransition(m_scrollBarAlphaAni, ACTOR_ANI_ALPHA);
		}

		m_scrollBarMouserListener = new CMScrollBarMouseListener(this);
		m_scrollBar->AddMouseListener(m_scrollBarMouserListener);

		OnValueChanged(m_scrollBar, E_TYPE_DRAG);
	}

	void CDataListControl::SetColorOfDimWindow(int alpha, int red, int green, int blue)
	{
		m_dimWindowColor = new ClutterColor;
		clutter_color_init(m_dimWindowColor, red, green, blue, alpha);

		if (NULL != m_dimWindow)
		{
			m_dimWindow->SetBackgroundColor(*m_dimWindowColor);
		}
	}

	void CDataListControl::Dim(bool flagShowDimWindow)
	{
		if (true == flagShowDimWindow)
		{
			if (NULL == m_dimWindow)
			{
				m_dimWindow = IDimWindow::CreateInstance(NULL, -1, -1);
				HALO_ASSERT(NULL != m_dimWindow);
			}

			TItem *focusItem = NULL;

			if (NULL != t_focusedItem)
			{
				focusItem = t_focusedItem;
			}
			else if (NULL != t_focusedItemBak)
			{
				focusItem = t_focusedItemBak;
			}

			if (NULL != focusItem && NULL != focusItem->window)
			{
				TValue2f realValue = t_GetRealPointBaseItemGroup(focusItem->rect, m_windowRect);
				focusItem->window->SetPosition(realValue.val[0], realValue.val[1]);
				focusItem->window->SetRotation(0.0f, 0.0f, 0.0f);
			}

			if (NULL != focusItem && NULL != focusItem->window)
			{
				Widget *listControl = dynamic_cast<Widget*>(this);
				HALO_ASSERT(NULL != listControl);

				m_dimWindow->ClearTransparentArea();

				Vector3 position = listControl->getAbsolutePosition();

				TRect focusRect = focusItem->rect;
				focusRect.x += t_itemGroupRect.x;
				focusRect.y += t_itemGroupRect.y;

				TValue2f realValue = t_GetRealPointBaseItemGroup(focusRect, m_windowRect);
				position.x += realValue.val[0];
				position.y += realValue.val[1];

				m_dimWindow->AddTransparentArea(position.x, position.y, focusRect.w, focusRect.h);
			}

			if (NULL != m_dimWindowColor)
			{
				m_dimWindow->SetBackgroundColor(*m_dimWindowColor);
			}

			m_dimWindow->Show();
		}
		else
		{
			m_dimWindow->Hide();
		}
	}

	void CDataListControl::SetChangeMount(const float changeMount)
	{
		m_ChangeMount = changeMount;
	}

	float CDataListControl::ChangeMount(void)
	{
		return m_ChangeMount;
	}

	void CDataListControl::SetCursorScrollArea(float totalSpace, float inShowAreaSpace)
	{
		m_cursorScrollSpace = totalSpace;
		m_cursorScrollInShowAreaSpace = inShowAreaSpace;
		m_scrollType = t_GetScrollDirection();

		m_scrollActorListener = new CMScrollAreaListener(this);

		if (TYPE_HORIZONTAL == m_scrollType)
		{
			m_leftScrollAreaActor = IActor::CreateInstance(dynamic_cast<IActor*>(this), m_cursorScrollSpace, t_itemGroupRect.h);
			m_leftScrollAreaActor->SetPosition(-(m_cursorScrollSpace - m_cursorScrollInShowAreaSpace), t_itemGroupRect.y);

			m_rightScrollAreaActor = IActor::CreateInstance(dynamic_cast<IActor*>(this), m_cursorScrollSpace, t_itemGroupRect.h);
			m_rightScrollAreaActor->SetPosition(t_listWidth - m_cursorScrollInShowAreaSpace, t_itemGroupRect.y);

			SetClipArea(-(m_cursorScrollSpace - m_cursorScrollInShowAreaSpace), 0.0f, t_listWidth + (m_cursorScrollSpace - m_cursorScrollInShowAreaSpace) * 2.0f, t_listHeight);
		}
		else
		{
			m_leftScrollAreaActor = IActor::CreateInstance(dynamic_cast<IActor*>(this), t_itemGroupRect.w, m_cursorScrollSpace);
			m_leftScrollAreaActor->SetPosition(t_itemGroupRect.x, -(m_cursorScrollSpace - m_cursorScrollInShowAreaSpace));

			m_rightScrollAreaActor = IActor::CreateInstance(dynamic_cast<IActor*>(this), t_itemGroupRect.w, m_cursorScrollSpace);
			m_rightScrollAreaActor->SetPosition(t_itemGroupRect.x, t_listHeight - m_cursorScrollInShowAreaSpace);

			SetClipArea(0.0f, -(m_cursorScrollSpace - m_cursorScrollInShowAreaSpace), t_listWidth, t_listHeight + (m_cursorScrollSpace - m_cursorScrollInShowAreaSpace) * 2.0f);
		}

// 		ClutterColor color = {255, 0, 0, 150};
// 		m_leftScrollAreaActor->SetBackgroundColor(color);
// 		m_rightScrollAreaActor->SetBackgroundColor(color);

		m_leftScrollAreaActor->Show();
		m_rightScrollAreaActor->Show();

		m_leftScrollAreaActor->AddMouseListener(m_scrollActorListener);
		m_rightScrollAreaActor->AddMouseListener(m_scrollActorListener);
	}

	void CDataListControl::GetCursorScrollArea(float &totalSpace, float &inShowAreaSpace)
	{
		totalSpace = m_cursorScrollSpace;
		inShowAreaSpace = m_cursorScrollInShowAreaSpace;
	}

	CMActor* CDataListControl::FocusedItemWindow(void)
	{
		if (NULL != t_focusedItem && NULL != t_focusedItem->window)
		{
			return t_focusedItem->window;
		}
		else
		{
			return NULL;
		}
	}

	bool CDataListControl::OnValueChanged(IScroll* scroll, EValueChangedType type)
	{
		H_LOG_TRACE(LOGGER, "["<< this <<"]CDataListControl::OnValueChanged, type is " << type << ", set to value: " << scroll->Value());

		bool aniFlag = false;
		switch (type)
		{
		case HALO::E_TYPE_SETVALUE:
			return false;
		case HALO::E_TYPE_CLICK:
			aniFlag = true;
			break;
		case HALO::E_TYPE_DRAG:
			if (TYPE_HORIZONTAL == m_scrollBar->DirectionType())
			{
				if (t_itemGroupRect.w <= t_listWidth)
				{
					m_scrollBar->SetAlpha(0);
					return false;
				}
			}
			else
			{
				if (t_itemGroupRect.h <= t_listHeight)
				{
					m_scrollBar->SetAlpha(0);
					return false;
				}
			}
			aniFlag = false;
			break;
		default:
			break;
		}

		if (TYPE_HORIZONTAL == m_scrollBar->DirectionType())
		{
			float toRatio = (float)scroll->Value() / (float)(scroll->MaxValue() - scroll->MinValue());

			float fromXValue = t_itemGroupRect.x;
			float toXValue = -(t_itemGroupRect.w - t_listWidth) * toRatio;

			//TValue2f realValue = t_GetRealPointBaseItemGroup(t_itemGroupRect, m_windowRect);
			float xOffset = fromXValue - toXValue; //+ realValue.val[0];
			ScrollVisibleArea(xOffset, 0.0f, aniFlag);
		}
		else
		{
			float toRatio = (float)scroll->Value() / (float)(scroll->MaxValue() - scroll->MinValue());

			float fromYValue = t_itemGroupRect.y;
			float toYValue = -(t_itemGroupRect.h - t_listHeight) * toRatio;

			float yOffset = fromYValue - toYValue;
			ScrollVisibleArea(0.0f, yOffset, aniFlag);
		}

		return true;
	}

	int CDataListControl::m_ScrollBarTimeOut(gpointer data)
	{
		CDataListControl* pThis = (CDataListControl*)data;

		pThis->m_HideScrollBar(true);
		pThis->m_scrollBarTimer = -1;
		return 0;
	}

	void CDataListControl::m_StartScrollBarAlphaOutTimer(void)
	{
		if (m_scrollBarTimer < 0)
		{
			m_scrollBarTimer = clutter_threads_add_timeout(m_scrollBarTimerInterval, m_ScrollBarTimeOut, this);
		}	
	}

	void CDataListControl::m_StopScrollBarAlphaOutTimer(void)
	{
		if (m_scrollBarTimer > 0)
		{
			g_source_remove(m_scrollBarTimer);
			m_scrollBarTimer = -1;
		}
	}

	void CDataListControl::m_ShowScrollBar(bool flagAni)
	{
		if (m_scrollBar != NULL && m_scrollBarAlphaAni != NULL)
		{
			if (TYPE_HORIZONTAL == m_scrollBar->DirectionType())
			{
				if (t_itemGroupRect.w <= t_listWidth)
				{
					m_scrollBar->SetAlpha(0);
					return;
				}
			}
			else
			{
				if (t_itemGroupRect.h <= t_listHeight)
				{
					m_scrollBar->SetAlpha(0);
					return;
				}
			}

			if (flagAni)
			{
				m_scrollBarAlphaAni->SetDestination(255);
				m_scrollBarAlphaAni->SetDuration(200);
				m_scrollBarAlphaAni->Play();
			}
			else
			{
				m_scrollBar->SetAlpha(255);
			}
			m_scrollBar->Enable(true);
		}
	}

	void CDataListControl::m_HideScrollBar(bool flagAni)
	{
		if (m_scrollBar != NULL && m_scrollBarAlphaAni != NULL)
		{
			if (flagAni)
			{
				m_scrollBarAlphaAni->SetDestination(0);
				m_scrollBarAlphaAni->SetDuration(200);
				m_scrollBarAlphaAni->Play();
			}
			else
			{
				m_scrollBar->SetAlpha(0);
			}
			m_scrollBar->Enable(false);
		}
	}

	bool CDataListControl::m_DoFoveaAnimation(TItem *item, IMouseEvent* ptrMouseEvent)
	{
		if (NULL != item->renderer && NULL != item->renderer->Thumbnail())
		{
			std::vector<TItem*> itemArray;

			HALO_ASSERT(NULL != item->window);

			Vector3 parentPos = item->window->getParent()->getAbsolutePosition();
			TValue2f cursorCenter(ptrMouseEvent->GetX() - parentPos.x, ptrMouseEvent->GetY() - parentPos.y);

			TRect cursorRect(cursorCenter.val[0], cursorCenter.val[1], 0.0f, 0.0f);
			cursorCenter = t_GetLogicalPosition(cursorRect, t_itemGroupRect);

			if (true == t_GetItemsNeedFoveaAni(item, itemArray, cursorCenter, t_cursorRadius))
			{
				for (int i = 0; i < (int)itemArray.size(); i++)
				{
					TItem *item = itemArray[i];

					if (NULL != item && NULL != item->renderer)
					{
						CThumbnail *thumb = dynamic_cast<CThumbnail*>(item->renderer->Thumbnail());
						if (NULL != thumb)
						{
							TValue2f itemWindowPos = t_GetRealPointBaseItemGroup(item->rect, t_itemGroupRect);

							TValue2f center(item->rect.x + item->rect.w / 2.0f, item->rect.y + item->rect.h / 2.0f);

							float thumbImageFactor = IUtility::GetInstance()->GetInterpolatedValue(thumb->GetFoveaImageInterpolatorType(),thumb->GetFoveaImageScaleFactor());
							float thumInfoBoxFactor = IUtility::GetInstance()->GetInterpolatedValue(thumb->GetFoveaInfoBoxInterpolatorType(),thumb->GetFoveaInfoBoxScaleFactor());
							
							float imageFactor = IFoveaAnimator::GetInstance()->CalculateFoveaTransX(item->rect.w, item->rect.h, center.val[0], center.val[1], cursorCenter.val[0], cursorCenter.val[1], t_cursorRadius);
							imageFactor = imageFactor * thumbImageFactor  + 1.0f;
							TValue2f imageFactors(imageFactor,imageFactor);
							
							if (t_focusedItem == item)//for the focused one, need to do text trans.
							{
								float transText = IFoveaAnimator::GetInstance()->CalculateFoveaTransText(item->rect.w, item->rect.h, center.val[0], center.val[1], cursorCenter.val[0], cursorCenter.val[1]);
								float textRatio = 1 + transText * thumInfoBoxFactor;

								thumb->enableFontScale(true);
								thumb->Scale(imageFactors, textRatio, false);
							}
							else //other influenced items, only need to do image trans.
							{
								thumb->Scale(imageFactors, false);
							}
						}
					}
				}

				return true;
			}
		}

		return false;
	}

	void CDataListControl::m_DoCursorScroll(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		HALO_ASSERT(0.0f != m_cursorScrollSpace);

		TRect destItemGroupRect = m_windowRect;
		bool flagScroll = false;

		float speedRatio = 1.0f;

		Widget *hitWidget = dynamic_cast<Widget*>(pWindow);
		HALO_ASSERT(NULL != hitWidget);

		Vector3 windowPos = hitWidget->getAbsolutePosition();
		float mouseX = ptrMouseEvent->GetX();
		float mouseY = ptrMouseEvent->GetY();

		mouseX -= windowPos.x;
		mouseY -= windowPos.y;

		float scrollDistance = 0.0f;

		if (TYPE_HORIZONTAL == m_scrollType)
		{
			if (m_leftScrollAreaActor == pWindow)
			{
				speedRatio = (m_cursorScrollSpace - mouseX) / m_cursorScrollSpace;
				flagScroll = true;

				scrollDistance = abs(t_itemGroupRect.x);

				destItemGroupRect.x = 0.0f;
				destItemGroupRect.y = t_itemGroupRect.y;
			}
			else if (m_rightScrollAreaActor == pWindow)
			{
				speedRatio = mouseX / m_cursorScrollSpace;
				flagScroll = true;

				scrollDistance = abs(t_itemGroupRect.w - t_listWidth - t_itemGroupRect.x);

				destItemGroupRect.x = t_itemGroupRect.w - t_listWidth;
				destItemGroupRect.y = t_itemGroupRect.y;
			}
		}
		else
		{
			
		}

		if (true == flagScroll)
		{
			float speed = m_ChangeMount * speedRatio;
			float duration = scrollDistance / speed;

			m_itemScrollAni->SetDuration(duration);

			if (false == m_itemScrollAni->IsPlaying())
			{
				ScrollVisibleArea(destItemGroupRect, true);
			}
			else
			{
				m_itemScrollAni->Play();
			}
		}
	}

	void CDataListControl::t_UpdateOrientation(EOrientation orientation)
	{
		if (m_scrollBar != NULL)
		{
			m_scrollBar->SetOrientation(orientation);
		}
		
		TValue2f realValue = t_GetRealPointBaseItemGroup(t_itemGroupRect, m_windowRect);
		t_itemGroup->SetPosition(realValue.val[0], realValue.val[1]);

		if (NULL != m_focusBar)
		{
			TRect focusRect = m_focusImgRect;
			focusRect.x += m_focusItemRect.x;
			focusRect.y += m_focusItemRect.y;

			realValue = t_GetRealPointBaseItemGroup(focusRect, t_itemGroupRect);
			m_focusBar->SetPosition(realValue.val[0], realValue.val[1]);
		}

		//CActor::t_UpdateOrientation(orientation);
	}

	void CDataListControl::t_UpdateHighContrast(bool flagHighContrast)
	{
		H_LOG_1_PARAM(TRACE, LOGGER, flagHighContrast);
		if (NULL == m_focusImage)
		{
			return;
		}
		
		if (!IDeviceManager::GetInstance()->IsCursorVisible())
		{
			return;
		}
		
		if (flagHighContrast)
		{
			// show focus bar when high contrast mode even if cursor is shown
			m_focusImage->Resize(m_focusImgRect.w - m_focusImageOffsetX * 2, m_focusImgRect.h - m_focusImageOffsetY * 2);
			m_focusImage->SetPosition(m_focusImageOffsetX, m_focusImageOffsetY);
			m_focusImage->Show();
		}
		else
		{
			m_focusImage->Resize(0.0f, 0.0f);
			m_focusImage->Hide();
		}
	}

	bool CDataListControl::OnMouseWheel(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_0_PARAM(TRACE, LOGGER);

		if (false == m_flagDealMouseEvent)
		{
			return false;
		}

		return t_MouseWheel(ptrMouseEvent);
	}


	bool CMScrollBarMouseListener::OnMousePointerIn(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		m_pOwner->m_StopScrollBarAlphaOutTimer();
		
		return false;
	}

	bool CMScrollBarMouseListener::OnMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		m_pOwner->m_StartScrollBarAlphaOutTimer();
		return false;
	}
}
