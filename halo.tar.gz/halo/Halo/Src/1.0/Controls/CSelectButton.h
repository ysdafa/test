#ifndef _CBASESELECTBUTTON_H_
#define _CBASESELECTBUTTON_H_

namespace HALO
{

	class OnButtonCheckedChangedListener
	{
		public:
			/*!
			\brief               Process the event when button is selected.
			\remarks             If use the listener ,must over write the function.
			\param               list:[in] the selected group. 
			\param               index:[in] the button index. 
			\param               ischecked:[in]  the button check state. 
			\param               checkcontrol:[in] the checked button. 
			\return              None
			*/
			virtual void OnCheckedChanged(class ISelectButton* button , bool ischecked){};
	};
	class CSelectButton : virtual public ISelectButton, public CActor , public IKeyboardListener , public IMouseListener, public IFocusListener
	{
		typedef CActor ParentType;
	public:
		CSelectButton();
		virtual ~CSelectButton();
		virtual bool Initialize(IActor *parent ,float width, float height);

		virtual bool Initialize(Widget *parent ,float width, float height);
		//Set item text.
		virtual void SetItemText(EItemState state, const char* itemText);
		//Get item text.
		virtual const char* ItemText(EItemState state);
		//Set item text font size.
		virtual void SetItemTextFontSize(EItemState state, const int fontSize);
		//Set item text color.
		virtual void SetItemTextColor(EItemState state, const ClutterColor color);
		//Get text color.
		//virtual const ClutterColor& TextColor(EItemState state);
		//Set Text font.
		virtual void SetTextFont(EItemState state,const char* font);
		//Get Text font.
		virtual char* TextFont(EItemState state);
		//Set group image by state.

		virtual void SetBoxBackGroudImage(EItemState state, const std::string& iconPath);

		virtual void SetCheckImage(EItemState state, const std::string& iconPath);

		virtual void SetBoxBackGroudImageOpacity(EItemState state, int boxbgOpacity);

		virtual void SetCheckImageOpacity(EItemState state, int checkOpacity);

		virtual void UpdateImageAttr(float x , float y , float w , float h);

		virtual void SetAttachText(float x , float y , float w , float h);
		//Set item Id;
		virtual void SetId(int itemId);
		//Get item Id.
		virtual int GetId();
		//Set text alignment.
		virtual void SetTextAlignment(EHAlignment hAlign, EVAlignment vAlign);

		virtual void Show();

		virtual void SetCheck(bool isChecked);

		virtual bool IsChecked();

		virtual void EnableChecked(bool isSelected);

		virtual void SetAsyncLoading(const bool isAsync);

		virtual void SetAutoFocusFlag(bool isAutoFocused);

		virtual void SetFocusState(bool isFocused);

		virtual bool AsyncLoading(void) const;

		virtual void SetAutoCheckFlag(bool isAutoChecked);

		virtual void Resize(float width, float height);

		virtual void AddListener(OnButtonCheckedChangedListener *listener);	

		virtual const char* GetActorType(void);

	protected:
		struct CTStateData
		{
			std::string bg_imagepath;
			std::string check_imagepath;
			char* textContent;
			char* font;
			ClutterColor color;
			int fontSize;
			int boxbgOpacity; 
			int checkOpacity;
		};
		CTStateData m_stateData[E_STATE_ALL];

		virtual void t_Initialize();

		void t_ChangeStateTo(EItemState toState);

		//virtual void t_SetButtonDefaultImage() = 0;

		bool t_IsChecked;

		bool t_IsEnableSelected;

		bool t_IsAutoFocused;

		bool t_IsAutoChecked;

		ImageWidget* t_BoxBgImage;

		ImageWidget* t_CheckImage;

		IText* t_text;

		float t_itemW;

		float t_itemH;

		virtual bool OnKeyPressed(IWidgetExtension* pThis, IKeyboardEvent* event);

		virtual bool OnFocusIn(IWidgetExtension* pWindow);

		virtual bool OnFocusOut(IWidgetExtension* pWindow);

		//! The callback function when mouse pointer in.
		virtual bool OnMousePointerIn(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);

		//! The callback function when mouse pointer out.
		virtual bool OnMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);

		virtual bool OnMouseButtonPressed(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent);
	private:
		bool m_IsText;
		bool m_HasBgImage;
		bool m_HasCheckImage;
		bool m_Async;
		bool m_IsFocused;
		int m_curState;
		int m_Id;
		void m_OnStateChange();

		void m_Destory();

		class OnButtonCheckedChangedListener* m_listener;
	};

}
#endif