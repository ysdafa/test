#ifndef _HALO_CMULTIIMAGE_H_
#define _HALO_CMULTIIMAGE_H_

namespace HALO
{
	class CMultiImage: public virtual IMultiImage, public CImage
	{
	public:
		CMultiImage(void);
		virtual ~CMultiImage(void);

		virtual bool Initialize(IActor* parent, float width, float height);
		virtual bool Initialize(Widget* parent, float width, float height);

		virtual void AddIcon(const char* path, TRect icon_rect, int opacity);
		virtual void AddIcon(IImageBuffer *buffer, TRect icon_rect, int opacity);
		virtual void AddIcon(ClutterContent *image, TRect icon_rect, int opacity);

		virtual bool SetIcon(int index, const char*path, int opacity);
		virtual bool SetIcon(int index, IImageBuffer *buffer, int opacity);
		virtual bool SetIcon(int index, ClutterContent *image, int opacity);

		virtual void RemoveIcon(int index);

		virtual int IconCount(void);

		virtual void GetIconRect(int index, TRect &icon_rect);

	protected:
		virtual ClutterContent  *t_CreateContent();

	private:
		struct IconInfo
		{
			gpointer id;
			ClutterContent *image;
			int opacity;

			IconInfo() :id(nullptr), image(NULL) {}
		};
		std::vector<IconInfo> m_icons;
	};

} /* namespace HALO */
#endif /* _HALO_CMULTIIMAGE_H_ */
