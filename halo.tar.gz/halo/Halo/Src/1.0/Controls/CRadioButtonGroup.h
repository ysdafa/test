#ifndef _CRADIOBUTTON_GROUP_H_
#define _CRADIOBUTTON_GROUP_H_

namespace HALO
{

	class CRadioButtonGroup : virtual public IRadioButtonGroup, public CSelectButtonGroup
	{
	public:
		CRadioButtonGroup(){};

		virtual ~CRadioButtonGroup(){};
		
		virtual bool Initialize(void);

		virtual const char* GetActorType(void);

		virtual int GetSelectedItemIndex(); 
	protected:
		virtual void t_ProcessSelect(class ISelectButton* button , bool ischecked);
	private:
		int m_selectedId;
	};
}
#endif