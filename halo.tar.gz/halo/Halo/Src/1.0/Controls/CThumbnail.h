#ifndef _CTHUMBNAIL_H_
#define _CTHUMBNAIL_H_

namespace HALO
{
	class CThumbnail : virtual public IThumbnail, public CActor, public IProgressListener
	{
		friend class CScrollPlayerHandler;
	public:
		enum EThumbnailEventType
		{
			EVENT_IMAGE_READY = 0,
			EVENT_ICON_CLICKED,
			EVENT_CHECK_STATE_CHANGED,
			EVENT_PROGRESS_VALUE_CHANGED,

			EVENT_THUMBNAIL_MAX,					//!< last thumbnail event type identifier.
		};

	public:
		CThumbnail();
		virtual ~CThumbnail();

		virtual bool Initialize(Widget* parent, float width, float height, EThumbnailStyles styles, EThumbnailStyles visibleStyles, const TThumbnailAttr& attr);

		virtual bool AddThumbnailListener(IThumbnailListener *listener);

		virtual bool OnMouseEvent(EMouseEventType eventType, IMouseEvent* pMouseEvent);

		virtual void SetThumbnailStyle(EThumbnailStyles styles, EThumbnailStyles visibleStyles, const TThumbnailAttr& attr, bool flagAni);
		virtual void EnableThumbnailStyle(bool enable, EThumbnailStyle style, bool flagAni);
		virtual void EnableThumbnailStyles(bool enable, EThumbnailStyles styles, bool flagAni);
		virtual void EnableAttachIcon(bool enable, int iconIndex, bool flagAni);
		virtual void EnableInformationIcon(bool enable, int iconIndex, bool flagAni);
		virtual void EnableInformationText(bool enable, int textIndex, bool flagAni);

		virtual void SetImage(const char* fileName);
		virtual void SetAttachTextColorPickingRange(int fromHPer, int toHPer, int fromVPer, int toVPer);
		virtual void SetInformationColorPickingRange(int fromHPer, int toHPer, int fromVPer, int toVPer);
		virtual bool GetInformationColorPicking(Color &color);
		virtual bool GetInformationExtractColor(Color &color);
		virtual bool GetColorPicking(int fromHPer, int toHPer, int fromVPer, int toVPer, Color &color);

		virtual void AddAttachIcon(const std::vector<TIconInfo> &iconInfo);
		virtual void RemoveAttachIcon(int index);
		virtual int  AttachedIconNumber(void);
		virtual void SetAttachIconImage(int index, const char* fileName);

		virtual void AddAttachText(const TAttachText &atInfo);
		virtual void RemoveAttachText();
		virtual void SetAttachText(const char* text);
		virtual void SetAttachTextColor(Color color);
		virtual void SetAttachTextFont(const char* font);
		virtual void SetAttachTextScrollAttribute(guint duration, guint delay, gint repeat, ClutterTextScrollType type, ClutterTimelineDirection direction, guint continueGap);
		virtual void EnableAttachTextAutoScroll(bool enable);
		virtual bool isAttachTextAutoScrollEnabled(void);
		virtual void EnableAttachTextEllipsize(bool enable);
		virtual bool isAttachTextEllipsizeEnabled(void);
		virtual void EnableAttachTextMultiLine(bool enable);
		virtual bool isAttachTextMultiLineEnabled(void);

		virtual void AddProgressBar(const TProgressBarInfo &pbInfo);
		virtual void RemoveProgressBar(void);
		virtual void SetProgressBarRange(int min, int max);
		virtual void SetProgressBarValue(int value);

		virtual void AddCheckBox(const TCheckBoxInfo &cbInfo);
		virtual void RemoveCheckBox(void);

		virtual void AddInformationText(const std::vector<TTextInfo> &textInfo);
		virtual void RemoveInformationText(int index);
		virtual int InformationTextNumber(void);
		virtual void SetInformationText(int index, const char* text);
		virtual void SetInformationTextColor(int index, Color color);
		virtual void SetInformationTextFont(int index, const char* font);
		virtual void SetInformationTextScrollAttribute(int index, guint duration, guint delay, gint repeat, ClutterTextScrollType type, ClutterTimelineDirection direction, guint continueGap);
		virtual void EnableInformationTextAutoScroll(int index, bool enable);
		virtual bool isInformationTextAutoScrollEnabled(int index);
		virtual void EnableInformationTextEllipsize(int index, bool enable);
		virtual bool isInformationTextEllipsizeEnabled(int index);
		virtual void EnableInformationTextMultiLine(int index, bool enable);
		virtual bool isInformationTextMultiLineEnabled(int index);
		virtual void SetInformationRatingValue(int value);

		virtual void AddInformationIcon(const std::vector<TIconInfo> &iconInfo);
		virtual void RemoveInformationIcon(int index);
		virtual int InformationIconNumber(void);
		virtual void SetInformationIconImage(int index, const char* fileName);

		virtual void SetImagePosition(float x, float y);
		virtual void GetImagePosition(float &x, float &y);
		virtual void ResizeImage(float width, float height);
		virtual void GetImageSize(float &width, float &height);

		virtual void SetAttachIconPosition(int index, float x, float y);
		virtual void GetAttachIconPosition(int index, float &x, float &y);
		virtual void ResizeAttachIcon(int index, float width, float height);
		virtual void GetAttachIconSize(int index, float &width, float &height);

		virtual void SetAttachTextPosition(float x, float y);
		virtual void GetAttachTextPosition(float &x, float &y);
		virtual void ResizeAttachText(float width, float height);
		virtual void GetAttachTextSize(float &width, float &height);

		virtual void SetCheckBoxPosition(float x, float y);
		virtual void GetCheckBoxPosition(float &x, float &y);
		virtual void ResizeCheckBox(float width, float height);
		virtual void GetCheckBoxSize(float &width, float &height);

		virtual void SetProgressBarPosition(float x, float y);
		virtual void GetProgressBarPosition(float &x, float &y);
		virtual void ResizeProgressBar(float width, float height);
		virtual void GetProgressBarSize(float &width, float &height);

		virtual void SetInformationPosition(float x, float y);
		virtual void GetInformationPosition(float &x, float &y);
		virtual void ResizeInformation(float width, float height);
		virtual void GetInformationSize(float &width, float &height);

		virtual void SetInformationIconPosition(int index, float x, float y);
		virtual void GetInformationIconPosition(int index, float &x, float &y);
		virtual void ResizeInformationIcon(int index, float width, float height);
		virtual void GetInformationIconSize(int index, float &width, float &height);

		virtual void SetInformationTextPosition(int index, float x, float y);
		virtual void GetInformationTextPosition(int index, float &x, float &y);
		virtual void ResizeInformationText(int index, float width, float height);
		virtual void GetInformationTextSize(int index, float &width, float &height);

		virtual void SetAttachIconOpacity(int index, int opacity);
		virtual int AttachIconOpacity(int index);
		virtual void SetAttachTextOpacity(int opacity);
		virtual int  AttachTextOpacity(void);
		virtual void SetInformationIconOpacity(int index, int opacity);
		virtual int  InformationIconOpacity(int index);

		virtual EThumbnailStyles VisibleThumbnailStyles(void);

		virtual EThumbnailStyles ThumbnailStyle(void);
		virtual EInformationStyles ThumbnailInformationStyle(void);

		virtual void SetScaleAnimation(int duration, ClutterAnimationMode mode);
		virtual void SetStyleTransAnimation(int duration, ClutterAnimationMode mode);
		virtual void Scale(TValue2f imageScaleFactor, bool flagAni);
		virtual void Scale(TValue2f imageScaleFactor, float titleFontScaleFactor, bool flagAni);

		virtual void SetDimBackgroundColor(const Color &color);
		virtual void SetDimImage(const char* path, int opacity);
		virtual void Dim(bool enable);
		virtual void RaiseImage(void);
		virtual void RaiseAttachIcon(int index);
		virtual void RaiseAttachText(void);
		virtual void RaiseProgressBar(void);
		virtual void RaiseCheckBox(void);
		virtual void RaiseInformation(void);

		virtual void SetChecked(bool checked);
		virtual bool IsChecked(void);

		virtual void Enable(bool enable);
		virtual bool IsEnabled(void);

		void enableFontScale(bool enable);

		void SetTTSText(const std::string text);
		void PlayTTSText(void);

		void ScrollImage(void);
		void SetScrollPlayerImages(std::vector<std::string> srcList);

	public: //for bridge usage
#ifndef WIN32
		class CVideoActor* VideoActor(void);
#endif

	protected:
		virtual void t_UpdateOrientation(EOrientation orientation);

		virtual bool OnValueChanged(class IProgress* slider);

	private:
		ImageWidgetReadyCallback m_RegisterReadyCallback(void);
		static void m_ImageLoadReadyCallback(CThumbnail* pThis, bool success);

		AnimationCallback m_RegisterAnimationCallback(void);
		static void m_AnimationCallback(CThumbnail* pThis);

		typedef std::function<bool(CThumbnail* thumb, Widget* widget, Widget* origin, const volt::util::MOUSE_BUTTON, Vector2 coordinates)> MouseEventCallback;

		ButtonPressCallback m_RegisterMouseEventCallback(MouseEventCallback cb);
		static bool m_mousePressedCallback(CThumbnail* pThis, Widget* widget, Widget* origin, volt::util::MOUSE_BUTTON button, Vector2 coordinates);
		static bool m_mouseReleaseCallback(CThumbnail* pThis, Widget* widget, Widget* origin, volt::util::MOUSE_BUTTON button, Vector2 coordinates);
		static bool m_mouseClickedCallback(CThumbnail* pThis, Widget* widget, Widget* origin, volt::util::MOUSE_BUTTON button, Vector2 coordinates);

		void m_ResetAttachTextColor(ImageWidget* w);
		void m_ResetInfoTextColor(ImageWidget* w);

		bool m_CreateContent(const TImageInfo &imageInfo);
		void m_DestroyContent(void);
		bool m_CreateAttachIcon(const TIconInfo &iconInfo);
		void m_DestroyAttachIcon(int index);
		bool m_CreateAttachText(const TAttachText &atInfo);
		void m_DestroyAttachText(void);
		bool m_CreateProgressBar(const TProgressBarInfo &pbInfo);
		void m_DestroyProgressBar(void);
		bool m_CreateCheckBox(const TCheckBoxInfo &cbInfo);
		void m_DestroyCheckBox(void);
		bool m_CreateInfo(const TInformation &info, EInformationStyles infoStyles);
		void m_DestroyInfo(void);
		bool m_CreateInfoText(const TTextInfo &textInfo);
		void m_DestroyInfoText(int index);
		bool m_CreateInfoIcon(const TIconInfo &iconInfo);
		void m_DestroyInfoIcon(int index);
		bool m_CreateInfoRating(const TRatingInfo &ratingInfo);
		void m_DestroyInfoRating(void);
		void m_UpdateInfoRating(int value);

		void m_ModifyText(IText* widget, const TTextInfo &textInfo);
		void m_ModifyIcon(ImageWidget* widget, const TIconInfo &iconInfo);

		TValue2f m_GetLogicalPos(const TRect& rect);

		bool m_CreateScrollPlayer(const TScrollPlayerInfo &scrollPlayerInfo);
		void m_DestroyScrollPlayer(void);
#ifndef WIN32
		bool m_CreateVideoActor(const TVideoActorInfo &videoActorInfo);
		void m_DestroyVideoActor(void);
#endif
		inline void m_SetId(Widget* w, std::string id, int index = -1)
		{
			if (w)
			{
				char buf[30];
				if (index != -1)
				{
					SNPRINTF(buf, 30, "[0x%p]%d", this, index);
				}
				else
				{
					SNPRINTF(buf, 30, "[0x%p]", this);
				}

				std::string _id(buf);
				_id.insert(12, id);
				w->setID(_id);
			}
		}

		EThumbnailStyles m_styles;
		EThumbnailStyles m_visibleStyles;
		EInformationStyles m_infoStyles;

		struct TextItem
		{
			IText* widget;
			TRect alloc;
			Color textColor;
			int   fontSize;   // font size user set
			float width;   // width user set
			float minHeight;   // preferred height of text associate to current font size

			TextItem() : widget(NULL), minHeight(0) {}
		};
		struct IconItem
		{
			ImageWidget* widget;
			TRect alloc;

			IconItem() : widget(NULL) {}
		};
		struct RatingItem
		{
			IMultiImage* widget;
			TRect alloc;
			std::string offName;
			std::string onName;
			std::string halfName;

			int value;

			RatingItem() : widget(NULL), value(0) {}
		};
		struct _ThumbInfo{
			Widget* root;
			TRect alloc;

			std::vector<TextItem*> texts;
			std::vector<IconItem*> icons;
			RatingItem* rating;

			Animation *rootAni;
			CMultiObjectTransition *textAni;

			TRegion colorPickingRange;
			ClutterColor bgColorPicking;
			ClutterColor fgColorExtracted;
			bool colorPickingReady;
			bool useReferenceColor;

			_ThumbInfo() : root(NULL), rating(NULL), rootAni(NULL), textAni(NULL), colorPickingReady(false), useReferenceColor(true) {}
		}m_info;

		struct ImageInfo
		{
			ImageWidget *widget;
			TRect alloc;
			Animation *widgetAni;

			bool isReady;

			ImageInfo() : widget(NULL), widgetAni(NULL), isReady(false) {}
		};
		struct _ThumbContent
		{
			IActor* root; // for clip when scale
			TRect rootAlloc;  // clip area
			ImageInfo image;

			_ThumbContent() : root(NULL) {}
		}m_content;

		struct AttachIcon
		{
			std::string unpressName;
			std::string pressedNmae;
			ImageWidget* widget;
			TRect alloc;

			Widget::EventHandle mousePressedHandle;
			Widget::EventHandle mouseReleaseHandle;
			Widget::EventHandle mouseClickedHandle;

			bool clickable;

			AttachIcon() : widget(NULL), clickable(false) {}
		};

		std::vector<AttachIcon*> m_attachIcons;

		struct AttachText
		{
			IText *widget;
			TRect alloc;
			TRegion colorPickingRange;
			ClutterColor bgColorPicking;
			ClutterColor fgColorExtracted;
			Color textColor;
			bool colorPickingReady;
			bool useReferenceColor;

			AttachText() : widget(NULL), colorPickingReady(false), useReferenceColor(true) {}
		}m_attachText;

		struct _ProgressBar
		{
			IProgress *progess;
			TRect alloc;
			bool slidable;

			_ProgressBar() : progess(NULL), slidable(false) {}
		}m_progressBar;

		struct _CheckMark
		{
			ImageWidget* widget;
			TRect alloc;
			std::string uncheckName;
			std::string checkedName;
			bool isChecked;

			_CheckMark() : widget(NULL), isChecked(false) {}
		}m_checkMark;

		IUtility* m_utility;

		ImageWidget *m_dimWin;
		bool m_dimUseImage;

		ImageWidget* m_defalut;

		ClutterAnimationMode m_scaleAniMode;
		int m_scaleAniDuration;
		ClutterAnimationMode m_resizeAniMode;
		int m_resizeAniDuration;

		bool m_enabled;
		bool m_fontScaleEnabled;

		std::string m_ttsText;

		class CThumbnailListenerSet* m_listenerSet;
		
		class CScrollPlayer* m_scrollPlayer;
		bool m_scrollPlayerAsyncLoad;
		class CSingleLineDataSource* m_scrollDataSource;

		class CScrollPlayerHandler* m_scrollPlayerHandler;
#ifndef WIN32
		class CVideoActor* m_videoActor;
#endif
	};

	class CThumbnailNormal : public CThumbnail
	{
	private:
		//ImageWidget* image;   
	};

	class CThumbnailVideo : public CThumbnail
	{
	public:
		struct TThumbnailVideoAttr : public TThumbnailAttr
		{
			std::string uri;
		};
	private:
		//VideoWidget* video;
	};

	class CScrollData : public IData
	{
	public:
		std::string imageSrc;
		int index;
		bool async;
	};

	class CScrollPlayerHandler : public IRendererProvider, public CScrollPlayerListener
	{
	public:
		CScrollPlayerHandler(CThumbnail* owner) : m_owner(owner){}
		virtual ~CScrollPlayerHandler(void){}

	public:
		virtual IRenderer* GetRenderer(IData *data, IActor* parent);

	public:
		virtual void OnItemLoad(class CScrollPlayer *scrollPlayer, int itemIndex){};
		virtual void OnItemUnload(class CScrollPlayer *scrollPlayer, int itemIndex){};

	private:
		ImageWidgetReadyCallback m_RegisterReadyCallback(class CScrollPlayerRenderer *renderer);
		static void m_ImageLoadReadyCallback(class CScrollPlayerHandler* pThis, CScrollPlayerRenderer *renderer, bool success);

		class CThumbnail *m_owner;

		friend class CThumbnail;
	};

	class CScrollPlayerRenderer : public IRenderer
	{
		friend class CScrollPlayerHandler;
	public:
		CScrollPlayerRenderer(IActor *parent) : m_dataIndex(-1) {}

		~CScrollPlayerRenderer() {}

		void Draw(IData *data, IActor* parent, E_DRAW_TYPE drawType);
		void Update(IData *data, IActor* parent){}
		void Resize(IData *data, IActor* parent, ClutterSize destSize, bool flagAni, int animationDuration){};

	private:
		ImageWidget* m_image;

		int m_dataIndex;
	};

}

#endif //_CTHUMBNAIL_H_
