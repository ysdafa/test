#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{

	IRichText* IRichText::CreateInstance(IActor* parent, float width, float height)
	{
		CRichText* richtext = dynamic_cast<CRichText*>(Instance::CreateInstance(CLASS_ID_IRICHTEXT));

		if (NULL != richtext)
		{
			richtext->Initialize(parent, width, height);
		}

		return richtext;
	}

	IRichText* IRichText::CreateInstance(Widget* parent, float width, float height)
	{
		CRichText* text = dynamic_cast<CRichText*>(Instance::CreateInstance(CLASS_ID_IRICHTEXT));

		if (NULL != text)
		{
			text->Initialize(parent, width, height);
		}

		return text;
	}

}