#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{

	ICheckBoxGroup* ICheckBoxGroup::CreateInstance()
	{
		CCheckBoxGroup* buttonGroup = dynamic_cast<CCheckBoxGroup*>(Instance::CreateInstance(CLASS_ID_ICHECKBOXGROUP));

		if (NULL != buttonGroup)
		{
			buttonGroup->Initialize();
		}

		return buttonGroup;
	}
}