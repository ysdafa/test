#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	IRectangle* IRectangle::CreateInstance(IActor* parent, float width, float height)
	{
		CRectangle* rectangle = dynamic_cast<CRectangle*>(Instance::CreateInstance(CLASS_ID_IRECTANGLE));
		ASSERT(rectangle != NULL);

		if (NULL != rectangle)
		{
			rectangle->Initialize(parent, width, height);
		}

		return rectangle;
	}

	IRectangle* IRectangle::CreateInstance(Widget* parent, float width, float height)
	{
		CRectangle* rectangle = dynamic_cast<CRectangle*>(Instance::CreateInstance(CLASS_ID_IRECTANGLE));
		ASSERT(rectangle != NULL);

		if (NULL != rectangle)
		{
			rectangle->Initialize(parent, width, height);
		}

		return rectangle;

	}

}