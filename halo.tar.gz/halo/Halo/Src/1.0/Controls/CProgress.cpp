#include "Halo1_0.h"

namespace HALO
{
	static HALO::util::Logger LOGGER("CProgress");
	static const char* THUMB_DRAG_ACTION_NAME = "thumb-drag-action-name";
	static const char* TRACK_CLICK_ACTION_NAME = "track-click-action-name";

	const static int DEFAULT_MIN_VALUE = 0;
	const static int DEFAULT_MAX_VALUE = 100;
	const static int INVALIDE_VALUE = -1;

	void static FactorApproximateValue(float &factor)
	{
		HALO_ASSERT(factor >= 0);
		if (factor < 0.005)
		{
			factor = 0;
		} 
		else if (factor > 0.995)
		{
			factor = 1.0;
		}
	}

	void CProgress::m_OnThumbDragMotion(ClutterDragAction *action, ClutterActor *actor, gfloat delta_x, gfloat delta_y, CProgress* progress)
	{		
		progress->m_ThumbMoved();
	}

	void CProgress::m_OnProgressClicked(ClutterClickAction *action, ClutterActor *actor, CProgress *progress)
	{
		gfloat pressX, pressY;
		clutter_click_action_get_coords(action, &pressX, &pressY);

		Vector3 position = progress->getAbsolutePosition();		// get absolute position on screen
		float x = pressX - position.x;
		float y = pressY - position.y;

		x = progress->t_MultiResolutionConvert1920(x);			// convert to 1920 resolution coordinate
		y = progress->t_MultiResolutionConvert1920(y);

		progress->m_OnProgressClick(x, y);	
	}

	CProgress::CProgress() : m_direction(TYPE_HORIZONTAL),
		m_reverseFlag(false),
		m_bgImage(NULL),
		m_progressImage(NULL),
		//m_thumbActor(NULL),
		//m_thumbImageWidget(NULL),
		m_thumbImage(NULL),
		m_active(false),
		m_minValue(INVALIDE_VALUE),
		m_value(INVALIDE_VALUE),
		m_maxValue(INVALIDE_VALUE)
	{
		H_LOG_TRACE(LOGGER, "CProgress::CProgress()");

	}

	CProgress::~CProgress()
	{
		H_LOG_TRACE(LOGGER, "CProgress::~CProgress()");

		delete m_progressImage;
		m_progressImage = NULL;

		delete m_bgImage;
		m_bgImage = NULL;

		//delete m_thumbImageWidget;
		//m_thumbImageWidget = NULL;
		delete m_thumbImage;
		m_thumbImage = NULL;

		RemoveFocusListener(this);
	}

	bool CProgress::AddListener(IProgressListener* listener)
	{
		H_LOG_TRACE(LOGGER, "CProgress::AddListener(" << listener << ")");
		HALO_ASSERT(listener != NULL);

		m_listenerSet.insert(listener);
		return true;
	}

	bool CProgress::RemoveListener(IProgressListener* listener)
	{
		H_LOG_TRACE(LOGGER, "CProgress::RemoveListener(" << listener << ")");
		HALO_ASSERT(listener != NULL);

		m_listenerSet.erase(listener);
		return true;
	}

	bool CProgress::Initialize(IActor* parent, float width, float height, EDirectionType direction)
	{
		H_LOG_TRACE(LOGGER, "CProgress::Initialize(" << parent << ", " << width << ", " << height << ", " << direction << ")");

		Widget *widget = dynamic_cast<Widget *>(parent);
		return Initialize(widget, width, height, direction);
	}

	bool CProgress::Initialize(Widget* parent, float width, float height, EDirectionType direction)
	{
		H_LOG_TRACE(LOGGER, "CProgress::Initialize(" << parent << ", " << width << ", " << height << ", " << direction << ")");

		//ASSERT(parent != NULL);
		CActor::Initialize(parent, width, height);
		m_direction = direction;

		Widget *widget = dynamic_cast<Widget*>(this);
		if (widget != NULL)
		{
			// background image fills this actor region
			m_bgImage = IImage::CreateInstance(widget, width, height);
			// progress image
			m_progressImage = IImage::CreateInstance(widget, 0, 0);	// begin with zero
			if (m_bgImage == NULL || m_progressImage == NULL)
			{
				return false;
			}

			//m_thumbActor = IActor::CreateInstance(widget, 0, 0);
			//if (m_thumbActor == NULL)
			//{
			//	return false;
			//}
			//ClutterColor color = { 255, 255, 255, 0 };
			//m_thumbActor->SetBackgroundColor(color);	// just for easy debug
			//m_thumbImageWidget = new ImageWidget(0.0f, 0.0f, 0.0f, 0.0f, dynamic_cast<Widget*>(m_thumbActor), nullptr);
			//m_thumbImageWidget->setAsyncLoading(false);
			//m_thumbImageWidget->show();		
			m_thumbImage = ICompositeImage::CreateInstance(widget, 0.0f, 0.0f);
		}

		// make sure progress image is not overlapped background image
		clutter_actor_set_child_above_sibling(t_actor, m_progressImage->Actor(), m_bgImage->Actor());

		// set default align constraint
		m_SetAlignConstraint();

		//m_thumbActor->AddMouseListener(this);		// for mousePointIn/mousePointOut
		//m_thumbImage->AddMouseListener(this);

		// progress bar will not support orientation revert automatically
		for (uint i = 0; i < this->getChildCount(); ++i)
		{
			Widget *child = this->getChildByIndex(i);
			static_cast<CActor *>(child)->EnableReverse(false);
		}		

		EnableFocus(true);
		AddFocusListener(this);

		return true;
	}

	void CProgress::SetValue( int value )
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetValue(" << value << ")");

		//if (value < m_minValue)
		//{
		//	value = m_minValue;
		//}
		//if (value > m_maxValue)
		//{
		//	value = m_maxValue;
		//}
		//H_LOG_TRACE(LOGGER, "Real CProgress::SetValue(" << value << ")");

		m_value = value;

		//m_StateChanged();
		m_ValueChanged();
	}

	int CProgress::Value(void) const
	{
		H_LOG_TRACE(LOGGER, "CProgress::Value()");
		//ASSERT(m_value != INVALIDE_VALUE);

		return m_value;
	}

	void CProgress::SetReverse( bool flagReverse )
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetReverse(" << flagReverse << ")");

		if (m_reverseFlag == flagReverse)
		{
			return;
		}

		m_reverseFlag = flagReverse;

		m_SetAlignConstraint();
		m_ValueChanged();
	}

	bool CProgress::FlagReverse( void ) const
	{
		H_LOG_TRACE(LOGGER, "CProgress::FlagReverse()");

		return m_reverseFlag;
	}

	void CProgress::SetBackgroundImage( IImageBuffer* image )
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetBackgroundImage(" << image << ")");
		HALO_ASSERT(image != NULL);

		m_bgImage->SetImage(image);
	}

	void CProgress::SetProgressImage( IImageBuffer* image )
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetProgressImage(" << image << ")");
		HALO_ASSERT(image != NULL);

		m_progressImage->SetImage(image);
	}

	void CProgress::SetBackgroundColor(const ClutterColor& color)
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetBackgroundColor()");

		// needed! Since widget bridge will set default color to {255, 255, 255, 255}, which not we wanted
		ClutterColor transparent = { 255, 255, 255, 0 };
		clutter_actor_set_background_color(t_actor, &transparent);

		m_bgImage->SetBackgroundColor(color);
	}

	void CProgress::SetProgressColor(const ClutterColor& color)
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetProgressColor()");
		m_progressImage->SetBackgroundColor(color);
	}

	const char* CProgress::GetActorType(void)
	{
		return "Progress";
	}
	
	void CProgress::m_SetAlignConstraint()
	{
		ClutterActor *progressImageActor = m_progressImage->Actor();
		ClutterActor *backgroundImageActor = m_bgImage->Actor();
		//ClutterActor *thumbActor = m_thumbActor->Actor();
		ClutterActor *thumbActor = m_thumbImage->Actor();
		if (m_direction == TYPE_HORIZONTAL)
		{
			if (!m_reverseFlag)
			{
				// from left to right
				clutter_actor_add_constraint(progressImageActor,
					clutter_align_constraint_new(backgroundImageActor, CLUTTER_ALIGN_X_AXIS, 0));

				clutter_actor_add_constraint(progressImageActor,
					clutter_align_constraint_new(backgroundImageActor, CLUTTER_ALIGN_Y_AXIS, 0.5));
			}
			else
			{
				// from right to left
				clutter_actor_add_constraint(progressImageActor,
					clutter_align_constraint_new(backgroundImageActor, CLUTTER_ALIGN_X_AXIS, 1));

				clutter_actor_add_constraint(progressImageActor,
					clutter_align_constraint_new(backgroundImageActor, CLUTTER_ALIGN_Y_AXIS, 0.5));
			}

			clutter_actor_add_constraint(thumbActor,
				clutter_align_constraint_new(progressImageActor, CLUTTER_ALIGN_Y_AXIS, 0.5));
		}

		if (m_direction == TYPE_VERTICAL)
		{
			if (!m_reverseFlag)
			{
				// from bottom to up
				clutter_actor_add_constraint(progressImageActor,
					clutter_align_constraint_new(backgroundImageActor, CLUTTER_ALIGN_X_AXIS, 0.5));

				clutter_actor_add_constraint(progressImageActor,
					clutter_align_constraint_new(backgroundImageActor, CLUTTER_ALIGN_Y_AXIS, 1));
			}
			else
			{
				// from top to bottom
				clutter_actor_add_constraint(progressImageActor,
					clutter_align_constraint_new(backgroundImageActor, CLUTTER_ALIGN_X_AXIS, 0.5));

				clutter_actor_add_constraint(progressImageActor,
					clutter_align_constraint_new(backgroundImageActor, CLUTTER_ALIGN_Y_AXIS, 0));
			}

			clutter_actor_add_constraint(thumbActor,
				clutter_align_constraint_new(progressImageActor, CLUTTER_ALIGN_X_AXIS, 0.5));
		}
	}

	bool CProgress::FlagActive(void) const
	{
		H_LOG_TRACE(LOGGER, "CProgress::FlagActive()");

		return m_active;
	}

	void CProgress::SetActive(bool flagActive)
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetActive(" << flagActive << ")");
		if (m_active == flagActive)
		{
			return;
		}
		
		m_active = flagActive;

		// add/remove actions
		//ClutterActor* thumbActor = m_thumbActor->Actor();
		ClutterActor* thumbActor = m_thumbImage->Actor();
		ClutterActor* fillActor = m_progressImage->Actor();
		ClutterActor* trackActor = m_bgImage->Actor();
		if (flagActive)
		{
			// Add drag support for thumb, the rectangle area will be set in SetThumbSize()
			ClutterAction* thumbDragAction = clutter_drag_action_new();
			clutter_actor_add_action_with_name(thumbActor, THUMB_DRAG_ACTION_NAME, thumbDragAction);
			g_signal_connect(thumbDragAction, "drag-motion", G_CALLBACK(m_OnThumbDragMotion), this);
			clutter_actor_set_reactive(thumbActor, true);
			m_SetDragArea();

			// Add click support
			ClutterAction* clickAction = clutter_click_action_new();
			clutter_actor_add_action_with_name(trackActor, TRACK_CLICK_ACTION_NAME, clickAction);
			g_signal_connect(clickAction, "clicked", G_CALLBACK(m_OnProgressClicked), this);
			clutter_actor_set_reactive(trackActor, true);

			m_thumbImage->AddMouseListener(this);
		} 
		else
		{
			clutter_actor_remove_action_by_name(thumbActor, THUMB_DRAG_ACTION_NAME);
			clutter_actor_remove_action_by_name(trackActor, TRACK_CLICK_ACTION_NAME);

			m_thumbImage->RemoveMouseListener(this);
		}
	}

	void CProgress::GetThumbSize(float &width, float &height) const
	{
		H_LOG_TRACE(LOGGER, "CProgress::GetThumbSize()");

		//m_thumbActor->GetSize(width, height);
		m_thumbImage->GetSize(width, height);
	}

	void CProgress::SetThumbSize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetThumbSize(" << width << ", " << height << ")");
		HALO_ASSERT(width >= 0);
		HALO_ASSERT(height >= 0);

		//m_thumbActor->Resize(width, height);
		//m_thumbImageWidget->setWidth(width);
		//m_thumbImageWidget->setHeight(height);
		m_thumbImage->Resize(width, height);

		m_SetDragArea();	
		m_ValueChanged();			// thumb has width/height
	}

	void CProgress::SetFocusThumbImage(const std::string& focusThumbImagePath)
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetFocusThumbImage(" << focusThumbImagePath << ")");

		m_focusThumbImage = focusThumbImagePath;
	}

	void CProgress::SetNormalThumbImage(const std::string& normalThumbImagePath)
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetNormalThumbImage(" << normalThumbImagePath << ")");

		m_normalThumbImage = normalThumbImagePath;
		//m_thumbImageWidget->setSource(m_normalThumbImage);
		m_thumbImage->SetImage(m_normalThumbImage.c_str());
	}

	void CProgress::m_ValueChanged()
	{
		if (m_minValue == INVALIDE_VALUE || m_value == INVALIDE_VALUE || m_maxValue == INVALIDE_VALUE)
		{
			return;
		}
		HALO_ASSERT(m_minValue >= 0);
		HALO_ASSERT(m_value >= m_minValue);
		HALO_ASSERT(m_maxValue >= m_value);
		HALO_ASSERT(m_maxValue > m_minValue);

		float factor = static_cast<float>(m_value - m_minValue) / (m_maxValue - m_minValue);
		//ClutterActor* thumb = m_thumbActor->Actor();
		//ClutterActor* thumb = m_thumbImage->Actor();
		CWidgetEx* thumb = dynamic_cast<CWidgetEx *>(m_thumbImage);
		if (thumb == NULL)
		{
			HALO_EXCEPTION(false, "m_thumbImage is not CWidgetEx type.");
			return;
		}		

		// 1, move thumb
		if (m_direction == TYPE_HORIZONTAL)
		{
			//gfloat validWidth = clutter_actor_get_width(t_actor) - clutter_actor_get_width(thumb);
			gfloat validWidth = this->getWidth() - thumb->getWidth();
			gfloat x = 0;
			if (m_reverseFlag)
			{
				x = (1 - factor) * validWidth;
			} 
			else
			{
				x = factor * validWidth;
			}
			thumb->setX(x);
		}
		else
		{
			//gfloat validHeight = clutter_actor_get_height(t_actor) - clutter_actor_get_height(thumb);
			gfloat validHeight = this->getHeight() - thumb->getHeight();
			gfloat y = 0;
			if (m_reverseFlag)
			{
				y = factor * validHeight;
			}
			else
			{
				y = (1 - factor) * validHeight;
			}
			thumb->setY(y);
		}

		// 2, resize fill actor color
		float width = 0;
		float height = 0;
		GetSize(width, height);
		if (m_direction == TYPE_HORIZONTAL)
		{
			gfloat validWidth = this->getWidth() - thumb->getWidth();
			width = thumb->getWidth() / 2 + factor * validWidth;
		}
		else			// vertical progress bar
		{
			gfloat validHeight = this->getHeight() - thumb->getHeight();
			height = thumb->getHeight() / 2 + factor * validHeight;
		}

		ClutterActor* fillActor = m_progressImage->Actor();
		m_progressImage->Resize(width, height);

		// 3, update listeners
		for (std::set<IProgressListener *>::iterator iter = m_listenerSet.begin(); iter != m_listenerSet.end(); ++iter)
		{
			HALO_ASSERT(*iter != NULL);
			(*iter)->OnValueChanged(this);
		}
	}

	void CProgress::m_ThumbMoved()
	{
		float factor = 0;
		//ClutterActor* thumb = m_thumbActor->Actor();
		CWidgetEx* thumb = dynamic_cast<CWidgetEx *>(m_thumbImage);
		if (thumb == NULL)
		{
			HALO_EXCEPTION(false, "m_thumbImage is not CWidgetEx type.");
			return;
		}

		if (m_direction == TYPE_HORIZONTAL)
		{
			float currentX = thumb->getX();
			float validWidth = this->getWidth() - thumb->getWidth();
			factor = currentX / validWidth;
			FactorApproximateValue(factor);
			if (m_reverseFlag)
			{
				factor = 1 - factor;
			}
			
			m_value = m_minValue + static_cast<int>(factor * (m_maxValue - m_minValue));

			//ClutterActor* fillActor = m_progressImage->Actor();
			//clutter_actor_set_width(fillActor, clutter_actor_get_width(thumb) / 2 + (clutter_actor_get_width(t_actor) - clutter_actor_get_width(thumb)) * factor);;
			//clutter_actor_set_height(fillActor, clutter_actor_get_height(t_actor));

			gfloat fillWidth = thumb->getWidth() / 2 + validWidth * factor;
			m_progressImage->Resize(fillWidth, this->getHeight());
		}
		else
		{
			float currentY = thumb->getY();
			float validHeight = this->getHeight() - thumb->getHeight();
			factor = 1 - currentY / validHeight;		// bottom is zero
			FactorApproximateValue(factor);
			if (m_reverseFlag)
			{
				factor = 1 - factor;
			}

			//ClutterActor* fillActor = m_progressImage->Actor();
			//clutter_actor_set_height(fillActor, clutter_actor_get_height(thumb) / 2 + (clutter_actor_get_height(t_actor) - clutter_actor_get_height(thumb) ) * factor);
			//clutter_actor_set_width(fillActor, clutter_actor_get_width(t_actor));

			gfloat fillHeight = thumb->getHeight() / 2 + validHeight * factor;
			m_progressImage->Resize(this->getWidth(), fillHeight);
		}

		m_value = m_minValue + static_cast<int>(factor * (m_maxValue - m_minValue));
		for (std::set<IProgressListener *>::iterator iter = m_listenerSet.begin(); iter != m_listenerSet.end(); ++iter)
		{
			HALO_ASSERT(*iter != NULL);
			(*iter)->OnValueChanged(this);
		}
	}

	void CProgress::m_SetDragArea() // thumb size will effect it
	{
		if (!m_active)
		{
			return;
		}
		//ClutterActor* thumbActor = m_thumbActor->Actor();
		ClutterActor* thumbActor = m_thumbImage->Actor();
		ClutterActor* trackActor = m_bgImage->Actor();

		// need not convert to 1920 resolution
		ClutterAction* thumbDragAction = clutter_actor_get_action(thumbActor, THUMB_DRAG_ACTION_NAME);
		HALO_ASSERT(thumbDragAction != NULL);

		if (m_direction == TYPE_HORIZONTAL)
		{
			// set drag action attributes
			clutter_drag_action_set_drag_axis(CLUTTER_DRAG_ACTION(thumbDragAction), CLUTTER_DRAG_X_AXIS);
			ClutterRect rect;
			rect.origin.x = 0;
			rect.origin.y = 0;
			rect.size.width = clutter_actor_get_width(trackActor) - clutter_actor_get_width(thumbActor);
			rect.size.height = clutter_actor_get_height(trackActor);
			clutter_drag_action_set_drag_area(CLUTTER_DRAG_ACTION(thumbDragAction), &rect);
		}
		else
		{
			// set drag action attributes
			clutter_drag_action_set_drag_axis(CLUTTER_DRAG_ACTION(thumbDragAction), CLUTTER_DRAG_Y_AXIS);
			ClutterRect rect;
			rect.origin.x = 0;
			rect.origin.y = 0;
			rect.size.width = clutter_actor_get_width(trackActor);
			rect.size.height = clutter_actor_get_height(trackActor) - clutter_actor_get_height(thumbActor);
			clutter_drag_action_set_drag_area(CLUTTER_DRAG_ACTION(thumbDragAction), &rect);
		}
	}

	bool CProgress::OnMousePointerIn(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_TRACE(LOGGER, "CScroll::OnMousePointerIn(" << pWindow << ", " << ptrMouseEvent << ")");

		// pointing on thumb
		if (pWindow == dynamic_cast<CActor *>(m_bgImage))
		{
			//m_thumbImageWidget->setSource(m_normalThumbImage);
			m_thumbImage->SetImage(m_normalThumbImage.c_str());
		}
		//else if (pWindow == dynamic_cast<CActor *>(m_thumbActor))
		else if (pWindow == dynamic_cast<CActor *>(m_thumbImage))
		{
			//m_thumbImageWidget->setSource(m_focusThumbImage);
			m_thumbImage->SetImage(m_focusThumbImage.c_str());
		}

		return true;
	}

	bool CProgress::OnMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_TRACE(LOGGER, "CScroll::OnMousePointerOut(" << pWindow << ", " << ptrMouseEvent << ")");

		//m_thumbImageWidget->setSource(m_normalThumbImage);
		m_thumbImage->SetImage(m_normalThumbImage.c_str());

		return true;
	}

	void CProgress::m_OnProgressClick(float x, float y)
	{
		// both input x/y and width/height have transformed to 1920 resolution
		float trackWidth = this->getWidth();
		float trackHeight = this->getHeight();
		//GetSize(trackWidth, trackHeight);

		float thumbWidth = 0;
		float thumbHeight = 0;
		m_thumbImage->GetSize(thumbWidth, thumbHeight);

		CWidgetEx* thumb = dynamic_cast<CWidgetEx *>(m_thumbImage);
		if (thumb == NULL)
		{
			HALO_EXCEPTION(false, "m_thumbImage is not CWidgetEx type.");
			return;
		}

		float factor = 0;
		if (m_direction == TYPE_HORIZONTAL)
		{
			float validWidth = trackWidth - thumbWidth;
			if (x < thumbWidth/2)
			{
				factor = 0;
				thumb->setX(0);
			}
			else if (x > trackWidth - thumbWidth / 2)
			{
				factor = 1.0;
				thumb->setX(validWidth);
			}
			else
			{
				factor = (x - thumbWidth / 2) / validWidth;
				thumb->setX(x - thumbWidth / 2);
			}
				
			if (m_reverseFlag)
			{
				factor = 1 - factor;
			}

			//ClutterActor* fillActor = m_progressImage->Actor();
			//clutter_actor_set_width(fillActor, thumbWidth / 2 + validWidth * factor);;
			//clutter_actor_set_height(fillActor, clutter_actor_get_height(t_actor));

			m_progressImage->Resize(thumb->getWidth() / 2 + validWidth * factor, trackHeight);
		}
		else
		{
			float validHeight = trackHeight - thumbHeight;
			if (y < thumbHeight / 2)
			{
				factor = 1.0;
				thumb->setY(0);
			}
			else if (y > trackHeight - thumbHeight / 2)
			{
				factor = 0;
				thumb->setY(validHeight);
			}
			else
			{
				//clutter_actor_set_y(m_thumbImage->Actor(), y - thumbHeight / 2);
				factor = 1 - (y - thumbHeight / 2) / validHeight;;
				thumb->setY(y - thumbHeight / 2);
			}

			if (m_reverseFlag)
			{
				factor = 1 - factor;
			}

			//ClutterActor* fillActor = m_progressImage->Actor();
			//clutter_actor_set_height(fillActor, thumbHeight / 2 + validHeight * factor);
			//clutter_actor_set_width(fillActor, clutter_actor_get_width(t_actor));

			m_progressImage->Resize(trackWidth, thumbHeight / 2 + validHeight * factor);
		}
		
		m_value = m_minValue + static_cast<int>(factor * (m_maxValue - m_minValue));

		for (std::set<IProgressListener *>::iterator iter = m_listenerSet.begin(); iter != m_listenerSet.end(); ++iter)
		{
			HALO_ASSERT(*iter != NULL);
			(*iter)->OnValueChanged(this);
		}
	}

	void CProgress::Resize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CProgress::Resize(" << width << ", " << height << ")");

		CActor::Resize(width, height);

		m_bgImage->Resize(width, height);
		//m_progressImage->Resize(width, height);

		m_ValueChanged();
	}

	void CProgress::SetMinValue(int minValue)
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetMinValue(" << minValue << ")");

		HALO_ASSERT(minValue >= 0);

		m_minValue = minValue;
		m_ValueChanged();
	}

	int CProgress::MinValue(void) const
	{
		HALO_ASSERT(m_minValue != INVALIDE_VALUE);

		return m_minValue;
	}

	void CProgress::SetMaxValue(int maxValue)
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetMaxValue(" << maxValue << ")");

		HALO_ASSERT(maxValue >= 0);

		m_maxValue = maxValue;
		m_ValueChanged();
	}

	int CProgress::MaxValue(void) const
	{
		HALO_ASSERT(m_maxValue != INVALIDE_VALUE);

		return m_maxValue;
	}

	std::string CProgress::NormalThumbImage(void) const
	{
		return m_normalThumbImage;
	}

	std::string CProgress::FocusThumbImage(void) const
	{
		return m_focusThumbImage;
	}

	bool CProgress::OnFocusIn(IWidgetExtension* pWindow)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CProgress::OnFocusIn().");
		if (IsFocusEnabled())
		{
			//m_thumbImageWidget->setSource(m_focusThumbImage);
			m_thumbImage->SetImage(m_focusThumbImage.c_str());
		}

		return true;
	}

	bool CProgress::OnFocusOut(IWidgetExtension* pWindow)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CProgress::OnFocusOut().");
		if (IsFocusEnabled())
		{
			//m_thumbImageWidget->setSource(m_normalThumbImage);
			m_thumbImage->SetImage(m_normalThumbImage.c_str());
		}

		return true;
	}
	

	//void CProgress::t_UpdateOrientation(EOrientation orientation)
	//{
	//	ASSERT(orientation != ORIENTATION_REFER_TO_PARENT);

	//	switch (orientation)
	//	{
	//	case HALO::ORIENTATION_LEFT_TO_RIGHT:
	//		this->SetReverse(false);
	//		break;

	//	case HALO::ORIENTATION_RIGHT_TO_LEFT:
	//		this->SetReverse(true);
	//		break;

	//	default:
	//		ASSERT(0 && "Should not reach here.");
	//		break;
	//	}
	//}
}
