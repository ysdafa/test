#include "Halo1_0.h"

namespace HALO
{
	static HALO::util::Logger LOGGER("CProgress");
	static const char* THUMB_DRAG_ACTION_NAME = "thumb-drag-action-name";
	static const char* TRACK_CLICK_ACTION_NAME = "track-click-action-name";

	const static int DEFAULT_MIN_VALUE = 0;
	const static int DEFAULT_MAX_VALUE = 100;
	const static int INVALIDE_VALUE = -1;

	void static FactorApproximateValue(float &factor)
	{
		ASSERT(factor >= 0);
		if (factor < 0.005)
		{
			factor = 0;
		} 
		else if (factor > 0.995)
		{
			factor = 1.0;
		}
	}

	void CProgress::m_OnThumbDragMotion(ClutterDragAction *action, ClutterActor *actor, gfloat delta_x, gfloat delta_y, CProgress* progress)
	{		
		progress->m_ThumbMoved();
	}

	void CProgress::m_OnProgressClicked(ClutterClickAction *action, ClutterActor *actor, CProgress *progress)
	{
		gfloat pressX, pressY;
		clutter_click_action_get_coords(action, &pressX, &pressY);

		Vector3 position = progress->getAbsolutePosition();		// get absolute position on screen
		float x = pressX - position.x;
		float y = pressY - position.y;

		progress->m_OnProgressClick(x, y);	
	}

	CProgress::CProgress() : m_direction(TYPE_HORIZONTAL),
		m_reverseFlag(false),
		m_bgImage(NULL),
		m_progressImage(NULL),
		m_thumbActor(NULL),
		m_thumbImageWidget(NULL),
		m_active(false),
		m_minValue(INVALIDE_VALUE),
		m_value(INVALIDE_VALUE),
		m_maxValue(INVALIDE_VALUE)
	{
		H_LOG_TRACE(LOGGER, "CProgress::CProgress()");

	}

	CProgress::~CProgress()
	{
		H_LOG_TRACE(LOGGER, "CProgress::~CProgress()");

		delete m_progressImage;
		m_progressImage = NULL;

		delete m_bgImage;
		m_bgImage = NULL;

		delete m_thumbImageWidget;
		m_thumbImageWidget = NULL;
	}

	bool CProgress::AddListener(IProgressListener* listener)
	{
		H_LOG_TRACE(LOGGER, "CProgress::AddListener(" << listener << ")");
		ASSERT(listener != NULL);

		m_listenerSet.insert(listener);
		return true;
	}

	bool CProgress::RemoveListener(IProgressListener* listener)
	{
		H_LOG_TRACE(LOGGER, "CProgress::RemoveListener(" << listener << ")");
		ASSERT(listener != NULL);

		m_listenerSet.erase(listener);
		return true;
	}

	bool CProgress::Initialize(IActor* parent, float width, float height, EDirectionType direction)
	{
		H_LOG_TRACE(LOGGER, "CProgress::Initialize(" << parent << ", " << width << ", " << height << ", " << direction << ")");

		Widget *widget = dynamic_cast<Widget *>(parent);
		return Initialize(widget, width, height, direction);
	}

	bool CProgress::Initialize(Widget* parent, float width, float height, EDirectionType direction)
	{
		H_LOG_TRACE(LOGGER, "CProgress::Initialize(" << parent << ", " << width << ", " << height << ", " << direction << ")");

		//ASSERT(parent != NULL);
		CActor::Initialize(parent, width, height);
		m_direction = direction;

		Widget *widget = dynamic_cast<Widget*>(this);
		if (widget != NULL)
		{
			// background image fills this actor region
			m_bgImage = IImage::CreateInstance(widget, width, height);
			// progress image
			m_progressImage = IImage::CreateInstance(widget, 0, 0);	// begin with zero
			if (m_bgImage == NULL || m_progressImage == NULL)
			{
				return false;
			}

			m_thumbActor = IActor::CreateInstance(widget, 0, 0);
			if (m_thumbActor == NULL)
			{
				return false;
			}
			ClutterColor color = { 255, 255, 255, 0 };
			m_thumbActor->SetBackgroundColor(color);	// just for easy debug
			m_thumbImageWidget = new ImageWidget(0.0f, 0.0f, 0.0f, 0.0f, dynamic_cast<Widget*>(m_thumbActor), nullptr);
			m_thumbImageWidget->setAsyncLoading(false);
			m_thumbImageWidget->show();			
		}

		// make sure progress image is not overlapped background image
		clutter_actor_set_child_above_sibling(t_actor, m_progressImage->Actor(), m_bgImage->Actor());

		// set default align constraint
		m_SetAlignConstraint();

		m_thumbActor->AddMouseListener(this);		// for mousePointIn/mousePointOut

		return true;
	}

	void CProgress::SetValue( int value )
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetValue(" << value << ")");

		//if (value < m_minValue)
		//{
		//	value = m_minValue;
		//}
		//if (value > m_maxValue)
		//{
		//	value = m_maxValue;
		//}
		//H_LOG_TRACE(LOGGER, "Real CProgress::SetValue(" << value << ")");

		m_value = value;

		//m_StateChanged();
		m_ValueChanged();
	}

	int CProgress::Value(void) const
	{
		H_LOG_TRACE(LOGGER, "CProgress::Value()");
		//ASSERT(m_value != INVALIDE_VALUE);

		return m_value;
	}

	void CProgress::SetReverse( bool flagReverse )
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetReverse(" << flagReverse << ")");

		if (m_reverseFlag == flagReverse)
		{
			return;
		}

		m_reverseFlag = flagReverse;

		m_SetAlignConstraint();
		m_ValueChanged();
	}

	bool CProgress::FlagReverse( void ) const
	{
		H_LOG_TRACE(LOGGER, "CProgress::FlagReverse()");

		return m_reverseFlag;
	}

	void CProgress::SetBackgroundImage( IImageBuffer* image )
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetBackgroundImage(" << image << ")");

		ASSERT(image != NULL);

		m_bgImage->SetImage(image);
	}

	void CProgress::SetProgressImage( IImageBuffer* image )
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetProgressImage(" << image << ")");

		ASSERT(image != NULL);

		m_progressImage->SetImage(image);
	}

	void CProgress::SetBackgroundColor(const ClutterColor& color)
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetBackgroundColor()");

		// needed! Since widget bridge will set default color to {255, 255, 255, 255}, which not we wanted
		ClutterColor transparent = { 255, 255, 255, 0 };
		clutter_actor_set_background_color(t_actor, &transparent);

		m_bgImage->SetBackgroundColor(color);
	}

	void CProgress::SetProgressColor(const ClutterColor& color)
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetProgressColor()");
		m_progressImage->SetBackgroundColor(color);
	}

	const char* CProgress::GetActorType(void)
	{
		return "Progress";
	}
	
	void CProgress::m_SetAlignConstraint()
	{
		ClutterActor *progressImageActor = m_progressImage->Actor();
		ClutterActor *backgroundImageActor = m_bgImage->Actor();
		ClutterActor *thumbActor = m_thumbActor->Actor();
		if (m_direction == TYPE_HORIZONTAL)
		{
			if (!m_reverseFlag)
			{
				// from left to right
				clutter_actor_add_constraint(progressImageActor,
					clutter_align_constraint_new(backgroundImageActor, CLUTTER_ALIGN_X_AXIS, 0));

				clutter_actor_add_constraint(progressImageActor,
					clutter_align_constraint_new(backgroundImageActor, CLUTTER_ALIGN_Y_AXIS, 0.5));
			}
			else
			{
				// from right to left
				clutter_actor_add_constraint(progressImageActor,
					clutter_align_constraint_new(backgroundImageActor, CLUTTER_ALIGN_X_AXIS, 1));

				clutter_actor_add_constraint(progressImageActor,
					clutter_align_constraint_new(backgroundImageActor, CLUTTER_ALIGN_Y_AXIS, 0.5));
			}

			clutter_actor_add_constraint(thumbActor,
				clutter_align_constraint_new(progressImageActor, CLUTTER_ALIGN_Y_AXIS, 0.5));
		}

		if (m_direction == TYPE_VERTICAL)
		{
			if (!m_reverseFlag)
			{
				// from bottom to up
				clutter_actor_add_constraint(progressImageActor,
					clutter_align_constraint_new(backgroundImageActor, CLUTTER_ALIGN_X_AXIS, 0.5));

				clutter_actor_add_constraint(progressImageActor,
					clutter_align_constraint_new(backgroundImageActor, CLUTTER_ALIGN_Y_AXIS, 1));
			}
			else
			{
				// from top to bottom
				clutter_actor_add_constraint(progressImageActor,
					clutter_align_constraint_new(backgroundImageActor, CLUTTER_ALIGN_X_AXIS, 0.5));

				clutter_actor_add_constraint(progressImageActor,
					clutter_align_constraint_new(backgroundImageActor, CLUTTER_ALIGN_Y_AXIS, 0));
			}

			clutter_actor_add_constraint(thumbActor,
				clutter_align_constraint_new(progressImageActor, CLUTTER_ALIGN_X_AXIS, 0.5));
		}
	}

	bool CProgress::FlagActive(void) const
	{
		H_LOG_TRACE(LOGGER, "CProgress::FlagActive()");

		return m_active;
	}

	void CProgress::SetActive(bool flagActive)
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetActive()");
		if (m_active == flagActive)
		{
			return;
		}
		
		m_active = flagActive;

		// add/remove actions
		ClutterActor* thumbActor = m_thumbActor->Actor();
		ClutterActor* fillActor = m_progressImage->Actor();
		ClutterActor* trackActor = m_bgImage->Actor();
		if (flagActive)
		{
			// Add drag support for thumb, the rectangle area will be set in SetThumbSize()
			ClutterAction* thumbDragAction = clutter_drag_action_new();
			clutter_actor_add_action_with_name(thumbActor, THUMB_DRAG_ACTION_NAME, thumbDragAction);
			g_signal_connect(thumbDragAction, "drag-motion", G_CALLBACK(m_OnThumbDragMotion), this);
			clutter_actor_set_reactive(thumbActor, true);
			m_SetDragArea();

			// Add click support
			ClutterAction* clickAction = clutter_click_action_new();
			clutter_actor_add_action_with_name(trackActor, TRACK_CLICK_ACTION_NAME, clickAction);
			g_signal_connect(clickAction, "clicked", G_CALLBACK(m_OnProgressClicked), this);
			clutter_actor_set_reactive(trackActor, true);
		} 
		else
		{
			clutter_actor_remove_action_by_name(thumbActor, THUMB_DRAG_ACTION_NAME);
			clutter_actor_remove_action_by_name(trackActor, TRACK_CLICK_ACTION_NAME);
		}
	}

	void CProgress::GetThumbSize(float &width, float &height) const
	{
		H_LOG_TRACE(LOGGER, "CProgress::GetThumbSize()");

		m_thumbActor->GetSize(width, height);
	}

	void CProgress::SetThumbSize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetThumbSize(" << width << ", " << height << ")");
		ASSERT(width >= 0);
		ASSERT(height >= 0);

		m_thumbActor->Resize(width, height);
		m_thumbImageWidget->setWidth(width);
		m_thumbImageWidget->setHeight(height);

		if (m_direction == TYPE_HORIZONTAL)
		{
			clutter_actor_set_width(m_progressImage->Actor(), width / 2);
		} 
		else
		{
			clutter_actor_set_height(m_progressImage->Actor(), height / 2);
		}

		m_SetDragArea();	
		m_ValueChanged();			// thumb has width/height
	}

	void CProgress::SetFocusThumbImage(const std::string& focusThumbImagePath)
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetFocusThumbImage(" << focusThumbImagePath << ")");

		m_focusThumbImage = focusThumbImagePath;
	}

	void CProgress::SetNormalThumbImage(const std::string& normalThumbImagePath)
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetNormalThumbImage(" << normalThumbImagePath << ")");

		m_normalThumbImage = normalThumbImagePath;
		m_thumbImageWidget->setSource(m_normalThumbImage);
	}

	void CProgress::m_ValueChanged()
	{
		if (m_minValue == INVALIDE_VALUE || m_value == INVALIDE_VALUE || m_maxValue == INVALIDE_VALUE)
		{
			return;
		}
		ASSERT(m_minValue >= 0);
		ASSERT(m_value >= m_minValue);
		ASSERT(m_maxValue >= m_value);
		ASSERT(m_maxValue > m_minValue);

		float factor = static_cast<float>(m_value - m_minValue) / (m_maxValue - m_minValue);
		ClutterActor* thumb = m_thumbActor->Actor();

		// 1, move thumb
		if (m_direction == TYPE_HORIZONTAL)
		{
			gfloat validWidth = clutter_actor_get_width(t_actor) - clutter_actor_get_width(thumb);
			if (m_reverseFlag)
			{
				gfloat x = (1 - factor) * validWidth;
				clutter_actor_set_x(thumb, x);
			} 
			else
			{
				gfloat x = factor * validWidth;
				clutter_actor_set_x(thumb, x);
			}
		}
		else
		{
			//factor = static_cast<float>(m_value - m_minValue) / (m_maxValue - m_minValue);
			gfloat validHeight = clutter_actor_get_height(t_actor) - clutter_actor_get_height(thumb);
			if (m_reverseFlag)
			{
				gfloat y = factor * validHeight;
				clutter_actor_set_y(thumb, y);
			}
			else
			{
				gfloat y = (1 - factor) * validHeight;
				clutter_actor_set_y(thumb, y);
			}
		}

		// 2, resize fill actor color
		float width = 0;
		float height = 0;
		GetSize(width, height);
		if (m_direction == TYPE_HORIZONTAL)
		{
			gfloat validWidth = clutter_actor_get_width(t_actor) - clutter_actor_get_width(thumb);
			width = clutter_actor_get_width(thumb) / 2 + factor * validWidth;
		}
		else			// vertical progress bar
		{
			gfloat validHeight = clutter_actor_get_height(t_actor) - clutter_actor_get_height(thumb);
			height = clutter_actor_get_height(thumb) / 2 + factor * validHeight;
		}

		ClutterActor* fillActor = m_progressImage->Actor();
		//if (m_active == false)
		//{
		//	clutter_actor_save_easing_state(fillActor);
		//	clutter_actor_set_easing_duration(fillActor, 250);
		//	clutter_actor_set_easing_mode(fillActor, CLUTTER_LINEAR);
		//	clutter_actor_set_width(fillActor, width);
		//	clutter_actor_set_height(fillActor, height);
		//	clutter_actor_restore_easing_state(fillActor);
		//}
		//else
		//{
		//	clutter_actor_save_easing_state(fillActor);
		//	clutter_actor_set_easing_duration(fillActor, 1);		// need it. Seems clutter bug
		//	clutter_actor_set_easing_mode(fillActor, CLUTTER_LINEAR);
		//	clutter_actor_set_width(fillActor, width);
		//	clutter_actor_set_height(fillActor, height);
		//	clutter_actor_restore_easing_state(fillActor);
		//}	

		clutter_actor_set_width(fillActor, width);
		clutter_actor_set_height(fillActor, height);

		// 3, update listeners
		for (std::set<IProgressListener *>::iterator iter = m_listenerSet.begin(); iter != m_listenerSet.end(); ++iter)
		{
			ASSERT(*iter != NULL);
			(*iter)->OnValueChanged(this);
		}
	}

	void CProgress::m_ThumbMoved()
	{
		float factor = 0;
		ClutterActor* thumb = m_thumbActor->Actor();
		if (m_direction == TYPE_HORIZONTAL)
		{
			float currentX = clutter_actor_get_x(thumb);
			float validWidth = clutter_actor_get_width(t_actor) - clutter_actor_get_width(thumb);
			factor = currentX / validWidth;
			FactorApproximateValue(factor);
			if (m_reverseFlag)
			{
				factor = 1 - factor;
			}
			
			m_value = m_minValue + static_cast<int>(factor * (m_maxValue - m_minValue));

			ClutterActor* fillActor = m_progressImage->Actor();
			clutter_actor_set_width(fillActor, clutter_actor_get_width(thumb) / 2 + (clutter_actor_get_width(t_actor) - clutter_actor_get_width(thumb)) * factor);;
			clutter_actor_set_height(fillActor, clutter_actor_get_height(t_actor));
		}
		else
		{
			float currentY = clutter_actor_get_y(thumb);
			float validHeight = clutter_actor_get_height(t_actor) - clutter_actor_get_height(thumb);
			factor = 1 - currentY / validHeight;		// bottom is zero
			FactorApproximateValue(factor);
			if (m_reverseFlag)
			{
				factor = 1 - factor;
			}

			ClutterActor* fillActor = m_progressImage->Actor();
			clutter_actor_set_height(fillActor, clutter_actor_get_height(thumb) / 2 + (clutter_actor_get_height(t_actor) - clutter_actor_get_height(thumb) ) * factor);
			clutter_actor_set_width(fillActor, clutter_actor_get_width(t_actor));
		}

		m_value = m_minValue + static_cast<int>(factor * (m_maxValue - m_minValue));
		for (std::set<IProgressListener *>::iterator iter = m_listenerSet.begin(); iter != m_listenerSet.end(); ++iter)
		{
			ASSERT(*iter != NULL);
			(*iter)->OnValueChanged(this);
		}
	}

	void CProgress::m_SetDragArea() // thumb size will effect it
	{
		if (!m_active)
		{
			return;
		}
		ClutterActor* thumbActor = m_thumbActor->Actor();
		ClutterActor* tintActor = m_progressImage->Actor();
		ClutterActor* trackActor = m_bgImage->Actor();

		ClutterAction* thumbDragAction = clutter_actor_get_action(thumbActor, THUMB_DRAG_ACTION_NAME);
		ASSERT(thumbDragAction != NULL);

		if (m_direction == TYPE_HORIZONTAL)
		{
			// set drag action attributes
			clutter_drag_action_set_drag_axis(CLUTTER_DRAG_ACTION(thumbDragAction), CLUTTER_DRAG_X_AXIS);
			ClutterRect rect;
			rect.origin.x = 0;
			rect.origin.y = 0;
			rect.size.width = clutter_actor_get_width(trackActor) - clutter_actor_get_width(thumbActor);
			rect.size.height = clutter_actor_get_height(trackActor);
			clutter_drag_action_set_drag_area(CLUTTER_DRAG_ACTION(thumbDragAction), &rect);
		}
		else
		{
			// set drag action attributes
			clutter_drag_action_set_drag_axis(CLUTTER_DRAG_ACTION(thumbDragAction), CLUTTER_DRAG_Y_AXIS);
			ClutterRect rect;
			rect.origin.x = 0;
			rect.origin.y = 0;
			rect.size.width = clutter_actor_get_width(trackActor);
			rect.size.height = clutter_actor_get_height(trackActor) - clutter_actor_get_height(thumbActor);
			clutter_drag_action_set_drag_area(CLUTTER_DRAG_ACTION(thumbDragAction), &rect);
		}
	}

	bool CProgress::OnMousePointerIn(IActor* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_TRACE(LOGGER, "CScroll::OnMousePointerIn(" << pWindow << ", " << ptrMouseEvent << ")");

		// pointing on thumb
		if (pWindow == dynamic_cast<CActor *>(m_bgImage))
		{
			m_thumbImageWidget->setSource(m_normalThumbImage);
		}
		else if (pWindow == dynamic_cast<CActor *>(m_thumbActor))
		{
			m_thumbImageWidget->setSource(m_focusThumbImage);
		}

		return true;
	}

	bool CProgress::OnMousePointerOut(IActor* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_TRACE(LOGGER, "CScroll::OnMousePointerOut(" << pWindow << ", " << ptrMouseEvent << ")");

		m_thumbImageWidget->setSource(m_normalThumbImage);

		return true;
	}

	void CProgress::m_OnProgressClick(float x, float y)
	{
		float trackWidth = 0;
		float trackHeight = 0;
		GetSize(trackWidth, trackHeight);

		float thumbWidth = 0;
		float thumbHeight = 0;
		GetThumbSize(thumbWidth, thumbHeight);

		float factor = 0;
		if (m_direction == TYPE_HORIZONTAL)
		{
			float validWidth = trackWidth - thumbWidth;
			if (x < thumbWidth/2)
			{
				clutter_actor_set_x(m_thumbActor->Actor(), 0);
				factor = 0;
			}
			else if (x > clutter_actor_get_width(t_actor) - thumbWidth/2)
			{
				clutter_actor_set_x(m_thumbActor->Actor(), validWidth);
				factor = 1.0;
			}
			else
			{
				clutter_actor_set_x(m_thumbActor->Actor(), x - thumbWidth/2);
				factor = (x - thumbWidth / 2) / validWidth;
			}
				
			if (m_reverseFlag)
			{
				factor = 1 - factor;
			}

			ClutterActor* fillActor = m_progressImage->Actor();
			clutter_actor_set_width(fillActor, thumbWidth / 2 + validWidth * factor);;
			clutter_actor_set_height(fillActor, clutter_actor_get_height(t_actor));
		}
		else
		{
			float validHeight = trackHeight - thumbHeight;
			if (y < thumbHeight / 2)
			{
				clutter_actor_set_y(m_thumbActor->Actor(), 0);
				factor = 1.0;
			}
			else if (y > clutter_actor_get_height(t_actor) - thumbHeight / 2)
			{
				clutter_actor_set_y(m_thumbActor->Actor(), validHeight);
				factor = 0;
			}
			else
			{
				clutter_actor_set_y(m_thumbActor->Actor(), y - thumbHeight / 2);
				factor = 1 - (y - thumbHeight / 2) / validHeight;;
			}

			if (m_reverseFlag)
			{
				factor = 1 - factor;
			}

			ClutterActor* fillActor = m_progressImage->Actor();
			clutter_actor_set_height(fillActor, thumbHeight / 2 + validHeight * factor);
			clutter_actor_set_width(fillActor, clutter_actor_get_width(t_actor));
		}
		
		m_value = m_minValue + static_cast<int>(factor * (m_maxValue - m_minValue));

		for (std::set<IProgressListener *>::iterator iter = m_listenerSet.begin(); iter != m_listenerSet.end(); ++iter)
		{
			ASSERT(*iter != NULL);
			(*iter)->OnValueChanged(this);
		}
	}

	void CProgress::Resize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CProgress::Resize(" << width << ", " << height << ")");

		CActor::Resize(width, height);

		m_bgImage->Resize(width, height);
		m_progressImage->Resize(width, height);

		m_ValueChanged();
	}

	void CProgress::SetMinValue(int minValue)
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetMinValue(" << minValue << ")");

		ASSERT(minValue >= 0);

		m_minValue = minValue;
		m_ValueChanged();
	}

	int CProgress::MinValue(void) const
	{
		ASSERT(m_minValue != INVALIDE_VALUE);

		return m_minValue;
	}

	void CProgress::SetMaxValue(int maxValue)
	{
		H_LOG_TRACE(LOGGER, "CProgress::SetMaxValue(" << maxValue << ")");

		ASSERT(maxValue >= 0);

		m_maxValue = maxValue;
		m_ValueChanged();
	}

	int CProgress::MaxValue(void) const
	{
		ASSERT(m_maxValue != INVALIDE_VALUE);

		return m_maxValue;
	}

	std::string CProgress::NormalThumbImage(void) const
	{
		return m_normalThumbImage;
	}

	std::string CProgress::FocusThumbImage(void) const
	{
		return m_focusThumbImage;
	}

	void CProgress::t_UpdateOrientation(EOrientation orientation)
	{
		ASSERT(orientation != ORIENTATION_REFER_TO_PARENT);

		switch (orientation)
		{
		case HALO::ORIENTATION_LEFT_TO_RIGHT:
			this->SetReverse(false);
			break;

		case HALO::ORIENTATION_RIGHT_TO_LEFT:
			this->SetReverse(true);
			break;

		default:
			ASSERT(0 && "Should not reach here.");
			break;
		}
	}
}
