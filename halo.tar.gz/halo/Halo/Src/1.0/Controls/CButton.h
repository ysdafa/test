#ifndef _CBUTTON_H_
#define _CBUTTON_H_

namespace HALO
{
	class CButton : virtual public IButton, public CActor, public IMouseListener, public IFocusListener, public IKeyboardListener
	{
	public:

		CButton();
		virtual ~CButton();

		virtual bool Initialize(IActor* parent, float width, float height);

		virtual bool Initialize(Widget* parent, float width, float height);

		void SetBackgroundColor(EButtonState state, const ClutterColor& color);
		const ClutterColor& BackgroundColor(EButtonState state);

		virtual void SetBackgroundImage(EButtonState state, const std::string& imagePath);
		const std::string& BackgroundImage(EButtonState state);

		void SetIconImage(EButtonState state, const std::string& iconPath);
		const std::string& IconImage(EButtonState state);

		void SetIconAlpha(EButtonState state, int alpha);
		int IconAlpha(EButtonState state);

		virtual void SetText(EButtonState state, const std::string& text);
		virtual const std::string& Text(EButtonState state);

		virtual void SetTextColor(EButtonState state, const ClutterColor& color);
		virtual const ClutterColor& TextColor(EButtonState state);

		virtual void SetFontSize(EButtonState state, int fontSize);
		virtual int FontSize(EButtonState state);

		virtual void Resize(float width, float height);

		virtual ICompositeImage* BackGroundImageActor(void);
		virtual IText* TextActor(void);
		virtual IImage* IconActor(void);

		virtual void Enable(bool flagEnable);
		virtual bool IsEnabled(void);

		virtual bool IsFocusEnabled(void);

		virtual bool AddListener(IButtonListener* listener);
		virtual bool RemoveListener(IButtonListener* listener);

		enum E_ButtonEventType
		{
			EVENT_RETURN_KEY_CLICKED = 0,		//!< return key clicked event

			EVENT_MOUSE_BUTTON_CLICKED,         //!< mouse button clicked event

			EVENT_GRIDLIST_MAX,				//!< last button event type identifier.
		};

	public:
		virtual const char* GetActorType(void);

	protected:
		//! The callback function when mouse button press.
		virtual bool OnMouseButtonPressed(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		//! The callback function when mouse button release.
		virtual bool OnMouseButtonReleased(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		//! The callback function when mouse pointer in.
		virtual bool OnMousePointerIn(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		//! The callback function when mouse pointer out.
		virtual bool OnMousePointerOut(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		//! The callback function when mouse move.
		virtual bool OnMouseMoved(IActor* pWindow, IMouseEvent* ptrMouseEvent);

		virtual bool OnFocusIn(IActor* pWindow);
		virtual bool OnFocusOut(IActor* pWindow);

		//! The callback function when key pressed.
		virtual bool OnKeyPressed(IActor* pThis, IKeyboardEvent* event);
		//! The callback function when key released.
		virtual bool OnKeyReleased(IActor* pWindow, IKeyboardEvent* event);

	public:
		EButtonState CurrentState(void);
	private:
		ICompositeImage* m_backGroundImage;
		IImage* m_icon;
		IText* m_text;
		class CButtonListenerSet* m_listenerSet;

		struct CTStateData
		{
			std::string backgroundImagePath;
			ClutterColor backgroundColor;
			std::string iconPath;
			int iconAlpha;//0~255
			std::string textContent;
			int fontSize;
			ClutterColor textColor;
		};
		CTStateData m_stateData[STATE_ALL];
		EButtonState m_curState;

		bool m_flagEnabled;

		bool m_flagPointerIn;

		void m_ChangeStateTo(EButtonState toState);
		//! Handle state change
		void m_OnStateChange(void);

		void m_Initialize(void);
	};
}


#endif
