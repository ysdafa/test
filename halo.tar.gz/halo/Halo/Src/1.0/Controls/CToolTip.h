#ifndef _HALO_CTOOLTIP_H_
#define _HALO_CTOOLTIP_H_

namespace HALO
{
	class CToolTip : virtual public IToolTip, public CActor
	{
	private:
		IActor *m_frame;
		ICompositeImage *m_popup;
		ICompositeImage *m_tail;
		IText *m_text;

		float m_tailWidth, m_tailHeight, m_tailOffset;
		float m_popupWidth, m_popupHeight;
		float m_tailSideRatio;
		float m_textRatio;
		float m_frameWidth;

		EToolTipTailPosition m_tailPosition;
		EToolTipTailSide m_tailSide;
		
		bool m_enablePositionCustom;
		bool m_enableReverse;
		float m_tailPositionLength;

		std::string m_upTailImage;
		std::string m_downTailImage;
		std::string m_leftTailImage;
		std::string m_rightTailImage;

		guint m_showTimerId;
		guint m_showTime;

	public:
		CToolTip(void);
		~CToolTip(void);

		// Create the Tool tip.
		bool Initialize(IActor *parent, float width, float height);
		bool Initialize(Widget *parent, float width, float height);

	private:		
		void m_CalPopupSize(void);
		void m_CalPopupPosition(float& x, float& y);
		void m_CalFrameSize(float& width, float& height);
		void m_CalFramePosition(float& x, float& y);
		void m_CalTailPosition(float& x, float& y);
		void m_CalTextPosition(float& x, float& y);
		void m_RefreshBalloon(void);
		void m_RefreshTail(void);
		void m_EnableReverse(bool enable);
		static gboolean m_HideTooltip(gpointer data);
	
	protected:
		void t_UpdateOrientation(EOrientation orientation);
		void t_OnShow(void);

	public:
		IText* TextActor(void);

		void Resize(float width, float height);

		void SetPopupImage(const std::string& image);
		std::string PopupImage(void) const;
		void SetTailImage(const std::string& image);
		std::string TailImage(void) const;

		void SetTailPosition(EToolTipTailSide side, EToolTipTailPosition position);
		void SetTailPosition(EToolTipTailSide side, float length);
		void SetTailPosition(EToolTipTailSide side, EToolTipTailPosition position, float offset);
		void SetTailPosition(EToolTipTailSide side, float length, float offset);
		void SetTailSize(float width, float height);
		void SetTailOffset(float offset);
		float TailOffset(void) const;

		void SetText(const std::string& text);
		std::string Text(void) const;

		void SetFont(const std::string& font);
		std::string Font(void) const;
		void SetFontSize(int size);
		int FontSize(void) const;
		void SetTextColor(const ClutterColor& color);
		void SetTextBackgroundColor(const ClutterColor& color);

		void SetFrameColor(const ClutterColor& color) ;
		void SetFrameWidth(float width);
		float FrameWidth(void) const;

		void SetUpTailImage(const std::string& image);
		std::string UpTailImage(void) const;
		void SetDownTailImage(const std::string& image);
		std::string DownTailImage(void) const;
		void SetLeftTailImage(const std::string& image);
		std::string LeftTailImage(void) const;
		void SetRightTailImage(const std::string& image);
		std::string RightTailImage(void) const;

		guint ShowTime() const;
		void SetShowTime(guint time);
	};

} /* namespace HALO */
#endif //_HALO_CTOOLTIP_H_
