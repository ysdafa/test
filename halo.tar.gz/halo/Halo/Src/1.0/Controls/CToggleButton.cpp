#include "Halo1_0.h"

namespace HALO
{
	bool CToggleButton::Initialize( IActor *parent , const TToggleButtonAttr &attr )
	{
		m_width = attr.width;
		m_height = attr.height;
		ParentType::Initialize(parent , m_width ,m_height);
		m_ItemImage = IImage::CreateInstance(dynamic_cast<Widget*>(this) , m_width , m_height);
		if (NULL != m_ItemImage)
		{
			m_CheckImage = IImage::CreateInstance(m_ItemImage ,m_width ,m_height);
		}
		m_posAni = ITransition::CreateInstance();
		if (NULL != m_posAni)
		{
			if (NULL != m_CheckImage)
			{
				m_CheckImage->BindTransition(m_posAni, IActor::ACTOR_ANI_POSITION);
			}
		}
		m_xPos = attr.xPos;
		m_yPos = attr.yPos;
		m_UseClick = true;
		m_IsMotion = true;
		SetPosition(m_xPos ,m_yPos);
		m_InitializeState();
		AddClickListener(this);
		AddKeyboardListener(this);
		AddFocusListener(this);
		AddMouseListener(this);
		if (NULL != m_CheckImage)
		{
			m_CheckImage->AddMouseListener(this);
			m_CheckImage->AddDragListener(this);
		}
		m_listener = NULL;
		EnableFocus(true);
		EnablePointerFocus(true);
		
		return true;
	}

	
	CToggleButton::CToggleButton()
	{
		m_aniDuration = 400;
	}

	CToggleButton::~CToggleButton()
	{
		m_Destory();
	}

	

	void CToggleButton::SetCheckImage( ECheckState state , IImageBuffer* imageBuffer ,float width ,float height)
	{
		ASSERT(imageBuffer != NULL);
		m_CheckImage->Resize(width , height);
		if (m_text!=NULL)
		{
			m_text->Resize(width , height);
		}
		
		m_CheckImage->SetPosition((m_height - height)/2 ,(m_height - height)/2);
		m_checkStateData[state].boxW = width;
		m_checkStateData[state].boxH = height;
		m_checkStateData[state].imageBuffer = dynamic_cast<CImageBuffer*>(imageBuffer);
		m_checkStateData[state].textContent = NULL;
		m_checkStateData[state].fontSize = 0;
		m_boxW = width;
		m_boxH = height;
	}

	void CToggleButton::SetImage( EItemState state , IImageBuffer* imageBuffer )
	{
		ASSERT(imageBuffer != NULL);

		if(state == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				m_itemStateData[i].imageBuffer = dynamic_cast<CImageBuffer*>(imageBuffer);
			}
		}
		else
		{
			m_itemStateData[state].imageBuffer = dynamic_cast<CImageBuffer*>(imageBuffer);
		}
	}

	void CToggleButton::AddListener( ToggleButtonListener *listeners )
	{
		m_listener = listeners;
	}

	void CToggleButton::SetCheck( bool isChecked )
	{
		m_IsChecked = isChecked;
		m_update();
	}

	bool CToggleButton::IsChecked()
	{
		return m_IsChecked;
	}

	void CToggleButton::EnableChecked( bool isEnableChecked )
	{
		this->Enable(isEnableChecked);
		m_ItemImage->Enable(isEnableChecked);
		m_CheckImage->Enable(isEnableChecked);
		m_ItemImage->EnableFocus(isEnableChecked);
		m_CheckImage->EnableFocus(isEnableChecked);
		this->EnableFocus(isEnableChecked);
	}

	void CToggleButton::m_Destory()
	{
		RemoveClickListener(this);
		RemoveKeyboardListener(this);
		RemoveFocusListener(this);
		RemoveMouseListener(this);
		m_CheckImage->RemoveDragListener(this);
		m_CheckImage->RemoveMouseListener(this);
		m_posAni->Release();
		m_text->Release();
		m_CheckImage->Release();
		m_ItemImage->Release();
		m_action->Release();
		m_daction->Release();
	}
	

	bool CToggleButton::OnFocusIn( IActor* pWindow )
	{
		EItemState state;
		state = E_STATE_FOCUSED;
		m_ChangeItemStateTo(state);
		return true;
	}

	bool CToggleButton::OnFocusOut( IActor* pWindow )
	{
		EItemState state;
		state = E_STATE_NORMAL;
		m_ChangeItemStateTo(state);
		return true;
	}

	bool CToggleButton::OnClicked( IActor* pWindow, IEvent* pClickEvent )
	{
		if (this->IsFocused())
		{
			if (m_UseClick)
			{
				if (IsChecked())
				{
					m_ProcessOff();
				}
				else 
				{
					m_ProcessOn();
				}
			}
			else
			{
				m_UseClick = true;
			}
		}
		return true;
	}

	bool CToggleButton::OnKeyPressed( IActor* pThis, IKeyboardEvent* event )
	{
		int keyValue = event->GetKeyVal();
		if (keyValue == 65293 && IsFocused())
		{
			if (m_IsChecked)
			{
				m_ProcessOff();
			}
			else 
			{
				m_ProcessOn();
			}
		}
		return true;
	}

	void CToggleButton::Show(bool isOpened)
	{
		sx = 0;
		ex = m_width -m_boxW;
		m_CreateAction();
		if (isOpened)
		{
			m_CheckImage->SetImage(m_checkStateData[E_STATE_ON].imageBuffer);
			m_text->SetText(m_checkStateData[E_STATE_ON].textContent);
			m_text->EnableEllipsize(true);
			if (m_checkStateData[E_STATE_ON].fontSize != 0)
			{
				m_text->SetFontSize(m_checkStateData[E_STATE_ON].fontSize);
			}
		}
		else
		{
			m_CheckImage->SetPosition(m_width - m_boxW - (m_height - m_boxH)/2 ,(m_height - m_boxH)/2);
			SetCheck(false);
		}
		m_CheckImage->Show();
		m_text->Show();
		ParentType::Show();
		this->SetFocus();
	}

	void CToggleButton::m_CreateAction()
	{
		IClickAction* action = IClickAction::CreateInstance(this);
		this->AddAction(action);
		m_action = action;

		IDragAction* daction = IDragAction::CreateInstance(m_CheckImage);
		if (daction)
		{
			m_CheckImage->AddAction(daction);
			daction->SetDragAxis(CLUTTER_DRAG_X_AXIS);
			daction->SetDragArea(0,0,m_width,m_height);
			m_daction = daction;
		}
		
	}

	void CToggleButton::m_InitializeState()
	{
		for(int i = 0; i < E_STATE_ALL; i++)
		{
			m_itemStateData[i].imageBuffer = NULL;
		}
		for (int i = 0; i <= E_STATE_OFF; i++)
		{
			m_checkStateData[i].imageBuffer = NULL;
			m_checkStateData[i].boxW = 0;
			m_checkStateData[i].boxH = 0;
		}
		m_curCheckState = 0;
		m_curItemState = 0;
		m_text = NULL;
	}

	void CToggleButton::m_ChangeItemStateTo( EItemState state )
	{
		if (state == m_curItemState || E_STATE_ALL == state)
		{
			return;
		}
		m_curItemState = state;
		m_OnItemStateChange();
	}

	void CToggleButton::m_OnItemStateChange()
	{
		if(NULL == m_itemStateData[m_curItemState].imageBuffer)
		{
			m_ItemImage->Hide();
		}
		else
		{
			m_ItemImage->SetImage(m_itemStateData[m_curItemState].imageBuffer);
			m_ItemImage->Show();
		}
	}

	bool CToggleButton::OnMousePointerIn( IActor* pWindow, IMouseEvent* ptrMouseEvent )
	{
		return true;
	}

	bool CToggleButton::OnMousePointerOut( IActor* pWindow, IMouseEvent* ptrMouseEvent )
	{
		EItemState state;
		state = E_STATE_NORMAL;
		m_ChangeItemStateTo(state);
		return true;
	}

	void CToggleButton::m_update()
	{
		if (m_IsChecked)
		{
			m_ChangeCheckStateTo(E_STATE_ON);
		}
		else
		{
			m_ChangeCheckStateTo(E_STATE_OFF);
		}
	}

	void CToggleButton::m_ChangeCheckStateTo( ECheckState state )
	{
		if (state == m_curCheckState)
		{
			return;
		}
		m_curCheckState = state;
		if(NULL == m_checkStateData[m_curCheckState].imageBuffer)
		{
			m_CheckImage->Hide();
		}
		else
		{
			m_CheckImage->SetImage(m_checkStateData[m_curCheckState].imageBuffer);
			m_text->SetText(m_checkStateData[m_curCheckState].textContent);
			if (m_checkStateData[m_curCheckState].fontSize != 0)
			{
				m_text->SetFontSize(m_checkStateData[m_curCheckState].fontSize);
			}
			m_CheckImage->Show();
			m_text->Show();
		}
	}

	bool CToggleButton::OnDragBegin( IActor* pWindow, IDragEvent* pDragEvent )
	{
		return true;
	}

	bool CToggleButton::OnDragEnd( IActor* pWindow, IDragEvent* pDragEvent )
	{
		float pressx, pressy, motionx, motiony;
		pDragEvent->PressCoords(&pressx, &pressy);
		pDragEvent->MotionCoords(&motionx, &motiony);
		if (m_IsChecked)
		{
			if (motionx -  m_xPos > 10)
			{
				m_ProcessOff();	
				m_UseClick = false;	
			}	
		}
		else if (!m_IsChecked)
		{
			if (m_xPos + m_width - motionx > 10)
			{
				m_ProcessOn();
				m_UseClick = false;
			}	
		}
		return true;
	}

	bool CToggleButton::OnDragMotion( IActor* pWindow, IDragEvent* pDragEvent )
	{
		return true;
	}

	void CToggleButton::SetText( ECheckState state ,const char* text )
	{
		ASSERT(text != NULL);
		m_text = IText::CreateInstance(m_CheckImage ,m_boxW ,m_boxW);
		if (NULL != m_text)
		{
			m_text->EnableEllipsize(true);
			m_text->SetTextAlignment(HALIGN_CENTER , VALIGN_MIDDLE);
		}
		if (m_checkStateData[state].textContent != NULL)
		{
			delete[] m_checkStateData[state].textContent;
			m_checkStateData[state].textContent = NULL;
		}
		m_checkStateData[state].textContent = new char[strlen(text) + 1];
		//! temp for Prevent
		int len = strlen(text) + 1;
		strncpy(m_checkStateData[state].textContent, text, len);
	}

	const char* CToggleButton::ItemText( ECheckState state )
	{
		return m_checkStateData[state].textContent;
	}

	void CToggleButton::SetTextFontSize( ECheckState state, const int fontSize )
	{
		m_checkStateData[state].fontSize = fontSize;
	}

	void CToggleButton::RemoveListener()
	{
		ASSERT(m_listener != NULL);
		delete m_listener;
	}

	void CToggleButton::m_ProcessOn()
	{
		m_posAni->SetDestination((m_height - m_boxH)/2, (m_height - m_boxH)/2);
		m_posAni->SetDuration(m_aniDuration);
		m_posAni->Play();
		SetCheck(true);
		if (NULL != m_listener)
		{
			m_listener->OnToggleOn(this);
		}
	}

	void CToggleButton::m_ProcessOff()
	{
		m_posAni->SetDestination(ex - (m_height - m_boxH)/2, (m_height - m_boxH)/2);
		m_posAni->SetDuration(m_aniDuration);
		m_posAni->Play();
		SetCheck(false);
		if (NULL != m_listener)
		{
			m_listener->OnToggleOff(this);
		}
	}

	void CToggleButton::SetAnimationProperty(ClutterAnimationMode animationMode , int aniDuration)
	{
		m_aniDuration = aniDuration;
		m_posAni->SetMode(animationMode);
	}

	const char* CToggleButton::GetActorType(void)
	{
		return "ToggleButton";
	}

}
