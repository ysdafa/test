#include "Halo1_0.h"

namespace HALO
{

	static HALO::util::Logger LOGGER("CCategoryTab");

	CCategoryTab::CCategoryTab()
	{
		m_background = NULL;
		m_tabAreaActor = NULL;
		m_highlightBar = NULL;
		m_leftBar = NULL;
		m_rightBar = NULL;
		m_leftArrows = NULL;
		m_rightArrows = NULL;
	}

	CCategoryTab::~CCategoryTab()
	{
		m_tabItemVec.clear();
		m_tabItemVecHeightFill.clear();
		m_tabItemVecWidthFix.clear();
		m_tabSpliterVec.clear();
		m_tabChangedListenerSet.clear();
		m_RemoveSizeListener();

		if (m_leftArrows != NULL)
		{
			m_leftArrows->Release();
		}
		if (m_rightArrows != NULL)
		{
			m_rightArrows->Release();
		}
		if (m_highlightBar != NULL)
		{
			m_highlightBar->Release();
		}
		if (m_leftBar != NULL)
		{
			m_leftBar->Release();
		}
		if (m_rightBar != NULL)
		{
			m_rightBar->Release();
		}
		if (m_tabAreaActor != NULL)
		{
			m_tabAreaActor->Release();
		}
		if (m_background != NULL)
		{
			m_background->Release();
		}
	}

	bool CCategoryTab::Initialize(IActor *parent, float width, float height)
	{
		Widget *cParent = dynamic_cast<Widget*>(parent);

		return Initialize(cParent, width, height);
	}

	bool CCategoryTab::Initialize(Widget *parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::Initialize a CategoryTab");

		for (int i = 0; i <= IButton::STATE_ALL; i++)
		{
			m_tabTextColorDataFlag[i] = false;
			m_tabColorDataFlag[i] = false;
			m_tabFontSizeData[i] = -1;
		}

		CActor::Initialize(parent, width, height);
		Widget *widget = dynamic_cast<Widget*>(this);
		if (widget != NULL)
		{
			ClutterColor c = { 125, 125, 125, 255 };

			m_background = ICompositeImage::CreateInstance(widget, width, height);

			m_tabAreaActor = IActor::CreateInstance(widget, width, height);
			//m_tabAreaActor->EnableClipOverflow(true);
			//for test
			//m_tabAreaActor->SetBackgroundColor(*clutter_color_init(&c, 255, 0, 0, 255));

			m_leftArrows = IImage::CreateInstance(m_background, 30, height);
			m_leftArrows->SetFillMode(CLUTTER_CONTENT_GRAVITY_LEFT);
			m_leftArrows->EnableFocus(false);
			m_leftArrows->EnablePointerFocus(false);
			m_leftArrows->Enable(false);
			m_leftArrows->Hide();

			m_rightArrows = IImage::CreateInstance(m_background, 30, height);
			m_rightArrows->SetFillMode(CLUTTER_CONTENT_GRAVITY_RIGHT);
			m_rightArrows->EnableFocus(false);
			m_rightArrows->EnablePointerFocus(false);
			m_rightArrows->Enable(false);
			m_rightArrows->Hide();

			m_highlightBar = IActor::CreateInstance(widget, 0, 0);
			m_highlightBar->SetBackgroundColor(*clutter_color_init(&c, 30, 158, 230, 255));
			m_highlightBar->Hide();

			m_leftBar = IActor::CreateInstance(m_tabAreaActor, 10, 5);
			m_leftBar->Hide();
			m_rightBar = IActor::CreateInstance(m_tabAreaActor, 10, 5);
			m_rightBar->Hide();

			//SetBackgroundColor(c);
			//init defalut attrs
			allocationListenerId = -1;
			m_focusIndex = -1;
			m_focusIndexLast = -1;
			m_mouseinIndex = -1;
			m_enableAlwaysScroll = false;
			m_enableLooping = true;
			m_enableHighlightbar = true;
			m_tabsAlignCenter = true;
			m_enableReverse = false;
			m_enableLeftRightBar = false;
			m_tabSpliterWidth = 2.f;
			m_tabSpliterHeight = 2.f;
			m_tabTextlimitWidth = 500;
			m_marginTop = m_marginBottom = m_marginLeft = m_marginRight = 0;
			float w = 0, h = 0;
			this->GetSize(w, h);
			m_tabMargin = w * 0.020833f;
			m_tabspliterColor = *clutter_color_init(&c, 70, 70, 70, 255);

			SetTabFont("Sans 28px"); //default font name and size
			SetTabFontSize(ICategoryTab::STATE_UNSELECTED, 28);
			SetTabFontSize(ICategoryTab::STATE_SELECTED, 31);
			SetTabFontSize(ICategoryTab::STATE_HIGHLIGHTED, 31);
			SetTabTextColor(ICategoryTab::STATE_UNSELECTED, *clutter_color_init(&c, 70, 70, 70, 255));
			SetTabTextColor(ICategoryTab::STATE_SELECTED, *clutter_color_init(&c, 30, 158, 230, 255));
			SetTabTextColor(ICategoryTab::STATE_HIGHLIGHTED, *clutter_color_init(&c, 255, 255, 255, 255));
			SetTabColor(ICategoryTab::STATE_UNSELECTED, *clutter_color_init(&c, 242, 242, 242, 255));
			SetTabColor(ICategoryTab::STATE_SELECTED, *clutter_color_init(&c, 242, 242, 242, 255));
			SetTabColor(ICategoryTab::STATE_HIGHLIGHTED, *clutter_color_init(&c, 30, 158, 230, 255));

			m_leftArrows->SetBackgroundColor(*clutter_color_init(&c, 0, 0, 0, 0));
			m_rightArrows->SetBackgroundColor(*clutter_color_init(&c, 0, 0, 0, 0));

			m_lastWidth = m_lastHeight = -1;
			m_ResizeCategoryTab();
		}

		EnableFocus(true);
		EnablePointerFocus(false);
		//AddMouseListener(this);
		AddFocusListener(this);
		m_AddSizeListener();
		return true;
	}

	void CCategoryTab::m_AddSizeListener(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_AddSizeListener.");
		allocationListenerId = g_signal_connect(Actor(), "notify::size", G_CALLBACK(m_OnResize), this);
	}

	void CCategoryTab::m_RemoveSizeListener(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_RemoveSizeListener.");
		if (allocationListenerId > 0)
		{
			g_signal_handler_disconnect(Actor(), allocationListenerId);
		}
	}

	void CCategoryTab::m_OnResize(GObject* object, GParamSpec* paramSpec, gpointer user_data)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_OnResize.");
		CCategoryTab* tab = (CCategoryTab*)user_data;

		//Stop scroll
		tab->m_StopTextScroll();

		//Resize all child-actors
		tab->m_ResizeCategoryTab();

		//Start scroll again
		tab->m_StartTextScroll(tab->m_focusIndex);
	}

	IButton* CCategoryTab::TabButtontActor(int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::TabButtontActor[" << index << "]");
		ASSERT(0 <= index && index < (int)m_tabItemVec.size());
		return m_tabItemVec[index];
	}

	IText* CCategoryTab::TabTextActor(int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::TabTextActor[" << index << "]");
		ASSERT(0 <= index && index < (int)m_tabItemVec.size());
		return TabButtontActor(index)->TextActor();
	}

	ICompositeImage* CCategoryTab::TabImageActor(int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::TabImageActor[" << index << "]");
		ASSERT(0 <= index && index < (int)m_tabItemVec.size());
		return TabButtontActor(index)->BackGroundImageActor();
	}

	void CCategoryTab::SetMargin(float top, float bottom, float left, float right)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetMargin [" << top << "," << bottom << "," << left << "," << right << "]");
		m_marginTop = top;
		m_marginBottom = bottom;
		m_marginLeft = left;
		m_marginRight = right;

		m_ResizeArrows();
		m_ResizeTabArea(true);

		m_ReplaceArrows();
		m_ReplaceTabArea(false);
		m_ReplaceSpliters();
		m_ReplaceHighlightBar(m_focusIndex);
	}

	void CCategoryTab::SetSpliterSize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetSpliterSize [" << width << ", " << height << "]");
		m_ResizeSpliters(width, height);
		m_ReplaceTabArea(true);
		m_ReplaceSpliters();
	}

	void CCategoryTab::EnableLooping(bool enable)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::EnableLooping [" << enable << "]");
		m_enableLooping = enable;
	}

	bool CCategoryTab::IsLoopingEnabled(void) const
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::IsLoopingEnabled .");
		return m_enableLooping;
	}
	void CCategoryTab::EnableAlignTabsCenter(bool enable)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::EnableAlignTabsCenter [" << enable << "]");
		m_tabsAlignCenter = enable;
	}

	bool CCategoryTab::IsAlignTabsCenterEnabled(void) const
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::IsAlignTabsCenterEnabled .");
		return m_tabsAlignCenter;
	}

	int CCategoryTab::CurrentTabIndex(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::CurrentTabIndex");
		if (m_focusIndex < 0)
		{
			return 0;
		}
		return m_focusIndex;
	}

	const char* CCategoryTab::CurrentTabText(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::CurrentTabText");
		return TabText(m_focusIndex);
	}

	const char* CCategoryTab::TabText(int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::CurrentTabText");
		ASSERT(0 <= index && index < (int)m_tabItemVec.size());
		return m_tabItemVec[index]->TextActor()->Text();
	}

	bool CCategoryTab::ChangeTab(int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::ChangeTab [" << index << "]");
		ASSERT(0 <= index && index < (int)m_tabItemVec.size());
		if (index <0 || index >= (int)m_tabItemVec.size() || m_tabItemVec[index] == NULL)
		{
			return false;
		}
		//m_tabItemVec[index]->SetFocus();
		m_focusIndex = index;
		m_GetFocusOn(m_focusIndex);
		return true;
	}

	int CCategoryTab::NumberOfTab(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::NumberOfTab");
		return (int)m_tabItemVec.size();
	}

	void CCategoryTab::SetLeftArrowsSize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetLeftArrowsSize [" << width << "," << height << "]");
		m_leftArrows->Resize(width, height);

		m_ResizeArrows();
		m_ResizeTabArea(true);

		m_ReplaceArrows();
		m_ReplaceTabArea(false);
		m_ReplaceSpliters();
		m_ReplaceHighlightBar(m_focusIndex);
	}

	void CCategoryTab::SetRightArrowsSize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetRightArrowsSize [" << width << "," << height << "]");
		m_rightArrows->Resize(width, height);

		m_ResizeArrows();
		m_ResizeTabArea(true);

		m_ReplaceArrows();
		m_ReplaceTabArea(false);
		m_ReplaceSpliters();
		m_ReplaceHighlightBar(m_focusIndex);
	}

	void CCategoryTab::m_RefreshArrows(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::RefreshArrows");
		bool leftFlag = false, rightFlag = false;

		if (m_tabItemVec.size() > 1)
		{
			if (m_enableReverse)
			{
				float x, y;
				m_tabItemVec[m_tabItemVec.size() - 1]->GetPosition(x, y);
				if ((int)(x - m_tabSpliterWidth) < 0)
				{
					leftFlag = true;
				}

				m_tabItemVec[0]->GetPosition(x, y);
				float tabitemWidth = 0, tabitemHeight = 0;
				m_tabItemVec[0]->GetSize(tabitemWidth, tabitemHeight);
				float tabareaWidth = 0, tabareaHeight = 0;
				m_tabAreaActor->GetSize(tabareaWidth, tabareaHeight);
				if ((int)(x + tabitemWidth + m_tabSpliterWidth) > (int)tabareaWidth)
				{
					rightFlag = true;
				}
			}
			else
			{
				float x, y;
				m_tabItemVec[0]->GetPosition(x, y);
				if ((int)(x - m_tabSpliterWidth) < 0)
				{
					leftFlag = true;
				}

				m_tabItemVec[m_tabItemVec.size() - 1]->GetPosition(x, y);
				float tabitemWidth = 0, tabitemHeight = 0;
				m_tabItemVec[m_tabItemVec.size() - 1]->GetSize(tabitemWidth, tabitemHeight);
				float tabareaWidth = 0, tabareaHeight = 0;
				m_tabAreaActor->GetSize(tabareaWidth, tabareaHeight);
				if ((int)(x + tabitemWidth + m_tabSpliterWidth) > (int)tabareaWidth)
				{
					rightFlag = true;
				}
			}
		}

		m_leftArrows->Hide();
		m_rightArrows->Hide();
		if (leftFlag)
		{
			/*
			if ((int)m_leftArrowsImage.length() > 0)
			{
				m_leftArrows->SetImage(m_leftArrowsImage.c_str());
			}
			*/
			m_leftArrows->Show();
		}
		if (rightFlag)
		{
			/*
			if ((int)m_rightArrows_image.length() > 0)
			{
				m_rightArrows->SetImage(m_rightArrows_image.c_str());
			}
			*/
			m_rightArrows->Show();
		}
	}

	void CCategoryTab::SetBackgroundColor(const ClutterColor &color)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetBackgroundColor");
		m_background->SetBackgroundColor(color);
	}

	//LIsteners:
	bool CCategoryTab::OnMouseButtonPressed(IActor* pThis, IMouseEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::OnMouseButtonPressed");
		for (int i = 0; i < (int)m_tabItemVec.size(); i++)
		{
			if (m_tabItemVec[i] == pThis)
			{
				m_focusIndex = i;
				m_GetFocusOn(m_focusIndex);
				break;
			}
		}
		return true;
	}

	bool CCategoryTab::OnMouseButtonReleased(IActor* pThis, IMouseEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::OnMouseButtonReleased");
		return true;
	}

	bool CCategoryTab::OnFocusIn(IActor* pWindow)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::OnFocusIn");
		if (pWindow == this)
		{
			if (m_focusIndex < 0)
			{
				m_focusIndex = 0;
			}
			m_GetFocusOn(m_focusIndex);
		}

		return true;
	}

	bool CCategoryTab::OnFocusOut(IActor* pWindow)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::OnFocusOut");
		/*
		StopTextScroll();
		*/
		return true;
	}

	void CCategoryTab::m_GetFocusOn(int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::GetFocusOn");
		ASSERT(0 <= index && index < (int)m_tabItemVec.size());

		if (index < 0 || index >= (int)m_tabItemVec.size() || m_tabItemVec[index] == NULL)
		{
			m_highlightBar->Hide();
			return;
		}

		if (m_focusIndexLast >= 0)
		{
			m_ChangeTabState(m_focusIndexLast, STATE_UNSELECTED);

			m_StopTextScroll();
			/*
			if ((int)strlen(m_tabItemVec[m_focusIndexLast]->TextActor()->Text()) > m_tab_textlimit)
			{
			m_tabItemVec[m_focusIndexLast]->TextActor()->StopScrollText();
			m_tabItemVec[m_focusIndexLast]->SetText(IButton::STATE_ALL, m_LimitTextContent(m_tabItemVec_text[m_focusIndexLast].c_str(), m_tab_textlimit).c_str());
			m_tabItemVec[m_focusIndexLast]->TextActor()->SetTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
			}
			*/
			m_ShowSpliter(m_focusIndexLast, true);
		}

		m_ChangeTabState(index, STATE_SELECTED);

		m_StartTextScroll(index);
		/*
		if ((int)m_tabItemVec_text[index].length() > m_tab_textlimit)
		{
		m_tabItemVec[index]->SetText(IButton::STATE_ALL, m_tabItemVec_text[index]);
		m_tabItemVec[index]->TextActor()->SetScrollAttribute(1000, 0, -1, CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_INSIDE, CLUTTER_TIMELINE_BACKWARD, m_tab_textlimit);
		m_tabItemVec[index]->TextActor()->StartScrollText();
		}
		*/
		m_tabItemVec[index]->SetFocus();

		float x = 0, y = 0;
		m_tabItemVec[index]->GetPosition(x, y);
		float tabitemWidth = 0, tabitemHeight = 0;
		m_tabItemVec[index]->GetSize(tabitemWidth, tabitemHeight);
		float tabareaWidth = 0, tabareaHeight = 0;
		m_tabAreaActor->GetSize(tabareaWidth, tabareaHeight);
		if ((x - m_tabSpliterWidth) < 0)
		{
			//at left end
			if (m_enableReverse)
			{
				if ((int)m_tabItemVec.size() > (index + 1))
				{
					//show left more
					float lastTabWidth = 0, lastTabHeight = 0;
					m_tabItemVec[index + 1]->GetSize(lastTabWidth, lastTabHeight);
					m_MoveTabItems(0, -x + m_tabSpliterWidth + lastTabWidth / 2.f);
				}
				else
				{
					m_MoveTabItems(0, -x + m_tabSpliterWidth);
				}
			}
			else
			{
				if (index > 0)
				{
					//show left more
					float lastTabWidth = 0, lastTabHeight = 0;
					m_tabItemVec[index - 1]->GetSize(lastTabWidth, lastTabHeight);
					m_MoveTabItems(0, -x + m_tabSpliterWidth + lastTabWidth / 2.f);
				}
				else
				{
					m_MoveTabItems(0, -x + m_tabSpliterWidth);
				}
			}
			m_ReplaceSpliters();
		}
		else if (x + tabitemWidth + m_tabSpliterWidth > tabareaWidth)
		{
			//at right end
			if (m_enableReverse)
			{
				if (index > 0)
				{
					//show right more
					float nextTabWidth = 0, nextTabHeight = 0;
					m_tabItemVec[index - 1]->GetSize(nextTabWidth, nextTabHeight);
					m_MoveTabItems(0, tabareaWidth - (x + tabitemWidth + m_tabSpliterWidth) - nextTabWidth / 2.f);
				}
				else
				{
					m_MoveTabItems(0, tabareaWidth - (x + tabitemWidth + m_tabSpliterWidth));
				}
			}
			else
			{
				if ((int)m_tabItemVec.size() > (index + 1))
				{
					//show right more
					float nextTabWidth = 0, nextTabHeight = 0;
					m_tabItemVec[index + 1]->GetSize(nextTabWidth, nextTabHeight);
					m_MoveTabItems(0, tabareaWidth - (x + tabitemWidth + m_tabSpliterWidth) - nextTabWidth / 2.f);
				}
				else
				{
					m_MoveTabItems(0, tabareaWidth - (x + tabitemWidth + m_tabSpliterWidth));
				}
			}
			m_ReplaceSpliters();
		}
		m_ShowSpliter(index, false);
		m_RefreshArrows();

		m_TabChangedListenerCallBack();
		m_focusIndexLast = index;
		m_ReplaceHighlightBar(index);
		m_ShowLeftRightBar(index, false);
	}

	void CCategoryTab::m_MoveTabItems(int from, float distance)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::MoveTabItems [ from:" << from << " , distance:" << distance << "]");

		for (int i = from; i < (int)m_tabItemVec.size(); i++)
		{
			float x, y;
			m_tabItemVec[i]->GetPosition(x, y);
			m_tabItemVec[i]->SetPosition(x + distance, y);
		}
	}

	void CCategoryTab::m_StartTextScroll(int index)
	{
		if (index > -1 && index < (int)m_tabItemVec.size())
		{
			m_tabItemVec[index]->TextActor()->StartScrollText();
		}
	}

	void CCategoryTab::m_StopTextScroll(void)
	{
		if (!m_enableAlwaysScroll && m_focusIndexLast > 0)
		{
			m_tabItemVec[m_focusIndexLast]->TextActor()->StopScrollText();
		}
	}

	bool CCategoryTab::OnKeyPressed(IActor* pThis, IKeyboardEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::OnKeyPressed");

		int keyValue = event->GetKeyVal();
		if (keyValue == CLUTTER_KEY_Down)
		{
			m_StopTextScroll();
		}
		else if (keyValue == CLUTTER_KEY_Up)
		{
			m_StopTextScroll();
		}
		else if (keyValue == CLUTTER_KEY_Right)
		{
			if (m_enableReverse)
			{
				if (m_focusIndex > 0)
				{
					m_GetFocusOn(--m_focusIndex);
				}
				else if (m_enableLooping)
				{
					m_focusIndex = (int)m_tabItemVec.size() - 1;
					m_GetFocusOn(m_focusIndex);
				}
			}
			else
			{
				if ((m_focusIndex + 1) < (int)m_tabItemVec.size())
				{
					m_GetFocusOn(++m_focusIndex);
				}
				else if (m_enableLooping)
				{
					m_focusIndex = 0;
					m_GetFocusOn(m_focusIndex);
				}
			}
		}
		else if (keyValue == CLUTTER_KEY_Left)
		{
			if (m_enableReverse)
			{
				if ((m_focusIndex + 1) < (int)m_tabItemVec.size())
				{
					m_GetFocusOn(++m_focusIndex);
				}
				else if (m_enableLooping)
				{
					m_focusIndex = 0;
					m_GetFocusOn(m_focusIndex);
				}
			}
			else
			{
				if (m_focusIndex > 0)
				{
					m_GetFocusOn(--m_focusIndex);
				}
				else if (m_enableLooping)
				{
					m_focusIndex = (int)m_tabItemVec.size() - 1;
					m_GetFocusOn(m_focusIndex);
				}
			}
		}
		return true;
	}

	bool CCategoryTab::OnKeyReleased(IActor* pWindow, IKeyboardEvent* ptrKeyboardEvent)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::OnKeyReleased");
		return true;
	}

	//Set Images:
	void CCategoryTab::SetBackgroundImage(const std::string& image)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetBackgroundImage, [" << image << "]");

		m_background->SetImage(image.c_str());
	}

	std::string CCategoryTab::BackgroundImage(void) const
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::BackgroundImage");
		return m_background->ImagePath();
	}

	void CCategoryTab::SetSpliterImage(const std::string& image)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetSpliterImage, [" << image << "]");
		m_spliterImage = image;
		for (int i = 0; i < (int)m_tabSpliterVec.size(); i++)
		{
			m_tabSpliterVec[i]->SetImage(m_spliterImage.c_str());
		}
	}

	std::string CCategoryTab::SpliterImage(void) const
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SpliterImage");
		return m_spliterImage;
	}

	void CCategoryTab::SetLeftArrowsImage(const std::string& image)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetLeftArrowsImage, [" << image << "]");
		m_leftArrowsImage = image;
		m_leftArrows->SetImage(m_leftArrowsImage.c_str());
	}

	void CCategoryTab::SetRightArrowsImage(const std::string& image)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetRightArrowsImage, [" << image << "]");
		m_rightArrowsImage = image;
		m_rightArrows->SetImage(m_rightArrowsImage.c_str());
	}

	std::string CCategoryTab::LeftArrowsImage(void) const
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::LeftArrowsImage.");
		return m_leftArrowsImage;
	}

	std::string CCategoryTab::RightArrowsImage(void) const
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::RightArrowsImage.");
		return m_rightArrowsImage;
	}

	void CCategoryTab::SetTabFont(const std::string& font)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabFont.");
		m_textFont = font;
	}

	std::string CCategoryTab::TabFont(void) const
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::TabFont.");
		return m_textFont;
	}

	void CCategoryTab::SetTabFontSize(ECategoryTabState state, int size)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabFontSize, [" << state << "," << size << "]");
		switch (state)
		{
		case STATE_UNSELECTED:
			m_tabFontSizeData[IButton::STATE_NORMAL] = size;
			m_tabFontSizeData[IButton::STATE_DISABLED] = size;
			m_tabFontSizeData[IButton::STATE_DISABLED_FOCUSED] = size;
			break;
		case STATE_SELECTED:
			m_tabFontSizeData[IButton::STATE_FOCUSED] = size;
			m_tabFontSizeData[IButton::STATE_SELECTED] = size;
			m_tabFontSizeData[IButton::STATE_FOCUSED_ROLL_OVER] = size;
			break;
		case STATE_HIGHLIGHTED:
			m_tabFontSizeData[IButton::STATE_ROLL_OVER] = size;
			break;
		case STATE_ALL:
			m_tabFontSizeData[IButton::STATE_ALL] = size;
			break;
		}
	}

	void CCategoryTab::SetTabTextColor(ECategoryTabState state, const ClutterColor &color)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabTextColor, [" << state << "]");
		switch (state)
		{
		case STATE_UNSELECTED:
			m_tabTextColorDataFlag[IButton::STATE_NORMAL] = true;
			m_tabTextColorData[IButton::STATE_NORMAL] = color;
			m_tabTextColorDataFlag[IButton::STATE_DISABLED] = true;
			m_tabTextColorData[IButton::STATE_DISABLED] = color;
			m_tabTextColorDataFlag[IButton::STATE_DISABLED_FOCUSED] = true;
			m_tabTextColorData[IButton::STATE_DISABLED_FOCUSED] = color;
			break;
		case STATE_SELECTED:
			m_tabTextColorDataFlag[IButton::STATE_FOCUSED] = true;
			m_tabTextColorData[IButton::STATE_FOCUSED] = color;
			m_tabTextColorDataFlag[IButton::STATE_SELECTED] = true;
			m_tabTextColorData[IButton::STATE_SELECTED] = color;
			m_tabTextColorDataFlag[IButton::STATE_FOCUSED_ROLL_OVER] = true;
			m_tabTextColorData[IButton::STATE_FOCUSED_ROLL_OVER] = color;
			break;
		case STATE_HIGHLIGHTED:
			m_tabTextColorDataFlag[IButton::STATE_ROLL_OVER] = true;
			m_tabTextColorData[IButton::STATE_ROLL_OVER] = color;
			break;
		case STATE_ALL:
			m_tabTextColorDataFlag[IButton::STATE_ALL] = true;
			m_tabTextColorData[IButton::STATE_ALL] = color;
			break;
		}
	}

	void CCategoryTab::SetTabColor(ECategoryTabState state, const ClutterColor &color)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabColor, [" << state << "]");
		switch (state)
		{
		case STATE_UNSELECTED:
			m_tabColorDataFlag[IButton::STATE_NORMAL] = true;
			m_tabColorData[IButton::STATE_NORMAL] = color;
			m_tabColorDataFlag[IButton::STATE_DISABLED] = true;
			m_tabColorData[IButton::STATE_DISABLED] = color;
			m_tabColorDataFlag[IButton::STATE_DISABLED_FOCUSED] = true;
			m_tabColorData[IButton::STATE_DISABLED_FOCUSED] = color;
			break;
		case STATE_SELECTED:
			m_tabColorDataFlag[IButton::STATE_FOCUSED] = true;
			m_tabColorData[IButton::STATE_FOCUSED] = color;
			m_tabColorDataFlag[IButton::STATE_SELECTED] = true;
			m_tabColorData[IButton::STATE_SELECTED] = color;
			m_tabColorDataFlag[IButton::STATE_FOCUSED_ROLL_OVER] = true;
			m_tabColorData[IButton::STATE_FOCUSED_ROLL_OVER] = color;
			break;
		case STATE_HIGHLIGHTED:
			m_tabColorDataFlag[IButton::STATE_ROLL_OVER] = true;
			m_tabColorData[IButton::STATE_ROLL_OVER] = color;
			m_leftBar->SetBackgroundColor(color);
			m_rightBar->SetBackgroundColor(color);
			break;
		case STATE_ALL:
			m_tabColorDataFlag[IButton::STATE_ALL] = true;
			m_tabColorData[IButton::STATE_ALL] = color;
			break;
		}
	}

	void CCategoryTab::SetTabImage(ECategoryTabState state, const char* image)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabImage, [" << state << "," << image << "]");
		ASSERT(NULL != image);
		switch (state)
		{
		case STATE_UNSELECTED:
			m_tabImageData[IButton::STATE_NORMAL] = image;
			m_tabImageData[IButton::STATE_DISABLED] = image;
			m_tabImageData[IButton::STATE_DISABLED_FOCUSED] = image;
			break;
		case STATE_SELECTED:
			m_tabImageData[IButton::STATE_FOCUSED] = image;
			m_tabImageData[IButton::STATE_SELECTED] = image;
			m_tabImageData[IButton::STATE_FOCUSED_ROLL_OVER] = image;
			break;
		case STATE_HIGHLIGHTED:
			m_tabImageData[IButton::STATE_ROLL_OVER] = image;
			break;
		case STATE_ALL:
			m_tabImageData[IButton::STATE_ALL] = image;
			break;
		}
	}

	void CCategoryTab::SetHighlightBarColor(const ClutterColor& color)
	{
		m_highlightBar->SetBackgroundColor(color);
	}

	bool CCategoryTab::IsHightlightBarEnabled(void) const
	{
		return m_enableHighlightbar;
	}

	void CCategoryTab::EnableHightlightBar(bool enable)
	{
		m_enableHighlightbar = enable;
		if (m_enableHighlightbar)
		{
			m_highlightBar->Show();
		}
		else
		{
			m_highlightBar->Hide();
		}
	}

	float CCategoryTab::HighlightBarHeight(void) const
	{
		float w = 0, h = 0;
		m_highlightBar->GetSize(w, h);
		return h;
	}

	void CCategoryTab::SetHighlightBarHeight(float height)
	{
		float w = 0, h = 0;
		m_highlightBar->GetSize(w, h);
		m_highlightBar->Resize(w, height);
	}

	float CCategoryTab::TabTextLimitWidth(void) const
	{
		return m_tabTextlimitWidth;
	}

	void CCategoryTab::SetTabTextLimitWidth(float limit)
	{
		m_tabTextlimitWidth = limit;
		m_ResizeTabArea(true);
	}

	void CCategoryTab::SetTabTextMargin(float margin)
	{
		m_tabMargin = margin;
	}

	float CCategoryTab::TabTextMargin(void) const
	{
		return m_tabMargin;
	}

	void CCategoryTab::m_InitTabItemProperties(IButton *tabItem)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::InitTabItemProperties");

		if ((int)m_textFont.length() > 0)
		{
			tabItem->TextActor()->SetFont(m_textFont.c_str());
		}
		for (int i = 0; i <= IButton::STATE_ALL; i++)
		{
			if (m_tabTextColorDataFlag[i])
			{
				tabItem->SetTextColor((IButton::EButtonState)i, m_tabTextColorData[i]);
			}
			if (m_tabColorDataFlag[i])
			{
				tabItem->SetBackgroundColor((IButton::EButtonState)i, m_tabColorData[i]);
			}
			if ((int)m_tabImageData[i].length() > 0)
			{
				tabItem->SetBackgroundImage((IButton::EButtonState)i, m_tabImageData[i]);
			}
			if (m_tabFontSizeData[i] > 0)
			{
				tabItem->SetFontSize((IButton::EButtonState)i, m_tabFontSizeData[i]);
			}
		}
	}

	float CCategoryTab::m_CalTextWidth(const char* text)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::CalTextWidth, [" << text << "]");
		ASSERT(NULL != text);
		int textFontSize = 20;
		if (m_tabFontSizeData[IButton::STATE_ALL] > 0)
		{
			textFontSize = m_tabFontSizeData[IButton::STATE_ALL];
		}
		else if (m_tabFontSizeData[IButton::STATE_SELECTED] > 0)  // NORMAL smaller
		{
			textFontSize = m_tabFontSizeData[IButton::STATE_SELECTED];
		}
		// 1. create ClutterText
		ClutterText* text1 = (ClutterText*)clutter_text_new();
		// 2. set font 
		clutter_text_set_font_name(text1, m_textFont.c_str());
		// 3. set font size
		PangoFontDescription *fontdes = pango_font_description_from_string(clutter_text_get_font_name(text1));
		gboolean flag = pango_font_description_get_size_is_absolute(fontdes);
		if (!flag)
		{
			pango_font_description_set_size(fontdes, (gint)textFontSize *PANGO_SCALE);
		}	
		else
		{
			pango_font_description_set_absolute_size(fontdes, (gint)textFontSize *PANGO_SCALE);
		}	
		clutter_text_set_font_description(text1, fontdes);
		pango_font_description_free(fontdes);
		// 4. set text
		clutter_text_set_text(text1, text);
		// 5. get width
		float width = clutter_actor_get_width(CLUTTER_ACTOR(text1));
		return width;
	}

	bool CCategoryTab::AddTab(const char* text)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::AddTab, [" << text << "]");
		ASSERT(NULL != text);
		return AddTab(text, (int)m_tabItemVec.size());
	}

	bool CCategoryTab::AddTab(const char* text, int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::AddTab, [" << text << "," << index << "]");
		ASSERT(NULL != text);
		return AddTab(text, -1, -1, index);
	}

	bool CCategoryTab::AddTab(const char* text, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::AddTab, [" << text << "," << width << "," << height << "]");
		ASSERT(NULL != text);
		return AddTab(text, width, height, (int)m_tabItemVec.size());
	}

	bool CCategoryTab::AddTab(const char* text, float width, float height, int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::AddTab, [" << text << "," << width << "," << height << "," << index << "]");
		ASSERT(NULL != text);
		if (index < 0)
		{
			return false;
		}

		float widthOri = width;
		if (width < 0)
		{
			//auto width
			width = m_CalTextWidth(text);	
		}	
		if (width > m_tabTextlimitWidth)
		{
			//text width limit
			width = m_tabTextlimitWidth;
		}
		//add margin
		width = width + m_tabMargin * 2.f;

		int size = m_tabItemVec.size();


		float tabWidth = 0, tabHeight = 0;
		m_tabAreaActor->GetSize(tabWidth, tabHeight);

		bool heightFillFlag = false;
		if (height < 0 || height > tabHeight)
		{
			//height >= tab_heigt,  then button fill the tab area
			height = tabHeight;
			heightFillFlag = true;
		}
		/*
		float x, y;
		if (size == 0 || index == 0)
		{
		x = m_tabSpliterWidth;
		}
		else
		{
		if (index >= size)
		{
		index = size;
		}
		m_MoveTabItems(index, width + m_tabSpliterWidth);
		gfloat last_x = 0, last_y = 0;
		m_tabItemVec[index - 1]->GetPosition(last_x, last_y);
		gfloat last_width = 0, last_height = 0;
		m_tabItemVec[index - 1]->GetSize(last_width, last_height);
		x = last_x + last_width + m_tabSpliterWidth;
		}
		y = (tab_height - height) / 2;
		*/
		IButton *tabItem = IButton::CreateInstance(m_tabAreaActor, width, height);
		tabItem->SetText(IButton::STATE_ALL, text);
		m_InitTabItemProperties(tabItem);
		tabItem->TextActor()->Resize(width - m_tabMargin * 2.f, height);
		tabItem->TextActor()->SetPosition(m_tabMargin, 0);
		tabItem->TextActor()->EnableEllipsize(true);

		tabItem->EnableFocus(true);
		tabItem->EnablePointerFocus(false);
		tabItem->AddKeyboardListener(this);
		t_AddNoticeActor(tabItem);

		// use self-change tab state
		tabItem->AddMouseListener(this);

		if (size == 0 || index >= size)
		{
			m_tabItemVec.push_back(tabItem);
			m_tabItemVecHeightFill.push_back(heightFillFlag);
			m_tabItemVecWidthFix.push_back(widthOri);
			//use self-change tab state
			m_ChangeTabState(size, STATE_UNSELECTED);
		}
		else
		{
			m_tabItemVec.insert(m_tabItemVec.begin() + index, tabItem);
			m_tabItemVecHeightFill.insert(m_tabItemVecHeightFill.begin() + index, heightFillFlag);
			m_tabItemVecWidthFix.insert(m_tabItemVecWidthFix.begin() + index, widthOri);
			//use self-change tab state
			m_ChangeTabState(index, STATE_UNSELECTED);
		}
		tabItem->Show();

		if (m_tabItemVec.size() == 1)
		{
			m_AddSpliter(2);
		}
		else
		{
			m_AddSpliter(1);
		}

		m_ReplaceTabArea(true);
		m_ReplaceSpliters();
		m_RefreshArrows();

		return true;
	}

	void CCategoryTab::m_AddSpliter(int number)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_AddSpliter, [" << number << "]");
		for (int i = 0; i < number; i++)
		{
			//add spliter
			ICompositeImage *tabSpliter = ICompositeImage::CreateInstance(m_tabAreaActor, m_tabSpliterWidth, m_tabSpliterHeight);
			tabSpliter->SetBackgroundColor(m_tabspliterColor);
			m_tabSpliterVec.push_back(tabSpliter);
		}
	}

	void CCategoryTab::SetSpliterColor(const ClutterColor &color)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetSpliterColor.");
		m_tabspliterColor = color;
		for (int i = 0; i < (int)m_tabSpliterVec.size(); i++)
		{
			m_tabSpliterVec[i]->SetBackgroundColor(m_tabspliterColor);
		}
	}

	void CCategoryTab::m_ShowSpliter(int index, bool show)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_ShowSpliter [ " << index << " ].");
		if (index < 0)
		{
			return;
		}

		if (show)
		{
			if (index > 0)
			{
				//left
				m_tabSpliterVec[index]->Show();
			}
			if (index < ((int)m_tabItemVec.size() - 1))
			{
				//right
				m_tabSpliterVec[index + 1]->Show();
			}
		}
		else
		{
			m_tabSpliterVec[index]->Hide();
			m_tabSpliterVec[index + 1]->Hide();
		}
	}

	bool CCategoryTab::RemoveTab(int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::RemoveTab, [" << index << "]");
		ASSERT(index >= 0 && index < (int)m_tabItemVec.size());

		if (index < 0)
		{
			return false;
		}

		if ((index + 1) >(int)m_tabItemVec.size())
		{
			return false;
		}

		gfloat removeWidth = 0, removeHeight = 0;
		m_tabItemVec[index]->GetSize(removeWidth, removeHeight);
		bool isFocus = false;
		if (m_tabItemVec[index]->IsFocused())
		{
			isFocus = true;
		}
		m_tabItemVec[index]->Release();
		m_tabItemVec.erase(m_tabItemVec.begin() + index);
		m_tabItemVecHeightFill.erase(m_tabItemVecHeightFill.begin() + index);
		m_tabItemVecWidthFix.erase(m_tabItemVecWidthFix.begin() + index);
		m_tabSpliterVec[index + 1]->Hide();
		m_tabSpliterVec[index + 1]->Release();
		m_tabSpliterVec.erase(m_tabSpliterVec.begin() + index + 1);
		//m_MoveTabItems(index, -(remove_width + m_tabSpliterWidth));
		if ((int)m_tabItemVec.size() == 0)
		{
			m_tabSpliterVec[0]->Release();
			m_tabSpliterVec.erase(m_tabSpliterVec.begin() + 0);
		}

		if (isFocus)
		{
			m_focusIndex = 0;
			m_focusIndexLast = -1;
			m_ReplaceTabArea(true);
			m_ReplaceSpliters();
			m_GetFocusOn(m_focusIndex);
		}
		else
		{
			m_ReplaceTabArea(true);
			m_ReplaceSpliters();
			m_RefreshArrows();
		}

		return true;
	}

	void CCategoryTab::m_ChangeTabState(int index, ECategoryTabState state)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_ChangeTabState, [" << index << "]");
		IButton::EButtonState bstate = IButton::STATE_NORMAL;
		switch (state)
		{
		case HALO::ICategoryTab::STATE_UNSELECTED:
			bstate = IButton::STATE_NORMAL;
			break;
		case HALO::ICategoryTab::STATE_SELECTED:
			bstate = IButton::STATE_SELECTED;
			break;
		case HALO::ICategoryTab::STATE_HIGHLIGHTED:
			bstate = IButton::STATE_ROLL_OVER;
			break;
		case HALO::ICategoryTab::STATE_ALL:
			bstate = IButton::STATE_ALL;
			break;
		default:
			break;
		}
		//use self-change tab state
		m_tabItemVec[index]->SetFontSize(IButton::STATE_ALL, m_tabFontSizeData[bstate]);
		m_tabItemVec[index]->SetTextColor(IButton::STATE_ALL, m_tabTextColorData[bstate]);
	}

	//Tab Changed Call Back:
	void CCategoryTab::m_TabChangedListenerCallBack(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::TabChangedListenerCallBack");
		// call back listeners
		for (std::set<ICategoryTabChangedListener *>::iterator iter = m_tabChangedListenerSet.begin(); iter != m_tabChangedListenerSet.end(); ++iter)
		{
			ASSERT(*iter != NULL);
			(*iter)->OnTabChanged(this, m_focusIndex);//could send m_focusIndexLast 
		}
	}

	bool CCategoryTab::AddTabChangedListener(ICategoryTabChangedListener* listener)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::AddTabChangedListener");
		ASSERT(listener != NULL);
		m_tabChangedListenerSet.insert(listener);
		return true;
	}

	bool CCategoryTab::RemoveTabChangedListener(ICategoryTabChangedListener* listener)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::RemoveTabChangedListener");
		ASSERT(listener != NULL);
		m_tabChangedListenerSet.erase(listener);
		return true;
	}

	bool CCategoryTab::OnMousePointerIn(IActor* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::OnMousePointerIn");
		int index = -1;
		for (int i = 0; i < (int)m_tabItemVec.size(); i++)
		{
			if (m_tabItemVec[i] == pWindow)
			{
				index = i;
				break;
			}
		}
		if (index > -1 && index != m_focusIndex)
		{
			m_mouseinIndex = index;
			m_ChangeTabState(index, STATE_HIGHLIGHTED);
			m_ShowSpliter(index, false);
			m_ShowLeftRightBar(index, true);
		}
		return true;
	}

	bool CCategoryTab::OnMousePointerOut(IActor* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::OnMousePointerOut");
		int index = -1;
		for (int i = 0; i < (int)m_tabItemVec.size(); i++)
		{
			if (m_tabItemVec[i] == pWindow)
			{
				index = i;
				break;
			}
		}

		if (index > -1 && index != m_focusIndex)
		{
			m_mouseinIndex = -1;
			m_ChangeTabState(index, STATE_UNSELECTED);
			m_ShowSpliter(index, true);
			m_ShowSpliter(m_focusIndex, false);
			m_ShowLeftRightBar(index, false);
		}
		return true;
	}

	void CCategoryTab::m_ResizeBackground(void)
	{
		float width = 0, height = 0;
		this->GetSize(width, height);
		m_background->Resize(width, height);
	}

	void CCategoryTab::m_ResizeArrows(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_ResizeArrows");
		float tabWidth = 0, tabHeight = 0;
		this->GetSize(tabWidth, tabHeight);

		float leftWidth = 0, leftHeight = 0;
		m_leftArrows->GetSize(leftWidth, leftHeight);

		float rightWidth = 0, rightHeight = 0;
		m_rightArrows->GetSize(rightWidth, rightHeight);

		if (leftHeight > (tabHeight - m_marginTop - m_marginBottom))
		{
			leftHeight = tabHeight - m_marginTop - m_marginBottom;
		}
		m_leftArrows->Resize(leftWidth, leftHeight);

		if (rightHeight > (tabHeight - m_marginTop - m_marginBottom))
		{
			rightHeight = tabHeight - m_marginTop - m_marginBottom;
		}
		m_rightArrows->Resize(rightWidth, rightHeight);
	}

	void CCategoryTab::m_ReplaceArrows(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_ReplaceArrows");
		float tabWidth = 0, tabHeight = 0;
		this->GetSize(tabWidth, tabHeight);
		float leftWidth = 0, leftHeight = 0;
		m_leftArrows->GetSize(leftWidth, leftHeight);
		float tabarea_width = 0, tabarea_height = 0;
		m_tabAreaActor->GetSize(tabarea_width, tabarea_height);
		float rightWidth = 0, rightHeight = 0;
		m_rightArrows->GetSize(rightWidth, rightHeight);

		m_leftArrows->SetPosition(m_marginLeft, (tabHeight - leftHeight) / 2);
		m_rightArrows->SetPosition(m_marginLeft + leftWidth + tabarea_width, (tabHeight - rightHeight) / 2);
	}

	void CCategoryTab::m_ResizeTabArea(bool sub)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_ResizeTabArea");
		float tabWidth = 0, tabHeight = 0;
		this->GetSize(tabWidth, tabHeight);
		float leftWidth = 0, leftHeight = 0;
		m_leftArrows->GetSize(leftWidth, leftHeight);
		float rightWidth = 0, rightHeight = 0;
		m_rightArrows->GetSize(rightWidth, rightHeight);

		//Resize tab_area
		float tabareaWidth = 0, tabareaHeight = 0;
		tabareaWidth = tabWidth - leftWidth - rightWidth - m_marginLeft - m_marginRight;
		if (tabareaWidth < 0)
		{
			tabareaWidth = 0;
		}
		tabareaHeight = tabHeight - m_marginTop - m_marginBottom;
		if (tabareaHeight < 0)
		{
			tabareaHeight = 0;
		}
		
		m_tabAreaActor->Resize(tabareaWidth, tabareaHeight);
		m_tabAreaActor->SetClipArea(0, 0, tabareaWidth, tabareaHeight);
		
		if (sub)
		{
			//Resize all sub-tabs
			float textWidth = 0, textHeihgt = 0;
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{
				IText *tabText = m_tabItemVec[i]->TextActor();
				if (m_tabItemVecWidthFix[i] < 0)
				{
					textWidth = m_CalTextWidth(tabText->Text());
				}
				else
				{
					textWidth = m_tabItemVecWidthFix[i];
				}
				if (textWidth > m_tabTextlimitWidth)
				{
					textWidth = m_tabTextlimitWidth;
				}
				textWidth += (m_tabMargin * 2.f);

				if (m_tabItemVecHeightFill[i] == true)
				{
					//fill tab area
					textHeihgt = tabareaHeight;
					m_tabItemVec[i]->Resize(textWidth, textHeihgt);
				}
				else
				{
					float tabitemWidth = 0, tabitemHeight = 0;
					m_tabItemVec[i]->GetSize(tabitemWidth, tabitemHeight);
					textHeihgt = tabitemHeight;
					m_tabItemVec[i]->Resize(textWidth, textHeihgt);
					float tabItemX = 0, tabItemY = 0;
					m_tabItemVec[i]->GetPosition(tabItemX, tabItemY);
					//place to bottom
					m_tabItemVec[i]->SetPosition(tabItemX, tabareaHeight - tabitemHeight);
				}
				//Resize text area in button
				tabText->Resize(textWidth - (m_tabMargin * 2.f), textHeihgt);
				tabText->SetPosition(m_tabMargin, 0);

				if (m_mouseinIndex == i)
				{
					m_ResizeLeftRightBar(m_tabSpliterWidth, textHeihgt);
				}
			}
		}
	}

	void CCategoryTab::m_ReplaceTabArea(bool sub)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_ReplaceTabArea");
		float leftWidth = 0, leftHeight = 0;
		m_leftArrows->GetSize(leftWidth, leftHeight);

		//Replace tab area
		m_tabAreaActor->SetPosition(m_marginLeft + leftWidth, m_marginTop);

		if (sub)
		{
			//Replace sub-tabs
			if (m_tabItemVec.size() > 0)
			{
				float tabareaWidth = 0, tabareaHeight = 0;
				m_tabAreaActor->GetSize(tabareaWidth, tabareaHeight);
				//from left to right
				float x = m_tabSpliterWidth;
				float tabitemWidth = 0, tabitemHeight = 0;

				if (m_enableReverse)
				{
					//reverse
					for (int i = (int)m_tabItemVec.size() - 1; i >= 0; i--)
					{
						m_tabItemVec[i]->GetSize(tabitemWidth, tabitemHeight);
						//place to bottom
						m_tabItemVec[i]->SetPosition(x, tabareaHeight - tabitemHeight);
						x += tabitemWidth + m_tabSpliterWidth;
					}
					if (m_tabsAlignCenter && x < tabareaWidth)
					{
						//align tabs center if width of tabs less than width of tab_area.
						m_MoveTabItems(0, (tabareaWidth - x) / 2.f);
					}
					else
					{
						//move to right
						m_MoveTabItems(0, tabareaWidth - x);
					}
				}
				else
				{
					//not reverse
					for (int i = 0; i < (int)m_tabItemVec.size(); i++)
					{
						m_tabItemVec[i]->GetSize(tabitemWidth, tabitemHeight);
						//place to bottom
						m_tabItemVec[i]->SetPosition(x, tabareaHeight - tabitemHeight);
						x += tabitemWidth + m_tabSpliterWidth;
					}

					if (m_tabsAlignCenter)
					{
						//align tabs center if width of tabs less than width of tab_area.
						if (x < tabareaWidth)
						{
							m_MoveTabItems(0, (tabareaWidth - x) / 2.f);
						}
					}
				}
			}
		}
	}

	void CCategoryTab::m_ResizeHighlightBar(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_ResizeHighlightBar [ " << width << " , " << height << " ].");
		float tabareaWidth = 0, tabareaHeight = 0;
		m_tabAreaActor->GetSize(tabareaWidth, tabareaHeight);
		float highX = 0, highY = 0;
		m_highlightBar->GetPosition(highX, highY);

		m_highlightBar->SetPosition(highX, tabareaHeight - height);
		m_highlightBar->Resize(width, height);
	}

	void CCategoryTab::m_ReplaceHighlightBar(int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_ReplaceHighlightBar [ " << index << " ].");
		if (index < 0)
		{
			return;
		}
		//highlight bar move:
		float x = 0, y = 0;
		m_tabItemVec[index]->GetPosition(x, y);
		float tabitemWidth = 0, tabitemHeight = 0;
		m_tabItemVec[index]->GetSize(tabitemWidth, tabitemHeight);
		float barWidth = 0, barHeight = 0;
		m_highlightBar->GetSize(barWidth, barHeight);
		float leftWidth = 0, leftHeight = 0;
		m_leftArrows->GetSize(leftWidth, leftHeight);
		float tabareaWidth = 0, tabareaHeight = 0;
		m_tabAreaActor->GetSize(tabareaWidth, tabareaHeight);

		if (x < 0)
		{
			//last one
			m_highlightBar->Resize(tabitemWidth + x + m_tabSpliterWidth * 2, barHeight);
		}
		else if (x + tabitemWidth > tabareaWidth)
		{
			m_highlightBar->Resize(tabareaWidth - x + m_tabSpliterWidth * 2, barHeight);
		}
		else
		{
			m_highlightBar->Resize(tabitemWidth + m_tabSpliterWidth * 2, barHeight);
		}

		float bx = 0, by = 0;
		bx = leftWidth + m_marginLeft + x - m_tabSpliterWidth;
		by = tabitemHeight - barHeight + m_marginTop;
		if (bx < 0)
		{
			bx = 0;
		}

		if (m_enableHighlightbar)
		{
			if (m_highlightBar->FlagShow())
			{
				/*
				clutter_actor_save_easing_state(m_highlightBar->Actor());
				clutter_actor_set_easing_mode(m_highlightBar->Actor(), CLUTTER_LINEAR);
				clutter_actor_set_easing_duration(m_highlightBar->Actor(), 0.5 * 1000);
				clutter_actor_set_position(m_highlightBar->Actor(), left_width + m_margin_left + x - m_tabSpliterWidth, t_height - b_height + m_margin_top);
				clutter_actor_restore_easing_state(m_highlightBar->Actor());
				*/
				m_highlightBar->SetPosition(bx, by);
			}
			else
			{
				m_highlightBar->SetPosition(bx, by);
				m_highlightBar->Show();
			}
		}
		else
		{
			m_highlightBar->SetPosition(bx, by);
			m_highlightBar->Hide();
		}
	}
}

void CCategoryTab::m_ResizeSpliters(float width, float height)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_ResizeSpliters [ " << width << " , " << height << " ].");
	m_tabSpliterWidth = width;
	m_tabSpliterHeight = height;

	for (int i = 0; i < (int)m_tabSpliterVec.size(); i++)
	{
		m_tabSpliterVec[i]->Resize(m_tabSpliterWidth, m_tabSpliterHeight);
	}
	m_ResizeTabArea(true);
}

void CCategoryTab::m_ReplaceSpliters(void)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_ReplaceSpliters.");
	gfloat x, y;
	if (m_tabItemVec.size() > 0)
	{
		x = 0;
		float tabareaWidth = 0, tabareaHeight = 0;
		m_tabAreaActor->GetSize(tabareaWidth, tabareaHeight);
		//spliter put center
		y = (tabareaHeight - m_tabSpliterHeight) / 2;
		
		if (m_enableReverse)
		{
			gfloat lastX = 0, lastY = 0;
			gfloat lastW = 0, lastH = 0;
			m_tabItemVec[0]->GetPosition(lastX, lastY);
			m_tabItemVec[0]->GetSize(lastW, lastH);
			x = lastX + lastW;
			m_tabSpliterVec[0]->SetPosition(x, y);
			m_tabSpliterVec[0]->Show();
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{
				m_tabItemVec[i]->GetPosition(lastX, lastY);
				m_tabItemVec[i]->GetSize(lastW, lastH);
				x = lastX - m_tabSpliterWidth;
				//left splter
				m_tabSpliterVec[i + 1]->SetPosition(x, y);
				m_tabSpliterVec[i + 1]->Show();
			}
		}
		else
		{
			gfloat lastX = 0, lastY = 0;
			gfloat lastWidth = 0, lastHeight = 0;
			m_tabItemVec[0]->GetPosition(lastX, lastY);
			m_tabSpliterVec[0]->SetPosition(lastX - m_tabSpliterWidth, y);
			m_tabSpliterVec[0]->Show();
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{
				m_tabItemVec[i]->GetPosition(lastX, lastY);
				m_tabItemVec[i]->GetSize(lastWidth, lastHeight);
				x = lastX + lastWidth;
				m_tabSpliterVec[i + 1]->SetPosition(x, y);
				m_tabSpliterVec[i + 1]->Show();
			}
		}
	}

	if (m_tabSpliterVec.size() > 1)
	{
		//Hide first and last spliter
		m_tabSpliterVec[0]->Hide();
		m_tabSpliterVec[m_tabSpliterVec.size() - 1]->Hide();
	}
	if (m_focusIndex > -1)
	{
		//Hide focus spliter
		m_ShowSpliter(m_focusIndex, false);
	}
}

void CCategoryTab::m_ResizeCategoryTab(void)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_ResizeCategoryTab.");

	m_ResizeBackground();
	m_ReplaceArrows();
	m_ResizeTabArea(true);

	float tabWidth = 0, tabHeight = 0;
	this->GetSize(tabWidth, tabHeight);
	if (tabWidth == m_lastWidth && tabHeight != m_lastHeight)
	{
		m_ReplaceTabArea(false);
	}
	else
	{
		m_ReplaceTabArea(true);
	}

	m_ReplaceSpliters();
	m_ReplaceHighlightBar(m_focusIndex);

	//Update date
	m_lastWidth = tabWidth;
	m_lastHeight = tabHeight;
}

void CCategoryTab::m_EnableReverse(bool enable)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_EnableReverse.");
	if (enable == m_enableReverse)
	{
		return;
	}
	m_enableReverse = enable;
	float focusX = 0, focusY = 0;
	if (m_focusIndex > -1)
	{
		m_tabItemVec[m_focusIndex]->GetPosition(focusX, focusY);
	}
	m_ReplaceTabArea(true);

	if (m_focusIndex > -1)
	{
		float tabareaWidth = 0, tabareaHeight = 0;
		m_tabAreaActor->GetSize(tabareaWidth, tabareaHeight);
		float itemX = 0, itemY = 0, itemWidth = 0, itemHeight = 0;
		m_tabItemVec[m_focusIndex]->GetPosition(itemX, itemY);
		m_tabItemVec[m_focusIndex]->GetSize(itemWidth, itemHeight);
		if (m_enableReverse)
		{
			//change to reverse
			float offset = (tabareaWidth - itemX - itemWidth) - focusX;
			m_MoveTabItems(0, offset);
		}
		else
		{
			//chage to not reverse
			float offset = tabareaWidth - focusX - itemWidth - itemX;
			m_MoveTabItems(0, offset);
		}
	}

	m_ReplaceSpliters();
	m_ReplaceHighlightBar(m_focusIndex);
	m_RefreshArrows();
}

void CCategoryTab::m_ShowLeftRightBar(int index, bool show)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_ShowLeftRightBar.");
	if (m_enableLeftRightBar)
	{
		if (show)
		{
			if (index > -1 && index < (int)m_tabItemVec.size())
			{
				float x = 0, y = 0, width = 0, height = 0;
				m_tabItemVec[index]->GetPosition(x, y);
				m_tabItemVec[index]->GetSize(width, height);

				m_ResizeLeftRightBar(m_tabSpliterWidth, height);
				m_ReplaceLeftRightBar(x - m_tabSpliterWidth, x + width, y);
				m_leftBar->Show();
				m_rightBar->Show();
			}
		}
		else
		{
			m_leftBar->Hide();
			m_rightBar->Hide();
		}
	}	
}

void CCategoryTab::m_ResizeLeftRightBar(float width, float height)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_ResizeLeftRightBar [ " << width << " , " << height << " ].");
	m_leftBar->Resize(width, height);
	m_rightBar->Resize(width, height);
}

void CCategoryTab::m_ReplaceLeftRightBar(float left_x, float right_x, float y)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_ReplaceLeftRightBar [ " << left_x << " , " << right_x << " , " << y << " ].");
	m_leftBar->SetPosition(left_x, y);
	m_rightBar->SetPosition(right_x, y);
}

void CCategoryTab::t_UpdateOrientation(EOrientation orientation)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::t_UpdateOrientation.");
	if (orientation == ORIENTATION_RIGHT_TO_LEFT)
	{
		m_EnableReverse(true);
	}
	else
	{
		m_EnableReverse(false);
	}
	CActor::t_UpdateOrientation(orientation);
}

