#include "Halo1_0.h"

namespace HALO
{

	static HALO::util::Logger LOGGER("CCategoryTab");

	CCategoryTab::CCategoryTab()
	{
		H_LOG_DEBUG(LOGGER, "CCategoryTab::CCategoryTab");

		m_background = NULL;
		m_tabAreaActor = NULL;
		m_highlightBar = NULL;
		m_leftArrows = NULL;
		m_rightArrows = NULL;

		m_swapMoveAni = NULL;
		m_resizeHighlightAni = NULL;
		m_replaceHighlightAni = NULL;
	}

	CCategoryTab::~CCategoryTab()
	{
		H_LOG_DEBUG(LOGGER, "CCategoryTab::~CCategoryTab");
		if (m_isEnableDragTab)
		{
			EnableDragTab(false);
		}

		for (int i = 0; i < (int)m_tabItemVec.size(); i++)
		{
			m_tabItemVec[i]->RemoveMouseListener(this);
			m_tabItemVec[i]->Release();
		}
		m_tabItemVec.clear();
		m_tabSpliterVec.clear();
		m_categoryTabListenerSet.clear();
		m_RemoveSizeListener();
		m_RemoveHighlightbarSizeListener();

		if (m_leftArrows != NULL)
		{
			m_leftArrows->RemoveMouseListener(this);
			m_leftArrows->Release();
		}
		if (m_rightArrows != NULL)
		{
			m_rightArrows->RemoveMouseListener(this);
			m_rightArrows->Release();
		}
		if (m_highlightBar != NULL)
		{
			m_highlightBar->Release();
		}
		if (m_tabAreaActor != NULL)
		{
			m_tabAreaActor->Release();
		}
		if (m_background != NULL)
		{
			m_background->Release();
		}
		if (m_swapMoveAni != NULL)
		{
			m_swapMoveAni->Release();
		}
		if (m_resizeHighlightAni != NULL)
		{
			m_resizeHighlightAni->Release();
		}
		if (m_replaceHighlightAni != NULL)
		{
			m_replaceHighlightAni->Release();
		}
		RemoveFocusListener(this);
		RemoveKeyboardListener(this);
		RemoveMouseListener(this);
	}

	bool CCategoryTab::Initialize(IActor *parent, float width, float height)
	{
		Widget *cParent = dynamic_cast<Widget*>(parent);

		return Initialize(cParent, width, height);
	}

	bool CCategoryTab::Initialize(Widget *parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::Initialize a CategoryTab");

		for (int i = 0; i < ICategoryTab::STATE_ALL; i++)
		{
			ClutterColor defaultBgColor = { 0, 0, 0, 0 };
			ClutterColor defaultTextColor = { 0, 0, 0, 255 };
			m_defaultTabBackgroundColor[i] = defaultBgColor;
			m_defaultTabTextColor[i] = defaultTextColor;
			m_defaultTabFontSize[i] = 20;
			m_defaultTabIconAlpha[i] = 255;
		}

		for (int i = 0; i <= STATE_SELECT_ALL; i++)
		{
			m_tabCheckImageOpacityData[i] = 255;
			m_tabCheckBoxImageOpacityData[i] = 255;
		}

		CActor::Initialize(parent, width, height);
		Widget *widget = dynamic_cast<Widget*>(this);
		if (widget != NULL)
		{
			ClutterColor c = { 125, 125, 125, 255 };

			m_background = ICompositeImage::CreateInstance(widget, width, height);

			m_highlightBar = IActor::CreateInstance(widget, 0, 0);
			m_highlightBar->SetBackgroundColor(*clutter_color_init(&c, 30, 158, 230, 255));
			m_highlightBar->Hide();

			m_tabAreaActor = IActor::CreateInstance(widget, width, height);
			//m_tabAreaActor->EnableReverse(false);
			//m_tabAreaActor->EnableClipOverflow(true);
			//for test
			//m_tabAreaActor->SetBackgroundColor(*clutter_color_init(&c, 255, 0, 0, 255));

			m_leftArrows = IImage::CreateInstance(m_background, 30, height);
			m_leftArrows->SetFillMode(CLUTTER_CONTENT_GRAVITY_LEFT);
			m_leftArrows->EnableFocus(false);
			m_leftArrows->EnablePointerFocus(false);
			m_leftArrows->Enable(false);
			m_leftArrows->EnableReverse(false);
			m_leftArrows->AddMouseListener(this);
			m_leftArrows->Hide();

			m_rightArrows = IImage::CreateInstance(m_background, 30, height);
			m_rightArrows->SetFillMode(CLUTTER_CONTENT_GRAVITY_RIGHT);
			m_rightArrows->EnableFocus(false);
			m_rightArrows->EnablePointerFocus(false);
			m_rightArrows->Enable(false);
			m_rightArrows->EnableReverse(false);
			m_rightArrows->AddMouseListener(this);
			m_rightArrows->Hide();

			//SetBackgroundColor(c);
			//init default attrs
			//not open
			m_isEnableAlwaysScroll = false;
			m_useSelfReverse = false;

			m_allocationListenerId = -1;
			m_highlightbarSizeListenerId = -1;
			m_focusIndex = -1;
			m_focusIndexLast = -1;
			m_mouseinIndex = -1;
			m_selectedIndex = m_highlightedIndex = -1;
			m_isEnableLooping = true;
			m_isEnableHighlightbar = true;
			m_isHighlightbarBottom = false;
			m_isEnableKey = true;
			m_highlightbarFocusHeight = height;
			m_highlightbarUnfocusHeight = 5;
			m_tabTargetHeightMin = height;
			m_tabTargetHeightMax = -1;
			m_highlightbarEasingDuration = 400;
			m_highlightbarMoveDuration = 200;
			m_highlightbarEasingMode = CLUTTER_LINEAR;
			m_highlightbarMoveMode = CLUTTER_LINEAR;
			m_tabsAlignCenter = true;
			m_isReverse = false;
			m_isEnableChangeTab = true;
			m_isShowCheckBox = false;
			m_highlightbarExpand = true;
			m_tabSpliterWidth = m_tabSpliterHeight = 2.f;
			m_tabIconDefaultWidth = m_tabIconDefaultHeight = 38.f;
			m_tabTextlimitWidth = 500;
			m_marginTop = m_marginBottom = 0;
			m_marginLeft = m_marginRight = width * 0.005208f;
			m_tabLeftMargin = m_tabRightMargin = width * 0.020833f;
			m_tabIconMargin = width * 0.017188f;
			m_checkboxWidth = m_checkboxHeight = 38.f;
			m_checkboxMargin = width * 0.017188f;
			m_tabspliterColor = *clutter_color_init(&c, 70, 70, 70, 255);
			m_tabLeftImageWidth = m_tabLeftImageHeight = m_tabRightImageWidth = m_tabRightImageHeight = 30;
			m_tabLeftImageMargin = m_tabRightImageMargin = 5;
			m_swapFrom = m_swapTo = -1;
			m_isSwapMoveAni = false;
			m_isResizeHighlightAni = false;
			m_isDragMove = 0;
			m_isEnableDragTab = false;
			m_swapMoveDuration = 200;
			m_dragX = m_dragY = -1;
			m_highlightDragX = m_highlightDragY = -1;
			m_isAutoShowLeftRightImage = false;

			m_textscrollDefaultDuration = 2500;
			m_textscrollDefaultSpeed = 0.06f;
			m_textscrollDefaultDelay = 0;
			m_textscrollDefaultRepeat = -1;
			m_textscrollDefaultType = CLUTTER_TEXT_SCROLL_START_OUTSIDE_STOP_OUTSIDE;
			m_textscrollDefaultDirection = CLUTTER_TIMELINE_BACKWARD;
			m_textscrollDefaultContinueGap = 0;

			SetTabFont("Sans 28px"); //default font name and size
			SetTabFontSize(ICategoryTab::STATE_UNSELECTED, 28);
			SetTabFontSize(ICategoryTab::STATE_SELECTED, 31);
			SetTabFontSize(ICategoryTab::STATE_HIGHLIGHTED, 31);
			SetTabTextColor(ICategoryTab::STATE_UNSELECTED, *clutter_color_init(&c, 255, 255, 255, 255));
			SetTabTextColor(ICategoryTab::STATE_SELECTED, *clutter_color_init(&c, 30, 158, 230, 255));
			SetTabTextColor(ICategoryTab::STATE_HIGHLIGHTED, *clutter_color_init(&c, 70, 70, 70, 255));
			//SetTabColor(ICategoryTab::STATE_UNSELECTED, *clutter_color_init(&c, 242, 242, 242, 255));
			//SetTabColor(ICategoryTab::STATE_SELECTED, *clutter_color_init(&c, 242, 242, 242, 255));
			//SetTabColor(ICategoryTab::STATE_HIGHLIGHTED, *clutter_color_init(&c, 30, 158, 230, 255));
			SetSpliterColor(*clutter_color_init(&c, 255, 255, 255, 255 * 0.6));
			SetHighlightBarUnfocusedColor(*clutter_color_init(&c, 255, 255, 255, 255));
			SetHighlightBarFocusedColor(*clutter_color_init(&c, 33, 158, 230, 255));

			m_leftArrows->SetBackgroundColor(*clutter_color_init(&c, 0, 0, 0, 0));
			m_rightArrows->SetBackgroundColor(*clutter_color_init(&c, 0, 0, 0, 0));

			m_lastWidth = m_lastHeight = -1;
			m_ResizeCategoryTab();
		}

		EnableFocus(true);
		EnablePointerFocus(false);
		AddMouseListener(this);
		AddFocusListener(this);
		AddKeyboardListener(this);
		m_AddSizeListener();
		if (m_isHighlightbarBottom)
		{
			m_AddHighlightbarSizeListener();
		}

		m_swapMoveAni = new CMultiObjectTransition;
		m_swapMoveAni->Initialize();
		m_swapMoveAni->AddListener(this, m_swapMoveAni);
		m_swapMoveAni->AddAnimatableObject(m_highlightBar, IActor::ACTOR_ANI_POSITION);
		m_resizeHighlightAni = new CMultiObjectTransition;
		m_resizeHighlightAni->Initialize();
		m_resizeHighlightAni->AddListener(this, m_resizeHighlightAni);
		m_resizeHighlightAni->AddAnimatableObject(m_highlightBar, IActor::ACTOR_ANI_SIZE);
		m_replaceHighlightAni = new CMultiObjectTransition;
		m_replaceHighlightAni->Initialize();
		m_replaceHighlightAni->AddListener(this, m_replaceHighlightAni);
		m_replaceHighlightAni->AddAnimatableObject(m_highlightBar, IActor::ACTOR_ANI_POSITION);

		if (ParentWidgetExtension() != NULL && ParentWidgetExtension()->Orientation(true) == ORIENTATION_RIGHT_TO_LEFT)
		{
			t_UpdateOrientation(ORIENTATION_RIGHT_TO_LEFT);
		}

		return true;
	}

	void CCategoryTab::m_AddSizeListener(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_AddSizeListener.");
		m_allocationListenerId = g_signal_connect(Actor(), "notify::size", G_CALLBACK(m_OnResize), this);
	}

	void CCategoryTab::m_RemoveSizeListener(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_RemoveSizeListener.");
		if (m_allocationListenerId > 0)
		{
			g_signal_handler_disconnect(Actor(), m_allocationListenerId);
		}
	}
	void CCategoryTab::m_AddHighlightbarSizeListener(void)
	{
		m_highlightbarSizeListenerId = g_signal_connect(m_highlightBar->Actor(), "notify::size", G_CALLBACK(m_OnHighlightBarResize), this);
	}
	void CCategoryTab::m_RemoveHighlightbarSizeListener(void)
	{
		if (m_highlightbarSizeListenerId > 0)
		{
			g_signal_handler_disconnect(m_highlightBar->Actor(), m_highlightbarSizeListenerId);
		}
	}


	void CCategoryTab::m_OnResize(GObject* object, GParamSpec* paramSpec, gpointer user_data)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_OnResize.");
		CCategoryTab* tab = (CCategoryTab*)user_data;

		//Stop scroll
		//tab->m_StopTextScroll();

		//Resize all child-actors
		tab->m_ResizeCategoryTab();
		if (!tab->m_isSwapMoveAni && tab->m_isHighlightbarBottom)
		{
			tab->m_KeepHighlightBarBottom();
		}

	}
	void CCategoryTab::m_OnHighlightBarResize(GObject* object, GParamSpec* paramSpec, gpointer user_data)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_OnResize.");
		CCategoryTab* tab = (CCategoryTab*)user_data;
		if (!tab->m_isSwapMoveAni && tab->m_isDragMove <= 0)
		{
			tab->m_KeepHighlightBarBottom();
		}
	}

	IText* CCategoryTab::TabTextActor(int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::TabTextActor[" << index << "]");
		HALO_EXCEPTION(index >= 0 && index < (int)m_tabItemVec.size(), "Index out of range.");
		return m_tabItemVec[index]->TextActor();
	}

	ICompositeImage* CCategoryTab::TabImageActor(int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::TabImageActor[" << index << "]");
		HALO_EXCEPTION(index >= 0 && index < (int)m_tabItemVec.size(), "Index out of range.");
		return m_tabItemVec[index]->BackgroundImageActor();
	}

	void CCategoryTab::SetMargin(float top, float bottom, float left, float right)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetMargin [" << top << "," << bottom << "," << left << "," << right << "]");
		m_marginTop = top;
		m_marginBottom = bottom;
		m_marginLeft = left;
		m_marginRight = right;

		m_ResizeArrows();
		m_ResizeTabArea(true);

		m_ReplaceArrows();
		m_ReplaceTabArea(false);
		m_ReplaceSpliters();
		m_ReplaceHighlightBar(m_focusIndex);
	}

	void CCategoryTab::SetSpliterSize(float width, float height, int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetSpliterSize [" << width << ", " << height << "]");
		if (index < 0)
		{
			m_ResizeSpliters(width, height);
		}
		else if (index < (int)m_tabSpliterVec.size())
		{
			m_tabSpliterVec[index]->Resize(width, height);
		}
		m_ReplaceTabArea(true);
		m_ReplaceSpliters();
	}

	void CCategoryTab::EnableLooping(bool enable)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::EnableLooping [" << enable << "]");
		m_isEnableLooping = enable;
	}

	bool CCategoryTab::IsLoopingEnabled(void) const
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::IsLoopingEnabled .");
		return m_isEnableLooping;
	}
	void CCategoryTab::EnableAlignTabsCenter(bool enable)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::EnableAlignTabsCenter [" << enable << "]");
		m_tabsAlignCenter = enable;
	}

	bool CCategoryTab::IsAlignTabsCenterEnabled(void) const
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::IsAlignTabsCenterEnabled .");
		return m_tabsAlignCenter;
	}

	int CCategoryTab::CurrentTabIndex(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::CurrentTabIndex");
		return m_focusIndex;
	}

	const char* CCategoryTab::CurrentTabText(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::CurrentTabText");
		if (m_focusIndex < 0 || m_focusIndex >= (int)m_tabItemVec.size())
		{
			return "";
		}
		return TabText(m_focusIndex);
	}

	const char* CCategoryTab::TabText(int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::CurrentTabText");
		HALO_EXCEPTION(index >= 0 && index < (int)m_tabItemVec.size(), "Index out of range.");
		return m_tabItemVec[index]->TextActor()->Text();
	}

	bool CCategoryTab::ChangeTab(int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::ChangeTab [" << index << "]");
		HALO_EXCEPTION(index >= 0 && index < (int)m_tabItemVec.size(), "Index out of range.");
		if (index <0 || index >= (int)m_tabItemVec.size() || m_tabItemVec[index] == NULL || !m_isEnableChangeTab)
		{
			return false;
		}
		m_focusIndex = index;
		m_GetFocusOn(m_focusIndex);
		m_ReplaceHighlightBar(m_focusIndex);
		return true;
	}

	int CCategoryTab::NumberOfTab(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::NumberOfTab");
		return (int)m_tabItemVec.size();
	}

	void CCategoryTab::SetLeftArrowsSize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetLeftArrowsSize [" << width << "," << height << "]");
		m_leftArrows->Resize(width, height);

		m_ResizeArrows();
		m_ResizeTabArea(true);

		m_ReplaceArrows();
		m_ReplaceTabArea(false);
		m_ReplaceSpliters();
		m_ReplaceHighlightBar(m_focusIndex);
	}

	void CCategoryTab::SetRightArrowsSize(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetRightArrowsSize [" << width << "," << height << "]");
		m_rightArrows->Resize(width, height);

		m_ResizeArrows();
		m_ResizeTabArea(true);

		m_ReplaceArrows();
		m_ReplaceTabArea(false);
		m_ReplaceSpliters();
		m_ReplaceHighlightBar(m_focusIndex);
	}

	void CCategoryTab::m_RefreshArrows(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::RefreshArrows");
		bool leftFlag = false, rightFlag = false;

		if (m_tabItemVec.size() > 1)
		{
			if (m_isReverse && m_useSelfReverse)
			{
				float x, y;
				m_tabItemVec[m_tabItemVec.size() - 1]->GetPosition(x, y);
				if ((int)(x - m_tabSpliterWidth) < 0)
				{
					leftFlag = true;
				}

				m_tabItemVec[0]->GetPosition(x, y);
				float tabitemWidth = 0, tabitemHeight = 0;
				m_tabItemVec[0]->GetSize(tabitemWidth, tabitemHeight);
				float tabareaWidth = 0, tabareaHeight = 0;
				m_tabAreaActor->GetSize(tabareaWidth, tabareaHeight);
				if ((int)(x + tabitemWidth + m_tabSpliterWidth) > (int)tabareaWidth)
				{
					rightFlag = true;
				}
			}
			else
			{
				float x, y;
				m_tabItemVec[0]->GetPosition(x, y);
				if ((int)(x - m_tabSpliterWidth) < 0)
				{
					leftFlag = true;
				}

				m_tabItemVec[m_tabItemVec.size() - 1]->GetPosition(x, y);
				float tabitemWidth = 0, tabitemHeight = 0;
				m_tabItemVec[m_tabItemVec.size() - 1]->GetSize(tabitemWidth, tabitemHeight);
				float tabareaWidth = 0, tabareaHeight = 0;
				m_tabAreaActor->GetSize(tabareaWidth, tabareaHeight);
				if ((int)(x + tabitemWidth + m_tabSpliterWidth) > (int)tabareaWidth)
				{
					rightFlag = true;
				}
			}
		}

		m_leftArrows->Hide();
		m_rightArrows->Hide();
		if (leftFlag)
		{
			/*
			if ((int)m_leftArrowsImage.length() > 0)
			{
			m_leftArrows->SetImage(m_leftArrowsImage.c_str());
			}
			*/
			if (m_isReverse)
			{
				m_rightArrows->Show();
			}
			else
			{
				m_leftArrows->Show();
			}
		}
		if (rightFlag)
		{
			/*
			if ((int)m_rightArrows_image.length() > 0)
			{
			m_rightArrows->SetImage(m_rightArrows_image.c_str());
			}
			*/
			if (m_isReverse)
			{
				m_leftArrows->Show();
			}
			else
			{
				m_rightArrows->Show();
			}
		}
	}

	void CCategoryTab::SetBackgroundColor(const ClutterColor &color)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetBackgroundColor");
		m_background->SetBackgroundColor(color);
	}

	//LIsteners:	
	bool CCategoryTab::OnMouseButtonPressed(IWidgetExtension* pThis, IMouseEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::OnMouseButtonPressed");

		if (pThis == m_leftArrows)
		{
			m_TabArrowsClickedListenerCallBack(0);
		}
		else if (pThis == m_rightArrows)
		{
			m_TabArrowsClickedListenerCallBack(1);
		}
		else if (!m_resizeHighlightAni->IsPlaying())
		{
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{
				if (m_tabItemVec[i] == pThis)
				{
					if (m_isAutoShowLeftRightImage)
					{
						ShowTabLeftImage(i);
						ShowTabRightImage(i);
					}
					if (m_isEnableChangeTab  && !m_isResizeHighlightAni)
					{
						if (IsFocused())
						{
							if (m_tabItemVec[i]->CheckBoxActor()->FlagShow())
							{
								m_tabItemVec[i]->CheckBoxActor()->SetCheck(!m_tabItemVec[i]->CheckBoxActor()->IsChecked());
							}
							if (i != m_focusIndex)
							{
								m_focusIndex = i;
								m_GetFocusOn(m_focusIndex);
								m_ReplaceHighlightBar(m_focusIndex);
							}
							m_TabClickedListenerCallBack(i);
						}
						else
						{
							m_focusIndex = i;
							m_LocationSubTab(m_focusIndex);
							SetFocus();
						}
					}
					break;
				}
			}
		}
		return true;
	}

	bool CCategoryTab::OnMouseButtonReleased(IWidgetExtension* pThis, IMouseEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::OnMouseButtonReleased");
		if (m_isAutoShowLeftRightImage)
		{
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{
				if (m_tabItemVec[i] == pThis)
				{
					HideTabLeftImage(i);
					HideTabRightImage(i);
					break;
				}
			}
		}
		return true;
	}

	bool CCategoryTab::OnFocusIn(IWidgetExtension* pWindow)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::OnFocusIn");
		if (pWindow == this)
		{
			if ((int)m_tabItemVec.size() > 0)
			{
				if (m_focusIndex < 0)
				{
					if (m_mouseinIndex > -1)
					{
						m_focusIndex = m_mouseinIndex;
					}
					else
					{
						m_focusIndex = 0;
					}
					m_ReplaceHighlightBar(m_focusIndex);
					m_GetFocusOn(m_focusIndex);
					m_ChangeTabItemState(m_focusIndex, STATE_HIGHLIGHTED);
					m_StopTextScroll(m_focusIndex);
					m_ExpandHighlightBar(true);
				}
				else
				{
					for (int i = 0; i < (int)m_tabItemVec.size(); i++)
					{
						m_ChangeTabItemState(i, STATE_UNSELECTED);
					}
					if (m_mouseinIndex > -1)
					{
						m_ChangeTabItemState(m_mouseinIndex, STATE_HIGHLIGHTED);
						m_StopTextScroll(m_mouseinIndex);
						m_ReplaceHighlightBar(m_mouseinIndex);
					}
					else
					{
						m_ChangeTabItemState(m_focusIndex, STATE_HIGHLIGHTED);
						m_StopTextScroll(m_focusIndex);
						m_ReplaceHighlightBar(m_focusIndex);
					}
					m_ExpandHighlightBar(true);
				}
			}
		}
		return true;
	}

	bool CCategoryTab::OnFocusOut(IWidgetExtension* pWindow)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::OnFocusOut");
		if (pWindow == this)
		{
			if ((int)m_tabItemVec.size() > 0)
			{
				//focus out before mouse out
				if (m_mouseinIndex > -1)
				{
					if (m_focusIndex > -1 && m_mouseinIndex != m_focusIndex)
					{
						m_ChangeTabItemState(m_mouseinIndex, STATE_UNSELECTED);
					}
					else if (m_focusIndex < 0)
					{
						m_ChangeTabItemState(m_mouseinIndex, STATE_UNSELECTED);
						m_highlightBar->Hide();
					}
					m_mouseinIndex = -1;
				}
				if (m_focusIndex > -1)
				{
					m_LocationSubTab(m_focusIndex);
					m_ReplaceHighlightBar(m_focusIndex, false);
					m_ChangeTabItemState(m_focusIndex, STATE_SELECTED);
					m_StopTextScroll(m_focusIndexLast);
					m_ShrinkHighlightBar(true);
				}
			}
		}
		return true;
	}

	void CCategoryTab::m_GetFocusOn(int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::GetFocusOn");
		if (index < 0 || index >= (int)m_tabItemVec.size() || m_tabItemVec[index] == NULL)
		{
			m_highlightBar->Hide();
			return;
		}
		if (index == m_focusIndexLast)
		{
			m_LocationSubTab(index);
			return;
		}

		for (int i = 0; i < (int)m_tabItemVec.size(); i++)
		{
			m_ChangeTabItemState(i, STATE_UNSELECTED);
		}
		//m_StopTextScroll(m_focusIndexLast);

		if (IsFocused())
		{
			m_ChangeTabItemState(index, STATE_HIGHLIGHTED);
		}
		else
		{
			m_ChangeTabItemState(index, STATE_SELECTED);
		}
		m_LocationSubTab(index);

		m_TabChangedListenerCallBack();
		m_focusIndexLast = index;
		//m_ReplaceHighlightBar(index);
	}

	void CCategoryTab::m_MoveTabItems(int from, float distance)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::MoveTabItems [ from:" << from << " , distance:" << distance << "]");

		for (int i = from; i < (int)m_tabItemVec.size(); i++)
		{
			float x, y;
			m_tabItemVec[i]->GetPosition(x, y);
			m_tabItemVec[i]->SetPosition(x + distance, y);
		}
	}

	void CCategoryTab::m_StartTextScroll(int index)
	{
		if (index > -1 && index < (int)m_tabItemVec.size())
		{
			if (m_tabItemVec[index]->TextActor() != NULL)
			{
				m_tabItemVec[index]->TextActor()->StartScrollText();
			}
		}
	}

	void CCategoryTab::m_StopTextScroll(int index)
	{
		if (index >= 0 && index < (int)m_tabItemVec.size())
		{
			m_tabItemVec[index]->TextActor()->StopScrollText();
		}
	}

	bool CCategoryTab::OnKeyPressed(IWidgetExtension* pThis, IKeyboardEvent* event)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::OnKeyPressed");
		if (!m_isEnableKey)
		{
			return true;
		}

		int keyValue = event->GetKeyVal();
		if (keyValue == CLUTTER_KEY_Down)
		{
			/*
			if (!m_enableAlwaysScroll)
			{
			m_StopTextScroll();
			}
			*/
		}
		else if (keyValue == CLUTTER_KEY_Up)
		{
			/*
			if (!m_enableAlwaysScroll)
			{
			m_StopTextScroll();
			}
			*/
		}
		else if (keyValue == CLUTTER_KEY_Right)
		{
			if (m_isEnableChangeTab && !m_isResizeHighlightAni)
			{
				if (m_isReverse)
				{
					if (m_focusIndex > 0)
					{
						m_GetFocusOn(--m_focusIndex);
						m_ReplaceHighlightBar(m_focusIndex, true);
					}
					else if (m_isEnableLooping)
					{
						m_focusIndex = (int)m_tabItemVec.size() - 1;
						m_GetFocusOn(m_focusIndex);
						m_ReplaceHighlightBar(m_focusIndex, false);
					}
				}
				else
				{
					if ((m_focusIndex + 1) < (int)m_tabItemVec.size())
					{
						m_GetFocusOn(++m_focusIndex);
						m_ReplaceHighlightBar(m_focusIndex, true);
					}
					else if (m_isEnableLooping)
					{
						m_focusIndex = 0;
						m_GetFocusOn(m_focusIndex);
						m_ReplaceHighlightBar(m_focusIndex, false);
					}
				}
			}
		}
		else if (keyValue == CLUTTER_KEY_Left)
		{
			if (m_isEnableChangeTab && !m_isResizeHighlightAni)
			{
				if (m_isReverse)
				{
					if ((m_focusIndex + 1) < (int)m_tabItemVec.size())
					{
						m_GetFocusOn(++m_focusIndex);
						m_ReplaceHighlightBar(m_focusIndex, true);
					}
					else if (m_isEnableLooping)
					{
						m_focusIndex = 0;
						m_GetFocusOn(m_focusIndex);
						m_ReplaceHighlightBar(m_focusIndex, false);
					}
				}
				else
				{
					if (m_focusIndex > 0)
					{
						m_GetFocusOn(--m_focusIndex);
						m_ReplaceHighlightBar(m_focusIndex, true);
					}
					else if (m_isEnableLooping)
					{
						m_focusIndex = (int)m_tabItemVec.size() - 1;
						m_GetFocusOn(m_focusIndex);
						m_ReplaceHighlightBar(m_focusIndex, false);
					}
				}
			}
		}
		return true;
	}

	bool CCategoryTab::OnKeyReleased(IWidgetExtension* pWindow, IKeyboardEvent* ptrKeyboardEvent)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::OnKeyReleased");
		if (!m_isEnableKey)
		{
			return true;
		}
		int keyValue = ptrKeyboardEvent->GetKeyVal();

		if (keyValue == CLUTTER_KEY_Return)
		{
			if (m_focusIndex > -1)
			{
				if (m_tabItemVec[m_focusIndex]->CheckBoxActor()->FlagShow())
				{
					m_tabItemVec[m_focusIndex]->CheckBoxActor()->SetCheck(!m_tabItemVec[m_focusIndex]->CheckBoxActor()->IsChecked());
				}
				m_TabClickedListenerCallBack(m_focusIndex);
			}
		}
		return true;
	}

	//Set Images:
	void CCategoryTab::SetBackgroundImage(const std::string& image)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetBackgroundImage, [" << image << "]");

		m_background->SetImage(image.c_str());
	}

	std::string CCategoryTab::BackgroundImage(void) const
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::BackgroundImage");
		return m_background->ImagePath();
	}

	void CCategoryTab::SetSpliterImage(const std::string& image)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetSpliterImage, [" << image << "]");
		m_spliterImage = image;
		for (int i = 0; i < (int)m_tabSpliterVec.size(); i++)
		{
			m_tabSpliterVec[i]->SetImage(m_spliterImage.c_str());
		}
	}

	std::string CCategoryTab::SpliterImage(void) const
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SpliterImage");
		return m_spliterImage;
	}

	void CCategoryTab::SetLeftArrowsImage(const std::string& image)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetLeftArrowsImage, [" << image << "]");
		m_leftArrowsImage = image;
		m_leftArrows->SetImage(m_leftArrowsImage.c_str());
	}

	void CCategoryTab::SetRightArrowsImage(const std::string& image)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetRightArrowsImage, [" << image << "]");
		m_rightArrowsImage = image;
		m_rightArrows->SetImage(m_rightArrowsImage.c_str());
	}

	std::string CCategoryTab::LeftArrowsImage(void) const
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::LeftArrowsImage.");
		return m_leftArrowsImage;
	}

	std::string CCategoryTab::RightArrowsImage(void) const
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::RightArrowsImage.");
		return m_rightArrowsImage;
	}

	void CCategoryTab::SetTabFont(const std::string& font)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabFont.");
		m_textFont = font;
	}

	std::string CCategoryTab::TabFont(void) const
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::TabFont.");
		return m_textFont;
	}

	void CCategoryTab::SetTabFontSize(ECategoryTabState state, int size)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabFontSize, [" << state << "," << size << "]");
		switch (state)
		{
		case STATE_UNSELECTED:
		case STATE_SELECTED:
		case STATE_HIGHLIGHTED:
			m_defaultTabFontSize[state] = size;
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{
				m_tabItemVec[i]->m_stateData[state].fontSize = size;
			}
			break;
		case STATE_ALL:
			for (int i = 0; i < STATE_ALL; i++)
			{
				m_defaultTabFontSize[i] = size;
			}
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{
				for (int j = 0; j < STATE_ALL; j++)
				{
					m_tabItemVec[i]->m_stateData[j].fontSize = size;
				}
			}
			break;
		}
		m_ResetTabItemsState();
	}

	void CCategoryTab::SetTabTextColor(ECategoryTabState state, const ClutterColor &color)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabTextColor, [" << state << "]");
		switch (state)
		{
		case STATE_UNSELECTED:
		case STATE_SELECTED:
		case STATE_HIGHLIGHTED:
			m_defaultTabTextColor[state] = color;
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{
				m_tabItemVec[i]->m_stateData[state].textColor = color;
			}
			break;
		case STATE_ALL:
			for (int i = 0; i < STATE_ALL; i++)
			{
				m_defaultTabTextColor[i] = color;
			}
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{
				for (int j = 0; j < STATE_ALL; j++)
				{
					m_tabItemVec[i]->m_stateData[j].textColor = color;
				}
			}
			break;
		}
		m_ResetTabItemsState();
	}

	void CCategoryTab::SetTabColor(ECategoryTabState state, const ClutterColor &color)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabColor, [" << state << "]");
		switch (state)
		{
		case STATE_UNSELECTED:
		case STATE_SELECTED:
		case STATE_HIGHLIGHTED:
			m_defaultTabBackgroundColor[state] = color;
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{
				m_tabItemVec[i]->m_stateData[state].backgroundColor = color;
			}
			break;
		case STATE_ALL:
			for (int i = 0; i < STATE_ALL; i++)
			{
				m_defaultTabBackgroundColor[i] = color;
			}
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{
				for (int j = 0; j < STATE_ALL; j++)
				{
					m_tabItemVec[i]->m_stateData[j].backgroundColor = color;
				}
			}
			break;
		}
		m_ResetTabItemsState();
	}

	void CCategoryTab::SetTabImage(ECategoryTabState state, const char* image)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabImage, [" << state << "," << image << "]");
		HALO_ASSERT(NULL != image);
		switch (state)
		{
		case STATE_UNSELECTED:
		case STATE_SELECTED:
		case STATE_HIGHLIGHTED:
			m_defaultTabBackgroundImage[state] = image;
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{
				m_tabItemVec[i]->m_stateData[state].backgroundImagePath = image;
			}
			break;
		case STATE_ALL:
			for (int i = 0; i < STATE_ALL; i++)
			{
				m_defaultTabBackgroundImage[i] = image;
			}
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{
				for (int j = 0; j < STATE_ALL; j++)
				{
					m_tabItemVec[i]->m_stateData[j].backgroundImagePath = image;
				}
			}
			break;
		}
		m_ResetTabItemsState();
	}

	void CCategoryTab::SetHighlightBarColor(const ClutterColor& color)
	{
		m_highlightBar->SetBackgroundColor(color);
	}

	bool CCategoryTab::IsHightlightBarEnabled(void) const
	{
		return m_isEnableHighlightbar;
	}

	void CCategoryTab::EnableHighlightBar(bool enable)
	{
		if (enable == m_isEnableHighlightbar)
		{
			return;
		}
		m_isEnableHighlightbar = enable;
		if (m_isEnableHighlightbar)
		{
			m_highlightBar->Show();
		}
		else
		{
			m_highlightBar->Hide();
		}
	}

	float CCategoryTab::HighlightBarHeight(void) const
	{
		float w = 0, h = 0;
		m_highlightBar->GetSize(w, h);
		return h;
	}

	void CCategoryTab::SetHighlightBarHeight(float height)
	{
		float w = 0, h = 0;
		m_highlightBar->GetSize(w, h);
		m_highlightBar->Resize(w, height);
	}

	float CCategoryTab::TabTextLimitWidth(void) const
	{
		return m_tabTextlimitWidth;
	}

	void CCategoryTab::SetTabTextLimitWidth(float limit)
	{
		m_tabTextlimitWidth = limit;
		m_ResizeTabArea(true);
	}

	void CCategoryTab::SetTabTextLeftMargin(float margin)
	{
		m_tabLeftMargin = margin;
		m_ResizeTabArea(true);
	}

	void CCategoryTab::SetTabTextRightMargin(float margin)
	{
		m_tabRightMargin = margin;
		m_ResizeTabArea(true);
	}

	float CCategoryTab::TabTextLeftMargin(void) const
	{
		return m_tabLeftMargin;
	}

	float CCategoryTab::TabTextRightMargin(void) const
	{
		return m_tabRightMargin;
	}

	void CCategoryTab::m_InitTabItemProperties(CCategoryTabItem *tabItem)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::InitTabItemProperties");

		if ((int)m_textFont.length() > 0)
		{
			tabItem->TextActor()->SetFont(m_textFont.c_str());
		}

		for (int i = 0; i < STATE_ALL; i++)
		{
			tabItem->m_stateData[i].backgroundImagePath = m_defaultTabBackgroundImage[i];
			tabItem->m_stateData[i].backgroundColor = m_defaultTabBackgroundColor[i];
			//text content already set in AddTab()
			//text font will be always same
			tabItem->m_stateData[i].textColor = m_defaultTabTextColor[i];
			tabItem->m_stateData[i].fontSize = m_defaultTabFontSize[i];
			tabItem->m_stateData[i].iconPath = m_defaultTabIconImage[i];
			tabItem->m_stateData[i].iconAlpha = m_defaultTabIconAlpha[i];
			//left image will be always same
			//right image will be always same
		}
	}

	int CCategoryTab::m_GetTabMaxFontSize(void)
	{
		int maxfontsize = 0;
		for (int i = 0; i < STATE_ALL; i++)
		{
			if (m_defaultTabFontSize[i] > maxfontsize)
			{
				maxfontsize = m_defaultTabFontSize[i];
			}
		}
		return maxfontsize;
	}

	float CCategoryTab::m_CalTextWidth(const char* text, const std::string& font, int fontsize)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::CalTextWidth, [" << text << "]");
		if (fontsize < 0)
		{
			fontsize = 20;
		}
		// 1. create ClutterText
		ClutterText* text1 = (ClutterText*)clutter_text_new();
		// 2. set font 
		clutter_text_set_font_name(text1, font.c_str());
		// 3. set font size
		PangoFontDescription *fontdes = pango_font_description_from_string(clutter_text_get_font_name(text1));
		gboolean flag = pango_font_description_get_size_is_absolute(fontdes);
		if (!flag)
		{
			pango_font_description_set_size(fontdes, (gint)fontsize *PANGO_SCALE);
		}
		else
		{
			pango_font_description_set_absolute_size(fontdes, (gint)fontsize *PANGO_SCALE);
		}
		clutter_text_set_font_description(text1, fontdes);
		pango_font_description_free(fontdes);
		// 4. set text
		clutter_text_set_text(text1, text);
		// 5. get width
		float width = clutter_actor_get_width(CLUTTER_ACTOR(text1));
		clutter_actor_destroy(CLUTTER_ACTOR(text1));
		return width;
	}

	bool CCategoryTab::AddTab(const char* text)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::AddTab, [" << text << "]");
		HALO_ASSERT(NULL != text);
		return AddTab(text, (int)m_tabItemVec.size());
	}

	bool CCategoryTab::AddTab(const char* text, int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::AddTab, [" << text << "," << index << "]");
		HALO_ASSERT(NULL != text);
		return AddTab(text, -1, -1, index);
	}

	bool CCategoryTab::AddTab(const char* text, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::AddTab, [" << text << "," << width << "," << height << "]");
		HALO_ASSERT(NULL != text);
		return AddTab(text, width, height, (int)m_tabItemVec.size());
	}

	bool CCategoryTab::AddTab(const char* text, float width, float height, int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::AddTab, [" << text << "," << width << "," << height << "," << index << "]");
		HALO_ASSERT(NULL != text);
		if (index < 0)
		{
			return false;
		}

		float widthOri = width;
		if (width < 0)
		{
			//auto width
			int fontsize = m_GetTabMaxFontSize();
			width = m_CalTextWidth(text, m_textFont, fontsize);
		}
		if (width > m_tabTextlimitWidth)
		{
			//text width limit
			width = m_tabTextlimitWidth;
		}
		//add margin
		width = width + m_tabLeftMargin + m_tabRightMargin;

		int size = m_tabItemVec.size();


		float tabWidth = 0, tabHeight = 0;
		m_tabAreaActor->GetSize(tabWidth, tabHeight);

		bool heightFillFlag = false;
		if (height < 0 || height > tabHeight)
		{
			//height >= tab_heigt,  then button fill the tab area
			height = tabHeight;
			heightFillFlag = true;
		}

		CCategoryTabItem *tabItem = new CCategoryTabItem();
		tabItem->Initialize(m_tabAreaActor, width, height);
		std::string strtext(text);
		for (int i = 0; i < STATE_ALL; i++)
		{
			tabItem->m_stateData[i].textContent = strtext;
		}
		m_InitTabItemProperties(tabItem);
		//text
		tabItem->TextActor()->Resize(width - m_tabLeftMargin - m_tabRightMargin, height);
		tabItem->TextActor()->SetPosition(m_tabLeftMargin, 0);
		tabItem->TextActor()->EnableEllipsize(true);
		//tabItem->TextActor()->SetScrollAttribute(2500, 0.06f, 0, -1, CLUTTER_TEXT_SCROLL_START_OUTSIDE_STOP_OUTSIDE, CLUTTER_TIMELINE_BACKWARD, 0);
		tabItem->TextActor()->SetScrollAttribute(m_textscrollDefaultDuration, m_textscrollDefaultSpeed, m_textscrollDefaultDelay, m_textscrollDefaultRepeat, m_textscrollDefaultType, m_textscrollDefaultDirection, m_textscrollDefaultContinueGap);

		//icon
		if (tabItem->IconActor() != NULL)
		{
			tabItem->IconActor()->Resize(m_tabIconDefaultWidth, m_tabIconDefaultHeight);
			tabItem->IconActor()->SetPosition(m_tabIconMargin, (height - m_tabIconDefaultHeight) / 2.f);
		}

		tabItem->EnableFocus(false);
		tabItem->EnablePointerFocus(false);
		tabItem->AddMouseListener(this);
		/*tabItem->AddKeyboardListener(this);
		tabItem->AddFocusListener(this);
		t_AddNoticeActor(tabItem);*/
		m_swapMoveAni->AddAnimatableObject(tabItem, IActor::ACTOR_ANI_POSITION);

		//add drag
		if (m_isEnableDragTab)
		{
			tabItem->AddAction(tabItem->m_dragAction);
			tabItem->AddDragListener(this);
		}

		//add checkbox
		tabItem->CheckBoxActor()->SetPosition(m_checkboxMargin, (height - m_checkboxHeight) / 2.f);
		tabItem->CheckBoxActor()->EnableFocus(false);
		tabItem->CheckBoxActor()->EnablePointerFocus(false);
		tabItem->CheckBoxActor()->SetAsyncLoading(true);
		tabItem->CheckBoxActor()->SetAutoCheckFlag(false);
		tabItem->CheckBoxActor()->SetAutoFocusFlag(false);
		m_InitTabItemCheckBox(tabItem->CheckBoxActor());
		tabItem->CheckBoxActor()->Resize(m_checkboxWidth, m_checkboxHeight);
		if (m_isShowCheckBox)
		{
			tabItem->CheckBoxActor()->Show();
		}
		else
		{
			tabItem->CheckBoxActor()->Hide();
		}

		//left and right image
		tabItem->LeftImageActor()->Resize(m_tabLeftImageWidth, m_tabLeftImageHeight);
		tabItem->LeftImageActor()->SetPosition(m_tabLeftImageMargin, (height - m_tabLeftImageHeight) / 2.f);
		if (m_tabLeftImagePath.length() > 0)
		{
			tabItem->LeftImageActor()->SetImage(m_tabLeftImagePath.c_str());
		}
		tabItem->LeftImageActor()->Hide();
		tabItem->RightImageActor()->Resize(m_tabRightImageWidth, m_tabRightImageHeight);
		tabItem->RightImageActor()->SetPosition(width - m_tabRightImageWidth - m_tabRightImageMargin, (height - m_tabRightImageHeight) / 2.f);
		if (m_tabRightImagePath.length() > 0)
		{
			tabItem->RightImageActor()->SetImage(m_tabRightImagePath.c_str());
		}
		tabItem->RightImageActor()->Hide();

		tabItem->ChangeState(STATE_UNSELECTED);
		tabItem->m_fixwidth = widthOri;
		tabItem->m_fillheight = heightFillFlag;

		if (size == 0 || index >= size)
		{
			m_tabItemVec.push_back(tabItem);
		}
		else
		{
			m_tabItemVec.insert(m_tabItemVec.begin() + index, tabItem);
			if (m_focusIndex > -1 && index <= m_focusIndex)
			{
				m_focusIndex++;
			}
			if (m_focusIndexLast > -1 && index <= m_focusIndexLast)
			{
				m_focusIndexLast++;
			}
			if (m_selectedIndex > -1 && index <= m_selectedIndex)
			{
				m_selectedIndex++;
			}
			if (m_highlightedIndex > -1 && index <= m_highlightedIndex)
			{
				m_highlightedIndex++;
			}
		}
		tabItem->Show();

		if (m_tabItemVec.size() == 1)
		{
			m_AddSpliter(2);
		}
		else
		{
			m_AddSpliter(1);
		}

		//m_ReplaceTabArea(true);
		m_ReplaceSubTab(index);
		m_ReplaceSpliters();
		m_ReplaceHighlightBar(m_focusIndex);
		m_RefreshArrows();
		m_ResetTabItemsState();
		return true;
	}

	void CCategoryTab::m_AddSpliter(int number)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_AddSpliter, [" << number << "]");
		for (int i = 0; i < number; i++)
		{
			//add spliter
			ICompositeImage *tabSpliter = ICompositeImage::CreateInstance(m_tabAreaActor, m_tabSpliterWidth, m_tabSpliterHeight);
			tabSpliter->SetBackgroundColor(m_tabspliterColor);
			m_tabSpliterVec.push_back(tabSpliter);
		}
	}

	void CCategoryTab::SetSpliterColor(const ClutterColor &color)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::SetSpliterColor.");
		m_tabspliterColor = color;
		for (int i = 0; i < (int)m_tabSpliterVec.size(); i++)
		{
			m_tabSpliterVec[i]->SetBackgroundColor(m_tabspliterColor);
		}
	}

	void CCategoryTab::m_ShowSpliter(int index, bool show)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_ShowSpliter [ " << index << " ].");
		if (index < 0)
		{
			return;
		}

		if (show)
		{
			if (index > 0)
			{
				//left
				m_tabSpliterVec[index]->Show();
			}
			if (index < ((int)m_tabItemVec.size() - 1))
			{
				//right
				m_tabSpliterVec[index + 1]->Show();
			}
		}
		else
		{
			if (index < (int)m_tabItemVec.size())
			{
				m_tabSpliterVec[index]->Hide();
			}
			if (index + 1 < (int)m_tabItemVec.size())
			{
				m_tabSpliterVec[index + 1]->Hide();
			}
		}
	}

	bool CCategoryTab::RemoveTab(int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::RemoveTab, [" << index << "]");
		HALO_EXCEPTION(index >= 0 && index < (int)m_tabItemVec.size(), "Index out of range.");

		gfloat removeWidth = 0, removeHeight = 0;
		m_tabItemVec[index]->GetSize(removeWidth, removeHeight);
		m_tabItemVec[index]->RemoveMouseListener(this);
		if (m_isEnableDragTab)
		{
			m_tabItemVec[index]->RemoveAction(m_tabItemVec[index]->m_dragAction);
			m_tabItemVec[index]->RemoveDragListener(this);
		}
		IUtility::GetInstance()->AsyncRelease(m_tabItemVec[index]);
		//IUtility::GetInstance()->AsyncRelease(dynamic_cast<CCategoryTabItem*>(m_tabItemVec[index]));
		//m_tabItemVec[index]->Release();
		m_tabItemVec.erase(m_tabItemVec.begin() + index);
		m_tabSpliterVec[index + 1]->Release();
		m_tabSpliterVec.erase(m_tabSpliterVec.begin() + index + 1);
		//m_MoveTabItems(index, -(remove_width + m_tabSpliterWidth));
		if ((int)m_tabItemVec.size() == 0)
		{
			m_tabSpliterVec[0]->Release();
			m_tabSpliterVec.erase(m_tabSpliterVec.begin() + 0);
		}

		if (m_focusIndex == index)
		{
			m_focusIndex = -1;
			m_focusIndexLast = -1;
		}
		else if (index < m_focusIndex)
		{
			m_focusIndex--;
			if (m_focusIndexLast > -1 && index <= m_focusIndexLast)
			{
				m_focusIndexLast--;
			}
		}
		if (m_selectedIndex == index)
		{
			m_selectedIndex = -1;
		}
		else if (index < m_selectedIndex)
		{
			m_selectedIndex--;
		}
		if (m_highlightedIndex == index)
		{
			m_highlightedIndex = -1;
		}
		else if (index < m_highlightedIndex)
		{
			m_highlightedIndex--;
		}
		if (index > 0)
		{
			m_ReplaceSubTab(index - 1);
		}
		else
		{
			m_ReplaceSubTab(0);
		}

		/*m_focusIndexLast = -1;
		if (m_focusIndex == index)
		{
		if ((int)m_tabItemVec.size() > 0)
		{
		m_focusIndex = 0;
		m_GetFocusOn(m_focusIndex);
		}
		else
		{
		m_focusIndex = -1;
		}
		}
		else
		{
		if (m_focusIndex >= index)
		{
		m_focusIndex--;
		}
		}
		m_focusIndex = -1;*/
		m_ReplaceSpliters();
		m_RefreshArrows();
		m_ReplaceHighlightBar(m_focusIndex);

		return true;
	}

	//Tab Changed Call Back:
	void CCategoryTab::m_TabChangedListenerCallBack(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_TabChangedListenerCallBack");
		// call back listeners
		for (std::set<ICategoryTabListener *>::iterator iter = m_categoryTabListenerSet.begin(); iter != m_categoryTabListenerSet.end(); ++iter)
		{
			HALO_ASSERT(*iter != NULL);
			(*iter)->OnTabChanged(this, m_focusIndex);//could send m_focusIndexLast 
		}
	}
	void CCategoryTab::m_TabClickedListenerCallBack(int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_TabClickedListenerCallBack");
		// call back listeners
		for (std::set<ICategoryTabListener *>::iterator iter = m_categoryTabListenerSet.begin(); iter != m_categoryTabListenerSet.end(); ++iter)
		{
			HALO_ASSERT(*iter != NULL);
			(*iter)->OnTabClicked(this, index);
		}
	}
	void CCategoryTab::m_TabMouseInListenerCallBack(int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_TabMouseInListenerCallBack");
		// call back listeners
		for (std::set<ICategoryTabListener *>::iterator iter = m_categoryTabListenerSet.begin(); iter != m_categoryTabListenerSet.end(); ++iter)
		{
			HALO_ASSERT(*iter != NULL);
			(*iter)->OnTabMouseIn(this, index);
		}
	}
	void CCategoryTab::m_TabMouseOutListenerCallBack(int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_TabMouseOutListenerCallBack");
		// call back listeners
		for (std::set<ICategoryTabListener *>::iterator iter = m_categoryTabListenerSet.begin(); iter != m_categoryTabListenerSet.end(); ++iter)
		{
			HALO_ASSERT(*iter != NULL);
			(*iter)->OnTabMouseOut(this, index);
		}
	}
	void CCategoryTab::m_TabArrowsClickedListenerCallBack(int index)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_TabArrowsClickedListenerCallBack");
		// call back listeners
		for (std::set<ICategoryTabListener *>::iterator iter = m_categoryTabListenerSet.begin(); iter != m_categoryTabListenerSet.end(); ++iter)
		{
			HALO_ASSERT(*iter != NULL);
			if (index == 0)
			{
				(*iter)->OnLeftArrowsClicked(this);
			}
			else if (index == 1)
			{
				(*iter)->OnRightArrowsClicked(this);
			}
		}
	}

	bool CCategoryTab::AddCategoryTabListener(ICategoryTabListener* listener)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::AddCategoryTabListener");
		HALO_ASSERT(listener != NULL);
		m_categoryTabListenerSet.insert(listener);
		return true;
	}

	bool CCategoryTab::RemoveCategoryTabListener(ICategoryTabListener* listener)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::RemoveCategoryTabListener");
		HALO_ASSERT(listener != NULL);
		m_categoryTabListenerSet.erase(listener);
		return true;
	}

	bool CCategoryTab::OnMouseMoved(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::OnMouseMoved");
		//if (m_isResizeHighlightAni && m_highlightbarExpand)
		//{
		//	int index = -1;
		//	for (int i = 0; i < (int)m_tabItemVec.size(); i++)
		//	{
		//		if (m_tabItemVec[i] == pWindow)
		//		{
		//			index = i;
		//			break;
		//		}
		//	}
		//	if (index > -1)
		//	{
		//		//m_TabMouseInListenerCallBack(index);
		//		if (index != m_focusIndex)
		//		{
		//			m_StopHighlightbarResize();
		//			m_LocationSubTab(index);
		//			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
		//			{
		//				m_ChangeButtonState(i, STATE_UNSELECTED);
		//				m_ShowSpliter(i, true);
		//			}
		//			m_ReplaceHighlightBar(index, false);
		//			float barWidth = 0, barHeight = 0;
		//			m_highlightBar->GetSize(barWidth, barHeight);
		//			m_highlightBar->Resize(barWidth, m_highlightbarUnfocusHeight);
		//			m_ShowSpliter(index, false);
		//			m_ChangeButtonState(index, STATE_HIGHLIGHTED);
		//			m_mouseinIndex = index;
		//			m_ExpandHighlightBar(true);
		//		}
		//	}
		//}
		//else 
		if (m_isDragMove <= 0)
		{
			OnMousePointerIn(pWindow, ptrMouseEvent);
		}
		return true;
	}

	bool CCategoryTab::OnMousePointerIn(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::OnMousePointerIn");
		if (m_isSwapMoveAni || m_isResizeHighlightAni || !m_isEnableChangeTab)
		{
			return true;
		}
		int index = -1;
		for (int i = 0; i < (int)m_tabItemVec.size(); i++)
		{
			if (m_tabItemVec[i] == pWindow)
			{
				index = i;
				break;
			}
		}
		if (index > -1)
		{
			if (index != m_mouseinIndex)
			{
				m_LocationSubTab(index);
				for (int i = 0; i < (int)m_tabItemVec.size(); i++)
				{
					m_ChangeTabItemState(i, STATE_UNSELECTED);
				}
				if (m_focusIndex > -1 && IsFocused())
				{
					m_ReplaceHighlightBar(index, true);
				}
				else
				{
					m_ReplaceHighlightBar(index, false);
				}
				if (IsFocused())
				{
					m_ChangeTabItemState(index, STATE_HIGHLIGHTED);
				}
				else
				{
					m_ChangeTabItemState(index, STATE_SELECTED);
				}
				m_mouseinIndex = index;
				m_TabMouseInListenerCallBack(index);
			}
		}
		return true;
	}

	bool CCategoryTab::OnMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::OnMousePointerOut");
		if (m_isSwapMoveAni || m_isResizeHighlightAni)
		{
			return true;
		}

		if (pWindow == this)
		{
			float pointerY = ptrMouseEvent->GetY();
			Widget *categoryTabControl = dynamic_cast<Widget*>(this);
			HALO_ASSERT(NULL != categoryTabControl);
			Vector3 cPos = categoryTabControl->getAbsolutePosition();
			if (pointerY <= cPos.y || pointerY >= cPos.y + getHeight())
			{
				m_StopHighlightbarMove();
				if (m_focusIndex > -1)
				{
					m_LocationSubTab(m_focusIndex);
				}
				//mouse out parent
				if (m_mouseinIndex > -1)
				{
					if (m_focusIndex > -1 && m_mouseinIndex != m_focusIndex)
					{
						if (IsFocused())
						{
							m_ChangeTabItemState(m_focusIndex, STATE_HIGHLIGHTED);
							m_ChangeTabItemState(m_mouseinIndex, STATE_UNSELECTED);
							m_ReplaceHighlightBar(m_focusIndex, false);
						}
						else
						{
							m_ChangeTabItemState(m_focusIndex, STATE_SELECTED);
							m_ChangeTabItemState(m_mouseinIndex, STATE_UNSELECTED);
							m_ReplaceHighlightBar(m_focusIndex, false);
						}
					}
					else if (m_focusIndex < 0)
					{
						m_ChangeTabItemState(m_mouseinIndex, STATE_UNSELECTED);
						m_highlightBar->Hide();
					}
				}
				m_mouseinIndex = -1;
			}
		}
		else
		{
			//int index = -1;
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{
				if (m_tabItemVec[i] == pWindow)
				{
					//index = i;
					m_TabMouseOutListenerCallBack(i);
					break;
				}
			}
			/*if (index > -1 && index != m_focusIndex && m_isEnableChangeTab)
			{
			m_mouseinIndex = -1;
			m_ShowSpliter(index, true);
			m_ShowSpliter(m_focusIndex, false);
			}*/
		}

		return true;
	}

	void CCategoryTab::m_ResizeBackground(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_ResizeBackground.");
		float width = 0, height = 0;
		this->GetSize(width, height);
		m_background->Resize(width, height);
	}

	void CCategoryTab::m_ResizeArrows(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_ResizeArrows");
		float tabWidth = 0, tabHeight = 0;
		this->GetSize(tabWidth, tabHeight);

		float leftWidth = 0, leftHeight = 0;
		m_leftArrows->GetSize(leftWidth, leftHeight);

		float rightWidth = 0, rightHeight = 0;
		m_rightArrows->GetSize(rightWidth, rightHeight);

		if (leftHeight > (tabHeight - m_marginTop - m_marginBottom))
		{
			leftHeight = tabHeight - m_marginTop - m_marginBottom;
		}
		m_leftArrows->Resize(leftWidth, leftHeight);

		if (rightHeight > (tabHeight - m_marginTop - m_marginBottom))
		{
			rightHeight = tabHeight - m_marginTop - m_marginBottom;
		}
		m_rightArrows->Resize(rightWidth, rightHeight);
	}

	void CCategoryTab::m_ReplaceArrows(void)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_ReplaceArrows");
		float tabWidth = 0, tabHeight = 0;
		this->GetSize(tabWidth, tabHeight);
		float leftWidth = 0, leftHeight = 0;
		m_leftArrows->GetSize(leftWidth, leftHeight);
		float tabarea_width = 0, tabarea_height = 0;
		m_tabAreaActor->GetSize(tabarea_width, tabarea_height);
		float rightWidth = 0, rightHeight = 0;
		m_rightArrows->GetSize(rightWidth, rightHeight);

		m_leftArrows->SetPosition(m_marginLeft, (tabHeight - leftHeight) / 2);
		m_rightArrows->SetPosition(m_marginLeft + leftWidth + tabarea_width, (tabHeight - rightHeight) / 2);
	}

	void CCategoryTab::m_ResizeTabArea(bool sub)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_ResizeTabArea");
		float tabWidth = 0, tabHeight = 0;
		this->GetSize(tabWidth, tabHeight);
		float leftWidth = 0, leftHeight = 0;
		m_leftArrows->GetSize(leftWidth, leftHeight);
		float rightWidth = 0, rightHeight = 0;
		m_rightArrows->GetSize(rightWidth, rightHeight);

		//Resize tab_area
		float tabareaWidth = 0, tabareaHeight = 0;
		tabareaWidth = tabWidth - leftWidth - rightWidth - m_marginLeft - m_marginRight;
		if (tabareaWidth < 0)
		{
			tabareaWidth = 0;
		}
		tabareaHeight = tabHeight - m_marginTop - m_marginBottom;
		if (tabareaHeight < 0)
		{
			tabareaHeight = 0;
		}

		m_tabAreaActor->Resize(tabareaWidth, tabareaHeight);
		m_tabAreaActor->SetClipArea(0, 0 - 1500, tabareaWidth, tabareaHeight + 3000);

		if (sub)
		{
			//Resize all sub-tabs
			float textWidth = 0, textHeight = 0;
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{
				IText *tabText = m_tabItemVec[i]->TextActor();
				if (m_tabItemVec[i]->m_fixwidth < 0)
				{
					int fontsize = m_GetTabMaxFontSize();
					textWidth = m_CalTextWidth(m_tabItemVec[i]->m_stateData[STATE_UNSELECTED].textContent.c_str(), m_textFont, fontsize);
				}
				else
				{
					textWidth = m_tabItemVec[i]->m_fixwidth;
				}
				if (textWidth > m_tabTextlimitWidth)
				{
					textWidth = m_tabTextlimitWidth;
				}
				textWidth += (m_tabLeftMargin + m_tabRightMargin);

				if (m_tabItemVec[i]->m_fillheight == true)
				{
					//fill tab area
					textHeight = tabareaHeight;
					m_tabItemVec[i]->Resize(textWidth, textHeight);
				}
				else
				{
					float tabitemWidth = 0, tabitemHeight = 0;
					m_tabItemVec[i]->GetSize(tabitemWidth, tabitemHeight);
					textHeight = tabitemHeight;
					m_tabItemVec[i]->Resize(textWidth, textHeight);
					float tabItemX = 0, tabItemY = 0;
					m_tabItemVec[i]->GetPosition(tabItemX, tabItemY);
					//place to bottom
					m_tabItemVec[i]->SetPosition(tabItemX, tabareaHeight - tabitemHeight);
				}
				//Resize text area in button
				tabText->Resize(textWidth - (m_tabLeftMargin + m_tabRightMargin), textHeight);
				tabText->SetPosition(m_tabLeftMargin, 0);
				//Resize icon in button
				if (m_tabItemVec[i]->IconActor() != NULL)
				{
					float iconwidth = 0, iconheight = 0;
					m_tabItemVec[i]->IconActor()->GetSize(iconwidth, iconheight);
					m_tabItemVec[i]->IconActor()->SetPosition(m_tabIconMargin, (textHeight - iconheight) / 2.f);
				}
				//Resize checkbox in button
				if (m_tabItemVec[i]->CheckBoxActor() != NULL)
				{
					m_tabItemVec[i]->CheckBoxActor()->Resize(m_checkboxWidth, m_checkboxHeight);
					m_tabItemVec[i]->CheckBoxActor()->SetPosition(m_checkboxMargin, (textHeight - m_checkboxHeight) / 2.f);
				}
				//Resize left and right image in button
				if (m_tabItemVec[i]->LeftImageActor() != NULL)
				{
					m_tabItemVec[i]->LeftImageActor()->Resize(m_tabLeftImageWidth, m_tabLeftImageHeight);
					m_tabItemVec[i]->LeftImageActor()->SetPosition(m_tabLeftImageMargin, (textHeight - m_tabLeftImageHeight) / 2.f);
				}
				if (m_tabItemVec[i]->RightImageActor() != NULL)
				{
					m_tabItemVec[i]->RightImageActor()->Resize(m_tabRightImageWidth, m_tabRightImageHeight);
					m_tabItemVec[i]->RightImageActor()->SetPosition(textWidth - m_tabRightImageWidth - m_tabRightImageMargin, (textHeight - m_tabRightImageHeight) / 2.f);
				}
			}
		}
	}

	void CCategoryTab::m_ReplaceTabArea(bool sub)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_ReplaceTabArea");
		float leftWidth = 0, leftHeight = 0;
		m_leftArrows->GetSize(leftWidth, leftHeight);

		//Replace tab area
		m_tabAreaActor->SetPosition(m_marginLeft + leftWidth, m_marginTop);

		if (sub)
		{
			m_ReplaceSubTab(0);
		}
	}

	void CCategoryTab::m_ResizeHighlightBar(float width, float height, bool easing, float expectYPostion)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_ResizeHighlightBar [ " << width << " , " << height << " ].");
		float tabareaWidth = 0, tabareaHeight = 0;
		m_tabAreaActor->GetSize(tabareaWidth, tabareaHeight);
		float highX = 0, highY = 0;
		m_highlightBar->GetPosition(highX, highY);

		m_StopHighlightbarResize();
		if (easing)
		{
			m_StartHighlightbarResize(width, height);
		}
		else
		{
			if (m_isHighlightbarBottom)
			{
				m_highlightBar->SetPosition(highX, tabareaHeight - height);
			}
			else
			{
				m_highlightBar->SetPosition(highX, 0);
			}
			m_highlightBar->Resize(width, height);
		}
	}

	void CCategoryTab::m_ReplaceHighlightBar(int index, bool easing)
	{
		H_LOG_TRACE(LOGGER, "CCategoryTab::m_ReplaceHighlightBar [ " << index << " ].");
		if (index < 0 || index >= (int)m_tabItemVec.size() || m_tabItemVec[index] == NULL)
		{
			m_highlightBar->Hide();
			return;
		}
		//highlight bar move:
		float x = 0, y = 0;
		m_tabItemVec[index]->GetPosition(x, y);
		float tabitemWidth = 0, tabitemHeight = 0;
		m_tabItemVec[index]->GetSize(tabitemWidth, tabitemHeight);
		float barWidth = 0, barHeight = 0;
		m_highlightBar->GetSize(barWidth, barHeight);
		float leftWidth = 0, leftHeight = 0;
		m_leftArrows->GetSize(leftWidth, leftHeight);
		float tabareaWidth = 0, tabareaHeight = 0;
		m_tabAreaActor->GetSize(tabareaWidth, tabareaHeight);

		if (x < 0)
		{
			//last one
			m_highlightBar->Resize(tabitemWidth + x + m_tabSpliterWidth * 2, barHeight);
		}
		else if (x + tabitemWidth > tabareaWidth)
		{
			m_highlightBar->Resize(tabareaWidth - x + m_tabSpliterWidth * 2, barHeight);
		}
		else
		{
			m_highlightBar->Resize(tabitemWidth + m_tabSpliterWidth * 2, barHeight);
		}

		float bx = 0, by = 0;
		bx = leftWidth + m_marginLeft + x - m_tabSpliterWidth;
		if (m_isHighlightbarBottom)
		{
			by = tabitemHeight - barHeight + m_marginTop;
		}

		if (bx < 0)
		{
			bx = 0;
		}

		m_StopHighlightbarMove();
		if (m_isEnableHighlightbar)
		{
			if (easing)
			{
				m_StartHighlightbarMove(bx, by);
			}
			else
			{
				m_highlightBar->SetPosition(bx, by);
				m_highlightBar->Show();
			}
		}
		else
		{
			m_highlightBar->SetPosition(bx, by);
			m_highlightBar->Hide();
		}
	}
}

void CCategoryTab::m_ResizeSpliters(float width, float height)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_ResizeSpliters [ " << width << " , " << height << " ].");
	m_tabSpliterWidth = width;
	m_tabSpliterHeight = height;

	for (int i = 0; i < (int)m_tabSpliterVec.size(); i++)
	{
		m_tabSpliterVec[i]->Resize(m_tabSpliterWidth, m_tabSpliterHeight);
	}
	m_ResizeTabArea(true);
}

void CCategoryTab::m_ReplaceSpliters(void)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_ReplaceSpliters.");
	gfloat x, y;
	if (m_tabItemVec.size() > 0)
	{
		x = 0;
		float tabareaWidth = 0, tabareaHeight = 0;
		m_tabAreaActor->GetSize(tabareaWidth, tabareaHeight);

		if (m_isReverse && m_useSelfReverse)
		{
			gfloat lastX = 0, lastY = 0;
			gfloat lastW = 0, lastH = 0;
			m_tabItemVec[0]->GetPosition(lastX, lastY);
			m_tabItemVec[0]->GetSize(lastW, lastH);
			x = lastX + lastW;
			float fsWidth = 0, fsHeight = 0;
			m_tabSpliterVec[0]->GetSize(fsWidth, fsHeight);
			y = (tabareaHeight - fsHeight) / 2;
			m_tabSpliterVec[0]->SetPosition(x, y);
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{
				m_tabItemVec[i]->GetPosition(lastX, lastY);
				m_tabItemVec[i]->GetSize(lastW, lastH);
				x = lastX - m_tabSpliterWidth;
				//left splter
				float sWidth = 0, sHeight = 0;
				m_tabSpliterVec[i + 1]->GetSize(sWidth, sHeight);
				y = (tabareaHeight - sHeight) / 2;
				m_tabSpliterVec[i + 1]->SetPosition(x, y);
			}
		}
		else
		{
			gfloat lastX = 0, lastY = 0;
			gfloat lastWidth = 0, lastHeight = 0;
			m_tabItemVec[0]->GetPosition(lastX, lastY);
			float fsWidth = 0, fsHeight = 0;
			m_tabSpliterVec[0]->GetSize(fsWidth, fsHeight);
			y = (tabareaHeight - fsHeight) / 2;
			m_tabSpliterVec[0]->SetPosition(lastX - m_tabSpliterWidth, y);
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{//spliter put center

				m_tabItemVec[i]->GetPosition(lastX, lastY);
				m_tabItemVec[i]->GetSize(lastWidth, lastHeight);
				x = lastX + lastWidth;
				float sWidth = 0, sHeight = 0;
				m_tabSpliterVec[i + 1]->GetSize(sWidth, sHeight);
				y = (tabareaHeight - sHeight) / 2;
				m_tabSpliterVec[i + 1]->SetPosition(x, y);
			}
		}
	}

	if (m_tabSpliterVec.size() > 1)
	{
		//Hide first and last spliter
		m_tabSpliterVec[0]->Hide();
		m_tabSpliterVec[m_tabSpliterVec.size() - 1]->Hide();
	}
}

void CCategoryTab::m_ResizeCategoryTab(void)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_ResizeCategoryTab.");
	float tabWidth = 0, tabHeight = 0;
	this->GetSize(tabWidth, tabHeight);
	if (tabWidth == m_lastWidth && tabHeight == m_lastHeight)
	{
		//g_print("Resize, return\n");
		return;
	}

	m_ResizeBackground();
	if (tabHeight == m_tabTargetHeightMin || tabHeight == m_tabTargetHeightMax)
	{
		//g_print("Resize, target height %f, %f/%f\n", tabHeight, m_tabTargetHeightMin, m_tabTargetHeightMax);
		m_ReplaceArrows();
		m_ResizeTabArea(true);
		m_ReplaceTabArea(false);
		m_ReplaceSpliters();
		if (tabHeight == m_tabTargetHeightMax)
		{
			m_StartTextScroll(m_highlightedIndex);
		}
	}
	else
	{
		//g_print("Resize, during animation\n");
		float x = 0, y = 0;
		m_tabAreaActor->GetPosition(x, y);
		m_tabAreaActor->SetPosition(x, y + (tabHeight - m_lastHeight) / 2);
		m_leftArrows->GetPosition(x, y);
		m_leftArrows->SetPosition(x, y + (tabHeight - m_lastHeight) / 2);
		m_rightArrows->GetPosition(x, y);
		m_rightArrows->SetPosition(x, y + (tabHeight - m_lastHeight) / 2);
	}
	//m_ReplaceHighlightBar(m_focusIndex);
	//m_KeepHighlightBarBottom();

	//Update date
	m_lastWidth = tabWidth;
	m_lastHeight = tabHeight;
}

void CCategoryTab::m_EnableReverse(bool enable)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_EnableReverse.");
	if (enable == m_isReverse)
	{
		return;
	}
	m_isReverse = enable;
	//float focusX = 0, focusY = 0;
	//if (m_focusIndex > -1)
	//{
	//	m_tabItemVec[m_focusIndex]->GetPosition(focusX, focusY);
	//}
	//m_ReplaceTabArea(true);

	//if (m_focusIndex > -1)
	//{
	//	float tabareaWidth = 0, tabareaHeight = 0;
	//	m_tabAreaActor->GetSize(tabareaWidth, tabareaHeight);
	//	float itemX = 0, itemY = 0, itemWidth = 0, itemHeight = 0;
	//	m_tabItemVec[m_focusIndex]->GetPosition(itemX, itemY);
	//	m_tabItemVec[m_focusIndex]->GetSize(itemWidth, itemHeight);
	//	if (m_enableReverse)
	//	{
	//		//change to reverse
	//		float offset = (tabareaWidth - itemX - itemWidth) - focusX;
	//		m_MoveTabItems(0, offset);
	//	}
	//	else
	//	{
	//		//chage to not reverse
	//		float offset = tabareaWidth - focusX - itemWidth - itemX;
	//		m_MoveTabItems(0, offset);
	//	}
	//}

	//m_ReplaceSpliters();
	//m_ReplaceHighlightBar(m_focusIndex);
	//m_RefreshArrows();
	if (m_leftArrows->FlagShow() && !m_rightArrows->FlagShow())
	{
		m_leftArrows->Hide();
		m_rightArrows->Show();
	}
	else if (!m_leftArrows->FlagShow() && m_rightArrows->FlagShow())
	{
		m_leftArrows->Show();
		m_rightArrows->Hide();
	}
}

void CCategoryTab::t_UpdateOrientation(EOrientation orientation)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::t_UpdateOrientation.");
	if (orientation == ORIENTATION_RIGHT_TO_LEFT)
	{
		m_EnableReverse(true);
	}
	else
	{
		m_EnableReverse(false);
	}
	CActor::t_UpdateOrientation(orientation);

	//m_ReplaceSpliters();
	//m_ReplaceHighlightBar(m_focusIndex);
	//m_RefreshArrows();
}

float CCategoryTab::TabIconMargin(void) const
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::TabIconMargin.");
	return m_tabIconMargin;
}

void CCategoryTab::SetTabIconMargin(float margin)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabIconMargin.");
	m_tabIconMargin = margin;
	m_ResizeTabArea(true);
}

void CCategoryTab::SetTabIconSize(float width, float height, int index)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabIconSize.");
	if (index < 0)
	{
		m_tabIconDefaultWidth = width;
		m_tabIconDefaultHeight = height;
		for (int i = 0; i < (int)m_tabItemVec.size(); i++)
		{
			gfloat itemWidth = 0, itemHeight = 0;
			m_tabItemVec[i]->GetSize(itemWidth, itemHeight);
			m_tabItemVec[i]->IconActor()->Resize(width, height);
			m_tabItemVec[i]->IconActor()->SetPosition(m_tabIconMargin, (itemHeight - height) / 2.f);
		}
		m_ResizeTabArea(true);
	}
	else if (index >= 0 && index < (int)m_tabItemVec.size())
	{
		if (m_tabItemVec[index]->IconActor() != NULL)
		{
			gfloat itemWidth = 0, itemHeight = 0;
			m_tabItemVec[index]->GetSize(itemWidth, itemHeight);
			m_tabItemVec[index]->IconActor()->Resize(width, height);
			m_tabItemVec[index]->IconActor()->SetPosition(m_tabIconMargin, (itemHeight - height) / 2.f);
		}
	}
}

void CCategoryTab::ShowTabIcon(int index)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::ShowTabIcon." << index);
	if (index < 0)
	{
		for (int i = 0; i < (int)m_tabItemVec.size(); i++)
		{
			if (m_tabItemVec[i]->IconActor() != NULL)
			{
				m_tabItemVec[i]->IconActor()->Show();
			}
		}
	}
	else if (index < (int)m_tabItemVec.size())
	{
		if (m_tabItemVec[index]->IconActor() != NULL)
		{
			m_tabItemVec[index]->IconActor()->Show();
		}
	}
}

void CCategoryTab::HideTabIcon(int index)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::HideTabIcon " << index << " .");
	if (index < 0)
	{
		for (int i = 0; i < (int)m_tabItemVec.size(); i++)
		{
			if (m_tabItemVec[i]->IconActor() != NULL)
			{
				m_tabItemVec[i]->IconActor()->Hide();
			}
		}
	}
	else if (index < (int)m_tabItemVec.size())
	{
		if (m_tabItemVec[index]->IconActor() != NULL)
		{
			m_tabItemVec[index]->IconActor()->Hide();
		}
	}
}

bool CCategoryTab::FlagTabIconShow(int index) const
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::FlagTabIconShow " << index << " .");
	bool flag = false;
	if (index >= 0 && index < (int)m_tabItemVec.size())
	{
		if (m_tabItemVec[index]->IconActor() != NULL)
		{
			if (m_tabItemVec[index]->IconActor()->FlagShow())
			{
				flag = true;
			}
		}
	}
	return flag;
}

void CCategoryTab::SetTabIconImage(ECategoryTabState state, const std::string& image, int alpha, int index)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabIconImage " << image << " , " << alpha << " , " << index << " . " << state);
	if (index < 0)
	{
		switch (state)
		{
		case STATE_UNSELECTED:
		case STATE_SELECTED:
		case STATE_HIGHLIGHTED:
			m_defaultTabIconImage[state] = image;
			m_defaultTabIconAlpha[state] = alpha;
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{
				m_tabItemVec[i]->m_stateData[state].iconPath = image;
				m_tabItemVec[i]->m_stateData[state].iconAlpha = alpha;
			}
			break;
		case STATE_ALL:
			for (int i = 0; i < STATE_ALL; i++)
			{
				m_defaultTabIconImage[i] = image;
				m_defaultTabIconAlpha[i] = alpha;
			}
			for (int i = 0; i < (int)m_tabItemVec.size(); i++)
			{
				for (int j = 0; j < STATE_ALL; j++)
				{
					m_tabItemVec[i]->m_stateData[j].iconPath = image;
					m_tabItemVec[i]->m_stateData[j].iconAlpha = alpha;
				}
			}
			break;
		default:
			break;
		}
	}
	else if (index>0 && index < (int)m_tabItemVec.size())
	{
		switch (state)
		{
		case STATE_UNSELECTED:
		case STATE_SELECTED:
		case STATE_HIGHLIGHTED:
			m_tabItemVec[index]->m_stateData[state].iconPath = image;
			m_tabItemVec[index]->m_stateData[state].iconAlpha = alpha;
			break;
		case STATE_ALL:
			for (int j = 0; j < STATE_ALL; j++)
			{
				m_tabItemVec[index]->m_stateData[j].iconPath = image;
				m_tabItemVec[index]->m_stateData[j].iconAlpha = alpha;
			}
			break;
		default:
			break;
		}
	}
	m_ResetTabItemsState();
}

void CCategoryTab::SetTabText(ECategoryTabState state, const char* text, int index)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabText " << index << " .");
	HALO_ASSERT(NULL != text);
	if (index >= 0 && index < (int)m_tabItemVec.size())
	{
		switch (state)
		{
		case STATE_UNSELECTED:
			m_tabItemVec[index]->m_stateData[STATE_UNSELECTED].textContent = text;
			if (m_tabItemVec[index]->m_fixwidth < 0)
			{
				m_ResizeTabArea(true);
				m_ReplaceTabArea(true);
				m_ReplaceSpliters();
			}
			break;
		case STATE_SELECTED:
			m_tabItemVec[index]->m_stateData[STATE_SELECTED].textContent = text;
			break;
		case STATE_HIGHLIGHTED:
			m_tabItemVec[index]->m_stateData[STATE_HIGHLIGHTED].textContent = text;
			break;
		case STATE_ALL:
			for (int i = 0; i < STATE_ALL; i++)
			{
				m_tabItemVec[index]->m_stateData[i].textContent = text;
			}
			break;
		default:
			break;
		}
	}
}

void CCategoryTab::EnableChangeTab(bool enable)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::EnableChangeTab.");
	if (enable == m_isEnableChangeTab)
	{
		return;
	}
	EnableFocus(enable);
	m_isEnableChangeTab = enable;
	for (int i = 0; i < (int)m_tabItemVec.size(); i++)
	{
		m_tabItemVec[i]->EnableFocus(enable);
		m_tabItemVec[i]->Enable(enable);
	}
	if (enable)
	{
		if (IsFocused())
		{
			m_StartTextScroll(m_focusIndex);
		}		
	}
	else
	{
		m_StopTextScroll(m_focusIndexLast);
	}
}

bool CCategoryTab::IsChangeTabEnabled(void) const
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::IsChangeTabEnabled.");
	return m_isEnableChangeTab;
}

void CCategoryTab::ShowFocus(void)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::ShowFocus.");
	EnableChangeTab(true);
	if (m_isEnableHighlightbar)
	{
		m_highlightBar->Show();
	}
}

void CCategoryTab::HideFocus(void)
{
	EnableChangeTab(false);
	m_highlightBar->Hide();
}

void CCategoryTab::m_ReplaceSubTab(int fromIndex)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_ReplaceSubTab.");
	if (fromIndex < 0 || fromIndex >= (int)m_tabItemVec.size())
	{
		return;
	}

	//Replace sub-tabs
	if (m_tabItemVec.size() > 0)
	{
		float tabareaWidth = 0, tabareaHeight = 0;
		m_tabAreaActor->GetSize(tabareaWidth, tabareaHeight);
		//from left to right
		float x = m_tabSpliterWidth, y = 0;
		float tabitemWidth = 0, tabitemHeight = 0;
		if (fromIndex > 0)
		{
			m_tabItemVec[0]->GetPosition(x, y);
			if (x > m_tabSpliterWidth)
			{
				fromIndex = 0;
				x = m_tabSpliterWidth;
				y = 0;
			}
			else
			{
				m_tabItemVec[fromIndex - 1]->GetPosition(x, y);
				m_tabItemVec[fromIndex - 1]->GetSize(tabitemWidth, tabitemHeight);
				x += tabitemWidth + m_tabSpliterWidth;
			}
		}

		if (m_isReverse && m_useSelfReverse)
		{
			//reverse
			for (int i = (int)m_tabItemVec.size() - 1; i >= fromIndex; i--)
			{
				m_tabItemVec[i]->GetSize(tabitemWidth, tabitemHeight);
				//place to bottom
				m_tabItemVec[i]->SetPosition(x, tabareaHeight - tabitemHeight);
				x += tabitemWidth + m_tabSpliterWidth;
			}
			if (m_tabsAlignCenter && x < tabareaWidth)
			{
				//align tabs center if width of tabs less than width of tab_area.
				m_MoveTabItems(0, (tabareaWidth - x) / 2.f);
			}
			else
			{
				//move to right
				m_MoveTabItems(0, tabareaWidth - x);
			}
		}
		else
		{
			//not reverse
			for (int i = fromIndex; i < (int)m_tabItemVec.size(); i++)
			{
				m_tabItemVec[i]->GetSize(tabitemWidth, tabitemHeight);
				//place to bottom
				m_tabItemVec[i]->SetPosition(x, tabareaHeight - tabitemHeight);
				x += tabitemWidth + m_tabSpliterWidth;
			}

			if (m_tabsAlignCenter)
			{
				//align tabs center if width of tabs less than width of tab_area.
				if (x < tabareaWidth)
				{
					m_MoveTabItems(0, (tabareaWidth - x) / 2.f);
				}
			}
		}
	}
}

void CCategoryTab::m_ChangeTabItemState(int index, ECategoryTabState state)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_ChangeTabItemState.");
	switch (state)
	{
	case STATE_UNSELECTED:
		m_tabItemVec[index]->ChangeState(state);
		if (m_tabItemVec[index]->CheckBoxActor()->FlagShow())
		{
			m_tabItemVec[index]->CheckBoxActor()->SetFocusState(false);
		}
		if (m_selectedIndex == index)
		{
			m_selectedIndex = -1;
		}
		if (m_highlightedIndex == index)
		{
			m_highlightedIndex = -1;
		}
		m_ShowSpliter(index, true);
		m_StopTextScroll(index);
		break;
	case STATE_SELECTED:
		m_tabItemVec[index]->ChangeState(state);
		if (m_tabItemVec[index]->CheckBoxActor()->FlagShow())
		{
			m_tabItemVec[index]->CheckBoxActor()->SetFocusState(false);
		}
		m_selectedIndex = index;
		m_ShowSpliter(index, true);
		m_StopTextScroll(index);
		break;
	case STATE_HIGHLIGHTED:
		m_tabItemVec[index]->ChangeState(state);
		if (m_tabItemVec[index]->CheckBoxActor()->FlagShow())
		{
			m_tabItemVec[index]->CheckBoxActor()->SetFocusState(true);
		}
		m_highlightedIndex = index;
		m_ShowSpliter(index, false);
		m_StartTextScroll(index);
		break;
	case STATE_ALL:
		break;
	}
}

void CCategoryTab::m_ExpandHighlightBar(bool easing)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_ExpandHighlightBar.");
	if (m_isEnableHighlightbar && !m_highlightBar->FlagShow())
	{
		m_highlightBar->Show();
	}
	m_highlightBar->SetBackgroundColor(m_highlightbarFocusedColor);
	m_highlightbarExpand = true;

	float width = 0, height = 0;
	m_highlightBar->GetSize(width, height);
	m_ResizeHighlightBar(width, m_highlightbarFocusHeight, easing, 0);
}

void CCategoryTab::m_ShrinkHighlightBar(bool easing)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_ShrinkHighlightBar.");
	if (m_isEnableHighlightbar && !m_highlightBar->FlagShow())
	{
		m_highlightBar->Show();
	}
	m_highlightbarExpand = false;

	float width = 0, height = 0;
	m_highlightBar->GetSize(width, height);
	m_ResizeHighlightBar(width, m_highlightbarUnfocusHeight, easing, m_highlightbarFocusHeight - m_highlightbarUnfocusHeight);
}

void CCategoryTab::m_KeepHighlightBarBottom(void)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_KeepHighlightBarBottom.");
	if (m_isHighlightbarBottom)
	{
		float tabareaWidth = 0, tabareaHeight = 0;
		m_tabAreaActor->GetSize(tabareaWidth, tabareaHeight);
		float highX = 0, highY = 0;
		m_highlightBar->GetPosition(highX, highY);
		float width = 0, height = 0;
		m_highlightBar->GetSize(width, height);
		m_highlightBar->SetPosition(highX, tabareaHeight - height);
	}
	else
	{
		float highX = 0, highY = 0;
		m_highlightBar->GetPosition(highX, highY);
		m_highlightBar->SetPosition(highX, 0);
	}
}

void CCategoryTab::m_LocationSubTab(int index)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_LocationSubTab.");
	float x = 0, y = 0;
	m_tabItemVec[index]->GetPosition(x, y);
	float tabitemWidth = 0, tabitemHeight = 0;
	m_tabItemVec[index]->GetSize(tabitemWidth, tabitemHeight);
	float tabareaWidth = 0, tabareaHeight = 0;
	m_tabAreaActor->GetSize(tabareaWidth, tabareaHeight);
	if ((x - m_tabSpliterWidth) < 10)
	{
		//at left end
		if (m_isReverse && m_useSelfReverse)
		{
			if ((int)m_tabItemVec.size() > (index + 1))
			{
				//show left more
				float lastTabWidth = 0, lastTabHeight = 0;
				m_tabItemVec[index + 1]->GetSize(lastTabWidth, lastTabHeight);
				m_MoveTabItems(0, -x + m_tabSpliterWidth + lastTabWidth / 2.f);
			}
			else
			{
				m_MoveTabItems(0, -x + m_tabSpliterWidth);
			}
		}
		else
		{
			if (index > 0)
			{
				//show left more
				float lastTabWidth = 0, lastTabHeight = 0;
				m_tabItemVec[index - 1]->GetSize(lastTabWidth, lastTabHeight);
				m_MoveTabItems(0, -x + m_tabSpliterWidth + lastTabWidth / 2.f);
			}
			else
			{
				m_MoveTabItems(0, -x + m_tabSpliterWidth);
			}
		}
		m_ReplaceSpliters();
	}
	else if (x + tabitemWidth + m_tabSpliterWidth > tabareaWidth - 10)
	{
		//at right end
		if (m_isReverse && m_useSelfReverse)
		{
			if (index > 0)
			{
				//show right more
				float nextTabWidth = 0, nextTabHeight = 0;
				m_tabItemVec[index - 1]->GetSize(nextTabWidth, nextTabHeight);
				m_MoveTabItems(0, tabareaWidth - (x + tabitemWidth + m_tabSpliterWidth) - nextTabWidth / 2.f);
			}
			else
			{
				m_MoveTabItems(0, tabareaWidth - (x + tabitemWidth + m_tabSpliterWidth));
			}
		}
		else
		{
			if ((int)m_tabItemVec.size() > (index + 1))
			{
				//show right more
				float nextTabWidth = 0, nextTabHeight = 0;
				m_tabItemVec[index + 1]->GetSize(nextTabWidth, nextTabHeight);
				m_MoveTabItems(0, tabareaWidth - (x + tabitemWidth + m_tabSpliterWidth) - nextTabWidth / 2.f);
			}
			else
			{
				m_MoveTabItems(0, tabareaWidth - (x + tabitemWidth + m_tabSpliterWidth));
			}
		}
		m_ReplaceSpliters();
	}
	m_RefreshArrows();
}

void CCategoryTab::m_StopHighlightbarMove(void)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_StopHighlightbarMove.");
	/*ClutterTransition *trans = clutter_actor_get_transition(m_highlightBar->Actor(), "position");
	if (trans)
	{
	clutter_timeline_stop(CLUTTER_TIMELINE(trans));
	}*/
	if (m_replaceHighlightAni->IsPlaying())
	{
		m_replaceHighlightAni->Stop();
	}
}

void CCategoryTab::m_StartHighlightbarMove(gfloat x, gfloat y)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_StartHighlightbarMove.");
	/*clutter_actor_save_easing_state(m_highlightBar->Actor());
	clutter_actor_set_easing_mode(m_highlightBar->Actor(), m_highlightbarMoveMode);
	clutter_actor_set_easing_duration(m_highlightBar->Actor(), m_highlightbarMoveDuration);
	clutter_actor_set_position(m_highlightBar->Actor(), x, y);
	clutter_actor_restore_easing_state(m_highlightBar->Actor());*/
	if (m_replaceHighlightAni->Duration() != m_highlightbarMoveDuration)
	{
		m_replaceHighlightAni->SetDuration(m_highlightbarMoveDuration);
	}
	TValue2f replaceHighlightAniTValue(x, y);
	m_replaceHighlightAni->SetDestination(m_highlightBar, IActor::ACTOR_ANI_POSITION, &replaceHighlightAniTValue);
	m_replaceHighlightAni->Play();

}

void CCategoryTab::m_StopHighlightbarResize(void)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_StopHighlightbarResize.");
	/*ClutterTransition *trans = clutter_actor_get_transition(m_highlightBar->Actor(), "size");
	if (trans)
	{
	clutter_timeline_stop(CLUTTER_TIMELINE(trans));
	}*/
	//if (m_resizeHighlightAni->IsPlaying())
	if (m_isResizeHighlightAni)
	{
		//m_resizeHighlightAni->JumpToDestination();
		m_resizeHighlightAni->Stop();
	}
}

void CCategoryTab::m_StartHighlightbarResize(float width, float height)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_StartHighlightbarResize.");
	m_isResizeHighlightAni = true;
	if (m_resizeHighlightAni->Duration() != m_highlightbarEasingDuration)
	{
		m_resizeHighlightAni->SetDuration(m_highlightbarEasingDuration);
	}
	TValue2f resizeHighlightAniTValue(width, height);
	m_resizeHighlightAni->SetDestination(m_highlightBar, IActor::ACTOR_ANI_SIZE, &resizeHighlightAniTValue);
	m_resizeHighlightAni->Play();

	/*clutter_actor_save_easing_state(m_highlightBar->Actor());
	clutter_actor_set_easing_mode(m_highlightBar->Actor(), m_highlightbarEasingMode);
	clutter_actor_set_easing_duration(m_highlightBar->Actor(), m_highlightbarEasingDuration);
	clutter_actor_set_size(m_highlightBar->Actor(), width, height);
	clutter_actor_restore_easing_state(m_highlightBar->Actor());*/
}

void CCategoryTab::SetHighlightBarFocusAnimation(float unfocusHeight, float focusHeight, ECategoryTabAnimationMode mode, int time)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetHighlightBarFocusAnimation.");
	if (unfocusHeight >= 0)
	{
		m_highlightbarUnfocusHeight = unfocusHeight;
	}
	if (focusHeight >= 0)
	{
		m_highlightbarFocusHeight = focusHeight;
		if (m_tabTargetHeightMax < 0)
		{
			m_tabTargetHeightMax = focusHeight;
		}
	}
	if (mode > ANIMATION_CUSTOM_MODE)
	{
		m_highlightbarEasingMode = m_ChangeAnimationMode(mode);
	}
	if (time >= 0)
	{
		m_highlightbarEasingDuration = time;
	}
}

void CCategoryTab::SetHighlightBarMoveAnimation(ECategoryTabAnimationMode mode, int time)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetHighlightBarMoveAnimation.");
	if (mode >= ANIMATION_CUSTOM_MODE)
	{
		m_highlightbarMoveMode = m_ChangeAnimationMode(mode);
	}
	if (time >= 0)
	{
		m_highlightbarMoveDuration = time;
	}
}

ClutterAnimationMode CCategoryTab::m_ChangeAnimationMode(ECategoryTabAnimationMode mode)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_ChangeAnimationMode.");
	ClutterAnimationMode clutterMode;
	switch (mode)
	{
	case ANIMATION_CUSTOM_MODE:
		clutterMode = CLUTTER_CUSTOM_MODE;
		break;
	case ANIMATION_LINEAR:
		clutterMode = CLUTTER_LINEAR;
		break;
	case ANIMATION_EASE_IN_QUAD:
		clutterMode = CLUTTER_EASE_IN_QUAD;
		break;
	case ANIMATION_EASE_OUT_QUAD:
		clutterMode = CLUTTER_EASE_OUT_QUAD;
		break;
	case ANIMATION_EASE_IN_OUT_QUAD:
		clutterMode = CLUTTER_EASE_IN_OUT_QUAD;
		break;
	case ANIMATION_EASE_IN_CUBIC:
		clutterMode = CLUTTER_EASE_IN_CUBIC;
		break;
	case ANIMATION_EASE_OUT_CUBIC:
		clutterMode = CLUTTER_EASE_OUT_CUBIC;
		break;
	case ANIMATION_EASE_IN_OUT_CUBIC:
		clutterMode = CLUTTER_EASE_IN_OUT_CUBIC;
		break;
	case ANIMATION_EASE_IN_QUART:
		clutterMode = CLUTTER_EASE_IN_QUART;
		break;
	case ANIMATION_EASE_OUT_QUART:
		clutterMode = CLUTTER_EASE_OUT_QUART;
		break;
	case ANIMATION_EASE_IN_OUT_QUART:
		clutterMode = CLUTTER_EASE_IN_OUT_QUART;
		break;
	case ANIMATION_EASE_IN_QUINT:
		clutterMode = CLUTTER_EASE_IN_QUINT;
		break;
	case ANIMATION_EASE_OUT_QUINT:
		clutterMode = CLUTTER_EASE_OUT_QUINT;
		break;
	case ANIMATION_EASE_IN_OUT_QUINT:
		clutterMode = CLUTTER_EASE_IN_OUT_QUINT;
		break;
	case ANIMATION_EASE_IN_SINE:
		clutterMode = CLUTTER_EASE_IN_SINE;
		break;
	case ANIMATION_EASE_OUT_SINE:
		clutterMode = CLUTTER_EASE_OUT_SINE;
		break;
	case ANIMATION_EASE_IN_OUT_SINE:
		clutterMode = CLUTTER_EASE_IN_OUT_SINE;
		break;
	case ANIMATION_EASE_IN_EXPO:
		clutterMode = CLUTTER_EASE_IN_EXPO;
		break;
	case ANIMATION_EASE_OUT_EXPO:
		clutterMode = CLUTTER_EASE_OUT_EXPO;
		break;
	case ANIMATION_EASE_IN_OUT_EXPO:
		clutterMode = CLUTTER_EASE_IN_OUT_EXPO;
		break;
	case ANIMATION_EASE_IN_CIRC:
		clutterMode = CLUTTER_EASE_IN_CIRC;
		break;
	case ANIMATION_EASE_OUT_CIRC:
		clutterMode = CLUTTER_EASE_OUT_CIRC;
		break;
	case ANIMATION_EASE_IN_OUT_CIRC:
		clutterMode = CLUTTER_EASE_IN_OUT_CIRC;
		break;
	case ANIMATION_EASE_IN_ELASTIC:
		clutterMode = CLUTTER_EASE_IN_ELASTIC;
		break;
	case ANIMATION_EASE_OUT_ELASTIC:
		clutterMode = CLUTTER_EASE_OUT_ELASTIC;
		break;
	case ANIMATION_EASE_IN_OUT_ELASTIC:
		clutterMode = CLUTTER_EASE_IN_OUT_ELASTIC;
		break;
	case ANIMATION_EASE_IN_BACK:
		clutterMode = CLUTTER_EASE_IN_BACK;
		break;
	case ANIMATION_EASE_OUT_BACK:
		clutterMode = CLUTTER_EASE_OUT_BACK;
		break;
	case ANIMATION_EASE_IN_OUT_BACK:
		clutterMode = CLUTTER_EASE_IN_OUT_BACK;
		break;
	case ANIMATION_EASE_IN_BOUNCE:
		clutterMode = CLUTTER_EASE_IN_BOUNCE;
		break;
	case ANIMATION_EASE_OUT_BOUNCE:
		clutterMode = CLUTTER_EASE_OUT_BOUNCE;
		break;
	case ANIMATION_EASE_IN_OUT_BOUNCE:
		clutterMode = CLUTTER_EASE_IN_OUT_BOUNCE;
		break;
	case ANIMATION_STEPS:
		clutterMode = CLUTTER_STEPS;
		break;
	case ANIMATION_STEP_START:
		clutterMode = CLUTTER_STEP_START;
		break;
	case ANIMATION_STEP_END:
		clutterMode = CLUTTER_STEP_END;
		break;
	case ANIMATION_CUBIC_BEZIER:
		clutterMode = CLUTTER_CUBIC_BEZIER;
		break;
	case ANIMATION_EASE:
		clutterMode = CLUTTER_EASE;
		break;
	case ANIMATION_EASE_IN:
		clutterMode = CLUTTER_EASE_IN;
		break;
	case ANIMATION_EASE_OUT:
		clutterMode = CLUTTER_EASE_OUT;
		break;
	case ANIMATION_EASE_IN_OUT:
		clutterMode = CLUTTER_EASE_IN_OUT;
		break;
	case ANIMATION_LAST:
		clutterMode = CLUTTER_ANIMATION_LAST;
		break;
	default:
		clutterMode = CLUTTER_LINEAR;
		break;
	}
	return clutterMode;
}

void CCategoryTab::EnableTabsKey(bool enable)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::EnableTabsKey.");
	if (enable == m_isEnableKey)
	{
		return;
	}
	m_isEnableKey = enable;
}

bool CCategoryTab::IsTabsKeyEnabled(void) const
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::IsTabsKeyEnabled.");
	return m_isEnableKey;
}

void CCategoryTab::SwapSubTab(int fromIndex, int toIndex)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SwapSubTab " << fromIndex << " to " << toIndex << " .");
	HALO_EXCEPTION(fromIndex >= 0 && fromIndex < (int)m_tabItemVec.size(), "From index out of range.");
	HALO_EXCEPTION(toIndex >= 0 && toIndex < (int)m_tabItemVec.size(), "To index out of range.");

	if (m_isSwapMoveAni || fromIndex == toIndex)
	{
		return;
	}
	m_isSwapMoveAni = true;
	if (toIndex != m_focusIndex && toIndex > -1 && toIndex < (int)m_tabItemVec.size())
	{
		float bx = 0, by = 0, bw = 0, bh = 0, aw = 0, ah = 0;
		m_tabItemVec[toIndex]->GetPosition(bx, by);
		m_tabItemVec[toIndex]->GetSize(bw, bh);
		m_tabAreaActor->GetSize(aw, ah);
		if (bx < 0 || bx + bw > aw)
		{
			m_LocationSubTab(toIndex);
		}
	}

	//move first
	if (fromIndex >= toIndex)
	{
		int temp = fromIndex;
		fromIndex = toIndex;
		toIndex = temp;
	}

	float fw = 0, fh = 0, tw = 0, th = 0;
	m_tabItemVec[fromIndex]->GetSize(fw, fh);
	m_tabItemVec[toIndex]->GetSize(tw, th);
	float dif = fw - tw;

	float fx = 0, fy = 0, tx = 0, ty = 0;
	m_tabItemVec[fromIndex]->GetPosition(fx, fy);
	m_tabItemVec[toIndex]->GetPosition(tx, ty);
	//m_tabItemVec[fromIndex]->SetPosition(tx - dif, fy); //set first and end
	//m_tabItemVec[toIndex]->SetPosition(fx, ty);
	TValue2f swapMoveAniFromTValue(tx - dif, fy);
	m_swapMoveAni->SetDestination(m_tabItemVec[fromIndex], IActor::ACTOR_ANI_POSITION, &swapMoveAniFromTValue);
	TValue2f swapMoveAniToTValue(fx, fy);
	m_swapMoveAni->SetDestination(m_tabItemVec[toIndex], IActor::ACTOR_ANI_POSITION, &swapMoveAniToTValue);

	for (int i = fromIndex + 1; i < toIndex; i++)
	{
		float x = 0, y = 0;
		m_tabItemVec[i]->GetPosition(x, y);
		//m_tabItemVec[i]->SetPosition(x - dif, y); //set middle
		TValue2f swapMoveAniTValue(x - dif, y);
		m_swapMoveAni->SetDestination(m_tabItemVec[i], IActor::ACTOR_ANI_POSITION, swapMoveAniTValue);
		if (i == m_focusIndex)
		{
			float hx = 0, hy = 0;
			m_highlightBar->GetPosition(hx, hy);
			TValue2f swapMoveAniTValue(hx - dif, hy);
			m_swapMoveAni->SetDestination(m_highlightBar, IActor::ACTOR_ANI_POSITION, &swapMoveAniTValue);
		}
	}

	//move highlightbar
	if (m_focusIndex == fromIndex)
	{
		float x = 0, y = 0;
		m_highlightBar->GetPosition(x, y);
		float leftWidth = 0, leftHeight = 0;
		m_leftArrows->GetSize(leftWidth, leftHeight);
		x = leftWidth + m_marginLeft + tx - dif - m_tabSpliterWidth;
		TValue2f swapMoveAniTValue(x, y);
		m_swapMoveAni->SetDestination(m_highlightBar, IActor::ACTOR_ANI_POSITION, &swapMoveAniTValue);
		//m_highlightBar->SetPosition(x, y);
	}
	else if (m_focusIndex == toIndex)
	{
		float x = 0, y = 0;
		m_highlightBar->GetPosition(x, y);
		float leftWidth = 0, leftHeight = 0;
		m_leftArrows->GetSize(leftWidth, leftHeight);
		x = leftWidth + m_marginLeft + fx - m_tabSpliterWidth;
		TValue2f swapMoveAniTValue(x, y);
		m_swapMoveAni->SetDestination(m_highlightBar, IActor::ACTOR_ANI_POSITION, &swapMoveAniTValue);
		//m_highlightBar->SetPosition(x, y);
	}

	m_swapFrom = fromIndex;
	m_swapTo = toIndex;

	m_swapMoveAni->Play();
}

void CCategoryTab::m_swapSubTabByPosition(int fromIndex, float fromX, float fromY, float fromWidth, int toIndex, float toX, float toY, float toWidth)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_swapSubTabByPosition.");
	//move position
	float dif = fromWidth - toWidth;

	if (m_swapMoveAni->Duration() != m_swapMoveDuration)
	{
		m_swapMoveAni->SetDuration(m_swapMoveDuration);
	}
	TValue2f swapMoveAniFromTValue(toX - dif, fromY);
	m_swapMoveAni->SetDestination(m_tabItemVec[fromIndex], IActor::ACTOR_ANI_POSITION, swapMoveAniFromTValue);
	TValue2f swapMoveAniToTValue(fromX, toY);
	m_swapMoveAni->SetDestination(m_tabItemVec[toIndex], IActor::ACTOR_ANI_POSITION, &swapMoveAniToTValue);
	//m_tabItemVec[fromIndex]->SetPosition(tx - dif, fy); //set first and end
	//m_tabItemVec[toIndex]->SetPosition(fx, ty);

	for (int i = fromIndex + 1; i < toIndex; i++)
	{
		float x = 0, y = 0;
		m_tabItemVec[i]->GetPosition(x, y);
		//m_tabItemVec[i]->SetPosition(x - dif, y); //set middle
		TValue2f swapMoveAniTValueTmp(x - dif, y);
		m_swapMoveAni->SetDestination(m_tabItemVec[i], IActor::ACTOR_ANI_POSITION, &swapMoveAniTValueTmp);
	}

	//move highlightbar
	if (m_focusIndex == fromIndex)
	{
		float x = 0, y = 0;
		m_highlightBar->GetPosition(x, y);
		float leftWidth = 0, leftHeight = 0;
		m_leftArrows->GetSize(leftWidth, leftHeight);
		x = leftWidth + m_marginLeft + toX - dif - m_tabSpliterWidth;
		TValue2f tvalue(x, y);
		m_swapMoveAni->SetDestination(m_highlightBar, IActor::ACTOR_ANI_POSITION, &tvalue);
		//m_highlightBar->SetPosition(x, y);
	}
	else if (m_focusIndex == toIndex)
	{
		float x = 0, y = 0;
		m_highlightBar->GetPosition(x, y);
		float leftWidth = 0, leftHeight = 0;
		m_leftArrows->GetSize(leftWidth, leftHeight);
		x = leftWidth + m_marginLeft + fromX - m_tabSpliterWidth;
		TValue2f tvalue(x, y);
		m_swapMoveAni->SetDestination(m_highlightBar, IActor::ACTOR_ANI_POSITION, &tvalue);
		//m_highlightBar->SetPosition(x, y);
	}

	m_swapFrom = fromIndex;
	m_swapTo = toIndex;

	m_swapMoveAni->Play();
}

void CCategoryTab::m_InitTabItemCheckBox(ISelectButton *checkbox)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_InitTabItemCheckBox.");
	for (int i = 0; i <= STATE_SELECT_ALL; i++)
	{
		if ((int)m_tabCheckImageData[i].length() > 0)
		{
			checkbox->SetCheckImage((ISelectButton::EItemState)i, m_tabCheckImageData[i]);
		}
		if ((int)m_tabCheckBoxImageData[i].length() > 0)
		{
			checkbox->SetBoxBackGroudImage((ISelectButton::EItemState)i, m_tabCheckBoxImageData[i]);
		}
		if (m_tabCheckImageOpacityData[i] >= 0)
		{
			checkbox->SetCheckImageOpacity((ISelectButton::EItemState)i, m_tabCheckImageOpacityData[i]);
		}
		if (m_tabCheckBoxImageOpacityData[i] >= 0)
		{
			checkbox->SetBoxBackGroudImageOpacity((ISelectButton::EItemState)i, m_tabCheckBoxImageOpacityData[i]);
		}
	}
}

void CCategoryTab::SetTabCheckImage(ECategoryTabSelectState state, const std::string& image)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabCheckImage.");
	m_tabCheckImageData[state] = image;
}

void CCategoryTab::SetTabBoxBackGroudImage(ECategoryTabSelectState state, const std::string& image)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabBoxBackGroudImage.");
	m_tabCheckBoxImageData[state] = image;
}

void CCategoryTab::SetTabCheckImageOpacity(ECategoryTabSelectState state, int value)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabCheckImageOpacity.");
	m_tabCheckImageOpacityData[state] = value;
}

void CCategoryTab::SetTabBoxBackGroudImageOpacity(ECategoryTabSelectState state, int value)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabBoxBackGroudImageOpacity.");
	m_tabCheckBoxImageOpacityData[state] = value;
}

void CCategoryTab::ShowTabCheckBox(void)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::ShowTabCheckBox.");
	m_isShowCheckBox = true;
	for (int i = 0; i < (int)m_tabItemVec.size(); i++)
	{
		m_tabItemVec[i]->CheckBoxActor()->Show();
	}
}

void CCategoryTab::HideTabCheckBox(void)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::HideTabCheckBox.");
	m_isShowCheckBox = false;
	for (int i = 0; i < (int)m_tabItemVec.size(); i++)
	{
		m_tabItemVec[i]->CheckBoxActor()->Hide();
	}
}

void CCategoryTab::ShowTabLeftImage(int index)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::ShowTabLeftImage.");
	m_tabItemVec[index]->LeftImageActor()->Show();
}

void CCategoryTab::ShowTabRightImage(int index)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::ShowTabRightImage.");
	m_tabItemVec[index]->RightImageActor()->Show();
}

void CCategoryTab::HideTabLeftImage(int index)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::HideTabLeftImage.");
	m_tabItemVec[index]->LeftImageActor()->Hide();
}

void CCategoryTab::HideTabRightImage(int index)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::HideTabRightImage.");
	m_tabItemVec[index]->RightImageActor()->Hide();
}

void CCategoryTab::SetTabLeftImageSize(float width, float height, float margin)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabLeftImageSize.");
	m_tabLeftImageWidth = width;
	m_tabLeftImageHeight = height;
	m_tabLeftImageMargin = margin;
}

void CCategoryTab::SetTabRightImageSize(float width, float height, float margin)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabRightImageSize.");
	m_tabRightImageWidth = width;
	m_tabRightImageHeight = height;
	m_tabRightImageMargin = margin;
}

void CCategoryTab::SetTabLeftImagePath(const std::string&  path, int index)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabLeftImagePath.");
	if (index < 0)
	{
		m_tabLeftImagePath = path;
	}
	else if (index < (int)m_tabItemVec.size())
	{
		m_tabItemVec[index]->LeftImageActor()->SetImage(path.c_str());
	}
}
void CCategoryTab::SetTabRightImagePath(const std::string&  path, int index)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabRightImagePath.");
	if (index < 0)
	{
		m_tabRightImagePath = path;
	}
	else if (index < (int)m_tabItemVec.size())
	{
		m_tabItemVec[index]->LeftImageActor()->SetImage(path.c_str());
	}
}

void CCategoryTab::EnableHighlightBarBottom(bool enable)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::EnableHighlightBarBottom.");
	if (enable == m_isHighlightbarBottom)
	{
		return;
	}
	if (enable)
	{
		m_AddHighlightbarSizeListener();
	}
	else
	{
		m_RemoveHighlightbarSizeListener();
	}
	m_isHighlightbarBottom = enable;
	m_KeepHighlightBarBottom();
}

bool CCategoryTab::IsHighlightBarBottom(void) const
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::IsHighlightBarBottom.");
	return m_isHighlightbarBottom;
}

bool CCategoryTab::OnCompleted(class ITimeLine *animation, void *data)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::OnCompleted.");
	//swap end
	if (data == m_swapMoveAni)
	{
		int fromIndex = m_swapFrom;
		int toIndex = m_swapTo;
		//change date in vecs
		CCategoryTabItem* firstButton = m_tabItemVec[fromIndex];
		m_tabItemVec.erase(m_tabItemVec.begin() + fromIndex);
		m_tabItemVec.insert(m_tabItemVec.begin() + toIndex, firstButton);

		if (toIndex - fromIndex > 1) //move over other sub-tab
		{
			CCategoryTabItem* endButton = m_tabItemVec[toIndex - 1];
			m_tabItemVec.erase(m_tabItemVec.begin() + toIndex - 1);
			m_tabItemVec.insert(m_tabItemVec.begin() + fromIndex, endButton);
		}

		//change focus index and highlightbar
		if (m_focusIndex == fromIndex)
		{
			m_focusIndex = toIndex;
			m_ReplaceHighlightBar(m_focusIndex, false);
		}
		else if (m_focusIndex == toIndex)
		{
			m_focusIndex = fromIndex;
			m_ReplaceHighlightBar(m_focusIndex, false);
		}
		if (m_focusIndexLast == fromIndex)
		{
			m_focusIndexLast = toIndex;
		}
		else if (m_focusIndexLast == toIndex)
		{
			m_focusIndexLast = fromIndex;
		}

		m_ReplaceSpliters();
		m_RefreshArrows();
		if (m_highlightedIndex == fromIndex)
		{
			m_highlightedIndex = toIndex;
		}
		else if (m_highlightedIndex == toIndex)
		{
			m_highlightedIndex = fromIndex;
		}
		if (m_selectedIndex == fromIndex)
		{
			m_selectedIndex = toIndex;
		}
		else if (m_selectedIndex == toIndex)
		{
			m_selectedIndex = fromIndex;
		}
		m_ResetTabItemsState();
		m_isSwapMoveAni = false;
	}
	else if (data == m_resizeHighlightAni)
	{
		if (!m_highlightbarExpand)
		{
			m_highlightBar->SetBackgroundColor(m_highlightbarUnfocusedColor);
		}
		m_isResizeHighlightAni = false;
	}

	return true;
}

void CCategoryTab::SetTabCheckBoxSize(float width, float height)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabCheckBoxSize.");
	m_checkboxWidth = width;
	m_checkboxHeight = height;
}
void CCategoryTab::SetTabCheckBoxMargin(float margin)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabCheckBoxMargin.");
	m_checkboxMargin = margin;
}
void CCategoryTab::SetSwapSubTabDuration(int time)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetSwapSubTabDuration.");
	m_swapMoveDuration = time;
}

bool CCategoryTab::OnDragBegin(IWidgetExtension* pWindow, IDragEvent* pDragEvent)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::OnDragBegin.");
	if (m_isDragMove > 0)
	{
		for (int i = 0; i < (int)m_tabItemVec.size(); i++)
		{
			if (pWindow == m_tabItemVec[i])
			{
				m_tabItemVec[i]->GetPosition(m_dragX, m_dragY);
				m_isDragMove++;
				return true;
			}
		}
	}
	m_isEnableKey = false;
	m_isDragMove++;
	for (int i = 0; i < (int)m_tabItemVec.size(); i++)
	{
		if (pWindow == m_tabItemVec[i])
		{
			if (i != m_focusIndex)
			{
				m_focusIndex = i;
				m_GetFocusOn(m_focusIndex);
				m_ChangeTabItemState(m_focusIndex, STATE_HIGHLIGHTED);
				m_ReplaceHighlightBar(m_focusIndex);
			}

			m_tabItemVec[i]->GetPosition(m_dragX, m_dragY);
			if (m_highlightBar->FlagShow())
			{
				m_highlightBar->GetPosition(m_highlightDragX, m_highlightDragY);
			}
			break;
		}
	}
	return true;
}

bool CCategoryTab::OnDragEnd(IWidgetExtension* pWindow, IDragEvent* pDragEvent)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::OnDragEnd.");
	for (int i = 0; i < (int)m_tabItemVec.size(); i++)
	{
		if (pWindow == m_tabItemVec[i])
		{
			float dragx = 0, dragy = 0;
			pDragEvent->MotionCoords(&dragx, &dragy);
			if (m_isAutoShowLeftRightImage)
			{
				HideTabLeftImage(i);
				HideTabRightImage(i);
			}

			bool flag = false;
			float cx = 0, cy = 0, cw = 0, ch = 0;
			m_tabAreaActor->GetSize(cw, ch);
			Widget *tabControl = dynamic_cast<Widget*>(m_tabAreaActor);
			HALO_ASSERT(NULL != tabControl);
			Vector3 cPos = tabControl->getAbsolutePosition();
			cx = (float)cPos.x;
			cy = (float)cPos.y;
			if (dragy >= cy + 5 && dragy <= cy + ch - 5 && dragx >= cx + 5 && dragx <= cx + cw - 5)
			{
				for (int j = 0; j < (int)m_tabItemVec.size(); j++)
				{
					if (i == j)
					{
						continue;
					}
					else
					{
						/*float jw = 0, jh = 0, jx=0, jy=0, aw=0, ah = 0;
						m_tabItemVec[j]->GetPosition(jx, jy);
						m_tabItemVec[j]->GetSize(jw, jh);
						m_tabAreaActor->GetSize(aw, ah);
						if (jx < 0 || jx + jw > aw)
						{
						m_tabItemVec[i]->SetPosition(m_dragX, m_dragY);
						if (i == m_focusIndex)
						{
						m_highlightBar->SetPosition(m_highlightDragX, m_highlightDragY);
						}
						break;
						}*/
					}

					float tx = 0, ty = 0, tw = 0, th = 0;
					m_tabItemVec[j]->GetSize(tw, th);
					Widget *subtabControl = dynamic_cast<Widget*>(m_tabItemVec[j]);
					HALO_ASSERT(NULL != subtabControl);
					Vector3 sPos = subtabControl->getAbsolutePosition();
					tx = (float)sPos.x;
					ty = (float)sPos.y;
					if (dragx >= tx && dragx <= tx + tw)
					{
						if (i == j)
						{
							m_tabItemVec[i]->SetPosition(m_dragX, m_dragY);
							if (i == m_focusIndex)
							{
								m_highlightBar->SetPosition(m_highlightDragX, m_highlightDragY);
								flag = true;
							}
						}
						else
						{
							m_tabItemVec[i]->SetPosition(m_dragX, m_dragY);
							if (i == m_focusIndex)
							{
								m_highlightBar->SetPosition(m_highlightDragX, m_highlightDragY);
							}
							flag = true;
							SwapSubTab(i, j);
						}
						break;
					}
				}
				if (!flag && i > 0)
				{
					//at most left
					float leftx = 0, lefty = 0;
					Widget *subtabControl = dynamic_cast<Widget*>(m_tabItemVec[0]);
					HALO_ASSERT(NULL != subtabControl);
					Vector3 sPos = subtabControl->getAbsolutePosition();
					leftx = (float)sPos.x;
					lefty = (float)sPos.y;
					if (dragx < leftx)
					{
						m_tabItemVec[i]->SetPosition(m_dragX, m_dragY);
						if (i == m_focusIndex)
						{
							m_highlightBar->SetPosition(m_highlightDragX, m_highlightDragY);
						}
						flag = true;
						SwapSubTab(i, 0);
					}
				}
				if (!flag && i < (int)m_tabItemVec.size() - 1)
				{
					//at most right
					float rightx = 0, righty = 0, rightwidth = 0, rightheight = 0;
					int tempIndex = (int)m_tabItemVec.size() - 1;
					Widget *subtabControl = dynamic_cast<Widget*>(m_tabItemVec[tempIndex]);
					HALO_ASSERT(NULL != subtabControl);
					Vector3 sPos = subtabControl->getAbsolutePosition();
					rightx = (float)sPos.x;
					righty = (float)sPos.y;
					m_tabItemVec[tempIndex]->GetSize(rightwidth, rightheight);
					if (dragx > rightx + rightwidth)
					{
						m_tabItemVec[i]->SetPosition(m_dragX, m_dragY);
						if (i == m_focusIndex)
						{
							m_highlightBar->SetPosition(m_highlightDragX, m_highlightDragY);
						}
						flag = true;
						SwapSubTab(i, tempIndex);
					}
				}
			}

			if (!flag)
			{
				m_tabItemVec[i]->SetPosition(m_dragX, m_dragY);
				if (i == m_focusIndex)
				{
					m_highlightBar->SetPosition(m_highlightDragX, m_highlightDragY);
				}
			}
			m_highlightDragX = m_highlightDragY = m_dragX = m_dragY = -1;
			m_isEnableKey = true;
			m_isDragMove--;
			break;
		}
	}
	return true;
}

bool CCategoryTab::OnDragMotion(IWidgetExtension* pWindow, IDragEvent* pDragEvent)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::OnDragMotion.");
	for (int i = 0; i < (int)m_tabItemVec.size(); i++)
	{
		if (pWindow == m_tabItemVec[i])
		{
			if (m_highlightBar->FlagShow())
			{
				float dragx = 0, dragy = 0, dragx2, dragy2;
				pDragEvent->MotionCoords(&dragx, &dragy);
				pDragEvent->PressCoords(&dragx2, &dragy2);

				float offsetX = dragx - dragx2;
				float offsetY = dragy - dragy2;
				float x = 0, y = 0;
				m_highlightBar->GetPosition(x, y);
				//m_highlightBar->SetPosition(m_highlightDragX + offsetX, m_highlightDragY + offsetY);
				m_highlightBar->SetPosition(m_highlightDragX + offsetX, y);
			}
			break;
		}
	}
	return true;
}

void CCategoryTab::EnableDragTab(bool enable)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::EnableDragTab.");
	if (m_isEnableDragTab == enable)
	{
		return;
	}
	m_isEnableDragTab = enable;
	if (enable)
	{
		for (int i = 0; i < (int)m_tabItemVec.size(); i++)
		{
			m_tabItemVec[i]->AddAction(m_tabItemVec[i]->m_dragAction);
			m_tabItemVec[i]->AddDragListener(this);
		}
	}
	else
	{
		for (int i = 0; i < (int)m_tabItemVec.size(); i++)
		{
			m_tabItemVec[i]->RemoveAction(m_tabItemVec[i]->m_dragAction);
			m_tabItemVec[i]->RemoveDragListener(this);
		}
	}
}

bool CCategoryTab::IsEnableDragTab(void) const
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::IsEnableDragTab.");
	return m_isEnableDragTab;
}

std::vector<int> CCategoryTab::GetTabCheckBoxSelectedIndexes(void)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::GetTabCheckBoxSelectedIndexes.");
	std::vector<int> selectedIndexes;
	for (int i = 0; i < (int)m_tabItemVec.size(); i++)
	{
		if (m_tabItemVec[i]->CheckBoxActor()->IsChecked())
		{
			selectedIndexes.push_back(i);
		}
	}
	return selectedIndexes;
}

void CCategoryTab::SetHighlightBarFocusedColor(const ClutterColor& color)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetHighlightBarFocusedColor.");
	m_highlightbarFocusedColor = color;
}

void CCategoryTab::SetHighlightBarUnfocusedColor(const ClutterColor& color)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetHighlightBarUnfocusedColor.");
	m_highlightbarUnfocusedColor = color;
}

void CCategoryTab::SetTabTargetHeight(float targetMin, float targetMax)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabTargetHeight.");
	if (targetMin >= 0)
	{
		m_tabTargetHeightMin = targetMin;
	}
	if (targetMax >= 0)
	{
		m_tabTargetHeightMax = targetMin;
	}
}

void CCategoryTab::SetTabChecked(int index, bool enable)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabCheck.");
	HALO_EXCEPTION(index >= 0 && index < (int)m_tabItemVec.size(), "Index out of range.");
	m_tabItemVec[index]->CheckBoxActor()->SetCheck(enable);
}

bool CCategoryTab::IsTabChecked(int index)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::IsTabChecked.");
	HALO_EXCEPTION(index >= 0 && index < (int)m_tabItemVec.size(), "Index out of range.");
	return m_tabItemVec[index]->CheckBoxActor()->IsChecked();
}

void CCategoryTab::m_ResetTabItemsState(void)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::m_ResetTabItemsState.");
	for (int i = 0; i < (int)m_tabItemVec.size(); i++)
	{
		if (i == m_selectedIndex)
		{
			m_ChangeTabItemState(i, STATE_SELECTED);
		}
		else if (i == m_highlightedIndex)
		{
			m_ChangeTabItemState(i, STATE_HIGHLIGHTED);
		}
		else
		{
			m_ChangeTabItemState(i, STATE_UNSELECTED);
		}
	}
}

const char* CCategoryTab::GetActorType(void)
{
	return "CategoryTab";
}

void CCategoryTab::EnableAutoShowImagesOnPressTab(bool enable)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::EnableAutoShowImagesOnPressTab." << enable);
	if (enable == m_isAutoShowLeftRightImage)
	{
		return;
	}
	m_isAutoShowLeftRightImage = enable;
}

bool CCategoryTab::IsEnableAutoShowImagesOnPressTab(void) const
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::IsEnableAutoShowImagesOnPressTab.");
	return m_isAutoShowLeftRightImage;
}

void CCategoryTab::GetTabSize(int index, float &width, float &height)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::GetTabSize." << index);
	HALO_EXCEPTION(index >= 0 && index < (int)m_tabItemVec.size(), "Index out of range.");
	m_tabItemVec[index]->GetSize(width, height);
}


void CCategoryTab::GetTabPosition(int index, bool isAbsolute, float &x, float &y)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::GetTabPosition." << index << " " << isAbsolute);
	HALO_EXCEPTION(index >= 0 && index < (int)m_tabItemVec.size(), "Index out of range.");
	if (isAbsolute)
	{
		Vector3 cPos = m_tabItemVec[index]->getAbsolutePosition();
		x = cPos.x;
		y = cPos.y;
	}
	else
	{
		m_tabItemVec[index]->GetPosition(x, y);
	}
}

void CCategoryTab::SetTabScrollAttribute(guint duration, gfloat speed, guint delay, gint repeat, ClutterTextScrollType type, ClutterTimelineDirection direction, guint continueGap)
{
	H_LOG_TRACE(LOGGER, "CCategoryTab::SetTabScrollAttribute:" << duration << "," << speed << "," << delay << "," << repeat);
	m_textscrollDefaultDuration = duration;
	m_textscrollDefaultSpeed = speed;
	m_textscrollDefaultDelay = delay;
	m_textscrollDefaultRepeat = repeat;
	m_textscrollDefaultType = type;
	m_textscrollDefaultDirection = direction;
	m_textscrollDefaultContinueGap = continueGap;
}

CCategoryTabItem::CCategoryTabItem(void)
{
	m_backgroundImage = NULL;
	m_icon = NULL;
	m_text = NULL;
	m_leftImage = NULL;
	m_rightImage = NULL;
	m_checkbox = NULL;
	m_curState = ICategoryTab::STATE_ALL;
	m_dragAction = NULL;
	m_fixwidth = 0;
	m_fillheight = false;

	for (int i = 0; i < ICategoryTab::STATE_ALL; i++)
	{
		ClutterColor defaultBgColor = { 0, 0, 0, 0 };
		ClutterColor defaultTextColor = { 0, 0, 0, 255 };
		m_stateData[i].backgroundColor = defaultBgColor;
		m_stateData[i].textColor = defaultTextColor;
		m_stateData[i].iconAlpha = 255;
		m_stateData[i].fontSize = 20; //default font size set to 20
	}
}
CCategoryTabItem::~CCategoryTabItem(void)
{
	if (m_backgroundImage != NULL)
	{
		m_backgroundImage->Release();
	}
	if (m_icon != NULL)
	{
		m_icon->Release();
	}
	if (m_text != NULL)
	{
		m_text->Release();
	}
	if (m_leftImage != NULL)
	{
		m_leftImage->Release();
	}
	if (m_rightImage != NULL)
	{
		m_rightImage->Release();
	}
	if (m_checkbox != NULL)
	{
		m_checkbox->Release();
	}
	if (m_dragAction != NULL)
	{
		m_dragAction->Release();
	}
}

bool CCategoryTabItem::Initialize(IActor *parent, float width, float height)
{
	Widget *cParent = dynamic_cast<Widget*>(parent);
	return Initialize(cParent, width, height);
}
bool CCategoryTabItem::Initialize(Widget *parent, float width, float height)
{
	CActor::Initialize(parent, width, height);
	Widget *widget = dynamic_cast<Widget*>(this);
	if (widget != NULL)
	{
		m_backgroundImage = ICompositeImage::CreateInstance(widget, width, height);
		m_icon = IImage::CreateInstance(widget, width, height);
		m_text = IText::CreateInstance(widget, width, height);
		m_text->SetTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
		m_leftImage = ICompositeImage::CreateInstance(widget, width, height);
		m_rightImage = ICompositeImage::CreateInstance(widget, width, height);
		m_checkbox = ISelectButton::CreateInstance(this, width, height);
		m_dragAction = IDragAction::CreateInstance(this);
		m_dragAction->SetDragAxis(CLUTTER_DRAG_X_AXIS);
	}
	return true;
}

void CCategoryTabItem::ChangeState(ICategoryTab::ECategoryTabState state)
{
	H_LOG_TRACE(LOGGER, "CCategoryTabItem::ChangeState [" << state << "].");
	if (state == ICategoryTab::STATE_ALL)
	{
		state = ICategoryTab::STATE_UNSELECTED;
	}
	//change background image
	if (!m_stateData[state].backgroundImagePath.empty())
	{
		m_backgroundImage->SetImage(m_stateData[state].backgroundImagePath.c_str());
	}
	//change background color
	CActor::SetBackgroundColor(m_stateData[state].backgroundColor);
	//change icon image
	if (!m_stateData[state].iconPath.empty())
	{
		m_icon->SetImage(m_stateData[state].iconPath.c_str());
	}
	//change icon alpha
	if (m_stateData[state].iconAlpha >= 0 && m_stateData[state].iconAlpha <= 255)
	{
		m_icon->SetAlpha(m_stateData[state].iconAlpha);
	}
	//change text content
	if (!m_stateData[state].textContent.empty())
	{
		m_text->SetText(m_stateData[state].textContent.c_str());
	}
	//not change text font, could add this.
	//change text font size
	if (m_stateData[state].fontSize >= 0)
	{
		m_text->SetFontSize(m_stateData[state].fontSize);
	}
	//change text color
	m_text->SetTextColor(m_stateData[state].textColor);
	//not change left image
	/*if (!m_stateData[state].leftImagePath.empty())
	{
	m_leftImage->SetImage(m_stateData[state].leftImagePath.c_str());
	}*/
	//not change right image
	/*if (!m_stateData[state].rightImagePath.empty())
	{
	m_rightImage->SetImage(m_stateData[state].rightImagePath.c_str());
	}*/

	m_curState = state;
}
