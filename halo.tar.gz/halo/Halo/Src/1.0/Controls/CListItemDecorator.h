#ifndef _CLISITEMDECORATOR_H_
#define _CLISITEMDECORATOR_H_

namespace HALO
{
	class CListItemDecorator: public CListItem
	{
	public:
		CListItemDecorator(){};
		virtual ~CListItemDecorator(){};
		virtual void Create(TRect* rect , IActor* parent) = 0;
		virtual void Enable(bool flagEnable) = 0;
		virtual void LoadData() = 0;
		virtual void UnLoadData() = 0;
		void SetUIElementStyle(int style);
		int GetUIElementStyle(){return t_style;};
	protected:
		int t_style;
	};

	class CProgressDecorator: public CListItemDecorator
	{
	public:
		CProgressDecorator(){};
		 ~CProgressDecorator();
		void Create(TRect* rect , IActor* parent);
		void Enable(bool flagEnable);
		void SetValue(int value);
		void LoadData();
		void UnLoadData();
	private:
		IProgress* m_progress;
		int m_MinValue;
		int m_MaxValue;
		EDirectionType m_progressType;
		bool m_reverseFlag;

		IImageBuffer* m_bgImage;
		IImageBuffer* m_progressImage;
		ClutterColor m_bgColor;
	};

	class CTextDecorator: public CListItemDecorator
	{
	public:
		CTextDecorator(){};
		 ~CTextDecorator();
		void Create(TRect* rect , IActor* parent);
		void Enable(bool flagEnable);
		void LoadData();
		void UnLoadData();
	private:
		int m_fontSize;
		char* m_contentText;
		IText* m_text;
		EHAlignment m_hAlignment;
		EVAlignment m_vAlignment;
		ClutterColor m_textColor;	
	};

	class CImageDecorator: public CListItemDecorator
	{
	public:
		CImageDecorator(){};
		 ~CImageDecorator();
		void Create(TRect* rect , IActor* parent);
		void Enable(bool flagEnable);
		void LoadData();
		void UnLoadData();
		void SetImageBuffer(IImageBuffer *buffer);
	private:
		IImage* m_image;
		IImageBuffer *m_imageBuffer;
		ClutterContentGravity m_gravity;
	};
} /* namespace HALO */
#endif 