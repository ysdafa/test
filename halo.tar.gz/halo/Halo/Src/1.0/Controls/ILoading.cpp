#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	ILoading* ILoading::CreateInstance(IActor* parent, const TLoadingAttr &attr)
	{
		CLoading* loading = dynamic_cast<CLoading*>(Instance::CreateInstance(CLASS_ID_ILOADING));

		if (NULL != loading)
		{
			loading->Initialize(parent , attr);
		}
		return loading;
	}

	ILoading* ILoading::CreateInstance(Widget* parent, const TLoadingAttr &attr)
	{
		CLoading* loading = dynamic_cast<CLoading*>(Instance::CreateInstance(CLASS_ID_ILOADING));

		if (NULL != loading)
		{
			loading->Initialize(parent , attr);
		}
		return loading;
	}
}