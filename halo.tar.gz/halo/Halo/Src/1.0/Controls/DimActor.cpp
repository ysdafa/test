#define CLUTTER_ENABLE_EXPERIMENTAL_API
#define COGL_ENABLE_EXPERIMENTAL_API

#include "VoltActor.h"
#include "DimActor.h"

/**
* SECTION:DimActor
* @short_description: Halo library clutter actor
*
* A clutter actor with modifications for Dim window.
*
* 1) allows prevention of painting of the root actor (i.e.
* itself but not its children) that would be done through the
* paint_node routine.
*/

G_DEFINE_TYPE(DimActor, dim_actor, VOLT_ACTOR_TYPE);

/* macro for accessing the object's private structure */
#define DIM_ACTOR_TYPE_GET_PRIVATE(obj) \
	(G_TYPE_INSTANCE_GET_PRIVATE((obj), DIM_ACTOR_TYPE, DimActorPrivate))

static const ClutterColor grey = { 0, 0, 0, 150 };

/* private structure - should only be accessed through the public API;
* this is used to store member variables whose properties
* need to be accessible from the implementation; for example, if we
* intend to create wrapper functions which modify properties on the
* actors composing an object, we should keep a reference to the actors
* here
*
* this is also the place where other state variables go:
* for example, you might record the current state of the button
* (toggled on or off) or a background image
*/
struct _DimActorPrivate
{
	ClutterColor bg_color;

	GList *hole_rects;
};

static void
hole_rect_free(ClutterRect *rect)
{
	g_free(rect);
}

static void
dim_actor_dispose(GObject* gobject)
{
	DimActorPrivate* priv = DIM_ACTOR(gobject)->priv;

	g_list_free_full(priv->hole_rects, 
		(GDestroyNotify)hole_rect_free);
	priv->hole_rects = NULL;

	/* call the parent class' dispose() method */
	G_OBJECT_CLASS(dim_actor_parent_class)->dispose(gobject);
}


/* from http://mail.gnome.org/archives/gtk-devel-list/2004-July/msg00158.html:
*
* "The finalize method finishes releasing the remaining
* resources just before the object itself will be freed from memory, and
* therefore it will only be called once. The two step process helps break
* cyclic references. Both dispose and finalize must chain up to their
* parent objects by calling their parent's respective methods *after* they
* have disposed or finalized their own members."
*/
static void
dim_actor_finalize(GObject *gobject)
{
	/* call the parent class' finalize() method */
	G_OBJECT_CLASS(dim_actor_parent_class)->finalize(gobject);
}

static void
dim_actor_paint_node(ClutterActor *actor, ClutterPaintNode *root)
{
	//CLUTTER_ACTOR_GET_CLASS(dim_actor_parent_class)->paint_node(actor, root);

	DimActor* dimActor = DIM_ACTOR(actor);
	DimActorPrivate *priv = dimActor->priv;

	ClutterPaintNode *node;
	ClutterColor color;

	color = priv->bg_color;
	color.alpha = clutter_actor_get_paint_opacity(actor)
		* priv->bg_color.alpha
		/ 255;

	node = clutter_color_node_new(&color);
	clutter_paint_node_set_name(node, "solidColor");

	cogl_path_new();

	cogl_path_rectangle(0, 0, volt_actor_get_width(VOLT_ACTOR(actor)), volt_actor_get_height(VOLT_ACTOR(actor)));

	GList *l;
	for (l = priv->hole_rects; l != NULL; l = l->next)
	{
		ClutterRect *rect = (ClutterRect*)l->data;
		cogl_path_rectangle(rect->origin.x, rect->origin.y, rect->origin.x + rect->size.width, rect->origin.y + rect->size.height);
	}

	CoglPath* path = cogl_get_path();
	clutter_paint_node_add_path(node, path);
	clutter_paint_node_add_child(root, node);
	clutter_paint_node_unref(node);
}

/* GObject class and instance initialization functions; note that
* these have been placed after the Clutter implementation, as
* they refer to the static function implementations above
*/

/* class init: attach functions to superclasses, define properties
* and signals
*/

static void
dim_actor_class_init(DimActorClass *klass)
{
	ClutterActorClass *actor_class = CLUTTER_ACTOR_CLASS(klass);
	actor_class->paint_node = dim_actor_paint_node;

	GObjectClass *gobject_class = G_OBJECT_CLASS(klass);

	gobject_class->dispose = dim_actor_dispose;
	gobject_class->finalize = dim_actor_finalize;

	g_type_class_add_private(klass, sizeof (DimActorPrivate));
}

/* object init: create a private structure and pack
* composed ClutterActors into it
*/
static void
dim_actor_init(DimActor *self)
{
	DimActorPrivate *priv;

	priv = self->priv = DIM_ACTOR_TYPE_GET_PRIVATE(self);

	priv->bg_color = grey;
	priv->hole_rects = NULL;
}

/* called each time a property is set on the effect */
static void
dim_actor_update(DimActor *self)
{
	clutter_actor_queue_redraw(CLUTTER_ACTOR(self));
}

/**
* dim_actor_new:
*
* Creates a new #DimActor instance
*
* Returns: a new #DimActor
*/
ClutterActor *
dim_actor_new(void)
{
	return CLUTTER_ACTOR(g_object_new(DIM_ACTOR_TYPE, NULL));
}

void 
dim_actor_set_background_color(DimActor *self, const ClutterColor *color)
{
	DimActorPrivate *priv;

	g_return_if_fail(IS_DIM_ACTOR(self));

	priv = DIM_ACTOR_TYPE_GET_PRIVATE(self);

	if (clutter_color_equal(color, &priv->bg_color))
	{
		return;
	}
	else
	{
		priv->bg_color.red = color->red;
		priv->bg_color.green = color->green;
		priv->bg_color.blue = color->blue;
		priv->bg_color.alpha = color->alpha;

		dim_actor_update(self);
	}
}

void 
dim_actor_add_transparent_area(DimActor *self, float x, float y, float width, float height)
{
	DimActorPrivate *priv;

	g_return_if_fail(IS_DIM_ACTOR(self));

	priv = DIM_ACTOR_TYPE_GET_PRIVATE(self);

	ClutterRect *holeRect = g_new0(ClutterRect, 1);
	holeRect->origin.x = x;
	holeRect->origin.y = y;
	holeRect->size.width = width;
	holeRect->size.height = height;

	priv->hole_rects = 
		g_list_append(priv->hole_rects, holeRect);

	dim_actor_update(self);
}

void 
dim_actor_clear_transparent_area(DimActor *self)
{
	DimActorPrivate *priv;

	g_return_if_fail(IS_DIM_ACTOR(self));

	priv = DIM_ACTOR_TYPE_GET_PRIVATE(self);

	g_list_free_full(priv->hole_rects, 
		(GDestroyNotify)hole_rect_free);
	priv->hole_rects = NULL;

	dim_actor_update(self);
}