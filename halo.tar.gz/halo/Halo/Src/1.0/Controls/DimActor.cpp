#define CLUTTER_ENABLE_EXPERIMENTAL_API
#define COGL_ENABLE_EXPERIMENTAL_API

#include "VoltActor.h"
#include "DimActor.h"


G_DEFINE_TYPE(DimActor, dim_actor, VOLT_ACTOR_TYPE);

/* macro for accessing the object's private structure */
#define DIM_ACTOR_TYPE_GET_PRIVATE(obj) \
	(G_TYPE_INSTANCE_GET_PRIVATE((obj), DIM_ACTOR_TYPE, DimActorPrivate))

static const ClutterColor grey = { 0, 0, 0, 150 };

struct _DimActorPrivate
{
	ClutterColor bg_color;

	GList *hole_rects;
};

static void
hole_rect_free(ClutterRect *rect)
{
	g_free(rect);
}

static void
dim_actor_dispose(GObject* gobject)
{
	DimActorPrivate* priv = DIM_ACTOR(gobject)->priv;

	g_list_free_full(priv->hole_rects, 
		(GDestroyNotify)hole_rect_free);
	priv->hole_rects = NULL;

	/* call the parent class' dispose() method */
	G_OBJECT_CLASS(dim_actor_parent_class)->dispose(gobject);
}


static void
dim_actor_finalize(GObject *gobject)
{
	/* call the parent class' finalize() method */
	G_OBJECT_CLASS(dim_actor_parent_class)->finalize(gobject);
}

static void
dim_actor_paint_node(ClutterActor *actor, ClutterPaintNode *root)
{
	//CLUTTER_ACTOR_GET_CLASS(dim_actor_parent_class)->paint_node(actor, root);

	DimActor* dimActor = DIM_ACTOR(actor);
	DimActorPrivate *priv = dimActor->priv;

	ClutterPaintNode *node;
	ClutterColor color;

	color = priv->bg_color;
	color.alpha = clutter_actor_get_paint_opacity(actor)
		* priv->bg_color.alpha
		/ 255;

	node = clutter_color_node_new(&color);
	clutter_paint_node_set_name(node, "solidColor");

	cogl_path_new();

	cogl_path_rectangle(0, 0, volt_actor_get_width(VOLT_ACTOR(actor)), volt_actor_get_height(VOLT_ACTOR(actor)));

	GList *l;
	for (l = priv->hole_rects; l != NULL; l = l->next)
	{
		ClutterRect *rect = (ClutterRect*)l->data;
		cogl_path_rectangle(rect->origin.x, rect->origin.y, rect->origin.x + rect->size.width, rect->origin.y + rect->size.height);
	}

	CoglPath* path = cogl_get_path();
	clutter_paint_node_add_path(node, path);
	clutter_paint_node_add_child(root, node);
	clutter_paint_node_unref(node);
}

#if !defined(WIN32) && !defined(LINUX_BUILD)
void
 dim_actor_copy_new(ClutterActor* source, ClutterActor* dest)
 {
   DimActorPrivate* dimSrcActorPriv = DIM_ACTOR(source)->priv;
   DimActorPrivate* dimDstActorPriv = DIM_ACTOR(dest)->priv;
   
   clutter_color_init(&dimDstActorPriv->bg_color, dimSrcActorPriv->bg_color.red, dimSrcActorPriv->bg_color.green,
					  dimSrcActorPriv->bg_color.blue, dimSrcActorPriv->bg_color.alpha);
   if (dimDstActorPriv->hole_rects != NULL)
  {
	g_list_free_full(dimDstActorPriv->hole_rects,(GDestroyNotify)hole_rect_free);
	dimDstActorPriv->hole_rects = NULL;
  }
  
  if (dimSrcActorPriv->hole_rects != NULL)
  {
    GList *l;
	for (l = dimSrcActorPriv->hole_rects; l != NULL; l = l->next)
	{
	  ClutterRect *srcholeRect = (ClutterRect*)l->data;
	  ClutterRect *dstholeRect = g_new0(ClutterRect, 1);
	  
	  dstholeRect->origin.x = srcholeRect->origin.x;
	  dstholeRect->origin.y = srcholeRect->origin.y;
	  dstholeRect->size.width = srcholeRect->size.width;
	  dstholeRect->size.height = srcholeRect->size.height;

	  dimDstActorPriv->hole_rects = 
		g_list_append(dimDstActorPriv->hole_rects, dstholeRect);
	}
  }
   volt_actor_copy_new(source, dest);
 }
 
static void
dim_actor_clone_for_render_thread (ClutterActor  *self)
{
	if(self->copy_actor == NULL)
	{
		self->copy_actor = dim_actor_new();
	}
	dim_actor_copy_new(self, self->copy_actor);
}
#endif

static void
dim_actor_class_init(DimActorClass *klass)
{
	ClutterActorClass *actor_class = CLUTTER_ACTOR_CLASS(klass);
	actor_class->paint_node = dim_actor_paint_node;
#if !defined(WIN32) && !defined(LINUX_BUILD)
	actor_class->clone_for_render_thread = dim_actor_clone_for_render_thread;
#endif
	GObjectClass *gobject_class = G_OBJECT_CLASS(klass);

	gobject_class->dispose = dim_actor_dispose;
	gobject_class->finalize = dim_actor_finalize;

	g_type_class_add_private(klass, sizeof (DimActorPrivate));
}


static void
dim_actor_init(DimActor *self)
{
	DimActorPrivate *priv;

	priv = self->priv = DIM_ACTOR_TYPE_GET_PRIVATE(self);

	priv->bg_color = grey;
	priv->hole_rects = NULL;
}

/* called each time a property is set on the effect */
static void
dim_actor_update(DimActor *self)
{
	clutter_actor_queue_redraw(CLUTTER_ACTOR(self));
}

/**
* dim_actor_new:
*
* Creates a new #DimActor instance
*
* Returns: a new #DimActor
*/
ClutterActor *
dim_actor_new(void)
{
	return CLUTTER_ACTOR(g_object_new(DIM_ACTOR_TYPE, NULL));
}

void 
dim_actor_set_background_color(DimActor *self, const ClutterColor *color)
{
	DimActorPrivate *priv;

	g_return_if_fail(IS_DIM_ACTOR(self));

	priv = DIM_ACTOR_TYPE_GET_PRIVATE(self);

	if (clutter_color_equal(color, &priv->bg_color))
	{
		return;
	}
	else
	{
		priv->bg_color.red = color->red;
		priv->bg_color.green = color->green;
		priv->bg_color.blue = color->blue;
		priv->bg_color.alpha = color->alpha;

		dim_actor_update(self);
	}
}

void 
dim_actor_add_transparent_area(DimActor *self, float x, float y, float width, float height)
{
	DimActorPrivate *priv;

	g_return_if_fail(IS_DIM_ACTOR(self));

	priv = DIM_ACTOR_TYPE_GET_PRIVATE(self);

	ClutterRect *holeRect = g_new0(ClutterRect, 1);
	holeRect->origin.x = x;
	holeRect->origin.y = y;
	holeRect->size.width = width;
	holeRect->size.height = height;

	priv->hole_rects = 
		g_list_append(priv->hole_rects, holeRect);

	dim_actor_update(self);
}

void 
dim_actor_clear_transparent_area(DimActor *self)
{
	DimActorPrivate *priv;

	g_return_if_fail(IS_DIM_ACTOR(self));

	priv = DIM_ACTOR_TYPE_GET_PRIVATE(self);

	g_list_free_full(priv->hole_rects, 
		(GDestroyNotify)hole_rect_free);
	priv->hole_rects = NULL;

	dim_actor_update(self);
}