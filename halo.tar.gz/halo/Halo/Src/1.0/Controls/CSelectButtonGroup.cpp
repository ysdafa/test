#include "Halo1_0.h"

namespace HALO
{
	class CSelectButtonGroupListenerSet : public ListenerSet
	{
	public:
		struct TSelectButtonGroupListenerData
		{
			int type;
			int param[2];	
			ISelectButton* checkcontrol;
			void* pData;
		};

		CSelectButtonGroupListenerSet(CSelectButtonGroup* owner) :m_owner(owner){}
		virtual ~CSelectButtonGroupListenerSet(void){}

		virtual bool Process(TSelectButtonGroupListenerData* data);

	private:
		CSelectButtonGroup* m_owner;
	};

	bool CSelectButtonGroupListenerSet::Process(TSelectButtonGroupListenerData* data)
	{
		bool ret = false;
		Lock();
		if (NULL != data)
		{
			ListenerList::iterator iter = m_list.begin();

			while (iter != m_list.end())
			{
				OnCheckedChangedListener* listener = (OnCheckedChangedListener*)(*iter);

				ret |= listener->OnCheckChanged(m_owner, data->param[0], data->param[1] , data->checkcontrol);
				if (m_list.empty())
				{
					break;
				}
				iter++;
			}
		}
		Unlock();
		return ret;
	}
	int CSelectButtonGroup::AddButton( ISelectButton *checkContorl )
	{
		HALO_ASSERT(NULL != checkContorl);
		t_itemList.push_back(checkContorl);
		m_itemIndex ++;
		checkContorl->SetId(m_itemIndex);
		t_itemNum ++;
		checkContorl->AddListener(this);
		t_AddNoticeActor(checkContorl);
		return m_itemIndex;
	}

	void CSelectButtonGroup::RemoveButton( ISelectButton *checkContorl )
	{
		HALO_ASSERT(NULL != checkContorl);
		std::vector<ISelectButton*>::iterator it_pos;
		for (it_pos = t_itemList.begin();it_pos != t_itemList.end();it_pos ++)
		{
			if (checkContorl == *it_pos)
			{
				t_itemList.erase(it_pos);
				t_itemNum --;
				return;
			}
		}
		
	}

	ISelectButton* CSelectButtonGroup::GetItemById( int itemId )
	{
		ASSERT(itemId < t_itemNum && itemId > 0);
		return t_itemList[itemId - 1];	
	}

	void HALO::CSelectButtonGroup::SetDefaultFocus( int itemId )
	{
		ASSERT(itemId <= t_itemNum && itemId > 0);
		t_itemList[itemId - 1]->SetFocus();
	}

	int CSelectButtonGroup::NumofItem()
	{
		return t_itemNum;
	}

	CSelectButtonGroup::CSelectButtonGroup()
	{
		t_pSelectButtonGroupListenerSet = NULL;
	}

	CSelectButtonGroup::~CSelectButtonGroup()
	{
		m_Destory();
	}
	void CSelectButtonGroup::m_Destory()
	{
		if (NULL != t_pSelectButtonGroupListenerSet)
		{
			//delete t_pSelectButtonGroupListenerSet;
			if (t_pSelectButtonGroupListenerSet->IsLocked())
			{
				t_pSelectButtonGroupListenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(t_pSelectButtonGroupListenerSet);
			} 
			else
			{
				delete t_pSelectButtonGroupListenerSet;
			}

			t_pSelectButtonGroupListenerSet = NULL;
		}
		t_itemList.clear();
	}

	bool CSelectButtonGroup::AddListener( OnCheckedChangedListener *listener )
	{
		HALO_ASSERT(NULL != listener);

		return t_pSelectButtonGroupListenerSet->Add(listener);
	}

	bool CSelectButtonGroup::RemoveListener(OnCheckedChangedListener *listener)
	{
		HALO_ASSERT(NULL != listener);

		return t_pSelectButtonGroupListenerSet->Remove(listener);
	}

	const char* CSelectButtonGroup::GetActorType(void)
	{
		return "BaseSelectButton";
	}

	void CSelectButtonGroup::OnCheckedChanged( class ISelectButton* button , bool ischecked )
	{
		CSelectButtonGroupListenerSet::TSelectButtonGroupListenerData data;
		data.param[0] = button->GetId();
		data.param[1] = ischecked;
		data.checkcontrol = button;
		t_ProcessSelect(button , ischecked);
		t_pSelectButtonGroupListenerSet->Process(&data);
	}

	bool CSelectButtonGroup::t_Initialize()
	{
		t_itemNum = 0;
		m_itemIndex = 0;
		t_itemW = 0;
		t_itemH = 0;
		t_pSelectButtonGroupListenerSet = new class CSelectButtonGroupListenerSet(this);
		CActor::Initialize((Widget*)NULL, 0,0);
		return true;
	}

	void CSelectButtonGroup::SetDefaultSelectedItem( int itemId )
	{
		HALO_ASSERT(itemId < t_itemNum && itemId > 0);
		t_itemList[itemId - 1]->SetCheck(true);
	}




}
