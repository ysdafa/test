#ifndef _HALO_CPAGECONTROL_H_
#define _HALO_CPAGECONTROL_H_

namespace HALO
{
	class CPageControl : virtual public IPageControl, public CActor
	{
	public:
		CPageControl();

		virtual ~CPageControl();

		virtual bool Initialize(IActor* parent, float width, float height);
		virtual bool Initialize(Widget* parent, float width, float height);

	public:
		virtual int CurrentPage() const;
		virtual void SetCurrentPage(int curPage);

		virtual int NumberOfPages() const;
		virtual void SetNumberOfPages(int numPages);

		virtual void SetPageIndicatorImage(IImageBuffer *imageBuffer);
		virtual void SetHighlightPageIndicatorImage(IImageBuffer *imageBuffer);

		virtual void SetPageIndicatorGap(float indicatorGap);
		virtual float PageIndicatorGap(void);

		virtual void SetHideForSinglePageFlag(bool hideFlag);
		virtual bool FlagHideForSinglePage();

		virtual void SetPageIndicatorImageSize(float width, float height);
		virtual void PageIndicatorImageSize(float &width, float &height);

		virtual const char* GetActorType(void);

	private:
		int m_currentPage;
		float m_indicatorGap;
		bool m_bHideForSinglePage;
		std::vector<IImage *> m_indicatorImages;

		IImageBuffer* m_pageIndicatorImageBuffer;
		IImageBuffer* m_highlightPageIndicatorImageBuffer;
		float m_pageIndicatorImageWidth;
		float m_pageIndicatorImageHeight;

	private:
		void m_StateChanged();
	};
}

#endif	// CPAGECONTROL1_0_H
