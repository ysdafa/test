#include "Halo1_0.h"

#if !defined(WIN32) && !defined(LINUX_BUILD)
#include "TTSEngine.h"
#endif

namespace HALO
{
	static HALO::util::Logger LOGGER("Thumbnail");

	/*CThumbnailListenerSet*/
	class CThumbnailListenerSet : public ListenerSet
	{
	public:
		struct TThumbListenerData
		{
			int type;
			int param[4];
			void* pData;
		};

		CThumbnailListenerSet(CThumbnail* owner) :m_owner(owner){}
		virtual ~CThumbnailListenerSet(void){};

		virtual bool Process(TThumbListenerData* data);

	private:
		CThumbnail* m_owner;
	};

	bool CThumbnailListenerSet::Process(TThumbListenerData* data)
	{
		bool ret = false;
		Lock();
		if (NULL != data)
		{
			ListenerList::iterator iter = m_list.begin();

			while (iter != m_list.end())
			{
				IThumbnailListener* listener = (IThumbnailListener*)(*iter);

				switch (data->type)
				{
				case CThumbnail::EVENT_IMAGE_READY:
					H_LOG_TRACE(LOGGER, "[" << m_owner << "] Image" << data->param[0]<< " is loaded. success: " << data->param[1]);
					ret |= listener->OnImageReady(m_owner, data->param[0], data->param[1]);
					H_LOG_TRACE(LOGGER, "[" << m_owner << "] OnImageReady.Listener--end");
					break;
				case CThumbnail::EVENT_INFO_ICON_READY:
					H_LOG_TRACE(LOGGER, "[" << m_owner << "] Info Icon" << data->param[0] << " is loaded. success: " << data->param[1]);
					ret |= listener->OnInformationIconReady(m_owner, data->param[0], data->param[1]);
					H_LOG_TRACE(LOGGER, "[" << m_owner << "] OnInformationIconReady.Listener--end");
					break;
				case CThumbnail::EVENT_ATTACH_ICON_READY:
					H_LOG_TRACE(LOGGER, "[" << m_owner << "] Attach Icon" << data->param[0] << " is loaded. success: " << data->param[1]);
					ret |= listener->OnAttachIconReady(m_owner, data->param[0], data->param[1]);
					H_LOG_TRACE(LOGGER, "[" << m_owner << "] OnAttachIconReady.Listener--end");
					break;
				case CThumbnail::EVENT_SCROLLIMAGE_READY:
					H_LOG_TRACE(LOGGER, "[" << m_owner << "] Scroll Image" << data->param[0] << " is loaded. success: " << data->param[1]);
					ret |= listener->OnScrollImageReady(m_owner, data->param[0], data->param[1]);
					H_LOG_TRACE(LOGGER, "[" << m_owner << "] OnScrollImageReady.Listener--end");
					break;
				case CThumbnail::EVENT_ICON_CLICKED:
					H_LOG_TRACE(LOGGER, "[" << m_owner << "] Icon" << data->param[0] << " is clicked");
					ret |= listener->OnIconClicked(m_owner, data->param[0]);
					H_LOG_TRACE(LOGGER, "[" << m_owner << "] OnIconClicked.Listener--end");
					break;
				case CThumbnail::EVENT_CHECK_STATE_CHANGED:
					H_LOG_TRACE(LOGGER, "[" << m_owner << "] CheckMark state change to " << data->param[0]);
					ret |= listener->OnCheckMarkStateChanged(m_owner, data->param[0]);
					H_LOG_TRACE(LOGGER, "[" << m_owner << "] OnCheckMarkStateChanged.Listener--end" << data->param[0]);
					break;
				case CThumbnail::EVENT_PROGRESS_VALUE_CHANGED:
					H_LOG_TRACE(LOGGER, "[" << m_owner << "] OnProgressValueChanged. To:" << data->param[0]);
					ret |= listener->OnProgressValueChanged(m_owner, data->param[0]);
					break;

				default:
					break;
				}
				if (m_list.empty())
				{
					break;
				}
				iter++;
			}
		}

		Unlock();
		return ret;
	}

	/*CThumbnail*/
	CThumbnail::CThumbnail() :
		m_styles(0),
		m_visibleStyles(0),
		m_infoStyles(0),
		m_utility(NULL),
		m_dimWin(NULL),
		m_dimUseImage(false),
		m_defalut(NULL),
		m_flagEnlarge(false),
		m_flagHighContrast(false),
		m_enabled(true),
		m_fontScaleEnabled(false),
		m_fontScaleFactor(1.0f),
		m_isHighlighted(false),
		m_scaleAni(NULL),
		m_styleTransAni(NULL),
		m_listenerSet(NULL),
		m_scrollPlayer(NULL),
		m_scrollPlayerAsyncLoad(true),
		m_scrollDataSource(NULL),
		m_scrollPlayerHandler(NULL)
	{
		m_scaleAniMode = CLUTTER_EASE_IN_OUT_CUBIC;
		m_scaleAniDuration = 100;
		m_styleTransAniMode = CLUTTER_EASE_IN_OUT_CUBIC;
		m_styleTransAniDuration = 100;
		m_foveaImageScaleFactor = 0.1f;
		m_foveaImageInterpolatorType = 0;
		m_foveaInfoBoxScaleFactor = 0.06f;
		m_foveaInfoBoxInterpolatorType = 0;
		
#if !defined(WIN32) && !defined(LINUX_BUILD)
		m_videoActor = NULL;
#endif
	}

	CThumbnail::~CThumbnail()
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		if (m_listenerSet)
		{
			//delete m_listenerSet;
			if (m_listenerSet->IsLocked())
			{
				m_listenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(m_listenerSet);
			} 
			else
			{
				delete m_listenerSet;
			}

			m_listenerSet = NULL;
		}
		
		if (m_scaleAni)
		{
			m_scaleAni->Release();
			m_scaleAni = NULL;
		}
		if (m_styleTransAni)
		{
			m_styleTransAni->Release();
			m_styleTransAni = NULL;
		}
				
		if (m_dimWin)
		{
			delete m_dimWin;
			m_dimWin = NULL;
		}
		
		if (m_defalut)
		{
			delete m_defalut;
			m_defalut = NULL;
		}
		
		if (m_styles & THUMB_STYLE_IMAGE)
		{
			m_DestroyContent();
		}
		if (m_styles & THUMB_STYLE_ICON)
		{
			while (m_attachIcons.size() != 0)
			{
				m_DestroyAttachIcon(0);
			}
		}
		if (m_styles & THUMB_STYLE_TEXT)
		{
			m_DestroyAttachText();
		}
		if (m_styles & THUMB_STYLE_PROGRESSBAR)
		{
			m_DestroyProgressBar();
		}
		if (m_styles & THUMB_STYLE_CHECKBOX)
		{
			m_DestroyCheckBox();
		}

		if (m_styles & THUMB_STYLE_INFO)
		{
			m_DestroyInfo();
		}
		if (m_styles & THUMB_STYLE_SCROLLPLAYER)
		{
			m_DestroyScrollPlayer();
		}
		if (m_styles & THUMB_STYLE_VIDEO)
		{
#if !defined(WIN32) && !defined(LINUX_BUILD)
			m_DestroyVideoActor();
#endif
		}
		
	}

	bool CThumbnail::Initialize(Widget* parent, float width, float height, EThumbnailStyles styles, EThumbnailStyles visibleStyles, const TThumbnailAttr& attr)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]" << " parent(" << parent << ") width(" << width << ") height(" << height <<") styles(" << styles << ") visibleStyles(" << visibleStyles <<")");
		CActor::Initialize(parent, width, height);

		if (m_utility = IUtility::GetInstance())
		{
			m_flagEnlarge = m_utility->IsEnlargeEnabled();
			m_flagHighContrast = m_utility->IsHighContrastEnabled();
		}

		m_listenerSet = new class CThumbnailListenerSet(this);

		m_scaleAni = new CMultiObjectTransition;
		m_scaleAni->Initialize();
		m_scaleAni->SetDuration(m_scaleAniDuration);
		m_scaleAni->SetMode(m_scaleAniMode);

		m_styleTransAni = new CMultiObjectTransition;
		m_styleTransAni->Initialize();
		m_styleTransAni->SetDuration(m_styleTransAniDuration);
		m_styleTransAni->SetMode(m_styleTransAniMode);

		if (styles & THUMB_STYLE_IMAGE)
		{
			m_CreateContent(attr.imageInfo);
		}
		if (styles & THUMB_STYLE_INFO)
		{
			m_CreateInfo(attr.info, attr.infoStyle);
		}
		if (styles & THUMB_STYLE_ICON)
		{
			int attachIconNum = attr.attachIconInfos.size();
			for (int i = 0; i < attachIconNum; i++)
			{
				m_CreateAttachIcon(attr.attachIconInfos[i]);
			}
		}
		if (styles & THUMB_STYLE_TEXT)
		{
			m_CreateAttachText(attr.attachTextInfo);
		}

		if (styles & THUMB_STYLE_PROGRESSBAR)
		{
			m_CreateProgressBar(attr.progressBar);
		}
		if (styles & THUMB_STYLE_CHECKBOX)
		{
			m_CreateCheckBox(attr.checkBox);
		}
		if (styles & THUMB_STYLE_SCROLLPLAYER)
		{
			m_CreateScrollPlayer(attr.scrollPlayerInfo);
		}
		if (styles & THUMB_STYLE_VIDEO)
		{
#if !defined(WIN32) && !defined(LINUX_BUILD)
			m_CreateVideoActor(attr.videoActorInfo);
#endif
		}

		if ((styles & THUMB_STYLE_IMAGE) && !m_content.image.isReady && !attr.imageInfo.defaultSrc.empty())
		{
			m_defalut = new CImageWidgetEx(0, 0, getWidth(), getHeight(), this);
			m_SetId(m_defalut, "default-image");
			m_defalut->setFillMode(ImageWidget::Center);
			m_defalut->setAsyncLoading(false);
			m_defalut->setSource(attr.imageInfo.defaultSrc);
		}

		this->EnableThumbnailStyles(true, visibleStyles, false);

		m_dimWin = new CImageWidgetEx(0, 0, this);
		m_SetId(m_dimWin, "dim-win");
		Color color(0, 0, 0, 150);
		m_dimWin->setColor(color);
		m_dimWin->hide();

		return true;
	}

	bool CThumbnail::AddThumbnailListener(IThumbnailListener *listener)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] listener(" << listener << ")");
		HALO_ASSERT(listener != NULL);

		return m_listenerSet->Add(listener);
	}

	bool CThumbnail::RemoveThumbnailListener(IThumbnailListener *listener)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] listener(" << listener << ")");
		HALO_ASSERT(listener != NULL);

		return m_listenerSet->Remove(listener);
	}

	bool CThumbnail::OnMouseEvent(EMouseEventType eventType, IMouseEvent* pMouseEvent)
	{
		return false;
	}

	void CThumbnail::SetThumbnailStyle(EThumbnailStyles styles, EThumbnailStyles visibleStyles, const TThumbnailAttr& attr, bool flagAni)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] styles(" << styles << ") visibleStyles(" << visibleStyles <<") flagAni(" << flagAni <<")");
		if (styles == 0)
		{
			setGradientFill(true);
		}
		else if (m_styles == 0)
		{
			setGradientFill(false);
		}

		if ((styles & THUMB_STYLE_IMAGE) && !(m_styles & THUMB_STYLE_IMAGE))
		{
			m_CreateContent(attr.imageInfo);
		}
		else if (!(styles & THUMB_STYLE_IMAGE) && (m_styles & THUMB_STYLE_IMAGE))
		{
			m_DestroyContent();
		}
		else if ((styles & THUMB_STYLE_IMAGE) && (m_styles & THUMB_STYLE_IMAGE))
		{
			m_content.image.widget->setFillMode(attr.imageInfo.fillMode);
			if (m_content.image.widget->getSource() != attr.imageInfo.src)
			{
				H_LOG_TRACE(LOGGER, "[" << this << "] Reset image source. async(" << attr.imageInfo.async << ") src(" << attr.imageInfo.src.c_str() << ")");
				// reset image source , need reset color picking
				m_content.image.isReady = false;
				m_info.colorPickingReady = false;
				m_attachText.colorPickingReady = false;
				m_content.image.widget->setAsyncLoading(attr.imageInfo.async);
				m_content.image.widget->setSource(attr.imageInfo.src);
			}
			m_content.root->Resize(attr.imageInfo.alloc.w, attr.imageInfo.alloc.h);
			m_content.root->SetPosition(attr.imageInfo.alloc.x, attr.imageInfo.alloc.y);

			TValue2f destSize(attr.imageInfo.alloc.w, attr.imageInfo.alloc.h);
			m_styleTransAni->SetDestination(m_content.image.widget, IActor::ACTOR_ANI_SIZE, &destSize);
		}
		// parse information
		if ((styles & THUMB_STYLE_INFO) && !(m_styles & THUMB_STYLE_INFO))
		{
			m_CreateInfo(attr.info, attr.infoStyle);
		}
		else if (!(styles & THUMB_STYLE_INFO) && (m_styles & THUMB_STYLE_INFO))
		{
			m_DestroyInfo();
		}
		else if ((styles & THUMB_STYLE_INFO) && (m_styles & THUMB_STYLE_INFO))
		{
			// update info background color
			if (attr.info.colorPickingRange != m_info.colorPickingRange)
			{
				m_info.colorPickingReady = false;
			}
			m_info.colorPickingRange = attr.info.colorPickingRange;
			m_info.useReferenceColor = attr.info.useRefereceColor;
			if (!m_flagHighContrast)
			{
				if (!m_info.useReferenceColor)
				{
					 m_SetInfoBgColor(attr.info.backgroundColor);
				}
				else if (m_info.colorPickingReady)
				{
					 m_SetInfoBgColor(m_info.bgColorPicking);
				}
				else if (m_content.image.isReady)
				{
					m_ResetInfoTextColor(m_content.image.widget);
				}
			}
			else
			{
				 m_SetInfoBgColor(attr.info.highContrastInfo.backgroundColor);
			}
			m_info.bgColor = attr.info.backgroundColor;
			// for enlarge
			m_info.enlargeFactor = attr.info.enlargeFactor;
			m_info.anchorPoint = attr.info.anchorPoint;
			// for high contrast
			m_info.alloc = attr.info.alloc;
			m_info.hc_bgColor = attr.info.highContrastInfo.backgroundColor;

			int yOffset = 0;
			if (m_flagEnlarge && (m_info.anchorPoint == ANCHOR_BOTTOM))
			{
				yOffset = m_info.alloc.h * (1 - m_info.enlargeFactor);
			}
			// update info allocation
			TValue2f destPos(attr.info.alloc.x, attr.info.alloc.y + yOffset);
			m_styleTransAni->SetDestination(m_info.root, IActor::ACTOR_ANI_POSITION, &destPos);
			TValue2f destSize(attr.info.alloc.w, m_flagEnlarge ? m_info.alloc.h * m_info.enlargeFactor : attr.info.alloc.h);
			m_styleTransAni->SetDestination(m_info.root, IActor::ACTOR_ANI_SIZE, &destSize);

			// update info icons
			int oldInfoIconNum = m_info.icons.size();
			int newInfoIconNum = attr.info.iconInfos.size();
			int i = 0;
			for (i = 0; i < newInfoIconNum; i++)
			{
				if (i >= oldInfoIconNum)
				{
					m_CreateInfoIcon(attr.info.iconInfos[i]);
				}
				else
				{
					const TIconInfo &iconInfo = attr.info.iconInfos[i];
					m_ModifyIcon(m_info.icons[i]->widget, iconInfo);
					m_info.icons[i]->alloc = iconInfo.alloc;
					if (m_flagEnlarge)
					{
						m_info.icons[i]->widget->setY(iconInfo.alloc.y * m_info.enlargeFactor);
					}
				}
			}

			if (i < oldInfoIconNum)
			{
				while ((int)m_info.icons.size() > i)
				{
					m_DestroyInfoIcon(i);
				}
			}

			// update info rating
			if ((attr.infoStyle & THUMB_INFO_STYLE_RATING) && !(m_infoStyles & THUMB_INFO_STYLE_RATING))
			{
				m_CreateInfoRating(attr.info.ratingInfo);
			}
			else if (!(attr.infoStyle & THUMB_INFO_STYLE_RATING) && (m_infoStyles & THUMB_INFO_STYLE_RATING))
			{
				m_DestroyInfoRating();
			}
			else if ((attr.infoStyle & THUMB_INFO_STYLE_RATING) && (m_infoStyles & THUMB_INFO_STYLE_RATING))
			{
				m_info.rating->widget->SetPosition(attr.info.ratingInfo.alloc.x, attr.info.ratingInfo.alloc.y);
				m_info.rating->widget->Resize(attr.info.ratingInfo.alloc.w, attr.info.ratingInfo.alloc.h);

				m_info.rating->onImage = m_CreateRatingImage(attr.info.ratingInfo.onName);
				m_info.rating->offImage = m_CreateRatingImage(attr.info.ratingInfo.offName);
				m_info.rating->halfImage = m_CreateRatingImage(attr.info.ratingInfo.halfName);

				m_info.rating->alloc = attr.info.ratingInfo.alloc;
				m_UpdateInfoRating(attr.info.ratingInfo.value);
				if (m_flagEnlarge)
				{
					m_info.rating->widget->SetPosition(attr.info.ratingInfo.alloc.x, attr.info.ratingInfo.alloc.y * m_info.enlargeFactor);
				}
			}

			// update info texts
			int oldInfoTextNum = m_info.texts.size();
			int newInfoTextNum = attr.info.textInfos.size();
			i = 0;
			for (i = 0; i < newInfoTextNum; i++)
			{
				if (i >= oldInfoTextNum)
				{
					m_CreateInfoText(attr.info.textInfos[i]);
				}
				else
				{
					const TTextInfo &textInfo = attr.info.textInfos[i];
					m_InitInfoText(m_info.texts[i], textInfo);
				}
			}

			if (i < oldInfoTextNum)
			{
				while ((int)m_info.texts.size() > i)
				{
					m_DestroyInfoText(i);
				}
			}
		}
		
		// parse attach icons
		if ((styles & THUMB_STYLE_ICON) && !(m_styles & THUMB_STYLE_ICON))
		{
			int attachIconNum = attr.attachIconInfos.size();
			for (int i = 0; i < attachIconNum; i++)
			{
				m_CreateAttachIcon(attr.attachIconInfos[i]);
			}
		}
		else if (!(styles & THUMB_STYLE_ICON) && (m_styles & THUMB_STYLE_ICON))
		{
			while (m_attachIcons.size() != 0)
			{
				m_DestroyAttachIcon(0);
			}
		}
		else if ((styles & THUMB_STYLE_ICON) && (m_styles & THUMB_STYLE_ICON))
		{
			int oldAttachIconNum = m_attachIcons.size();
			int newAttachIconNum = attr.attachIconInfos.size();
			int i = 0;
			for (i = 0; i < newAttachIconNum; i++)
			{
				if (i >= oldAttachIconNum)
				{
					m_CreateAttachIcon(attr.attachIconInfos[i]);
				}
				else
				{
					const TIconInfo &iconInfo = attr.attachIconInfos[i].iconInfo;
					m_ModifyIcon(m_attachIcons[i]->widget, iconInfo);

					m_attachIcons[i]->widget->EnableReverse(attr.attachIconInfos[i].reversible);

					if (iconInfo.clickable && !m_attachIcons[i]->clickable)
					{
						m_attachIcons[i]->mousePressedHandle = m_attachIcons[i]->widget->registerMouseEvent(Widget::MOUSE_DOWN, m_RegisterMouseEventCallback(m_mousePressedCallback));
						m_attachIcons[i]->mouseReleaseHandle = m_attachIcons[i]->widget->registerMouseEvent(Widget::MOUSE_UP, m_RegisterMouseEventCallback(m_mouseReleaseCallback));
						m_attachIcons[i]->mouseClickedHandle = m_attachIcons[i]->widget->registerMouseEvent(Widget::MOUSE_CLICK, m_RegisterMouseEventCallback(m_mouseClickedCallback));
					}
					else if (!iconInfo.clickable && m_attachIcons[i]->clickable)
					{
						m_attachIcons[i]->widget->unregisterMouseEvent(Widget::MOUSE_DOWN, m_attachIcons[i]->mousePressedHandle);
						m_attachIcons[i]->widget->unregisterMouseEvent(Widget::MOUSE_UP, m_attachIcons[i]->mouseReleaseHandle);
						m_attachIcons[i]->widget->unregisterMouseEvent(Widget::MOUSE_CLICK, m_attachIcons[i]->mouseClickedHandle);
					}

					m_attachIcons[i]->unpressName = iconInfo.unpressName;
					m_attachIcons[i]->pressedNmae = iconInfo.pressedName;
				}
			}

			if (i < oldAttachIconNum)
			{
				while ((int)m_attachIcons.size() > i)
				{
					m_DestroyAttachIcon(i);
				}
			}
		}
		// parse attach text
		if ((styles & THUMB_STYLE_TEXT) && !(m_styles & THUMB_STYLE_TEXT))
		{
			m_CreateAttachText(attr.attachTextInfo);
		}
		else if (!(styles & THUMB_STYLE_TEXT) && (m_styles & THUMB_STYLE_TEXT))
		{
			m_DestroyAttachText();
		}
		else if ((styles & THUMB_STYLE_TEXT) && (m_styles & THUMB_STYLE_TEXT))
		{
			const TTextInfo &textInfo = attr.attachTextInfo.textInfo;
			m_ModifyText(m_attachText.widget, textInfo);
			// update attach text color
			m_attachText.textColor = textInfo.textColor;
			if (!textInfo.textColor.isTransparent())
			{
				m_attachText.widget->SetTextColor(*textInfo.textColor.toClutterColor());
			}
			else if (m_info.colorPickingReady)
			{
				m_attachText.widget->SetTextColor(m_info.fgColorExtracted);
			}
		}
		// parse attach progress bar
		if ((styles & THUMB_STYLE_PROGRESSBAR) && !(m_styles & THUMB_STYLE_PROGRESSBAR))
		{
			m_CreateProgressBar(attr.progressBar);
		}
		else if (!(styles & THUMB_STYLE_PROGRESSBAR) && (m_styles & THUMB_STYLE_PROGRESSBAR))
		{
			m_DestroyProgressBar();
		}
		else if ((styles & THUMB_STYLE_PROGRESSBAR) && (m_styles & THUMB_STYLE_PROGRESSBAR))
		{
			m_progressBar.progess->SetPosition(attr.progressBar.alloc.x, attr.progressBar.alloc.y);
			m_progressBar.progess->Resize(attr.progressBar.alloc.w, attr.progressBar.alloc.h);
		}
		// parse attach check box
		if ((styles & THUMB_STYLE_CHECKBOX) && !(m_styles & THUMB_STYLE_CHECKBOX))
		{
			m_CreateCheckBox(attr.checkBox);
		}
		else if (!(styles & THUMB_STYLE_CHECKBOX) && (m_styles & THUMB_STYLE_CHECKBOX))
		{
			m_DestroyCheckBox();
		}
		else if ((styles & THUMB_STYLE_CHECKBOX) && (m_styles & THUMB_STYLE_CHECKBOX))
		{
			m_checkMark.widget->SetPosition(attr.checkBox.alloc.x, attr.checkBox.alloc.y);
			m_checkMark.widget->Resize(attr.checkBox.alloc.w, attr.checkBox.alloc.h);
		}
		// parse scroll player
		if ((styles & THUMB_STYLE_SCROLLPLAYER) && !(m_styles & THUMB_STYLE_SCROLLPLAYER))
		{
			m_CreateScrollPlayer(attr.scrollPlayerInfo);
		}
		else if (!(styles & THUMB_STYLE_SCROLLPLAYER) && (m_styles & THUMB_STYLE_SCROLLPLAYER))
		{
			m_DestroyScrollPlayer();
		}

		m_styleTransAni->Play();

		EThumbnailStyles disVisibleStyles = m_visibleStyles & (m_visibleStyles ^ visibleStyles);
		EThumbnailStyles newVisibleStyles = (~m_visibleStyles) & (m_visibleStyles ^ visibleStyles);
		newVisibleStyles |= visibleStyles & THUMB_STYLE_ICON ? THUMB_STYLE_ICON : 0;

		this->EnableThumbnailStyles(false, disVisibleStyles, false);
		this->EnableThumbnailStyles(true, newVisibleStyles, false);
	}

	void CThumbnail::EnableThumbnailStyle(bool enable, EThumbnailStyle style, bool flagAni)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] enable(" << enable << ") style(" << style << ") m_styles(" << m_styles << ") flagAni(" << flagAni <<")");
		if (!(m_styles & style))
		{
			return;
		}
		
		EThumbnailStyles _styles = style;
		EnableThumbnailStyles(enable, _styles, flagAni);
	}

	void CThumbnail::EnableThumbnailStyles(bool enable, EThumbnailStyles styles, bool flagAni)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] enable(" << enable << ") styles(" << styles << ") flagAni(" << flagAni <<")");
		if (styles & THUMB_STYLE_IMAGE)
		{
			if (!enable)
			{
				m_visibleStyles &= ~THUMB_STYLE_IMAGE;
				if (m_content.root) { m_content.root->Hide(); }
			}
			else if (m_styles & THUMB_STYLE_IMAGE)
			{
				m_visibleStyles |= THUMB_STYLE_IMAGE;
				if (m_content.root && (NULL == m_defalut)) { m_content.root->Show(); }
			}
		}
		
		if (styles & THUMB_STYLE_INFO)
		{
			if (!enable)
			{
				m_visibleStyles &= ~THUMB_STYLE_INFO;
				if (m_info.root) { m_info.root->hide(); }
			}
			else if (m_styles & THUMB_STYLE_INFO)
			{
				m_visibleStyles |= THUMB_STYLE_INFO;
				if (m_info.root && (NULL == m_defalut)) { m_info.root->show(); }
			}
		}

		if (styles & THUMB_STYLE_ICON)
		{
			if (!enable)
			{
				m_visibleStyles &= ~THUMB_STYLE_ICON;
			}
			else if (m_styles & THUMB_STYLE_ICON)
			{
				m_visibleStyles |= THUMB_STYLE_ICON;
			}
			int attachIconNum = m_attachIcons.size();
			for (int i = 0; i < attachIconNum; i++)
			{
				EnableAttachIcon(enable, i, flagAni);
			}
		}

		if (styles & THUMB_STYLE_TEXT)
		{
			if (!enable)
			{
				m_visibleStyles &= ~THUMB_STYLE_TEXT;
				if (m_attachText.widget) { m_attachText.widget->Hide(); }
			}
			else if (m_styles & THUMB_STYLE_TEXT)
			{
				m_visibleStyles |= THUMB_STYLE_TEXT;
				if (m_attachText.widget && (NULL == m_defalut)) { m_attachText.widget->Show(); }
			}
		}

		if (styles & THUMB_STYLE_PROGRESSBAR)
		{
			if (!enable)
			{
				m_visibleStyles &= ~THUMB_STYLE_PROGRESSBAR;
				if (m_progressBar.progess) { m_progressBar.progess->Hide(); }
			}
			else if (m_styles & THUMB_STYLE_PROGRESSBAR)
			{
				m_visibleStyles |= THUMB_STYLE_PROGRESSBAR;
				if (m_progressBar.progess && (NULL == m_defalut)) { m_progressBar.progess->Show(); }
			}
		}

		if (styles & THUMB_STYLE_CHECKBOX)
		{
			if (!enable)
			{
				m_visibleStyles &= ~THUMB_STYLE_CHECKBOX;
				if (m_checkMark.widget) { m_checkMark.widget->Hide(); }
				SetChecked(false);
			}
			else if (m_styles & THUMB_STYLE_CHECKBOX)
			{
				m_visibleStyles |= THUMB_STYLE_CHECKBOX;
				if (m_checkMark.widget && (NULL == m_defalut)) { m_checkMark.widget->Show(); }
			}
		}

		if (styles & THUMB_STYLE_SCROLLPLAYER)
		{
			if (!enable)
			{
				m_visibleStyles &= ~THUMB_STYLE_SCROLLPLAYER;
				if (m_scrollPlayer) { m_scrollPlayer->Hide(); }
			}
			else if (m_styles & THUMB_STYLE_SCROLLPLAYER)
			{
				m_visibleStyles |= THUMB_STYLE_SCROLLPLAYER;
				if (m_scrollPlayer && (NULL == m_defalut)) { m_scrollPlayer->Show(); }
			}
		}
		
	}

	void CThumbnail::EnableAttachIcon(bool enable, int iconIndex, bool flagAni)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] enable(" << enable << ") iconIndex(" << iconIndex << ") flagAni(" << flagAni << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_ICON);
		HALO_ASSERT(iconIndex >= 0 && iconIndex < (int)m_attachIcons.size());

		if (enable && (NULL == m_defalut))
		{
			m_attachIcons[iconIndex]->widget->show();
		}
		else
		{
			m_attachIcons[iconIndex]->widget->hide();
		}
	}

	void CThumbnail::EnableInformationIcon(bool enable, int iconIndex, bool flagAni)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] enable(" << enable << ") iconIndex(" << iconIndex << ") flagAni(" << flagAni << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(iconIndex >= 0 && iconIndex < (int)m_info.icons.size());

		if (enable)
		{
			m_info.icons[iconIndex]->widget->show();
		}
		else
		{
			m_info.icons[iconIndex]->widget->hide();
		}
	}

	void CThumbnail::EnableInformationText(bool enable, int textIndex, bool flagAni)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] enable(" << enable << ") textIndex(" << textIndex << ") flagAni(" << flagAni << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(textIndex >= 0 && textIndex < (int)m_info.texts.size());

		if (enable)
		{
			m_info.texts[textIndex]->widget->Show();
		}
		else
		{
			m_info.texts[textIndex]->widget->Hide();
		}
	}

	void CThumbnail::EnableInformationRating(bool enable, bool flagAni)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] enable(" << enable << ") flagAni(" << flagAni << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(m_infoStyles & THUMB_INFO_STYLE_RATING);

		if (enable)
		{
			m_info.rating->widget->Show();
		}
		else
		{
			m_info.rating->widget->Hide();
		}
	}

	void CThumbnail::SetImage(const char* fileName)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] fileName(" << fileName << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_IMAGE);
		HALO_ASSERT(fileName != NULL);

		if (m_content.image.widget)
		{
			m_content.image.widget->setSource(fileName);
		}
	}

	void CThumbnail::SetAttachTextColorPickingRange(int fromHPer, int toHPer, int fromVPer, int toVPer)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] range(h1:" << fromHPer <<",h2:" <<toHPer << ",v1:" << fromVPer << ",v2:" << toVPer << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.colorPickingRange.Set(fromHPer, toHPer, fromVPer, toVPer);
		if (m_content.image.isReady)
		{
			m_ResetAttachTextColor(m_content.image.widget);
		}
	}

	void CThumbnail::SetInformationColorPickingRange(int fromHPer, int toHPer, int fromVPer, int toVPer)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] range(h1:" << fromHPer << ",h2:" << toHPer << ",v1:" << fromVPer << ",v2:" << toVPer << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);

		m_info.colorPickingRange.Set(fromHPer, toHPer, fromVPer, toVPer);
		if (m_content.image.isReady)
		{
			m_ResetInfoTextColor(m_content.image.widget);
		}
	}

	void CThumbnail::GetInformationColor(Color &color)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);

		color = m_info.root->getColor();
		H_LOG_TRACE(LOGGER, "[" << this << "] color(r:" << (int)color.r << ",g:" << (int)color.g << ",b:" << (int)color.b << ",a:" << (int)color.a << ")");
	}

	bool CThumbnail::GetInformationColorPicking(Color &color)
	{
		color = m_info.bgColorPicking;
		H_LOG_TRACE(LOGGER, "[" << this << "] colorPickingReady("<< m_info.colorPickingReady << ") color(r:" << (int)color.r << ",g:" << (int)color.g << ",b:" << (int)color.b << ",a:" << (int)color.a << ")");

		return m_info.colorPickingReady;
	}

	bool CThumbnail::GetInformationExtractColor(Color &color)
	{
		color = m_info.fgColorExtracted;
		H_LOG_TRACE(LOGGER, "[" << this << "] colorPickingReady(" << m_info.colorPickingReady << ") color(r:" << (int)color.r << ",g:" << (int)color.g << ",b:" << (int)color.b << ",a:" << (int)color.a << ")");

		return m_info.colorPickingReady;
	}

	bool CThumbnail::GetColorPicking(int fromHPer, int toHPer, int fromVPer, int toVPer, Color &color)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] range(h1:" << fromHPer << ",h2:" << toHPer << ",v1:" << fromVPer << ",v2:" << toVPer << ") imageReady:" << m_content.image.isReady);
		if (m_content.image.isReady)
		{
			if (m_content.image.widget)
			{
				float x1, x2, y1, y2;
				m_content.image.widget->getImageCroppedCoord(&x1, &y1, &x2, &y2);
				float cpx1, cpx2, cpy1, cpy2;
				cpx1 = x1 + (x2 - x1) * fromHPer / 100;
				cpx2 = x1 + (x2 - x1) * toHPer / 100;
				cpy1 = y1 + (y2 - y1) * fromVPer / 100;
				cpy2 = y1 + (y2 - y1) * toVPer / 100;
				return m_content.image.widget->getColorPicking(0, cpx1, cpx2, cpy1, cpy2, &color);
			}
		}
		
		return false;
	}

	void CThumbnail::AddAttachIcon(const std::vector<TAttachIcon> &aiInfo)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		int attachIconNum = aiInfo.size();
		for (int i = 0; i < attachIconNum; i++)
		{
			m_CreateAttachIcon(aiInfo[i]);
		}
	}

	void CThumbnail::RemoveAttachIcon(int index)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_ICON);
		HALO_ASSERT(index >= 0 && index < (int)m_attachIcons.size());

		m_DestroyAttachIcon(index);
	}

	int CThumbnail::AttachedIconNumber(void)
	{
		int attachIconNum = m_attachIcons.size();
		H_LOG_TRACE(LOGGER, "[" << this << "] attachIconNum:" << attachIconNum);

		return attachIconNum;
	}

	void CThumbnail::SetAttachIconUnpressImage(int index, const char* fileName)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") fileName(" << fileName <<")");
		HALO_ASSERT(m_styles & THUMB_STYLE_ICON);
		HALO_ASSERT(index >= 0 && index < (int)m_attachIcons.size());
		HALO_ASSERT(fileName != NULL);

		m_attachIcons[index]->unpressName = std::string(fileName);
		m_attachIcons[index]->widget->setSource(fileName);
	}

	void CThumbnail::SetAttachIconPressedImage(int index, const char* fileName)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") fileName(" << fileName << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_ICON);
		HALO_ASSERT(index >= 0 && index < (int)m_attachIcons.size());
		HALO_ASSERT(fileName != NULL);

		m_attachIcons[index]->pressedNmae = std::string(fileName);
	}

	void CThumbnail::AddAttachText(const TAttachText &atInfo)
	{
		m_CreateAttachText(atInfo);
	}

	void CThumbnail::RemoveAttachText()
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_DestroyAttachText();
	}

	void CThumbnail::SetAttachText(const char* text)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] text(" << text<< ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->SetText(text);
	}

	void CThumbnail::SetAttachTextColor(Color color)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] color(r:" << (int)color.r << ",g:" << (int)color.g << ",b:" << (int)color.b << ",a:" << (int)color.a << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);

		if (m_attachText.widget)
		{
			m_attachText.textColor = color;
			m_attachText.widget->SetTextColor(*color.toClutterColor());
		}
	}

	void CThumbnail::SetAttachTextFont(const char* font)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] font(" << font<< ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);
		HALO_ASSERT(font != NULL);

		if (m_attachText.widget)
		{
			m_attachText.widget->SetFont(font);
		}
	}

	void CThumbnail::SetAttachTextScrollAttribute(guint duration, gfloat speed, guint delay, gint repeat, ClutterTextScrollType type, ClutterTimelineDirection direction, guint continueGap)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] duration(" << duration << ") speed(" << speed << ") delay(" << delay << ") repeat(" << repeat << ") type(" << type << ") direction(" << direction << ") gap(" << continueGap << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->SetScrollAttribute(duration, speed, delay, repeat, type, direction, continueGap);
	}

	void CThumbnail::GetAttachTextScrollAttribute(guint& duration, gfloat& speed, guint& delay, gint& repeat, ClutterTextScrollType& type, ClutterTimelineDirection& direction, guint& continueGap)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->GetScrollAttribute(duration, speed, delay, repeat, type, direction, continueGap);
	}

	void CThumbnail::EnableAttachTextAutoScroll(bool enable)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] enable(" << enable << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);

		if (enable)
		{
			m_attachText.widget->StartScrollText();
		}
		else
		{
			m_attachText.widget->StopScrollText();
		}
	}

	bool CThumbnail::isAttachTextAutoScrollEnabled(void)
	{
		return false;
	}

	void CThumbnail::EnableAttachTextEllipsize(bool enable)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] enable(" << enable << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->EnableEllipsize(enable);
	}

	bool CThumbnail::isAttachTextEllipsizeEnabled(void)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);

		return m_attachText.widget->IsEllipsizeEnable();
	}

	void CThumbnail::EnableAttachTextMultiLine(bool enable)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] enable(" << enable << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->EnableMultiLine(enable);
	}

	bool CThumbnail::isAttachTextMultiLineEnabled(void)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);
		
		return m_attachText.widget->IsMultiLineEnabled();
	}


	void CThumbnail::AddProgressBar(const TProgressBarInfo &pbInfo)
	{
		m_CreateProgressBar(pbInfo);
	}

	void CThumbnail::RemoveProgressBar(void)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_PROGRESSBAR);

		m_DestroyProgressBar();
	}

	void CThumbnail::SetProgressBarRange(int min, int max)
	{
		H_LOG_TRACE(LOGGER, "[" <<this << "] range(min:" << min <<" max:" << max << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_PROGRESSBAR);

		if (m_progressBar.progess)
		{
			m_progressBar.progess->SetMinValue(min);
			m_progressBar.progess->SetMaxValue(max);
		}
	}

	void CThumbnail::SetProgressBarValue(int value)
	{
		H_LOG_TRACE(LOGGER, "[" <<this << "] value(" << value << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_PROGRESSBAR);

		if (m_progressBar.progess)
		{
			m_progressBar.progess->SetValue(value);
		}
	}

	void CThumbnail::AddCheckBox(const TCheckBoxInfo &cbInfo)
	{
		m_CreateCheckBox(cbInfo);
	}

	void CThumbnail::RemoveCheckBox(void)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		m_DestroyCheckBox();
	}

	void CThumbnail::AddInformationText(const std::vector<TTextInfo> &textInfo)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);

		int textNum = textInfo.size();
		for (int i = 0; i < textNum; i++)
		{
			m_CreateInfoText(textInfo[i]);
		}
	}

	void CThumbnail::RemoveInformationText(int index)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.texts.size());

		m_DestroyInfoText(index);
	}

	int CThumbnail::InformationTextNumber(void)
	{
		int infoTextNum = m_info.texts.size();
		H_LOG_TRACE(LOGGER, "[" << this << "] infoTextNum:" << infoTextNum);

		return infoTextNum;
	}

	void CThumbnail::SetInformationColor(Color color)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] color(r:" << (int)color.r << ",g:" << (int)color.g << ",b:" << (int)color.b << ",a:" << (int)color.a << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);

		m_info.bgColor = color;
		m_info.useReferenceColor = false;
		m_SetInfoBgColor(color);
	}

	void CThumbnail::SetInformationText(int index, const char* text)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") text(" <<text << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.texts.size());
		HALO_ASSERT(text != NULL);

		m_info.texts[index]->widget->SetText(text);
	}

	void CThumbnail::SetInformationTextColor(int index, Color color)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") color(r:" << (int)color.r << ",g:" << (int)color.g << ",b:" << (int)color.b << ",a:" << (int)color.a << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.texts.size());

		if (m_info.texts[index]->widget)
		{
			m_info.texts[index]->widget->SetTextColor(*color.toClutterColor());
		}
	}

	void CThumbnail::SetInformationTextFont(int index, const char* font)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") font(" << font << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.texts.size());
		HALO_ASSERT(font != NULL);

		if (m_info.texts[index]->widget)
		{
			m_info.texts[index]->widget->SetFont(font);
		}
	}

	void CThumbnail::SetInformationTextScrollAttribute(int index, guint duration, gfloat speed, guint delay, gint repeat, ClutterTextScrollType type, ClutterTimelineDirection direction, guint continueGap)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" <<index << ") duration(" << duration << ") speed(" << speed << ") delay(" << delay << ") repeat(" << repeat << ") type(" << type << ") direction(" << direction << ") gap(" << continueGap << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.texts.size());

		m_info.texts[index]->widget->SetScrollAttribute(duration, speed, delay, repeat, type, direction, continueGap);
	}

	void CThumbnail::GetInformationTextScrollAttribute(int index, guint& duration, gfloat& speed, guint& delay, gint& repeat, ClutterTextScrollType& type, ClutterTimelineDirection& direction, guint& continueGap)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.texts.size());

		m_info.texts[index]->widget->GetScrollAttribute(duration, speed, delay, repeat, type, direction, continueGap);
	}

	void CThumbnail::EnableInformationTextAutoScroll(int index, bool enable)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") enable(" << enable << ") highContrast(" << m_flagHighContrast << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.texts.size());

		if (m_flagHighContrast || m_flagEnlarge)
		{
			return;
		}
		
		if (enable)
		{
			m_info.texts[index]->widget->StartScrollText();
		}
		else
		{
			m_info.texts[index]->widget->StopScrollText();
		}
	}

	bool CThumbnail::isInformationTextAutoScrollEnabled(int index)
	{
		return false;
	}

	void CThumbnail::EnableInformationTextEllipsize(int index, bool enable)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") enable(" << enable << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.texts.size());

		m_info.texts[index]->widget->EnableEllipsize(enable);
	}

	bool CThumbnail::isInformationTextEllipsizeEnabled(int index)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.texts.size());

		return m_info.texts[index]->widget->IsEllipsizeEnable();
	}

	void CThumbnail::EnableInformationTextMultiLine(int index, bool enable)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") enable(" << enable << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.texts.size());

		m_info.texts[index]->widget->EnableMultiLine(enable);
	}

	bool CThumbnail::isInformationTextMultiLineEnabled(int index)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.texts.size());

		return m_info.texts[index]->widget->IsMultiLineEnabled();
	}

	void CThumbnail::SetInformationRatingValue(int value)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] value(" << value << ")");
		HALO_ASSERT(m_infoStyles & THUMB_INFO_STYLE_RATING);
		HALO_ASSERT(value >= 0 && value <= 10);

		if (m_info.rating && m_info.rating->widget)
		{
			m_UpdateInfoRating(value);
		}
	}

	int CThumbnail::InformationRatingValue(void)
	{
		HALO_ASSERT(m_infoStyles & THUMB_INFO_STYLE_RATING);

		if (m_info.rating && m_info.rating->widget)
		{
			return m_info.rating->value;
		}

		return 0;
	}

	void CThumbnail::SetInformationRatingBgImage(const char* fileName)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] fileName(" << fileName << ")");
		HALO_ASSERT(m_infoStyles & THUMB_INFO_STYLE_RATING);

		if (m_info.rating && m_info.rating->widget && m_info.rating->hasBg)
		{
			m_info.rating->bgImage = m_CreateRatingImage(std::string(fileName));
			for (int i = 0; i < 5; i++)
			{
				m_info.rating->widget->SetIcon(i, m_info.rating->bgImage, m_info.rating->bgOpacity);
			}
		}
	}

	void CThumbnail::SetInformationRatingOnImage(const char* fileName)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] fileName(" << fileName << ")");
		HALO_ASSERT(m_infoStyles & THUMB_INFO_STYLE_RATING);

		if (m_info.rating && m_info.rating->widget)
		{
			m_info.rating->onImage = m_CreateRatingImage(std::string(fileName));
			int indexOffset = (m_info.rating->hasBg) ? 5 : 0;
			for (int i = 0; i < m_info.rating->value / 2; i++)
			{
				m_info.rating->widget->SetIcon(i + indexOffset, m_info.rating->onImage, m_info.rating->onOpacity);
			}
		}
	}

	void CThumbnail::SetInformationRatingHalfImage(const char* fileName)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] fileName(" << fileName << ")");
		HALO_ASSERT(m_infoStyles & THUMB_INFO_STYLE_RATING);

		if (m_info.rating && m_info.rating->widget)
		{
			m_info.rating->halfImage = m_CreateRatingImage(std::string(fileName));
			int indexOffset = (m_info.rating->hasBg) ? 5 : 0;
			if (m_info.rating->value % 2)
			{
				m_info.rating->widget->SetIcon(m_info.rating->value / 2 + indexOffset, m_info.rating->halfImage, m_info.rating->halfOpacity);
			}
		}
	}

	void CThumbnail::SetInformationRatingOffImage(const char* fileName)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] fileName(" << fileName << ")");
		HALO_ASSERT(m_infoStyles & THUMB_INFO_STYLE_RATING);

		if (m_info.rating && m_info.rating->widget)
		{
			m_info.rating->offImage = m_CreateRatingImage(std::string(fileName));
			int indexOffset = (m_info.rating->hasBg) ? 5 : 0;
			for (int i = (m_info.rating->value + 1) / 2; i < 5; i++)
			{
				m_info.rating->widget->SetIcon(i + indexOffset, m_info.rating->offImage, m_info.rating->offOpacity);
			}
		}
	}

	void CThumbnail::AddInformationIcon(const std::vector<TIconInfo> &iconInfo)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);

		int iconNum = iconInfo.size();
		for (int i = 0; i < iconNum; i++)
		{
			m_CreateInfoIcon(iconInfo[i]);
		}
	}

	void CThumbnail::RemoveInformationIcon(int index)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.icons.size());

		m_DestroyInfoIcon(index);
	}

	int CThumbnail::InformationIconNumber(void)
	{
		int infoIconNum = m_info.icons.size();
		H_LOG_TRACE(LOGGER, "[" << this << "] infoIconNum:" << infoIconNum);

		return infoIconNum;
	}

	void CThumbnail::SetInformationIconImage(int index, const char* fileName)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") fileName(" << fileName << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.icons.size());
		HALO_ASSERT(fileName != NULL);

		m_info.icons[index]->widget->setSource(fileName);
	}

	void CThumbnail::SetImagePosition(float x, float y)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] pos(" << x << "," << y << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_IMAGE);

		if (m_content.root)
		{
			m_content.root->SetPosition(x, y);
		}
	}

	void CThumbnail::GetImagePosition(float &x, float &y)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_IMAGE);

		if (m_content.root)
		{
			m_content.root->GetPosition(x, y);
		}
		H_LOG_TRACE(LOGGER, "[" << this << "] pos(" << x << "," << y << ")");
	}

	void CThumbnail::ResizeImage(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] size(" << width << "," << height << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_IMAGE);

		if (m_content.root)
		{
			m_content.root->Resize(width, height);
			m_content.image.widget->setWidth(width);
			m_content.image.widget->setHeight(height);
		}
	}

	void CThumbnail::GetImageSize(float &width, float &height)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_IMAGE);

		if (m_content.image.widget)
		{
			width = m_content.image.widget->getWidth();
			height = m_content.image.widget->getHeight();
		}
		H_LOG_TRACE(LOGGER, "[" << this << "] size(" << width << "," << height << ")");
	}

	void CThumbnail::SetAttachIconPosition(int index, float x, float y)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") pos(" << x << "," << y << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_ICON);
		HALO_ASSERT(index >= 0 && index < (int)m_attachIcons.size());

		m_attachIcons[index]->widget->setX(x);
		m_attachIcons[index]->widget->setY(y);
	}

	void CThumbnail::GetAttachIconPosition(int index, float &x, float &y)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_ICON);
		HALO_ASSERT(index >= 0 && index < (int)m_attachIcons.size());

		x = m_attachIcons[index]->widget->getX();
		y = m_attachIcons[index]->widget->getY();
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") pos(" << x << "," << y << ")");
	}

	void CThumbnail::ResizeAttachIcon(int index, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") size(" << width << "," << height << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_ICON);
		HALO_ASSERT(index >= 0 && index < (int)m_attachIcons.size());

		m_attachIcons[index]->widget->setWidth(width);
		m_attachIcons[index]->widget->setHeight(height);
	}

	void CThumbnail::GetAttachIconSize(int index, float &width, float &height)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_ICON);
		HALO_ASSERT(index >= 0 && index < (int)m_attachIcons.size());

		width = m_attachIcons[index]->widget->getWidth();
		height = m_attachIcons[index]->widget->getHeight();
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") size(" << width << "," << height << ")");
	}

	void CThumbnail::SetAttachTextPosition(float x, float y)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] pos(" << x << "," << y << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->SetPosition(x, y);
	}

	void CThumbnail::GetAttachTextPosition(float &x, float &y)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->GetPosition(x, y);
		H_LOG_TRACE(LOGGER, "[" << this << "] pos(" << x << "," << y << ")");
	}

	void CThumbnail::ResizeAttachText(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] size(" << width << "," << height << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->Resize(width, height);
	}

	void CThumbnail::GetAttachTextSize(float &width, float &height)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->GetSize(width, height);
		H_LOG_TRACE(LOGGER, "[" << this << "] size(" << width << "," << height << ")");
	}

	void CThumbnail::SetCheckBoxPosition(float x, float y)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] pos(" << x << "," << y << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		m_checkMark.widget->SetPosition(x, y);
	}

	void CThumbnail::GetCheckBoxPosition(float &x, float &y)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		m_checkMark.widget->GetSize(x, y);
		H_LOG_TRACE(LOGGER, "[" << this << "] pos(" << x << "," << y << ")");
	}

	void CThumbnail::ResizeCheckBox(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] size(" << width << "," << height << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		m_checkMark.widget->Resize(width, height);
	}

	void CThumbnail::GetCheckBoxSize(float &width, float &height)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		m_checkMark.widget->GetSize(width, height);
		H_LOG_TRACE(LOGGER, "[" << this << "] size(" << width << "," << height << ")");
	}

	void CThumbnail::SetProgressBarPosition(float x, float y)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] pos(" << x << "," << y << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_PROGRESSBAR);

		m_progressBar.progess->SetPosition(x, y);
	}

	void CThumbnail::GetProgressBarPosition(float &x, float &y)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_PROGRESSBAR);

		m_progressBar.progess->GetPosition(x, y);
		H_LOG_TRACE(LOGGER, "[" << this << "] pos(" << x << "," << y << ")");
	}

	void CThumbnail::ResizeProgressBar(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] size(" << width << "," << height << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_PROGRESSBAR);

		m_progressBar.progess->Resize(width, height);
	}

	void CThumbnail::GetProgressBarSize(float &width, float &height)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_PROGRESSBAR);

		m_progressBar.progess->GetSize(width, height);
		H_LOG_TRACE(LOGGER, "[" << this << "] size(" << width << "," << height << ")");
	}

	void CThumbnail::SetInformationPosition(float x, float y)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] pos(" << x << "," << y << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);

		m_info.root->setX(x);
		m_info.root->setY(y);
	}

	void CThumbnail::GetInformationPosition(float &x, float &y)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);

		x = m_info.root->getX();
		y = m_info.root->getY();
		H_LOG_TRACE(LOGGER, "[" << this << "] pos(" << x << "," << y << ")");
	}

	void CThumbnail::ResizeInformation(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] size(" << width << "," << height << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);

		m_info.root->setWidth(width);
		m_info.root->setHeight(height);
	}

	void CThumbnail::GetInformationSize(float &width, float &height)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);

		width = m_info.root->getWidth();
		height = m_info.root->getHeight();
		H_LOG_TRACE(LOGGER, "[" << this << "] size(" << width << "," << height << ")");
	}

	void CThumbnail::SetInformationIconPosition(int index, float x, float y)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") pos(" << x << "," << y << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.icons.size());

		m_info.icons[index]->widget->setX(x);
		m_info.icons[index]->widget->setY(y);
	}

	void CThumbnail::GetInformationIconPosition(int index, float &x, float &y)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.icons.size());

		x = m_info.icons[index]->widget->getX();
		y = m_info.icons[index]->widget->getY();
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") pos(" << x << "," << y << ")");
	}

	void CThumbnail::ResizeInformationIcon(int index, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") size(" << width << "," << height << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.icons.size());

		m_info.icons[index]->widget->setWidth(width);
		m_info.icons[index]->widget->setHeight(height);
	}

	void CThumbnail::GetInformationIconSize(int index, float &width, float &height)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.icons.size());

		width = m_info.icons[index]->widget->getWidth();
		height = m_info.icons[index]->widget->getHeight();
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") size(" << width << "," << height << ")");
	}

	void CThumbnail::SetInformationTextPosition(int index, float x, float y)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") pos(" << x << "," << y << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.texts.size());

		m_info.texts[index]->widget->SetPosition(x, y);
	}

	void CThumbnail::GetInformationTextPosition(int index, float &x, float &y)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.texts.size());

		m_info.texts[index]->widget->GetPosition(x, y);
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") pos(" << x << "," << y << ")");
	}

	void CThumbnail::ResizeInformationText(int index, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") size(" << width << "," << height << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.texts.size());

		m_info.texts[index]->widget->Resize(width, height);
	}

	void CThumbnail::GetInformationTextSize(int index, float &width, float &height)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.texts.size());

		m_info.texts[index]->widget->GetSize(width, height);
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") size(" << width << "," << height << ")");
	}

	void CThumbnail::SetAttachIconOpacity(int index, int opacity)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") opacity(" << opacity << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_ICON);
		HALO_ASSERT(index >= 0 && index < (int)m_attachIcons.size());
 
		m_attachIcons[index]->widget->setOpacity(opacity);
	}

	int CThumbnail::AttachIconOpacity(int index)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_ICON);
		HALO_ASSERT(index >= 0 && index < (int)m_attachIcons.size());

		return m_attachIcons[index]->widget->getOpacity();
	}

	void CThumbnail::SetAttachTextOpacity(int opacity)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] opacity(" << opacity << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->SetAlpha(opacity);
	}

	int  CThumbnail::AttachTextOpacity(void)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);

		return m_attachText.widget->Alpha();
	}

	void CThumbnail::SetCheckBgOpacity(int opacity)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] opacity(" << opacity << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		m_checkMark.widget->SetBoxBackGroudImageOpacity(ISelectButton::E_STATE_ALL, opacity);
	}

	int  CThumbnail::CheckBgOpacity(void)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_CHECKBOX);
	
		return 255;
	}

	void CThumbnail::SetCheckedImageOpacity(int opacity)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] opacity(" << opacity << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		m_checkMark.widget->SetCheckImageOpacity(ISelectButton::E_STATE_ALL, opacity);
	}

	int  CThumbnail::CheckedImageOpacity(void)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		return 255;
	}

	void CThumbnail::SetCheckBgImage(const char* fileName)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] fileName(" << fileName << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		m_checkMark.widget->SetBoxBackGroudImage(ISelectButton::E_STATE_NORMAL, fileName);
	}

	void CThumbnail::SetCheckedImage(const char* fileName)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] fileName(" << fileName << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		m_checkMark.widget->SetCheckImage(ISelectButton::E_STATE_SELECTED, fileName);
	}

	void CThumbnail::SetFocusCheckBgImage(const char* fileName)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] fileName(" << fileName << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		m_checkMark.widget->SetBoxBackGroudImage(ISelectButton::E_STATE_FOCUSED, fileName);
	}

	void CThumbnail::SetFocusCheckedImage(const char* fileName)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] fileName(" << fileName << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		m_checkMark.widget->SetCheckImage(ISelectButton::E_STATE_FOCUSED, fileName);
	}

	void CThumbnail::SetInformationOpacity(int opacity)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] opacity(" << opacity << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);

		m_info.root->setOpacity(opacity);
	}

	void CThumbnail::SetInformationTextOpacity(int index, int opacity)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") opacity(" << opacity << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.texts.size());

		m_info.texts[index]->widget->SetAlpha(opacity);
	}

	void CThumbnail::SetInformationIconOpacity(int index, int opacity)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ") opacity(" << opacity << ")");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.icons.size());

		m_info.icons[index]->widget->setOpacity(opacity);
	}

	int  CThumbnail::InformationIconOpacity(int index)
	{
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);
		HALO_ASSERT(index >= 0 && index < (int)m_info.icons.size());

		return m_info.icons[index]->widget->getOpacity();
	}

	IThumbnail::EThumbnailStyles CThumbnail::VisibleThumbnailStyles(void)
	{
		return m_visibleStyles;
	}

	IThumbnail::EThumbnailStyles CThumbnail::ThumbnailStyle(void)
	{
		return m_styles;
	}

	IThumbnail::EInformationStyles CThumbnail::ThumbnailInformationStyle(void)
	{
		return m_infoStyles;
	}

	void CThumbnail::SetScaleAnimation(int duration, ClutterAnimationMode mode)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] duration(" << duration << ") mode(" << mode << ")");
		m_scaleAniDuration = duration;
		m_scaleAniMode = mode;

		if (m_scaleAni)
		{
			m_scaleAni->SetDuration(duration);
			m_scaleAni->SetMode(mode);
		}
		if (m_info.enlargeAni)
		{
			m_info.enlargeAni->SetDuration(duration);
			m_info.enlargeAni->SetMode(mode);
		}
	}

	void CThumbnail::SetStyleTransAnimation(int duration, ClutterAnimationMode mode)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] duration(" << duration << ") mode(" << mode << ")");
		m_styleTransAniDuration = duration;
		m_styleTransAniMode = mode;

		if (m_styleTransAni)
		{
			m_styleTransAni->SetDuration(duration);
			m_styleTransAni->SetMode(mode);
		}
	}

	void CThumbnail::Scale(TValue2f imageScaleFactor, bool flagAni)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] imageScaleFactor(" << imageScaleFactor.val[0] << "," << imageScaleFactor.val[1] << ") flagAni(" << flagAni << ")");
		if (0 == (m_visibleStyles & THUMB_STYLE_IMAGE))
		{
			return;
		}
		HALO_ASSERT(imageScaleFactor.val[0] >= 0 && imageScaleFactor.val[1] >= 0);

		if (flagAni)
		{
			TValue1f destX, destY;
			destX.Set(imageScaleFactor.val[0]);
			destY.Set(imageScaleFactor.val[1]);
			m_scaleAni->SetDestination(m_content.image.widget, IActor::ACTOR_ANI_SCALE_X, &destX);
			m_scaleAni->SetDestination(m_content.image.widget, IActor::ACTOR_ANI_SCALE_Y, &destY);
			m_scaleAni->Play();
		}
		else
		{
			m_content.image.widget->setScale(Vector2(imageScaleFactor.val[0], imageScaleFactor.val[1]));
		}
	}

	void CThumbnail::Scale(TValue2f imageScaleFactor, float titleFontScaleFactor, bool flagAni)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] imageScaleFactor(" << imageScaleFactor.val[0] << "," << imageScaleFactor.val[1] << ") titleFontScaleFactor(" << titleFontScaleFactor << ") m_fontScaleEnabled(" << m_fontScaleEnabled << ")");
		HALO_ASSERT(imageScaleFactor.val[0] >= 0 && imageScaleFactor.val[1] >= 0 && titleFontScaleFactor >= 0);

		m_fontScaleFactor = titleFontScaleFactor;

		if (flagAni)
		{
			TValue1f destX, destY;
			if (m_visibleStyles & THUMB_STYLE_IMAGE)
			{
				destX.Set(imageScaleFactor.val[0]);
				destY.Set(imageScaleFactor.val[1]);
				m_scaleAni->SetDestination(m_content.image.widget, IActor::ACTOR_ANI_SCALE_X, &destX);
				m_scaleAni->SetDestination(m_content.image.widget, IActor::ACTOR_ANI_SCALE_Y, &destY);
			}
			
			if (m_fontScaleEnabled && !m_flagEnlarge && !m_flagHighContrast && (m_visibleStyles & THUMB_STYLE_INFO))
			{
				destX.Set(titleFontScaleFactor);
				m_scaleAni->SetDestination(m_info.subRoot, IActor::ACTOR_ANI_SCALE_X, &destX);
				m_scaleAni->SetDestination(m_info.subRoot, IActor::ACTOR_ANI_SCALE_Y, &destX);
			}
			m_scaleAni->Play();
		}
		else
		{
			if (m_visibleStyles & THUMB_STYLE_IMAGE)
			{
				m_content.image.widget->setScale(Vector2(imageScaleFactor.val[0], imageScaleFactor.val[1]));
			}
			if (m_fontScaleEnabled && !m_flagEnlarge && !m_flagHighContrast && (m_visibleStyles & THUMB_STYLE_INFO))
			{
				m_info.subRoot->SetScale(titleFontScaleFactor, titleFontScaleFactor, 1.0f);
			}
		}
	}

	void CThumbnail::SetDimBackgroundColor(const Color &color)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] color(r:" << (int)color.r << ",g:" << (int)color.g << ",b:" << (int)color.b << ",a:" << (int)color.a << ")");
		if (m_dimWin && !m_dimUseImage)
		{
			m_dimWin->setColor(color);
		}
	}

	void CThumbnail::SetDimImage(const char* path, int opacity)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] path(" << path << ") opacity(" << opacity << ")");
		if (m_dimWin)
		{
			m_dimWin->setColor(Color());
			m_dimWin->setSource(path);
			m_dimWin->setOpacity(opacity);

			m_dimUseImage = true;
		}
		
	}

	void CThumbnail::Dim(bool enable)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] dim(" << enable << ")");
		if (enable)
		{
#if !defined(WIN32) && !defined(LINUX_BUILD)
			int num = clutter_actor_get_n_children(t_actor);
			for (int i = 0; i < num; i++)
			{
				ClutterActor *child = clutter_actor_get_child_at_index(t_actor, i);
				printf("child%d %s %f,%f %f * %f\n", i, 
					clutter_actor_get_name(child),
					clutter_actor_get_x(child),
					clutter_actor_get_x(child), 
					clutter_actor_get_width(child), 
					clutter_actor_get_height(child));
			}
#endif			
			float width, height;
			GetSize(width, height);
			m_dimWin->setWidth(width);
			m_dimWin->setHeight(height);
			clutter_actor_set_child_above_sibling(t_actor, 
				m_dimWin->getAnimationActor(), NULL);
			m_dimWin->show();
		}
		else
		{
			m_dimWin->hide();
			m_dimWin->setWidth(0);
			m_dimWin->setHeight(0);
		}
	}

	void CThumbnail::RaiseImage(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		HALO_ASSERT(m_styles & THUMB_STYLE_IMAGE);

		if (m_content.root)
		{
			m_content.root->Raise(NULL);
		}
	}

	void CThumbnail::RaiseAttachIcon(int index)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] index(" << index << ")");
		HALO_ASSERT(index >= 0 && index < (int)m_attachIcons.size());

		if (m_attachIcons[index]->widget)
		{
			clutter_actor_set_child_above_sibling(t_actor,
				m_attachIcons[index]->widget->getAnimationActor(), NULL);
		}
	}

	void CThumbnail::RaiseAttachText(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		HALO_ASSERT(m_styles & THUMB_STYLE_TEXT);

		if (m_attachText.widget)
		{
			m_attachText.widget->Raise(NULL);
		}
	}

	void CThumbnail::RaiseProgressBar(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		HALO_ASSERT(m_styles & THUMB_STYLE_PROGRESSBAR);

		if (m_progressBar.progess)
		{
			m_progressBar.progess->Raise(NULL);
		}
	}

	void CThumbnail::RaiseCheckBox(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		HALO_ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		if (m_checkMark.widget)
		{
			m_checkMark.widget->Raise(NULL);
		}
	}

	void CThumbnail::RaiseInformation(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		HALO_ASSERT(m_styles & THUMB_STYLE_INFO);

		if (m_info.root)
		{
			clutter_actor_set_child_above_sibling(t_actor,
				m_info.root->getAnimationActor(), NULL);
		}
	}

	void CThumbnail::SetChecked(const bool checked)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] checked(" << checked << ") hasCheckBox(" << (m_styles & THUMB_STYLE_CHECKBOX) << ")");
		//HALO_ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		if (m_checkMark.widget)
		{
			m_checkMark.widget->SetCheck(checked);
		}
	}

	bool CThumbnail::IsChecked(void) const
	{
		if (m_checkMark.widget)
		{
			return m_checkMark.widget->IsChecked();
		}
		
		return false;
	}

	void CThumbnail::Enable(bool enable)
	{
		m_enabled = enable;
	}

	bool CThumbnail::IsEnabled(void)
	{
		return m_enabled;
	}

	void CThumbnail::enableFontScale(bool enable)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] enable(" << enable << ")");
		m_fontScaleEnabled = enable;
	}

	void CThumbnail::SetHighContrastInfo(const THighContrastAttr &attr)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] color(r:" << (int)attr.backgroundColor.r << ",g:" << (int)attr.backgroundColor.g << ",b:" << (int)attr.backgroundColor.b << ",a:" << (int)attr.backgroundColor.a << ")"
			<< " textColor(r:" << (int)attr.textColor.r << ",g:" << (int)attr.textColor.g << ",b:" << (int)attr.textColor.b << ",a:" << (int)attr.textColor.a << ")"
			<< " highligtTextColor(r:" << (int)attr.highlightTextColor.r << ",g:" << (int)attr.highlightTextColor.g << ",b:" << (int)attr.highlightTextColor.b << ",a:" << (int)attr.highlightTextColor.a << ")");

		m_info.hc_bgColor = attr.backgroundColor;

		int infoTextNum = m_info.texts.size();
		for (int i = 0; i < infoTextNum; i++)
		{
			m_info.texts[i]->hc_textColor = attr.textColor;
			m_info.texts[i]->hc_highlightTextColor = attr.highlightTextColor;
		}

		if (m_flagHighContrast)
		{
			t_UpdateHighContrast(true);
		}
	}

	void CThumbnail::SetHighlighted(const bool flagHighlight, bool flagAni)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] flagHighlight(" << flagHighlight << ") flagAni(" << flagAni << ")");
		m_isHighlighted = flagHighlight;

		if (m_styles & THUMB_STYLE_CHECKBOX)
		{
			m_checkMark.widget->SetFocusState(flagHighlight);
		}

		if (m_flagHighContrast)
		{
			t_UpdateHighContrast(true);
		}
		if (m_flagEnlarge)
		{
			m_EnlargeInfo(flagHighlight, flagAni);
		}
	}

	const char* CThumbnail::GetActorType(void)
	{
		return "Thumbnail";
	}

	//Protected
	bool CThumbnail::OnValueChanged(class IProgress* slider)
	{
		if (m_visibleStyles & THUMB_STYLE_PROGRESSBAR)
		{
			CThumbnailListenerSet::TThumbListenerData data;
			data.type = EVENT_PROGRESS_VALUE_CHANGED;
			data.param[0] = m_progressBar.progess->Value();
			m_listenerSet->Process(&data);
		}
		
		return true;
	}

	void CThumbnail::t_UpdateEnlarge(bool flagEnlarge)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] flagEnlarge(" << flagEnlarge << ") isHighlight(" << m_isHighlighted << ") hasInformation(" << (m_styles & THUMB_STYLE_INFO) << ")");
		if (0 == (m_styles & THUMB_STYLE_INFO) /*|| (m_flagEnlarge == flagEnlarge)*/)
		{
			return;
		}

		m_flagEnlarge = flagEnlarge;

		if (!m_isHighlighted)
		{
			return;
		}

		if (flagEnlarge)
		{
			if (!m_flagHighContrast)
			{
				// disable information fovea animation when enlarge mode
				if (m_fontScaleEnabled)
				{
					m_info.subRoot->SetScale(1.0f, 1.0f, 1.0f);
				}
				// stop scroll when enlarge on
				int infoTextNum = m_info.texts.size();
				for (int i = 0; i < infoTextNum; i++)
				{
					m_info.texts[i]->widget->StopScrollText();
				}
			}
		}
		else
		{
			if (!m_flagHighContrast)
			{
				// enable information fovea animation when enlarge off
				if (m_fontScaleEnabled)
				{
					m_info.subRoot->SetScale(m_fontScaleFactor, m_fontScaleFactor, 1.0f);
				}
				// start scroll when enlarge off
				int infoTextNum = m_info.texts.size();
				for (int i = 0; i < infoTextNum; i++)
				{
					m_info.texts[i]->widget->StartScrollText();
				}
			}
		}

		m_EnlargeInfo(flagEnlarge, false);
	}

	void CThumbnail::t_UpdateHighContrast(bool flagHighContrast)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] flagHighContrast(" << flagHighContrast << ") hasInformation(" << (m_styles & THUMB_STYLE_INFO) << ")");
		if (0 == (m_styles & THUMB_STYLE_INFO) /*|| (m_flagHighContrast == flagHighContrast)*/)
		{
			return;
		}

		m_flagHighContrast = flagHighContrast;

		if (flagHighContrast)
		{
			if (m_isHighlighted && !m_flagEnlarge)
			{
				// disable information fovea animation when high contrast mode
				if (m_fontScaleEnabled)
				{
					m_info.subRoot->SetScale(1.0f, 1.0f, 1.0f);
				}
				// stop scroll when high contrast on
				int infoTextNum = m_info.texts.size();
				for (int i = 0; i < infoTextNum; i++)
				{
					m_info.texts[i]->widget->StopScrollText();
				}
			}
			// update info background color
			 m_SetInfoBgColor(m_info.hc_bgColor);
			// update info text
			int infoTextNum = m_info.texts.size();
			for (int i = 0; i < infoTextNum; i++)
			{
				TextItem *text = m_info.texts[i];
				if (m_isHighlighted)
				{
					text->widget->SetTextColor(*text->hc_highlightTextColor.toClutterColor());
				}
				else
				{
					text->widget->SetTextColor(*text->hc_textColor.toClutterColor());
				}
			}
		}
		else
		{
			if (m_isHighlighted && !m_flagEnlarge)
			{
				// enable information fovea animation when high contrast off
				if (m_fontScaleEnabled)
				{
					m_info.subRoot->SetScale(m_fontScaleFactor, m_fontScaleFactor, 1.0f);
				}
				// start scroll when high contrast off
				int infoTextNum = m_info.texts.size();
				for (int i = 0; i < infoTextNum; i++)
				{
					m_info.texts[i]->widget->StartScrollText();
				}
			}
			// restore info background color
			if (!m_info.useReferenceColor)
			{
				 m_SetInfoBgColor(m_info.bgColor);
			}
			else if (m_info.colorPickingReady)
			{
				 m_SetInfoBgColor(m_info.bgColorPicking);
			}
			else if (m_content.image.isReady)
			{
				m_ResetInfoTextColor(m_content.image.widget);
			}
			// restore text color
			int infoTextNum = m_info.texts.size();
			for (int i = 0; i < infoTextNum; i++)
			{
				TextItem *text = m_info.texts[i];
				if (!text->textColor.isTransparent())
				{
					text->widget->SetTextColor(*text->textColor.toClutterColor());
				}
				else if (m_info.colorPickingReady)
				{
					text->widget->SetTextColor(m_info.fgColorExtracted);
				}
			}
		}
	}

	// private funtions
	ImageWidgetReadyCallback CThumbnail::m_RegisterReadyCallback(EThumbnailStyle style, int index)
	{
		ImageWidgetReadyCallback readyCallback = std::bind(m_ImageLoadReadyCallback, this, style, index, std::placeholders::_1);
		return readyCallback;
	}

	void CThumbnail::m_ImageLoadReadyCallback(CThumbnail* pThis, EThumbnailStyle style, int index, bool success)
	{
		if (style == THUMB_STYLE_IMAGE)
		{
			pThis->m_content.image.isReady = success;
			if (success)
			{
				pThis->m_ResetAttachTextColor(pThis->m_content.image.widget);
				pThis->m_ResetInfoTextColor(pThis->m_content.image.widget);
			}

			CThumbnailListenerSet::TThumbListenerData data;
			data.type = EVENT_IMAGE_READY;
			data.param[0] = 0;
			data.param[1] = success;
			pThis->m_listenerSet->Process(&data);

			if (pThis->m_defalut)
			{
				delete pThis->m_defalut;
				pThis->m_defalut = NULL;

				pThis->EnableThumbnailStyles(true, pThis->m_visibleStyles, false);
			}
		}
		else if (style == THUMB_STYLE_ICON)
		{
			CThumbnailListenerSet::TThumbListenerData data;
			data.type = EVENT_ATTACH_ICON_READY;
			data.param[0] = index;
			data.param[1] = success;
			pThis->m_listenerSet->Process(&data);
		}
		else if (style == THUMB_STYLE_INFO)
		{
			CThumbnailListenerSet::TThumbListenerData data;
			data.type = EVENT_INFO_ICON_READY;
			data.param[0] = index;
			data.param[1] = success;
			pThis->m_listenerSet->Process(&data);
		}
	}

	AnimationCallback CThumbnail::m_RegisterAnimationCallback(void)
	{
		AnimationCallback aniCallback = std::bind(m_AnimationCallback, this);
		return aniCallback;
	}

	void CThumbnail::m_AnimationCallback(CThumbnail* pThis)
	{
	}

	ButtonPressCallback CThumbnail::m_RegisterMouseEventCallback(MouseEventCallback cb)
	{
		ButtonPressCallback mouseCallback = std::bind(cb, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3, std::placeholders::_4);
		return mouseCallback;
	}

	bool CThumbnail::m_mousePressedCallback(CThumbnail* pThis, Widget* widget, Widget* origin, volt::util::MOUSE_BUTTON button, Vector2 coordinates)
	{
		std::vector<AttachIcon*>::iterator aiIt;
		for (aiIt = pThis->m_attachIcons.begin(); aiIt != pThis->m_attachIcons.end(); aiIt++)
		{
			if ((*aiIt)->widget == widget)
			{
				(*aiIt)->widget->setSource((*aiIt)->pressedNmae);
				break;
			}
		}

		return false;
	}

	bool CThumbnail::m_mouseReleaseCallback(CThumbnail* pThis, Widget* widget, Widget* origin, volt::util::MOUSE_BUTTON button, Vector2 coordinates)
	{
		std::vector<AttachIcon*>::iterator aiIt;
		for (aiIt = pThis->m_attachIcons.begin(); aiIt != pThis->m_attachIcons.end(); aiIt++)
		{
			if ((*aiIt)->widget == widget)
			{
				(*aiIt)->widget->setSource((*aiIt)->unpressName);

				CThumbnailListenerSet::TThumbListenerData data;
				data.type = EVENT_ICON_CLICKED; 
				data.param[0] = aiIt - pThis->m_attachIcons.begin();
				pThis->m_listenerSet->Process(&data);
				break;
			}
		}
		return false;
	}

	bool CThumbnail::m_mouseClickedCallback(CThumbnail* pThis, Widget* widget, Widget* origin, volt::util::MOUSE_BUTTON button, Vector2 coordinates)
	{
		return false;
	}

	void CThumbnail::m_ResetAttachTextColor(ImageWidget* w)
	{
		if (w)
		{
			Color color;
#if !defined(WIN32) && !defined(LINUX_BUILD)
			float x1, x2, y1, y2;
			w->getImageCroppedCoord(&x1, &y1, &x2, &y2);
			float cpx1, cpx2, cpy1, cpy2;
			if (m_info.colorPickingRange.isEmpty())
			{
				cpx1 = x1;
				cpx2 = x2;
				cpy1 = y1;
				cpy2 = y2;
			}
			else
			{
				cpx1 = x1 + (x2 - x1)*m_info.colorPickingRange.l / 100;
				cpx2 = x1 + (x2 - x1)*m_info.colorPickingRange.r / 100;
				cpy1 = y1 + (y2 - y1)*m_info.colorPickingRange.t / 100;
				cpy2 = y1 + (y2 - y1)*m_info.colorPickingRange.b / 100;
			}
			w->getColorPicking(0, cpx1, cpx2, cpy1, cpy2, &color);
#else
			w->getColorPicking(100, &color);
#endif
			ClutterColor bg = CLUTTER_COLOR_INIT(color.r, color.g, color.b, m_attachText.colorPickingOpacity);
			m_attachText.bgColorPicking = bg;
			m_attachText.colorPickingReady = true;

			uint to_r = 0, to_g = 0, to_b = 0;
			m_utility->ExtractForegroundColor(color.r, color.g, color.b, &to_r, &to_g, &to_b);
			ClutterColor fg = CLUTTER_COLOR_INIT((guint8)to_r, (guint8)to_g, (guint8)to_b, m_attachText.extractColorOpacity);
			m_attachText.fgColorExtracted = fg;
		}
		
		if (m_attachText.widget && m_attachText.colorPickingReady)
		{
			if (m_attachText.useReferenceColor)
			{
				m_SetAttachTexBgColor(m_attachText.bgColorPicking);
				if (m_attachText.textColor.isTransparent())
				{
					m_attachText.widget->SetTextColor(m_attachText.fgColorExtracted);
				}
			}
		}
	}

	void CThumbnail::m_ResetInfoTextColor(ImageWidget* w)
	{
		if (w)
		{
			Color color;
#if !defined(WIN32) && !defined(LINUX_BUILD)
			float x1, x2, y1, y2;
			w->getImageCroppedCoord(&x1, &y1, &x2, &y2);
			float cpx1, cpx2, cpy1, cpy2;
			if (m_info.colorPickingRange.isEmpty())
			{
				cpx1 = x1;
				cpx2 = x2;
				cpy1 = y2 - (y2 - y1) * 10 / 100;
				cpy2 = y2;
			}
			else
			{
				cpx1 = x1 + (x2 - x1)*m_info.colorPickingRange.l / 100;
				cpx2 = x1 + (x2 - x1)*m_info.colorPickingRange.r / 100;
				cpy1 = y1 + (y2 - y1)*m_info.colorPickingRange.t / 100;
				cpy2 = y1 + (y2 - y1)*m_info.colorPickingRange.b / 100;
			}
			w->getColorPicking(0, cpx1, cpx2, cpy1, cpy2, &color);
#else
			w->getColorPicking(10, &color);
#endif
			ClutterColor bg = CLUTTER_COLOR_INIT(color.r, color.g, color.b, m_info.colorPickingOpacity);
			m_info.bgColorPicking = bg;
			m_info.colorPickingReady = true;

			uint to_r = 0, to_g = 0, to_b = 0;
			m_utility->ExtractForegroundColor(color.r, color.g, color.b, &to_r, &to_g, &to_b);
			ClutterColor fg = CLUTTER_COLOR_INIT((guint8)to_r, (guint8)to_g, (guint8)to_b, m_info.extractColorOpacity);
			m_info.fgColorExtracted = fg;
			H_LOG_TRACE(LOGGER, "[" << this << "] bgColorPicking(r:" << (int)color.r << ",g:" << (int)color.g << ",b:" << (int)color.b 
				<< ") fgColorExtracted(r:" << to_r << ",g:" << to_g << ",b:" << to_b << ")");
		}
		
		if (!m_flagHighContrast && m_info.root && m_info.colorPickingReady)
		{
			if (m_info.useReferenceColor)
			{
				 m_SetInfoBgColor(m_info.bgColorPicking);
			}
			
			int textNum = m_info.texts.size();
			for (int i = 0; i < textNum; i++)
			{
				if (m_info.texts[i]->textColor.isTransparent())
				{
					m_info.texts[i]->widget->SetTextColor(m_info.fgColorExtracted);
				}
			}
		}
	}

	bool CThumbnail::m_CreateContent(const TImageInfo &info)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] src(" << info.src << ") async(" << info.async << ") fillMode(" << info.fillMode
			<< ") x(" << info.alloc.x << ") y(" << info.alloc.y << ") w(" << info.alloc.w << ") h(" << info.alloc.h << ")");
		m_content.root = IActor::CreateInstance((IActor*)this, info.alloc.w, info.alloc.h);
		m_SetId(dynamic_cast<Widget*>(m_content.root), "image-root");

		m_content.root->SetPosition(info.alloc.x, info.alloc.y);

		m_content.root->EnableClipOverflow(true);
		m_content.root->Hide();

		m_content.image.widget = new CImageWidgetEx(0, 0, info.alloc.w, info.alloc.h, dynamic_cast<Widget*>(m_content.root), m_RegisterReadyCallback(THUMB_STYLE_IMAGE, 0));
		m_SetId(m_content.image.widget, "image");
		m_content.image.widget->setAsyncLoading(info.async);

		if (!info.src.empty())
		{
			m_content.image.widget->setSource(info.src);
		}
		m_content.image.widget->setFillMode(info.fillMode);

		m_scaleAni->AddAnimatableObject(m_content.image.widget, IActor::ACTOR_ANI_SCALE_X);
		m_scaleAni->AddAnimatableObject(m_content.image.widget, IActor::ACTOR_ANI_SCALE_Y);

		m_styleTransAni->AddAnimatableObject(m_content.image.widget, IActor::ACTOR_ANI_SIZE);

		m_styles |= THUMB_STYLE_IMAGE;

		return true;
	}

	void CThumbnail::m_DestroyContent(void)
	{
		if (m_content.image.widget)
		{
			delete m_content.image.widget;
			m_content.image.widget = NULL;
		}
		if (m_content.root)
		{
			m_content.root->Release();
			m_content.root = NULL;
		}
		m_styles &= ~THUMB_STYLE_IMAGE;
	}

	bool CThumbnail::m_CreateAttachIcon(const TAttachIcon &aiInfo)
	{
		AttachIcon *icon = new AttachIcon;
		icon->widget = new CImageWidgetEx(aiInfo.iconInfo.alloc.x, aiInfo.iconInfo.alloc.y, aiInfo.iconInfo.alloc.w, aiInfo.iconInfo.alloc.h, dynamic_cast<Widget*>(this), m_RegisterReadyCallback(THUMB_STYLE_ICON, m_attachIcons.size()));
		m_SetId(icon->widget, "attach-icon", m_attachIcons.size() + 1);
		icon->widget->setAsyncLoading(aiInfo.iconInfo.async);
		icon->widget->hide();

		icon->clickable = aiInfo.iconInfo.clickable;
		if (aiInfo.iconInfo.clickable)
		{
			icon->mousePressedHandle = icon->widget->registerMouseEvent(Widget::MOUSE_DOWN, m_RegisterMouseEventCallback(m_mousePressedCallback));
			icon->mouseReleaseHandle = icon->widget->registerMouseEvent(Widget::MOUSE_UP, m_RegisterMouseEventCallback(m_mouseReleaseCallback));
			icon->mouseClickedHandle = icon->widget->registerMouseEvent(Widget::MOUSE_CLICK, m_RegisterMouseEventCallback(m_mouseClickedCallback));
		}

		icon->unpressName = aiInfo.iconInfo.unpressName;
		icon->pressedNmae = aiInfo.iconInfo.pressedName;
		
		if (!aiInfo.iconInfo.unpressName.empty())
		{
			icon->widget->setSource(aiInfo.iconInfo.unpressName);
		}
		icon->widget->setOpacity(aiInfo.iconInfo.opacity);
		icon->widget->EnableReverse(aiInfo.reversible);
		m_attachIcons.push_back(icon);

		m_styles |= THUMB_STYLE_ICON;

		return true;
	}

	void CThumbnail::m_DestroyAttachIcon(int index)
	{
		std::vector<AttachIcon*>::iterator it = m_attachIcons.begin() + index;
		AttachIcon* icon = *it;
		delete icon->widget;
		delete icon;
		m_attachIcons.erase(it);

		if (m_attachIcons.size() == 0)
		{
			m_styles &= ~THUMB_STYLE_ICON;
		}
	}

	bool CThumbnail::m_CreateAttachText(const TAttachText &atInfo)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] setAsBackground(" << atInfo.setAsBackground << ")");
		m_attachText.widget = IText::CreateInstance((Widget*)this, atInfo.textInfo.alloc.w, atInfo.textInfo.alloc.h);
		m_SetId(dynamic_cast<Widget*>(m_attachText.widget), "attach-text");
		m_attachText.widget->SetPosition(atInfo.textInfo.alloc.x, atInfo.textInfo.alloc.y);
		m_attachText.widget->Hide();

		if (!atInfo.textInfo.fontName.empty())
		{
			m_attachText.widget->SetFont(atInfo.textInfo.fontName.c_str());
		}
		if (atInfo.textInfo.bold)
		{
			m_attachText.widget->SetCharFormat(IText::STYLE_BOLD);
		}
		m_attachText.widget->EnableMultiLine(!atInfo.textInfo.singleLineMode);
		m_attachText.widget->EnableEllipsize(atInfo.textInfo.ellipsize);
		m_attachText.widget->SetRowGap(atInfo.textInfo.rowGap);
		m_attachText.widget->SetTextAlignment(atInfo.textInfo.hAlign, atInfo.textInfo.vAlign);
		if (!atInfo.textInfo.text.empty())
		{
			m_attachText.widget->SetText(atInfo.textInfo.text.c_str());
		}
		m_attachText.useReferenceColor = atInfo.useRefereceColor;
		m_attachText.colorPickingOpacity = atInfo.colorPickingOpacity;
		m_attachText.extractColorOpacity = atInfo.extractColorOpacity;
		m_attachText.setAsBackground = atInfo.setAsBackground;
		if (!atInfo.useRefereceColor)
		{
			m_SetAttachTexBgColor(atInfo.backgroundColor);
		}
		else if (m_attachText.colorPickingReady)
		{
			m_SetAttachTexBgColor(m_attachText.bgColorPicking);
		}
		m_attachText.textColor = atInfo.textInfo.textColor;
		if (!atInfo.textInfo.textColor.isTransparent())
		{
			m_attachText.widget->SetTextColor(*atInfo.textInfo.textColor.toClutterColor());
		}
		else if (m_attachText.colorPickingReady)
		{
			m_attachText.widget->SetTextColor(m_attachText.fgColorExtracted);
		}
		
		m_attachText.widget->SetAlpha(atInfo.textInfo.opacity);
		m_attachText.widget->SetScrollAttribute(5000, 0.1f, 1000, -1, CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_OUTSIDE, CLUTTER_TIMELINE_BACKWARD, 0);

		m_styles |= THUMB_STYLE_TEXT;

		return true;
	}

	void CThumbnail::m_DestroyAttachText(void)
	{
		if (m_attachText.widget != NULL)
		{
			m_attachText.widget->Release();
			m_attachText.widget = NULL;
		}
		
		m_styles &= ~THUMB_STYLE_TEXT;
	}

	void CThumbnail::m_SetAttachTexBgColor(const Color &color)
	{
		if (m_attachText.widget != NULL)
		{
			ClutterColor _color = *color.toClutterColor();
			m_attachText.widget->SetBackgroundColor(_color);
			if (m_attachText.setAsBackground)
			{
				SetBackgroundColor(_color);
			}
		}
	}

	bool CThumbnail::m_CreateProgressBar(const TProgressBarInfo &pbInfo)
	{
		m_progressBar.progess = IProgress::CreateInstance((IActor*)this, pbInfo.alloc.w, pbInfo.alloc.h, pbInfo.direction);
		m_SetId(dynamic_cast<Widget*>(m_progressBar.progess), "progress-bar");
		m_progressBar.progess->SetPosition(pbInfo.alloc.x, pbInfo.alloc.y);
		m_progressBar.progess->SetBackgroundColor(*pbInfo.backgroundColor.toClutterColor());
		m_progressBar.progess->SetProgressColor(*pbInfo.progressColor.toClutterColor());
		m_progressBar.progess->SetNormalThumbImage(pbInfo.normalThumb);
		m_progressBar.progess->SetFocusThumbImage(pbInfo.focusThumb);
		m_progressBar.progess->SetThumbSize(pbInfo.thumbSize.val[0], pbInfo.thumbSize.val[1]);
		m_progressBar.progess->SetActive(pbInfo.slidable);
		
		m_progressBar.progess->Hide();

		m_progressBar.slidable = pbInfo.slidable;
		m_styles |= THUMB_STYLE_PROGRESSBAR;

		return true;
	}

	void CThumbnail::m_DestroyProgressBar(void)
	{
		if (m_progressBar.progess)
		{
			m_progressBar.progess->Release();
			m_progressBar.progess = NULL;
		}

		m_styles &= ~THUMB_STYLE_PROGRESSBAR;
	}

	bool CThumbnail::m_CreateCheckBox(const TCheckBoxInfo &cbInfo)
	{
		m_checkMark.widget = ISelectButton::CreateInstance((IActor*)this, cbInfo.alloc.w, cbInfo.alloc.h);
		m_SetId(dynamic_cast<Widget*>(m_checkMark.widget), "check-box");
		m_checkMark.widget->SetPosition(cbInfo.alloc.x, cbInfo.alloc.y);
		m_checkMark.widget->SetAsyncLoading(cbInfo.async);
		m_checkMark.widget->Hide();

		m_checkMark.widget->SetAutoCheckFlag(cbInfo.autoCheck);
		m_checkMark.widget->SetAutoFocusFlag(false);

		m_checkMark.widget->SetBoxBackGroudImage(ISelectButton::E_STATE_NORMAL, cbInfo.backgroundName.c_str());
		m_checkMark.widget->SetBoxBackGroudImage(ISelectButton::E_STATE_FOCUSED, cbInfo.focusBackgroundName.c_str());
		m_checkMark.widget->SetCheckImage(ISelectButton::E_STATE_SELECTED, cbInfo.checkedName.c_str());
		m_checkMark.widget->SetCheckImage(ISelectButton::E_STATE_FOCUSED, cbInfo.focusCheckedName.c_str());

		m_checkMark.widget->SetBoxBackGroudImageOpacity(ISelectButton::E_STATE_ALL, cbInfo.backgroundOpacity);
		m_checkMark.widget->SetCheckImageOpacity(ISelectButton::E_STATE_SELECTED, cbInfo.checkedOpacity);

		m_styles |= THUMB_STYLE_CHECKBOX;

		return true;
	}

	void CThumbnail::m_DestroyCheckBox(void)
	{
		if (NULL != m_checkMark.widget)
		{
			delete m_checkMark.widget;
			m_checkMark.widget = NULL;
		}

		m_styles &= ~THUMB_STYLE_CHECKBOX;
	}

	bool CThumbnail::m_CreateInfo(const TInformation &info, EInformationStyles infoStyles)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] anchorPiont(" << info.anchorPoint << ") enlargeFactor(" << info.enlargeFactor
			<< ") highContrastColor(r:" << (int)info.highContrastInfo.backgroundColor.r << ",g:" << (int)info.highContrastInfo.backgroundColor.g << ",b:" << (int)info.highContrastInfo.backgroundColor.b << ",a:" << (int)info.highContrastInfo.backgroundColor.a
			<< ") setAsBackground(" << info.setAsBackground << ")");
		m_info.bgColorPicking.red = m_info.bgColorPicking.green = m_info.bgColorPicking.blue = m_info.bgColorPicking.alpha = 0;
		m_info.fgColorExtracted.red = m_info.fgColorExtracted.green = m_info.fgColorExtracted.blue = 0;
		if (NULL == m_info.root)
		{
			m_info.root = new CWidgetEx(info.alloc.x,info.alloc.y, info.alloc.w, info.alloc.h, this);
			m_SetId(m_info.root, "info-root");
			m_info.root->setCropOverflow(true);
			m_info.root->hide();

			m_info.subRoot = IActor::CreateInstance(m_info.root, -1, -1);
			m_info.subRoot->SetPivotPoint(0.5f, 0.5f, 1.0f);

			m_info.colorPickingRange = info.colorPickingRange;
			m_info.colorPickingOpacity = info.colorPickingOpacity;
			m_info.extractColorOpacity = info.extractColorOpacity;
			m_info.useReferenceColor = info.useRefereceColor;
			m_info.setAsBackground = info.setAsBackground;
			if (!m_flagHighContrast)
			{
				if (!m_info.useReferenceColor)
				{
					m_SetInfoBgColor(info.backgroundColor);
				}
				else if (!info.colorPickingRange.isEmpty() && m_content.image.isReady)   // user sets colorPicking range, so re-get color picking
				{
					m_ResetInfoTextColor(m_content.image.widget);
				}
				else if (m_info.colorPickingReady)
				{
					 m_SetInfoBgColor(m_info.bgColorPicking);
				}
			}
			else
			{
				 m_SetInfoBgColor(info.highContrastInfo.backgroundColor);
			}
			m_info.root->setOpacity(info.opacity);

			m_scaleAni->AddAnimatableObject(m_info.subRoot, IActor::ACTOR_ANI_SCALE_X);
			m_scaleAni->AddAnimatableObject(m_info.subRoot, IActor::ACTOR_ANI_SCALE_Y);

			m_styleTransAni->AddAnimatableObject(m_info.root, IActor::ACTOR_ANI_POSITION);
			m_styleTransAni->AddAnimatableObject(m_info.root, IActor::ACTOR_ANI_SIZE);

			// for enlarge
			m_info.enlargeFactor = info.enlargeFactor;
			m_info.anchorPoint = info.anchorPoint;

			m_info.enlargeAni = new CMultiObjectTransition;
			m_info.enlargeAni->Initialize();
			m_info.enlargeAni->SetDuration(m_scaleAniDuration);
			m_info.enlargeAni->SetMode(m_scaleAniMode);

			m_info.enlargeAni->AddAnimatableObject(m_info.root, IActor::ACTOR_ANI_POSITION_Y);
			m_info.enlargeAni->AddAnimatableObject(m_info.root, IActor::ACTOR_ANI_SIZE);

			// for high-contrast
			m_info.alloc = info.alloc;
			m_info.bgColor = info.backgroundColor;
			m_info.hc_bgColor = info.highContrastInfo.backgroundColor;
		}

		int iconNum = info.iconInfos.size();
		for (int i = 0; i < iconNum; i++)
		{
			m_CreateInfoIcon(info.iconInfos[i]);
		}

		if (infoStyles & THUMB_INFO_STYLE_RATING)
		{
			m_CreateInfoRating(info.ratingInfo);
		}

		int textNum = info.textInfos.size();
		for (int i = 0; i < textNum; i++)
		{
			m_CreateInfoText(info.textInfos[i]);
		}

		m_styles |= THUMB_STYLE_INFO;
		return true;
	}

	void CThumbnail::m_DestroyInfo(void)
	{
		if (m_info.enlargeAni)
		{
			m_info.enlargeAni->Release();
			m_info.enlargeAni = NULL;
		}
		
		while (m_info.texts.size() != 0)
		{
			m_DestroyInfoText(0);
		}
		while (m_info.icons.size() != 0)
		{
			m_DestroyInfoIcon(0);
		}
		m_DestroyInfoRating();
		
		if (m_info.subRoot)
		{
			m_info.subRoot->Release();
			m_info.subRoot = NULL;
		}

		if (m_info.root != NULL)
		{
			delete m_info.root;
			m_info.root = NULL;
		}

		m_styles &= ~THUMB_STYLE_INFO;
	}

	void CThumbnail::m_SetInfoBgColor(const Color &color)
	{
		if (m_info.root != NULL)
		{
			m_info.root->setColor(color);
			if (m_info.setAsBackground)
			{
				SetBackgroundColor(*color.toClutterColor());
			}
		}
	}

	bool CThumbnail::m_CreateInfoText(const TTextInfo &textInfo)
	{
		TextItem *text = new TextItem;
		text->widget = IText::CreateInstance(m_info.subRoot, textInfo.alloc.w, textInfo.alloc.h);
		m_SetId(dynamic_cast<Widget*>(text->widget), "info-text", m_info.texts.size() + 1);

		m_InitInfoText(text, textInfo);

		text->widget->SetScaleAttribute(text->fontSize, m_scaleAniDuration, 0, m_scaleAniMode);
		text->widget->SetScrollAttribute(5000, 0.1f, 1000, -1, CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_OUTSIDE, CLUTTER_TIMELINE_BACKWARD, 0);

		m_info.texts.push_back(text);

		m_info.enlargeAni->AddAnimatableObject(text->widget, IActor::ACTOR_ANI_POSITION_Y);  

		m_infoStyles |= THUMB_INFO_STYLE_TEXT;

		return true;
	}

	void CThumbnail::m_InitInfoText(TextItem* text, const TTextInfo &textInfo)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] singleLineMode(" << textInfo.singleLineMode << ") ellipsize(" << textInfo.ellipsize
			<< ") rowGap(" << textInfo.rowGap << ") text(" << textInfo.text.c_str() << ") font(" << textInfo.fontName.c_str()
			<< ") anchorPoint(" << textInfo.anchorPoint << ") enlargeFactor(" << textInfo.enlargeFactor 
			<< ") hcTextColor(r:" << (int)textInfo.hc_textColor.r << ",g:" << (int)textInfo.hc_textColor.g << ",b:" << (int)textInfo.hc_textColor.b << ",a:" << (int)textInfo.hc_textColor.a
			<< ") hcHighlightTextColor(r:" << (int)textInfo.hc_highlightTextColor.r << ",g:" << (int)textInfo.hc_highlightTextColor.g << ",b:" << (int)textInfo.hc_highlightTextColor.b << ",a:" << (int)textInfo.hc_highlightTextColor.a << ")");
		if (textInfo.bold)
		{
			text->widget->SetCharFormat(IText::STYLE_BOLD);
		}
		else
		{
			text->widget->SetCharFormat(IText::STYLE_NONE);
		}
		text->widget->EnableMultiLine(!textInfo.singleLineMode);
		text->widget->EnableEllipsize(textInfo.ellipsize);
		text->widget->SetRowGap(textInfo.rowGap);
		text->widget->SetTextAlignment(textInfo.hAlign, textInfo.vAlign);
		text->widget->SetAlpha(textInfo.opacity);

		text->textColor = textInfo.textColor;
		text->anchorPoint = textInfo.anchorPoint;
		text->enlargeFactor = textInfo.enlargeFactor;
		text->hc_textColor = textInfo.hc_textColor;
		text->hc_highlightTextColor = textInfo.hc_highlightTextColor;
		text->alloc = textInfo.alloc;

		if (!m_flagEnlarge || !m_isHighlighted)
		{
			text->widget->SetPosition(textInfo.alloc.x, textInfo.alloc.y);
			text->widget->Resize(textInfo.alloc.w, textInfo.alloc.h);
			// font
			if (!textInfo.fontName.empty())
			{
				text->widget->SetFont(textInfo.fontName.c_str());
			}
			text->fontSize = text->widget->FontSize();
		}
		else
		{
			text->widget->SetPosition(textInfo.alloc.x, textInfo.alloc.y * text->enlargeFactor);
			text->widget->Resize(textInfo.alloc.w, textInfo.alloc.h * text->enlargeFactor);
			// font
			if (!textInfo.fontName.empty())
			{
				PangoFontDescription *fontdes = pango_font_description_from_string(textInfo.fontName.c_str());
				text->fontSize = pango_font_description_get_size(fontdes) / PANGO_SCALE;
				pango_font_description_free(fontdes);
			}
			text->widget->SetFontSize(text->fontSize * text->enlargeFactor);
		}

		if (!m_flagHighContrast)
		{
			// text color
			if (!text->textColor.isTransparent())
			{
				text->widget->SetTextColor(*text->textColor.toClutterColor());
			}
			else if (m_info.colorPickingReady)
			{
				text->widget->SetTextColor(m_info.fgColorExtracted);
			}
		}
		else
		{
			// text color
			text->widget->SetTextColor(*text->hc_textColor.toClutterColor());
		}

		if (!textInfo.text.empty())
		{
			text->widget->SetText(textInfo.text.c_str());
			text->minHeight = text->widget->PreferredHeight(textInfo.alloc.w);
		}
	}

	void CThumbnail::m_DestroyInfoText(int index)
	{
		std::vector<TextItem*>::iterator it = m_info.texts.begin() + index;
		TextItem* text = *it;
		delete text->widget;
		delete text;
		m_info.texts.erase(it);

		if (m_info.texts.size() == 0)
		{
			m_infoStyles &= ~THUMB_INFO_STYLE_TEXT;
		}
		
	}

	bool CThumbnail::m_CreateInfoIcon(const TIconInfo &iconInfo)
	{
		IconItem *icon = new IconItem;
		Widget* subWidget = dynamic_cast<Widget*>(m_info.subRoot);
		icon->widget = new CImageWidgetEx(iconInfo.alloc.x,	iconInfo.alloc.y, iconInfo.alloc.w, iconInfo.alloc.h, dynamic_cast<Widget*>(subWidget), m_RegisterReadyCallback(THUMB_STYLE_INFO, m_info.icons.size()));
		m_SetId(dynamic_cast<Widget*>(icon->widget), "info-icon", m_info.icons.size() + 1);
		icon->widget->setAsyncLoading(iconInfo.async);
		if (!iconInfo.unpressName.empty())
		{
			icon->widget->setSource(iconInfo.unpressName);
		}
		icon->widget->setOpacity(iconInfo.opacity);
		icon->alloc = iconInfo.alloc;
		m_info.icons.push_back(icon);

		m_info.enlargeAni->AddAnimatableObject(icon->widget, IActor::ACTOR_ANI_POSITION_Y);

		m_infoStyles |= THUMB_INFO_STYLE_ICON;

		return true;
	}

	void CThumbnail::m_DestroyInfoIcon(int index)
	{
		std::vector<IconItem*>::iterator it = m_info.icons.begin() + index;
		IconItem* icon = *it;
		delete icon->widget;
		delete icon;
		m_info.icons.erase(it);

		if (m_info.icons.size() == 0)
		{
			m_infoStyles &= ~THUMB_INFO_STYLE_ICON;
		}
	}

	ClutterContent* CThumbnail::m_CreateRatingImage(const std::string path)
	{
		ClutterContent *image = clutter_image_new();
		IImageBuffer *buffer = IImageBuffer::CreateInstance(path.c_str());
		if (buffer && buffer->IsReady())
		{
			clutter_image_set_data(CLUTTER_IMAGE(image),
				buffer->GetPixels(),
				buffer->HasAlphaChannel() ? COGL_PIXEL_FORMAT_RGBA_8888 : COGL_PIXEL_FORMAT_RGB_888,
				buffer->Width(),
				buffer->Height(),
				buffer->BytesPerLine(),
				NULL);
			buffer->Release();
		}

		return image;
	}

	bool CThumbnail::m_CreateInfoRating(const TRatingInfo &ratingInfo)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] bgSrc(" << ratingInfo.bgName.c_str() << ") onSrc(" << ratingInfo.onName.c_str()
			<< ") offSrc(" << ratingInfo.offName.c_str() << ") halfSrc(" << ratingInfo.halfName.c_str() << ") value(" << ratingInfo.value << ")");
		m_info.rating = new RatingItem;
		m_info.rating->widget = IMultiImage::CreateInstance(m_info.subRoot, ratingInfo.alloc.w, ratingInfo.alloc.h);
		m_SetId(dynamic_cast<Widget*>(m_info.rating->widget), "info-rating");
		m_info.rating->widget->SetPosition(ratingInfo.alloc.x, ratingInfo.alloc.y);
		m_info.rating->widget->SetAlpha(ratingInfo.opacity);

		m_info.rating->hasBg = !ratingInfo.bgName.empty();

		m_info.rating->bgImage = m_CreateRatingImage(ratingInfo.bgName);
		m_info.rating->onImage = m_CreateRatingImage(ratingInfo.onName);
		m_info.rating->offImage = m_CreateRatingImage(ratingInfo.offName);
		m_info.rating->halfImage = m_CreateRatingImage(ratingInfo.halfName);

		m_info.rating->bgOpacity = ratingInfo.bgOpacity;
		m_info.rating->offOpacity = ratingInfo.offOpacity;
		m_info.rating->onOpacity = ratingInfo.onOpacity;
		m_info.rating->halfOpacity = ratingInfo.halfOpacity;

		if (m_info.rating->hasBg)
		{
			for (int i = 0; i < 5; i++)
			{
				TRect rect((ratingInfo.iconSize.val[0] + ratingInfo.gap)*i, 0, ratingInfo.iconSize.val[0], ratingInfo.iconSize.val[1]);
				m_info.rating->widget->AddIcon(m_info.rating->bgImage, rect, m_info.rating->bgOpacity);
			}
		}
		for (int i = 0; i < 5; i++)
		{
			TRect rect((ratingInfo.iconSize.val[0] + ratingInfo.gap)*i, 0, ratingInfo.iconSize.val[0], ratingInfo.iconSize.val[1]);
			if (ratingInfo.value >(i + 1) * 2)
			{
				m_info.rating->widget->AddIcon(m_info.rating->onImage, rect, m_info.rating->onOpacity);
			}
			else if (ratingInfo.value > i * 2)
			{
				m_info.rating->widget->AddIcon(m_info.rating->halfImage, rect, m_info.rating->halfOpacity);
			}
			else
			{
				m_info.rating->widget->AddIcon(m_info.rating->offImage, rect, m_info.rating->offOpacity);
			}
		}
		m_info.rating->value = ratingInfo.value;
		m_info.rating->alloc = ratingInfo.alloc;

		m_info.enlargeAni->AddAnimatableObject(m_info.rating->widget, IActor::ACTOR_ANI_POSITION_Y);

		m_infoStyles |= THUMB_INFO_STYLE_RATING;

		return true;
	}

	void CThumbnail::m_DestroyInfoRating(void)
	{
		if (m_info.rating != NULL)
		{
			if (m_info.rating->widget != NULL)
			{
				m_info.rating->widget->Release();
				m_info.rating->widget = NULL;
			}
			
			delete m_info.rating;
			m_info.rating = NULL;
		}
		
		m_infoStyles &= ~THUMB_INFO_STYLE_RATING;
	}

	void CThumbnail::m_UpdateInfoRating(int value)
	{
		if (value == m_info.rating->value)
		{
			return;
		}

		if (m_info.rating->widget != NULL)
		{
			int indexOffset = (m_info.rating->hasBg) ? 5 : 0;
			if (value > m_info.rating->value)
			{
				int startUpdate = m_info.rating->value / 2;
				int endUpate = (value - 1) / 2;
				for (int i = startUpdate; i <= endUpate; i++)
				{
					if (i == endUpate && (value % 2 != 0))
					{
						m_info.rating->widget->SetIcon(i + indexOffset, m_info.rating->halfImage, m_info.rating->halfOpacity);
					}
					else
					{
						m_info.rating->widget->SetIcon(i + indexOffset, m_info.rating->onImage, m_info.rating->onOpacity);
					}
				}
			}
			else
			{
				int endUpdate = (m_info.rating->value - 1) / 2;
				int startUpdate = value / 2;
				for (int i = endUpdate; i >= startUpdate; i--)
				{
					if (i == startUpdate && (value % 2 != 0))
					{
						m_info.rating->widget->SetIcon(i + indexOffset, m_info.rating->halfImage, m_info.rating->halfOpacity);
					}
					else
					{
						m_info.rating->widget->SetIcon(i + indexOffset, m_info.rating->offImage, m_info.rating->offOpacity);
					}
				}
			}
		}
		m_info.rating->value = value;
	}

	void CThumbnail::m_ModifyText(IText* widget, const TTextInfo &textInfo)
	{
		widget->SetPosition(textInfo.alloc.x, textInfo.alloc.y);
		widget->Resize(textInfo.alloc.w, textInfo.alloc.h);

		if (!textInfo.fontName.empty())
		{
			widget->SetFont(textInfo.fontName.c_str());
		}
		if (textInfo.bold)
		{
			widget->SetCharFormat(IText::STYLE_BOLD);
		}
		else
		{
			widget->SetCharFormat(IText::STYLE_NONE);
		}
		widget->EnableMultiLine(!textInfo.singleLineMode);
		widget->EnableEllipsize(textInfo.ellipsize);
		widget->SetTextAlignment(textInfo.hAlign, textInfo.vAlign);		

		if (!textInfo.text.empty())
		{
			widget->SetText(textInfo.text.c_str());
		}
		widget->SetAlpha(textInfo.opacity);
	}

	void CThumbnail::m_ModifyIcon(ImageWidget* widget, const TIconInfo &iconInfo)
	{
		widget->setX(iconInfo.alloc.x);
		widget->setY(iconInfo.alloc.y);
		widget->setWidth(iconInfo.alloc.w);
		widget->setHeight(iconInfo.alloc.h);

		widget->setAsyncLoading(iconInfo.async);
		widget->setSource(iconInfo.unpressName);

		widget->setOpacity(iconInfo.opacity);
	}

	void CThumbnail::m_EnlargeInfo(bool flagEnlarge, bool flagAni)
	{
		const float EPSINON = 0.00001f;

		if (NULL == m_info.root)
		{
			return;
		}

		if (flagEnlarge)
		{
			if ((m_info.enlargeFactor - 1.0 < -EPSINON) || (m_info.enlargeFactor - 1.0 > EPSINON))
			{
				int yOffset = 0;
				if (m_info.anchorPoint == ANCHOR_BOTTOM)
				{
					yOffset = m_info.alloc.h * (1 - m_info.enlargeFactor);
				}
				if (flagAni)
				{
					// update info allocation
					TValue1f destY(m_info.alloc.y + yOffset);
					TValue2f destSize(m_info.alloc.w, m_info.alloc.h * m_info.enlargeFactor);
					m_info.enlargeAni->SetDestination(m_info.root, IActor::ACTOR_ANI_POSITION_Y, &destY);
					m_info.enlargeAni->SetDestination(m_info.root, IActor::ACTOR_ANI_SIZE, &destSize);
					// update info icon
					int infoIconNum = m_info.icons.size();
					for (int i = 0; i < infoIconNum; i++)
					{
						IconItem *icon = m_info.icons[i];
						TValue1f destY(icon->alloc.y * m_info.enlargeFactor);
						m_info.enlargeAni->SetDestination(icon->widget, IActor::ACTOR_ANI_POSITION_Y, &destY);
					}
					// update info rating
					if (m_infoStyles & THUMB_INFO_STYLE_RATING)
					{
						TValue1f destY(m_info.rating->alloc.y * m_info.enlargeFactor);
						m_info.enlargeAni->SetDestination(m_info.rating->widget, IActor::ACTOR_ANI_POSITION_Y, &destY);
					}
				}
				else // !flagAni
				{
					// update info allocation
					m_info.root->setY(m_info.alloc.y + yOffset);
					m_info.root->setHeight(m_info.alloc.h * m_info.enlargeFactor);
					// update info icon
					int infoIconNum = m_info.icons.size();
					for (int i = 0; i < infoIconNum; i++)
					{
						IconItem *icon = m_info.icons[i];
						icon->widget->setY(icon->alloc.y * m_info.enlargeFactor);
					}
					// update info rating
					if (m_infoStyles & THUMB_INFO_STYLE_RATING)
					{
						m_info.rating->widget->SetPosition(m_info.rating->alloc.x, m_info.rating->alloc.y * m_info.enlargeFactor);
					}
				}
			}
			if (flagAni)
			{
				// update info text
				int infoTextNum = m_info.texts.size();
				for (int i = 0; i < infoTextNum; i++)
				{
					TextItem *text = m_info.texts[i];
					text->widget->SetFontSize(text->fontSize * text->enlargeFactor);
					float tempHeight = text->widget->PreferredHeight(text->alloc.w);
					float yOffset = 0;
					if (text->anchorPoint == ANCHOR_CENTER)
					{
						yOffset = (text->minHeight - tempHeight) / 2;
					}
					text->widget->Resize(text->alloc.w, text->alloc.h * m_info.enlargeFactor);
					// according to anchor point
					TValue1f destY(text->alloc.y * m_info.enlargeFactor + yOffset);
					m_info.enlargeAni->SetDestination(text->widget, IActor::ACTOR_ANI_POSITION_Y, &destY);
				}
				m_info.enlargeAni->Play();
			}
			else
			{
				// update info text
				int infoTextNum = m_info.texts.size();
				for (int i = 0; i < infoTextNum; i++)
				{
					TextItem *text = m_info.texts[i];
					text->widget->SetFontSize(text->fontSize * text->enlargeFactor);
					float tempHeight = text->widget->PreferredHeight(text->alloc.w);
					float yOffset = 0;
					if (text->anchorPoint == ANCHOR_CENTER)
					{
						yOffset = (text->minHeight - tempHeight) / 2;
					}
					text->widget->Resize(text->alloc.w, text->alloc.h * m_info.enlargeFactor);
					// according to anchor point
					text->widget->SetPosition(text->alloc.x, text->alloc.y * m_info.enlargeFactor + yOffset);
				}
			}
		}
		else
		{
			if ((m_info.enlargeFactor - 1.0 < -EPSINON) || (m_info.enlargeFactor - 1.0 > EPSINON))
			{
				// restore info root
				if (flagAni)
				{
					// restore info allocation
					TValue1f destY(m_info.alloc.y);
					TValue2f destSize(m_info.alloc.w, m_info.alloc.h);
					m_info.enlargeAni->SetDestination(m_info.root, IActor::ACTOR_ANI_POSITION_Y, &destY);
					m_info.enlargeAni->SetDestination(m_info.root, IActor::ACTOR_ANI_SIZE, &destSize);
					// restore info icon pos
					int infoIconNum = m_info.icons.size();
					for (int i = 0; i < infoIconNum; i++)
					{
						IconItem *icon = m_info.icons[i];
						TValue1f destY(icon->alloc.y);
						m_info.enlargeAni->SetDestination(icon->widget, IActor::ACTOR_ANI_POSITION_Y, &destY);
					}
					// restore info rating pos
					if (m_infoStyles & THUMB_INFO_STYLE_RATING)
					{
						m_info.rating->widget->SetPosition(m_info.rating->alloc.x, m_info.rating->alloc.y);
						TValue1f destY(m_info.rating->alloc.y);
						m_info.enlargeAni->SetDestination(m_info.rating->widget, IActor::ACTOR_ANI_POSITION_Y, &destY);
					}
				}
				else
				{
					// restore info allocation
					m_info.root->setY(m_info.alloc.y);
					m_info.root->setHeight(m_info.alloc.h);
					// restore info icon pos
					int infoIconNum = m_info.icons.size();
					for (int i = 0; i < infoIconNum; i++)
					{
						IconItem *icon = m_info.icons[i];
						icon->widget->setY(icon->alloc.y);
					}
					// restore info rating pos
					if (m_infoStyles & THUMB_INFO_STYLE_RATING)
					{
						m_info.rating->widget->SetPosition(m_info.rating->alloc.x, m_info.rating->alloc.y);
						m_info.rating->widget->SetPosition(m_info.rating->alloc.x, m_info.rating->alloc.y);
					}
				}
			}
			if (flagAni)
			{
				// restore font size
				int infoTextNum = m_info.texts.size();
				for (int i = 0; i < infoTextNum; i++)
				{
					TextItem *text = m_info.texts[i];
					text->widget->SetFontSize(text->fontSize);
					text->widget->Resize(text->alloc.w, text->alloc.h);
					TValue1f destY(text->alloc.y);
					m_info.enlargeAni->SetDestination(text->widget, IActor::ACTOR_ANI_POSITION_Y, &destY);
				}
				m_info.enlargeAni->Play();
			}
			else
			{
				// restore font size
				int infoTextNum = m_info.texts.size();
				for (int i = 0; i < infoTextNum; i++)
				{
					TextItem *text = m_info.texts[i];
					text->widget->SetFontSize(text->fontSize);
					text->widget->Resize(text->alloc.w, text->alloc.h);
					text->widget->SetPosition(text->alloc.x, text->alloc.y);
				}
			}
		}
	}

	void CThumbnail::SetTTSText(const std::string text)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] text(" << text << ")");
		m_ttsText = text;
	}		
	
	void CThumbnail::PlayTTSText()
	{
		H_LOG_TRACE(LOGGER, "[" <<this << "]");
#if !defined(WIN32) && !defined(LINUX_BUILD)
		TTSEngine::Instance().SetText(m_ttsText);
		TTSEngine::Instance().StopAndPlay();
	#endif
	}

	void CThumbnail::ScrollImage(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] m_styles(" << m_styles << ")");
		if (m_scrollPlayer != NULL)
		{
			m_scrollPlayer->PlayScroll();
		}	
	}

	bool CThumbnail::m_CreateScrollPlayer(const TScrollPlayerInfo &scrollPlayerInfo)
	{
		m_scrollPlayerHandler = new CScrollPlayerHandler(this);
		CScrollPlayer::T_ScrollPlayerAttr attr(scrollPlayerInfo.alloc.w, scrollPlayerInfo.alloc.h);
		attr.scrollAniDuration = scrollPlayerInfo.aniDuration;
		attr.scrollAniMode = scrollPlayerInfo.aniMode;
		attr.itemNum = scrollPlayerInfo.itemNumber;
		m_scrollPlayer = new CScrollPlayer;
		m_scrollPlayer->Initialize(this, &attr);
		m_SetId(dynamic_cast<Widget*>(m_scrollPlayer), "scroll-player");

		m_scrollPlayer->SetPosition(scrollPlayerInfo.alloc.x, scrollPlayerInfo.alloc.y);

		m_scrollPlayer->SetListener(m_scrollPlayerHandler);
		m_scrollPlayerAsyncLoad = scrollPlayerInfo.async;
		m_scrollDataSource = new CSingleLineDataSource;
		for (size_t i = 0; i < scrollPlayerInfo.srcList.size(); i++)
		{
			CScrollData* data = new CScrollData;
			data->index = i;
			data->imageSrc = scrollPlayerInfo.srcList.at(i);
			data->async = scrollPlayerInfo.async;
			data->fillMode = scrollPlayerInfo.fillMode;
			m_scrollDataSource->AddData(data);
		}
		
		m_scrollPlayer->SetDataSource(m_scrollDataSource);
	
		m_scrollPlayer->SetRendererProvider(m_scrollPlayerHandler);
		m_scrollPlayer->LoadData();
		m_scrollPlayer->Hide();

		m_styles |= THUMB_STYLE_SCROLLPLAYER;

		return true;
	}

	void CThumbnail::m_DestroyScrollPlayer(void)
	{
		if (m_scrollPlayerHandler != NULL)
		{
			delete m_scrollPlayerHandler;
			m_scrollPlayerHandler = NULL;
		}
		if (m_scrollDataSource != NULL)
		{			
			delete m_scrollDataSource;
			m_scrollDataSource = NULL;
		}
		if (m_scrollPlayer != NULL)
		{
			delete m_scrollPlayer;
			m_scrollPlayer = NULL;
		}

		m_styles &= ~THUMB_STYLE_SCROLLPLAYER;
	}

	void CThumbnail::SetScrollPlayerImages(std::map<int, std::string> srcMap)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] srcSize:" << srcMap.size());
		std::map<int, std::string>::iterator iter;

		for (iter = srcMap.begin(); iter != srcMap.end(); iter++)
		{
			CScrollData* data = (CScrollData*)m_scrollDataSource->GetData(iter->first);
			data->imageSrc = iter->second;
			data->async = m_scrollPlayerAsyncLoad;
			m_scrollPlayer->UpdateItem(iter->first);
			H_LOG_TRACE(LOGGER, "[" << this << "] src" << iter->first << " path " << iter->second.c_str());
		}
	}

	void CThumbnail::SetFoveaImageScaleFactor(float factor)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] factor(" << factor << ")");
		m_foveaImageScaleFactor = factor;
	}

	void CThumbnail::SetFoveaImageInterpolatorType(int type)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] type(" << type << ")");
		m_foveaImageInterpolatorType = type;
	}

	void CThumbnail::SetFoveaInfoBoxScaleFactor(float factor)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] factor(" << factor << ")");
		m_foveaInfoBoxScaleFactor = factor;
	}

	void CThumbnail::SetFoveaInfoBoxInterpolatorType(int type)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] type(" << type << ")");
		m_foveaInfoBoxInterpolatorType = type;
	}

	float CThumbnail::GetFoveaImageScaleFactor()
	{
		return m_foveaImageScaleFactor;
	}
	
	int CThumbnail::GetFoveaImageInterpolatorType()
	{
		return m_foveaImageInterpolatorType;
	}
	
	float CThumbnail::GetFoveaInfoBoxScaleFactor()
	{
		return m_foveaInfoBoxScaleFactor;
	}
	
	int CThumbnail::GetFoveaInfoBoxInterpolatorType()
	{
		return m_foveaInfoBoxInterpolatorType;
	}

#if !defined(WIN32) && !defined(LINUX_BUILD)
	bool CThumbnail::m_CreateVideoActor(const TVideoActorInfo &videoActorInfo)
	{
		m_videoActor = new CVideoActor;
		m_videoActor->Initialize((Widget*)this, videoActorInfo.alloc.w, videoActorInfo.alloc.h, videoActorInfo.type);
		m_SetId(dynamic_cast<Widget*>(m_videoActor), "video-actor");
		m_videoActor->SetPosition(videoActorInfo.alloc.x, videoActorInfo.alloc.y);
		if(videoActorInfo.uri.empty() == false && (videoActorInfo.type == CLUTTER_VC_TYPE_MM_SYNC || videoActorInfo.type ==  CLUTTER_VC_TYPE_MM_ASYNC))
		{	
			m_videoActor->SetUri(videoActorInfo.uri);
		}

		m_styles |= THUMB_STYLE_VIDEO;

		return true;
	}

	void CThumbnail::m_DestroyVideoActor(void)
	{
		if (m_videoActor != NULL)
		{
			m_videoActor->Release();
			m_videoActor = NULL;
		}
	}

	CVideoActor* CThumbnail::VideoActor(void)
	{
		return m_videoActor;
	}



#endif

	int CThumbnail::ScrollPlayerImageCount(void)
	{
		return m_scrollDataSource->NumOfData();
	}

	// CScrollPlayerHandler
	IRenderer* CScrollPlayerHandler::GetRenderer(IData *data, IActor* parent)
	{
		CScrollData *scrollData = dynamic_cast<CScrollData*>(data);
		CScrollPlayerRenderer * renderer = new CScrollPlayerRenderer(parent);
		if(scrollData != NULL && renderer != NULL)
		{
			float w, h;
			parent->GetSize(w, h);
			Widget* pa = dynamic_cast<Widget*>(parent);
			renderer->m_image = new CImageWidgetEx(0, 0, w, h, pa, m_RegisterReadyCallback(renderer));
			renderer->m_image->setAsyncLoading(scrollData->async);
			renderer->m_image->setFillMode(scrollData->fillMode);
		}
		return renderer;
	}

	ImageWidgetReadyCallback CScrollPlayerHandler::m_RegisterReadyCallback(CScrollPlayerRenderer *renderer)
	{
		ImageWidgetReadyCallback readyCallback = std::bind(m_ImageLoadReadyCallback, this, renderer, std::placeholders::_1);
		return readyCallback;
	}

	void CScrollPlayerHandler::m_ImageLoadReadyCallback(CScrollPlayerHandler* pThis, CScrollPlayerRenderer *renderer, bool success)
	{
		if (success && (renderer->m_dataIndex == 0))
		{
			pThis->m_owner->m_ResetAttachTextColor(renderer->m_image);
			pThis->m_owner->m_ResetInfoTextColor(renderer->m_image);
		}

		CThumbnailListenerSet::TThumbListenerData data;
		data.type = CThumbnail::EVENT_SCROLLIMAGE_READY;
		data.param[0] = renderer->m_dataIndex;
		data.param[1] = success;
		pThis->m_owner->m_listenerSet->Process(&data);
	}

	// CScrollPlayerRenderer
	void CScrollPlayerRenderer::Draw(IData *data, IActor* parent, E_DRAW_TYPE drawType)
	{
		CScrollData *scrollData = dynamic_cast<CScrollData*>(data);
		if(scrollData != NULL)
		{
			m_dataIndex = scrollData->index;
			m_image->setSource(scrollData->imageSrc);
		}
	}

}


