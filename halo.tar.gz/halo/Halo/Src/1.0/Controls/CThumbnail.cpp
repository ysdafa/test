#include "Halo1_0.h"

#ifndef WIN32
#include "TTSEngine.h"
#endif

namespace HALO
{
	static HALO::util::Logger LOGGER("Thumbnail");

	/*CThumbnailListenerSet*/
	class CThumbnailListenerSet : public ListenerSet
	{
	public:
		struct TThumbListenerData
		{
			int type;
			int param[4];
			void* pData;
		};

		CThumbnailListenerSet(CThumbnail* owner) :m_owner(owner){}
		virtual ~CThumbnailListenerSet(void){};

		virtual bool Process(TThumbListenerData* data);

	private:
		CThumbnail* m_owner;
	};

	bool CThumbnailListenerSet::Process(TThumbListenerData* data)
	{
		bool ret = false;
		if (NULL != data)
		{
			ListenerList::iterator iter = m_list.begin();

			while (iter != m_list.end())
			{
				IThumbnailListener* listener = (IThumbnailListener*)(*iter);

				switch (data->type)
				{
				case CThumbnail::EVENT_IMAGE_READY:
					H_LOG_TRACE(LOGGER, "CThumbnail::OnImageReady.[" << m_owner << "]" << data->param[0] << "load " << data->param[1]);
					ret |= listener->OnImageReady(m_owner, data->param[0], data->param[1]);
					break;
				case CThumbnail::EVENT_ICON_CLICKED:
					H_LOG_TRACE(LOGGER, "CThumbnail::OnIconClicked.[" << m_owner << "]" << data->param[0]);
					ret |= listener->OnIconClicked(m_owner, data->param[0]);
					break;
				case CThumbnail::EVENT_CHECK_STATE_CHANGED:
					H_LOG_TRACE(LOGGER, "CThumbnail::OnCheckMarkStateChanged.[" << m_owner << "]" << data->param[0]);
					ret |= listener->OnCheckMarkStateChanged(m_owner, data->param[0]);
					break;
				case CThumbnail::EVENT_PROGRESS_VALUE_CHANGED:
					H_LOG_TRACE(LOGGER, "CThumbnail::OnProgressValueChanged.[" << m_owner << "]" << data->param[0]);
					ret |= listener->OnProgressValueChanged(m_owner, data->param[0]);
					break;

				default:
					break;
				}
				iter++;
			}
		}

		return ret;
	}

	/*CThumbnail*/
	CThumbnail::CThumbnail() :
		m_styles(0),
		m_visibleStyles(0),
		m_infoStyles(0),
		m_utility(NULL),
		m_dimWin(NULL),
		m_dimUseImage(false),
		m_defalut(NULL),
		m_enabled(true),
		m_fontScaleEnabled(false),
		m_listenerSet(NULL),
		m_scrollPlayer(NULL),
		m_scrollPlayerAsyncLoad(true),
		m_scrollDataSource(NULL),
		m_scrollPlayerHandler(NULL)
	{
		m_scaleAniMode = CLUTTER_LINEAR;
		m_scaleAniDuration = 100;
		m_resizeAniMode = CLUTTER_LINEAR;
		m_resizeAniDuration = 100;
#ifndef WIN32
		m_videoActor = NULL;
#endif
	}

	CThumbnail::~CThumbnail()
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::~CThumbnail.[" << this << "]");
		if (m_listenerSet)
		{
			delete m_listenerSet;
			m_listenerSet = NULL;
		}
		
		if (m_utility)
		{
			delete m_utility;
			m_utility = NULL;
		}
		
		if (m_dimWin)
		{
			delete m_dimWin;
			m_dimWin = NULL;
		}
		
		if (m_defalut)
		{
			delete m_defalut;
			m_defalut = NULL;
		}
		
		if (m_styles & THUMB_STYLE_IMAGE)
		{
			m_DestroyContent();
		}
		if (m_styles & THUMB_STYLE_ICON)
		{
			while (m_attachIcons.size() != 0)
			{
				m_DestroyAttachIcon(0);
			}
		}
		if (m_styles & THUMB_STYLE_TEXT)
		{
			m_DestroyAttachText();
		}
		if (m_styles & THUMB_STYLE_PROGRESSBAR)
		{
			m_DestroyProgressBar();
		}
		if (m_styles & THUMB_STYLE_CHECKBOX)
		{
			m_DestroyCheckBox();
		}

		if (m_styles & THUMB_STYLE_INFO)
		{
			m_DestroyInfo();
		}
		if (m_styles & THUMB_STYLE_SCROLLPLAYER)
		{
			m_DestroyScrollPlayer();
		}
		if (m_styles & THUMB_STYLE_VIDEO)
		{
#ifndef WIN32
			m_DestroyVideoActor();
#endif
		}
		
	}

	bool CThumbnail::Initialize(Widget* parent, float width, float height, EThumbnailStyles styles, EThumbnailStyles visibleStyles, const TThumbnailAttr& attr)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::Initialize.[" << this << "]" << "parent(" << parent << ") width(" << width << ") height(" << height <<") styles(" << styles << ") visibleStyles(" << visibleStyles <<")");
		CActor::Initialize(parent, width, height);

		m_utility = new CUtility;

		if (styles & THUMB_STYLE_IMAGE)
		{
			m_CreateContent(attr.imageInfo);
		}
		if (styles & THUMB_STYLE_INFO)
		{
			m_CreateInfo(attr.info, attr.infoStyle);
		}
		if (styles & THUMB_STYLE_ICON)
		{
			int attachIconNum = attr.attachIconInfos.size();
			for (int i = 0; i < attachIconNum; i++)
			{
				m_CreateAttachIcon(attr.attachIconInfos[i]);
			}
		}
		if (styles & THUMB_STYLE_TEXT)
		{
			m_CreateAttachText(attr.attachTextInfo);
		}

		if (styles & THUMB_STYLE_PROGRESSBAR)
		{
			m_CreateProgressBar(attr.progressBar);
		}
		if (styles & THUMB_STYLE_CHECKBOX)
		{
			m_CreateCheckBox(attr.checkBox);
		}
		if (styles & THUMB_STYLE_SCROLLPLAYER)
		{
			m_CreateScrollPlayer(attr.scrollPlayerInfo);
		}
		if (styles & THUMB_STYLE_VIDEO)
		{
#ifndef WIN32
			m_CreateVideoActor(attr.videoActorInfo);
#endif
		}

		if ((styles & THUMB_STYLE_IMAGE) && !m_content.image.isReady && !attr.imageInfo.defaultSrc.empty())
		{
			m_defalut = new ImageWidget(0, 0, getWidth(), getHeight(), this);
			m_SetId(m_defalut, "default-image");
			m_defalut->setFillMode(ImageWidget::Center);
			m_defalut->setAsyncLoading(false);
			m_defalut->setSource(attr.imageInfo.defaultSrc);
		}

		this->EnableThumbnailStyles(true, visibleStyles, false);

		m_listenerSet = new class CThumbnailListenerSet(this);

		m_dimWin = new ImageWidget(0, 0, this);
		m_SetId(m_dimWin, "dim-win");
		Color color(0, 0, 0, 150);
		m_dimWin->setColor(color);
		m_dimWin->hide();

		return true;
	}

	bool CThumbnail::AddThumbnailListener(IThumbnailListener *listener)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::AddThumbnailListener[" << this << "]");
		ASSERT(listener != NULL);

		return m_listenerSet->Add(listener);
	}

	bool CThumbnail::OnMouseEvent(EMouseEventType eventType, IMouseEvent* pMouseEvent)
	{
		return false;
	}

	void CThumbnail::SetThumbnailStyle(EThumbnailStyles styles, EThumbnailStyles visibleStyles, const TThumbnailAttr& attr, bool flagAni)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetThumbnailStyle[" << this << "] styles(" << styles << ") visibleStyles(" << visibleStyles <<")");
		if (styles == 0)
		{
			setGradientFill(true);
		}
		else if (m_styles == 0)
		{
			setGradientFill(false);
		}

		if ((styles & THUMB_STYLE_IMAGE) && !(m_styles & THUMB_STYLE_IMAGE))
		{
			m_CreateContent(attr.imageInfo);
		}
		else if (!(styles & THUMB_STYLE_IMAGE) && (m_styles & THUMB_STYLE_IMAGE))
		{
			m_DestroyContent();
		}
		else if ((styles & THUMB_STYLE_IMAGE) && (m_styles & THUMB_STYLE_IMAGE))
		{
			/*if (m_content.image.widget)
			{
				m_content.image.widget->setAsyncLoading(attr.imageInfo.async);
				m_content.image.widget->setSource(attr.imageInfo.src);
			}*/
			m_content.root->SetPosition(attr.imageInfo.alloc.x, attr.imageInfo.alloc.y);
			m_content.root->Resize(attr.imageInfo.alloc.w, attr.imageInfo.alloc.h);

			float clipW = HALO_MAX(m_content.rootAlloc.w, attr.imageInfo.alloc.w);
			float clipH = HALO_MAX(m_content.rootAlloc.h, attr.imageInfo.alloc.h);
			m_content.root->SetClipArea(0, 0, clipW, clipH);
			m_content.rootAlloc = attr.imageInfo.alloc;
			m_content.image.alloc.w = attr.imageInfo.alloc.w;
			m_content.image.alloc.h = attr.imageInfo.alloc.h;

			std::vector<AnimatableProperty> propertiesToCancel;
			m_content.image.widgetAni->cancelAnimation(m_content.image.widget, propertiesToCancel);

			m_content.image.widgetAni->setDuration(m_resizeAniDuration);
			m_content.image.widgetAni->addKey(AnimatableProperty::Width, m_content.rootAlloc.w, false, TweenMode(m_resizeAniMode));
			m_content.image.widgetAni->addKey(AnimatableProperty::Height, m_content.rootAlloc.h, false, TweenMode(m_resizeAniMode));
			m_content.image.widgetAni->apply(m_content.image.widget, m_RegisterAnimationCallback());
		}
		// parse information
		if ((styles & THUMB_STYLE_INFO) && !(m_styles & THUMB_STYLE_INFO))
		{
			m_CreateInfo(attr.info, attr.infoStyle);
		}
		else if (!(styles & THUMB_STYLE_INFO) && (m_styles & THUMB_STYLE_INFO))
		{
			m_DestroyInfo();
		}
		else if ((styles & THUMB_STYLE_INFO) && (m_styles & THUMB_STYLE_INFO))
		{
			int oldInfoTextNum = m_info.texts.size();
			int newInfoTextNum = attr.info.textInfos.size();
			int i = 0;
			for (i = 0; i < newInfoTextNum; i++)
			{
				if (i >= oldInfoTextNum)
				{
					m_CreateInfoText(attr.info.textInfos[i]);
				}
				else
				{
					const TTextInfo &textInfo = attr.info.textInfos[i];
					m_ModifyText(m_info.texts[i]->widget, textInfo);
				}
			}

			if (i < oldInfoTextNum)
			{
				while ((int)m_info.texts.size() > i)
				{
					m_DestroyInfoText(i);
				}
			}

			int oldInfoIconNum = m_info.icons.size();
			int newInfoIconNum = attr.info.iconInfos.size();
			i = 0;
			for (i = 0; i < newInfoIconNum; i++)
			{
				if (i >= oldInfoIconNum)
				{
					m_CreateInfoIcon(attr.info.iconInfos[i]);
				}
				else
				{
					const TIconInfo &iconInfo = attr.info.iconInfos[i];
					m_ModifyIcon(m_info.icons[i]->widget, iconInfo);
				}
			}

			if (i < oldInfoIconNum)
			{
				while ((int)m_info.icons.size() > i)
				{
					m_DestroyInfoIcon(i);
				}
			}

			if ((attr.infoStyle & THUMB_INFO_STYLE_RATING) && !(m_infoStyles & THUMB_INFO_STYLE_RATING))
			{
				m_CreateInfoRating(attr.info.ratingInfo);
			}
			else if (!(attr.infoStyle & THUMB_INFO_STYLE_RATING) && (m_infoStyles & THUMB_INFO_STYLE_RATING))
			{
				m_DestroyInfoRating();
			}
			else if ((attr.infoStyle & THUMB_INFO_STYLE_RATING) && (m_infoStyles & THUMB_INFO_STYLE_RATING))
			{
				m_info.rating->widget->SetPosition(attr.info.ratingInfo.alloc.x, attr.info.ratingInfo.alloc.y);
				m_info.rating->widget->Resize(attr.info.ratingInfo.alloc.w, attr.info.ratingInfo.alloc.h);

				m_info.rating->onName = attr.info.ratingInfo.onName;
				m_info.rating->halfName = attr.info.ratingInfo.halfName;
				m_info.rating->offName = attr.info.ratingInfo.offName;

				m_UpdateInfoRating(attr.info.ratingInfo.value);
			}


			std::vector<AnimatableProperty> propertiesToCancel;
			m_info.rootAni->cancelAnimation(m_info.root, propertiesToCancel);

			//m_info.rootAni->setDuration(m_resizeAniDuration);
			m_info.rootAni->addKey(AnimatableProperty::PositionX, attr.info.alloc.x, false, TweenMode(m_resizeAniMode));
			m_info.rootAni->addKey(AnimatableProperty::PositionY, attr.info.alloc.y, false, TweenMode(m_resizeAniMode));
			m_info.rootAni->addKey(AnimatableProperty::Width, attr.info.alloc.w, false, TweenMode(m_resizeAniMode));
			m_info.rootAni->addKey(AnimatableProperty::Height, attr.info.alloc.h, false, TweenMode(m_resizeAniMode));
			m_info.rootAni->apply(m_info.root);
		}
		
		// parse attach icons
		if ((styles & THUMB_STYLE_ICON) && !(m_styles & THUMB_STYLE_ICON))
		{
			int attachIconNum = attr.attachIconInfos.size();
			for (int i = 0; i < attachIconNum; i++)
			{
				m_CreateAttachIcon(attr.attachIconInfos[i]);
			}
		}
		else if (!(styles & THUMB_STYLE_ICON) && (m_styles & THUMB_STYLE_ICON))
		{
			while (m_attachIcons.size() != 0)
			{
				m_DestroyAttachIcon(0);
			}
		}
		else if ((styles & THUMB_STYLE_ICON) && (m_styles & THUMB_STYLE_ICON))
		{
			int oldAttachIconNum = m_attachIcons.size();
			int newAttachIconNum = attr.attachIconInfos.size();
			int i = 0;
			for (i = 0; i < newAttachIconNum; i++)
			{
				if (i >= oldAttachIconNum)
				{
					m_CreateAttachIcon(attr.attachIconInfos[i]);
				}
				else
				{
					const TIconInfo &iconInfo = attr.attachIconInfos[i];
					m_ModifyIcon(m_attachIcons[i]->widget, iconInfo);

					if (iconInfo.clickable && !m_attachIcons[i]->clickable)
					{
						m_attachIcons[i]->mousePressedHandle = m_attachIcons[i]->widget->registerMouseEvent(Widget::MOUSE_DOWN, m_RegisterMouseEventCallback(m_mousePressedCallback));
						m_attachIcons[i]->mouseReleaseHandle = m_attachIcons[i]->widget->registerMouseEvent(Widget::MOUSE_UP, m_RegisterMouseEventCallback(m_mouseReleaseCallback));
						m_attachIcons[i]->mouseClickedHandle = m_attachIcons[i]->widget->registerMouseEvent(Widget::MOUSE_CLICK, m_RegisterMouseEventCallback(m_mouseClickedCallback));
					}
					else if (!iconInfo.clickable && m_attachIcons[i]->clickable)
					{
						m_attachIcons[i]->widget->unregisterMouseEvent(Widget::MOUSE_DOWN, m_attachIcons[i]->mousePressedHandle);
						m_attachIcons[i]->widget->unregisterMouseEvent(Widget::MOUSE_UP, m_attachIcons[i]->mouseReleaseHandle);
						m_attachIcons[i]->widget->unregisterMouseEvent(Widget::MOUSE_CLICK, m_attachIcons[i]->mouseClickedHandle);
					}

					m_attachIcons[i]->unpressName = iconInfo.unpressName;
					m_attachIcons[i]->pressedNmae = iconInfo.pressedName;
				}
			}

			if (i < oldAttachIconNum)
			{
				while ((int)m_attachIcons.size() > i)
				{
					m_DestroyAttachIcon(i);
				}
			}
		}
		// parse attach text
		if ((styles & THUMB_STYLE_TEXT) && !(m_styles & THUMB_STYLE_TEXT))
		{
			m_CreateAttachText(attr.attachTextInfo);
		}
		else if (!(styles & THUMB_STYLE_TEXT) && (m_styles & THUMB_STYLE_TEXT))
		{
			m_DestroyAttachText();
		}
		else if ((styles & THUMB_STYLE_TEXT) && (m_styles & THUMB_STYLE_TEXT))
		{
			m_ModifyText(m_attachText.widget, attr.attachTextInfo.textInfo);
		}
		// parse attach progress bar
		if ((styles & THUMB_STYLE_PROGRESSBAR) && !(m_styles & THUMB_STYLE_PROGRESSBAR))
		{
			m_CreateProgressBar(attr.progressBar);
		}
		else if (!(styles & THUMB_STYLE_PROGRESSBAR) && (m_styles & THUMB_STYLE_PROGRESSBAR))
		{
			m_DestroyProgressBar();
		}
		else if ((styles & THUMB_STYLE_PROGRESSBAR) && (m_styles & THUMB_STYLE_PROGRESSBAR))
		{
			m_progressBar.progess->SetPosition(attr.progressBar.alloc.x, attr.progressBar.alloc.y);
			m_progressBar.progess->Resize(attr.progressBar.alloc.w, attr.progressBar.alloc.h);
		}
		// parse attach check box
		if ((styles & THUMB_STYLE_CHECKBOX) && !(m_styles & THUMB_STYLE_CHECKBOX))
		{
			m_CreateCheckBox(attr.checkBox);
		}
		else if (!(styles & THUMB_STYLE_CHECKBOX) && (m_styles & THUMB_STYLE_CHECKBOX))
		{
			m_DestroyCheckBox();
		}
		else if ((styles & THUMB_STYLE_CHECKBOX) && (m_styles & THUMB_STYLE_CHECKBOX))
		{
			SetChecked(m_checkMark.isChecked);
			m_checkMark.widget->setX(attr.checkBox.alloc.x);
			m_checkMark.widget->setX(attr.checkBox.alloc.y);
			m_checkMark.widget->setWidth(attr.checkBox.alloc.w);
			m_checkMark.widget->setWidth(attr.checkBox.alloc.h);
		}
		// parse scroll player
		if ((styles & THUMB_STYLE_SCROLLPLAYER) && !(m_styles & THUMB_STYLE_SCROLLPLAYER))
		{
			m_CreateScrollPlayer(attr.scrollPlayerInfo);
		}
		else if (!(styles & THUMB_STYLE_SCROLLPLAYER) && (m_styles & THUMB_STYLE_SCROLLPLAYER))
		{
			m_DestroyScrollPlayer();
		}

		EThumbnailStyles disVisibleStyles = m_visibleStyles & (m_visibleStyles ^ visibleStyles);
		EThumbnailStyles newVisibleStyles = (~m_visibleStyles) & (m_visibleStyles ^ visibleStyles);
		newVisibleStyles |= visibleStyles & THUMB_STYLE_ICON ? THUMB_STYLE_ICON : 0;

		this->EnableThumbnailStyles(false, disVisibleStyles, false);
		this->EnableThumbnailStyles(true, newVisibleStyles, false);
	}

	void CThumbnail::EnableThumbnailStyle(bool enable, EThumbnailStyle style, bool flagAni)
	{
		if (!(m_styles & style))
		{
			return;
		}
		
		EThumbnailStyles _styles = style;
		EnableThumbnailStyles(enable, _styles, flagAni);
	}

	void CThumbnail::EnableThumbnailStyles(bool enable, EThumbnailStyles styles, bool flagAni)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::EnableThumbnailStyles[" << this << "] enable(" << enable << ") styles(" << styles << ")");
		if (styles & THUMB_STYLE_IMAGE)
		{
			if (!enable)
			{
				m_visibleStyles &= ~THUMB_STYLE_IMAGE;
				if (m_content.root) { m_content.root->Hide(); }
			}
			else if (m_styles & THUMB_STYLE_IMAGE)
			{
				m_visibleStyles |= THUMB_STYLE_IMAGE;
				if (m_content.root && (NULL == m_defalut)) { m_content.root->Show(); }
			}
		}
		
		if (styles & THUMB_STYLE_INFO)
		{
			if (!enable)
			{
				m_visibleStyles &= ~THUMB_STYLE_INFO;
				if (m_info.root) { m_info.root->hide(); }
			}
			else if (m_styles & THUMB_STYLE_INFO)
			{
				m_visibleStyles |= THUMB_STYLE_INFO;
				if (m_info.root && (NULL == m_defalut)) { m_info.root->show(); }
			}
		}

		if (styles & THUMB_STYLE_ICON)
		{
			if (!enable)
			{
				m_visibleStyles &= ~THUMB_STYLE_ICON;
			}
			else if (m_styles & THUMB_STYLE_ICON)
			{
				m_visibleStyles |= THUMB_STYLE_ICON;
			}
			int attachIconNum = m_attachIcons.size();
			for (int i = 0; i < attachIconNum; i++)
			{
				EnableAttachIcon(enable, i, flagAni);
			}
		}

		if (styles & THUMB_STYLE_TEXT)
		{
			if (!enable)
			{
				m_visibleStyles &= ~THUMB_STYLE_TEXT;
				if (m_attachText.widget) { m_attachText.widget->Hide(); }
			}
			else if (m_styles & THUMB_STYLE_TEXT)
			{
				m_visibleStyles |= THUMB_STYLE_TEXT;
				if (m_attachText.widget && (NULL == m_defalut)) { m_attachText.widget->Show(); }
			}
		}

		if (styles & THUMB_STYLE_PROGRESSBAR)
		{
			if (!enable)
			{
				m_visibleStyles &= ~THUMB_STYLE_PROGRESSBAR;
				if (m_progressBar.progess) { m_progressBar.progess->Hide(); }
			}
			else if (m_styles & THUMB_STYLE_PROGRESSBAR)
			{
				m_visibleStyles |= THUMB_STYLE_PROGRESSBAR;
				if (m_progressBar.progess && (NULL == m_defalut)) { m_progressBar.progess->Show(); }
			}
		}

		if (styles & THUMB_STYLE_CHECKBOX)
		{
			if (!enable)
			{
				m_visibleStyles &= ~THUMB_STYLE_CHECKBOX;
				if (m_checkMark.widget) { m_checkMark.widget->hide(); }
				SetChecked(false);
			}
			else if (m_styles & THUMB_STYLE_CHECKBOX)
			{
				m_visibleStyles |= THUMB_STYLE_CHECKBOX;
				if (m_checkMark.widget && (NULL == m_defalut)) { m_checkMark.widget->show(); }
			}
		}

		if (styles & THUMB_STYLE_SCROLLPLAYER)
		{
			if (!enable)
			{
				m_visibleStyles &= ~THUMB_STYLE_SCROLLPLAYER;
				if (m_scrollPlayer) { m_scrollPlayer->Hide(); }
			}
			else if (m_styles & THUMB_STYLE_SCROLLPLAYER)
			{
				m_visibleStyles |= THUMB_STYLE_SCROLLPLAYER;
				if (m_scrollPlayer && (NULL == m_defalut)) { m_scrollPlayer->Show(); }
			}
		}
		
	}

	void CThumbnail::EnableAttachIcon(bool enable, int iconIndex, bool flagAni)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::EnableAttachIcon[" << this << "] enable(" << enable << ") iconIndex(" << iconIndex << ")");
		ASSERT(m_styles & THUMB_STYLE_ICON);
		ASSERT(iconIndex >= 0 && iconIndex < (int)m_attachIcons.size());

		if (enable && (NULL == m_defalut))
		{
			m_attachIcons[iconIndex]->widget->show();
		}
		else
		{
			m_attachIcons[iconIndex]->widget->hide();
		}
	}

	void CThumbnail::EnableInformationIcon(bool enable, int iconIndex, bool flagAni)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::EnableInformationIcon[" << this << "] enable(" << enable << ") iconIndex(" << iconIndex << ")");
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(iconIndex >= 0 && iconIndex < (int)m_info.icons.size());

		if (enable)
		{
			m_info.icons[iconIndex]->widget->show();
		}
		else
		{
			m_info.icons[iconIndex]->widget->hide();
		}
	}

	void CThumbnail::EnableInformationText(bool enable, int textIndex, bool flagAni)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::EnableInformationText[" << this << "] enable(" << enable << ") textIndex(" << textIndex << ")");
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(textIndex >= 0 && textIndex < (int)m_info.texts.size());

		if (enable)
		{
			m_info.texts[textIndex]->widget->Show();
		}
		else
		{
			m_info.texts[textIndex]->widget->Hide();
		}
	}

	void CThumbnail::SetImage(const char* fileName)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetImage[" << this << "] fileName(" << fileName << ")");
		ASSERT(m_styles & THUMB_STYLE_IMAGE);
		ASSERT(fileName != NULL);

		if (m_content.image.widget)
		{
			m_content.image.widget->setSource(fileName);
		}
	}

	void CThumbnail::SetAttachTextColorPickingRange(int fromHPer, int toHPer, int fromVPer, int toVPer)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetAttachTextColorPickingRange[" << this << "] range(h1:" << fromHPer <<",h2:" <<toHPer << ",v1:" << fromVPer << ",v2:" << toVPer << ")");
		ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.colorPickingRange.Set(fromHPer, toHPer, fromVPer, toVPer);
		if (m_content.image.isReady)
		{
			m_ResetAttachTextColor(m_content.image.widget);
		}
	}

	void CThumbnail::SetInformationColorPickingRange(int fromHPer, int toHPer, int fromVPer, int toVPer)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetInformationColorPickingRange[" << this << "] range(h1:" << fromHPer << ",h2:" << toHPer << ",v1:" << fromVPer << ",v2:" << toVPer << ")");
		ASSERT(m_styles & THUMB_STYLE_INFO);

		m_info.colorPickingRange.Set(fromHPer, toHPer, fromVPer, toVPer);
		if (m_content.image.isReady)
		{
			m_ResetInfoTextColor(m_content.image.widget);
		}
	}

	bool CThumbnail::GetInformationColorPicking(Color &color)
	{
		color = m_info.bgColorPicking;
		H_LOG_TRACE(LOGGER, "CThumbnail::GetInformationColorPicking[" << this << "] color(r:" << color.r << ",g:" << color.g << ",b:" << color.b << ",a:" << color.a << ")");

		return m_info.colorPickingReady;
	}

	bool CThumbnail::GetInformationExtractColor(Color &color)
	{
		color = m_info.fgColorExtracted;
		H_LOG_TRACE(LOGGER, "CThumbnail::GetInformationExtractColor[" << this << "] color(r:" << color.r << ",g:" << color.g << ",b:" << color.b << ",a:" << color.a << ")");

		return m_info.colorPickingReady;
	}

	bool CThumbnail::GetColorPicking(int fromHPer, int toHPer, int fromVPer, int toVPer, Color &color)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::GetColorPicking[" << this << "] range(h1:" << fromHPer << ",h2:" << toHPer << ",v1:" << fromVPer << ",v2:" << toVPer << ") imageReady:" << m_content.image.isReady);
		if (m_content.image.isReady)
		{
			if (m_content.image.widget)
			{
				//float x1, x2, y1, y2;
				//m_content.image.widget->getImageCroppedCoord(&x1, &y1, &x2, &y2);
				//return m_content.image.widget->getColorPicking(0, x1, x2, y1, y2, &color);
			}
		}
		
		return false;
	}

	void CThumbnail::AddAttachIcon(const std::vector<TIconInfo> &iconInfo)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::AddAttachIcon[" << this << "]");
		int attachIconNum = iconInfo.size();
		for (int i = 0; i < attachIconNum; i++)
		{
			m_CreateAttachIcon(iconInfo[i]);
		}
	}

	void CThumbnail::RemoveAttachIcon(int index)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::RemoveAttachIcon[" << this << "] index(" << index << ")");
		ASSERT(m_styles & THUMB_STYLE_ICON);
		ASSERT(index >= 0 && index < (int)m_attachIcons.size());

		m_DestroyAttachIcon(index);
	}

	int CThumbnail::AttachedIconNumber(void)
	{
		return m_attachIcons.size();
	}

	void CThumbnail::SetAttachIconImage(int index, const char* fileName)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetAttachIconImage[" << this << "] index(" << index << ") fileName(" << fileName <<")");
		ASSERT(m_styles & THUMB_STYLE_ICON);
		ASSERT(index >= 0 && index < (int)m_attachIcons.size());
		ASSERT(fileName != NULL);

		m_attachIcons[index]->widget->setSource(fileName);
	}

	void CThumbnail::AddAttachText(const TAttachText &atInfo)
	{
		m_CreateAttachText(atInfo);
	}

	void CThumbnail::RemoveAttachText()
	{
		ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_DestroyAttachText();
	}

	void CThumbnail::SetAttachText(const char* text)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetAttachText[" << this << "] text(" << text<< ")");
		ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->SetText(text);
	}

	void CThumbnail::SetAttachTextColor(Color color)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetAttachTextColor[" << this << "] color(r:" << color.r << ",g:" << color.g <<",b:" <<color.b <<",a:" << color.a << ")");
		ASSERT(m_styles & THUMB_STYLE_TEXT);

		if (m_attachText.widget)
		{
			m_attachText.textColor = color;
			m_attachText.widget->SetTextColor(*color.toClutterColor());
		}
	}

	void CThumbnail::SetAttachTextFont(const char* font)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetAttachTextFont[" << this << "] font(" << font<< ")");
		ASSERT(m_styles & THUMB_STYLE_TEXT);
		ASSERT(font != NULL);

		if (m_attachText.widget)
		{
			m_attachText.widget->SetFont(font);
		}
	}

	void CThumbnail::SetAttachTextScrollAttribute(guint duration, guint delay, gint repeat, ClutterTextScrollType type, ClutterTimelineDirection direction, guint continueGap)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetAttachTextScrollAttribute[" << this << "] duration(" << duration << ") delay(" << delay << ") repeat(" << repeat << ") type(" << type << ") direction(" <<direction <<") gap(" <<continueGap << ")");
		ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->SetScrollAttribute(duration, delay, repeat, type, direction, continueGap);
	}

	void CThumbnail::EnableAttachTextAutoScroll(bool enable)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::EnableAttachTextAutoScroll[" << this << "] enable(" << enable << ")");
		ASSERT(m_styles & THUMB_STYLE_TEXT);

		if (enable)
		{
			m_attachText.widget->StartScrollText();
		}
		else
		{
			m_attachText.widget->StopScrollText();
		}
	}

	bool CThumbnail::isAttachTextAutoScrollEnabled(void)
	{
		return false;
	}

	void CThumbnail::EnableAttachTextEllipsize(bool enable)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::EnableAttachTextEllipsize[" << this << "] enable(" << enable << ")");
		ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->EnableEllipsize(enable);
	}

	bool CThumbnail::isAttachTextEllipsizeEnabled(void)
	{
		ASSERT(m_styles & THUMB_STYLE_TEXT);

		return m_attachText.widget->IsEllipsizeEnable();
	}

	void CThumbnail::EnableAttachTextMultiLine(bool enable)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::EnableAttachTextMultiLine[" << this << "] enable(" << enable << ")");
		ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->EnableMultiLine(enable);
	}

	bool CThumbnail::isAttachTextMultiLineEnabled(void)
	{
		ASSERT(m_styles & THUMB_STYLE_TEXT);
		
		return m_attachText.widget->IsMultiLineEnabled();
	}


	void CThumbnail::AddProgressBar(const TProgressBarInfo &pbInfo)
	{
		m_CreateProgressBar(pbInfo);
	}

	void CThumbnail::RemoveProgressBar(void)
	{
		ASSERT(m_styles & THUMB_STYLE_PROGRESSBAR);

		m_DestroyProgressBar();
	}

	void CThumbnail::SetProgressBarRange(int min, int max)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetProgressRange[" <<this << "] range(min:" << min <<" max:" << max << ")");
		ASSERT(m_styles & THUMB_STYLE_PROGRESSBAR);

		if (m_progressBar.progess)
		{
			m_progressBar.progess->SetMinValue(min);
			m_progressBar.progess->SetMaxValue(max);
		}
	}

	void CThumbnail::SetProgressBarValue(int value)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetProgressValue[" <<this << "] value(" << value << ")");
		ASSERT(m_styles & THUMB_STYLE_PROGRESSBAR);

		if (m_progressBar.progess)
		{
			m_progressBar.progess->SetValue(value);
		}
	}

	void CThumbnail::AddCheckBox(const TCheckBoxInfo &cbInfo)
	{
		m_CreateCheckBox(cbInfo);
	}

	void CThumbnail::RemoveCheckBox(void)
	{
		ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		m_DestroyCheckBox();
	}

	void CThumbnail::AddInformationText(const std::vector<TTextInfo> &textInfo)
	{
		ASSERT(m_styles & THUMB_STYLE_INFO);

		int textNum = textInfo.size();
		for (int i = 0; i < textNum; i++)
		{
			m_CreateInfoText(textInfo[i]);
		}
	}

	void CThumbnail::RemoveInformationText(int index)
	{
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.texts.size());

		m_DestroyInfoText(index);
	}

	int CThumbnail::InformationTextNumber(void)
	{
		return m_info.texts.size();
	}

	void CThumbnail::SetInformationText(int index, const char* text)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetInformationText[" << this << "] index(" << index << ") text(" <<text << ")");
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.texts.size());
		ASSERT(text != NULL);

		m_info.texts[index]->widget->SetText(text);
	}

	void CThumbnail::SetInformationTextColor(int index, Color color)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetInformationTextColor[" << this << "] index(" << index << ") color(r:" << color.r << ",g:" << color.g << ",b:" << color.b << ",a:" << color.a << ")");
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.texts.size());

		if (m_info.texts[index]->widget)
		{
			m_info.texts[index]->widget->SetTextColor(*color.toClutterColor());
		}
	}

	void CThumbnail::SetInformationTextFont(int index, const char* font)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetInformationTextFont[" << this << "] index(" << index << ") font(" << font << ")");
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.texts.size());
		ASSERT(font != NULL);

		if (m_info.texts[index]->widget)
		{
			m_info.texts[index]->widget->SetFont(font);
		}
	}

	void CThumbnail::SetInformationTextScrollAttribute(int index, guint duration, guint delay, gint repeat, ClutterTextScrollType type, ClutterTimelineDirection direction, guint continueGap)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetInformationTextScrollAttribute[" << this << "] index(" <<index << ") duration(" << duration << ") delay(" << delay << ") repeat(" << repeat << ") type(" << type << ") direction(" << direction << ") gap(" << continueGap << ")");
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.texts.size());

		m_info.texts[index]->widget->SetScrollAttribute(duration, delay, repeat, type, direction, continueGap);
	}

	void CThumbnail::EnableInformationTextAutoScroll(int index, bool enable)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::EnableInformationTextAutoScroll[" << this << "] index(" << index << ") enable(" << enable << ")");
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.texts.size());

		if (enable)
		{
			m_info.texts[index]->widget->StartScrollText();
		}
		else
		{
			m_info.texts[index]->widget->StopScrollText();
		}
	}

	bool CThumbnail::isInformationTextAutoScrollEnabled(int index)
	{
		return false;
	}

	void CThumbnail::EnableInformationTextEllipsize(int index, bool enable)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::EnableInformationTextEllipsize[" << this << "] index(" << index << ") enable(" << enable << ")");
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.texts.size());

		m_info.texts[index]->widget->EnableEllipsize(enable);
	}

	bool CThumbnail::isInformationTextEllipsizeEnabled(int index)
	{
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.texts.size());

		return m_info.texts[index]->widget->IsEllipsizeEnable();
	}

	void CThumbnail::EnableInformationTextMultiLine(int index, bool enable)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::EnableInformationTextMultiLine[" << this << "] index(" << index << ") enable(" << enable << ")");
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.texts.size());

		m_info.texts[index]->widget->EnableMultiLine(enable);
	}

	bool CThumbnail::isInformationTextMultiLineEnabled(int index)
	{
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.texts.size());

		return m_info.texts[index]->widget->IsMultiLineEnabled();
	}

	void CThumbnail::SetInformationRatingValue(int value)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetInformationRatingValue[" << this << "] value(" << value << ")");
		ASSERT(m_infoStyles & THUMB_INFO_STYLE_RATING);
		ASSERT(value >= 0 && value <= 10);

		if (m_info.rating && m_info.rating->widget)
		{
			m_UpdateInfoRating(value);
		}
	}

	void CThumbnail::AddInformationIcon(const std::vector<TIconInfo> &iconInfo)
	{
		ASSERT(m_styles & THUMB_STYLE_INFO);

		int iconNum = iconInfo.size();
		for (int i = 0; i < iconNum; i++)
		{
			m_CreateInfoIcon(iconInfo[i]);
		}
	}

	void CThumbnail::RemoveInformationIcon(int index)
	{
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.icons.size());

		m_DestroyInfoIcon(index);
	}

	int CThumbnail::InformationIconNumber(void)
	{
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(m_infoStyles & THUMB_INFO_STYLE_ICON);

		return m_info.icons.size();
	}

	void CThumbnail::SetInformationIconImage(int index, const char* fileName)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetInformationIconImage[" << this << "] index(" << index << ") fileName(" << fileName << ")");
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.icons.size());
		ASSERT(fileName != NULL);

		m_info.icons[index]->widget->setSource(fileName);
	}

	void CThumbnail::SetImagePosition(float x, float y)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetImagePosition[" << this << "] pos(" << x << "," << y << ")");
		ASSERT(m_styles & THUMB_STYLE_IMAGE);

		if (m_content.root)
		{
			m_content.root->SetPosition(x, y);
			m_content.rootAlloc.x = x;
			m_content.rootAlloc.y = y;
		}
	}

	void CThumbnail::GetImagePosition(float &x, float &y)
	{
		ASSERT(m_styles & THUMB_STYLE_IMAGE);

		if (m_content.root)
		{
			m_content.root->GetPosition(x, y);
		}
		H_LOG_TRACE(LOGGER, "CThumbnail::GetImagePosition[" << this << "] pos(" << x << "," << y << ")");
	}

	void CThumbnail::ResizeImage(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::ResizeImage[" << this << "] size(" << width << "," << height << ")");
		ASSERT(m_styles & THUMB_STYLE_IMAGE);

		if (m_content.root)
		{
			m_content.root->Resize(width, height);
			m_content.rootAlloc.w = width;
			m_content.rootAlloc.h = height;
			m_content.root->SetClipArea(0, 0, width, height);
			m_content.image.widget->setWidth(width);
			m_content.image.widget->setHeight(height);
			m_content.image.alloc.w = width;
			m_content.image.alloc.h = height;
		}
	}

	void CThumbnail::GetImageSize(float &width, float &height)
	{
		ASSERT(m_styles & THUMB_STYLE_IMAGE);

		if (m_content.image.widget)
		{
			width = m_content.image.widget->getWidth();
			height = m_content.image.widget->getHeight();
		}
		H_LOG_TRACE(LOGGER, "CThumbnail::GetImageSize[" << this << "] size(" << width << "," << height << ")");
	}

	void CThumbnail::SetAttachIconPosition(int index, float x, float y)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetAttachIconPosition[" << this << "] index(" << index << ") pos(" << x << "," << y << ")");
		ASSERT(m_styles & THUMB_STYLE_ICON);
		ASSERT(index >= 0 && index < (int)m_attachIcons.size());

		m_attachIcons[index]->widget->setX(x);
		m_attachIcons[index]->widget->setY(y);
		m_attachIcons[index]->alloc.x = x;
		m_attachIcons[index]->alloc.y = y;
	}

	void CThumbnail::GetAttachIconPosition(int index, float &x, float &y)
	{
		ASSERT(m_styles & THUMB_STYLE_ICON);
		ASSERT(index >= 0 && index < (int)m_attachIcons.size());

		x = m_attachIcons[index]->widget->getX();
		y = m_attachIcons[index]->widget->getY();
		H_LOG_TRACE(LOGGER, "CThumbnail::GetAttachIconPosition[" << this << "] index(" << index << ") pos(" << x << "," << y << ")");
	}

	void CThumbnail::ResizeAttachIcon(int index, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::ResizeAttachIcon[" << this << "] index(" << index << ") size(" << width << "," << height << ")");
		ASSERT(m_styles & THUMB_STYLE_ICON);
		ASSERT(index >= 0 && index < (int)m_attachIcons.size());

		m_attachIcons[index]->widget->setWidth(width);
		m_attachIcons[index]->widget->setHeight(height);
		m_attachIcons[index]->alloc.w = width;
		m_attachIcons[index]->alloc.h = height;
	}

	void CThumbnail::GetAttachIconSize(int index, float &width, float &height)
	{
		ASSERT(m_styles & THUMB_STYLE_ICON);
		ASSERT(index >= 0 && index < (int)m_attachIcons.size());

		width = m_attachIcons[index]->widget->getWidth();
		height = m_attachIcons[index]->widget->getHeight();
		H_LOG_TRACE(LOGGER, "CThumbnail::GetAttachIconSize[" << this << "] index(" << index << ") size(" << width << "," << height << ")");
	}

	void CThumbnail::SetAttachTextPosition(float x, float y)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetAttachTextPosition[" << this << "] pos(" << x << "," << y << ")");
		ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->SetPosition(x, y);
		m_attachText.alloc.x = x;
		m_attachText.alloc.y = y;
	}

	void CThumbnail::GetAttachTextPosition(float &x, float &y)
	{
		ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->GetPosition(x, y);
		H_LOG_TRACE(LOGGER, "CThumbnail::GetAttachTextPosition[" << this << "] pos(" << x << "," << y << ")");
	}

	void CThumbnail::ResizeAttachText(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::ResizeAttachText[" << this << "] size(" << width << "," << height << ")");
		ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->Resize(width, height);
		m_attachText.alloc.w = width;
		m_attachText.alloc.h = height;
	}

	void CThumbnail::GetAttachTextSize(float &width, float &height)
	{
		ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->GetSize(width, height);
		H_LOG_TRACE(LOGGER, "CThumbnail::GetAttachTextSize[" << this << "] size(" << width << "," << height << ")");
	}

	void CThumbnail::SetCheckBoxPosition(float x, float y)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetCheckBoxPosition[" << this << "] pos(" << x << "," << y << ")");
		ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		m_checkMark.widget->setX(x);
		m_checkMark.widget->setY(y);
		m_checkMark.alloc.x = x;
		m_checkMark.alloc.y = y;
	}

	void CThumbnail::GetCheckBoxPosition(float &x, float &y)
	{
		ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		x = m_checkMark.widget->getX();
		y = m_checkMark.widget->getY();
		H_LOG_TRACE(LOGGER, "CThumbnail::GetCheckBoxPosition[" << this << "] pos(" << x << "," << y << ")");
	}

	void CThumbnail::ResizeCheckBox(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::ResizeCheckBox[" << this << "] size(" << width << "," << height << ")");
		ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		m_checkMark.widget->setWidth(width);
		m_checkMark.widget->setHeight(height);
		m_checkMark.alloc.w = width;
		m_checkMark.alloc.h = height;
	}

	void CThumbnail::GetCheckBoxSize(float &width, float &height)
	{
		ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		width = m_checkMark.widget->getWidth();
		height = m_checkMark.widget->getHeight();
		H_LOG_TRACE(LOGGER, "CThumbnail::GetCheckBoxSize[" << this << "] size(" << width << "," << height << ")");
	}

	void CThumbnail::SetProgressBarPosition(float x, float y)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetProgressBarPosition[" << this << "] pos(" << x << "," << y << ")");
		ASSERT(m_styles & THUMB_STYLE_PROGRESSBAR);

		m_progressBar.progess->SetPosition(x, y);
		m_progressBar.alloc.x = x;
		m_progressBar.alloc.y = y;
	}

	void CThumbnail::GetProgressBarPosition(float &x, float &y)
	{
		ASSERT(m_styles & THUMB_STYLE_PROGRESSBAR);

		m_progressBar.progess->GetPosition(x, y);
		H_LOG_TRACE(LOGGER, "CThumbnail::GetProgressBarPosition[" << this << "] pos(" << x << "," << y << ")");
	}

	void CThumbnail::ResizeProgressBar(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::ResizeProgressBar[" << this << "] size(" << width << "," << height << ")");
		ASSERT(m_styles & THUMB_STYLE_PROGRESSBAR);

		m_progressBar.progess->Resize(width, height);
		m_progressBar.alloc.w = width;
		m_progressBar.alloc.h = height;
	}

	void CThumbnail::GetProgressBarSize(float &width, float &height)
	{
		ASSERT(m_styles & THUMB_STYLE_PROGRESSBAR);

		m_progressBar.progess->GetSize(width, height);
		H_LOG_TRACE(LOGGER, "CThumbnail::GetProgressBarSize[" << this << "] size(" << width << "," << height << ")");
	}

	void CThumbnail::SetInformationPosition(float x, float y)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetInformationPosition[" << this << "] pos(" << x << "," << y << ")");
		ASSERT(m_styles & THUMB_STYLE_INFO);

		m_info.root->setX(x);
		m_info.root->setY(y);
		m_info.alloc.x = x;
		m_info.alloc.y = y;
	}

	void CThumbnail::GetInformationPosition(float &x, float &y)
	{
		ASSERT(m_styles & THUMB_STYLE_INFO);

		x = m_info.root->getX();
		y = m_info.root->getY();
		H_LOG_TRACE(LOGGER, "CThumbnail::GetInformationPosition[" << this << "] pos(" << x << "," << y << ")");
	}

	void CThumbnail::ResizeInformation(float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::ResizeInformation[" << this << "] size(" << width << "," << height << ")");
		ASSERT(m_styles & THUMB_STYLE_INFO);

		m_info.root->setWidth(width);
		m_info.root->setHeight(height);
		m_info.alloc.w = width;
		m_info.alloc.h = height;
	}

	void CThumbnail::GetInformationSize(float &width, float &height)
	{
		ASSERT(m_styles & THUMB_STYLE_INFO);

		width = m_info.root->getWidth();
		height = m_info.root->getHeight();
		H_LOG_TRACE(LOGGER, "CThumbnail::GetInformationSize[" << this << "] size(" << width << "," << height << ")");
	}

	void CThumbnail::SetInformationIconPosition(int index, float x, float y)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetInformationIconPosition[" << this << "] index(" << index << ") pos(" << x << "," << y << ")");
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.icons.size());

		m_info.icons[index]->widget->setX(x);
		m_info.icons[index]->widget->setY(y);
		m_info.icons[index]->alloc.x = x;
		m_info.icons[index]->alloc.y = y;
	}

	void CThumbnail::GetInformationIconPosition(int index, float &x, float &y)
	{
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.icons.size());

		x = m_info.icons[index]->widget->getX();
		y = m_info.icons[index]->widget->getY();
		H_LOG_TRACE(LOGGER, "CThumbnail::GetInformationIconPosition[" << this << "] index(" << index << ") pos(" << x << "," << y << ")");
	}

	void CThumbnail::ResizeInformationIcon(int index, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::ResizeInformationIcon[" << this << "] index(" << index << ") size(" << width << "," << height << ")");
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.icons.size());

		m_info.icons[index]->widget->setWidth(width);
		m_info.icons[index]->widget->setHeight(height);
		m_info.icons[index]->alloc.w = width;
		m_info.icons[index]->alloc.h = height;
	}

	void CThumbnail::GetInformationIconSize(int index, float &width, float &height)
	{
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.icons.size());

		width = m_info.icons[index]->widget->getWidth();
		height = m_info.icons[index]->widget->getHeight();
		H_LOG_TRACE(LOGGER, "CThumbnail::GetInformationIconSize[" << this << "] index(" << index << ") size(" << width << "," << height << ")");
	}

	void CThumbnail::SetInformationTextPosition(int index, float x, float y)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetInformationTextPosition[" << this << "] index(" << index << ") pos(" << x << "," << y << ")");
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.texts.size());

		m_info.texts[index]->widget->SetPosition(x, y);
		m_info.texts[index]->alloc.x = x;
		m_info.texts[index]->alloc.y = y;
	}

	void CThumbnail::GetInformationTextPosition(int index, float &x, float &y)
	{
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.texts.size());

		m_info.texts[index]->widget->GetPosition(x, y);
		H_LOG_TRACE(LOGGER, "CThumbnail::GetInformationTextPosition[" << this << "] index(" << index << ") pos(" << x << "," << y << ")");
	}

	void CThumbnail::ResizeInformationText(int index, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::ResizeInformationText[" << this << "] index(" << index << ") size(" << width << "," << height << ")");
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.texts.size());

		m_info.texts[index]->widget->Resize(width, height);
		m_info.texts[index]->alloc.w = width;
		m_info.texts[index]->alloc.h = height;
	}

	void CThumbnail::GetInformationTextSize(int index, float &width, float &height)
	{
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.texts.size());

		m_info.texts[index]->widget->GetSize(width, height);
		H_LOG_TRACE(LOGGER, "CThumbnail::GetInformationTextSize[" << this << "] index(" << index << ") size(" << width << "," << height << ")");
	}

	void CThumbnail::SetAttachIconOpacity(int index, int opacity)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetAttachIconOpacity[" << this << "] index(" << index << ") opacity(" << opacity << ")");
		ASSERT(m_styles & THUMB_STYLE_ICON);
		ASSERT(index >= 0 && index < (int)m_attachIcons.size());
 
		m_attachIcons[index]->widget->setOpacity(opacity);
	}

	int CThumbnail::AttachIconOpacity(int index)
	{
		ASSERT(m_styles & THUMB_STYLE_ICON);
		ASSERT(index >= 0 && index < (int)m_attachIcons.size());

		return m_attachIcons[index]->widget->getOpacity();
	}

	void CThumbnail::SetAttachTextOpacity(int opacity)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetAttachTextOpacity[" << this << "] opacity(" << opacity << ")");
		ASSERT(m_styles & THUMB_STYLE_TEXT);

		m_attachText.widget->SetAlpha(opacity);
	}

	int  CThumbnail::AttachTextOpacity(void)
	{
		ASSERT(m_styles & THUMB_STYLE_TEXT);

		return m_attachText.widget->Alpha();
	}

	void CThumbnail::SetInformationIconOpacity(int index, int opacity)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetInformationIconOpacity[" << this << "] index(" << index << ") opacity(" << opacity << ")");
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.icons.size());

		m_info.icons[index]->widget->setOpacity(opacity);
	}

	int  CThumbnail::InformationIconOpacity(int index)
	{
		ASSERT(m_styles & THUMB_STYLE_INFO);
		ASSERT(index >= 0 && index < (int)m_info.icons.size());

		return m_info.icons[index]->widget->getOpacity();
	}

	IThumbnail::EThumbnailStyles CThumbnail::VisibleThumbnailStyles(void)
	{
		return m_visibleStyles;
	}

	IThumbnail::EThumbnailStyles CThumbnail::ThumbnailStyle(void)
	{
		return m_styles;
	}

	IThumbnail::EInformationStyles CThumbnail::ThumbnailInformationStyle(void)
	{
		return m_infoStyles;
	}

	void CThumbnail::SetScaleAnimation(int duration, ClutterAnimationMode mode)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetScaleAnimation[" << this << "] duration(" << duration << ") mode(" << mode << ")");
		m_scaleAniDuration = duration;
		m_scaleAniMode = mode;

		if (m_info.textAni)
		{
			m_info.textAni->SetDuration(duration);
			m_info.textAni->SetMode(mode);
		}
	}

	void CThumbnail::SetStyleTransAnimation(int duration, ClutterAnimationMode mode)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetStyleTransAnimation[" << this << "] duration(" << duration << ") mode(" << mode << ")");
		m_resizeAniDuration = duration;
		m_resizeAniMode = mode;

		if (m_info.rootAni)
		{
			m_info.rootAni->setDuration(duration);
		}
	}

	void CThumbnail::Scale(TValue2f imageScaleFactor, bool flagAni)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::Scale-Image[" << this << "] imageScaleFactor(" << imageScaleFactor.val[0] << "," << imageScaleFactor.val[1] << ") flagAni(" << flagAni << ")");
		if (0 == (m_visibleStyles & THUMB_STYLE_IMAGE))
		{
			return;
		}

		float destW = m_content.image.alloc.w * imageScaleFactor.val[0];
		float destH = m_content.image.alloc.h * imageScaleFactor.val[1];
		float destX = (m_content.image.alloc.w - destW) / 2;
		float destY = (m_content.image.alloc.h - destH) / 2;

		if (m_content.image.widgetAni)
		{
			std::vector<AnimatableProperty> propertiesToCancel;
			m_content.image.widgetAni->cancelAnimation(m_content.image.widget, propertiesToCancel);
		}

		if (flagAni)
		{
			if (m_content.image.widgetAni)
			{
				m_content.root->SetClipArea(0, 0, m_content.rootAlloc.w, m_content.rootAlloc.h);


				m_content.image.widgetAni->setDuration(m_scaleAniDuration);
				m_content.image.widgetAni->addKey(AnimatableProperty::Width, destW, false, TweenMode(m_scaleAniMode));
				m_content.image.widgetAni->addKey(AnimatableProperty::Height, destH, false, TweenMode(m_scaleAniMode));
				m_content.image.widgetAni->addKey(AnimatableProperty::PositionX, destX, false, TweenMode(m_scaleAniMode));
				m_content.image.widgetAni->addKey(AnimatableProperty::PositionY, destY, false, TweenMode(m_scaleAniMode));
				m_content.image.widgetAni->apply(m_content.image.widget);
			}
		}
		else
		{
			m_content.image.widget->setX(destX);
			m_content.image.widget->setY(destY);
			m_content.image.widget->setWidth(destW);
			m_content.image.widget->setHeight(destH);
		}
	}

	void CThumbnail::Scale(TValue2f imageScaleFactor, float titleFontScaleFactor, bool flagAni)
	{
		if (0 == (m_visibleStyles & THUMB_STYLE_IMAGE))
		{
			return;
		}

		ASSERT(imageScaleFactor.val[0] >= 0 && imageScaleFactor.val[1] >= 0 && titleFontScaleFactor >= 0);

		Scale(imageScaleFactor, flagAni);

		H_LOG_TRACE(LOGGER, "CThumbnail::Scale-Text[" << this << "] titleFontScaleFactor(" << titleFontScaleFactor << ") m_fontScaleEnabled(" << m_fontScaleEnabled << ")");
		if (!m_fontScaleEnabled)
		{
			return;
		}
		
		if (m_visibleStyles & THUMB_STYLE_INFO)
		{
			std::vector<TextItem*>::iterator it;
			for (it = m_info.texts.begin(); it != m_info.texts.end(); it++)
			{
				if (flagAni)
				{
					(*it)->widget->SetScaleSize((*it)->fontSize * titleFontScaleFactor);
					(*it)->widget->StartScaleText();
				}
				else
				{
					(*it)->widget->SetFontSize((*it)->fontSize * titleFontScaleFactor);
				}
			}
		}
	}

	void CThumbnail::SetDimBackgroundColor(const Color &color)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetDimBackgroundColor[" << this << "] color(r:" << color.r << ",g:" << color.g << ",b:" << color.b << ",a:" << color.a << ")");
		if (m_dimWin && !m_dimUseImage)
		{
			m_dimWin->setColor(color);
		}
	}

	void CThumbnail::SetDimImage(const char* path, int opacity)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetDimImage[" << this << "] path(" << path << ") opacity(" << opacity << ")");
		if (m_dimWin)
		{
			m_dimWin->setColor(Color());
			m_dimWin->setSource(path);
			m_dimWin->setOpacity(opacity);

			m_dimUseImage = true;
		}
		
	}

	void CThumbnail::Dim(bool enable)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::Dim[" << this << "] dim(" << enable << ")");
		if (enable)
		{
#ifdef WIN32
			int num = clutter_actor_get_n_children(t_actor);
			for (int i = 0; i < num; i++)
			{
				ClutterActor *child = clutter_actor_get_child_at_index(t_actor, i);
				printf("child%d %s %f,%f %f * %f\n", i, 
					clutter_actor_get_name(child),
					clutter_actor_get_x(child),
					clutter_actor_get_x(child), 
					clutter_actor_get_width(child), 
					clutter_actor_get_height(child));
			}
#endif			
			float width, height;
			GetSize(width, height);
			m_dimWin->setWidth(width);
			m_dimWin->setHeight(height);
			clutter_actor_set_child_above_sibling(t_actor, 
				m_dimWin->getAnimationActor(), NULL);
			m_dimWin->show();
		}
		else
		{
			m_dimWin->hide();
			m_dimWin->setWidth(0);
			m_dimWin->setHeight(0);
		}
	}

	void CThumbnail::RaiseImage(void)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::RaiseImage[" << this << "]");
		ASSERT(m_styles & THUMB_STYLE_IMAGE);

		if (m_content.root)
		{
			m_content.root->Raise(NULL);
		}
	}

	void CThumbnail::RaiseAttachIcon(int index)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::RaiseAttachIcon[" << this << "] index(" << index << ")");
		ASSERT(index >= 0 && index < (int)m_attachIcons.size());

		if (m_attachIcons[index]->widget)
		{
			clutter_actor_set_child_above_sibling(t_actor,
				m_attachIcons[index]->widget->getAnimationActor(), NULL);
		}
	}

	void CThumbnail::RaiseAttachText(void)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::RaiseAttachText[" << this << "]");
		ASSERT(m_styles & THUMB_STYLE_TEXT);

		if (m_attachText.widget)
		{
			m_attachText.widget->Raise(NULL);
		}
	}

	void CThumbnail::RaiseProgressBar(void)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::RaiseProgressBar[" << this << "]");
		ASSERT(m_styles & THUMB_STYLE_PROGRESSBAR);

		if (m_progressBar.progess)
		{
			m_progressBar.progess->Raise(NULL);
		}
	}

	void CThumbnail::RaiseCheckBox(void)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::RaiseCheckBox[" << this << "]");
		ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		if (m_checkMark.widget)
		{
			clutter_actor_set_child_above_sibling(t_actor,
				m_checkMark.widget->getAnimationActor(), NULL);
		}
	}

	void CThumbnail::RaiseInformation(void)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::RaiseInformation[" << this << "]");
		ASSERT(m_styles & THUMB_STYLE_INFO);

		if (m_info.root)
		{
			clutter_actor_set_child_above_sibling(t_actor,
				m_info.root->getAnimationActor(), NULL);
		}
	}

	void CThumbnail::SetChecked(bool checked)
	{
		H_LOG_TRACE(LOGGER, "CThumbnail::SetChecked[" << this << "] checked(" << checked << ")");
		//ASSERT(m_styles & THUMB_STYLE_CHECKBOX);

		if (checked)
		{
			m_checkMark.isChecked = true;
			if (m_checkMark.widget) { m_checkMark.widget->setSource(m_checkMark.checkedName); }
		}
		else
		{
			m_checkMark.isChecked = false;
			if (m_checkMark.widget) { m_checkMark.widget->setSource(m_checkMark.uncheckName); }
		}
	}

	bool CThumbnail::IsChecked(void)
	{
		return m_checkMark.isChecked;
	}

	void CThumbnail::Enable(bool enable)
	{
		m_enabled = enable;
	}

	bool CThumbnail::IsEnabled(void)
	{
		return m_enabled;
	}

	void CThumbnail::enableFontScale(bool enable)
	{
		m_fontScaleEnabled = enable;
	}


	//Protected
	void CThumbnail::t_UpdateOrientation(EOrientation orientation)
	{
		if (m_styles & THUMB_STYLE_IMAGE)
		{
			m_content.root->GetSize(m_content.rootAlloc.w, m_content.rootAlloc.h);
			TValue2f pos = m_GetLogicalPos(m_content.rootAlloc);
			m_content.root->SetPosition(pos.val[0], pos.val[1]);
		}
		if (m_styles & THUMB_INFO_STYLE_ICON)
		{
			int attachIconNum = m_attachIcons.size();
			for (int i = 0; i < attachIconNum; i++)
			{
				m_attachIcons[i]->alloc.w = m_attachIcons[i]->widget->getWidth();
				m_attachIcons[i]->alloc.h = m_attachIcons[i]->widget->getHeight();
				TValue2f pos = m_GetLogicalPos(m_attachIcons[i]->alloc);
				m_attachIcons[i]->widget->setX(pos.val[0]);
				m_attachIcons[i]->widget->setY(pos.val[1]);
			}
		}
		if (m_styles & THUMB_STYLE_TEXT)
		{
			m_attachText.widget->GetSize(m_attachText.alloc.w, m_attachText.alloc.h);
			TValue2f pos = m_GetLogicalPos(m_attachText.alloc);
			m_attachText.widget->SetPosition(pos.val[0], pos.val[1]);
		}
		if (m_styles & THUMB_STYLE_CHECKBOX)
		{
			m_checkMark.alloc.w = m_checkMark.widget->getWidth();
			m_checkMark.alloc.h = m_checkMark.widget->getHeight();
			TValue2f pos = m_GetLogicalPos(m_checkMark.alloc);
			m_checkMark.widget->setX(pos.val[0]);
			m_checkMark.widget->setY(pos.val[1]);
		}
		if (m_styles & THUMB_STYLE_PROGRESSBAR)
		{
			TValue2f pos = m_GetLogicalPos(m_progressBar.alloc);
			m_progressBar.progess->SetPosition(pos.val[0], pos.val[1]);
		}
		if (m_styles & THUMB_STYLE_INFO)
		{
			m_info.alloc.w = m_info.root->getWidth();
			m_info.alloc.h = m_info.root->getHeight();
			TValue2f pos = m_GetLogicalPos(m_info.alloc);
			m_info.root->setX(pos.val[0]);
			m_info.root->setY(pos.val[1]);
			int i;
			int infoIconNum = m_info.icons.size();
			for (i = 0; i < infoIconNum; i++)
			{
				m_info.icons[i]->alloc.w = m_info.icons[i]->widget->getWidth();
				m_info.icons[i]->alloc.h = m_info.icons[i]->widget->getHeight();
				TValue2f pos = m_GetLogicalPos(m_info.icons[i]->alloc);
				m_info.icons[i]->widget->setX(pos.val[0]);
				m_info.icons[i]->widget->setY(pos.val[1]);
			}
			int infoTextNum = m_info.texts.size();
			for (i = 0; i < infoTextNum; i++)
			{
				m_info.texts[i]->widget->GetSize(m_info.texts[i]->alloc.w, m_info.texts[i]->alloc.h);
				TValue2f pos = m_GetLogicalPos(m_info.texts[i]->alloc);
				m_info.texts[i]->widget->SetPosition(pos.val[0], pos.val[1]);
				m_info.texts[i]->widget->SetOrientation(orientation);
			}
			if (m_infoStyles & THUMB_INFO_STYLE_RATING)
			{
				TValue2f pos = m_GetLogicalPos(m_info.rating->alloc);
				m_info.rating->widget->SetPosition(pos.val[0], pos.val[1]);
				m_info.rating->widget->SetOrientation(orientation);
			}
		}

		CActor::t_UpdateOrientation(orientation);
	}

	bool CThumbnail::OnValueChanged(class IProgress* slider)
	{
		if (m_visibleStyles & THUMB_STYLE_PROGRESSBAR)
		{
			CThumbnailListenerSet::TThumbListenerData data;
			data.type = EVENT_PROGRESS_VALUE_CHANGED;
			data.param[0] = m_progressBar.progess->Value();
			m_listenerSet->Process(&data);
		}
		
		return true;
	}

	// private funtions
	ImageWidgetReadyCallback CThumbnail::m_RegisterReadyCallback(void)
	{
		ImageWidgetReadyCallback readyCallback = std::bind(m_ImageLoadReadyCallback, this, std::placeholders::_1);
		return readyCallback;
	}

	void CThumbnail::m_ImageLoadReadyCallback(CThumbnail* pThis, bool success)
	{
		pThis->m_content.image.isReady = success;
		if (success)
		{
			pThis->m_ResetAttachTextColor(pThis->m_content.image.widget);
			pThis->m_ResetInfoTextColor(pThis->m_content.image.widget);
		}

		CThumbnailListenerSet::TThumbListenerData data;
		data.type = EVENT_IMAGE_READY;
		data.param[0] = 0;
		data.param[1] = success;
		pThis->m_listenerSet->Process(&data);

		if (pThis->m_defalut)
		{
			delete pThis->m_defalut;
			pThis->m_defalut = NULL;

			pThis->EnableThumbnailStyles(true, pThis->m_visibleStyles, false);
		}
	}

	AnimationCallback CThumbnail::m_RegisterAnimationCallback(void)
	{
		AnimationCallback aniCallback = std::bind(m_AnimationCallback, this);
		return aniCallback;
	}

	void CThumbnail::m_AnimationCallback(CThumbnail* pThis)
	{
		if (pThis->m_content.root)
		{
			pThis->m_content.root->SetClipArea(0, 0, pThis->m_content.rootAlloc.w, pThis->m_content.rootAlloc.h);
		}
	}

	ButtonPressCallback CThumbnail::m_RegisterMouseEventCallback(MouseEventCallback cb)
	{
		ButtonPressCallback mouseCallback = std::bind(cb, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3, std::placeholders::_4);
		return mouseCallback;
	}

	bool CThumbnail::m_mousePressedCallback(CThumbnail* pThis, Widget* widget, Widget* origin, volt::util::MOUSE_BUTTON button, Vector2 coordinates)
	{
		if (pThis->m_checkMark.widget == widget)
		{
			pThis->SetChecked(!pThis->m_checkMark.isChecked);
			if (pThis->m_listenerSet)
			{
				CThumbnailListenerSet::TThumbListenerData data;
				data.type = EVENT_CHECK_STATE_CHANGED;
				data.param[0] = pThis->m_checkMark.isChecked;
				pThis->m_listenerSet->Process(&data);
			}
		}
		else
		{
			std::vector<AttachIcon*>::iterator aiIt;
			for (aiIt = pThis->m_attachIcons.begin(); aiIt != pThis->m_attachIcons.end(); aiIt++)
			{
				if ((*aiIt)->widget == widget)
				{
					(*aiIt)->widget->setSource((*aiIt)->pressedNmae);
					break;
				}
			}
		}

		return false;
	}

	bool CThumbnail::m_mouseReleaseCallback(CThumbnail* pThis, Widget* widget, Widget* origin, volt::util::MOUSE_BUTTON button, Vector2 coordinates)
	{
		std::vector<AttachIcon*>::iterator aiIt;
		for (aiIt = pThis->m_attachIcons.begin(); aiIt != pThis->m_attachIcons.end(); aiIt++)
		{
			if ((*aiIt)->widget == widget)
			{
				(*aiIt)->widget->setSource((*aiIt)->unpressName);

				CThumbnailListenerSet::TThumbListenerData data;
				data.type = EVENT_ICON_CLICKED; 
				data.param[0] = aiIt - pThis->m_attachIcons.begin();
				pThis->m_listenerSet->Process(&data);
				break;
			}
		}
		return false;
	}

	bool CThumbnail::m_mouseClickedCallback(CThumbnail* pThis, Widget* widget, Widget* origin, volt::util::MOUSE_BUTTON button, Vector2 coordinates)
	{
		return false;
	}

	void CThumbnail::m_ResetAttachTextColor(ImageWidget* w)
	{
		if (w)
		{
			Color color;
			if (m_attachText.colorPickingRange.isEmpty())
			{
				w->getColorPicking(100, &color);
			}
			else
			{
				//float x1, x2, y1, y2;
				//w->getImageCroppedCoord(&x1, &y1, &x2, &y2);
				//float cpx1, cpx2, cpy1, cpy2;
				//cpx1 = x1 + (x2 - x1)*m_attachText.colorPickingRange.l / 100;
				//cpx2 = x1 + (x2 - x1)*m_attachText.colorPickingRange.r / 100;
				//cpy1 = y1 + (y2 - y1)*m_attachText.colorPickingRange.t / 100;
				//cpy2 = y1 + (y2 - y1)*m_attachText.colorPickingRange.b / 100;
				//w->getColorPicking(0, cpx1, cpx2, cpy1, cpy2, &color);
			}
			ClutterColor bg = CLUTTER_COLOR_INIT(color.r, color.g, color.b, 255);
			m_attachText.bgColorPicking = bg;
			m_attachText.colorPickingReady = true;

			uint to_r = 0, to_g = 0, to_b = 0;
			m_utility->ExtractForegroundColor(color.r, color.g, color.b, &to_r, &to_g, &to_b);
			ClutterColor fg = CLUTTER_COLOR_INIT((guint8)to_r, (guint8)to_g, (guint8)to_b, 255);
			m_attachText.fgColorExtracted = fg;
		}
		
		if (m_attachText.widget && m_attachText.colorPickingReady)
		{
			if (m_attachText.useReferenceColor)
			{
				m_attachText.widget->SetBackgroundColor(m_attachText.bgColorPicking);
				if (m_attachText.textColor.isTransparent())
				{
					m_attachText.widget->SetTextColor(m_attachText.fgColorExtracted);
				}
			}
		}
	}

	void CThumbnail::m_ResetInfoTextColor(ImageWidget* w)
	{
		if (w)
		{
			Color color;
			if (m_info.colorPickingRange.isEmpty())
			{
				w->getColorPicking(10, &color);
			}
			else
			{
				//float x1, x2, y1, y2;
				//w->getImageCroppedCoord(&x1, &y1, &x2, &y2);
				//float cpx1, cpx2, cpy1, cpy2;
				//cpx1 = x1 + (x2 - x1)*m_info.colorPickingRange.l / 100;
				//cpx2 = x1 + (x2 - x1)*m_info.colorPickingRange.r / 100;
				//cpy1 = y1 + (y2 - y1)*m_info.colorPickingRange.t / 100;
				//cpy2 = y1 + (y2 - y1)*m_info.colorPickingRange.b / 100;
				//w->getColorPicking(0, cpx1, cpx2, cpy1, cpy2, &color);
			}
			ClutterColor bg = CLUTTER_COLOR_INIT(color.r, color.g, color.b, 255);
			m_info.bgColorPicking = bg;
			m_info.colorPickingReady = true;

			uint to_r = 0, to_g = 0, to_b = 0;
			m_utility->ExtractForegroundColor(color.r, color.g, color.b, &to_r, &to_g, &to_b);
			ClutterColor fg = CLUTTER_COLOR_INIT((guint8)to_r, (guint8)to_g, (guint8)to_b, 255);
			m_info.fgColorExtracted = fg;
		}
		
		if (m_info.root  && m_info.colorPickingReady)
		{
			if (m_info.useReferenceColor)
			{
				m_info.root->setColor(m_info.bgColorPicking);
			}
			
			int textNum = m_info.texts.size();
			for (int i = 0; i < textNum; i++)
			{
				if (m_info.texts[i]->textColor.isTransparent())
				{
					m_info.texts[i]->widget->SetTextColor(m_info.fgColorExtracted);
				}
			}
		}
	}

	bool CThumbnail::m_CreateContent(const TImageInfo &info)
	{
		m_content.root = IActor::CreateInstance((IActor*)this, info.alloc.w, info.alloc.h);
		m_SetId(dynamic_cast<Widget*>(m_content.root), "image-root");

		TValue2f pos = m_GetLogicalPos(info.alloc);
		m_content.root->SetPosition(pos.val[0], pos.val[1]);
		m_content.rootAlloc = info.alloc;

		m_content.root->SetClipArea(0, 0, info.alloc.w, info.alloc.h);
		m_content.root->Hide();

		m_content.image.widget = new ImageWidget(0, 0, info.alloc.w, info.alloc.h, dynamic_cast<Widget*>(m_content.root), m_RegisterReadyCallback());
		m_SetId(m_content.image.widget, "image");
		m_content.image.widget->setAsyncLoading(info.async);

		if (!info.src.empty())
		{
			m_content.image.widget->setSource(info.src);
		}
		m_content.image.widget->setFillMode(info.fillMode);
		m_content.image.alloc.x = 0;
		m_content.image.alloc.y = 0;
		m_content.image.alloc.w = info.alloc.w;
		m_content.image.alloc.h = info.alloc.h;

		m_content.image.widgetAni = new Animation(m_scaleAniDuration, false);		

		m_styles |= THUMB_STYLE_IMAGE;

		return true;
	}

	void CThumbnail::m_DestroyContent(void)
	{
		if (m_content.image.widgetAni)
		{
			delete m_content.image.widgetAni;
			m_content.image.widgetAni = NULL;
		}
		if (m_content.image.widget)
		{
			delete m_content.image.widget;
			m_content.image.widget = NULL;
		}
		if (m_content.root)
		{
			m_content.root->Release();
			m_content.root = NULL;
		}
		m_styles &= ~THUMB_STYLE_IMAGE;
	}

	bool CThumbnail::m_CreateAttachIcon(const TIconInfo &iconInfo)
	{
		AttachIcon *icon = new AttachIcon;
		icon->widget = new ImageWidget(iconInfo.alloc.x, iconInfo.alloc.y, iconInfo.alloc.w, iconInfo.alloc.h, dynamic_cast<Widget*>(this));
		m_SetId(icon->widget, "attach-icon", m_attachIcons.size() + 1);
		icon->widget->setAsyncLoading(iconInfo.async);
		icon->widget->hide();

		icon->clickable = iconInfo.clickable;
		if (iconInfo.clickable)
		{
			icon->mousePressedHandle = icon->widget->registerMouseEvent(Widget::MOUSE_DOWN, m_RegisterMouseEventCallback(m_mousePressedCallback));
			icon->mouseReleaseHandle = icon->widget->registerMouseEvent(Widget::MOUSE_UP, m_RegisterMouseEventCallback(m_mouseReleaseCallback));
			icon->mouseClickedHandle = icon->widget->registerMouseEvent(Widget::MOUSE_CLICK, m_RegisterMouseEventCallback(m_mouseClickedCallback));
		}

		icon->unpressName = iconInfo.unpressName;
		icon->pressedNmae = iconInfo.pressedName;
		
		if (!iconInfo.unpressName.empty())
		{
			icon->widget->setSource(iconInfo.unpressName);
		}
		icon->widget->setOpacity(iconInfo.opacity);
		icon->alloc = iconInfo.alloc;
		m_attachIcons.push_back(icon);

		m_styles |= THUMB_STYLE_ICON;

		return true;
	}

	void CThumbnail::m_DestroyAttachIcon(int index)
	{
		std::vector<AttachIcon*>::iterator it = m_attachIcons.begin() + index;
		AttachIcon* icon = *it;
		delete icon->widget;
		delete icon;
		m_attachIcons.erase(it);

		if (m_attachIcons.size() == 0)
		{
			m_styles &= ~THUMB_STYLE_ICON;
		}
	}

	bool CThumbnail::m_CreateAttachText(const TAttachText &atInfo)
	{
		m_attachText.widget = IText::CreateInstance((Widget*)this, atInfo.textInfo.alloc.w, atInfo.textInfo.alloc.h);
		m_SetId(dynamic_cast<Widget*>(m_attachText.widget), "attach-text");
		m_attachText.widget->SetPosition(atInfo.textInfo.alloc.x, atInfo.textInfo.alloc.y);
		m_attachText.widget->Hide();

		if (!atInfo.textInfo.fontName.empty())
		{
			m_attachText.widget->SetFont(atInfo.textInfo.fontName.c_str());
		}
		if (atInfo.textInfo.bold)
		{
			m_attachText.widget->SetCharFormat(IText::STYLE_BOLD);
		}
		m_attachText.widget->EnableMultiLine(!atInfo.textInfo.singleLineMode);
		m_attachText.widget->EnableEllipsize(atInfo.textInfo.ellipsize);
		m_attachText.widget->SetTextAlignment(atInfo.textInfo.hAlign, atInfo.textInfo.vAlign);
		if (!atInfo.textInfo.text.empty())
		{
			m_attachText.widget->SetText(atInfo.textInfo.text.c_str());
		}
		m_attachText.useReferenceColor = atInfo.useRefereceColor;
		if (!atInfo.useRefereceColor)
		{
			m_attachText.widget->SetBackgroundColor(*atInfo.backgroundColor.toClutterColor());
		}
		else if (m_attachText.colorPickingReady)
		{
			m_attachText.widget->SetBackgroundColor(m_attachText.bgColorPicking);
		}
		m_attachText.textColor = atInfo.textInfo.textColor;
		if (!atInfo.textInfo.textColor.isTransparent())
		{
			m_attachText.widget->SetTextColor(*atInfo.textInfo.textColor.toClutterColor());
		}
		else if (m_attachText.colorPickingReady)
		{
			m_attachText.widget->SetTextColor(m_attachText.fgColorExtracted);
		}
		
		m_attachText.widget->SetAlpha(atInfo.textInfo.opacity);
		m_attachText.widget->SetScrollAttribute(5000, 0, -1, CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_OUTSIDE, CLUTTER_TIMELINE_BACKWARD, 0);
		m_attachText.alloc = atInfo.textInfo.alloc;

		m_styles |= THUMB_STYLE_TEXT;

		return true;
	}

	void CThumbnail::m_DestroyAttachText(void)
	{
		if (m_attachText.widget != NULL)
		{
			m_attachText.widget->Release();
			m_attachText.widget = NULL;
		}
		
		m_styles &= ~THUMB_STYLE_TEXT;
	}

	bool CThumbnail::m_CreateProgressBar(const TProgressBarInfo &pbInfo)
	{
		m_progressBar.progess = IProgress::CreateInstance((IActor*)this, pbInfo.alloc.w, pbInfo.alloc.h, pbInfo.direction);
		m_SetId(dynamic_cast<Widget*>(m_progressBar.progess), "progress-bar");
		m_progressBar.progess->SetPosition(pbInfo.alloc.x, pbInfo.alloc.y);
		m_progressBar.progess->SetBackgroundColor(*pbInfo.backgroundColor.toClutterColor());
		m_progressBar.progess->SetProgressColor(*pbInfo.progressColor.toClutterColor());
		m_progressBar.progess->SetNormalThumbImage(pbInfo.normalThumb);
		m_progressBar.progess->SetFocusThumbImage(pbInfo.focusThumb);
		m_progressBar.progess->SetThumbSize(pbInfo.thumbSize.val[0], pbInfo.thumbSize.val[1]);
		m_progressBar.progess->SetActive(pbInfo.slidable);
		
		m_progressBar.progess->Hide();

		m_progressBar.alloc = pbInfo.alloc;

		m_progressBar.slidable = pbInfo.slidable;
		m_styles |= THUMB_STYLE_PROGRESSBAR;

		return true;
	}

	void CThumbnail::m_DestroyProgressBar(void)
	{
		if (m_progressBar.progess)
		{
			m_progressBar.progess->Release();
			m_progressBar.progess = NULL;
		}

		m_styles &= ~THUMB_STYLE_PROGRESSBAR;
	}

	bool CThumbnail::m_CreateCheckBox(const TCheckBoxInfo &cbInfo)
	{
		m_checkMark.widget = new ImageWidget(cbInfo.alloc.x, cbInfo.alloc.y, cbInfo.alloc.w, cbInfo.alloc.h, dynamic_cast<Widget*>(this));
		m_SetId(m_checkMark.widget, "check-box");
		m_checkMark.widget->setAsyncLoading(false);
		m_checkMark.widget->registerMouseEvent(Widget::MOUSE_DOWN, m_RegisterMouseEventCallback(m_mousePressedCallback));
		m_checkMark.widget->hide();

		m_checkMark.uncheckName = cbInfo.uncheckName;
		m_checkMark.checkedName = cbInfo.checkedName;
		if (!cbInfo.uncheckName.empty())
		{
			m_checkMark.widget->setSource(cbInfo.uncheckName);
		}
		m_checkMark.alloc = cbInfo.alloc;

		m_styles |= THUMB_STYLE_CHECKBOX;

		return true;
	}

	void CThumbnail::m_DestroyCheckBox(void)
	{
		if (NULL != m_checkMark.widget)
		{
			delete m_checkMark.widget;
			m_checkMark.widget = NULL;
		}

		m_styles &= ~THUMB_STYLE_CHECKBOX;
	}

	bool CThumbnail::m_CreateInfo(const TInformation &info, EInformationStyles infoStyles)
	{
		if (NULL == m_info.root)
		{
			m_info.root = new Widget(info.alloc.x, info.alloc.y, info.alloc.w, info.alloc.h, this);
			m_SetId(m_info.root, "info-root");
			m_info.root->setCropOverflow(true);
			m_info.root->hide();

			m_info.colorPickingRange = info.colorPickingRange;
			m_info.useReferenceColor = info.useRefereceColor;
			if (!m_info.useReferenceColor)
			{
				m_info.root->setColor(info.backgroundColor);
			}
			else if (!info.colorPickingRange.isEmpty() && m_content.image.isReady)
			{
				m_ResetInfoTextColor(m_content.image.widget);
			}
			else if (m_info.colorPickingReady)
			{
				m_info.root->setColor(m_info.bgColorPicking);
			}

			m_info.rootAni = new Animation(m_resizeAniDuration, false);
		}
		m_info.alloc = info.alloc;

		int textNum = info.textInfos.size();
		for (int i = 0; i < textNum; i++)
		{
			m_CreateInfoText(info.textInfos[i]);
		}

		int iconNum = info.iconInfos.size();
		for (int i = 0; i < iconNum; i++)
		{
			m_CreateInfoIcon(info.iconInfos[i]);
		}

		if (infoStyles & THUMB_INFO_STYLE_RATING)
		{
			m_CreateInfoRating(info.ratingInfo);
		}

		m_styles |= THUMB_STYLE_INFO;
		return true;
	}

	void CThumbnail::m_DestroyInfo(void)
	{
		if (m_info.textAni != NULL)
		{
			m_info.textAni->Release();
			m_info.textAni = NULL;
		}

		while (m_info.texts.size() != 0)
		{
			m_DestroyInfoText(0);
		}
		while (m_info.icons.size() != 0)
		{
			m_DestroyInfoIcon(0);
		}
		m_DestroyInfoRating();
		
		
		if (m_info.rootAni != NULL)
		{
			delete m_info.rootAni;
			m_info.rootAni = NULL;
		}

		if (m_info.root != NULL)
		{
			delete m_info.root;
			m_info.root = NULL;
		}

		m_styles &= ~THUMB_STYLE_INFO;
	}

	bool CThumbnail::m_CreateInfoText(const TTextInfo &textInfo)
	{
		TextItem *text = new TextItem;
		text->widget = IText::CreateInstance(m_info.root, textInfo.alloc.w, textInfo.alloc.h);
		m_SetId(dynamic_cast<Widget*>(text->widget), "info-text", m_info.texts.size() + 1);
		text->widget->SetPosition(textInfo.alloc.x, textInfo.alloc.y);

		if (!textInfo.fontName.empty())
		{
			text->widget->SetFont(textInfo.fontName.c_str());
		}
		if (textInfo.bold)
		{
			text->widget->SetCharFormat(IText::STYLE_BOLD);
		}
		text->widget->EnableMultiLine(!textInfo.singleLineMode);
		text->widget->EnableEllipsize(textInfo.ellipsize);
		text->widget->SetTextAlignment(textInfo.hAlign, textInfo.vAlign);
		
		if (!textInfo.text.empty())
		{
			text->widget->SetText(textInfo.text.c_str());
			text->minHeight = text->widget->PreferredHeight(textInfo.alloc.w);
		}
		if (NULL == m_info.textAni)
		{
			m_info.textAni = new CMultiObjectTransition;
			m_info.textAni->Initialize();
			m_info.textAni->SetDuration(m_scaleAniDuration);
			m_info.textAni->SetMode(m_scaleAniMode);
		}
		m_info.textAni->AddAnimatableObject(text->widget, IActor::ACTOR_ANI_POSITION);  // for title2 pos ani
		text->fontSize = text->widget->FontSize();
		text->width = textInfo.alloc.w;
		text->widget->SetScaleAttribute(text->fontSize, m_scaleAniDuration, 0, m_scaleAniMode);
		text->widget->SetScrollAttribute(5000, 0, -1, CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_OUTSIDE, CLUTTER_TIMELINE_BACKWARD, 0);
		text->textColor = textInfo.textColor;
		if (!textInfo.textColor.isTransparent())
		{
			text->widget->SetTextColor(*textInfo.textColor.toClutterColor());
		}
		else if (m_info.colorPickingReady)
		{
			text->widget->SetTextColor(m_info.fgColorExtracted);
		}
		text->widget->SetAlpha(textInfo.opacity);
		text->alloc = textInfo.alloc;

		m_info.texts.push_back(text);

		m_infoStyles |= THUMB_INFO_STYLE_TEXT;

		return true;
	}

	void CThumbnail::m_DestroyInfoText(int index)
	{
		std::vector<TextItem*>::iterator it = m_info.texts.begin() + index;
		TextItem* text = *it;
		delete text->widget;
		delete text;
		m_info.texts.erase(it);

		if (m_info.texts.size() == 0)
		{
			m_infoStyles &= ~THUMB_INFO_STYLE_TEXT;
		}
		
	}

	bool CThumbnail::m_CreateInfoIcon(const TIconInfo &iconInfo)
	{
		IconItem *icon = new IconItem;
		icon->widget = new ImageWidget(iconInfo.alloc.x, iconInfo.alloc.y, iconInfo.alloc.w, iconInfo.alloc.h, dynamic_cast<Widget*>(m_info.root));
		m_SetId(dynamic_cast<Widget*>(icon->widget), "info-icon", m_info.icons.size() + 1);
		icon->widget->setAsyncLoading(iconInfo.async);
		if (!iconInfo.unpressName.empty())
		{
			icon->widget->setSource(iconInfo.unpressName);
		}
		icon->widget->setOpacity(iconInfo.opacity);
		icon->alloc = iconInfo.alloc;
		m_info.icons.push_back(icon);

		m_infoStyles |= THUMB_INFO_STYLE_ICON;

		return true;
	}

	void CThumbnail::m_DestroyInfoIcon(int index)
	{
		std::vector<IconItem*>::iterator it = m_info.icons.begin() + index;
		IconItem* icon = *it;
		delete icon->widget;
		delete icon;
		m_info.icons.erase(it);

		if (m_info.icons.size() == 0)
		{
			m_infoStyles &= ~THUMB_INFO_STYLE_ICON;
		}
	}

	bool CThumbnail::m_CreateInfoRating(const TRatingInfo &ratingInfo)
	{
		m_info.rating = new RatingItem;
		m_info.rating->widget = IMultiImage::CreateInstance(m_info.root, ratingInfo.alloc.w, ratingInfo.alloc.h);
		m_SetId(dynamic_cast<Widget*>(m_info.rating->widget), "info-rating");
		m_info.rating->widget->SetPosition(ratingInfo.alloc.x, ratingInfo.alloc.y);

		int i;
		for (i = 0; i < 5; i++)
		{
			TRect rect((ratingInfo.iconSize.val[0] + ratingInfo.gap)*i, 0, ratingInfo.iconSize.val[0], ratingInfo.iconSize.val[1]);
			if (ratingInfo.value > (i + 1) * 2)
			{
				m_info.rating->widget->AddIcon(ratingInfo.onName.c_str(), rect, ratingInfo.opacity);
			}
			else if (ratingInfo.value > i * 2)
			{
				m_info.rating->widget->AddIcon(ratingInfo.halfName.c_str(), rect, ratingInfo.opacity);
			}
			else
			{
				m_info.rating->widget->AddIcon(ratingInfo.offName.c_str(), rect, ratingInfo.opacity);
			}
		}
		m_info.rating->onName = ratingInfo.onName;
		m_info.rating->halfName = ratingInfo.halfName;
		m_info.rating->offName = ratingInfo.offName;
		m_info.rating->value = ratingInfo.value;
		m_info.rating->alloc = ratingInfo.alloc;

		m_infoStyles |= THUMB_INFO_STYLE_RATING;

		return true;
	}

	void CThumbnail::m_DestroyInfoRating(void)
	{
		if (m_info.rating != NULL)
		{
			if (m_info.rating->widget != NULL)
			{
				m_info.rating->widget->Release();
				m_info.rating->widget = NULL;
			}
			
			delete m_info.rating;
			m_info.rating = NULL;
		}
		
		m_infoStyles &= ~THUMB_INFO_STYLE_RATING;
	}

	void CThumbnail::m_UpdateInfoRating(int value)
	{
		if (value == m_info.rating->value)
		{
			return;
		}
		
		if (m_info.rating->widget != NULL)
		{
			if (value > m_info.rating->value)
			{
				int startUpdate = m_info.rating->value / 2;
				int endUpate = (value - 1) / 2;
				for (int i = startUpdate; i <= endUpate; i++)
				{
					if (i == endUpate && (value % 2 != 0))
					{
						m_info.rating->widget->SetIcon(i, m_info.rating->halfName.c_str());
					}
					else
					{
						m_info.rating->widget->SetIcon(i, m_info.rating->onName.c_str());
					}
				}
			}
			else
			{
				int endUpdate = (m_info.rating->value - 1) / 2;
				int startUpdate = value / 2;
				for (int i = endUpdate; i >= startUpdate; i--)
				{
					if (i == startUpdate && (value % 2 != 0))
					{
						m_info.rating->widget->SetIcon(i, m_info.rating->halfName.c_str());
					}
					else
					{
						m_info.rating->widget->SetIcon(i, m_info.rating->offName.c_str());
					}
				}
			}
		}
		m_info.rating->value = value;
	}

	void CThumbnail::m_ModifyText(IText* widget, const TTextInfo &textInfo)
	{
		widget->SetPosition(textInfo.alloc.x, textInfo.alloc.y);
		widget->Resize(textInfo.alloc.w, textInfo.alloc.h);

		if (!textInfo.fontName.empty())
		{
			widget->SetFont(textInfo.fontName.c_str());
		}
		if (textInfo.bold)
		{
			widget->SetCharFormat(IText::STYLE_BOLD);
		}
		else
		{
			widget->SetCharFormat(IText::STYLE_NONE);
		}
		widget->EnableMultiLine(!textInfo.singleLineMode);
		widget->EnableEllipsize(textInfo.ellipsize);
		widget->SetTextAlignment(textInfo.hAlign, textInfo.vAlign);		

		if (!textInfo.text.empty())
		{
			widget->SetText(textInfo.text.c_str());
		}
		widget->SetAlpha(textInfo.opacity);
	}

	void CThumbnail::m_ModifyIcon(ImageWidget* widget, const TIconInfo &iconInfo)
	{
		widget->setX(iconInfo.alloc.x);
		widget->setY(iconInfo.alloc.y);
		widget->setWidth(iconInfo.alloc.w);
		widget->setHeight(iconInfo.alloc.h);

		widget->setAsyncLoading(iconInfo.async);
		widget->setSource(iconInfo.unpressName);

		widget->setOpacity(iconInfo.opacity);
	}

	TValue2f CThumbnail::m_GetLogicalPos(const TRect& rect)
	{
		TValue2f point;

		if (ORIENTATION_LEFT_TO_RIGHT == Orientation(true))
		{
			point.Set(rect.x, rect.y);
		}
		else
		{
			point.Set(getWidth() - rect.x - rect.w, rect.y);
		}

		return point;
	}

	void CThumbnail::SetTTSText(const std::string text)
	{
		m_ttsText = text;
	}		
	
	void CThumbnail::PlayTTSText()
	{
	#ifndef WIN32
		TTSEngine::Instance().SetText(m_ttsText);
		TTSEngine::Instance().StopAndPlay();
	#endif
	}

	void CThumbnail::ScrollImage(void)
	{
		if (m_scrollPlayer != NULL)
		{
			m_scrollPlayer->PlayScroll();
		}	
	}

	bool CThumbnail::m_CreateScrollPlayer(const TScrollPlayerInfo &scrollPlayerInfo)
	{
		m_scrollPlayerHandler = new CScrollPlayerHandler(this);
		CScrollPlayer::T_ScrollPlayerAttr attr(scrollPlayerInfo.alloc.w, scrollPlayerInfo.alloc.h);
		attr.scrollAniDuration = scrollPlayerInfo.aniDuration;
		attr.scrollAniMode = scrollPlayerInfo.aniMode;
		attr.itemNum = scrollPlayerInfo.itemNumber;
		m_scrollPlayer = new CScrollPlayer;
		m_scrollPlayer->Initialize(this, &attr);
		m_SetId(dynamic_cast<Widget*>(m_scrollPlayer), "scroll-player");

		m_scrollPlayer->SetPosition(scrollPlayerInfo.alloc.x, scrollPlayerInfo.alloc.y);

		m_scrollPlayer->SetListener(m_scrollPlayerHandler);
		m_scrollPlayerAsyncLoad = scrollPlayerInfo.async;
		m_scrollDataSource = new CSingleLineDataSource;
		for (size_t i = 0; i < scrollPlayerInfo.srcList.size(); i++)
		{
			CScrollData* data = new CScrollData;
			data->index = i;
			data->imageSrc = scrollPlayerInfo.srcList.at(i);
			data->async = scrollPlayerInfo.async;
			m_scrollDataSource->AddData(data);
		}
		
		m_scrollPlayer->SetDataSource(m_scrollDataSource);
	
		m_scrollPlayer->SetRendererProvider(m_scrollPlayerHandler);
		m_scrollPlayer->LoadData();
		m_scrollPlayer->Hide();

		m_styles |= THUMB_STYLE_SCROLLPLAYER;

		return true;
	}

	void CThumbnail::m_DestroyScrollPlayer(void)
	{
		if (m_scrollPlayerHandler != NULL)
		{
			delete m_scrollPlayerHandler;
			m_scrollPlayerHandler = NULL;
		}
		if (m_scrollDataSource != NULL)
		{			
			delete m_scrollDataSource;
			m_scrollDataSource = NULL;
		}
		if (m_scrollPlayer != NULL)
		{
			delete m_scrollPlayer;
			m_scrollPlayer = NULL;
		}

		m_styles &= ~THUMB_STYLE_SCROLLPLAYER;
	}

	void CThumbnail::SetScrollPlayerImages(std::vector<std::string> srcList)
	{
		m_scrollDataSource->DeleteAll();

		for (size_t i = 0; i < srcList.size(); i++)
		{
			CScrollData* data = new CScrollData;
			data->index = i;
			data->imageSrc = srcList.at(i);
			data->async = m_scrollPlayerAsyncLoad;
			m_scrollDataSource->AddData(data);		
		}
		
		m_scrollPlayer->LoadData();
	}

#ifndef WIN32
	bool CThumbnail::m_CreateVideoActor(const TVideoActorInfo &videoActorInfo)
	{
		m_videoActor = new CVideoActor;
		m_videoActor->Initialize((Widget*)this, videoActorInfo.alloc.w, videoActorInfo.alloc.h, videoActorInfo.type);
		m_SetId(dynamic_cast<Widget*>(m_videoActor), "video-actor");
		m_videoActor->SetPosition(videoActorInfo.alloc.x, videoActorInfo.alloc.y);
		if(videoActorInfo.uri.empty() == false && (videoActorInfo.type == CLUTTER_VC_TYPE_MM_SYNC || videoActorInfo.type ==  CLUTTER_VC_TYPE_MM_ASYNC))
		{	
			m_videoActor->SetUri(videoActorInfo.uri);
		}

		m_styles |= THUMB_STYLE_VIDEO;

		return true;
	}

	void CThumbnail::m_DestroyVideoActor(void)
	{
		if (m_videoActor != NULL)
		{
			m_videoActor->Release();
			m_videoActor = NULL;
		}
	}

	CVideoActor* CThumbnail::VideoActor(void)
	{
		return m_videoActor;
	}
#endif


	// CScrollPlayerHandler
	IRenderer* CScrollPlayerHandler::GetRenderer(IData *data, IActor* parent)
	{
		CScrollData *scrollData = dynamic_cast<CScrollData*>(data);
		CScrollPlayerRenderer * renderer = new CScrollPlayerRenderer(parent);
		if(scrollData != NULL && renderer != NULL)
		{
			float w, h;
			parent->GetSize(w, h);
			renderer->m_image = new ImageWidget(0, 0, w, h, dynamic_cast<Widget*>(parent), m_RegisterReadyCallback(renderer));
			renderer->m_image->setAsyncLoading(scrollData->async);
		}
		return renderer;
	}

	ImageWidgetReadyCallback CScrollPlayerHandler::m_RegisterReadyCallback(CScrollPlayerRenderer *renderer)
	{
		ImageWidgetReadyCallback readyCallback = std::bind(m_ImageLoadReadyCallback, this, renderer, std::placeholders::_1);
		return readyCallback;
	}

	void CScrollPlayerHandler::m_ImageLoadReadyCallback(CScrollPlayerHandler* pThis, CScrollPlayerRenderer *renderer, bool success)
	{
		if (success && (renderer->m_dataIndex == 0))
		{
			pThis->m_owner->m_ResetAttachTextColor(renderer->m_image);
			pThis->m_owner->m_ResetInfoTextColor(renderer->m_image);
		}

		CThumbnailListenerSet::TThumbListenerData data;
		data.type = CThumbnail::EVENT_IMAGE_READY;
		data.param[0] = renderer->m_dataIndex;
		data.param[1] = success;
		pThis->m_owner->m_listenerSet->Process(&data);
	}

	// CScrollPlayerRenderer
	void CScrollPlayerRenderer::Draw(IData *data, IActor* parent, E_DRAW_TYPE drawType)
	{
		CScrollData *scrollData = dynamic_cast<CScrollData*>(data);
		if(scrollData != NULL)
		{
			m_dataIndex = scrollData->index;
			m_image->setSource(scrollData->imageSrc);
		}
	}

}


