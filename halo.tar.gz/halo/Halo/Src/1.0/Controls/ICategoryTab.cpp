#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	static HALO::util::Logger LOGGER("ICategoryTab");

	ICategoryTab* ICategoryTab::CreateInstance(IActor* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "ICategoryTab::CreateInstance [" << width << "," << height << "]");
		CCategoryTab* tab = dynamic_cast<CCategoryTab*>(Instance::CreateInstance(CLASS_ID_ICATEGORYTAB));

		if (NULL != tab)
		{
			tab->Initialize(parent, width, height);
		}

		return tab;
	}

	ICategoryTab* ICategoryTab::CreateInstance(Widget* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "ICategoryTab::CreateInstance [" << width << "," << height << "]");
		CCategoryTab* tab = dynamic_cast<CCategoryTab*>(Instance::CreateInstance(CLASS_ID_ICATEGORYTAB));

		if (NULL != tab)
		{
			tab->Initialize(parent, width, height);
		}

		return tab;
	}
}