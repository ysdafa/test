#ifdef WIN32
#include <WinSock2.h>
#endif

#include "Halo1_0.h"
#include <gdk-pixbuf/gdk-pixbuf.h>
#include "FileIORequest.h"

static HALO::util::Logger LOGGER("CImageBuffer");

namespace HALO
{
	CImageBuffer::~CImageBuffer(void)
	{
		H_LOG_TRACE(LOGGER, "CImageBuffer::~CImageBuffer.");
		if (NULL != m_croppedBuf)
		{
			g_object_unref(m_croppedBuf);
			m_croppedBuf = NULL;
		}
		if (NULL != m_pixbuf)
		{
			g_object_unref(m_pixbuf);
			m_pixbuf = NULL;
		}
	}

	bool CImageBuffer::Initialize(const char *fileName)
	{
		H_LOG_TRACE(LOGGER, "CImageBuffer::Initialize. fileName:" << fileName);
		ASSERT(NULL != fileName);

		std::string fullPath;
		Resource::FileIORequest::NormalizePath(fileName, fullPath);
		H_LOG_TRACE(LOGGER, "Initialize. Transfer fileName to fullPath:" << fullPath.c_str());

		m_pixbuf = gdk_pixbuf_new_from_file(fullPath.c_str(), NULL);

		ASSERT(NULL != m_pixbuf && "please check if the file  exists !");

		return true;
	}

	bool CImageBuffer::Initialize(const char *data, int len)
	{
		H_LOG_TRACE(LOGGER, "CImageBuffer::Initialize. data:" << data << "len:" << len);
		ASSERT(NULL != data && len > 0);

		GdkPixbufLoader *loader = gdk_pixbuf_loader_new();
		gdk_pixbuf_loader_write(loader, (const guchar*) data, len, NULL);
		gdk_pixbuf_loader_close(loader, NULL);

		m_pixbuf = gdk_pixbuf_loader_get_pixbuf(loader);
		g_object_unref(loader);

		ASSERT(NULL != m_pixbuf && "please check the data !");

		return true;
	}

	bool CImageBuffer::Initialize(IImageBuffer *buffer)
	{
		H_LOG_TRACE(LOGGER, "CImageBuffer::Initialize. buffer:" << buffer);
		ASSERT(NULL != buffer);

		CImageBuffer *cBuffer = dynamic_cast<CImageBuffer*>(buffer);
		if (cBuffer)
		{
			m_pixbuf = gdk_pixbuf_copy(cBuffer->m_pixbuf);
			return true;
		}

		return false;
	}

	void CImageBuffer::SetClipArea(int x, int y, int width, int height)
	{
		H_LOG_DEBUG(LOGGER, "CImageBuffer::SetClipArea. x:" << x << "y:" << y << "width:" << width << "height:" << height);
		ASSERT(x >= 0 && y >= 0 && width > 0 && height > 0);

		if (x==0 && y==0 && width==OriginalWidth() && height==OriginalHeight())
		{
			return;
		}
		
		m_croppedBuf = gdk_pixbuf_new_subpixbuf(m_pixbuf, x, y, width, height);

		//printf("%d %d %d %d \n", x, y, width, height);
	}

	int CImageBuffer::OriginalWidth(void)
	{
		return gdk_pixbuf_get_width(m_pixbuf);
	}

	int CImageBuffer::OriginalHeight(void)
	{
		return gdk_pixbuf_get_height(m_pixbuf);
	}

	int CImageBuffer::Width(void) 
	{
		int width = 0;
		if (NULL != m_croppedBuf)
		{
			width = gdk_pixbuf_get_width(m_croppedBuf);
		}
		else
		{
			width = gdk_pixbuf_get_width(m_pixbuf);
		}
		H_LOG_TRACE(LOGGER, "CImageBuffer::Width.." << width);
		return width;
	}

	int CImageBuffer::Height(void) 
	{
		int height = 0;
		if (NULL != m_croppedBuf)
		{
			height = gdk_pixbuf_get_height(m_croppedBuf);
		}
		else
		{
			height = gdk_pixbuf_get_height(m_pixbuf);
		}
		H_LOG_TRACE(LOGGER, "CImageBuffer::Height.." << height);
		return height;
	}

	int CImageBuffer::BytesPerLine(void) 
	{
		int bytesPerLine = 0;
		if (NULL != m_croppedBuf)
		{
			bytesPerLine = gdk_pixbuf_get_rowstride(m_croppedBuf);
		}
		else
		{
			bytesPerLine = gdk_pixbuf_get_rowstride (m_pixbuf);
		}
		H_LOG_TRACE(LOGGER, "CImageBuffer::BytesPerLine.." << bytesPerLine);
		return bytesPerLine;
	}

	bool CImageBuffer::HasAlphaChannel(void) 
	{
		bool hasAlpha = false;
		if (NULL != m_croppedBuf)
		{
			hasAlpha = gdk_pixbuf_get_has_alpha(m_croppedBuf) ? true : false;
		}
		else
		{
			hasAlpha = gdk_pixbuf_get_has_alpha(m_pixbuf) ? true : false;
		}
		H_LOG_TRACE(LOGGER, "CImageBuffer::HasAlphaChannel.." << hasAlpha);
		return hasAlpha;
	}

	guchar* CImageBuffer::GetPixels(void) 
	{
		if (NULL != m_croppedBuf)
		{
			return gdk_pixbuf_get_pixels(m_croppedBuf);
		}
		else
		{
			return gdk_pixbuf_get_pixels(m_pixbuf);
		}
	}

	IImageBuffer* CImageBuffer::Clone(void)
	{
		CImageBuffer *buffer = new CImageBuffer();
		buffer->Initialize(this);

		return buffer;
	}

	bool CImageBuffer::SaveToFile(const char *fileName, const char *format)
	{
		H_LOG_DEBUG(LOGGER, "CImageBuffer::SaveToFile. fileName:" << fileName << "format:" << format);
		return false;
	}


}
