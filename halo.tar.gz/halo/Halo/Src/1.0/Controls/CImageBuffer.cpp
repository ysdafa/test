#ifdef WIN32
#include <WinSock2.h>
#endif

#include "Halo1_0.h"
#include <gdk-pixbuf/gdk-pixbuf.h>
#include "FileIORequest.h"

static HALO::util::Logger LOGGER("CImageBuffer");

namespace HALO
{
	CImageBuffer::~CImageBuffer(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "]");
		if (NULL != m_croppedBuf)
		{
			g_object_unref(m_croppedBuf);
			m_croppedBuf = NULL;
		}
		if (NULL != m_pixbuf)
		{
			g_object_unref(m_pixbuf);
			m_pixbuf = NULL;
		}
	}

	bool CImageBuffer::Initialize(const char *fileName)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] fileName(" << fileName << ")");
		HALO_ASSERT(NULL != fileName);

		std::string fullPath;
		Resource::FileIORequest::NormalizePath(fileName, fullPath);

		m_pixbuf = gdk_pixbuf_new_from_file(fullPath.c_str(), NULL);

		if (NULL == m_pixbuf) 
		{ 
			H_LOG_FATAL(LOGGER, "[" << this << "] Error! File " << fullPath << " open failed! Maybe not exists..");
			return false;
		}

		return true;
	}

	bool CImageBuffer::Initialize(const char *data, int len)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] data(" << data << ") len(" << len << ")");
		HALO_ASSERT(NULL != data && len > 0);

		GdkPixbufLoader *loader = gdk_pixbuf_loader_new();
		gdk_pixbuf_loader_write(loader, (const guchar*) data, len, NULL);
		gdk_pixbuf_loader_close(loader, NULL);

		m_pixbuf = gdk_pixbuf_loader_get_pixbuf(loader);
		g_object_unref(loader);

		if (NULL == m_pixbuf) 
		{ 
			H_LOG_FATAL(LOGGER, "[" << this << "] Error! please check the data");
			return false;
		}

		return true;
	}

	bool CImageBuffer::Initialize(IImageBuffer *buffer)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] buffer(" << buffer << ")");
		HALO_ASSERT(NULL != buffer);

		CImageBuffer *cBuffer = dynamic_cast<CImageBuffer*>(buffer);
		if (cBuffer && cBuffer->m_pixbuf)
		{
			m_pixbuf = gdk_pixbuf_copy(cBuffer->m_pixbuf);
			return true;
		}

		H_LOG_FATAL(LOGGER, "[" << this << "] Error!");
		return false;
	}

	void CImageBuffer::SetClipArea(int x, int y, int width, int height)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] x(" << x <<") y(" << y <<") width(" <<width << ") height(" << height << ")");
		HALO_ASSERT(x >= 0 && y >= 0 && width > 0 && height > 0);

		if (NULL == m_pixbuf)
		{
			H_LOG_FATAL(LOGGER, "m_pixbuf is NULL!");
			return;
		}		

		if (x==0 && y==0 && width==OriginalWidth() && height==OriginalHeight())
		{
			return;
		}
		
		m_croppedBuf = gdk_pixbuf_new_subpixbuf(m_pixbuf, x, y, width, height);

		//printf("%d %d %d %d \n", x, y, width, height);
	}

	int CImageBuffer::OriginalWidth(void)
	{
		if (NULL == m_pixbuf)
		{
			H_LOG_FATAL(LOGGER, "m_pixbuf is NULL!");
			return 0;
		}

		return gdk_pixbuf_get_width(m_pixbuf);
	}

	int CImageBuffer::OriginalHeight(void)
	{
		if (NULL == m_pixbuf)
		{
			H_LOG_FATAL(LOGGER, "m_pixbuf is NULL!");
			return 0;
		}

		return gdk_pixbuf_get_height(m_pixbuf);
	}

	int CImageBuffer::Width(void) 
	{
		if (NULL == m_pixbuf)
		{
			H_LOG_FATAL(LOGGER, "m_pixbuf is NULL!");
			return 0;
		}

		int width = 0;
		if (NULL != m_croppedBuf)
		{
			width = gdk_pixbuf_get_width(m_croppedBuf);
		}
		else
		{
			width = gdk_pixbuf_get_width(m_pixbuf);
		}
		H_LOG_TRACE(LOGGER, "[" << this << "] width(" << width << ")");
		return width;
	}

	int CImageBuffer::Height(void) 
	{
		if (NULL == m_pixbuf)
		{
			H_LOG_FATAL(LOGGER, "m_pixbuf is NULL!");
			return 0;
		}

		int height = 0;
		if (NULL != m_croppedBuf)
		{
			height = gdk_pixbuf_get_height(m_croppedBuf);
		}
		else
		{
			height = gdk_pixbuf_get_height(m_pixbuf);
		}
		H_LOG_TRACE(LOGGER, "[" << this << "] height(" << height << ")");
		return height;
	}

	int CImageBuffer::BytesPerLine(void) 
	{
		if (NULL == m_pixbuf)
		{
			H_LOG_FATAL(LOGGER, "m_pixbuf is NULL!");
			return 0;
		}

		int bytesPerLine = 0;
		if (NULL != m_croppedBuf)
		{
			bytesPerLine = gdk_pixbuf_get_rowstride(m_croppedBuf);
		}
		else
		{
			bytesPerLine = gdk_pixbuf_get_rowstride (m_pixbuf);
		}
		H_LOG_TRACE(LOGGER, "[" << this << "] bytesPerLine(" << bytesPerLine << ")");
		return bytesPerLine;
	}

	bool CImageBuffer::HasAlphaChannel(void) 
	{
		if (NULL == m_pixbuf)
		{
			H_LOG_FATAL(LOGGER, "m_pixbuf is NULL!");
			return false;
		}

		bool hasAlpha = false;
		if (NULL != m_croppedBuf)
		{
			hasAlpha = gdk_pixbuf_get_has_alpha(m_croppedBuf) ? true : false;
		}
		else
		{
			hasAlpha = gdk_pixbuf_get_has_alpha(m_pixbuf) ? true : false;
		}
		H_LOG_TRACE(LOGGER, "[" << this << "] hasAlpha(" << hasAlpha << ")");
		return hasAlpha;
	}

	guchar* CImageBuffer::GetPixels(void) 
	{
		if (NULL == m_pixbuf)
		{
			H_LOG_FATAL(LOGGER, "m_pixbuf is NULL!");
			return NULL;
		}

		if (NULL != m_croppedBuf)
		{
			return gdk_pixbuf_get_pixels(m_croppedBuf);
		}
		else
		{
			return gdk_pixbuf_get_pixels(m_pixbuf);
		}
	}

	bool CImageBuffer::IsReady(void)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] isReady(" << (m_pixbuf != NULL) << ")");
		return m_pixbuf != NULL;
	}

	IImageBuffer* CImageBuffer::Clone(void)
	{
		CImageBuffer *buffer = new CImageBuffer();
		buffer->Initialize(this);

		return buffer;
	}

	bool CImageBuffer::SaveToFile(const char *fileName, const char *format)
	{
		H_LOG_TRACE(LOGGER, "[" << this << "] fileName(" << fileName << ") format(" <<format << ")");
		return false;
	}


}
