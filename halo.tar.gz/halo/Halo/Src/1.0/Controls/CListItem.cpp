#include "Halo1_0.h"

namespace HALO
{
	void CListItem::t_LoadData()
	{
		for (int index = 0; index < t_UIElements.size() ;index++)
		{
			t_UIElements[index]->LoadData();
		}
	}

	void CListItem::Enable(bool flagEnable)
	{
		if(flagEnable)
		{
			m_curState = E_STATE_UNSELECTED;
		}
		else
		{
			m_curState = E_STATE_DISABLED;
		}

		CActor::Enable(flagEnable);

		for (int index = 0; index < t_UIElements.size() ;index++)
		{
			t_UIElements[index]->Enable(flagEnable);
		}
		m_OnStateChange();
	}

	void CListItem::LoadData()
	{
		t_LoadData();
	}

	void CListItem::UnLoadData()
	{
		for (int index = 0; index < t_UIElements.size() ;index++)
		{
			t_UIElements[index]->UnLoadData();
		}
	}

	void CListItem::SetIndex(int itemIndex)
	{
		t_itemIndex = itemIndex;
	}

	void CListItem::SetItemImage( IImageBuffer *buffer , EListStateType statetype )
	{
		ASSERT(buffer != NULL);

		if(statetype == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				m_stateData[i].imageBuffer = dynamic_cast<CImageBuffer*>(buffer);
			}
		}
		else
		{
			m_stateData[statetype].imageBuffer = dynamic_cast<CImageBuffer*>(buffer);
		}
		//m_OnStateChange();
		if (statetype == E_STATE_ALL || statetype == m_curState)
		{
			t_Image->SetImage(m_stateData[m_curState].imageBuffer);
			t_Image->Show();
		}
	}


	bool CListItem::Initialize( IActor* parent, float width, float height )
	{
		t_Initialize(parent , width , height);
		return true;
	}

	void CListItem::m_CreateUIElemenObj(TRect* rect , EListItemStyle itemStyle)
	{
		if (itemStyle & E_ITEM_NONE)
		{

		}
		else if (itemStyle & E_ITEM_INDICATOR)
		{
			CListItemDecorator* indicator = new CImageDecorator;
			indicator->SetUIElementStyle(E_ITEM_INDICATOR);
			t_UIElements.push_back(indicator);

		}
		else if (itemStyle & E_ITEM_CONTENTTEXT)
		{
			CListItemDecorator* text = new CTextDecorator;
			text->SetUIElementStyle(E_ITEM_CONTENTTEXT);
			t_UIElements.push_back(text);
		} 
		else if(itemStyle & E_ITEM_ICON)
		{
			CListItemDecorator* icon = new CImageDecorator;
			icon->SetUIElementStyle(E_ITEM_ICON);
			t_UIElements.push_back(icon);
		}
		else if (itemStyle & E_ITEM_PROGRESSBAR)
		{
			CListItemDecorator* progress = new CProgressDecorator;
			progress->SetUIElementStyle(E_ITEM_PROGRESSBAR);
			t_UIElements.push_back(progress);
		} 
	}


	void CListItem::SetStyle( TItemBaseAttr* attr , EListItemStyle itemStyle )
	{

		m_CreateUIElemenObj(attr , itemStyle);
		m_SetUIElemenAttr(attr , itemStyle);

	}

	void CListItem::m_SetUIElemenAttr( TRect* rect , EListItemStyle itemStyle)
	{
		for (int index = 0; index < t_UIElements.size(); index++)
		{
			if (t_UIElements[index]->GetUIElementStyle() & itemStyle)
			{
				t_UIElements[index]->Create(rect , this);
			}
		}
	}

	void CListItem::SetTitleText( const char* titleText , EListStateType statetype )
	{
		ASSERT(titleText != NULL);
		int textLen = strlen(titleText) + 1;
		if(statetype == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				if (m_stateData[i].textContent != NULL)
				{
					delete[] m_stateData[i].textContent;
					m_stateData[i].textContent = NULL;
				}
				m_stateData[i].textContent = new char[textLen];
				strncpy(m_stateData[i].textContent, titleText, textLen);
			}
		}
		else
		{
			if (m_stateData[statetype].textContent != NULL)
			{
				delete[] m_stateData[statetype].textContent;
				m_stateData[statetype].textContent = NULL;
			}
			m_stateData[statetype].textContent = new char[textLen];
			strncpy(m_stateData[statetype].textContent, titleText, textLen);
		}
		//m_OnStateChange();
		if (statetype == E_STATE_ALL || statetype == m_curState)
		{
			t_TitleText->SetText(m_stateData[m_curState].textContent);
			t_TitleText->Show();
		}
	}

	void CListItem::SetTitleTextFontSize( int fontSize , EListStateType statetype )
	{

	}

	void CListItem::SetTitleTextFont( const char* titlefont , EListStateType statetype )
	{
		ASSERT(titlefont != NULL);
		int fontLen = strlen(titlefont) + 1;
		if(statetype == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				if (m_stateData[i].font != NULL)
				{
					delete[] m_stateData[i].font;
					m_stateData[i].font = NULL;
				}
				m_stateData[i].font = new char[fontLen];
				strncpy(m_stateData[i].font, titlefont, fontLen);
			}
		}
		else
		{
			if (m_stateData[statetype].font != NULL)
			{
				delete[] m_stateData[statetype].font;
				m_stateData[statetype].font = NULL;
			}
			m_stateData[statetype].font = new char[fontLen];
			strncpy(m_stateData[statetype].font, titlefont, fontLen);
		}
		//m_OnStateChange();
		if (statetype == E_STATE_ALL || statetype == m_curState)
		{
			t_TitleText->SetFont(m_stateData[m_curState].font);
		}
	}

	void CListItem::SetTitleTextColor( const ClutterColor color , EListStateType statetype )
	{
		if(statetype == E_STATE_ALL)
		{
			for(int i = 0; i < E_STATE_ALL; i++)
			{
				m_stateData[i].color = color;
			}
		}
		else
		{
			m_stateData[statetype].color = color;
		}
		//m_OnStateChange();
		if (statetype == E_STATE_ALL || statetype == m_curState)
		{
			t_TitleText->SetTextColor(m_stateData[m_curState].color);
		}
	}

	void CListItem::ChangeStateTo( EListStateType toState )
	{
		if (toState == m_curState || E_STATE_ALL == toState)
		{
			return;
		}
		m_curState = toState;
		m_OnStateChange();
	}

	void CListItem::m_OnStateChange( void )
	{
		if (E_STATE_SELECTED == m_curState &&
			NULL == m_stateData[E_STATE_SELECTED].imageBuffer && NULL == m_stateData[E_STATE_SELECTED].textContent)
		{
			m_curState = E_STATE_FOCUSED;
			m_OnStateChange();
			return;
		}

		if (E_STATE_FOCUSED == m_curState && IsFocusEnabled() == false)
		{
			m_curState = E_STATE_UNSELECTED;
			m_OnStateChange();
			return;
		}

		if(NULL == m_stateData[m_curState].imageBuffer)
		{
			t_Image->Hide();
		}
		else
		{
			t_Image->SetImage(m_stateData[m_curState].imageBuffer);
			t_Image->Show();
		}

		if(m_stateData[m_curState].font != NULL)
		{
			t_TitleText->SetFont(m_stateData[m_curState].font);
		}

		if(m_stateData[m_curState].textContent != NULL)
		{
			t_TitleText->SetTextColor(m_stateData[m_curState].color);
			t_TitleText->SetText(m_stateData[m_curState].textContent);
			t_TitleText->Show();
		}
		else
		{
			t_TitleText->Hide();
		}
	}

	void CListItem::t_Initialize(IActor* parent, float width, float height)
	{
		t_itemIndex = 0;
		t_Width = width;
		t_Height = height;
		CActor::Initialize(parent, width, height);
		t_Image = IImage::CreateInstance(dynamic_cast<Widget*>(this), width, height);
		t_TitleText = IText::CreateInstance(dynamic_cast<Widget*>(this), width, height);

		if (t_TitleText != NULL)
		{
			t_TitleText->SetTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
		}

		m_curState = E_STATE_UNSELECTED;

		for(int i = 0; i < E_STATE_ALL; i++)
		{
			m_stateData[i].imageBuffer = NULL;
			m_stateData[i].textContent = NULL;
			m_stateData[i].font = NULL;
			ClutterColor c = {0, 0, 0, 255};
			m_stateData[i].color = c;
		}
	}

	void CListItem::ResizeTitleText( float width, float height )
	{
		ASSERT(width < t_Width || height < t_Height);
		t_TitleText->Resize(width , height);
	}

	void CListItem::SetTitleTextPosition( float xpos, float ypos )
	{
		ASSERT(ypos < t_Width || xpos < t_Height);
		t_TitleText->SetPosition(xpos , ypos);
	}

	void CListItem::SetProgressValue( int value )
	{
		for (int index = 0; index < t_UIElements.size() ;index++)
		{
			if (t_UIElements[index]->GetUIElementStyle() == E_ITEM_PROGRESSBAR)
			{
				((CProgressDecorator*)t_UIElements[index])->SetValue(value);
			}
		}
	}

	CListItem::~CListItem()
	{
		delete t_TitleText;
		t_TitleText = NULL;

		delete t_Image;
		t_Image = NULL;

		for (int i = 0; i < E_STATE_ALL; i++)
		{
			if (m_stateData[i].textContent != NULL)
			{
				delete[] m_stateData[i].textContent;
			}

			if (m_stateData[i].font != NULL)
			{
				delete[] m_stateData[i].font;
			}

			if (m_stateData[i].imageBuffer != NULL)
			{
				delete[] m_stateData[i].imageBuffer;
			}
		}

		t_UIElements.clear();
	}

	bool CExpandableListItem::Initialize( IActor* parent, float width, float height )
	{
		m_Expandabled = false;
		t_Initialize(parent , width , height);
		AddClickListener(this);
		AddKeyboardListener(this);
		IClickAction* action = IClickAction::CreateInstance(this);
		this->AddAction(action);
		m_action = action;
		m_listItemListener = NULL;
		return true;
	}


	void CExpandableListItem::SetExpandable( bool isExpandabled )
	{
		if (isExpandabled == true)
		{
			m_Image->SetImage(m_OpenImageBuffer);
			m_OpenItem();
		}
		else
		{
			m_Image->SetImage(m_ClosedImageBuffer);
			m_CloseItem();
		}
		m_Expandabled = isExpandabled;
		m_listItemListener->OnExpandableChanged(this , t_itemIndex , 0 , m_Expandabled);
	}

	bool CExpandableListItem::OnClicked( IActor* pWindow, IEvent* pClickEvent )
	{
		if (m_Expandabled)
		{
			m_Expandabled = false;
			m_CloseItem();
		}
		else
		{
			m_Expandabled = true;
			m_OpenItem();
		}
		if (m_listItemListener != NULL)
		{
			m_listItemListener->OnExpandableChanged(this , t_itemIndex , 0 , m_Expandabled);
		}
		return true;
	}

	bool CExpandableListItem::OnKeyPressed( IActor* pThis, IKeyboardEvent* event )
	{
		int keyValue = event->GetKeyVal();
		if (keyValue == KEY_ENTER)
		{
			if (m_Expandabled)
			{
				m_Expandabled = false;
				m_CloseItem();
			}
			else
			{
				m_Expandabled = true;
				m_OpenItem();
			}
			m_listItemListener->OnExpandableChanged(this , t_itemIndex , 0 , m_Expandabled);
		}
		return true;
	}

	void CExpandableListItem::AddListener( ListItemListener* listener )
	{
		m_listItemListener = listener;
	}

	bool CExpandableListItem::IsExpandabled()
	{
		return m_Expandabled;
	}

	void CExpandableListItem::m_OpenItem()
	{

		m_alphaAni->SetDestination(255);
		m_alphaAni->Play();

		m_subListExpandAni->SetDestination(1.0f);
		m_subListExpandAni->Play();
	}

	void CExpandableListItem::m_CloseItem()
	{
		m_alphaAni->SetDestination(0);
		m_alphaAni->Play();

		m_subListExpandAni->SetDestination(0.0f);
		m_subListExpandAni->Play();

		m_Expandabled = false;
	}

	void CExpandableListItem::RemoveListener()
	{
		ASSERT( m_listItemListener != NULL);
		delete m_listItemListener;
	}

	CExpandableListItem::~CExpandableListItem()
	{
		if (NULL != m_Image)
		{
			delete m_Image;
			m_Image = NULL;
		}
		if (NULL != m_OpenImageBuffer)
		{
			delete m_OpenImageBuffer;
			m_OpenImageBuffer = NULL;
		}
		if (NULL != m_ClosedImageBuffer)
		{
			delete m_ClosedImageBuffer;
			m_ClosedImageBuffer = NULL;
		}
		RemoveKeyboardListener(this);
		this->RemoveAction(m_action);
		m_action->Release();
	}

	void CExpandableListItem::SetExpandableFlagImageBuffer( IImageBuffer* imagebuffer , EExpandableType imageType )
	{
		if (NULL != imagebuffer)
		{
			if (imageType == E_TYPE_OPEN)
			{
				m_OpenImageBuffer = imagebuffer;
			}
			else
			{
				m_ClosedImageBuffer = imagebuffer;
			}
		}
	}

	void CExpandableListItem::SetSingleLineListToItem( ISingleLineListControl* singlelinelist )
	{
		m_SingleLineList = singlelinelist;
		m_SingleLineList->SetParent(this);
		m_SingleLineList->SetPosition(0 , t_Height);
		m_subListExpandAni = new TransitionBase;
		m_subListExpandAni->Initialize(false);
		m_SingleLineList->BindTransition(m_subListExpandAni, ACTOR_ANI_SCALE_Y);
		m_subListExpandAni->SetDuration(500);

		m_alphaAni = new TransitionBase;
		m_alphaAni->Initialize(false);
		m_SingleLineList->BindTransition(m_alphaAni, ACTOR_ANI_ALPHA);

		m_CloseItem();
	}

	void CExpandableListItem::CreateExpandableFlagImage( TRect rect )
	{
		m_Image = IImage::CreateInstance((IActor*)this , rect.w , rect.h);
		m_Image->SetPosition(rect.x , rect.y);
	}


	bool CListSelectItem::Initialize( IActor* parent, float width, float height )
	{
		m_Image = NULL;
		m_SelectedImageBuffer = NULL;
		m_UnSelectedImageBuffer = NULL;
		t_Initialize(parent , width , height);
		m_Selected = false;
		AddClickListener(this);
		AddKeyboardListener(this);
		IClickAction* action = IClickAction::CreateInstance(this);
		this->AddAction(action);
		m_action = action;
		m_listItemListener = NULL;
		return true;
	}


	void CListSelectItem::SetCheck( bool isChecked )
	{
		if (isChecked == true)
		{
			m_Image->SetImage(m_SelectedImageBuffer);
		}
		else
		{
			m_Image->SetImage(m_UnSelectedImageBuffer);
		}
		m_Selected = isChecked;
	}

	bool CListSelectItem::IsChecked()
	{
		return m_Selected;
	}

	bool CListSelectItem::OnClicked( IActor* pWindow, IEvent* pClickEvent )
	{
		if (this->IsChecked())
		{
			this->SetCheck(false);
			m_Selected = false;
		}
		else
		{
			this->SetCheck(true);
			m_Selected = true;
		}
		if (m_listItemListener != NULL)
		{
			m_listItemListener->OnCheckedChanged(this , t_itemIndex , m_Selected);
		}
		return true;
	}

	bool CListSelectItem::OnKeyPressed( IActor* pThis, IKeyboardEvent* event )
	{
		int keyValue = event->GetKeyVal();
		if (keyValue == KEY_ENTER)
		{
			if (m_Selected)
			{
				m_Selected = false;
			}
			else
			{
				m_Selected = true;
			}
			m_listItemListener->OnCheckedChanged(this , t_itemIndex , m_Selected);
		}
		return true;
	}

	void CListSelectItem::AddListener( ListItemListener* listener )
	{
		m_listItemListener = listener;
	}

	void CListSelectItem::LoadData()
	{
		t_LoadData();
		m_Image->SetImage(m_UnSelectedImageBuffer);
	}

	void CListSelectItem::SetSelectImageBuffer( IImageBuffer* imagebuffer , ESelectType imageType )
	{
		if (NULL != imagebuffer)
		{
			if (imageType == E_TYPE_UNSELECTED)
			{
				m_SelectedImageBuffer = imagebuffer;
			}
			else
			{
				m_UnSelectedImageBuffer = imagebuffer;
			}
		}
	}

	void CListSelectItem::CreateSelectImage( TRect rect )
	{
		m_Image = IImage::CreateInstance((IActor*)this , rect.w , rect.h);
		m_Image->SetPosition(rect.x , rect.y);
	}

	void CListSelectItem::RemoveListener()
	{
		ASSERT( m_listItemListener != NULL);
		delete m_listItemListener;
	}

	CListSelectItem::~CListSelectItem()
	{
		if (NULL != m_Image)
		{
			delete m_Image;
			m_Image = NULL;
		}
		if (NULL != m_SelectedImageBuffer)
		{
			delete m_SelectedImageBuffer;
			m_SelectedImageBuffer = NULL;
		}
		if (NULL != m_UnSelectedImageBuffer)
		{
			delete m_UnSelectedImageBuffer;
			m_UnSelectedImageBuffer = NULL;
		}
		RemoveKeyboardListener(this);
		this->RemoveAction(m_action);
		m_action->Release();
	}

}