#ifndef _CCHECKBOX_GROUP_H_
#define _CCHECKBOX_GROUP_H_

namespace HALO
{

	class CCheckBoxGroup : virtual public ICheckBoxGroup, public CSelectButtonGroup
	{
	public:
		CCheckBoxGroup();

		virtual ~CCheckBoxGroup();
		virtual bool Initialize(void);
		virtual std::vector<int> GetSelectedItemIndexes();
	protected:
		virtual void t_ProcessSelect(class ISelectButton* button , bool ischecked);
		virtual const char* GetActorType(void);

	private:
		void m_Destory();

		std::vector<int> m_CheckSate;

	};



}
#endif