#ifndef _CDIM_WINDOW_H_
#define _CDIM_WINDOW_H_

namespace HALO
{
	class CDimWindow : virtual public IDimWindow, public CActor
	{
	public:
		CDimWindow(void);
		virtual ~CDimWindow(void);

		virtual bool Initialize(Widget* parent, float width, float height);

		virtual void SetBackgroundColor(const ClutterColor &color);

		virtual void AddTransparentArea(float x, float y, float width, float height);

		virtual void ClearTransparentArea(void);

	public:
		virtual ClutterActor* t_CreateActor(void);

	};
}

#endif /*_CDIM_WINDOW_H_*/