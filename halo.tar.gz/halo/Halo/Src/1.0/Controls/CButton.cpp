#include "Halo1_0.h"
static HALO::util::Logger LOGGER("ButtonControl");

namespace HALO
{
	/******* CButtonListenerSet ***********/
	class CButtonListenerSet : public ListenerSet
	{
	public:

		CButtonListenerSet(CButton* owner) :m_owner(owner){};
		virtual ~CButtonListenerSet(void){};

		virtual bool Process(int type);

	private:
		CButton* m_owner;
	};

	bool CButtonListenerSet::Process(int type)
	{
		bool ret = false;
		Lock();
		ListenerList::iterator iter = m_list.begin();

		while (iter != m_list.end())
		{
			IButtonListener* listener = (IButtonListener*)(*iter);

			switch (type)
			{
			case CButton::EVENT_RETURN_KEY_CLICKED:
				H_LOG_DEBUG(LOGGER, "[0x" << std::hex << m_owner << "]CButton::EVENT_RETURN_KEY_CLICKED Listener--start");
				ret |= listener->OnButtonClicked(m_owner, IButtonListener::TYPE_RETRUN_KEY);
				H_LOG_DEBUG(LOGGER, "[0x" << std::hex << m_owner << "]CButton::EVENT_RETURN_KEY_CLICKED Listener--end");
				break;
			case CButton::EVENT_MOUSE_BUTTON_CLICKED:
				H_LOG_DEBUG(LOGGER, "[0x" << std::hex << m_owner << "]CButton::EVENT_MOUSE_BUTTON_CLICKED Listener--start");
				ret |= listener->OnButtonClicked(m_owner, IButtonListener::TYPE_MOUSE);
				H_LOG_DEBUG(LOGGER, "[0x" << std::hex << m_owner << "]CButton::EVENT_MOUSE_BUTTON_CLICKED Listener--end");
				break;
			default:
				break;
			}
			if (m_list.empty())
			{
				break;
			}
			
			iter++;
		}
		Unlock();
		return ret;
	}

	/******* CButton ***********/
	CButton::CButton() : m_backGroundImage(NULL), m_icon(NULL), m_text(NULL), m_listenerSet(NULL), 
		m_curState(STATE_NORMAL), m_flagEnabled(true), m_flagPointerIn(false), m_flagMousePressed(false), m_flagReturnKeyPressed(false)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::CButton()");
	}

	CButton::~CButton()
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::~CButton()");
		if (m_backGroundImage != NULL)
		{
			delete m_backGroundImage;
		}
		if (m_icon != NULL)
		{
			delete m_icon;
		}
		if (m_text != NULL)
		{
			delete m_text;
		}
		if (m_listenerSet != NULL)
		{
			//delete m_listenerSet;
			if (m_listenerSet->IsLocked())
			{
				m_listenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(m_listenerSet);
			} 
			else
			{
				delete m_listenerSet;
			}
			m_listenerSet = NULL;
		}

		RemoveMouseListener(this);
		RemoveFocusListener(this);
		RemoveKeyboardListener(this);
	}

	bool CButton::Initialize(IActor* parent, float width, float height)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::Initialize() with IActor parent: 0x" << parent << ", width: " << width << ", height: " << height);
		CActor::Initialize(parent, width, height);
		
		m_Initialize();

		return true;
	}

	bool CButton::Initialize(Widget* parent, float width, float height)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::Initialize() with Widget parent: 0x" << parent << ", width: " << width << ", height: " << height);
		CActor::Initialize(parent, width, height);

		m_Initialize();

		return true;
	}

	void CButton::SetBackgroundImage(EButtonState state, const std::string& imagePath)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::SetBackgroundImage() to state: " << state << ", imagePath: " << imagePath);
		HALO_ASSERT(state <= STATE_ALL);

		float width, height;
		GetSize(width, height);

		if (NULL == m_backGroundImage)
		{
			m_backGroundImage = ICompositeImage::CreateInstance(dynamic_cast<Widget*>(this), width, height);
		}

		if(state == STATE_ALL)
		{
			for(int i = 0; i < STATE_ALL; i++)
			{
				m_stateData[i].backgroundImagePath = imagePath;
			}
		}
		else
		{
			m_stateData[state].backgroundImagePath = imagePath;
		}

		if (m_backGroundImage != NULL && (state == STATE_ALL || state == m_curState))
		{
			if (imagePath.empty())
			{
				m_backGroundImage->Hide();
			}
			else
			{
				m_backGroundImage->SetImage(m_stateData[m_curState].backgroundImagePath.c_str());
				m_backGroundImage->Show();
				m_backGroundImage->Lower(NULL);
			}
		}
	}

	const std::string& CButton::BackgroundImage(EButtonState state)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::BackgroundImage() of state: " << state);
		HALO_ASSERT(state <= STATE_ALL);

		return m_stateData[state].backgroundImagePath;
	}

	void CButton::SetText(EButtonState state, const std::string& text)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::SetText() to state: " << state << ", text: " << text);
		HALO_ASSERT(state <= STATE_ALL);

		float width, height;
		GetSize(width, height);

		if (NULL == m_text)
		{
			m_text = IText::CreateInstance(dynamic_cast<Widget*>(this), width, height);
			if (m_text != NULL)
			{
				m_text->SetTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE); //need or not??
			}
		}

		if(state == STATE_ALL)
		{
			for(int i = 0; i < STATE_ALL; i++)
			{
				m_stateData[i].textContent = text;
			}
		}
		else
		{
			m_stateData[state].textContent = text;
		}

		if (m_text != NULL && (state == STATE_ALL || state == m_curState))
		{
			m_text->SetText(m_stateData[m_curState].textContent.c_str());
			m_text->SetTextColor(m_stateData[m_curState].textColor);
			m_text->SetFontSize(m_stateData[m_curState].fontSize);
		}
	}

	const std::string& CButton::Text(EButtonState state)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::Text() of state: " << state);
		HALO_ASSERT(state <= STATE_ALL);

		return m_stateData[state].textContent;
	}

	void CButton::SetTextColor(EButtonState state, const ClutterColor& color)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::SetTextColor() to state: " << state << ", color: {r: " << color.red << ", g:" <<color.green << ", b:" <<color.blue << ", a:" <<color.alpha << "}.");
		HALO_ASSERT(state <= STATE_ALL);

		if(state == STATE_ALL)
		{
			for(int i = 0; i < STATE_ALL; i++)
			{
				m_stateData[i].textColor = color;
			}
		}
		else
		{
			m_stateData[state].textColor = color;
		}

		if (m_text != NULL && (state == STATE_ALL || state == m_curState))
		{
			m_text->SetTextColor(m_stateData[m_curState].textColor);
		}
	}

	const ClutterColor& CButton::TextColor(EButtonState state)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::TextColor() of state: " << state);
		HALO_ASSERT(state <= STATE_ALL);

		return m_stateData[state].textColor;
	}

	void CButton::SetFontSize(EButtonState state, int fontSize)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::SetFontSize() to state: " << state << ", with font size: " << fontSize);
		HALO_ASSERT(state <= STATE_ALL && fontSize > 0);
		if (state == STATE_ALL)
		{
			for (int i = 0; i < STATE_ALL; i++)
			{
				m_stateData[i].fontSize = fontSize;
			}
		}
		else
		{
			m_stateData[state].fontSize = fontSize;
		}

		if (m_text != NULL && (state == STATE_ALL || state == m_curState))
		{
			m_text->SetFontSize(m_stateData[m_curState].fontSize);
		}
	}

	int CButton::FontSize(EButtonState state)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::FontSize() of state: " << state);
		HALO_ASSERT(state <= STATE_ALL);

		return m_stateData[state].fontSize;
	}

	void CButton::SetBackgroundColor(EButtonState state, const ClutterColor& color)
	{
	
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::SetBackgroundColor() to state: " << state << ", color: {r: " << color.red << ", g:" <<color.green << ", b:" <<color.blue  << ", a:" <<color.alpha << "}.");
		HALO_ASSERT(state <= STATE_ALL);

		if (state == STATE_ALL)
		{
			for (int i = 0; i < STATE_ALL; i++)
			{
				m_stateData[i].backgroundColor = color;
			}
		}
		else
		{
			m_stateData[state].backgroundColor = color;
		}

		if (state == STATE_ALL || state == m_curState)
		{
			CActor::SetBackgroundColor(m_stateData[m_curState].backgroundColor);
		}
	}

	const ClutterColor& CButton::BackgroundColor(EButtonState state)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::BackgroundColor() of state: " << state);
		HALO_ASSERT(state <= STATE_ALL);

		return m_stateData[state].backgroundColor;
	}

	void CButton::SetIconImage(EButtonState state, const std::string& iconPath)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::SetIconImage() to state: " << state << ", with iconPath: " << iconPath);
		
		HALO_ASSERT(state <= STATE_ALL);

		float width, height;
		GetSize(width, height);

		if (NULL == m_icon)
		{
			m_icon = IImage::CreateInstance(dynamic_cast<Widget*>(this), width, height);
			m_icon->SetFillMode(CLUTTER_CONTENT_GRAVITY_CENTER);
		}

		if (state == STATE_ALL)
		{
			for (int i = 0; i < STATE_ALL; i++)
			{
				m_stateData[i].iconPath = iconPath;
			}
		}
		else
		{
			m_stateData[state].iconPath = iconPath;
		}

		if (m_icon != NULL && (state == STATE_ALL || state == m_curState))
		{
			if (iconPath.empty())
			{
				m_icon->Hide();
			}
			else
			{
				m_icon->SetImage(m_stateData[m_curState].iconPath.c_str());
				m_icon->SetAlpha(m_stateData[m_curState].iconAlpha);
			}
		}
	}

	const std::string& CButton::IconImage(EButtonState state)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::IconImage() of state: " << state);
		HALO_ASSERT(state <= STATE_ALL);

		return m_stateData[state].iconPath;
	}

	void CButton::SetIconAlpha(EButtonState state, int opacity)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::SetIconAlpha() to state: " << state << ", with opacity: " << opacity);
		HALO_ASSERT(state <= STATE_ALL);

		if (state == STATE_ALL)
		{
			for (int i = 0; i < STATE_ALL; i++)
			{
				m_stateData[i].iconAlpha = opacity;
			}
		}
		else
		{
			m_stateData[state].iconAlpha = opacity;
		}

		if (m_icon != NULL && (state == STATE_ALL || state == m_curState))
		{
			m_icon->SetAlpha(m_stateData[m_curState].iconAlpha);
		}
	}

	int CButton::IconAlpha(EButtonState state)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::IconAlpha() of state: " << state);
		HALO_ASSERT(state <= STATE_ALL);

		return m_stateData[state].iconAlpha;
	}

	ICompositeImage* CButton::BackGroundImageActor(void)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::BackGroundImageActor().");

		return m_backGroundImage;
	}

	IText* CButton::TextActor(void)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::TextActor().");

		return m_text;
	}

	IImage* CButton::IconActor(void)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::IconActor().");

		return m_icon;
	}

	void CButton::Enable(bool flagEnable)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::Enable() with flag: " << flagEnable);

		if (flagEnable == m_flagEnabled)
		{
			return;
		}

		m_flagEnabled = flagEnable;

		if(flagEnable)
		{
			if (m_curState == STATE_DISABLED)
			{
				m_curState = STATE_NORMAL;
			}
			else if (m_curState == STATE_DISABLED_FOCUSED)
			{
				m_curState = STATE_FOCUSED;
			}
		}
		else
		{
			if (m_curState == STATE_FOCUSED)
			{
				m_curState = STATE_DISABLED_FOCUSED;
			}
			else
			{
				m_curState = STATE_DISABLED;
			}
		}

		//CActor::Enable(flagEnable);
		m_OnStateChange();
	}

	bool CButton::IsEnabled(void)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::IsEnabled().");

		return m_flagEnabled;
	}

	void CButton::Resize(float width, float height)
	{
		H_LOG_DEBUG(LOGGER, "CButton::Resize with width: " << width << ", height: " << height);
		
		CActor::Resize(width, height);
		if (m_backGroundImage != NULL)
		{
			m_backGroundImage->Resize(width, height);
		}
		if (m_icon != NULL)
		{
			m_icon->Resize(width, height);
		}
		if (m_text != NULL)
		{
			m_text->Resize(width, height);
		}
	}

	const char* CButton::GetActorType(void)
	{
		return "Button";
	}

	bool CButton::OnMouseButtonPressed(IWidgetExtension* pThis, IMouseEvent* event)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::OnMouseButtonPressed().");

		if (!m_flagEnabled)
		{
			return false;
		}

		m_flagMousePressed = true;
		m_ChangeStateTo(STATE_SELECTED);

		return true;
	}

	bool CButton::OnMouseButtonReleased(IWidgetExtension* pThis, IMouseEvent* event)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::OnMouseButtonReleased().");

		if (!m_flagEnabled)
		{
			return false;
		}

		bool flagFocus = IsFocused();
		EButtonState state;
		if (m_flagPointerIn)
		{
			state = (flagFocus ? STATE_FOCUSED_ROLL_OVER : STATE_ROLL_OVER);
			m_ChangeStateTo(state);
			if (m_flagMousePressed)
			{
				m_listenerSet->Process(EVENT_MOUSE_BUTTON_CLICKED);
			}
		}
		else
		{
			state = (flagFocus ? STATE_FOCUSED : STATE_NORMAL);
			m_ChangeStateTo(state);
		}

		m_flagMousePressed = false;
		return true;
	}

	bool CButton::OnMousePointerIn(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::OnMousePointerIn().");

		m_flagPointerIn = true;
		if (!m_flagEnabled)
		{
			return false;
		}
		bool flagFocus = IsFocused();
		EButtonState state;
		state = (flagFocus ? STATE_FOCUSED_ROLL_OVER : STATE_ROLL_OVER);

		m_ChangeStateTo(state);

		return true;
	}

	bool CButton::OnMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::OnMousePointerOut().");

		m_flagPointerIn = false;
		if (!m_flagEnabled)
		{
			return false;
		}

		bool flagFocus = IsFocused();
		EButtonState state;
		state = (flagFocus ? STATE_FOCUSED : STATE_NORMAL);

		m_ChangeStateTo(state);
		return true;
	}

	bool CButton::OnMouseMoved(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::OnMouseMoved().");

		if (!m_flagEnabled)
		{
			return false;
		}

		return true;
	}
	bool CButton::OnFocusIn(IWidgetExtension* pWindow)
	{
		
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::OnFocusIn().");
		

		bool flagRollOver = (STATE_FOCUSED_ROLL_OVER == m_curState || STATE_ROLL_OVER == m_curState);
		EButtonState state;
		state = (flagRollOver ? STATE_FOCUSED_ROLL_OVER : STATE_FOCUSED);
		if (IsEnabled() == false)
		{
			state = STATE_DISABLED_FOCUSED;
		}
		m_ChangeStateTo(state);

		return true;
	}

	bool CButton::OnFocusOut(IWidgetExtension* pWindow)
	{

		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::OnFocusOut().");

		bool flagRollOver = (STATE_FOCUSED_ROLL_OVER == m_curState || STATE_ROLL_OVER == m_curState);
		EButtonState state;
		state = (flagRollOver ? STATE_ROLL_OVER : STATE_NORMAL);
		if (IsEnabled() == false)
		{
			state = STATE_DISABLED;
		}
		m_ChangeStateTo(state);

		return true;
	}

	bool CButton::OnKeyPressed(IWidgetExtension* pThis, IKeyboardEvent* event)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::OnKeyPressed().");

		if (!m_flagEnabled)
		{
			return false;
		}
		int keyValue = event->GetKeyVal();

		if (keyValue == CLUTTER_KEY_Return)
		{
			m_ChangeStateTo(IButton::STATE_SELECTED);
			m_flagReturnKeyPressed = true;
		}
		return true;
	}

	bool CButton::OnKeyReleased(IWidgetExtension* pWindow, IKeyboardEvent* event)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::OnKeyReleased().");

		if (!m_flagEnabled)
		{
			return false;
		}
		int keyValue = event->GetKeyVal();

		if (keyValue == CLUTTER_KEY_Return)
		{
			EButtonState state;
			if (m_flagPointerIn)
			{
				state = STATE_FOCUSED_ROLL_OVER;
			}
			else
			{
				state = STATE_FOCUSED;
			}

			m_ChangeStateTo(state);
			if (m_flagReturnKeyPressed)
			{
				m_listenerSet->Process(EVENT_RETURN_KEY_CLICKED);
			}
			m_flagReturnKeyPressed = false;
		}
		return true;
	}

	void CButton::m_OnStateChange(void)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::m_OnStateChange() change state to " << m_curState);

		if (STATE_FOCUSED == m_curState && IsFocusEnabled() == false)
		{
			m_curState = STATE_NORMAL;
			m_OnStateChange();
			return;
		}

		CActor::SetBackgroundColor(m_stateData[m_curState].backgroundColor);

		setBorderColor(m_stateData[m_curState].borderColor);
		setBorderWidth(m_stateData[m_curState].borderWidth);

		if (m_backGroundImage != NULL)
		{
			if (!m_stateData[m_curState].backgroundImagePath.empty())
			{
				m_backGroundImage->SetImage(m_stateData[m_curState].backgroundImagePath.c_str());
				m_backGroundImage->Show();
			}
			else
			{
				m_backGroundImage->Hide();
			}
		}

		if (m_icon != NULL)
		{
			if (!m_stateData[m_curState].iconPath.empty())
			{
				m_icon->SetImage(m_stateData[m_curState].iconPath.c_str());
				m_icon->SetAlpha(m_stateData[m_curState].iconAlpha);
				m_icon->Show();
			}
			else
			{
				m_icon->Hide();
			}
		}

		if (m_text != NULL)
		{
			if (!m_stateData[m_curState].textContent.empty())
			{			
				m_text->SetFontSize(m_stateData[m_curState].fontSize);
				m_text->SetTextColor(m_stateData[m_curState].textColor);
				m_text->SetText(m_stateData[m_curState].textContent.c_str());
				m_text->Show();
			}
		}
	}

	void CButton::m_ChangeStateTo(EButtonState toState)
	{
		if (toState == m_curState || STATE_ALL == toState)
		{
			return;
		}
		m_curState = toState;
		m_OnStateChange();
	}

	void CButton::m_Initialize(void)
	{
		for (int i = 0; i < STATE_ALL; i++)
		{
			ClutterColor defaultBgColor = { 0, 0, 0, 0 };
			ClutterColor defaultTextColor = { 0, 0, 0, 255 };
			m_stateData[i].backgroundColor = defaultBgColor;
			m_stateData[i].textColor = defaultTextColor;
			m_stateData[i].iconAlpha = 255;
			m_stateData[i].fontSize = 20; //default font size set to 20
			m_stateData[i].borderColor = defaultBgColor;
			m_stateData[i].borderWidth = 0;
		}

		EnableFocus(true);
		AddMouseListener(this);
		AddFocusListener(this);
		AddKeyboardListener(this);
		//EnablePointerFocus(true);

		m_listenerSet = new CButtonListenerSet(this);
	}

	bool CButton::AddListener(IButtonListener* listener)
	{
		HALO_ASSERT(listener != NULL);

		return m_listenerSet->Add(listener);
	}

	bool CButton::RemoveListener(IButtonListener* listener)
	{
		HALO_ASSERT(listener != NULL);

		return m_listenerSet->Remove(listener);
	}

	bool CButton::IsFocusEnabled(void)
	{
		return t_flagFocusable;
	}

	IButton::EButtonState CButton::CurrentState(void)
	{
		return m_curState;
	}

	void CButton::SetCurrentState(EButtonState state)
	{
		m_ChangeStateTo(state);
	}

	void CButton::SetBorderColor(EButtonState state, const ClutterColor& color)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::SetBorderColor() to state: " << state << ", color: {r: " << color.red << ", g:" << color.green << ", b:" << color.blue << ", a:" << color.alpha << "}.");
		HALO_ASSERT(state <= STATE_ALL);

		if (state == STATE_ALL)
		{
			for (int i = 0; i < STATE_ALL; i++)
			{
				m_stateData[i].borderColor = color;
			}
		}
		else
		{
			m_stateData[state].borderColor = color;
		}

		if (state == STATE_ALL || state == m_curState)
		{
			setBorderColor(m_stateData[m_curState].borderColor);
		}
	}

	const ClutterColor& CButton::BorderColor(EButtonState state)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::BorderColor() of state: " << state);
		HALO_ASSERT(state <= STATE_ALL);

		return m_stateData[state].borderColor;
	}

	void CButton::SetBorderWidth(EButtonState state, float width)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::SetBorderWidth() to state: " << state << ", width: " << width);
		HALO_ASSERT(state <= STATE_ALL);

		if (state == STATE_ALL)
		{
			for (int i = 0; i < STATE_ALL; i++)
			{
				m_stateData[i].borderWidth = width;
			}
		}
		else
		{
			m_stateData[state].borderWidth = width;
		}

		if (state == STATE_ALL || state == m_curState)
		{
			setBorderWidth(m_stateData[m_curState].borderWidth);
		}
	}

	float CButton::BorderWidth(EButtonState state)
	{
		H_LOG_DEBUG(LOGGER, "[0x" << std::hex << this << "]CButton::BorderWidth() of state: " << state);
		HALO_ASSERT(state <= STATE_ALL);

		return m_stateData[state].borderWidth;
	}
}
