#ifndef _HALO_CRICHTEXT_H_
#define _HALO_CRICHTEXT_H_
//#include <list>

#ifndef WIN32
#define HAVE_ECORE_IMF
#endif

namespace HALO
{
	class CIMFContext;

	class TextData : public IData
	{
	public:
		TextData(void){};
		void Release(void);

		char* textContent;
		float height;
		int index;
		PangoAttrList* attrList;
		int alignment;
	};

	class TextRenderer : public IRenderer
	{
	public:
		TextRenderer(IActor* parent, class CRichText *owner);
		~TextRenderer();

		void Draw(IData *data, IActor* parent, E_DRAW_TYPE drawType);
		void Update(IData *data, IActor* parent) {};
		void Resize(IData *data, IActor* parent, ClutterSize destSize, bool flagAni, int animationDuration);
		CText* GetText(void);

	private:
		CText *m_text;
		class CRichText *m_owner;

		static void m_KeyFocusInCb(ClutterActor* actor, CActor *pOwner);
		static void m_KeyFocusOutCb(ClutterActor* actor, CActor *pThis);
	};

	class CRichText : virtual public IRichText, public CActor, public IMouseListener, public IKeyboardListener, public IFocusListener, public ISingleLineListControlListener, public IRendererProvider
	{
	public:



	public:
		CRichText();
		virtual ~CRichText();

		// Initial text.
		virtual bool Initialize(IActor *parent, float width, float height);
		virtual bool Initialize(Widget *parent, float width, float height);

		// Set the text editable.
		virtual void EnableEditable(bool flagEditable);

		// Get the text editable state.
 		virtual bool IsEditableEnabled(void);

		// Set the text multiline mode.
		virtual void EnableMultiLine(bool flagMutliLineMode);

		// Get the text multiline mode state.
		virtual bool IsMultiLineEnabled(void);

		// Set the text content.
		virtual void SetText(const char *text);

		// Get the text content.
		virtual const char* Text(void);

		// Set font by the name.
		virtual void SetFont(const char* fontName);

		// Get the text font.
		virtual const char* Font(void);

		// Set the font size.
		virtual void SetFontSize(int size);

		// Get the font size.
		virtual int FontSize(void);

		// Insert the text buffer at the cursor position
		virtual void InsertText(char *text);

		// Delete selection text by cursor and bound index
		virtual void DeleteText(void);

		// Set the text selectable.
		virtual void EnableSelectable(bool flagSelectable);

		// Get the text selectable state.
 		virtual bool IsSelectableEnabled(void);

		// Set the selection text boundary .
 		virtual void SetSelection(int startPos, int endPos);

		// Get the text buffer that is selected.
 		virtual char* Selection(void);

		// Set the selection text color.
 		virtual void SetSelectionColor(const ClutterColor color);

		// Get the selection text color.
		virtual const ClutterColor& SelectionColor(void);

		// Set text color.
		virtual void SetTextColor(const ClutterColor color);

		// Get the text color.
		virtual const ClutterColor& TextColor(void);

		// Set the text background color.
		virtual void SetBackgroundColor(const ClutterColor color);

		// Get the text background color.
		virtual const ClutterColor& BackgroundColor(void);

		// Set the cursor color.
 		virtual void SetCursorColor(const ClutterColor color);

		// Get the cursor color.
		virtual const ClutterColor& CursorColor(void);

		// Set the cursor position by the given value.
 		virtual void SetCursorPosition(int charIndex);

		// Get the cursor position.
 		virtual int CursorPosition(void);

		// Set the cursor width.
 		virtual void SetCursorWidth(int width);

		// Get the cursor width.
		virtual int CursorWidth(void);

		// Set highlight move mode, on or off.
		virtual void EnableHighlightMove(bool flagEnable);

		// Get whether highlight move mode is on or off.
		virtual bool IsHighlightMoveEnabled(void);

		// Set background color in highlight move mode.
		virtual void SetHighlightMoveBgColor(ClutterColor color);

		// Set background color in highlight move mode.
		virtual void SetHighlightMoveBgColor(int a, int r, int g, int b);

		// Get highlight move background color.
		virtual const ClutterColor& HighlightMoveBgColor(void);

		// Get highlight move background color.
		virtual void GetHighlightMoveBgColor(unsigned char& a, unsigned char& r, unsigned char& g, unsigned char& b);

		// Highlight move 4 directions.
		virtual void MoveHighlight(EDirection dir);

		// The cursor move function by app invoke.
		virtual void MoveCursor(EDirection dir);

		// Set the cursor blink interval value.
		virtual void SetCursorBlinkInterval(int interval);

		// Get the cursor blink interval value.
		virtual int CursorBlinkInterval(void);

		// Set border thickness.
		virtual void SetBorderThickness(int thickness);

		// Get border thickness.
		virtual int BorderThickness(void);

		// Copy the selection text.
		virtual void Copy(void);

		// Cut the selection text.
		virtual void Cut(void);

		// Paste the text that has been selected.
		virtual void Paste(void);

		// Open the file by the filepath.
		virtual bool OpenFile(const char *filePath);

		// Save the text to a file by the filepath.
		virtual bool SaveFile(const char *filePath);

		// Set char format of the selection range or current position.
		virtual bool SetCharFormat(ITCharFormat &cf);

		// Set paragraph format of the selection range or current position.
		virtual bool SetParagraphFormat(ITParaFormat& pf);

		// Set text alignment in single-line mode.
		virtual bool SetSingleLineTextAlignment(EHAlignment hAlign, EVAlignment vAlign);

		// Get text alignment in single-line mode.
		virtual bool GetSingleLineTextAlignment(EHAlignment& hAlign, EVAlignment& vAlign);

		// Set text max count in single-line mode.
		virtual void SetSingleLineTextMaxCount(int count);
		
		// Show actor.
		virtual void Show(void);

		// Event
		virtual bool OnKeyPressed(IActor* pThis, IKeyboardEvent* event);
		virtual bool OnKeyReleased(IActor* pThis, IKeyboardEvent* event);
		virtual bool OnMouseButtonPressed(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnMouseButtonReleased(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnMouseMoved(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnMousePointerIn(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnMousePointerOut(IActor* pWindow, IMouseEvent* ptrMouseEvent);
		virtual bool OnMouseWheel(IActor* pWindow, IMouseEvent* ptrMouseEvent);

		// Singlelinelist use
		IRenderer* GetRenderer(IData *data, IActor* parent);
		virtual bool OnItemLoaded(class ISingleLineListControl* list, IData *data, int itemIndex);
		virtual bool OnItemUnloaded(class ISingleLineListControl* list, IData *data, int itemIndex);
		virtual bool OnAsyncItemLoad(class ISingleLineListControl *list, IData *data, int itemIndex);

		// Internal use
		void RegisterCommonEventCallback(CText *text);
		void RegisterTextChangedEventCallback(CText *text);
		void CursorPositionInfo(int& indexPara, int& indexChar);
		void SetFontInfo(CText *text);

		// Update the text list char/para format
		void UpdateMultiLineTextFormat(CText* text, PangoAttrList* list, int alignment);

		virtual bool OnFocusIn(IActor* pWindow);
		virtual bool OnFocusOut(IActor* pWindow);
		
        void ResetCursorPosition(void);

		virtual const char* GetActorType(void);

		// Internal use, add / remove listener.
		bool AddStateChangedListener(IRichTextListener* listener);
		bool RemoveStateChangedListener(IRichTextListener* listener);

#ifdef HAVE_ECORE_IMF
		CIMFContext *GetIMFContext();
		//! Get IMData that user set to IME.
		void GetIMEData(void *data, void *len);
		//! Set IME layout.
		void SetIMEData(const char *imdata);
		//!Get IME enable param.
		bool IsIMFEnableOnFocus();
		//! Set IME shown on CRichText Foucs.
		void EnableIMFOnFocus(bool is_enable);
		//! Show IME panel.
		void ShowIMFContext();
		//! Hide IME panel.
		void HideIMFContext();
		//!Focus in IMF.
		void FocusInIMFContext();
		//!Focus out IMF.
		void FocusOutIMFContext();
#endif

	private:
		CText *m_text;							//for single line mode
		PangoAttrList* m_textAttrList;

		CSingleLineListControl *m_singleLine;	//for multi line mode
		char* m_getTextBuf;
		char* m_copyTextBuf;
		char* m_selectionTextBuf;
		char* m_fontName;
		int m_fontSize;
		bool m_focusChangeFlag;
		bool m_hasFocusOutFlag;
		bool m_focusWithOutGrab;

		PangoAttrList* m_pangoAttrList;
		PangoAttrList* m_pangoAttrListCopy;
		std::list<PangoAttrList*> m_pangoAttrListCopyList;
		bool m_copyEventFlag;

		bool m_enableEditable;
		bool m_enableMultiLine;
		bool m_enableSelectable;
		bool m_enableSelectablePreState;
		bool m_enableHighLight;
		int m_cursorPos;
		int m_cursorWidth;
		int m_cursorBlinkTimerID;
		int m_cursorBlinkInterval;
		int m_cursorColorAlpha;
		int m_borderThick;
		bool m_enableEditablePreHLState;
		
		ClutterColor m_textColor;
		ClutterColor m_backgroundColor;
		ClutterColor m_cursorColor;
		ClutterColor m_selectionColor;
		ClutterColor m_highlightColor;
		//! the mouse press state
		bool m_mousePressState;
		int m_cursorPositionParaIndex;
		int m_cursorPositionCharIndex;
		int m_boundPositionParaIndex;
		int m_boundPositionCharIndex;
		int m_pressPositionPara;
		int m_pressPositionChar;
		bool m_insertEventFlag;
		bool m_backspaceEventFlag;
		bool m_returnEventFlag;

		ClutterActor* m_canvasActor;
		ClutterContent *m_canvasContent;
		std::list<PangoRectangle> m_showRectList;
		int m_selectionDrawTimerID;
		
		typedef struct T_HIGHLIGHT_DATA
		{
			int indexPara;
			int indexCharStart;
			int indexCharEnd;
		}CTHighlightData;
		std::list<CTHighlightData> m_highlightData;
		int m_highlightMoveIndex;
		bool m_moveCursorBusyFlag;
		bool m_insertTextFlag;
		bool m_moveHighLightBusyFlag;

		std::set<IRichTextListener *> m_stateChangedlistener;

#ifdef HAVE_ECORE_IMF
		CIMFContext  *m_imf_context;
#endif
		static void m_KeyFocusInCb(ClutterActor* actor, CActor *pThis);
		static void m_KeyFocusOutCb(ClutterActor* actor, CActor *pThis);
		//! Key release event.
		static bool m_KeyReleaseEvent(ClutterActor *actor, ClutterEvent *event, gpointer user_data);
		// Key press event.
		static bool m_KeyPressEvent(ClutterActor *actor, ClutterEvent *event, gpointer user_data);
		// Mouse move event.
		static bool m_MouseMoveEvent(ClutterActor *actor, ClutterEvent *event, gpointer user_data);
		// Mouse press event.
		static bool m_MousePressEvent(ClutterActor *actor, ClutterEvent *event, gpointer user_data);
		// Mouse release event.
		static bool m_MouseReleaseEvent(ClutterActor *actor, ClutterEvent *event, gpointer user_data);
		// Text changed event.
		static void m_TextChangedEvent(ClutterText *self, gpointer user_data);
		// Cursor changed event.
		static void m_CursorChangedEvent(ClutterText *actor, gpointer user_data);
		// Delete text event.
		static void m_DeleteTextEvent(ClutterText *self, gint start_pos, gint end_pos, gpointer user_data);
		// Insert text event.
		static void m_InsertTextEvent(ClutterText *self, gchar *new_text, gint new_text_length, gint position, gpointer user_data);

		// Key press event.
		static gboolean m_KeyPressEventSingleLine(ClutterActor *actor, ClutterEvent *event, gpointer user_data);
		// Mouse move event.
		static gboolean m_MouseMoveEventSingleLine(ClutterActor *actor, ClutterEvent *event, gpointer user_data);
		// Mouse press event.
		static gboolean m_MousePressEventSingleLine(ClutterActor *actor, ClutterEvent *event, gpointer user_data);
		// Mouse release event.
		static gboolean m_MouseReleaseEventSingleLine(ClutterActor *actor, ClutterEvent *event, gpointer user_data);
		// Delete text event.
		static void m_DeleteTextEventSingleLine(ClutterText *self, gint start_pos, gint end_pos, gpointer user_data);
		// Insert text event.
		static void m_InsertTextEventSingleLine(ClutterText *self, gchar *new_text, gint new_text_length, gint position, gpointer user_data);

		// Update the special paragraph attribute list.
		void m_UpdateParagraphAttrList(PangoAttrList* attrlist, int cursorIndex, int insertTextLen, int deleteTextLen, int preLen);
		// Update a new paragraph attribute list that several paragraphs merge.
		void m_UpdateMergedParagraphAttrList(PangoAttrList* attrListH, PangoAttrList* attrListT, int cursorIndexHead, int cursorIndexTail, int insertTextLen);
		// Get the pango attribute list with selection.
		void m_GetSelectionPangoAttrList(void);
		// Insert attribute list.
		void m_InsertAttrList(PangoAttrList* attrList, PangoAttrList* insertList, int cursorIndex, int insertLen, bool splitFlag);
		//
		PangoAttrList* m_UpdateCharSelectFormat(PangoAttrList* attrList, int startIndex, int endIndex, PangoAttrType type, bool& res);

		// Update the selection text.
		void m_UpdateSelection(int& x, int& y);

		// Draw selection text by cairo.
		static gboolean m_PaintCanvas(ClutterCanvas *canvas, cairo_t *cr, int width, int height, gpointer user_data);

		// Invalidates the canvas by timer.
		static gboolean m_InvalidateSelection(gpointer data_);

		// The timer that the cursor blink
		static int m_CursorBlink(gpointer user_data);

		// Get the text item range show now
		void m_ShowItemRange(int& start, int& end);

		// Move the current para to show when change its content.
		void m_MoveCurrentParaToShow(int indexPara, int indexChar);

		// Draw selection.
		gboolean m_DrawSelection(ClutterCanvas *canvas, cairo_t *cr);

		// Draw highlight.
		gboolean m_DrawHighLight(ClutterCanvas *canvas, cairo_t *cr);

		// Initial singleline
		void m_InitialSingleLine(const char *text);

		// Release singleline
		void m_ReleaseSingleLine(void);

		// Initial multiline
		void m_InitialMultiLine(const char *text);

		// Release multiline
		void m_ReleaseMultiLine(void);

		// Update single line text format.
		void m_UpdateSingleLineTextFormat();

		// Get selection data info.
		void m_GetSelectionBoundData(int& startPara, int& startChar, int& endPara, int& endChar, int& selectionLen);

		// Set special paragraph get focus
		void m_SetParagraphFocus(ClutterText* text, int cursorPos, int boundPos);

		// State changed listener callback
		void m_StateChangedListenerCallBack(int keyval);

	};
} /* namespace HALO */
#endif /* _HALO_CRICHTEXT_H_ */
