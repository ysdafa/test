#include "Halo1_0.h"

#ifndef _CLISTITEM_H_
#define _CLISTITEM_H_

#define KEY_ENTER	65293
namespace HALO
{
	class CListItem: public virtual IListItem, public CActor 
	{
	public:
		CListItem(){};
		virtual ~CListItem();
		virtual bool Initialize(IActor* parent, float width, float height);
		void Enable(bool flagEnable);
		void LoadData();
		void UnLoadData();
		void SetIndex(int itemIndex);
		void SetItemImage(IImageBuffer *buffer , EListStateType statetype);
		void SetTitleText(const char* titleText , EListStateType statetype);
		void SetTitleTextFontSize(int fontSize , EListStateType statetype);
		void SetTitleTextFont(const char* titlefont , EListStateType statetype);
		void SetTitleTextColor(const ClutterColor color , EListStateType statetype);
		void ChangeStateTo(EListStateType toState);
		void SetStyle(TItemBaseAttr* attr , EListItemStyle itemStyle);
		void ResizeTitleText(float width, float height);
		void SetTitleTextPosition(float xpos, float ypos);
		void SetProgressValue(int value);
		
	private:
		struct CTStateData
		{
			CImageBuffer* imageBuffer;
			char* textContent;
			char* font;
			ClutterColor color;
		};
		void m_CreateUIElemenObj(TRect* rect , EListItemStyle itemStyle );
		void m_SetUIElemenAttr(TRect* rect , EListItemStyle itemStyle);

		
		void m_OnStateChange(void);

		CTStateData m_stateData[E_STATE_ALL];
		int m_curState;

	protected:
		float t_Width; 
		float t_Height;
		IText* t_TitleText;
		IImage* t_Image;
		std::vector <class CListItemDecorator*> t_UIElements;
		int t_itemIndex;
		void t_Initialize(IActor* parent, float width, float height);
		void t_LoadData();
		
	};

	class CExpandableListItem: public virtual IExpandableListItem, public CListItem, public IKeyboardListener ,  public IClickListener
	{
	public:
		bool Initialize(IActor* parent, float width, float height);
		CExpandableListItem(){};
		 ~CExpandableListItem();
		void CreateExpandableFlagImage(TRect rect);
		void SetExpandableFlagImageBuffer(IImageBuffer* imagebuffer , EExpandableType imageType);
		void SetExpandable(bool isExpandabled);
		bool IsExpandabled();
		void AddListener(ListItemListener* listener);
		void RemoveListener();
		void SetSingleLineListToItem(ISingleLineListControl* singlelinelist);
		virtual bool OnClicked(IWidgetExtension* pWindow, IEvent* pClickEvent);

		virtual bool OnKeyPressed(IWidgetExtension* pThis, IKeyboardEvent* event);
		
	private:
		bool m_Expandabled;
		IImageBuffer* m_OpenImageBuffer;
		IImageBuffer* m_ClosedImageBuffer;
		IImage* m_Image;
		ISingleLineListControl* m_SingleLineList;
		ListItemListener* m_listItemListener;
		IAction* m_action;
		CTransition *m_subListExpandAni;
		CTransition *m_alphaAni;
	private:
		void m_OpenItem();
		void m_CloseItem();
	};

	class CListSelectItem: public virtual IListSelectItem , public CListItem, public IKeyboardListener ,  public IClickListener
	{
	public:
		bool Initialize(IActor* parent, float width, float height);
		CListSelectItem(){};
		 ~CListSelectItem();
		void CreateSelectImage(TRect rect);
		void SetSelectImageBuffer(IImageBuffer* imagebuffer , ESelectType imageType);
		void AddListener(ListItemListener* listener);
		void RemoveListener();
		void SetCheck(bool isChecked);
		bool IsChecked();
		void LoadData();
		virtual bool OnClicked(IWidgetExtension* pWindow, IEvent* pClickEvent);

		virtual bool OnKeyPressed(IWidgetExtension* pThis, IKeyboardEvent* event);
	private:
		ListItemListener* m_listItemListener;
		IImage* m_Image;
		IImageBuffer* m_SelectedImageBuffer;
		IImageBuffer* m_UnSelectedImageBuffer;
		bool m_Selected;
		IAction* m_action;
	};
}
#endif 