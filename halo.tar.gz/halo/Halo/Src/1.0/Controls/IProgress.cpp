#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	IProgress* IProgress::CreateInstance(IActor* parent, float width, float height, EDirectionType direction)
	{
		CProgress* progress = dynamic_cast<CProgress*>(Instance::CreateInstance(CLASS_ID_IPROGRESS));
		ASSERT(progress != NULL);

		if(progress != NULL)
		{
			progress->Initialize(parent, width, height, direction);
		}	

		return progress;
	}

	IProgress* IProgress::CreateInstance(Widget* parent, float width, float height, EDirectionType direction)
	{
		CProgress* progress = dynamic_cast<CProgress*>(Instance::CreateInstance(CLASS_ID_IPROGRESS));
		ASSERT(progress != NULL);

		if (progress != NULL)
		{
			progress->Initialize(parent, width, height, direction);
		}

		return progress;
	}

}