#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{

	ISelectButton* ISelectButton::CreateInstance(IActor *parent , float width, float height)
	{
		CSelectButton* button = dynamic_cast<CSelectButton*>(Instance::CreateInstance(CLASS_ID_ISELECTBUTTON));

		if (NULL != button)
		{
			button->Initialize(parent , width , height);
		}

		return button;
	}
}