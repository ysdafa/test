#ifndef	_CLOADING_H_
#define	_CLOADING_H_

namespace HALO
{
	class CLoading : virtual public ILoading, public CActor
	{
	public:
		CLoading();
		virtual ~CLoading();

		virtual bool Initialize(IActor *parent ,const TLoadingAttr &attr);
		virtual bool Initialize(Widget *parent ,const TLoadingAttr &attr);
		virtual void Play(void);
		virtual void Pause(void);
		virtual void Stop(void);
		virtual void SetText(const std::string& text);
		virtual std::string Text(void) const;
		virtual void SetTextColor(const ClutterColor textcolor);
		virtual const ClutterColor& TextColor(void);
		virtual void SetTextFont(const std::string& font);
		virtual std::string TextFont(void) const;
		virtual void SetFontSize(int size);
		virtual int FontSize(void) const;
		virtual void SetFPS(int fps);
		virtual int FPS(void) const;
		virtual void SetGap(int gap);
		virtual int Gap(void) const;
		virtual const char* GetActorType(void);

	public:
		bool IsInitialized(void) const { return m_flagCreated; };
		bool IsPlaying(void);

	private:
		void m_InitAttr(const TLoadingAttr &attr);
		void m_InitImage(const char *path, char **name);
		void m_InitText(const char *text);
		void m_InitTimeline(void);
		void m_Destroy(void);

		static void m_StartCallback(ClutterTimeline *timeline, gpointer user_data);
		static void m_EndCallback(ClutterTimeline *timeline, gpointer user_data);
		static void m_MarkReachedCallback(ClutterTimeline *timeline, gchar *marker_name, gint msecs, gpointer user_data);
		
		typedef std::vector<guint> TimelineEventList;
		TimelineEventList m_timelineEvents;

		ClutterTimeline *m_timeLine;
		IImage *m_image;
		ILabel *m_text;
		char* m_imagePath;
		char** m_imageName;
		const char* m_fontName;
		int m_count;
		float m_x;
		float m_y;
		float m_imgWidth;
		float m_imgHeight;		
		float m_textWidth;
		float m_textHeight;	
		int m_fps;
		int m_fontSize;
		int m_gap;
		bool m_flagCreated;
		ClutterColor m_color;

	};
}



#endif