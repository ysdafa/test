#ifndef _HALO_CMATRIXLISTCONTORL_H_
#define _HALO_CMATRIXLISTCONTORL_H_

namespace HALO
{
	class CMatrixListControl : public IMatrixListControl, public CDataListControl
	{
	public:
		CMatrixListControl() {}
		~CMatrixListControl() {}

		virtual bool Initialize(IActor *parent, const TMatrixListControlAttr &attr);

		virtual void SetColumnTitleHeight(int height);

		IText *ColumnTitle(int column);
	public:
		bool OnDataChanged(EDataSourceListenerType type, int row, int col);
		virtual const char* GetActorType(void);

	protected:
		virtual void t_GetInMemoryItems(TRect lastVisibleArea, TRect visibleArea, std::vector<TItem*> &loadItem, std::vector<TItem*> &unloadItem, std::vector<TItem*> &scrollItem, int reason = -1);
		virtual void t_OnItemGroupScrollStart(void);
		virtual void t_OnItemGroupScrollEnd(void);

		virtual void t_GetItemWindowPivotPoint(TItem *item, float &pivotX, float &pivotY, float &pivotZ);

		virtual void t_OnItemDataUnload(TItem *item);
		virtual void t_OnItemDataSyncLoad(TItem *item);
		virtual void t_OnItemDataAsyncLoad(TItem *item);

		virtual void t_FocusChangeStart(const TItem *from, const TItem *to);
		virtual void t_FocusChangeFinish(const TItem *from, const TItem *to);

		//The item in memory only scrolled, not loaded or unloaded.
		virtual void t_OnItemInMemoryScrolled(TItem *item);

		virtual TValue2f t_GetRealPointBaseItemGroup(TRect rect, TRect baseOnRect);
		virtual TValue2f t_GetLogicalPosition(TRect rect, TRect baseOnRect);

		virtual TRect t_InitRectOfLoadingItem(TItem *item, int reason);

		virtual bool t_CreateDerivedObject(CActor *parent, TDataListControlAttr *attr) { return false; }
		virtual void t_DestroyDerivedObject(void) { }
		virtual bool t_MoveFocusBar(EDirection direction);

		virtual void t_BindDataListToItemList(void);
		void t_OnMousePointerIn(TItem* item){}
	private:

	};
}

#endif // !_HALO_CMATRIXLISTCONTORL_H_
