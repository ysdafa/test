#include "Halo1_0.h"

namespace HALO
{
	bool CMatrixListControl::Initialize(IActor *parent, const TMatrixListControlAttr &attr)
	{
		CDataListControl::Initialize(parent, attr);

		return true;
	}

	void CMatrixListControl::SetColumnTitleHeight(int height)                                
	{

	}

	IText *CMatrixListControl::ColumnTitle(int column)
	{
		return NULL;
	}

	bool CMatrixListControl::OnDataChanged(EDataSourceListenerType type, int row, int col)
	{
		return true;
	}

	const char* CMatrixListControl::GetActorType(void)
	{
		return "MatrixListControl";
	}
	
	void CMatrixListControl::t_GetInMemoryItems(TRect lastVisibleArea, TRect visibleArea, std::vector<TItem*> &loadItem, std::vector<TItem*> &unloadItem, std::vector<TItem*> &noChangeItem, int reason /*= -1*/)
	{

	}

	void CMatrixListControl::t_OnItemGroupScrollStart(void)
	{

	}

	void CMatrixListControl::t_OnItemGroupScrollEnd(void)
	{

	}

	void CMatrixListControl::t_GetItemWindowPivotPoint(TItem *item, float &pivotX, float &pivotY, float &pivotZ)
	{
		pivotX = pivotY = pivotZ = 0.0f;
	}

	void CMatrixListControl::t_OnItemDataUnload(TItem *item)
	{

	}

	void CMatrixListControl::t_OnItemDataSyncLoad(TItem *item)
	{

	}

	void CMatrixListControl::t_OnItemDataAsyncLoad(TItem *item)
	{

	}

	void CMatrixListControl::t_FocusChangeStart(const TItem *from, const TItem *to)
	{

	}

	void CMatrixListControl::t_FocusChangeFinish(const TItem *from, const TItem *to)
	{

	}

	void CMatrixListControl::t_OnItemInMemoryScrolled(TItem *item)
	{

	}

	TValue2f CMatrixListControl::t_GetRealPointBaseItemGroup(TRect rect, TRect baseOnRect)
	{
		TValue2f point;

		return point;
	}

	TValue2f CMatrixListControl::t_GetLogicalPosition(TRect rect, TRect baseOnRect)
	{
		TValue2f point(rect.x, rect.y);
		return point;
	}

	TRect CMatrixListControl::t_InitRectOfLoadingItem(TItem *item, int reason)
	{
		return item->rect;
	}

	bool CMatrixListControl::t_MoveFocusBar(EDirection direction)
	{
		return true;
	}

	void CMatrixListControl::t_BindDataListToItemList(void)
	{

	}

}
