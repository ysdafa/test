#include "Halo1_0.h"
#include <iterator>
static HALO::util::Logger LOGGER("GridListControl");

#define ASSERT_RETURN(condition, returnVal) ASSERT(condition); if (false == (condition)) return returnVal;

namespace HALO
{
	class CGridListControlListenerSet : public ListenerSet
	{
	public:
		struct TGridListListenerData
		{
			int type;
			int param[4];
			void* pData;
		};

		CGridListControlListenerSet(CGridListControl* owner) :m_owner(owner){};
		virtual ~CGridListControlListenerSet(void){};

		virtual bool Process(TGridListListenerData* data);

	private:
		CGridListControl* m_owner;
	};

	bool CGridListControlListenerSet::Process(TGridListListenerData* data)
	{
		bool ret = false;

		if (NULL != data)
		{
			ListenerList::iterator iter = m_list.begin();

			while (iter != m_list.end())
			{
				IGridListControlListener* listener = (IGridListControlListener*)(*iter);

				switch (data->type)
				{
				case CGridListControl::EVENT_FOCUS_CHANGE:
					H_LOG_DEBUG(LOGGER, "[0x" << std::hex << m_owner << "]CGridListControl::EVENT_FOCUS_CHANGE (" << data->param[0] << "," << data->param[1] << "," << data->param[2] << "," << data->param[3] << ")Listener--start");
					ret |= listener->OnFocusChanged(m_owner, data->param[0], data->param[1], data->param[2], data->param[3]);
					H_LOG_DEBUG(LOGGER, "CGridListControl::EVENT_FOCUS_CHANGE Listener--end");
					break;
				case CGridListControl::EVENT_FOCUS_CHANGE_MOTION_START:
					H_LOG_DEBUG(LOGGER, "[0x" << std::hex << m_owner << "]CGridListControl::EVENT_FOCUS_CHANGE_MOTION_START (" << data->param[0] << "," << data->param[1] << "," << data->param[2] << "," << data->param[3] << ")Listener--start");
					ret |= listener->OnFocusChangeMotionStart(m_owner, data->param[0], data->param[1], data->param[2], data->param[3]);
					H_LOG_DEBUG(LOGGER, "CGridListControl::EVENT_FOCUS_CHANGE_MOTION_START Listener--end");
					break;
				case CGridListControl::EVENT_ITEM_LOAD:
					H_LOG_DEBUG(LOGGER, "[0x" << std::hex << m_owner << "]CGridListControl::EVENT_ITEM_LOAD (" << data->param[0] << "," << data->param[1] << ")Listener--start");
					ret |= listener->OnItemLoaded(m_owner, data->param[0], data->param[1]);
					H_LOG_DEBUG(LOGGER, "CGridListControl::EVENT_ITEM_LOAD Listener--end");
					break;
				case CGridListControl::EVENT_ITEM_ASYNC_LOAD:
					H_LOG_DEBUG(LOGGER, "[0x" << std::hex << m_owner << "]CGridListControl::EVENT_ITEM_ASYNC_LOAD (" << data->param[0] << "," << data->param[1] << ")Listener--start");
					ret |= listener->OnAsyncItemLoad(m_owner, data->param[0], data->param[1]);
					H_LOG_DEBUG(LOGGER, "CGridListControl::EVENT_ITEM_ASYNC_LOAD Listener--end");
					break;
				case CGridListControl::EVENT_ITEM_UNLOAD:
					H_LOG_DEBUG(LOGGER, "[0x" << std::hex << m_owner << "]CGridListControl::EVENT_ITEM_UNLOAD (" << data->param[0] << "," << data->param[1] << ")Listener--start");
					ret |= listener->OnItemUnloaded(m_owner, data->param[0], data->param[1]);
					H_LOG_DEBUG(LOGGER, "CGridListControl::EVENT_ITEM_UNLOAD Listener--end");
					break;
				case CGridListControl::EVENT_ITEM_INDEX_CHANGE:
					H_LOG_DEBUG(LOGGER, "[0x" << std::hex << m_owner << "]CGridListControl::EVENT_ITEM_INDEX_CHANGE (" << data->param[0] << "," << data->param[1] << "," << data->param[2] << "," << data->param[3] << ")Listener--start");
					ret |= listener->OnItemIndexChanged(m_owner, data->param[0], data->param[1], data->param[2], data->param[3]);
					H_LOG_DEBUG(LOGGER, "CGridListControl::EVENT_ITEM_INDEX_CHANGE Listener--end");
					break;
				case CGridListControl::EVENT_MOVE_OUT:
					H_LOG_DEBUG(LOGGER, "[0x" << std::hex << m_owner << "]CGridListControl::EVENT_MOVE_OUT (" << data->param[0] << "," << data->param[1] << ")Listener--start");
					ret |= listener->OnMoveOut(m_owner, (EDirection)data->param[0], data->param[1], data->param[2]);
					H_LOG_DEBUG(LOGGER, "CGridListControl::EVENT_MOVE_OUT Listener--end");
					break;

				case CGridListControl::EVENT_ITEM_CLICKED:
					H_LOG_DEBUG(LOGGER, "[0x" << std::hex << m_owner << "]CGridListControl::EVENT_ITEM_CLICKED (" << data->param[0] << "," << data->param[1] << ")Listener--start");
					ret |= listener->OnItemClicked(m_owner, data->param[0], data->param[1]);
					H_LOG_DEBUG(LOGGER, "CGridListControl::EVENT_ITEM_CLICKED Listener--end");
					break;

				case CGridListControl::EVENT_ENTER_KEY_LONG_PRESSED:
					H_LOG_DEBUG(LOGGER, "[0x" << std::hex << m_owner << "]CGridListControl::EVENT_ENTER_KEY_LONG_PRESSED (" << data->param[0] << "," << data->param[1] << ")Listener--start");
					ret |= listener->OnEnterKeyLongPressed(m_owner, data->param[0], data->param[1]);
					H_LOG_DEBUG(LOGGER, "CGridListControl::EVENT_ENTER_KEY_LONG_PRESSED Listener--end");
					break;

				default:
					break;
				}
				iter++;
			}
		}

		return ret;
	}

	CGridListControl::CGridListControl(void) : m_dataSource(NULL), m_flagRightToLeft(false), m_titleSpace(0), m_groupSpace(0), m_cellSpace(0)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::CGridListControl!");

		m_focusRangeOffset[0] = m_focusRangeOffset[1] = 0;
		m_focusGroupIndex = 0;
		m_focusItemIndex = 0;
		m_onScreenRange.startGroupIndex = -1;
		m_onScreenRange.startColumnIndex = -1;
		m_onScreenRange.endGroupIndex = -1;
		m_onScreenRange.endColumnIndex = -1;
		m_focusItemChangedFlag = false;

		m_dragItemIndex = -1;
		m_dropItemIndex = -1;

		m_flagItemDraged = false;
		m_flagUseMarginWhenFocusEdgeItem = true;

		m_flagStraightPath = true;

		m_flagRolloverEffect = false;

		m_leftBufferColumnNum = m_rightBufferColumnNum = 1;

		m_refXForFocusMoving = -1;
		m_refYForFocusMoving = -1;

		m_scrollDirectionType = TYPE_HORIZONTAL;

		m_aniInfoList[ANITYPE_STYLE_TRANS].duration = 330;

		m_timerId = -1;

		m_timerInterval = 1000;
	}

	CGridListControl::~CGridListControl(void)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::~CGridListControl!");

		delete m_dataSource;
		delete m_listenerSet;

		for (int i = 0; i < (int)m_groupList.size(); i++)
		{
			TGroup* group = m_groupList.at(i);
			delete group;
		}

		if (NULL != m_dragItemTrans)
		{
			m_dragItemTrans->Release();
		}

		if (NULL != m_itemScaleTrans)
		{
			m_itemScaleTrans->Release();
		}

		m_groupList.clear();

		StopScrollTimer();
	}


	bool CGridListControl::Initialize(IActor *parent, const TGridListControlAttr &attr)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::Initialize with IActor parent");
		ASSERT(attr.titleSpace >= 0 && attr.groupSpace >= 0 && attr.cellSpace >= 0 && attr.focusRangeOffset[0] >= 0 && attr.focusRangeOffset[1] >= 0);

		Widget *parentWidget = dynamic_cast<Widget*>(parent);
		return Initialize(parentWidget, attr);
	}

	bool CGridListControl::Initialize(Widget *parent, const TGridListControlAttr &attr)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::Initialize with Widget parent");
		ASSERT(attr.titleSpace >= 0 && attr.groupSpace >= 0 && attr.cellSpace >= 0 && attr.focusRangeOffset[0] >= 0 && attr.focusRangeOffset[1] >= 0);

		t_Initialize(parent, attr);

		m_scrollDirectionType = attr.directionType;

		m_titleSpace = attr.titleSpace;
		m_groupSpace = attr.groupSpace;
		m_cellSpace = attr.cellSpace;
		m_focusRangeOffset[0] = attr.focusRangeOffset[0];
		m_focusRangeOffset[1] = attr.focusRangeOffset[1];
		t_focusRangeRect.Set(m_focusRangeOffset[0], 0.0f, t_listWidth - m_focusRangeOffset[0] - m_focusRangeOffset[1], t_listHeight);
		m_dataSource = new CGridDataSource();

		m_listenerSet = new class CGridListControlListenerSet(this);

		m_canMove = false;
		m_isSunken = false;

		m_dragItemTrans = new CMultiObjectTransition;
		m_dragItemTrans->Initialize();
		t_RegisterMultiObjTransition(m_dragItemTrans, ITEM_POSITION_TRANS | ITEM_SIZE_TRANS | ITEM_SCALEX_TRANS | ITEM_SCALEY_TRANS);

		m_itemScaleTrans = new CMultiObjectTransition;
		m_itemScaleTrans->Initialize();
		m_itemScaleTrans->SetDuration(200);
		t_RegisterMultiObjTransition(m_itemScaleTrans, ITEM_SCALEX_TRANS | ITEM_SCALEY_TRANS);

		t_SetLoopAniDuration(300);

		return true;
	}

	IGridDataSource * CGridListControl::DataSource(void)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::DataSource");
		return m_dataSource;
	}

	void CGridListControl::AddGroup(int numberOfGroup)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::AddGroup with number " << numberOfGroup);
		ASSERT(numberOfGroup > 0);

		for (int i = 0; i < numberOfGroup; i++)
		{
			TGroup* newGroup = new TGroup;
			newGroup->currentStyle = -1;//default style index of group is 0
			newGroup->lastStyle = -1;
			newGroup->title = IActor::CreateInstance(t_itemGroup, 0, 0);
			if (newGroup->title != NULL)
			{
				newGroup->title->Show();
			}
			m_groupList.push_back(newGroup);
		}
	}

	bool CGridListControl::AddStyleToAllGroup(int numOfStyle)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::AddStyleToAllGroup with number " << numOfStyle);
		ASSERT(numOfStyle > 0);

		for (int i = 0; i < (int)m_groupList.size(); i++)
		{
			TGroup* group = m_groupList.at(i);
			group->currentStyle = 0;
			for (int j = 0; j < numOfStyle; j++)
			{
				TStyle *newStyle = new TStyle;
				newStyle->styleIndex = group->styleList.size();

				if (TYPE_VERTICAL == m_scrollDirectionType)
				{
					newStyle->startPos = newStyle->endPos = i * m_groupSpace + (i + 1) * m_titleSpace;
				}
				else
				{
					newStyle->startPos = newStyle->endPos = i * m_groupSpace;
				}

				group->styleList.push_back(newStyle);
			}
		}
		return true;
	}

	int CGridListControl::CurrentStyle(void)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::CurrentStyle");
		ASSERT(m_groupList.size() > 0);
		return m_groupList.at(0)->currentStyle;
	}

	int CGridListControl::AddColumn(int groupIndex, int styleIndex, float columnWidth)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::AddColumn to group: " << groupIndex << ", style: " << styleIndex << ", with width: " << columnWidth);
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		ASSERT(styleIndex >= 0 && styleIndex < (int)m_groupList.at(groupIndex)->styleList.size());

		float columnSpace = columnWidth;

		if (TYPE_VERTICAL == m_scrollDirectionType)
		{
			ASSERT(columnSpace > 0 && columnSpace <= t_listHeight);
		}
		else
		{
			ASSERT(columnSpace > 0 && columnSpace <= t_listWidth);
		}

		TStyle *style = m_groupList.at(groupIndex)->styleList.at(styleIndex);
		TColumn* newColumn = new TColumn;
		newColumn->space = columnSpace;
		newColumn->indexInGroup = style->columnList.size();

		if (TYPE_VERTICAL == m_scrollDirectionType)
		{
			newColumn->usedLength = 0;
		}
		else
		{
			newColumn->usedLength = m_titleSpace;
		}
		//newColumn->indexInList = -1;//reset before load data.

		if (0 == newColumn->indexInGroup)
		{
			newColumn->startPos = style->startPos;
		}
		else
		{
			TColumn *lastColumn = style->columnList.back();
			newColumn->startPos = lastColumn->endPos + m_cellSpace;
		}

		newColumn->endPos = newColumn->startPos + columnSpace;
		style->columnList.push_back(newColumn);

		//reset position of all the groups from current group to the last.
		float positionOffset = (0 == newColumn->indexInGroup) ? columnSpace : columnSpace + m_cellSpace;

		style->endPos += positionOffset; //current group only need to reset end position

		for (int i = groupIndex + 1; i < (int)m_groupList.size(); i++)
		{
			m_groupList.at(i)->styleList.at(styleIndex)->ResetPosition(positionOffset);
		}

		return newColumn->indexInGroup;
	}

	bool CGridListControl::AddRowToColumn(int groupIndex, int styleIndex, int columnIndex, float rowHeight)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::AddRowToColumn to group: " << groupIndex << ", style: " << styleIndex << ", column: " << columnIndex << ", with height: " << rowHeight);
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		ASSERT(styleIndex >= 0 && styleIndex < (int)m_groupList[groupIndex]->styleList.size());
		ASSERT(columnIndex >= 0 && columnIndex < (int)m_groupList[groupIndex]->styleList[styleIndex]->columnList.size());

		if (TYPE_HORIZONTAL == m_scrollDirectionType)
		{
			ASSERT(rowHeight > 0 && rowHeight <= t_listHeight);
		}
		else
		{
			ASSERT(rowHeight > 0 && rowHeight <= t_listWidth);
		}

		m_AddRowToColumn(groupIndex, styleIndex, columnIndex, rowHeight);

		return true;
	}

	bool CGridListControl::AddRowToAllColumn(int groupIndex, int styleIndex, float rowHeight)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::AddRowToAllColumn to group: " << groupIndex << ", style: " << styleIndex << ", with height: " << rowHeight);
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		ASSERT(styleIndex >= 0 && styleIndex < (int)m_groupList[groupIndex]->styleList.size());
		
		if (TYPE_HORIZONTAL == m_scrollDirectionType)
		{
			ASSERT(rowHeight > 0 && rowHeight <= t_listHeight);
		}
		else
		{
			ASSERT(rowHeight > 0 && rowHeight <= t_listWidth);
		}

		TStyle *style = m_groupList.at(groupIndex)->styleList.at(styleIndex);

		for (int i = 0; i < (int)style->columnList.size(); i++)
		{
			m_AddRowToColumn(groupIndex, styleIndex, i, rowHeight);
		}

		return true;
	}

	bool CGridListControl::MergeCells(int groupIndex, int styleIndex, int startRow, int startCol, int endRow, int endCol)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::MergeCells in group: " << groupIndex << ", style: " << styleIndex << ", fromRow: " << startRow << ", fromColumn: " << startCol << ", toRow: " << endRow << ", toColumn: " << endCol);
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		TGroup* group = m_groupList.at(groupIndex);

		ASSERT(styleIndex >= 0 && styleIndex < (int)group->styleList.size());
		TStyle* style = group->styleList.at(styleIndex);

		ASSERT((startCol < endCol && startRow < endRow) || (startCol == endCol && startRow < endRow) || (startRow == endRow && startCol < endCol));

		ASSERT(startCol >= 0 && startCol < (int)style->columnList.size());
		TColumn* startColumn = style->columnList.at(startCol);
		ASSERT(startRow >= 0 && startRow < (int)startColumn->cellList.size());

		ASSERT(endCol >= 0 && endCol < (int)style->columnList.size());
		TColumn* endColumn = style->columnList.at(endCol);
		ASSERT(endRow >= 0 && endRow < (int)endColumn->cellList.size());

		for (int i = startCol; i <= endCol; i++)
		{
			for (int j = startRow; j < endRow; j++)
			{
				TCell* cell = style->columnList[i]->cellList[j];
				ASSERT(cell->mergeState == STATE_NORMAL);
			}			
		}

		//check if the cells can be merged.
		TCell* startColTopCell = startColumn->cellList.at(startRow);
		if (startCol != endCol)
		{
			//check the top of the start row cells are the same.
			if (TYPE_VERTICAL == m_scrollDirectionType)
			{
				float topX = startColTopCell->rect.x;
				for (int i = startCol + 1; i <= endCol; i++)
				{
					TColumn* column = style->columnList.at(i);
					ASSERT(startRow < (int)column->cellList.size());
					TCell* cell = column->cellList.at(startRow);
					ASSERT(cell->rect.x == topX);
				}
				//check the bottom of the end row cells are the same.
				TCell* endColBottomCell = endColumn->cellList.at(endRow);
				float bottomX = endColBottomCell->rect.x + endColBottomCell->rect.w;
				for (int i = startCol; i < endCol; i++)
				{
					TColumn* column = style->columnList.at(i);
					ASSERT(endRow < (int)column->cellList.size());
					TCell* cell = column->cellList.at(endRow);
					ASSERT(cell->rect.x + cell->rect.w == bottomX);
				}
			}
			else
			{
				float topY = startColTopCell->rect.y;
				for (int i = startCol + 1; i <= endCol; i++)
				{
					TColumn* column = style->columnList.at(i);
					ASSERT(startRow < (int)column->cellList.size());
					TCell* cell = column->cellList.at(startRow);
					ASSERT(cell->rect.y == topY);
				}
				//check the bottom of the end row cells are the same.
				TCell* endColBottomCell = endColumn->cellList.at(endRow);
				float bottomY = endColBottomCell->rect.y + endColBottomCell->rect.h;
				for (int i = startCol; i < endCol; i++)
				{
					TColumn* column = style->columnList.at(i);
					ASSERT(endRow < (int)column->cellList.size());
					TCell* cell = column->cellList.at(endRow);
					ASSERT(cell->rect.y + cell->rect.h == bottomY);
				}
			}
		}

		//resize merged cell
		for (int i = startCol + 1; i <= endCol; i++)
		{
			if (TYPE_VERTICAL == m_scrollDirectionType)
			{
				startColTopCell->rect.h += style->columnList.at(i)->space;
			}
			else
			{
				startColTopCell->rect.w += style->columnList.at(i)->space;
			}
		}
		for (int i = startRow + 1; i <= endRow; i++)
		{
			if (TYPE_VERTICAL == m_scrollDirectionType)
			{
				startColTopCell->rect.w += startColumn->cellList.at(i)->rect.w;
			}
			else
			{
				startColTopCell->rect.h += startColumn->cellList.at(i)->rect.h;
			}
		}

		//set all the hidden cells state
		for (int i = startCol; i <= endCol; i++)
		{
			TColumn* column = style->columnList.at(i);

			for (int j = startRow; j <= endRow; j++)
			{
				TCell* cell = column->cellList.at(j);
				if (i == startCol && j == startRow)
				{
					cell->mergeState = STATE_MERGE_RESIZE;
					cell->fromColumnIndex = startCol;
					cell->fromRowIndex = startRow;
					cell->toColumnIndex = endCol;
					cell->toRowIndex = endRow;
				}
				else
				{
					cell->mergeState = STATE_MERGE_HIDDEN;
					cell->fromColumnIndex = startCol;
					cell->fromRowIndex = startRow;
					cell->toColumnIndex = endCol;
					cell->toRowIndex = endRow;
				}
			}
		}

		return true;
	}

	bool CGridListControl::SetStyle(int styleIndex)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::SetStyle to index: " << styleIndex);
		ASSERT(m_groupList.size() > 0);
		ASSERT(styleIndex >= 0 && styleIndex < (int)m_groupList.at(0)->styleList.size());

		TGroup *group = m_groupList.at(0);

		if (styleIndex == group->currentStyle)
		{
			return false;
		}

		for (int i = 0; i < (int)m_groupList.size(); i++)
		{
			TGroup *group = m_groupList.at(i);
			group->currentStyle = styleIndex;
			TStyle* style = group->styleList.at(group->currentStyle);
			TRect titleRect;
			titleRect.Set(style->startPos, 0.0f, 0.0f, 0.0f);
			TValue2f realValue = t_GetRealPointBaseItemGroup(titleRect, t_itemGroupRect);
			group->title->SetPosition(realValue.val[0], realValue.val[1]);
		}

		return true;
	}

	void CGridListControl::TransformStyle(int toStyleIndex)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::TransformStyle to style index: " << toStyleIndex);

		for (int i = 0; i < (int)m_groupList.size(); i++)
		{
			TGroup* group = m_groupList.at(i);
			ASSERT(toStyleIndex >= 0 && toStyleIndex < (int)group->styleList.size());
			if (toStyleIndex == group->currentStyle)
			{
				return;
			}
		}

		if (true == m_flagItemDraged)
		{
			return;
		}

		if (true == t_IsOnAnimation(LIST_ANI_TYPE_MAX))
		{
			return;
		}

		int lastStyle = m_groupList[0]->currentStyle;

		//reset group's current and last style index.
		for (int i = 0; i < (int)m_groupList.size(); i++)
		{
			TGroup* group = m_groupList.at(i);
			group->lastStyle = group->currentStyle;
			group->currentStyle = toStyleIndex;
		}

		TGroup* focusGroup = m_groupList[m_focusGroupIndex];
		TStyle* focusGroupStyle = focusGroup->styleList[focusGroup->currentStyle];

		TRect curFocusRect = focusGroup->itemList[m_focusItemIndex]->rect;

		int newStyleItemCount = HALO_MIN(focusGroupStyle->rectList.size(), focusGroup->itemList.size());
		if (newStyleItemCount - 1 < m_focusItemIndex)//if destination style has less items to keep focused item index unchanged, set focus to last item
		{
			m_focusItemIndex = newStyleItemCount - 1;
			H_LOG_WARN(LOGGER, "When transform style, focus item index changed to " << m_focusItemIndex);
			m_focusItemChangedFlag = true;
		}
		TRect nextFocusRect = focusGroupStyle->rectList[m_focusItemIndex];

		TGroup* lastGroup = m_groupList.back();
		TStyle* lastGroupStyle = lastGroup->styleList[toStyleIndex];
		TRect lastRect = lastGroupStyle->rectList[HALO_MIN(m_groupList.back()->itemList.size() - 1, lastGroupStyle->rectList.size() - 1)];

		TRect destItemGroupRect;

		if (TYPE_VERTICAL == m_scrollDirectionType)
		{
			destItemGroupRect.y = t_itemGroupRect.y + curFocusRect.y - nextFocusRect.y;
			destItemGroupRect.x = t_itemGroupRect.x;
			destItemGroupRect.h = lastRect.y + lastRect.h;
			destItemGroupRect.w = t_listWidth;

			if (destItemGroupRect.y >= 0.0f)
			{
				destItemGroupRect.y = 0.0f;
			}
			else
			{
				if (destItemGroupRect.y + lastRect.y + lastRect.h < t_listHeight)
				{
					if (lastRect.y + lastRect.h >= t_listHeight)
					{
						destItemGroupRect.y = t_listHeight - lastRect.y - lastRect.h;
					}
					else
					{
						destItemGroupRect.y = 0.0f;
					}
				}
				else if (destItemGroupRect.y + nextFocusRect.y + nextFocusRect.h > t_listHeight)
				{
					destItemGroupRect.y = t_listHeight - nextFocusRect.y - nextFocusRect.h;
				}
			}
		}
		else
		{
			destItemGroupRect.x = t_itemGroupRect.x + curFocusRect.x - nextFocusRect.x;
			destItemGroupRect.y = t_itemGroupRect.y;
			destItemGroupRect.w = lastRect.x + lastRect.w;
			destItemGroupRect.h = t_listHeight;

			if (destItemGroupRect.x >= 0.0f)
			{
				destItemGroupRect.x = 0.0f;
			}
			else
			{
				if (destItemGroupRect.x + lastRect.x + lastRect.w < t_listWidth)
				{
					if (lastRect.x + lastRect.w >= t_listWidth)
					{
						destItemGroupRect.x = t_listWidth - lastRect.x - lastRect.w;
					}
					else
					{
						destItemGroupRect.x = 0.0f;
					}
				}
				else if (destItemGroupRect.x + nextFocusRect.x + nextFocusRect.w > t_listWidth)
				{
					destItemGroupRect.x = t_listWidth - nextFocusRect.x - nextFocusRect.w;
				}
			}
		}

		std::vector<TItem*> itemList;
		std::vector<TRect> rectList;
		float itemRadiusSum = 0.0f;
		for (int i = 0; i < (int)m_groupList.size(); i++)
		{
			TGroup* group = m_groupList.at(i);
			TStyle* style = group->styleList.at(group->currentStyle);
			size_t itemCount = HALO_MIN(style->rectList.size(), group->itemList.size());
			for (size_t j = 0; j < itemCount; ++j)
			{
				TGridListItem* item = group->itemList[j];
				itemList.push_back(item);
				TRect rect = style->rectList[j];
				rectList.push_back(rect);
				item->radius = HALO_MIN(rect.w, rect.h) / 2;
				itemRadiusSum += item->radius;
			}
		}
		t_cursorRadius = itemRadiusSum / itemList.size();

		for (int i = 0; i < (int)m_groupList.size(); i++)
		{
			TGroup* group = m_groupList.at(i);

			float w, h;
			group->title->GetSize(w, h);

			TRect titleRect;

			if (TYPE_VERTICAL == m_scrollDirectionType)
			{
				titleRect.Set(0.0f, group->styleList[toStyleIndex]->startPos - m_titleSpace, w, h);
			}
			else
			{
				titleRect.Set(group->styleList[toStyleIndex]->startPos, 0.0f, w, h);
			}

			TValue2f realValue = t_GetRealPointBaseItemGroup(titleRect, destItemGroupRect);
			group->title->SetPosition(realValue.val[0], realValue.val[1]);
		}

		t_TransformLayout(lastStyle, toStyleIndex, itemList, rectList, destItemGroupRect, STYLE_ANIMATION);
	}

	bool CGridListControl::AddListListener(IGridListControlListener *listener)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::AddListListener");
		ASSERT(listener != NULL);

		return m_listenerSet->Add(listener);
	}

	bool CGridListControl::RemoveListListener(IGridListControlListener* listener)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::RemoveListListener");
		ASSERT(listener != NULL);

		return m_listenerSet->Remove(listener);
	}

	void CGridListControl::AttachGroupTitle(int groupIndex, IText* titleActor)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::AttachGroupTitle to group: " << groupIndex << ", with titleActor [0x" << std::hex << titleActor << "]");
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		ASSERT(titleActor != NULL);

		titleActor->SetParent(m_groupList[groupIndex]->title);

		float w, h;
		titleActor->GetSize(w, h);

		TRect titleRect;
		if (TYPE_VERTICAL == m_scrollDirectionType)
		{
			titleRect.Set(0.0f, m_groupList[groupIndex]->styleList[m_groupList[groupIndex]->currentStyle]->startPos - m_titleSpace, w, h);

			t_focusRangeRect.Set(0.0f, m_titleSpace, t_listWidth, t_listHeight - m_titleSpace);
		}
		else
		{
			titleRect.Set(m_groupList[groupIndex]->styleList[m_groupList[groupIndex]->currentStyle]->startPos, 0.0f, w, h);
		}

		m_groupList[groupIndex]->title->Resize(w, h);

		TValue2f realValue = t_GetRealPointBaseItemGroup(titleRect, t_itemGroupRect);
		m_groupList[groupIndex]->title->SetPosition(realValue.val[0], realValue.val[1]);
	}

	void CGridListControl::AttachGroupTitle(int groupIndex, Widget* titleWidget)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::AttachGroupTitle to group: " << groupIndex << ", with titleWidget [0x" << std::hex << titleWidget << "]");
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		ASSERT(titleWidget != NULL);

		CActor *parent = dynamic_cast<CActor*>(m_groupList[groupIndex]->title);
		if (parent)
		{
			titleWidget->setParent(parent);

			float w = titleWidget->getWidth(), h = titleWidget->getHeight();

			TRect titleRect;

			if (TYPE_VERTICAL == m_scrollDirectionType)
			{
				titleRect.Set(0.0f, m_groupList[groupIndex]->styleList[m_groupList[groupIndex]->currentStyle]->startPos - m_titleSpace, w, h);

				t_focusRangeRect.Set(0.0f, m_titleSpace, t_listWidth, t_listHeight - m_titleSpace);
			}
			else
			{
				titleRect.Set(m_groupList[groupIndex]->styleList[m_groupList[groupIndex]->currentStyle]->startPos, 0.0f, w, h);
			}
			
			parent->Resize(w, h);

			TValue2f realValue = t_GetRealPointBaseItemGroup(titleRect, t_itemGroupRect);
			parent->SetPosition(realValue.val[0], realValue.val[1]);
		}
	}

	void CGridListControl::SetFocusItemIndex(int groupIndex, int itemIndex)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::SetFocusItemIndex to group: " << groupIndex << ", itemIndex: " << itemIndex);
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		ASSERT(itemIndex >= 0 && itemIndex < (int)m_groupList.at(groupIndex)->itemList.size());

		if (m_focusGroupIndex == groupIndex && m_focusItemIndex == itemIndex)
		{
			return;
		}

		if (FlagShow() == true)
		{
			t_flagMouse = false;
			m_SetFocus(groupIndex, itemIndex, true, true);
		}
		else
		{
			m_focusGroupIndex = groupIndex;
			m_focusItemIndex = itemIndex;
		}
	}

	void CGridListControl::GetFocusItemIndex(int &groupIndex, int &itemIndex)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::GetFocusItemIndex");
		groupIndex = m_focusGroupIndex;
		itemIndex = m_focusItemIndex;
	}

	void CGridListControl::SetAnimationDuration(EAniType anitype, int duration)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::SetAnimationDuration to animation type: " << anitype << ", with duration: " << duration);

		if (ANITYPE_FOCUS_MOVE == anitype)
		{
			t_SetFocusMoveAniDuration(duration);
		}
		else if (ANITYPE_STYLE_TRANS == anitype)
		{
			t_SetTransStyleAniDuration(duration);
		}

		m_aniInfoList[anitype].duration = duration;
	}

	void CGridListControl::SetAnimationMode(EAniType anitype, ClutterAnimationMode mode)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::SetAnimationMode to animation type: " << anitype << ", with mode: " << mode);

		if (ANITYPE_FOCUS_MOVE == anitype)
		{
			t_SetFocusMoveAniMode(mode);
		}
		else if (ANITYPE_STYLE_TRANS == anitype)
		{
			t_SetTransStyleAniMode(mode);
		}

		m_aniInfoList[anitype].mode = mode;
	}

	void CGridListControl::EnableItem(int groupIndex, int itemIndex, bool flagEnable)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::EnableItem to group: " << groupIndex << ", itemIndex: " << itemIndex << ", with flag: " << flagEnable);
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		ASSERT(itemIndex >= 0 && itemIndex < (int)m_groupList.at(groupIndex)->itemList.size());

		TGroup* group = m_groupList.at(groupIndex);
		if (group->itemList.at(itemIndex)->flagEnable != flagEnable)
		{
			group->itemList.at(itemIndex)->flagEnable = flagEnable;

			//if the disable item is focused, hide focused item.
			if (flagEnable == false && groupIndex == m_focusGroupIndex && itemIndex == m_focusItemIndex)
			{
				HideFocus(true);
			}
		}
	}

	bool CGridListControl::IsItemEnabled(int groupIndex, int itemIndex)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::IsItemEnabled with group: " << groupIndex << ", itemIndex: " << itemIndex);
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		ASSERT(itemIndex >= 0 && itemIndex < (int)m_groupList.at(groupIndex)->itemList.size());

		return m_groupList.at(groupIndex)->itemList.at(itemIndex)->flagEnable;
	}

	void CGridListControl::EnableEdit(const bool flagEditable)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::EnableEdit with flag: " << flagEditable);

		//check if all the cells in the group are all the same size;
		size_t groupCount = m_groupList.size();
		//for (size_t i = 0; i < groupCount; i++)
		//{
		//	TGroup *group = m_groupList[i];
		//	TStyle *style = group->styleList[group->currentStyle];
		//	size_t columnCount = style->columnList.size();
		//	TRect startCellRect = style->columnList[0]->cellList[0]->rect;
		//	for (size_t j = 0; j < columnCount; j++)
		//	{
		//		TColumn* column = style->columnList[j];
		//		size_t cellCount = column->cellList.size();
		//		for (size_t k = 0; k < cellCount; k++)
		//		{
		//			TCell* cell = column->cellList[k];
		//			ASSERT(startCellRect.w == cell->rect.w && startCellRect.h == cell->rect.h);
		//		}
		//	}
		//	//size_t itemCount = m_groupList[i]->itemList.size();
		//	//for (size_t j = 1; j < itemCount; j++)
		//	//{
		//	//	TItem* item = m_groupList[i]->itemList[j];
		//	//	ASSERT(m_groupList[i]->itemList[0]->rect.w == item->rect.w && m_groupList[i]->itemList[0]->rect.h == item->rect.h);
		//	//}
		//}

		if (flagEditable == t_flagEditable)
		{
			return;
		}

		t_flagEditable = flagEditable;


		for (size_t i = 0; i < groupCount; i++)
		{
			size_t itemCount = m_groupList[i]->itemList.size();
			for (size_t j = 0; j < itemCount; j++)
			{
				if (m_groupList[i]->itemList[j]->window != NULL)
				{
					m_groupList[i]->itemList[j]->window->EnableDrag(t_flagEditable);
				}
			}
		}

	}

	bool CGridListControl::IsEditEnabled(void) const
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::IsEditEnabled");
		return t_flagEditable;
	}

	int CGridListControl::ColumnCount(int groupIndex, int styleIndex)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::ColumnCount with group: " << groupIndex << ", styleIndex: " << styleIndex);
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		ASSERT(styleIndex >= 0 && styleIndex < (int)m_groupList[groupIndex]->styleList.size());

		return m_groupList[groupIndex]->styleList[styleIndex]->columnList.size();
	}

	void CGridListControl::UpdateItem(int groupIndex, int itemIndex)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::UpdateItem with group: " << groupIndex << ", itemIndex: " << itemIndex);
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		ASSERT(itemIndex >= 0 && itemIndex < (int)m_groupList.at(groupIndex)->itemList.size());

		TGridListItem *gridItem = m_groupList[groupIndex]->itemList[itemIndex];
		gridItem->data = m_dataSource->GetData(groupIndex, itemIndex);
		t_UpdateItem(gridItem);
	}

	void CGridListControl::UpdateAllItems(int groupIndex)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::UpdateAllItems of group: " << groupIndex);

		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());

		int minCount = HALO_MIN((int)m_groupList[groupIndex]->itemList.size(), m_dataSource->NumOfData(groupIndex));
		for (int i = 0; i < minCount; i++)
		{
			TGridListItem *gridItem = m_groupList[groupIndex]->itemList[i];
			gridItem->data = m_dataSource->GetData(groupIndex, i);
			t_UpdateItem(gridItem);
		}
	}


	bool CGridListControl::t_CreateDerivedObject(IActor *parent, TDataListControlAttr *attr)
	{
		return true;
	}

	bool CGridListControl::t_MoveFocusBar(EDirection direction)
	{
		return m_MoveFocus(direction, m_focusGroupIndex, m_focusItemIndex);
	}

	void CGridListControl::t_GetInMemoryItems(TRect lastVisibleArea, TRect visibleArea, std::vector<TItem*> &loadItem, std::vector<TItem*> &unloadItem, std::vector<TItem*> &noChangeItem, int reason /*= -1*/)
	{
		if (SCROLL_ITEMGROUP == reason)
		{
			bool flagNeedUpdate = false;
			float deltaPos, visibleAreaStart, visibleAreaEnd;

			if (TYPE_VERTICAL == m_scrollDirectionType)
			{
				visibleAreaStart = visibleArea.y;
				visibleAreaEnd = visibleArea.y + visibleArea.h;
				deltaPos = visibleArea.y - lastVisibleArea.y;
			} 
			else
			{
				visibleAreaStart = visibleArea.x;
				visibleAreaEnd = visibleArea.x + visibleArea.w;
				deltaPos = visibleArea.x - lastVisibleArea.x;
			}

			TGroup *startGroup = m_groupList[m_onScreenRange.startGroupInScrn];
			TStyle *startStyle = startGroup->styleList[startGroup->currentStyle];
			TColumn *startColumn = startStyle->columnList[m_onScreenRange.startColumnInScrn];

			TGroup *endGroup = m_groupList[m_onScreenRange.endGroupInScrn];
			TStyle *endStyle = endGroup->styleList[endGroup->currentStyle];
			TColumn *endColumn = endStyle->columnList[m_onScreenRange.endColumnInScrn];

			if (true == m_ReCalcFocusItemIndex(visibleArea))
			{
				printf("new focus group:%d, item:%d\n", m_focusGroupIndex, m_focusItemIndex);
				TGridListItem *newFocusItem = m_groupList[m_focusGroupIndex]->itemList[m_focusItemIndex];

				if (false == t_flagShowFocusBar)
				{
					t_focusedItemBak = newFocusItem;
				}
				else
				{
					t_focusedItem = newFocusItem;
				}
			}

			if (0.0f < deltaPos)
			{
				if (startColumn->startPos < visibleAreaStart)
				{
					flagNeedUpdate = true;
				}

				if (endColumn->endPos < visibleAreaEnd)
				{
					if (m_onScreenRange.endColumnIndex < (int)endStyle->columnList.size() - 1 || m_onScreenRange.endGroupIndex < (int)m_groupList.size() - 1)
					{
						flagNeedUpdate = true;
					}
				}
			}
			else if (0.0f > deltaPos)
			{
				if (endColumn->endPos > visibleAreaEnd)
				{
					flagNeedUpdate = true;
				}
				
				if (startColumn->startPos > visibleAreaStart)
				{
					if (m_onScreenRange.startColumnIndex > 0 || m_onScreenRange.startGroupIndex > 0)
					{
						flagNeedUpdate = true;
					}
				}
			}

			if (false == flagNeedUpdate)
			{
				return;
			}
		}
		
		TRange newRange;
		m_FindOnScreenRange(visibleArea, newRange);
		
		H_LOG_INFO(LOGGER, "[0x" << std::hex<< this <<"]Old on screen range is (" << m_onScreenRange.startGroupIndex << "," << m_onScreenRange.startColumnIndex << "," << m_onScreenRange.endGroupIndex << "," << m_onScreenRange.endColumnIndex << ")");
		H_LOG_INFO(LOGGER, "[0x" << std::hex<< this <<"]New on screen range is (" << newRange.startGroupIndex << "," << newRange.startColumnIndex << "," << newRange.endGroupIndex << "," << newRange.endColumnIndex << ")");
		//Adjust the new start column.
		//Rule: if the start column has items which are merge_hidden, find the items' smallest start column as the new start column.
		TGroup* startGroup = m_groupList.at(newRange.startGroupIndex);
		TColumn* startColumn = startGroup->styleList.at(startGroup->currentStyle)->columnList.at(newRange.startColumnIndex);
		size_t cellCount = startColumn->cellList.size();
		for (size_t i = 0; i < cellCount; i++)
		{
			TCell* cell = startColumn->cellList.at(i);
			if (cell->mergeState == STATE_MERGE_HIDDEN)
			{
				if (cell->fromColumnIndex < newRange.startColumnIndex)
				{
					newRange.startColumnIndex = cell->fromColumnIndex;
					if (newRange.startColumnIndex == 0)
					{
						break;
					}
				}
			}
		}

		////save new range items to list
		//std::vector<TGridListItem*> nextInMemoryItemList;
		//m_GetItemsInRange(newRange, -1, nextInMemoryItemList);

		////save old range items to list
		//std::vector<TGridListItem*> curInMemoryItemList;
		//if (m_onScreenRange.startGroupIndex != -1)//first time load, current in memory items count is 0
		//{
		//	m_GetItemsInRange(m_onScreenRange, reason, curInMemoryItemList);
		//}

		//size_t i = 0, j = 0;
		//while (i < nextInMemoryItemList.size() && j < curInMemoryItemList.size())//loop to insert load & unload items.
		//{
		//	TGridListItem* gridItem1 = nextInMemoryItemList[i];
		//	TGridListItem* gridItem2 = curInMemoryItemList[j];
		//	if (gridItem1->groupIndex > gridItem2->groupIndex)
		//	{
		//		unloadItem.push_back(gridItem2);
		//		j++;
		//	}
		//	else if (gridItem1->groupIndex < gridItem2->groupIndex)
		//	{
		//		loadItem.push_back(gridItem1);
		//		i++;
		//	}
		//	else
		//	{
		//		if (gridItem1->indexInGroup > gridItem2->indexInGroup)
		//		{
		//			unloadItem.push_back(gridItem2);
		//			j++;
		//		}
		//		else if (gridItem1->indexInGroup < gridItem2->indexInGroup)
		//		{
		//			loadItem.push_back(gridItem1);
		//			i++;
		//		}
		//		else
		//		{
		//			if (gridItem1->window == NULL)
		//			{
		//				loadItem.push_back(gridItem1);
		//			}
		//			i++;
		//			j++;
		//		}
		//	}
		//}

		////push the rest of next in memory items into load item list.
		//while (i != nextInMemoryItemList.size())
		//{
		//	loadItem.push_back(nextInMemoryItemList[i]);
		//	i++;
		//}
		////push the rest of current in memory items into unload item list.
		//while (j != curInMemoryItemList.size())
		//{
		//	unloadItem.push_back(curInMemoryItemList[j]);
		//	j++;
		//}

		//save new range items to list
		std::set<TItem*> nextInMemoryItemSet;
		m_GetItemsInRange(newRange, -1, nextInMemoryItemSet);

		std::set_difference(nextInMemoryItemSet.begin(), nextInMemoryItemSet.end(), t_inMemoryItemSet.begin(), t_inMemoryItemSet.end(), inserter(loadItem, loadItem.begin()));
		std::set_difference(t_inMemoryItemSet.begin(), t_inMemoryItemSet.end(), nextInMemoryItemSet.begin(), nextInMemoryItemSet.end(), inserter(unloadItem,unloadItem.begin()));

		//reset on screen groups and columns
		m_onScreenRange = newRange;
	}

	void CGridListControl::t_OnItemGroupScrollStart(void)
	{
		//TBD:
	}

	void CGridListControl::t_OnItemGroupScrollEnd(void)
	{
		//TBD:
	}

	void CGridListControl::t_GetItemWindowPivotPoint(TItem *item, float &pivotX, float &pivotY, float &pivotZ)
	{
		pivotX = pivotY = 0.5f;
		pivotZ = 0.0f;
	}

	void CGridListControl::t_OnItemDataUnload(TItem *item)
	{
		ASSERT(item != NULL);

		TGridListItem *gridItem = (TGridListItem*)(item);

		if (m_listenerSet)
		{
			CGridListControlListenerSet::TGridListListenerData data;
			data.type = EVENT_ITEM_UNLOAD;
			data.param[0] = gridItem->groupIndex;
			data.param[1] = gridItem->indexInGroup;
			m_listenerSet->Process(&data);
		}
	}

	void CGridListControl::t_OnItemDataSyncLoad(TItem *item)
	{
		ASSERT(item != NULL);

		TGridListItem *gridItem = (TGridListItem*)(item);

		if (m_listenerSet)
		{
			CGridListControlListenerSet::TGridListListenerData data;
			data.type = EVENT_ITEM_LOAD;
			data.param[0] = gridItem->groupIndex;
			data.param[1] = gridItem->indexInGroup;
			m_listenerSet->Process(&data);
		}
	}

	void CGridListControl::t_OnItemDataAsyncLoad(TItem *item)
	{
		ASSERT(item != NULL);

		//TBD:
	}

	void CGridListControl::t_FocusChangeStart(const TItem *from, const TItem *to)
	{
		const TGridListItem *fromItem = dynamic_cast<const TGridListItem*>(from);
		const TGridListItem *toItem = dynamic_cast<const TGridListItem*>(to);

		if (t_flagShadowEffect)
		{
			if (0 != fromItem)
			{
				IActor * fromWin = fromItem->window;
				if (fromWin)
				{
					fromWin->RemoveEffect(t_shadowEffect);
				}
			}
		}

		CGridListControlListenerSet::TGridListListenerData data;
		data.type = EVENT_FOCUS_CHANGE_MOTION_START;

		if (NULL == fromItem)
		{
			data.param[0] = -1;
			data.param[1] = -1;
		}
		else
		{
			data.param[0] = fromItem->groupIndex;
			data.param[1] = fromItem->indexInGroup;
		}

		if (NULL == toItem)
		{
			data.param[2] = -1;
			data.param[3] = -1;
		}
		else
		{
			data.param[2] = toItem->groupIndex;
			data.param[3] = toItem->indexInGroup;
		}

		m_listenerSet->Process(&data);
	}

	void CGridListControl::t_FocusChangeFinish(const TItem *from, const TItem *to)
	{
		const TGridListItem *fromItem = dynamic_cast<const TGridListItem*>(from);
		const TGridListItem *toItem = dynamic_cast<const TGridListItem*>(to);

		if (t_flagShadowEffect)
		{
			if (NULL != toItem)
			{
				IActor * toWin = toItem->window;
				if (toWin)
				{
					if (true == t_flagShowFocusBar)
					{
						toWin->AddEffect(t_shadowEffect);
					}
				}
			}
		}
		
		CGridListControlListenerSet::TGridListListenerData data;
		data.type = EVENT_FOCUS_CHANGE;

		if (NULL == fromItem)
		{
			data.param[0] = -1;
			data.param[1] = -1;
		}
		else
		{
			data.param[0] = fromItem->groupIndex;
			data.param[1] = fromItem->indexInGroup;
		}

		if (NULL == toItem)
		{
			data.param[2] = -1;
			data.param[3] = -1;
		}
		else
		{
			data.param[2] = toItem->groupIndex;
			data.param[3] = toItem->indexInGroup;
		}

		m_listenerSet->Process(&data);
	}

	void CGridListControl::t_OnItemInMemoryScrolled(TItem *item)
	{
		//TBD:
	}

	HALO::TValue2f CGridListControl::t_GetRealPointBaseItemGroup(TRect rect, TRect baseOnRect)
	{
		TValue2f point;

		if (ORIENTATION_LEFT_TO_RIGHT == Orientation(true))
		{
			point.Set(rect.x, rect.y);
		}
		else
		{
			point.Set(baseOnRect.w - rect.x - rect.w, rect.y);
		}

		return point;
	}

	TValue2f CGridListControl::t_GetLogicalPosition(TRect rect, TRect baseOnRect)
	{
		TValue2f point;

		if (ORIENTATION_LEFT_TO_RIGHT == this->Orientation(true))
		{
			point.Set(rect.x, rect.y);
		}
		else
		{
			point.Set(baseOnRect.w - rect.x - rect.w, rect.y);
		}
		
		return point;
	}

	TRect CGridListControl::t_InitRectOfLoadingItem(TItem *item, int reason)
	{
		TRect initRect;

		switch (reason)
		{
		case STYLE_ANIMATION:
		{
			TGridListItem* gridItem = (TGridListItem*)item;
			TGroup* group = m_groupList.at(gridItem->groupIndex);
			TStyle* style = group->styleList[group->lastStyle];

			if (gridItem->indexInGroup >= (int)style->rectList.size())
			{
				initRect = item->rect;
				initRect.x = t_listWidth - t_itemGroupRect.x;
			}
			else
			{
				initRect = style->rectList[gridItem->indexInGroup];
			}
			break;
		}

		default:
			initRect = item->rect;
			break;
		}

		return initRect;
	}

	void CGridListControl::t_BindDataListToItemList()
	{
		size_t groupCount = m_groupList.size();
		for (size_t i = 0; i < groupCount; ++i)
		{
			if (m_ColumnNumberInGroup(i) == 0)
			{
				ASSERT(false && "There are groups that haven't add column infos.");
				TGroup* group = m_groupList[i];
				for (size_t j = 0; j < group->styleList.size(); j++)
				{
					TStyle* style = group->styleList[j];
					for (size_t k = 0; k < style->columnList.size(); k++)
					{
						TColumn* column = style->columnList[k];
						ASSERT(!column->cellList.empty() && "There are columns that haven't add row infos!");
					}
				}				
			}
		}

		m_InitItemIndex();

		size_t itemGroupCount = m_groupList.size();
		size_t dataGroupCount = m_dataSource->NumOfGroup();
		size_t minGroupCount = HALO_MIN(itemGroupCount, dataGroupCount);
		for (size_t i = 0; i < minGroupCount; ++i)
		{
			size_t styleCount = m_groupList.at(i)->styleList.size();
			for (size_t m = 0; m < styleCount; m++)
			{
				size_t cellCount = m_groupList.at(i)->styleList.at(m)->rectList.size();

				size_t dataCount = m_dataSource->NumOfData(i);
				size_t minDataCount = HALO_MIN(cellCount, dataCount);
				size_t bindedItemCount = m_groupList.at(i)->itemList.size();
				while (bindedItemCount > minDataCount)//this is for remove data case
				{
					m_groupList.at(i)->itemList.pop_back();
					bindedItemCount--;
				}
				for (size_t j = 0; j < minDataCount; ++j)
				{
					TGridListItem *newItem;
					if (j < bindedItemCount) //rebind item's data which is already binded
					{
						newItem = m_groupList.at(i)->itemList[j];
						newItem->data = m_dataSource->GetData(i, j);
					}
					else //this is for add data or insert data case
					{
						newItem = new TGridListItem;
						m_SetGridItemIndex(i, j, newItem);
						newItem->data = m_dataSource->GetData(i, j);
						m_groupList.at(i)->itemList.push_back(newItem);
					}
				}
			}
		}

		float itemRadiusSum = 0;
		size_t itemCountTotal = 0;
		for (size_t i = 0; i < groupCount; ++i)
		{
			int currentStyleIndex = m_groupList.at(i)->currentStyle;
			TStyle *style = m_groupList.at(i)->styleList.at(currentStyleIndex);

			//reset item positions
			size_t itemCount = HALO_MIN(style->rectList.size(), m_groupList.at(i)->itemList.size());
			itemCountTotal += itemCount;
			for (size_t j = 0; j < itemCount; ++j)
			{
				TGridListItem* item = m_groupList.at(i)->itemList.at(j);
				item->rect = style->rectList[j];
				item->radius = HALO_MIN(item->rect.w, item->rect.h) / 2;
				itemRadiusSum += item->radius;
			}
		}

		if (0 != (int)itemCountTotal)
		{
			t_cursorRadius = itemRadiusSum / itemCountTotal;
		}
		else
		{
			t_cursorRadius = 0.0f;
		}

		TGroup* lastGroup = m_groupList.back();
		TStyle* lastGroupStyle = lastGroup->styleList[lastGroup->currentStyle];
		TRect lastRect = lastGroupStyle->rectList[HALO_MIN(m_groupList.back()->itemList.size() - 1, lastGroupStyle->rectList.size() - 1)];

		if (TYPE_VERTICAL == m_scrollDirectionType)
		{
			t_SetItemGroupSize(t_listWidth, lastRect.y + lastRect.h);//reset group size for initialize
		}
		else
		{
			t_SetItemGroupSize(lastRect.x + lastRect.w, t_listHeight);//reset group size for initialize
		}

		for (size_t i = 0; i < groupCount; ++i)
		{
			//reset group title positions
			TStyle *style = m_groupList[i]->styleList[m_groupList[i]->currentStyle];
			TRect titleRect;
			titleRect.Set(style->startPos, 0.0f, 0.0f, 0.0f);
			TValue2f realValue = t_GetRealPointBaseItemGroup(titleRect, t_itemGroupRect);
			m_groupList.at(i)->title->SetPosition(realValue.val[0], realValue.val[1]);
		}

		t_UpdateInMemoryItems(true);

		for (size_t i = 0; i < groupCount; i++)
		{
			TGroup* group = m_groupList[i];
			for (size_t j = 0; j < group->itemList.size(); j++)
			{
				t_RefreshItemPosition(group->itemList[j], NULL);
			}
		}

		if (!t_inMemoryItemSet.empty())
		{
			t_flagMouse = false;
			m_SetFocus(m_focusGroupIndex, m_focusItemIndex, false, false);
		}
	}

	bool CGridListControl::t_OnMousePointerIn(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		//if (true == m_flagItemDraged)
		//{
		//	return false;
		//}

		if (false == t_flagShowFocusBar)
		{
			return false;
		}

		if (item->window == NULL)
		{
			return false;
		}

		if (!m_isSunken)
		{
			g_get_current_time(&m_start_time);
		}
		m_canMove = false;

		TGridListItem* gridItem = static_cast<TGridListItem*>(item);

		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridListControl::t_OnMousePointerIn groupIndex: " << gridItem->groupIndex << ",itemIndex: " << gridItem->indexInGroup);

		if (gridItem->groupIndex == m_focusGroupIndex && gridItem->indexInGroup == m_focusItemIndex)
		{
			if (false == m_isSunken)
			{
				if (NULL != t_focusedItem && NULL != t_focusedItem->window && t_flagShadowEffect)
				{
					t_focusedItem->window->AddEffect(t_shadowEffect);
				}

				t_ScaleUpFocuedItem(NULL);
			}
			return true;
		}
		else
		{
			t_flagMouse = true;
			m_SetFocus(gridItem->groupIndex, gridItem->indexInGroup, false, true);
		}
		m_refXForFocusMoving = m_refYForFocusMoving = -1;//reset reference line

		return true;
	}

	bool CGridListControl::t_OnMousePointerOut(TItem* item, IMouseEvent* ptrMouseEvent)
	{
// 		if (true == m_flagItemDraged)
// 		{
// 			return false;
// 		}

		TValue2f position = t_GetRealPointBaseItemGroup(item->rect, t_itemGroupRect);

		item->window->SetPosition(position.val[0], position.val[1]);
		item->window->SetRotation(0.0, 0.0, 0.0);

		if (false == m_isSunken)
		{
			if (NULL != t_focusedItem && NULL != t_focusedItem->window)
			{
				TGridListItem* gridItem = (TGridListItem*)item;

				if (m_focusGroupIndex == gridItem->groupIndex && m_focusItemIndex == gridItem->indexInGroup)
				{
					t_focusedItem->window->RemoveEffect(t_shadowEffect);
					
					t_ScaleDownFocuedItem(NULL);
				}
			}
		}

		return true;
	}

	bool CGridListControl::t_OnMouseMoved(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		TGridListItem* gridItem = static_cast<TGridListItem*>(item);

		if (true == m_flagItemDraged || t_flagEditable)
		{
			return false;
		}

		if (m_isSunken)
		{
			return false;
		}

		if (NULL != item->renderer)
		{
			IThumbnail *thum = item->renderer->Thumbnail();
			if (NULL != thum && true == thum->OnMouseEvent(IThumbnail::EVENT_MOUSE_MOVED, ptrMouseEvent))
			{
				return false;
			}
		}

		if (m_canMove == false)
		{
			TGridListItem* gridItem = static_cast<TGridListItem*>(item);

			if (gridItem->groupIndex != m_focusGroupIndex || gridItem->indexInGroup != m_focusItemIndex)
			{
				t_flagMouse = true;
				m_SetFocus(gridItem->groupIndex, gridItem->indexInGroup, false, false);
#ifdef WIN32
				m_refXForFocusMoving = m_refYForFocusMoving = -1;//reset reference line
#endif
				g_get_current_time(&m_start_time);
				return true;
			}

			GTimeVal end_time;
			g_get_current_time(&end_time);
			guint elapsed_msec;
			elapsed_msec = ((end_time.tv_sec * G_USEC_PER_SEC + end_time.tv_usec) -
				(m_start_time.tv_sec * G_USEC_PER_SEC + m_start_time.tv_usec)) / 1000;
			if (elapsed_msec < 300)
			{
				return false;
			}
			m_canMove = true;
		}

		if (m_flagRolloverEffect)
		{
			ClutterPoint centerGloable;
			TValue2f realValue = t_GetRealPointBaseItemGroup(item->rect, t_itemGroupRect);
			centerGloable.x = realValue.val[0];
			centerGloable.y = realValue.val[1];
			IActor *parent = item->window->Parent();
			while (parent != NULL)
			{
				float x, y;
				parent->GetPosition(x, y);
				centerGloable.x += x;
				centerGloable.y += y;

				parent = parent->Parent();
			}
			centerGloable.x += item->rect.w / 2;
			centerGloable.y += item->rect.h / 2;

			float enlargeWidth, enlargeHeight;
			GetEnlargeSizeOfFocusedItem(enlargeWidth, enlargeHeight);
			double x_angle = -(ptrMouseEvent->GetY() - centerGloable.y) * 3 / (item->rect.w / 2 + enlargeWidth);
			double y_angle = (ptrMouseEvent->GetX() - centerGloable.x) * 3 / (item->rect.h / 2 + enlargeHeight);

			item->window->SetRotation(x_angle, y_angle, 0.0);
			//TValue2f realValue = t_GetRealPointBaseItemGroup(item->rect, t_itemGroupRect);
			item->window->SetPosition(realValue.val[0] + (float)y_angle * 4, realValue.val[1] - (float)x_angle * 4);
		}

		return true;
	}

	bool CGridListControl::t_MouseButtonPressed(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		if (true == m_flagItemDraged)
		{
			return false;
		}

		if (item->window == NULL)
		{
			return false;
		}


		if (NULL != item->renderer)
		{
			IThumbnail *thum = item->renderer->Thumbnail();
			if (NULL != thum && true == thum->OnMouseEvent(IThumbnail::EVENT_MOUSE_PRESSED, ptrMouseEvent))
			{
				return false;
			}
		}

		TValue2f realValue = t_GetRealPointBaseItemGroup(item->rect, t_itemGroupRect);
		item->window->SetPosition(realValue.val[0], realValue.val[1]);
		item->window->SetRotation(0.0, 0.0, 0.0);
		item->window->GetScale(m_xFactor, m_yFactor, m_zFactor);
		item->window->SetScale(1.02, 1.02, m_zFactor);
		m_isSunken = true;

		if (!t_flagEditable)
		{
			IDeviceManager* pDeviceManager = IDeviceManager::GetInstance();
			IMouseDevice* device = dynamic_cast<IMouseDevice*>(pDeviceManager->GetDevice(CLUTTER_POINTER_DEVICE));
			item->window->GrabDeviceEvent(device);
		}

		return true;
	}

	bool CGridListControl::t_MouseButtonRelease(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		if (true == m_flagItemDraged)
		{
			return false;
		}

		if (NULL != item->renderer)
		{
			IThumbnail *thum = item->renderer->Thumbnail();
			if (NULL != thum && true == thum->OnMouseEvent(IThumbnail::EVENT_MOUSE_RELEASE, ptrMouseEvent))
			{
				return false;
			}
		}

		if (!t_flagEditable)
		{
			IDeviceManager* pDeviceManager = IDeviceManager::GetInstance();
			IMouseDevice* device = dynamic_cast<IMouseDevice*>(pDeviceManager->GetDevice(CLUTTER_POINTER_DEVICE));
			item->window->UnGrabDeviceEvent(device);
		}

		if (m_isSunken)
		{
			m_isSunken = false;

			TValue1f destX((float)m_xFactor);
			m_itemScaleTrans->SetDestination(item->window, IActor::ACTOR_ANI_SCALE_X, &destX);

			TValue1f destY((float)m_yFactor);
			m_itemScaleTrans->SetDestination(item->window, IActor::ACTOR_ANI_SCALE_Y, &destY);

			m_itemScaleTrans->Play();

			t_MouseClicked(item, ptrMouseEvent);
		}

		return true;
	}

	bool CGridListControl::t_MouseClicked(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		if (true == m_flagItemDraged)
		{
			return false;
		}

		TGridListItem* gridItem = static_cast<TGridListItem*>(item);

		CGridListControlListenerSet::TGridListListenerData data;
		data.type = EVENT_ITEM_CLICKED;
		data.param[0] = gridItem->groupIndex;
		data.param[1] = gridItem->indexInGroup;
		m_listenerSet->Process(&data);

		return true;
	}

	void CGridListControl::t_OnStyleAnimationFinish(void)
	{
		if (m_focusItemChangedFlag)
		{
			t_SetFocusBar(m_groupList[m_focusGroupIndex]->itemList[m_focusItemIndex], false, false);
		}

		m_refXForFocusMoving = m_refYForFocusMoving = -1;//reset reference line after style animation
	}

	bool CGridListControl::t_OnDragBegin(TItem* item, IDragEvent* pDragEvent)
	{
		m_flagItemDraged = true;

		TGridListItem* gridItem = (TGridListItem*)item;
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::t_OnDragBegin with item index:(" << gridItem->groupIndex << "," << gridItem->indexInGroup << ")");
		m_dragItemIndex = gridItem->indexInGroup;
		//float startItemX, startItemY;//item start position relative to stage
		
		TValue2f realValue = t_GetRealPointBaseItemGroup(item->rect, t_itemGroupRect);

		//startItemX = item->rect.x;
		//startItemY = item->rect.y;

		IActor* parent = item->window->Parent();
		while (parent != NULL)
		{
			float x, y;
			parent->GetPosition(x, y);
			realValue.val[0] += x;
			realValue.val[1] += y;

			parent = parent->Parent();
		}


		float pressX, pressY;
		pDragEvent->PressCoords(&pressX, &pressY);

		m_mouseToItemX = pressX - realValue.val[0];
		m_mouseToItemY = pressY - realValue.val[1];


		return true;
	}

	bool CGridListControl::t_OnDragEnd(TItem* item, IDragEvent* pDragEvent)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::t_OnDragEnd!");
		float dragX, dragY;
		pDragEvent->PressCoords(&dragX, &dragY);

		t_RefreshItemPosition(item, m_dragItemTrans);
		m_dragItemTrans->Play();

		if (NULL != t_focusedItem && NULL != t_focusedItem->window)
		{
			t_focusedItem->window->SetScale(m_xFactor, m_yFactor, 1.0f);
		}

		if (m_dragItemIndex != m_dropItemIndex)
		{
			// Notify user that Item index change
			CGridListControlListenerSet::TGridListListenerData data;
			data.type = EVENT_ITEM_INDEX_CHANGE;
			data.param[0] = m_dragItemIndex;
			data.param[1] = m_dropItemIndex;
			m_listenerSet->Process(&data);
		}

		m_dragItemIndex = -1;
		m_dropItemIndex = -1;

		return true;
	}

	bool CGridListControl::t_OnDragHold(TItem* item, IDragEvent* pDragEvent)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex<< this <<"]CGridListControl::t_OnDragHold!");
		float motionX, motionY;
		pDragEvent->MotionCoords(&motionX, &motionY);

		float currentItemX, currentItemY;//item destination position relative to stage
		currentItemX = motionX - m_mouseToItemX;
		currentItemY = motionY - m_mouseToItemY;

		//float itemToRootX, itemToRootY; //item destination position relative to item group root
		//float gridX, gridY;
		//this->GetPosition(gridX, gridY);
		//itemToRootX = currentItemX - t_itemGroupRect.x - gridX;
		//itemToRootY = currentItemY - t_itemGroupRect.y - gridY;

		size_t itemCount = m_groupList[m_focusGroupIndex]->itemList.size();
		for (size_t i = 0; i < itemCount; i++)
		{
			TGridListItem* itemTmp = m_groupList[m_focusGroupIndex]->itemList[i];
			if (itemTmp->window == NULL)
			{
				continue;
			}
			TValue2f realValue = t_GetRealPointBaseItemGroup(itemTmp->rect, t_itemGroupRect);

			IActor* parent = itemTmp->window->Parent();
			float itemX = realValue.val[0], itemY = realValue.val[1];//item position relative to stage
			while (parent != NULL)
			{
				float x, y;
				parent->GetPosition(x, y);
				itemX += x;
				itemY += y;

				parent = parent->Parent();
			}
			if (currentItemX >= itemX && currentItemX <= itemX + itemTmp->rect.w
				&&currentItemY >= itemY && currentItemY <= itemY + itemTmp->rect.h)
			{
				m_dropItemIndex = i;
				H_LOG_INFO(LOGGER, "[0x" << std::hex<< this <<"]Drag hold on item with groupIndex: " << m_focusGroupIndex << ", itemIndex" << m_dropItemIndex);
				break;
			}
		}

		if (m_dropItemIndex != -1)
		{
			m_MoveItem(m_focusGroupIndex, m_dragItemIndex, m_dropItemIndex);

			IData* data = m_dataSource->GetData(m_focusGroupIndex, m_dragItemIndex);

			m_dataSource->DeleteData(m_focusGroupIndex, m_dragItemIndex);

			m_dataSource->InsertData(data, m_focusGroupIndex, m_dropItemIndex);
		}

		return true;
	}

	void CGridListControl::m_FindOnScreenRange(TRect visibleArea, TRange &newRange)
	{
		//find from the focus column		
		TCell* focusedCell = m_GetCellByItemIndex(m_focusGroupIndex, m_focusItemIndex);
		
		int focusColumnIndex = focusedCell->columnIndex;
		bool startFoundFlag = false, endFoundFlag = false;

		float startVisiblePos, endVisiblePos;

		if (TYPE_VERTICAL == m_scrollDirectionType)
		{
			startVisiblePos = visibleArea.y;
			endVisiblePos = visibleArea.y + visibleArea.h;
		} 
		else
		{
			startVisiblePos = visibleArea.x;
			endVisiblePos = visibleArea.x + visibleArea.w;
		}
		
		//find start range
		for (int i = m_focusGroupIndex; i >= 0; --i)
		{
			TGroup *group = m_groupList.at(i);
			TStyle* style = group->styleList.at(group->currentStyle);
			int columnCount = style->columnList.size();
			int startColumnIndex = ((int)i == m_focusGroupIndex) ? focusColumnIndex : columnCount - 1;
			for (int j = startColumnIndex; j >= 0; --j)
			{
				TColumn* column = style->columnList.at(j);
				if (column->startPos <= startVisiblePos)
				{
					if (column->endPos > startVisiblePos)//visible area left edge cross the column
					{
						newRange.startGroupIndex = i;
						newRange.startColumnIndex = j;
						startFoundFlag = true;
						break;
					}
					else//the column is totally out of the visible area
					{
						if (j == m_ColumnNumberInGroup(i) - 1)//if the column is the last column of group
						{
							newRange.startGroupIndex = i + 1;//start group need to plus 1 
							newRange.startColumnIndex = 0;   //start column index is 0
						}
						else//the column is not the last column of group
						{
							newRange.startGroupIndex = i;     //start group is current group
							newRange.startColumnIndex = j + 1;//start column need to plus 1
						}
						startFoundFlag = true;
						break;
					}
				}
			}
			if (startFoundFlag)
			{
				break;
			}
		}
		if (!startFoundFlag) //no column is on left side of visible area, then start group is 0, start column is 0.
		{
			newRange.startGroupIndex = 0;
			newRange.startColumnIndex = 0;
		}
		//find end range
		size_t groupCount = m_groupList.size();
		for (size_t i = m_focusGroupIndex; i < groupCount; ++i)
		{
			TGroup *group = m_groupList.at(i);
			TStyle* style = group->styleList.at(group->currentStyle);
			int startColumnIndex = ((int)i == m_focusGroupIndex) ? focusColumnIndex : 0;
			size_t columnCount = style->columnList.size();
			for (size_t j = startColumnIndex; j < columnCount; ++j)
			{
				TColumn* column = style->columnList.at(j);
				if (column->endPos >= endVisiblePos)
				{
					if (column->startPos < endVisiblePos)//visible area right edge cross the column
					{
						newRange.endGroupIndex = i;
						newRange.endColumnIndex = j;
						endFoundFlag = true;
						break;
					}
					else //the column is totally out of the visible area
					{
						if (j == 0)//if the column is the first column of group
						{
							newRange.endGroupIndex = i - 1;//end group need to minus 1 
							newRange.endColumnIndex = m_ColumnNumberInGroup(i - 1) - 1; //end column is the last column
						}
						else //the column is not the first column
						{
							newRange.endGroupIndex = i;  //end group is current group 
							newRange.endColumnIndex = j - 1;//end column need to minus 1
						}
						endFoundFlag = true;
						break;
					}
				}
			}
			if (endFoundFlag)
			{
				break;
			}
		}
		if (!endFoundFlag)//no column is on right side of visible area, then end group is last group, end column is the last column of end group.
		{
			newRange.endGroupIndex = m_groupList.size() - 1;
			newRange.endColumnIndex = m_ColumnNumberInGroup(newRange.endGroupIndex) - 1;
		}

		newRange.startGroupInScrn = newRange.startGroupIndex;
		newRange.startColumnInScrn = newRange.startColumnIndex;
		newRange.endGroupInScrn = newRange.endGroupIndex;
		newRange.endColumnInScrn = newRange.endColumnIndex;

		//add buffer columns
		int leftBufferCount = m_leftBufferColumnNum;
		while (leftBufferCount -- > 0)
		{
			if (newRange.startColumnIndex > 0)
			{
				newRange.startColumnIndex--;
			}
			else
			{
				if (newRange.startGroupIndex > 0)
				{
					newRange.startGroupIndex--;
					newRange.startColumnIndex = m_ColumnNumberInGroup(newRange.startGroupIndex) - 1;
				}
				else
				{
					break;
				}
			}
		}

		int rightBufferCount = m_rightBufferColumnNum;
		while (rightBufferCount-- > 0)
		{
			if (newRange.endColumnIndex < m_ColumnNumberInGroup(newRange.endGroupIndex) - 1)
			{
				newRange.endColumnIndex++;
			}
			else
			{
				if (newRange.endGroupIndex < (int)m_groupList.size() - 1)
				{
					newRange.endGroupIndex++;
					newRange.endColumnIndex = 0;
				}
				else
				{
					break;
				}
			}
		}
	}

	bool CGridListControl::m_ReCalcFocusItemIndex(const TRect newVisibleArea)
	{
		if (m_focusGroupIndex == (int)m_groupList.size() - 1 && m_focusItemIndex == (int)m_groupList[m_focusGroupIndex]->itemList.size() - 1)
		{
			return false;
		}
		
		TCell *focusCell = m_GetCellByItemIndex(m_focusGroupIndex, m_focusItemIndex);

		float focusCellStart, newVisibleAreaStart, focusRangeStart, focusRangeEnd;

		if (TYPE_VERTICAL == m_scrollDirectionType)
		{
			focusCellStart = focusCell->rect.y;
			newVisibleAreaStart = newVisibleArea.y;
			focusRangeStart = t_focusRangeRect.y;
			focusRangeEnd = t_focusRangeRect.y + t_focusRangeRect.h;
		}
		else
		{
			focusCellStart = focusCell->rect.x;
			newVisibleAreaStart = newVisibleArea.x;
			focusRangeStart = t_focusRangeRect.x;
			focusRangeEnd = t_focusRangeRect.x + t_focusRangeRect.w;
		}

		if (focusCellStart < newVisibleAreaStart + focusRangeStart)
		{
			TGroup *curFocusGroup = m_groupList[m_focusGroupIndex];

			int focusColumn = focusCell->toColumnIndex;
			TStyle *focusStyle = curFocusGroup->styleList[curFocusGroup->currentStyle];

			for (int i = focusColumn + 1; i < (int)focusStyle->columnList.size(); i++)
			{
				TColumn *curColumn = focusStyle->columnList[i];
				if (curColumn->startPos >= newVisibleAreaStart + focusRangeStart && curColumn->endPos <= newVisibleAreaStart + focusRangeEnd)
				{
					m_GetNearestItem(focusCell, m_focusGroupIndex, i, m_focusItemIndex);
					return true;
				}
			}

			for (int i = m_focusGroupIndex + 1; i < (int)m_groupList.size(); i++)
			{
				curFocusGroup = m_groupList[i];
				TStyle *curStyle = curFocusGroup->styleList[curFocusGroup->currentStyle];

				for (int j = 0; j < (int)curStyle->columnList.size(); j++)
				{
					TColumn *curColumn = focusStyle->columnList[j];
					if (curColumn->startPos + curStyle->startPos >= newVisibleAreaStart + focusRangeStart && curColumn->endPos + curStyle->startPos <= newVisibleAreaStart + focusRangeEnd)
					{
						m_focusGroupIndex = i;
						m_GetNearestItem(focusCell, m_focusGroupIndex, j, m_focusItemIndex);

						return true;
					}
				}
			}
		}
		else if (focusCellStart + focusCell->rect.w > newVisibleAreaStart + focusRangeEnd)
		{
			TGroup *curFocusGroup = m_groupList[m_focusGroupIndex];

			int focusColumn = focusCell->toColumnIndex;
			TStyle *focusStyle = curFocusGroup->styleList[curFocusGroup->currentStyle];

			for (int i = focusColumn - 1; i >= 0; i--)
			{
				TColumn *curColumn = focusStyle->columnList[i];
				if (curColumn->startPos + focusStyle->startPos >= newVisibleAreaStart + focusRangeStart && curColumn->endPos + focusStyle->startPos <= newVisibleAreaStart + focusRangeEnd)
				{
					m_GetNearestItem(focusCell, m_focusGroupIndex, i, m_focusItemIndex);
					return true;
				}
			}

			for (int i = m_focusGroupIndex - 1; i >= 0; i--)
			{
				curFocusGroup = m_groupList[i];
				TStyle *curStyle = curFocusGroup->styleList[curFocusGroup->currentStyle];

				for (int j = (int)curStyle->columnList.size() - 1; j >= 0; j--)
				{
					TColumn *curColumn = focusStyle->columnList[j];
					if (curColumn->startPos + focusStyle->startPos >= newVisibleAreaStart + focusRangeStart && curColumn->endPos + focusStyle->startPos <= newVisibleAreaStart + focusRangeEnd)
					{
						m_focusGroupIndex = i;
						m_GetNearestItem(focusCell, m_focusGroupIndex, j, m_focusItemIndex);

						return true;
					}
				}
			}
		}
		
		return false;
	}

	CGridListControl::TCell* CGridListControl::m_GetCellByItemIndex(int groupIndex, int itemIndex)
	{
		TGroup* group = m_groupList.at(groupIndex);
		int styleIndex = group->currentStyle;
		TStyle* style = group->styleList.at(styleIndex);

		std::map<int, TCell*>::iterator x = style->itemIndexToCell.find(itemIndex);

		if (style->itemIndexToCell.end() != x)
		{
			return x->second;
		}
		else
		{
			return style->columnList[0]->cellList[0];
		}
	}

	void CGridListControl::m_SetGridItemIndex(int groupIndex, int itemIndex, TGridListItem *item)
	{
		TGroup* group = m_groupList.at(groupIndex);
		int styleIndex = group->currentStyle;
		TStyle* style = group->styleList.at(styleIndex);

		//item->rect = style->rectList[itemIndex];
		item->groupIndex = groupIndex;
		item->indexInGroup = itemIndex;
	}

	void CGridListControl::m_SetFocus(int groupIndex, int itemIndex, bool flagFocusBarAni, bool flagScrollAni)
	{
		if (groupIndex >= (int)m_groupList.size())
		{
			groupIndex = m_groupList.size() - 1;
		}
		if (groupIndex < 0)
		{
			return;
		}
		TGroup* group = m_groupList.at(groupIndex);
		if (itemIndex >= (int)group->itemList.size())
		{
			itemIndex = group->itemList.size() - 1;
		}
		if (itemIndex < 0)
		{
			return;
		}
		TGridListItem* newItem = group->itemList[itemIndex];

		if (newItem->flagEnable == false)
		{
			return;
		}

		TGroup *destGroup = m_groupList[groupIndex];
		TStyle *destGroupStyle = destGroup->styleList[destGroup->currentStyle];
		TCell *destCell = m_GetCellByItemIndex(groupIndex, itemIndex);

		m_focusGroupIndex = groupIndex;
		m_focusItemIndex = itemIndex;

		TRect focusImgRect;
		focusImgRect.x = 0;
		focusImgRect.y = 0;
		focusImgRect.w = newItem->rect.w;
		focusImgRect.h = newItem->rect.h;

		float expandWithOfLeft = 0.0f;
		float expandWithOfRight = 0.0f;

		if (true == m_flagUseMarginWhenFocusEdgeItem)
		{
			if (m_onScreenRange.startGroupInScrn == groupIndex)
			{
				TGroup *startGroup = m_groupList[groupIndex];
				TStyle *startStyle = startGroup->styleList[startGroup->currentStyle];
				TColumn *startCol = startStyle->columnList[m_onScreenRange.startColumnInScrn];

				bool flagNeedToExpand = false;

				if (startCol->startItemIndex <= itemIndex && startCol->endItemIndex >= itemIndex)
				{
					flagNeedToExpand = true;
				}
				else if (startCol->startItemIndex > itemIndex)
				{
					flagNeedToExpand = true;
				}

				if (true == flagNeedToExpand)
				{
					if (0 < destCell->fromColumnIndex)
					{
						expandWithOfLeft = destGroupStyle->columnList[destCell->fromColumnIndex - 1]->space / 2.0f;
					}
					else if (groupIndex > 0)
					{
						TGroup* nextGroup = m_groupList[groupIndex - 1];
						TColumn *nextColumn = nextGroup->styleList[nextGroup->currentStyle]->columnList.back();

						expandWithOfLeft = m_groupSpace + nextColumn->space / 2.0f;
					}
				}
			}

			if (m_onScreenRange.endGroupInScrn == groupIndex)
			{
				TGroup *endGroup = m_groupList[groupIndex];
				TStyle *endStyle = endGroup->styleList[endGroup->currentStyle];
				TColumn *endCol = endStyle->columnList[m_onScreenRange.endColumnInScrn];

				bool flagNeedToExpand = false;

				if (endCol->startItemIndex <= itemIndex && endCol->endItemIndex >= itemIndex)
				{
					flagNeedToExpand = true;
				}
				else if (endCol->endItemIndex < itemIndex)
				{
					flagNeedToExpand = true;
				}
				else if (destCell->mergeState == STATE_MERGE_RESIZE)
				{
					if (destCell->toColumnIndex == m_onScreenRange.endColumnInScrn)
					{
						flagNeedToExpand = true;
					}	
				}

				if (true == flagNeedToExpand)
				{
					if ((int)destGroupStyle->columnList.size() - 1 > destCell->toColumnIndex)
					{
						TColumn *nextColumn = destGroupStyle->columnList[destCell->toColumnIndex + 1];
						TCell *firstCellInNextColumn = nextColumn->cellList[0];

						if ((int)destGroup->itemList.size() > firstCellInNextColumn->itemIndex)
						{
							expandWithOfRight = nextColumn->space / 2.0f;
						}
					}
					else if ((int)m_groupList.size() - 1 > groupIndex)
					{
						TGroup* nextGroup = m_groupList[groupIndex + 1];
						TColumn *nextColumn = nextGroup->styleList[nextGroup->currentStyle]->columnList[0];
						TCell *firstCellInNextColumn = nextColumn->cellList[0];

						if ((int)nextGroup->itemList.size() > firstCellInNextColumn->itemIndex)
						{						
							expandWithOfRight = m_groupSpace + nextColumn->space / 2.0f;
						}
					}
				}
			}
		}

		if ((0.0f != expandWithOfLeft && 0.0f != expandWithOfRight)
			||
			(0.0f == expandWithOfLeft && 0.0f == expandWithOfRight))
		{
			t_SetFocusBar(focusImgRect, newItem, flagFocusBarAni, flagScrollAni);
		}
		else
		{
			TRect destFocusBarRect = newItem->rect;

			if (TYPE_VERTICAL == m_scrollDirectionType)
			{
				if (0.0f != expandWithOfLeft)
				{
					destFocusBarRect.y -= expandWithOfLeft;
					focusImgRect.y += expandWithOfLeft;
				}
				else if (0.0f != expandWithOfRight)
				{
					destFocusBarRect.h += expandWithOfRight;
				}
			} 
			else
			{
				if (0.0f != expandWithOfLeft)
				{
					destFocusBarRect.x -= expandWithOfLeft;
					focusImgRect.x += expandWithOfLeft;
				}
				else if (0.0f != expandWithOfRight)
				{
					destFocusBarRect.w += expandWithOfRight;
				}
			}

			t_SetFocusBar(focusImgRect, destFocusBarRect, newItem, flagFocusBarAni, flagScrollAni);
		}
	}

	void CGridListControl::m_InitItemIndex(void)
	{
		size_t groupCount = m_groupList.size();
		for (size_t i = 0; i < groupCount; i++)
		{
			TGroup* group = m_groupList.at(i);
			size_t styleCount = group->styleList.size();
			for (size_t m = 0; m < styleCount; m++)
			{
				TStyle *style = group->styleList.at(m);
				style->rectList.clear();
				int itemIndex = 0;
				size_t columnCount = style->columnList.size();
				for (size_t j = 0; j < columnCount; j++)
				{
					TColumn* column = style->columnList.at(j);

					column->startItemIndex = itemIndex;

					size_t cellCount = column->cellList.size();
					for (size_t k = 0; k < cellCount; k++)
					{
						TCell* cell = column->cellList.at(k);

						if (cell->mergeState < STATE_MERGE_HIDDEN)//if the cell is merged hidden, then it should not be numbered
						{
							style->itemIndexToCell.insert(std::make_pair(itemIndex, cell));
							column->cellList[k]->itemIndex = itemIndex++;

							style->rectList.push_back(cell->rect);

							if (STATE_MERGE_RESIZE != cell->mergeState)
							{
								cell->fromColumnIndex = j;
								cell->toColumnIndex = j;
							}
						}
					}

					column->endItemIndex = itemIndex - 1;
				}
			}
		}
	}

	bool CGridListControl::m_MoveFocus(EDirection direction, int fromGroupIndex, int fromItemIndex)
	{
		if (false == t_flagShowFocusBar)
		{
			return false;
		}

		if (true == t_IsOnAnimation(ITEM_SCROLL_ANI | ITEM_STYLE_ANI | LOOP_ANI))
		{
			return false;
		}

		EDirection logicalDirection = direction;

		if (TYPE_VERTICAL == m_scrollDirectionType)
		{
			if (DIRECTION_LEFT == direction)
			{
				logicalDirection = DIRECTION_UP;
			}
			else if (DIRECTION_RIGHT == direction)
			{
				logicalDirection = DIRECTION_DOWN;
			}
			else if (DIRECTION_DOWN == direction)
			{
				logicalDirection = DIRECTION_RIGHT;
			}
			else if (DIRECTION_UP == direction)
			{
				logicalDirection = DIRECTION_LEFT;
			}
		}
		else
		{
			if (ORIENTATION_RIGHT_TO_LEFT == Orientation(true))
			{
				if (DIRECTION_LEFT == direction)
				{
					logicalDirection = DIRECTION_RIGHT;
				}
				else if (DIRECTION_RIGHT == direction)
				{
					logicalDirection = DIRECTION_LEFT;
				}
			}
		}
		
		int destFocusGroupIndex = -2, destFocusItemIndex = -2;
		int destFocusColumnIndex;

		TCell* focusedCell = m_GetCellByItemIndex(fromGroupIndex, fromItemIndex);
		
		if (m_refXForFocusMoving == -1)
		{
			m_refXForFocusMoving = focusedCell->rect.x;
		}
		else if (m_refXForFocusMoving == -2)
		{
			m_refXForFocusMoving = -1;
		}
		
		if (m_refYForFocusMoving == -1)
		{
			m_refYForFocusMoving = focusedCell->rect.y;
		}
		else if (m_refYForFocusMoving == -2)
		{
			m_refYForFocusMoving = -1;
		}		
		
		TGroup* focusedGroup = m_groupList.at(fromGroupIndex);
		TStyle* style = focusedGroup->styleList.at(focusedGroup->currentStyle);
		int focusedColumnIndex = focusedCell->columnIndex;
		if (focusedCell->mergeState == STATE_MERGE_RESIZE && m_flagStraightPath)
		{
			for (int i = focusedCell->columnIndex; i <= focusedCell->toColumnIndex; i++)
			{
				if (style->columnList[i]->startPos == m_refXForFocusMoving)
				{
					focusedColumnIndex = i;
					break;
				}
			}
		}
		
		TColumn* focusedColumn = style->columnList[focusedColumnIndex];

		switch (logicalDirection)
		{
		case DIRECTION_UP:
			if (focusedCell->indexInColumn == 0) //means the item is the top item of current column
			{
				destFocusItemIndex = -1;
			}
			else
			{
				int destItemIndexInColumn = focusedCell->indexInColumn - 1;
				TCell* nextCell = focusedColumn->cellList.at(destItemIndexInColumn);
				if (nextCell->mergeState == STATE_MERGE_HIDDEN)
				{
					TColumn* realColumn = style->columnList.at(nextCell->fromColumnIndex);
					TCell* realCell = realColumn->cellList.at(nextCell->fromRowIndex);
					destFocusItemIndex = realCell->itemIndex;
					m_refYForFocusMoving = realCell->rect.y;
				}
				else
				{
					destFocusItemIndex = nextCell->itemIndex;//m_focusItemIndex - 1
					m_refYForFocusMoving = nextCell->rect.y;
				}
			}
			destFocusGroupIndex = m_focusGroupIndex;
			break;

		case DIRECTION_DOWN:
			{
				destFocusGroupIndex = m_focusGroupIndex;

				TCell* nextCell = NULL;

				int destItemIndexInColumn = focusedCell->indexInColumn + 1;

				if (destItemIndexInColumn >= (int)focusedColumn->cellList.size() || m_focusItemIndex == ItemCount(m_focusGroupIndex) - 1)
				{
					destFocusItemIndex = -1;
					if (m_focusItemIndex == ItemCount(m_focusGroupIndex) - 1)
					{
						destFocusColumnIndex = focusedColumnIndex - 1;

						//m_GetNearestItem(focusedCell, destFocusGroupIndex, destFocusColumnIndex, destFocusItemIndex);
						TCell* cellBelow = m_FindCellBellow(focusedCell, destFocusGroupIndex, destFocusColumnIndex);
						if (cellBelow != NULL)
						{
							destFocusItemIndex = cellBelow->itemIndex;

							m_refXForFocusMoving = cellBelow->rect.x;
							m_refYForFocusMoving = cellBelow->rect.y;
						}
					}
				}
				else
				{
					for (nextCell = focusedColumn->cellList.at(destItemIndexInColumn);
						destItemIndexInColumn < (int)focusedColumn->cellList.size();
						destItemIndexInColumn++)
					{
						nextCell = focusedColumn->cellList.at(destItemIndexInColumn);

						if (STATE_MERGE_HIDDEN == nextCell->mergeState)
						{
							TColumn* realColumn = style->columnList.at(nextCell->fromColumnIndex);
							TCell* realCell = realColumn->cellList.at(nextCell->fromRowIndex);

							if (realCell->indexInColumn != focusedCell->indexInColumn)
							{
								nextCell = realCell;
								break;
							}
						}
						else
						{
							break;
						}
					}

					if (destItemIndexInColumn >= (int)focusedColumn->cellList.size())
					{
						destFocusItemIndex = -1;
					}
					else
					{
						destFocusItemIndex = nextCell->itemIndex;
						m_refYForFocusMoving = nextCell->rect.y;
					}
				}
			}

			break;

		case DIRECTION_LEFT:
			if (focusedCell->columnIndex == 0)//first column of the group
			{
				if (m_focusGroupIndex == 0)// first group
				{
					if (t_flagLoopLeft)
					{
						destFocusGroupIndex = (int)m_groupList.size() - 1;
						destFocusColumnIndex = m_groupList.at(destFocusGroupIndex)->styleList.at(m_groupList.at(destFocusGroupIndex)->currentStyle)->columnList.size() - 1;
						m_GetNearestItem(focusedCell, destFocusGroupIndex, destFocusColumnIndex, destFocusItemIndex);
						int minCount = HALO_MIN((int)m_groupList[destFocusGroupIndex]->itemList.size(), m_dataSource->NumOfData(destFocusGroupIndex));
						while (destFocusItemIndex >= minCount)
						{
							//loop to find the valid destination focus item.
							destFocusColumnIndex--;
							m_GetNearestItem(focusedCell, destFocusGroupIndex, destFocusColumnIndex, destFocusItemIndex);
						}

						TGridListItem *destFocusItem = m_groupList[destFocusGroupIndex]->itemList[destFocusItemIndex];

						if (destFocusItem->flagEnable == false)//if the item is disabled, then loop to find the nearest enabled item
						{
							while (destFocusItemIndex > 0)
							{
								destFocusItemIndex--;
								destFocusItem = m_groupList[destFocusGroupIndex]->itemList[destFocusItemIndex];
								if (destFocusItem->flagEnable)
								{
									break;
								}			
							}
							m_refXForFocusMoving = m_refYForFocusMoving = -1;
						}
					
						TPoint focusBarOutOffset;
						TPoint itemGroupOutOffset;

						if (TYPE_VERTICAL == m_scrollDirectionType)
						{
							focusBarOutOffset.Set(0.0f, -30.0f);
							itemGroupOutOffset.Set(0.0f, 300.0f);
						}
						else
						{
							focusBarOutOffset.Set(-30.0f, 0.0f);
							itemGroupOutOffset.Set(300.0f, 0.0f);
						}

						int m_focusGroupIndexBak = m_focusGroupIndex;
						int m_focusItemIndexBak = m_focusItemIndex;

						m_focusGroupIndex = destFocusGroupIndex;
						m_focusItemIndex = destFocusItemIndex;

						if (t_FadeInOut(destFocusItem, destFocusItem->rect, focusBarOutOffset, itemGroupOutOffset, true))
						{
							return true;
						}
						else
						{
							m_focusGroupIndex = m_focusGroupIndexBak;
							m_focusItemIndex = m_focusItemIndexBak;
							return false;
						}
					}
					else
					{
						destFocusItemIndex = -1;
					}
				}
				else
				{
					destFocusGroupIndex = m_focusGroupIndex - 1;
					destFocusColumnIndex = m_groupList.at(destFocusGroupIndex)->styleList.at(m_groupList.at(destFocusGroupIndex)->currentStyle)->columnList.size() - 1;

					m_GetNearestItem(focusedCell, destFocusGroupIndex, destFocusColumnIndex, destFocusItemIndex);
				}
			}
			else //not the first column of group
			{
				destFocusGroupIndex = m_focusGroupIndex;
				destFocusColumnIndex = focusedCell->columnIndex - 1;

				m_GetNearestItem(focusedCell, destFocusGroupIndex, destFocusColumnIndex, destFocusItemIndex);
			}
			break;

		case DIRECTION_RIGHT:

			int focusedColumnIndex;
			if (focusedCell->mergeState == STATE_MERGE_RESIZE)
			{
				focusedColumnIndex = focusedCell->toColumnIndex;
			}
			else
			{
				focusedColumnIndex = focusedCell->columnIndex;
			}
			if (focusedColumnIndex == (int)style->columnList.size() - 1)//last column of the group
			{
				if (m_focusGroupIndex == (int)m_groupList.size() - 1)//last group
				{
					if (t_flagLoopRight)
					{
						destFocusGroupIndex = 0;
						destFocusColumnIndex = 0;
						m_GetNearestItem(focusedCell, destFocusGroupIndex, destFocusColumnIndex, destFocusItemIndex);

						TGridListItem *destFocusItem = m_groupList[destFocusGroupIndex]->itemList[destFocusItemIndex];
						if (destFocusItem->flagEnable == false)//if the item is disabled, then loop to find the nearest enabled item
						{
							while (destFocusColumnIndex < (int)focusedGroup->styleList[focusedGroup->currentStyle]->columnList.size() - 1)
							{
								destFocusColumnIndex++;
								m_GetNearestItem(focusedCell, destFocusGroupIndex, destFocusColumnIndex, destFocusItemIndex);
								destFocusItem = m_groupList[destFocusGroupIndex]->itemList[destFocusItemIndex];
								if (destFocusItem->flagEnable)
								{
									break;
								}
							}
							m_refXForFocusMoving = m_refYForFocusMoving = -1;
						}

						TPoint focusBarOutOffset;
						TPoint itemGroupOutOffset;

						if (TYPE_VERTICAL == m_scrollDirectionType)
						{
							focusBarOutOffset.Set(0.0f, 30.0f);
							itemGroupOutOffset.Set(0.0f, -300.0f);
						}
						else
						{
							focusBarOutOffset.Set(30.0f, 0.0f);
							itemGroupOutOffset.Set(-300.0f, 0.0f);
						}

						int m_focusGroupIndexBak = m_focusGroupIndex;
						int m_focusItemIndexBak = m_focusItemIndex;

						m_focusGroupIndex = destFocusGroupIndex;
						m_focusItemIndex = destFocusItemIndex;

						if (t_FadeInOut(destFocusItem, destFocusItem->rect, focusBarOutOffset, itemGroupOutOffset, true))
						{
							return true;
						}
						else
						{
							m_focusGroupIndex = m_focusGroupIndexBak;
							m_focusItemIndex = m_focusItemIndexBak;
							return false;
						}
					}
					else
					{
						destFocusItemIndex = -1;
					}
				}
				else //not the last group
				{
					destFocusGroupIndex = m_focusGroupIndex + 1;
					destFocusColumnIndex = 0;

					m_GetNearestItem(focusedCell, destFocusGroupIndex, destFocusColumnIndex, destFocusItemIndex);
				}
			}
			else //not the last column of group
			{
				destFocusGroupIndex = m_focusGroupIndex;
				destFocusColumnIndex = focusedColumnIndex + 1;

				m_GetNearestItem(focusedCell, destFocusGroupIndex, destFocusColumnIndex, destFocusItemIndex);

				if (t_flagLoopRight)
				{
					//in loop mode, if destination focus item index is larger than item list count, keep moving to next column
					int minCount = HALO_MIN((int)m_groupList[destFocusGroupIndex]->itemList.size(), m_dataSource->NumOfData(destFocusGroupIndex));
					if (destFocusItemIndex >= minCount)
					{
						return m_MoveFocus(direction, destFocusGroupIndex, destFocusItemIndex);
					}
				}
			}
			break;

		default:
			break;
		}

		if (destFocusGroupIndex >= 0 && destFocusItemIndex >= (int)m_groupList[destFocusGroupIndex]->itemList.size())
		{
			destFocusItemIndex = -1;
		}

		if (destFocusItemIndex == -1)
		{
			CGridListControlListenerSet::TGridListListenerData data;
			data.type = EVENT_MOVE_OUT;
			data.param[0] = direction;
			data.param[1] = m_focusGroupIndex;
			data.param[2] = m_focusItemIndex;
			m_listenerSet->Process(&data);
			return false;
		}

		if (m_groupList.at(destFocusGroupIndex)->itemList.at(destFocusItemIndex)->flagEnable == false)
		{
			m_refXForFocusMoving = m_refYForFocusMoving = -2; //set reference value to -2 for item disabled case.
			return m_MoveFocus(direction, destFocusGroupIndex, destFocusItemIndex);
		}
		else
		{
			m_canMove = false;
			t_flagMouse = false;
			m_SetFocus(destFocusGroupIndex, destFocusItemIndex, true, true);
		}

		return true;
	}

	void CGridListControl::m_GetNearestItem(TCell* focusedCell, int destGroupIndex, int destColumnIndex, int &destItemIndex)
	{
		TStyle* style = m_groupList.at(destGroupIndex)->styleList.at(m_groupList.at(destGroupIndex)->currentStyle);
		TColumn* nextColumn = style->columnList.at(destColumnIndex);

		float yDis = t_listHeight;
		TCell* nextCell = nextColumn->cellList.front();
		size_t cellCount = nextColumn->cellList.size();
		for (size_t i = 0; i < cellCount; i++)
		{
			TCell *cell = nextColumn->cellList.at(i);
			if (cell->itemIndex >= (int)m_groupList[destGroupIndex]->itemList.size())
			{
				break;
			}

			if (TYPE_VERTICAL == m_scrollDirectionType)
			{
				float tempXDis;
				if (m_flagStraightPath)
				{
					tempXDis = abs(cell->rect.x - m_refXForFocusMoving);
				}
				else
				{
					tempXDis = abs(cell->rect.x - focusedCell->rect.x);
				}

				if (tempXDis < yDis)
				{
					yDis = tempXDis;
					nextCell = cell;
					if (yDis == 0)
					{
						break;
					}
				}
			} 
			else
			{
				float tempYDis;
				if (m_flagStraightPath)
				{
					tempYDis = abs(cell->rect.y - m_refYForFocusMoving);
				}
				else
				{
					tempYDis = abs(cell->rect.y - focusedCell->rect.y);
				}

				if (tempYDis < yDis)
				{
					yDis = tempYDis;
					nextCell = cell;
					if (yDis == 0)
					{
						break;
					}
				}
			}
		}

		if (nextCell->mergeState == STATE_MERGE_HIDDEN)
		{
			TColumn* realColumn = style->columnList.at(nextCell->fromColumnIndex);
			TCell* realCell = realColumn->cellList.at(nextCell->fromRowIndex);
			destItemIndex = realCell->itemIndex;

			m_refXForFocusMoving = realCell->rect.x;
		}
		else
		{
			destItemIndex = nextCell->itemIndex;

			m_refXForFocusMoving = nextCell->rect.x;
			m_refYForFocusMoving = nextCell->rect.y;
		}
	}

	void CGridListControl::m_AddRowToColumn(int groupIndex, int styleIndex, int columnIndex, float rowHeight)
	{
		TGroup *group = m_groupList.at(groupIndex);
		TStyle *style = group->styleList.at(styleIndex);
		TColumn *column = style->columnList.at(columnIndex);

		int currentRowNumInCol = column->cellList.size();
		float newAddSpace = (currentRowNumInCol == 0 ? rowHeight : rowHeight + m_cellSpace);

		float listLength = ((TYPE_VERTICAL == m_scrollDirectionType) ? t_listWidth : t_listHeight);

		if (column->usedLength + newAddSpace > listLength)
		{
			ASSERT(false && "there is no more space in the column to add the rows");
		}
		else
		{
			column->usedLength += newAddSpace;
		}

		TCell* newCell = new TCell;
		if (TYPE_VERTICAL == m_scrollDirectionType)
		{
			newCell->rect.x = column->usedLength - rowHeight;
			newCell->rect.y = column->startPos;
			newCell->rect.w = rowHeight;
			newCell->rect.h = column->space;
		}
		else
		{
			newCell->rect.x = column->startPos;
			newCell->rect.y = column->usedLength - rowHeight;
			newCell->rect.w = column->space;
			newCell->rect.h = rowHeight;
		}

		newCell->columnIndex = columnIndex;
		newCell->indexInColumn = currentRowNumInCol;
		newCell->itemIndex = -1;
		newCell->mergeState = STATE_NORMAL;
		newCell->fromColumnIndex = -1;
		newCell->fromRowIndex = -1;
		newCell->toColumnIndex = -1;
		newCell->toRowIndex = -1;

		column->cellList.push_back(newCell);
	}

	int CGridListControl::m_ColumnNumberInGroup(int groupIndex)
	{
		TGroup* group = m_groupList.at(groupIndex);
		return group->styleList.at(group->currentStyle)->columnList.size();
	}

	void CGridListControl::m_MoveItem(int groupIndex, int fromItemIndex, int toItemIndex)
	{
		if (fromItemIndex == toItemIndex)
		{
			return;
		}
		m_dragItemIndex = toItemIndex;
		TGroup* group = m_groupList[groupIndex];

		TRect toItemRect = group->itemList[toItemIndex]->rect;
		if (fromItemIndex < toItemIndex)
		{
			for (int i = toItemIndex; i > fromItemIndex; i--)
			{
				group->itemList[i]->rect = group->itemList[i - 1]->rect;
				group->itemList[i]->indexInGroup--;
				t_RefreshItemPosition(group->itemList[i], m_dragItemTrans);
			}
		}
		else if (fromItemIndex > toItemIndex)
		{
			for (int i = toItemIndex; i < fromItemIndex; i++)
			{
				group->itemList[i]->rect = group->itemList[i + 1]->rect;
				group->itemList[i]->indexInGroup++;
				t_RefreshItemPosition(group->itemList[i], m_dragItemTrans);
			}
		}

		m_dragItemTrans->Play();

		group->itemList[fromItemIndex]->rect = toItemRect;
		group->itemList[fromItemIndex]->indexInGroup = toItemIndex;

		TGridListItem* fromItem = group->itemList[fromItemIndex];
		group->itemList.erase(group->itemList.begin() + fromItemIndex);
		group->itemList.insert(group->itemList.begin() + toItemIndex, fromItem);
		//TRect fromRect = group->styleList[group->currentStyle]->rectList[fromItemIndex];
		//group->styleList[group->currentStyle]->rectList.erase(group->styleList[group->currentStyle]->rectList.begin() + fromItemIndex);
		//group->styleList[group->currentStyle]->rectList.insert(group->styleList[group->currentStyle]->rectList.begin() + toItemIndex, fromRect);

	}

	void CGridListControl::m_GetItemsInRange(TRange range, int reason, std::set<TItem*> &itemList)
	{
		for (int i = range.startGroupIndex; i <= range.endGroupIndex; i++)
		{
			TGroup* group = m_groupList[i];
			int styleIndex = reason == STYLE_ANIMATION ? group->lastStyle : group->currentStyle;
			TStyle* style = group->styleList.at(styleIndex);
			int startColumnIndex = (i == range.startGroupIndex) ? range.startColumnIndex : 0;
			int endColumnIndex = (i == range.endGroupIndex) ? range.endColumnIndex : style->columnList.size() - 1;

			for (int m = startColumnIndex; m <= endColumnIndex; m++)
			{
				TColumn* column = style->columnList.at(m);
				for (int j = 0; j < (int)column->cellList.size(); j++)
				{
					TCell* cell = column->cellList[j];
					if (cell->mergeState < STATE_MERGE_HIDDEN && cell->itemIndex < (int)group->itemList.size())
					{
						itemList.insert(group->itemList.at(cell->itemIndex));
					}
				}
			}
		}
	}

	bool CGridListControl::t_OnEnterKeyLongPressed(void)
	{
		CGridListControlListenerSet::TGridListListenerData data;
		data.type = EVENT_ENTER_KEY_LONG_PRESSED;
		data.param[0] = m_focusGroupIndex;
		data.param[1] = m_focusItemIndex;
		m_listenerSet->Process(&data);

		return true;
	}

	void CGridListControl::t_OnRegisterAnimationCallback(ITimeLine *timeLine, EAniEventType aniCallbackType)
	{
		CMultiObjectTransition *trans = dynamic_cast<CMultiObjectTransition*>(timeLine);

		if (NULL != trans)
		{
			if (m_dragItemTrans == timeLine)
			{
				if (ANI_FINISH == aniCallbackType)
				{
					m_flagItemDraged = false;
				}
			}
		}
	}

	bool CGridListControl::t_GetItemsNeedFoveaAni(const TItem *hitItem, std::vector<TItem*> &itemArray, TValue2f cursorCenter, float cursorRadius)
	{
		if (true == m_flagItemDraged || t_flagEditable)
		{
			return false;
		}

		if (m_isSunken)
		{
			return false;
		}

		const TGridListItem *hitGridItem = dynamic_cast<const TGridListItem*>(hitItem);
		ASSERT_RETURN(NULL != hitGridItem, false);

		TGroup* group = m_groupList.at(hitGridItem->groupIndex);
		int styleIndex = group->currentStyle;
		TStyle* style = group->styleList.at(styleIndex);

		std::map<int, TCell*>::iterator x = style->itemIndexToCell.find(hitGridItem->indexInGroup);
		ASSERT_RETURN(style->itemIndexToCell.end() != x, false);

		TCell *cell = x->second;
		ASSERT_RETURN(NULL != cell, false);

		for (int i = cell->fromColumnIndex; i >= 0; i--)
		{
			bool flagHited = false;

			TColumn *column = style->columnList[i];
			for (int j = 0; j < (int)column->cellList.size(); j++)
			{
				TCell *curCell = column->cellList[j];

				if (0 <= curCell->itemIndex)
				{
					TValue2f center(curCell->rect.x + curCell->rect.w / 2.0f, curCell->rect.y + curCell->rect.h / 2.0f);

					TRect tempRect(center.val[0], center.val[1], 0.0f, 0.0f);
					center = t_GetRealPointBaseItemGroup(tempRect, t_itemGroupRect);

					float cellRadius = HALO_MIN(curCell->rect.w, curCell->rect.h) / 2.0f;
					float distance = sqrt((center.val[0] - cursorCenter.val[0]) * (center.val[0] - cursorCenter.val[0]) + (center.val[1] - cursorCenter.val[1]) * (center.val[1]- cursorCenter.val[1]));
					if (cellRadius + cursorRadius > distance)
					{
						TItem *item = group->itemList[curCell->itemIndex];
						if (NULL != item->renderer)
						{
							itemArray.push_back(item);
						}

						flagHited = true;
					}
				}
			}
			
			if (false == flagHited)
			{
				break;
			}
		}
		
		int colmunCnt = style->columnList.size();
		for (int i = HALO_MAX(cell->toColumnIndex, cell->fromColumnIndex + 1); i < colmunCnt; i++)
		{
			bool flagHited = false;

			TColumn *column = style->columnList[i];
			for (int j = 0; j < (int)column->cellList.size(); j++)
			{
				TCell *curCell = column->cellList[j];

				if (0 <= curCell->itemIndex)
				{
					TValue2f center(curCell->rect.x + curCell->rect.w / 2.0f, curCell->rect.y + curCell->rect.h / 2.0f);

					TRect tempRect(center.val[0], center.val[1], 0.0f, 0.0f);
					center = t_GetRealPointBaseItemGroup(tempRect, t_itemGroupRect);

					float cellRadius = HALO_MIN(curCell->rect.w, curCell->rect.h) / 2.0f;
					float distance = sqrt((center.val[0] - cursorCenter.val[0]) * (center.val[0] - cursorCenter.val[0]) + (center.val[1] - cursorCenter.val[1]) * (center.val[1]- cursorCenter.val[1]));
					if (cellRadius + cursorRadius > distance)
					{
						TItem *item = group->itemList[curCell->itemIndex];
						if (NULL != item->renderer)
						{
							itemArray.push_back(item);
						}

						flagHited = true;
					}
				}
			}

			if (false == flagHited)
			{
				break;
			}
		}
		
		return true;
	}

	void CGridListControl::SetBufferColumnSize(int left, int right)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridListControl::SetBufferColumnSize with left: " << left << ", right: " << right);
		m_leftBufferColumnNum = left;
		m_rightBufferColumnNum = right;
	}

	void CGridListControl::ClearDataSource(int groupIndex)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridListControl::ClearDataSource of groupIndex: " << groupIndex);
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		
		m_dataSource->DeleteGroup(groupIndex);
		for (size_t i = 0; i < m_groupList[groupIndex]->itemList.size(); i++)
		{
			m_groupList[groupIndex]->itemList[i]->data = NULL;
		}
	}

	bool CGridListControl::IsSetMarginWhenFocusEdgeItem(void) const
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridListControl::IsSetMarginWhenFocusEdgeItem!");
		return m_flagUseMarginWhenFocusEdgeItem;
	}

	void CGridListControl::EnableMarginWhenFocusEdgeItem(const bool flagEnable)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridListControl::EnableMarginWhenFocusEdgeItem with flag: " << flagEnable);

		m_flagUseMarginWhenFocusEdgeItem = flagEnable;
	}

	void CGridListControl::SetCheckToThumbnailOfGroup(int groupIndex, bool flagChecked)
	{
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());

		TGroup *group = m_groupList.at(groupIndex);

		for (int i = 0; i < (int)group->itemList.size(); i++)
		{
			TItem *item = group->itemList.at(i);

			if (NULL != item && NULL != item->renderer && NULL != item->renderer->Thumbnail())
			{
				item->renderer->Thumbnail()->SetChecked(flagChecked);
			}
		}
	}

	void CGridListControl::SetCheckToThumbnailOfItem(int groupIndex, int itemIndex, bool flagChecked)
	{
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		TGroup *group = m_groupList.at(groupIndex);

		ASSERT(itemIndex >= 0 && itemIndex < (int)group->itemList.size());
		TItem *item = group->itemList.at(itemIndex);

		if (NULL != item && NULL != item->renderer && NULL != item->renderer->Thumbnail())
		{
			item->renderer->Thumbnail()->SetChecked(flagChecked);
		}
	}

	bool CGridListControl::IsThumbnailChecked(int groupIndex, int itemIndex)
	{
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		TGroup *group = m_groupList.at(groupIndex);

		ASSERT(itemIndex >= 0 && itemIndex < (int)group->itemList.size());
		TItem *item = group->itemList.at(itemIndex);

		if (NULL != item && NULL != item->renderer && NULL != item->renderer->Thumbnail())
		{
			return item->renderer->Thumbnail()->IsChecked();
		}
		else
		{
			return false;
		}
	}

	void CGridListControl::EnableThumbnailStyleOfGroup(int groupIndex, IThumbnail::EThumbnailStyle style, bool flagEnable, bool flagAni)
	{
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());

		TGroup *group = m_groupList.at(groupIndex);

		for (int i = 0; i < (int)group->itemList.size(); i++)
		{
			TItem *item = group->itemList.at(i);

			if (true == flagEnable)
			{
				item->visibleThumbStyle = (item->visibleThumbStyle | style);
				item->disVisibleThumbStyle = (item->disVisibleThumbStyle & (~style));
			}
			else
			{
				item->visibleThumbStyle = (item->visibleThumbStyle & (~style));
				item->disVisibleThumbStyle = (item->disVisibleThumbStyle | style);
			}

			if (NULL != item->renderer)
			{
				IThumbnail *thumb = item->renderer->Thumbnail();
				if (NULL != thumb)
				{
					thumb->EnableThumbnailStyle(flagEnable, style, flagAni);
				}
			}
		}
	}

	void CGridListControl::EnableThumbnailStyleOfItem(int groupIndex, int itemIndex, IThumbnail::EThumbnailStyle style, bool flagEnable, bool flagAni)
	{
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		TGroup *group = m_groupList.at(groupIndex);

		ASSERT(itemIndex >= 0 && itemIndex < (int)group->itemList.size());
		TItem *item = group->itemList.at(itemIndex);

		if (true == flagEnable)
		{
			item->visibleThumbStyle = (item->visibleThumbStyle | style);
			item->disVisibleThumbStyle = (item->disVisibleThumbStyle & (~style));
		}
		else
		{
			item->visibleThumbStyle = (item->visibleThumbStyle & (~style));
			item->disVisibleThumbStyle = (item->disVisibleThumbStyle | style);
		}

		if (NULL != item->renderer)
		{
			IThumbnail *thumb = item->renderer->Thumbnail();
			if (NULL != thumb)
			{
				thumb->EnableThumbnailStyle(flagEnable, style, flagAni);
			}
		}
	}
	
	bool CGridListControl::IsThumbnailStyleEnabled(int groupIndex, int itemIndex, IThumbnail::EThumbnailStyle style)
	{
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		TGroup *group = m_groupList.at(groupIndex);

		ASSERT(itemIndex >= 0 && itemIndex < (int)group->itemList.size());
		TItem *item = group->itemList.at(itemIndex);

		bool ret = false;

		if (NULL == item->renderer)
		{
			ret = (0 != (item->visibleThumbStyle & style));
		}
		else
		{
			IThumbnail *thumb = item->renderer->Thumbnail();

			if (NULL != thumb)
			{
				//Todo
			}
			else
			{
				ret = false;
			}
		}

		return ret;
	}

	void CGridListControl::SelectThumbnailCheckBoxOfGroup(int groupIndex, bool flagSelect)
	{
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		TGroup *group = m_groupList.at(groupIndex);

		for (int i = 0; i < (int)group->itemList.size(); i++)
		{
			TItem *item = group->itemList.at(i);

			if (NULL == item->renderer)
			{
				item->flagCheckBoxSelected = flagSelect;
			}
			else
			{
				IThumbnail *thumb = item->renderer->Thumbnail();
				if (NULL != thumb)
				{
					//Todo
				}
			}
		}
	}
	
	void CGridListControl::SelectThumbnailCheckBoxOfItem(int groupIndex, int itemIndex, bool flagSelect)
	{
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		TGroup *group = m_groupList.at(groupIndex);

		ASSERT(itemIndex >= 0 && itemIndex < (int)group->itemList.size());
		TItem *item = group->itemList.at(itemIndex);

		if (NULL == item->renderer)
		{
			item->flagCheckBoxSelected = flagSelect;
		}
		else
		{
			IThumbnail *thumb = item->renderer->Thumbnail();
			if (NULL != thumb)
			{
				//Todo
			}
		}
	}

	bool CGridListControl::IsThumbnailCheckBoxSelected(int groupIndex, int itemIndex)
	{
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		TGroup *group = m_groupList.at(groupIndex);

		ASSERT(itemIndex >= 0 && itemIndex < (int)group->itemList.size());
		TItem *item = group->itemList.at(itemIndex);

		bool ret = false;

		if (NULL == item->renderer)
		{
			ret = item->flagCheckBoxSelected;
		}
		else
		{
			IThumbnail *thumb = item->renderer->Thumbnail();

			if (NULL != thumb)
			{
				ret = thumb->IsChecked();
			}
		}

		return ret;
	}

	int CGridListControl::GetThumbnailStyleOfItem(int groupIndex, int itemIndex)
	{
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		TGroup *group = m_groupList.at(groupIndex);

		ASSERT(itemIndex >= 0 && itemIndex < (int)group->itemList.size());
		TItem *item = group->itemList.at(itemIndex);

		if (NULL == item->renderer)
		{
			return item->visibleThumbStyle;
		}
		else
		{
			IThumbnail *thumb = item->renderer->Thumbnail();

			if (NULL == thumb)
			{
				return 0;
			}
			else
			{
				return thumb->ThumbnailStyle();
			}
		}
	}

	EDirectionType CGridListControl::ScrollDirection(void)
	{
		return m_scrollDirectionType;
	}

	IRenderer* CGridListControl::Renderer(int groupIndex, int itemIndex)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridListControl::Renderer of groupIndex: " << groupIndex<< ", itemIndex: " <<itemIndex);

		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());
		ASSERT(itemIndex >= 0 && itemIndex < (int)m_groupList[groupIndex]->itemList.size());

		return m_groupList[groupIndex]->itemList[itemIndex]->renderer;
	}

	void CGridListControl::GetOnScreenRange(int &startGroupIndex, int &startItemIndex, int &endGroupIndex, int &endItemIndex)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridListControl::GetOnScreenRange!");

		startGroupIndex = m_onScreenRange.startGroupInScrn;
		TGroup* startGroup = m_groupList[startGroupIndex];
		TColumn* startColumn = startGroup->styleList[startGroup->currentStyle]->columnList[m_onScreenRange.startColumnInScrn];
		TCell* startCell = startColumn->cellList.front();
		if (startCell->mergeState == STATE_MERGE_HIDDEN)
		{
			startColumn = startGroup->styleList[startGroup->currentStyle]->columnList[startCell->fromColumnIndex];
			startCell = startColumn->cellList[startCell->fromRowIndex];
		}
		startItemIndex = startCell->itemIndex;
		//startItemIndex = startColumn->startItemIndex;

		endGroupIndex = m_onScreenRange.endGroupInScrn;
		TGroup* endGroup = m_groupList[endGroupIndex];
		TColumn* endColumn = endGroup->styleList[endGroup->currentStyle]->columnList[m_onScreenRange.endColumnInScrn];
		TCell* endCell = endColumn->cellList.back();
		if (endCell->mergeState == STATE_MERGE_HIDDEN)
		{
			endColumn = endGroup->styleList[endGroup->currentStyle]->columnList[endCell->fromColumnIndex];
			endCell = endColumn->cellList[endCell->fromRowIndex];
		}
		endItemIndex = endCell->itemIndex;
		//endItemIndex = endColumn->endItemIndex;

		if (startItemIndex >= (int)startGroup->itemList.size())
		{
			startItemIndex = startGroup->itemList.size() - 1;
		}
		if (endItemIndex >= (int)endGroup->itemList.size())
		{
			endItemIndex = endGroup->itemList.size() - 1;
		}
	}

	int CGridListControl::ItemCount(int groupIndex)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridListControl::ItemCount , groupIndex = " << groupIndex);
		ASSERT(groupIndex >= 0 && groupIndex < (int)m_groupList.size());

		return m_groupList[groupIndex]->itemList.size();
	}

	CGridListControl::TCell* CGridListControl::m_FindCellBellow(TCell* fromCell, int destGroupIndex, int destColumnIndex)
	{
		if (destGroupIndex < 0 || destGroupIndex >= (int)m_groupList.size())
		{
			return NULL;
		}
		
		TGroup* destGroup = m_groupList[destGroupIndex];
		TStyle* destStyle = destGroup->styleList[destGroup->currentStyle];

		if (destColumnIndex < 0 || destColumnIndex >= (int)destStyle->columnList.size())
		{
			return NULL;
		}

		TColumn* destColumn = destStyle->columnList[destColumnIndex];

		for (size_t i = 0; i < destColumn->cellList.size(); i++)
		{
			TCell* cell = destColumn->cellList[i];
			if (cell->rect.y > fromCell->rect.y && cell->rect.y + cell->rect.h > fromCell->rect.y + fromCell->rect.h)
			{
				if (cell->mergeState == STATE_MERGE_HIDDEN)
				{
					int realCellColumnIndex = cell->fromColumnIndex;
					int realCellRowIndex = cell->fromRowIndex;
					cell = destStyle->columnList[realCellColumnIndex]->cellList[realCellRowIndex];
					if (cell->rect.y > fromCell->rect.y && cell->rect.y + cell->rect.h > fromCell->rect.y + fromCell->rect.h)
					{
						return cell;
					}
				}
				else
				{
					return cell;
				}
			}
		}
		
		return NULL;
	}

	void CGridListControl::EnableStraightPathOnFocusMoving(const bool flagStraightPath)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridListControl::EnableStraightPathOnFocusMoving with flag: " << flagStraightPath);

		m_flagStraightPath = flagStraightPath;
	}

	bool CGridListControl::IsStraightPathOnFocusMovingEnabled(void) const
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridListControl::IsStraightPathOnFocusMovingEnabled");

		return m_flagStraightPath;
	}

	const char* CGridListControl::GetActorType(void)
	{
		return "GridListControl";
	}

	void CGridListControl::t_UpdateOrientation(EOrientation orientation)
	{
		for (size_t i = 0; i < m_groupList.size(); i++)
		{
			TGroup* group = m_groupList[i];
			for (size_t j = 0; j < group->itemList.size(); j++)
			{
				TGridListItem* item = group->itemList[j];
				t_RefreshItemPosition(item, NULL);
			}

			float w, h;
			group->title->GetSize(w, h);

			TRect titleRect;
			titleRect.Set(group->styleList[group->currentStyle]->startPos, 0.0f, w, h);

			TValue2f realValue = t_GetRealPointBaseItemGroup(titleRect, t_itemGroupRect);
			group->title->SetPosition(realValue.val[0], realValue.val[1]);
		}

		
		CDataListControl::t_UpdateOrientation(orientation);
	}

	void CGridListControl::EnableRolloverEffect(const bool flagRolloverEffect)
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridListControl::EnableRolloverEffect with flag: " << flagRolloverEffect);

		m_flagRolloverEffect = flagRolloverEffect;
	}

	bool CGridListControl::IsRolloverEffectEnabled(void) const
	{
		H_LOG_TRACE(LOGGER, "[0x" << std::hex << this << "]CGridListControl::IsRolloverEffectEnabled");

		return m_flagRolloverEffect;
	}

	int CGridListControl::m_ScrollThumbnailImage(gpointer data)
	{
		//First: get a random item index on screen.
		CGridListControl* pThis = (CGridListControl*)data;
		//srand((unsigned)time(NULL));
		unsigned seed = (unsigned)time(NULL);
		int startGroup, startItem, endGroup, endItem;
		pThis->GetOnScreenRange(startGroup, startItem, endGroup, endItem);
#ifdef WIN32
		int groupIndex = rand() % (endGroup - startGroup + 1) + startGroup;
#else
		int groupIndex = rand_r(&seed) % (endGroup - startGroup + 1) + startGroup;
#endif
		int fromItemIndex = groupIndex == startGroup ? startItem : 0;
		int toItemIndex = groupIndex == endGroup ? endItem : pThis->ItemCount(groupIndex);
#ifdef WIN32		
		int itemIndext = rand() % (toItemIndex - fromItemIndex + 1) + fromItemIndex;
#else	
		int itemIndext = rand_r(&seed) % (toItemIndex - fromItemIndex + 1) + fromItemIndex;
#endif
		TGridListItem* itemRandom;
		itemRandom = pThis->m_groupList.at(groupIndex)->itemList.at(itemIndext);
		if (itemRandom->renderer != NULL && itemRandom->renderer->Thumbnail() != NULL)
		{
			itemRandom->renderer->Thumbnail()->ScrollImage();
		}
		
		return 1;
	}

	void CGridListControl::StartScrollTimer(void)
	{
		m_timerId = clutter_threads_add_timeout(m_timerInterval, m_ScrollThumbnailImage, this);
	}

	void CGridListControl::StopScrollTimer(void)
	{
		if (m_timerId > 0)
		{
			g_source_remove(m_timerId);
			m_timerId = -1;
		}
	}

	void CGridListControl::SetTimerInterval(const int timeInterval)
	{
		m_timerInterval = timeInterval;
	}

	int CGridListControl::TimerInterval(void) const
	{
		return m_timerInterval;
	}

	int CGridListControl::GroupCount(void)
	{
		return m_groupList.size();
	}

	void CGridListControl::TStyle::ResetPosition(float positionOffset)
	{
		startPos += positionOffset;
		endPos += positionOffset;
		size_t columnCount = columnList.size();
		for (size_t i = 0; i < columnCount; ++i)
		{
			TColumn* column = columnList.at(i);
			column->startPos += positionOffset;
			column->endPos += positionOffset;
			size_t columnCount = column->cellList.size();
			for (size_t j = 0; j < columnCount; ++j)
			{
				column->cellList.at(j)->rect.x += positionOffset;
			}
		}
	}
}


