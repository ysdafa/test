#ifndef _HALO_CTEXT_H_
#define _HALO_CTEXT_H_

namespace HALO
{
	class CText : virtual public IText, public CActor
	{
	public:
		CText();
		virtual ~CText();

		// Create the text.
		virtual bool Initialize(IActor *parent, float width, float height);
		virtual bool Initialize(Widget *parent, float width, float height);

		// Set the text content.
 		virtual void SetText(const char *text);

		// Get the text content.
 		virtual const char* Text(void);

 		// Set the text color.
 		virtual void SetTextColor(const ClutterColor& color);

 		// Get the text color.
		virtual const ClutterColor& TextColor(void);

 		// Set font by the name.
 		virtual void SetFont(const char* fontName);

		// Get text font name.
		virtual const char* Font(void);

 		// Set the alignment of the text.
 		virtual void SetTextAlignment(EHAlignment hAlign, EVAlignment vAlign);

		// Get text alignment.
 		virtual void GetTextAlignment(EHAlignment& hAlign, EVAlignment& vAlign);

 		// Set TextLine Mode:single/multi.
 		virtual void EnableMultiLine(bool flagMultiLineMode);

 		// Get TextLine Mode.
 		virtual bool IsMultiLineEnabled(void);

 		// Set the gap between rows.
 		virtual void SetRowGap(int gap);

 		// Get the gap between rows.
 		virtual int RowGap(void);

 		// Set the maximum drawing text count.
 		virtual void SetMaxTextCount(int textCount);

 		// Get the maximum drawing text count.
 		virtual int MaxTextCount(void);

		// Set the font size.
 		virtual void SetFontSize(int size);

		// Get the font size.
 		virtual int FontSize(void);

 		// Set Enable Text Shadow.
 		virtual void EnableShadow(bool flagEnable);

		// Get Enable Text Shadow.
 		virtual bool IsShadowEnabled(void);

		// Set Text Shadow Position.
 		virtual void SetShadowPosition(int x, int y);

		// Get Text Shadow Position.
 		virtual void GetShadowPosition(int& x, int& y);

		// Set Text Shadow color.
 		virtual void SetShadowColor(int a, int r, int g, int b);

		// Set Text Shadow color.
 		virtual void SetShadowColor(ClutterColor color);

		// Get Text Shadow color.
 		virtual void GetShadowColor(int& a, int& r, int& g, int& b);

		// Set Text Shadow color.
		virtual const ClutterColor& ShadowColor(void);

		// Get the text actor.
		virtual ClutterText* TextActor(void);

		// Set the position.
		virtual void SetPosition(float x, float y);

		// Resize the text.
		virtual void Resize(float width, float height);

		// Set Scale Attrs.
		virtual void SetScaleAttribute(guint scaled_size, guint duration, guint delay, ClutterAnimationMode ani_mode);

		// Set scaled size.
		virtual void SetScaleSize(guint scale_size);

		// Start text Scale.
		virtual void StartScaleText(void);

		// Stop text Scale.
		virtual void StopScaleText(void);

		// Set scroll Attrs.
		virtual void SetScrollAttribute(guint duration, guint delay, gint repeat, ClutterTextScrollType type, ClutterTimelineDirection direction, guint continueGap);
		
		// Start text scroll.
		virtual void StartScrollText(void);

		// Stop text scroll.
		virtual void StopScrollText(void);

		// Set enable ellipsize.
		virtual void EnableEllipsize(bool flagEnable);

		// Get enable ellipsize state.
		virtual bool IsEllipsizeEnable(void);

		// Set Text attribute.
		virtual bool SetCharFormat(T_STYLE style);

		// Get text preferred height
		virtual float PreferredHeight(float width);

		virtual const char* GetActorType(void);
		
		// Get text line number.
		virtual int LineCount(void);

		// Get text line height.
		virtual int LineHeight(int index);

	private:

		// The text color
		ClutterColor m_textColor;

		// The really text object.
		ClutterText* m_text;

		// The scale clutter for scale animation
		ClutterTextScalingAnimation* m_textScale;

		// The scroll clutter for scroll animation
		ClutterActor* m_textScroll;

		// The Font size
		int m_fontSize;

		// Horizontal alignment.
		EHAlignment m_hAlignment;

		// Vertical alignment
		EVAlignment m_vAlignment;

		// The g_single id to handle the paint for shadow.
 		gulong m_shadowPaintId;

		// The ellipsize enable state
		bool m_enableEllipsize;

		// The pango attribute list
		PangoAttrList* m_pangoAttrList;
		// The text attribute state
		int m_pangoAttrState;

		// Layout manager for text.
		ClutterLayoutManager* m_textLayout;

		// Text layout allocation box.
		ClutterActorBox m_textAllocationBox;

		// Text Row Gap
		int m_rowGap;

		// The state whether scroll animation has started.
		bool m_IsScrollStartFlag;

		// The state for setText when text is doing scroll animation.
		bool m_hasScrollStartFlag;

		// The single-line/multi-line flag before scroll start.
		bool m_preScrollStartMultiLineFlag;

		// The ellipsis enable flag before scroll start.
		bool m_preScrollStartEllipsisFlag;

 		struct T_Shadow_Attr
 		{
 			bool shadowFlag;				// The flag whether it's shadow.
 			ClutterColor shadowColor;		// The color of the shadow.
 			int shadowXPos;					// The xPos of the shadow.
 			int shadowYPos;					// The yPos of the shadow.
 		};
 		T_Shadow_Attr m_shadowAttr;			// The shadow attribute object.

		struct T_Animation_Scale_Attr
		{
			guint scaled_size;				// The scale font size.
			guint duration;					// The scale duration.
			guint delay;					// The delay rate.
			ClutterAnimationMode ani_mode;	// The scale animation mode.
		};
		T_Animation_Scale_Attr m_animationScaleAttr;	// The scale animation attribute.

		struct T_Animation_Scroll_Attr
		{
			ClutterTextScrollType type;			// The scroll animation type.
			ClutterTimelineDirection direction;	// The scroll animation direction.
			guint delay;						// The scroll animation delay rate.
			guint duration;						// The scroll animation duration.
			gint repeat;						// The scroll animation repeat times.
			guint continueGap;					// The scroll animation continue gap.
		};
		T_Animation_Scroll_Attr m_animationScrollAttr;	// The scroll animation attribute.

		// Render the shadow text.
 		static void m_shadow_text_paint(ClutterActor *actor, gpointer user_data);
		
		// Update text size.
		void m_updateTextSize(void);

		void m_updateTextAttribute(void);
	};

} /* namespace HALO */
#endif /* _HALO_CTEXT_H_ */
