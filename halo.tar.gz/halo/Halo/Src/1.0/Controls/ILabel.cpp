#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	ILabel* ILabel::CreateInstance(IActor* parent, float width, float height)
	{
		CLabel* label = dynamic_cast<CLabel*>(Instance::CreateInstance(CLASS_ID_ILABEL));
		ASSERT(label != NULL);

		if (NULL != label)
		{
			label->Initialize(parent, width, height);
		}

		return label;
	}

	ILabel* ILabel::CreateInstance(Widget* parent, float width, float height)
	{
		CLabel* label = dynamic_cast<CLabel*>(Instance::CreateInstance(CLASS_ID_ILABEL));

		if (NULL != label)
		{
			label->Initialize(parent, width, height);
		}

		return label;
	}

}