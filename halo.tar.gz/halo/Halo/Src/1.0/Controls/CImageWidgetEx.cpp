#include "Halo1_0.h"
#include "VoltActor.h"

static HALO::util::Logger LOGGER("CImageWidgetEx");

namespace HALO
{
	CImageWidgetEx::CImageWidgetEx(float x, float y, Widget* parent, ImageWidgetReadyCallback ready) : ImageWidget(x, y, parent, ready)
	{
		//H_LOG_TRACE(LOGGER, "CImageWidgetEx::CImageWidgetEx()");
		t_CreateWidget();
		EOrientation systemOrientation = IUtility::GetInstance()->GetOrientation();
		if (systemOrientation == ORIENTATION_RIGHT_TO_LEFT)
		{
			//UpdateOrientation(systemOrientation);
			setX(x);
			setY(y);
		}
	}
	CImageWidgetEx::CImageWidgetEx(float x, float y, float width, float height, Widget* parent, ImageWidgetReadyCallback ready) : ImageWidget(x, y, width, height, parent, ready)
	{
		//H_LOG_TRACE(LOGGER, "CImageWidgetEx::CImageWidgetEx()");
		t_CreateWidget();
		setX(x);
		setY(y);
		setWidth(width);
		setHeight(height);
		setParent(parent);

	}

	CImageWidgetEx::~CImageWidgetEx(void)
	{
		//H_LOG_TRACE(LOGGER, "CImageWidgetEx::~CImageWidgetEx()");
	}

	//bool CImageWidgetEx::Initialize(ClutterActor* parent, float width, float height)
	//{
	//	H_LOG_TRACE(LOGGER, "CImageWidgetEx::Initialize. with ClutterActor type parent:" << parent);
	//	bool retVal = Initialize((Widget*)NULL, width, height);
	//	return retVal;
	//}

	//bool CImageWidgetEx::Initialize(Widget* parent, float width, float height)
	//{
	//	H_LOG_TRACE(LOGGER, "CImageWidgetEx::Initialize. parent " << parent << "width " << width << "height " << height);

	//	t_CreateWidget();

	//	H_LOG_TRACE(LOGGER, "CImageWidgetEx::Initialize. Ok !");
	//	return true;
	//}

	//bool CImageWidgetEx::Initialize(IActor* parent, float width, float height)
	//{
	//	H_LOG_TRACE(LOGGER, "CImageWidgetEx::Initialize. with IActor type parent:" << parent);
	//	Widget *w;
	//	w = dynamic_cast<Widget*>(parent);
	//	
	//	return Initialize(w, width, height);
	//}

	//X
	float CImageWidgetEx::getX() const
	{
		float x = Widget::getX();
		//H_LOG_TRACE(LOGGER, "CImageWidgetEx::getX(). x :" << x);
		if (IsReversible())
		{
			if (ParentWidgetExtension())
			{
				if (ORIENTATION_RIGHT_TO_LEFT == ParentWidgetExtension()->Orientation(true))
				{
					if (getParent())
					{
						x = getParent()->Widget::getWidth() - x - Widget::getWidth();
						H_LOG_TRACE(LOGGER, "CImageWidgetEx::getX(). Reversed x :" << x);
					}
				}
			}
			else
			{
				if (IUtility::GetInstance() && IUtility::GetInstance()->GetOrientation() == ORIENTATION_RIGHT_TO_LEFT)
				{
					Widget* parent = getParent();
					if (parent)
					{
						float parentWidth = parent->Widget::getWidth();
						float thisWidth = Widget::getWidth();
						if (parentWidth && thisWidth)
						{
							x = parentWidth - x - thisWidth;
							H_LOG_TRACE(LOGGER, "CWidgetEx::getX(). Reversed x :" << x);
						}
					}
				}
			}
		}

		x = t_MultiResolutionConvert1920(x);
		if (m_origX != FLT_MAX)
		{
			if (abs(x - m_origX) < 1.0f)
			{
				return m_origX;
			}
			H_LOG_WARN(LOGGER, "Value was changed not by Halo, please check it!");
		}
		return x;
	}

	void CImageWidgetEx::setX(float x)
	{
		m_origX = x;
		//H_LOG_TRACE(LOGGER, "CImageWidgetEx::setX(). x :" << x);
		x = t_1920ConvertMultiResolution(x);
		if (IsReversible())
		{
			IWidgetExtension* parentWidgetExtension = ParentWidgetExtension();
			if (parentWidgetExtension)
			{
				if (ORIENTATION_RIGHT_TO_LEFT == parentWidgetExtension->Orientation(true))
				{
					Widget* parent = getParent();
					if (parent)
					{
						float parentWidth = parent->Widget::getWidth();
						float thisWidth = Widget::getWidth();
						if (parentWidth && thisWidth)
						{
							x = parentWidth - x - thisWidth;
							H_LOG_TRACE(LOGGER, "CImageWidgetEx::setX(). Reversed x :" << x);
						}
					}
				}
			}
			else
			{
				if (IUtility::GetInstance() && IUtility::GetInstance()->GetOrientation() == ORIENTATION_RIGHT_TO_LEFT)
				{
					Widget* parent = getParent();
					if (parent)
					{
						float parentWidth = parent->Widget::getWidth();
						float thisWidth = Widget::getWidth();
						if (parentWidth && thisWidth)
						{
							x = parentWidth - x - thisWidth;
							H_LOG_TRACE(LOGGER, "CImageWidgetEx::setX(). Reversed x :" << x);
						}
					}
				}
			}
		}
		Widget::setX(x);
	}

	//Y
	float CImageWidgetEx::getY() const
	{
		float y = Widget::getY();
		//H_LOG_TRACE(LOGGER, "CImageWidgetEx::getY(). y :" << y);

		y = t_MultiResolutionConvert1920(y);	

		if (m_origY != FLT_MAX)
		{
			if (abs(y - m_origY) < 1.0f)
			{
				return m_origY;
			}
			H_LOG_WARN(LOGGER, "Value was changed not by Halo, please check it!");
		}
		return y;
	}

	void CImageWidgetEx::setY(float y)
	{
		m_origY = y;
		//H_LOG_TRACE(LOGGER, "CImageWidgetEx::setY(). y :" << y);

		y = t_1920ConvertMultiResolution(y);

		Widget::setY(y);
	}
	
	//Width
	float CImageWidgetEx::getWidth() const
	{
		float width = ImageWidget::getWidth();
		//H_LOG_TRACE(LOGGER, "CImageWidgetEx::getWidth(). width :" << width);

		width = t_MultiResolutionConvert1920(width);	

		if (m_origWidth != FLT_MAX)
		{
			if (abs(width - m_origWidth) < 1.0f)
			{
				return m_origWidth;
			}
			H_LOG_WARN(LOGGER, "Value was changed not by Halo, please check it!");
		}

		return width;
	}
	void CImageWidgetEx::setWidth(float width)
	{
		//H_LOG_TRACE(LOGGER, "CImageWidgetEx::setWidth(). width :" << width);
		if (width != -1)
		{
			width = t_1920ConvertMultiResolution(width);
			if (width != Widget::getWidth())
			{
				if (IsReversible())
				{
					IWidgetExtension* parentWidgetExtension = ParentWidgetExtension();
					if (parentWidgetExtension)
					{
						if (parentWidgetExtension->Orientation(true) == ORIENTATION_RIGHT_TO_LEFT)
						{
							if (Widget::getWidth())
							{
								float realX = Widget::getX();
								float offset = width - Widget::getWidth();
								if (offset)
								{
									Widget::setX(realX - offset);
									H_LOG_TRACE(LOGGER, "CImageWidgetEx::setWidth(). offset X:" << offset==0?0:-offset);
								}
							}
						}
					}
					else if (IUtility::GetInstance())
					{
						if (IUtility::GetInstance()->GetOrientation() == ORIENTATION_RIGHT_TO_LEFT)
						{
							if (Widget::getWidth())
							{
								float realX = Widget::getX();
								float offset = width - Widget::getWidth();
								if (offset)
								{
									Widget::setX(realX - offset);
									H_LOG_TRACE(LOGGER, "CImageWidgetEx::setWidth(). offset X:" << offset==0?0:-offset);
								}
							}
						}
					}
				}
				Widget::setWidth(width);
			}
		}	
		else
		{
			Widget::setWidth(width);
			m_origWidth = Widget::getWidth();
			m_origWidth = t_MultiResolutionConvert1920(m_origWidth);
		}
	}

	//Height
	float CImageWidgetEx::getHeight() const
	{
		float height = Widget::getHeight();
		//H_LOG_TRACE(LOGGER, "CImageWidgetEx::getHeight(). height :" << height);

		height = t_MultiResolutionConvert1920(height);	

		if (m_origHeight!= FLT_MAX)
		{
			if (abs(height - m_origHeight) < 1.0f)
			{
				return m_origHeight;
			}
			H_LOG_WARN(LOGGER, "Value was changed not by Halo, please check it!");
		}

		return height;
	}

	void CImageWidgetEx::setHeight(float height)
	{
		//H_LOG_TRACE(LOGGER, "CImageWidgetEx::setHeight(). height :" << height);
		
		if (height != -1)
		{
			m_origHeight = height;
			height = t_1920ConvertMultiResolution(height);	
		}
		
		Widget::setHeight(height);		
	}

	int CImageWidgetEx::addChild(Widget* child, int index)
	{
		//save old orientation
		EOrientation oldOrientation = ORIENTATION_REFER_TO_PARENT;
		CWidgetExtension* childWidgetExtension = NULL;

		if (child)
		{
			childWidgetExtension = D_GET_HALO_WIDGET_EXTENSION(G_OBJECT(child->getAnimationActor()));
			if (childWidgetExtension)
			{
				oldOrientation = childWidgetExtension->Orientation(true);
			}
		}

		if (childWidgetExtension)
		{
			if (childWidgetExtension->ParentWidgetExtension())
			{
				if (childWidgetExtension->ParentWidgetExtension()->Orientation(true) == ORIENTATION_RIGHT_TO_LEFT)
				{
					if (childWidgetExtension->IsReversible() == true)
					{
						Widget* oldParent = child->getParent();
						if (oldParent)
						{							
							float parentWidth = oldParent->Widget::getWidth();
							float childWidth = child->Widget::getWidth();
							if (parentWidth && childWidth)
							{
								float childX = child->Widget::getX();
								float newChildX = parentWidth - childX - childWidth;
								child->Widget::setX(newChildX);
							}
						}
					}
				}
			}
			else if (IUtility::GetInstance())
			{
				if (IUtility::GetInstance()->GetOrientation() == ORIENTATION_RIGHT_TO_LEFT)
				{
					if (childWidgetExtension->IsReversible() == true)
					{
						Widget* oldParent = child->getParent();
						if (oldParent)
						{
							float parentWidth = oldParent->Widget::getWidth();
							float childWidth = child->Widget::getWidth();
							if (parentWidth && childWidth)
							{
								float childX = child->Widget::getX();
								float newChildX = parentWidth - childX - childWidth;
								child->Widget::setX(newChildX);
							}
						}
					}
				}
			}
		}

		EOrientation newOrientation = Orientation(true);

		if (NULL != childWidgetExtension)
		{
			if (childWidgetExtension->Orientation(false) == ORIENTATION_REFER_TO_PARENT)
			{
				if (oldOrientation == newOrientation)
				{
					if (ORIENTATION_RIGHT_TO_LEFT == oldOrientation)
					{
						CWidgetEx *childEx = dynamic_cast<CWidgetEx*>(childWidgetExtension->t_widgetSelf);

						if (NULL != childEx)
						{
							float width = Widget::getWidth();
							float childWidth = childEx->Widget::getWidth();

							if (width && childWidth)
							{
								float childX = childEx->Widget::getX();
								childWidgetExtension->t_widgetSelf->setX(width - childX - childWidth);
							}
						}
					}
				}
			}
		}

		//add child to parent
		int ret = Widget::addChild(child, index);

		//change orientation

		if (NULL != childWidgetExtension)
		{
			if (childWidgetExtension->Orientation(false) == ORIENTATION_REFER_TO_PARENT)
			{
				if (Orientation(true) == ORIENTATION_RIGHT_TO_LEFT)
				{
					float parentWidth = Widget::getWidth();
					float childWidth = child->Widget::getWidth();
					if (parentWidth && childWidth)
					{
						float childX = child->Widget::getX();
						float newChildX = parentWidth - childX - childWidth;
						child->Widget::setX(newChildX);
					}
				}

				if (oldOrientation != newOrientation)
				{
					childWidgetExtension->t_OnOrientation(newOrientation);
				}
			}
		}
		return ret;
	}

	Widget* CImageWidgetEx::getParent() const
	{
		return parent;
	}

	void CImageWidgetEx::setParent(Widget* newParent)
	{
		Widget* parent = getParent();
		if (parent != newParent)
		{
			//If new parent is Widget, will call Widget::addChild()
			if (IsReversible())
			{
				if (newParent)
				{
					IWidgetExtension* parentWidgetExtension = D_GET_HALO_WIDGET_EXTENSION(G_OBJECT(newParent->getAnimationActor()));
					if (parentWidgetExtension == NULL)
					{
						IWidgetExtension* currentParent = ParentWidgetExtension();
						if (currentParent)
						{
							if (currentParent->Orientation(true) == ORIENTATION_RIGHT_TO_LEFT)
							{
								//setX(getX());
								Widget* parentWidget = getParent();
								if (parentWidget)
								{
									float parentWidth = parentWidget->Widget::getWidth();
									float thisWidth = Widget::getWidth();
									if (parentWidget && thisWidth)
									{
										float x = Widget::getX();
										float newX = parentWidth - x - thisWidth;
										Widget::setX(newX);
									}
								}
							}
						}
						else
						{
							if (IUtility::GetInstance())
							{
								if (IUtility::GetInstance()->GetOrientation() == ORIENTATION_RIGHT_TO_LEFT)
								{
									Widget* parentWidget = getParent();
									if (parentWidget)
									{
										float parentWidth = parentWidget->Widget::getWidth();
										float thisWidth = Widget::getWidth();
										if (parentWidth && thisWidth)
										{
											float x = Widget::getX();
											float newX = parentWidth - x - thisWidth;
											Widget::setX(newX);
										}
									}
								}
							}
						}
					}
				}
			}

			if (newParent != NULL)
			{
				newParent->addChild(this);
			}

			//If new parent is Widget, will call Widget::addChild()
			if (IsReversible())
			{
				if (newParent)
				{
					IWidgetExtension* parentWidgetExtension = ParentWidgetExtension();
					if (parentWidgetExtension == NULL)
					{
						if (IUtility::GetInstance())
						{
							if (IUtility::GetInstance()->GetOrientation() == ORIENTATION_RIGHT_TO_LEFT)
							{
								Widget* parentWidget = getParent();
								if (parentWidget)
								{
									float parentWidth = parentWidget->Widget::getWidth();
									float thisWidth = Widget::getWidth();
									if (parentWidth && thisWidth)
									{
										float x = Widget::getX();
										float newX = parentWidth - x - thisWidth;
										Widget::setX(newX);
									}
								}
							}
						}
					}
				}
			}
		}
	}

	const char* CImageWidgetEx::GetActorType(void)
	{
		return "ImageWidgetEx";
	}

	void CImageWidgetEx::GetAnimatableValue(int animationType, UValueElement &val)
	{
		ClutterActor *actor = t_widgetSelf->getAnimationActor();

		switch (animationType)
		{
		case ACTOR_ANI_POSITION_X:
			val.d = getX();
			break;

		case ACTOR_ANI_POSITION_Y:
			val.d = getY();
			break;

		case ACTOR_ANI_POSITION_Z:
			val.d = clutter_actor_get_z_position(actor);
			break;

		case ACTOR_ANI_ALPHA:
			val.i = clutter_actor_get_opacity(actor);
			break;

		case ACTOR_ANI_POSITION:
			{
				if (NULL == val.p)
				{
					val.p = new ClutterPoint;
				}

				clutter_point_init((ClutterPoint*)(val.p), getX(), getY());
			}
			break;

		case ACTOR_ANI_SIZE:
			{
				if (NULL == val.p)
				{
					val.p = new ClutterSize;
				}

				clutter_size_init((ClutterSize*)(val.p), getWidth(), getHeight());
			}
			break;

		case ACTOR_ANI_SCALE_X:
			{
				double scaleX, scaleY;
				clutter_actor_get_scale(actor, &scaleX, &scaleY);
				val.d = scaleX;
			}
			break;

		case ACTOR_ANI_SCALE_Y:
			{
				double scaleX, scaleY;
				clutter_actor_get_scale(actor, &scaleX, &scaleY);
				val.d = scaleY;
			}
			break;

		case ACTOR_ANI_SCALE_Z:
			val.d = clutter_actor_get_scale_z(actor);
			break;

		default:
			break;
		}
	}

	void CImageWidgetEx::SetPropertyValue(int animationType, UValueElement element)
	{
		ClutterActor *actor = t_widgetSelf->getAnimationActor();

		switch (animationType)
		{
		case ACTOR_ANI_POSITION_X:
			{
				setX((float)element.d);
			}
			break;

		case ACTOR_ANI_POSITION_Y:
			{
				setY((float)element.d);
			}
			break;

		case ACTOR_ANI_POSITION_Z:
			{
				float z = (float)element.d;
				clutter_actor_set_z_position(actor, z);
			}
			break;

		case ACTOR_ANI_ALPHA:
			{
				int alpha = element.i;
				clutter_actor_set_opacity(actor, alpha);
			}
			break;

		case ACTOR_ANI_POSITION:
			{
				ClutterPoint *point = (ClutterPoint*)(element.p);
				setX(point->x);
				setY(point->y);
			}
			break;

		case ACTOR_ANI_SIZE:
			{
				ClutterSize *size = (ClutterSize*)(element.p);
				setWidth(size->width);
				setHeight(size->height);
			}
			break;

		case ACTOR_ANI_SCALE_X:
			{
				double scaleX;
				double scaleY;

				clutter_actor_get_scale(actor, &scaleX, &scaleY);
				scaleX = element.d;

				clutter_actor_set_scale(actor, scaleX, scaleY);
			}
			break;

		case ACTOR_ANI_SCALE_Y:
			{
				double scaleX;
				double scaleY;

				clutter_actor_get_scale(actor, &scaleX, &scaleY);
				scaleY = element.d;

				clutter_actor_set_scale(actor, scaleX, scaleY);
			}
			break;

		case ACTOR_ANI_SCALE_Z:
			{
				double scaleZ = element.d;
				clutter_actor_set_scale_z(actor, scaleZ);
			}
			break;

		default:
			break;
		}
	}
}


