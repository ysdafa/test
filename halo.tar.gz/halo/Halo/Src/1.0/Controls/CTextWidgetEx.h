#ifndef _HALO_TEXTWIDGETEX_H_
#define _HALO_TEXTWIDGETEX_H_

namespace HALO
{
	class CTextWidgetEx : public TextWidget, virtual public CWidgetExtension 
	{
	public:
		CTextWidgetEx( float x, float y, std::string text, std::string fontName, Widget* parent = nullptr, Color textColor = Color(255, 255, 255, 255));
		virtual ~CTextWidgetEx(void);

		//bool Initialize(ClutterActor* parent, float width, float height); 
		//bool Initialize(Widget* parent, float width, float height);
		//bool Initialize(IActor* parent, float width, float height);

		//Overload for orientation
		/** X position (pixels)*/
		float getX() const;
		void setX(float x);
		float getY() const;
		void setY(float y);
		float getWidth() const;
		void setWidth(float width);
		float getHeight() const;
		void setHeight(float height);
		virtual int addChild(Widget* child, int index);
		virtual Widget* getParent() const;
		virtual void setParent(Widget* newParent);
		LayoutAlignment getHorizontalAlignment() const;
		void setHorizontalAlignment(LayoutAlignment);
		void setFontName(const std::string& fontName);
		//! Get actor type
		virtual const char* GetActorType(void);
		static void onResize(GObject* object, GParamSpec* paramSpec, gpointer data);
		void recalculateVerticalOffset();
		Vector2 getTextSize();

		virtual void GetAnimatableValue(int animationType, UValueElement &val);
		virtual void SetPropertyValue(int animationType, UValueElement element);

	protected:
		virtual void t_UpdateOrientation(EOrientation orientation);
	};
}


#endif
