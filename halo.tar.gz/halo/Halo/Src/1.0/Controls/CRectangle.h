#ifndef _HALO_CRECTANGLE_H_
#define _HALO_CRECTANGLE_H_

namespace HALO
{
	class CRectangle : virtual public IRectangle, public CActor
	{
	public:
		//! Default constructor of class CRectangle
		// default border thickness is 0, and border color is transparent
		CRectangle();
		//! Destructor of class CRectangle
		virtual ~CRectangle();

		virtual bool Initialize(IActor* parent, float width, float height);
		virtual bool Initialize(Widget* parent, float width, float height);

		//! override ReSize()
		virtual void Resize(float width, float height);
		//! Gets the size of the window
		virtual void GetSize(float &width, float &height);

		//! Sets the position without changing z position, and (0, 0) presents left-top within parent
		virtual void SetPosition(float x, float y);
		//! Gets the position of x,y
		virtual void GetPosition(float &x, float &y);

		//! Sets the position relative to parent, and (0, 0, 0) presents left-top within parent
		virtual void SetPosition(float x, float y, float z);
		//! Gets the position
		virtual void GetPosition(float &x, float &y, float &z);

	public:
		// interface IRectangle
		virtual void SetBorderThickness(float topThickness, float leftThickness, float bottomThichness, float rightThickness);
		virtual void GetBorderThickness(float &topThickness, float &leftThickness, float &bottomThichness, float &rightThickness);

		//! Get border color
		virtual const ClutterColor& BorderColor() const;
		//! Set border color
		virtual void SetBorderColor(const ClutterColor& color);

		virtual const char* GetActorType(void);

	private:
		ClutterActor* m_topBorder;
		ClutterActor* m_leftBorder;
		ClutterActor* m_bottomBorder;
		ClutterActor* m_rightBorder;
		float m_topBorderThickness;
		float m_leftBorderThickness;
		float m_bottomBorderThickness;
		float m_rightBorderThickness;
		ClutterColor  m_borderColor;
	};
}

#endif
