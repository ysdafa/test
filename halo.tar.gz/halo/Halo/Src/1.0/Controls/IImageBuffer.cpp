#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{

	IImageBuffer* IImageBuffer::CreateInstance(const char *fileName)
	{
		CImageBuffer* buffer = dynamic_cast<CImageBuffer*>(Instance::CreateInstance(CLASS_ID_IIMAGEBUFFER));

		if (NULL != buffer)
		{
			buffer->Initialize(fileName);
		}

		return buffer;
	}

	IImageBuffer* IImageBuffer::CreateInstance(const char *data, int len)
	{
		CImageBuffer* buffer = dynamic_cast<CImageBuffer*>(Instance::CreateInstance(CLASS_ID_IIMAGEBUFFER));

		if (NULL != buffer)
		{
			buffer->Initialize(data, len);
		}

		return buffer;
	}

	IImageBuffer* IImageBuffer::CreateInstance(IImageBuffer *image)
	{
		CImageBuffer* buffer = dynamic_cast<CImageBuffer*>(Instance::CreateInstance(CLASS_ID_IIMAGEBUFFER));

		if (NULL != buffer)
		{
			buffer->Initialize(image);
		}

		return buffer;
	}

}