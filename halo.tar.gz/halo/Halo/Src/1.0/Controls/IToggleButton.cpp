#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	IToggleButton* IToggleButton::CreateInstance(IActor* parent, const TToggleButtonAttr &attr)
	{
		CToggleButton* togglebutton = dynamic_cast<CToggleButton*>(Instance::CreateInstance(CLASS_ID_ITOGGLEBUTTON));

		if (NULL != togglebutton)
		{
			togglebutton->Initialize(parent, attr);
		}

		return togglebutton;
	}

}