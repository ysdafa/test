#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{
	static HALO::util::Logger LOGGER("IToolTip");

	IToolTip* IToolTip::CreateInstance(IActor* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "IToolTip::CreateInstance [" << width << "," << height << "]");
		CToolTip* tip = dynamic_cast<CToolTip*>(Instance::CreateInstance(CLASS_ID_ITOOLTIP));

		if (NULL != tip)
		{
			tip->Initialize(parent, width, height);
		}

		return tip;
	}

	IToolTip* IToolTip::CreateInstance(Widget* parent, float width, float height)
	{
		H_LOG_TRACE(LOGGER, "IToolTip::CreateInstance [" << width << "," << height << "]");
		CToolTip* tip = dynamic_cast<CToolTip*>(Instance::CreateInstance(CLASS_ID_ITOOLTIP));

		if (NULL != tip)
		{
			tip->Initialize(parent, width, height);
		}

		return tip;
	}
}