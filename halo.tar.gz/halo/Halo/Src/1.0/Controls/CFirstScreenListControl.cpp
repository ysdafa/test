#include "Halo1_0.h"

namespace HALO
{
	class CFirstScreenListControlListenerSet : public ListenerSet
	{
	public:
		struct TFirstScreenListListenerData
		{
			CFirstScreenListControl::E_FirstScrnListEventType type;
			int param[4];
			void* pData;
		};

		CFirstScreenListControlListenerSet(class CFirstScreenListControl* owner) :m_owner(owner){};
		virtual ~CFirstScreenListControlListenerSet(void){};

		virtual bool Process(TFirstScreenListListenerData* data);

	private:
		class CFirstScreenListControl* m_owner;
	};

	bool CFirstScreenListControlListenerSet::Process(TFirstScreenListListenerData* data)
	{
		bool ret = false;
		Lock();
		if (NULL != data)
		{
			ListenerList::iterator iter = m_list.begin();

			while (iter != m_list.end())
			{
				IFirstScreenListListener* listener = (IFirstScreenListListener*)(*iter);

				switch (data->type)
				{
				case CFirstScreenListControl::EVENT_FOCUS_CHANGE:
					//printf("[0x%p]CGridListControl::EVENT_FOCUS_CHANGE (%d, %d)Listener--start\n", m_owner, data->param[0], data->param[1]);
					//printf("[0x%p]CGridListControl::EVENT_FOCUS_CHANGE Listener--end\n", m_owner);
					break;
				case CFirstScreenListControl::EVENT_FOCUS_CHANGE_MOTION_START:
					//printf("[0x%p]CGridListControl::EVENT_FOCUS_CHANGE_MOTION_START (%d, %d)Listener--start\n", m_owner, data->param[0], data->param[1]);
					//printf("[0x%p]CGridListControl::EVENT_FOCUS_CHANGE_MOTION_START Listener--end\n", m_owner);
					break;
				case CFirstScreenListControl::EVENT_ITEM_LOAD:
					//printf("[0x%p]CGridListControl::EVENT_ITEM_LOAD (%d, %d)Listener--start\n", m_owner, data->param[0], data->param[1]);
					ret |= listener->OnMainMenuItemLoaded(m_owner, data->param[0]);
					//printf("[0x%p]CGridListControl::EVENT_ITEM_LOAD Listener--end\n", m_owner);
					break;
				case CFirstScreenListControl::EVENT_SCROLL_ITEM_LOAD:
					ret |= listener->OnScrollListItemLoaded(m_owner, data->param[0], data->param[1]);
					break;

				case CFirstScreenListControl::EVENT_SUB_ITEM_LOAD:
					//printf("[0x%p]CGridListControl::EVENT_ITEM_LOAD (%d, %d)Listener--start\n", m_owner, data->param[0], data->param[1]);
					ret |= listener->OnSubMenuItemLoaded(m_owner, data->param[0], data->param[1]);
					//printf("[0x%p]CGridListControl::EVENT_ITEM_LOAD Listener--end\n", m_owner);
					break;

				default:
					break;
				}
				if (m_list.empty())
				{
					break;
				}

				++iter;
			}
		}

		Unlock();
		return true;
	}

	//CMSubMenuList
	CMSubMenuList::CMSubMenuList(void)
	{
		m_dataSource = NULL;
		m_subListExpandAni = NULL;
		m_alphaAni = NULL;

		m_listener = NULL;
	}

	CMSubMenuList::~CMSubMenuList(void)
	{
		if (NULL != m_subListExpandAni)
		{
			m_subListExpandAni->Release();
		}

		if (NULL != m_alphaAni)
		{
			m_alphaAni->Release();
		}
	}

	bool CMSubMenuList::Initialize(IActor *parent, class CFirstScreenListControl *owner, int mainMenuIndex, float enlargeFocusItemSize, float width, float height, float titleHeight /* = 0 */, float titleSpace /* = 0 */)
	{
		TLinearListControlAttr attr(width, height, TYPE_HORIZONTAL);
		attr.titleHeight = titleHeight;
		attr.titleSpace = titleSpace;

		bool ret = t_Initialize(parent, attr);

		if (true == ret)
		{
			m_mainMenuIndex = mainMenuIndex;
			m_enlargeFocusItemSize = enlargeFocusItemSize;

			m_owner = owner;

			m_focusItemIndex = -1;

			m_flagExpanded = false;

			m_subListExpandAni = new TransitionBase;
			m_subListExpandAni->Initialize(false);
			BindTransition(m_subListExpandAni, ACTOR_ANI_SCALE_X);
			m_subListExpandAni->SetDuration(500);

			//m_owner->t_itemScrollAni->AddListener(this, NULL);
			m_alphaAni = new TransitionBase;
			m_alphaAni->Initialize(false);
			BindTransition(m_alphaAni, ACTOR_ANI_ALPHA);
		}

		return ret;
	}

	void CMSubMenuList::AddItem(float itemSpace)
	{
		t_AddItem(1, &itemSpace);
	}

	void CMSubMenuList::Expand(void)
	{
		std::vector<TItem*> itemList;
		std::vector<TRect> rectList;

		m_flagExpanded = true;

		m_alphaAni->SetDestination(255);
		m_alphaAni->Play();

		m_subListExpandAni->SetDestination(1.0f);
		m_subListExpandAni->Play();

		//handle sub item title
		CFirstScreenListControl::TMainMenuItem* mainItem = (CFirstScreenListControl::TMainMenuItem*)m_owner->t_itemList.at(m_mainMenuIndex);
		TLinearItem* subItemStart = t_itemList.at(0);
		m_owner->m_subTitle->SetScale(0.0f, 1.0f, 1.0f);
#ifdef VOLT22_SUPPORT
#else
		m_owner->m_subTitle->SetText(mainItem->subItemTitleList.at(subItemStart->index));
#endif
		m_owner->m_subTitle->SetPosition(mainItem->rect.x + subItemStart->rect.x + m_owner->t_itemGroupRect.x - subItemStart->rect.w / 2, m_owner->m_mainTitleHeight + m_owner->m_mainTitleSpace);
		m_owner->m_subTitle->Show();
		m_owner->m_subTitleScaleX->SetDestination(1.0f);
		m_owner->m_subTitleScaleX->Play();
	}

	void CMSubMenuList::Shrink(float scaleRatio)
	{
		m_alphaAni->SetDestination(0);
		m_alphaAni->Play();

		m_subListExpandAni->SetDestination(0.0f);
		m_subListExpandAni->Play();

		m_flagExpanded = false;
		m_owner->m_subTitleScaleX->SetDestination(scaleRatio);
		m_owner->m_subTitleScaleX->Play();
	}

	bool CMSubMenuList::FlagExpanded(void)
	{
		return m_flagExpanded;
	}

	void CMSubMenuList::SetDataSource(CSingleLineDataSource *dataSource)
	{
		m_dataSource = dataSource;
	}

	const char* CMSubMenuList::GetActorType(void)
	{		
		return "MSubMenuList";	
	}
	bool CMSubMenuList::t_OnMousePointerIn(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		TSubMenuItem *subItem = dynamic_cast<TSubMenuItem*>(item);
		if (NULL == subItem)
		{
			return true;
		}

		if (CFirstScreenListControl::SUB_ITEM_NORMAL != m_owner->m_subItemLeaveStatus)
		{
			return true;
		}

		if (m_owner->t_IsOnAnimation(ITEM_GROUP_POS_TRANS))
		{
			return true;
		}
		
		CFirstScreenListControl::TMainMenuItem* mainItem = (CFirstScreenListControl::TMainMenuItem*)m_owner->t_itemList.at(m_mainMenuIndex);
#ifdef VOLT22_SUPPORT
#else
		m_owner->m_subTitle->SetText(mainItem->subItemTitleList.at(subItem->index));
#endif
		m_owner->m_subTitle->SetPosition(mainItem->rect.x + subItem->rect.x + m_owner->t_itemGroupRect.x - m_owner->m_subTitleWidth / 2, m_owner->m_mainTitleHeight + m_owner->m_mainTitleSpace);
		m_owner->m_subTitle->Show();

		if (true == t_IsOnAnimation(LIST_ANI_TYPE_MAX) || true == m_subListExpandAni->IsPlaying())
		{
			return true;
		}

		float mouseX, mouseY;
		mouseX = ptrMouseEvent->GetX();
		mouseY = ptrMouseEvent->GetY();

		m_mouseX = mouseX;
		m_mouseY = mouseY;

		m_focusItemIndex = subItem->index;

		float w, h;
		item->window->GetSize(w, h);

		for (IActor *parent = item->window; NULL != parent; parent = parent->Parent())
		{
			float x, y;
			parent->GetPosition(x, y);

			double scaleX, scaleY, scaleZ;
			parent->GetScale(scaleX, scaleY, scaleZ);

			mouseX -= x;
			mouseY -= y;
		}

		subItem->MouseMoveTo(mouseX, mouseY, m_enlargeFocusItemSize);

		return true;
	}

	bool CMSubMenuList::t_OnMousePointerOut(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		return true;
	}

	bool CMSubMenuList::t_OnMouseMoved(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		if (CFirstScreenListControl::SUB_ITEM_NORMAL != m_owner->m_subItemLeaveStatus)
		{
			return true;
		}

		if (true == t_IsOnAnimation(LIST_ANI_TYPE_MAX)|| true == m_subListExpandAni->IsPlaying())
		{
			return true;
		}

		if (m_owner->t_IsOnAnimation(ITEM_GROUP_POS_TRANS))
		{
			return true;
		}

		TSubMenuItem *subItem = dynamic_cast<TSubMenuItem*>(item);
		if (NULL == subItem)
		{
			return true;
		}
		
		float mouseX, mouseY;
		mouseX = ptrMouseEvent->GetX();
		mouseY = ptrMouseEvent->GetY();

		m_mouseX = mouseX;
		m_mouseY = mouseY;

		m_focusItemIndex = subItem->index;
		
		float w, h;
		item->window->GetSize(w, h);

		for (IActor *parent = item->window; NULL != parent; parent = parent->Parent())
		{
			float x, y;
			parent->GetPosition(x, y);

			double scaleX, scaleY, scaleZ;
			parent->GetScale(scaleX, scaleY, scaleZ);

			mouseX -= x;
			mouseY -= y;
		}

		subItem->MouseMoveTo(mouseX, mouseY, m_enlargeFocusItemSize);

		TItem* mainItem = m_owner->t_itemList.at(m_mainMenuIndex);

		m_owner->m_subTitle->SetPosition(mainItem->rect.x + subItem->rect.x + m_owner->t_itemGroupRect.x + mouseX - m_owner->m_subTitleWidth / 2, m_owner->m_mainTitleHeight + m_owner->m_mainTitleSpace);

		return true;
	}

	bool CMSubMenuList::t_MouseButtonPressed(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		if (0 <= m_focusItemIndex)
		{
			if (CFirstScreenListControl::SUB_ITEM_NORMAL == m_owner->m_subItemLeaveStatus)
			{
				m_owner->PlaySubItemLeaveAni(m_mainMenuIndex, m_focusItemIndex);
			}
			else if (CFirstScreenListControl::SUB_ITEM_LEAF == m_owner->m_subItemLeaveStatus)
			{
				m_owner->PlaySubItemEntranceAni(m_mainMenuIndex, m_focusItemIndex);
			}
		}

		return true;
	}

	bool CMSubMenuList::t_MoveFocusBar(EDirection direction)
	{
		return true;
	}

	void CMSubMenuList::t_BindDataListToItemList(void)
	{
		for (int i = 0; i < (int)t_itemList.size(); i++)
		{
			t_itemList[i]->data = m_dataSource->GetData(i);
		}

		t_UpdateInMemoryItems(true);
	}

	CMSubMenuList::TLinearItem* CMSubMenuList::t_AllocLinearItem(void)
	{
		return new TSubMenuItem(this);
	}

	void CMSubMenuList::t_FreeLinearItem(TLinearItem *item)
	{

	}

	void CMSubMenuList::t_GetRealItems(TLinearItem *item, std::vector<TItem*> &itemList)
	{
		itemList.push_back(item);
	}

	void CMSubMenuList::t_GetItemWindowPivotPoint(TItem *item, float &pivotX, float &pivotY, float &pivotZ)
	{
		pivotX = 0.5f;
		pivotY = 0.5f;
		pivotZ = 0.5f;
	}

	void CMSubMenuList::t_OnItemDataUnload(TItem *item)
	{
		m_listener->OnSubItemUnload(m_mainMenuIndex, item);
	}

	void CMSubMenuList::t_OnItemDataSyncLoad(TItem *item)
	{
		TSubMenuItem *subItem = (TSubMenuItem*)item;

		subItem->window->SetPivotPoint(subItem->xPivot, 0.0f, 1.0f);
		subItem->window->SetScale(subItem->scaleRatio, subItem->scaleRatio, 1.0f);

		m_listener->OnSubItemSyncLoad(m_mainMenuIndex, item);
	}

	void CMSubMenuList::t_OnItemDataAsyncLoad(TItem *item)
	{
		TSubMenuItem *subItem = (TSubMenuItem*)item;

		subItem->window->SetPivotPoint(subItem->xPivot, 0.0f, 1.0f);
		subItem->window->SetScale(subItem->scaleRatio, subItem->scaleRatio, 1.0f);

		m_listener->OnSubItemASyncLoad(m_mainMenuIndex, item);
	}

	void CMSubMenuList::t_FocusChangeStart(const TItem *from, const TItem *to)
	{

	}

	void CMSubMenuList::t_FocusChangeFinish(const TItem *from, const TItem *to)
	{

	}

	TValue2f CMSubMenuList::t_GetRealPointBaseItemGroup(TRect rect, TRect baseOnRect)
	{
		TValue2f point(rect.x, rect.y);
		return point;
	}

	TValue2f CMSubMenuList::t_GetLogicalPosition(TRect rect, TRect baseOnRect)
	{
		TValue2f point(rect.x, rect.y);
		return point;
	}

	TRect CMSubMenuList::t_InitRectOfLoadingItem(TItem *item, int reason)
	{
		return item->rect;
	}

	bool CMSubMenuList::OnNewFrame(class ITimeLine *animation, double currentProgress, void *data)
	{
		if (m_mainMenuIndex != m_owner->m_curExpanedMainItem)
		{
			return false;
		}

		float itemGroupX, itemGroupY;
		m_owner->t_itemGroup->GetPosition(itemGroupX, itemGroupY);
		float mouseToRootX = m_mouseX - itemGroupX;

		int subItemIndex = -1;
		CFirstScreenListControl::TMainMenuItem* mainItem = (CFirstScreenListControl::TMainMenuItem*)m_owner->t_itemList.at(m_mainMenuIndex);
		for (int j = 0; j < (int)t_itemList.size(); j++)
		{
			TItem* subItem = t_itemList.at(j);
			if (mouseToRootX > mainItem->rect.x + subItem->rect.x && mouseToRootX < mainItem->rect.x + subItem->rect.x + subItem->rect.w)
			{
				subItemIndex = j;
				break;
			}
		}

		if (subItemIndex == -1)
		{
			m_owner->m_subTitle->Hide();
		}
		else
		{
			m_owner->m_subTitle->Show();
			if (subItemIndex != m_focusItemIndex)
			{
				TSubMenuItem* subItem = (TSubMenuItem*)t_itemList.at(subItemIndex);
#ifdef VOLT22_SUPPORT
#else
				m_owner->m_subTitle->SetText(mainItem->subItemTitleList.at(subItem->index));
#endif
				m_focusItemIndex = subItemIndex;
			}
		}

		return true;
	}



	void CMSubMenuList::TSubMenuItem::MouseMoveTo(float x, float y, float enlargeWidth)
	{
		float centerX = (rect.w + enlarge) / 2.0f;

		CMSubMenuList *realOwner = (CMSubMenuList*)owner;

		float leftEnlarge, rightEnlarge;
		int leftAlpha, alpha, rightAlpha;

		if (x < centerX)
		{
			if (NULL == leftItem)
			{
				leftEnlarge = 0.0f;
				enlarge = enlargeWidth;
				rightEnlarge = 0.0f;
			}
			else
			{
				enlarge = (0.5f + 0.5f * x / centerX) * enlargeWidth;
				leftEnlarge = enlargeWidth - enlarge;
				rightEnlarge = 0.0f;
			}
		}
		else if (x > centerX)
		{
			if (NULL == rightItem)
			{
				leftEnlarge = 0.0f;
				enlarge = enlargeWidth;
				rightEnlarge = 0.0f;
			}
			else
			{
				enlarge = (1.5f - 0.5f * x / centerX) * enlargeWidth;
				rightEnlarge = enlargeWidth - enlarge;
				leftEnlarge = 0.0f;
			}
		}
		else
		{
			enlarge = enlargeWidth;
			leftEnlarge = 0.0f;
			rightEnlarge = 0.0f;
		}

		if (NULL != leftItem)
		{
			leftItem->enlarge = leftEnlarge;
		}

		if (NULL != rightItem)
		{
			rightItem->enlarge = rightEnlarge;
		}

		int leftItemIndex = index - 1;
		int rightItemIndex = index + 1;

		float curX = 0.0f;
		for (int i = 0; i <= leftItemIndex; i++)
		{
			TSubMenuItem *item = (TSubMenuItem*)realOwner->t_itemList[i];
			item->rect.x = curX;
			curX += item->rect.w;
			realOwner->t_RefreshItemPosition(item);

			if (i != leftItemIndex)
			{
				item->enlarge = 1.0f;
				item->Enlarge();
				item->ChangeAlpha(0);
			}
		}

		curX += leftEnlarge;

		rect.x = curX;
		realOwner->t_RefreshItemPosition(this);
		curX += rect.w + enlarge;

		if (NULL != rightItem)
		{
			rightItem->rect.x = curX;
			realOwner->t_RefreshItemPosition(rightItem);
			curX += rightItem->rect.w + rightEnlarge;

			for (int i = rightItemIndex + 1; i < (int)realOwner->t_itemList.size(); i++)
			{
				TSubMenuItem *item = (TSubMenuItem*)realOwner->t_itemList[i];
				item->rect.x = curX;
				curX += item->rect.w;
				realOwner->t_RefreshItemPosition(item);

				item->enlarge = 1.0f;
				item->Enlarge();
				item->ChangeAlpha(0);
			}
		}

		leftAlpha = (int)(255.0f * leftEnlarge / enlargeWidth);
		rightAlpha = (int)(255.0f * rightEnlarge / enlargeWidth);
		alpha = (int)(255.0f * enlarge / enlargeWidth);

		if (NULL != leftItem)
		{
			leftItem->Enlarge();
			leftItem->ChangeAlpha(leftAlpha);
		}

		if (NULL != rightItem)
		{
			rightItem->Enlarge();
			rightItem->ChangeAlpha(rightAlpha);
		}

		Enlarge();
		ChangeAlpha(alpha);
	}

	//CFirstScreenListControl
	CFirstScreenListControl::CFirstScreenListControl()
	{
		m_dataSource = NULL;
		m_listenerSet = NULL;

		m_mainTitle = NULL;
		m_subTitle = NULL;

		m_mainTitleScaleX = NULL;
		m_subTitleScaleX = NULL;

		m_subItemLeaveStatus = SUB_ITEM_NORMAL;
	}

	CFirstScreenListControl::~CFirstScreenListControl()
	{
		if (NULL != m_listenerSet)
		{
			//delete m_listenerSet;
			if (m_listenerSet->IsLocked())
			{
				m_listenerSet->Clear();
				HALO_ASSERT(IUtility::GetInstance());
				IUtility::GetInstance()->AsyncReleaseListenerSet(m_listenerSet);
			} 
			else
			{
				delete m_listenerSet;
			}

			m_listenerSet = NULL;
		}

		if (NULL != m_dataSource)
		{
			delete m_dataSource;
		}

		if (NULL != m_mainTitle)
		{
			m_mainTitle->Release();
		}

		if (NULL != m_subTitle)
		{
			m_subTitle->Release();
		}

		if (NULL != m_mainTitleScaleX)
		{
			m_mainTitleScaleX->Release();
		}

		if (NULL != m_subTitleScaleX)
		{
			m_subTitleScaleX->Release();
		}

		if (NULL != m_expandShrinkTrans)
		{
			m_expandShrinkTrans->Release();
		}

		if (NULL != m_subItemLeaveEntryTrans)
		{
			m_subItemLeaveEntryTrans->Release();
		}
	}

	bool CFirstScreenListControl::Initialize(IActor *parent, const TFirstScreenListControlAttr &attr)
	{
		TLinearListControlAttr linearAttr(attr.width, attr.height, TYPE_HORIZONTAL);
		linearAttr.titleHeight = attr.mainTitleHeight;
		linearAttr.titleSpace = attr.mainTitleSpace + attr.subTitleHeight + attr.subTitleSpace;
		m_mainTitleWidth = attr.mainTitleWidth;
		m_mainTitleHeight = attr.mainTitleHeight;
		m_mainTitleSpace = attr.mainTitleSpace;
		m_subTitleWidth = attr.subTitleWidth;
		m_subTitleHeight = attr.subTitleHeight;
		m_subTitleSpace = attr.subTitleSpace;
		bool ret = t_Initialize(parent, linearAttr);

		EnableUnload(false);

		m_dataSource = new CFirstScreenDataSource;
		m_listenerSet = new CFirstScreenListControlListenerSet(this);
		m_mainTitle = NULL;

		m_focusMargin[0] = 0.0f;
		m_focusMargin[1] = 0.0f;

		m_maxMargin[0] = 0.0f;
		m_maxMargin[1] = 0.0f;

		if (m_mainTitleHeight > 0)
		{
			m_mainTitle = IText::CreateInstance(dynamic_cast<Widget*>(this), m_mainTitleWidth, m_mainTitleHeight);
			if (NULL != m_mainTitle)
			{
				m_mainTitle->SetPosition(t_listWidth / 2 - m_mainTitleWidth / 2, 0.0f);
#ifdef VOLT22_SUPPORT
#else
				m_mainTitle->SetTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
				m_mainTitle->SetTextColor(*CLUTTER_COLOR_White);
#endif
				m_mainTitleScaleX = ITransition::CreateInstance();
				if (NULL != m_mainTitleScaleX)
				{
					m_mainTitleScaleX->SetDuration(500);
					m_mainTitle->SetPivotPoint(0.5f, 0.0f, 0.5f);
					m_mainTitle->BindTransition(m_mainTitleScaleX, IActor::ACTOR_ANI_SCALE_X);
				}
			}
		}

		if (m_subTitleHeight > 0)
		{
			m_subTitle = IText::CreateInstance(dynamic_cast<Widget*>(this), m_subTitleWidth, m_subTitleHeight);
			if (NULL != m_subTitle)
			{
#ifdef VOLT22_SUPPORT
#else
				m_subTitle->SetTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
				m_subTitle->SetTextColor(*CLUTTER_COLOR_White);
#endif
				m_subTitleScaleX = ITransition::CreateInstance();
				if (NULL != m_subTitleScaleX)
				{
					m_subTitleScaleX->SetDuration(500);
					m_subTitle->SetPivotPoint(0.5f, 0.0f, 0.5f);
					m_subTitle->BindTransition(m_subTitleScaleX, IActor::ACTOR_ANI_SCALE_X);
				}
			}
		}

		m_expandAniDuration = 500;
		m_itemScrollSpeed = 1.0f;

		m_curExpanedMainItem = -1;

		m_expandShrinkTrans = new CMultiObjectTransition;
		m_expandShrinkTrans->Initialize();
		t_RegisterMultiObjTransition(m_expandShrinkTrans, ITEM_POSITION_TRANS | ITEM_ALPHA_TRANS | ITEM_SIZE_TRANS | ITEM_SCALEX_TRANS | ITEM_SCALEY_TRANS);

		m_subItemLeaveEntryTrans = new CMultiObjectTransition;
		m_subItemLeaveEntryTrans->Initialize();
		t_RegisterMultiObjTransition(m_subItemLeaveEntryTrans, ITEM_POSITION_TRANS | ITEM_ALPHA_TRANS | ITEM_SIZE_TRANS | ITEM_SCALEX_TRANS | ITEM_SCALEY_TRANS);

		return ret;
	}

	bool CFirstScreenListControl::Initialize(Widget *parent, const TFirstScreenListControlAttr &attr)
	{
		TLinearListControlAttr linearAttr(attr.width, attr.height, TYPE_HORIZONTAL);
		linearAttr.titleHeight = attr.mainTitleHeight;
		linearAttr.titleSpace = attr.mainTitleSpace + attr.subTitleHeight + attr.subTitleSpace;
		m_mainTitleWidth = attr.mainTitleWidth;
		m_mainTitleHeight = attr.mainTitleHeight;
		m_mainTitleSpace = attr.mainTitleSpace;
		m_subTitleWidth = attr.subTitleWidth;
		m_subTitleHeight = attr.subTitleHeight;
		m_subTitleSpace = attr.subTitleSpace;
		bool ret = t_Initialize(parent, linearAttr);

		EnableUnload(false);

		m_dataSource = new CFirstScreenDataSource;
		m_listenerSet = new CFirstScreenListControlListenerSet(this);
		m_mainTitle = NULL;

		m_focusMargin[0] = 0.0f;
		m_focusMargin[1] = 0.0f;

		m_maxMargin[0] = 0.0f;
		m_maxMargin[1] = 0.0f;

		if (m_mainTitleHeight > 0)
		{
			m_mainTitle = IText::CreateInstance(dynamic_cast<Widget*>(this), m_mainTitleWidth, m_mainTitleHeight);
			if(m_mainTitle != NULL)
			{
				m_mainTitle->SetPosition(t_listWidth / 2 - m_mainTitleWidth / 2, 0.0f);
	#ifdef VOLT22_SUPPORT
	#else
				m_mainTitle->SetTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
				m_mainTitle->SetTextColor(*CLUTTER_COLOR_White);
	#endif
				m_mainTitleScaleX = ITransition::CreateInstance();
				if(m_mainTitleScaleX != NULL)
				{
					m_mainTitleScaleX->SetDuration(500);
					m_mainTitle->SetPivotPoint(0.5f, 0.0f, 0.5f);
					m_mainTitle->BindTransition(m_mainTitleScaleX, IActor::ACTOR_ANI_SCALE_X);
				}
			}
		}

		if (m_subTitleHeight > 0)
		{
			m_subTitle = IText::CreateInstance(dynamic_cast<Widget*>(this), m_subTitleWidth, m_subTitleHeight);
			if (NULL != m_subTitle)
			{
#ifdef VOLT22_SUPPORT
#else
				m_subTitle->SetTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
				m_subTitle->SetTextColor(*CLUTTER_COLOR_White);
#endif
				m_subTitleScaleX = ITransition::CreateInstance();
				if (NULL != m_subTitleScaleX)
				{
					m_subTitleScaleX->SetDuration(500);
					m_subTitle->SetPivotPoint(0.5f, 0.0f, 0.5f);
					m_subTitle->BindTransition(m_subTitleScaleX, IActor::ACTOR_ANI_SCALE_X);
				}
			}
		}

		m_expandAniDuration = 500;
		m_itemScrollSpeed = 1.0f;

		m_curExpanedMainItem = -1;

		return ret;
	}

	void CFirstScreenListControl::AddMainMenuItem(int itemNum, float itemSize, float spaceBetweenItem, char** itemTitles)
	{
		HALO_ASSERT(itemNum > 0 && itemSize > 0 && spaceBetweenItem >= 0);
		HALO_ASSERT(itemTitles != NULL);
		for (int i = 0; i < itemNum; i++)
		{
			HALO_ASSERT(itemTitles[i] != NULL);
		}

		float *itemSizeArray = new float[itemNum];
		if (NULL != itemSizeArray)
		{
			for (int i = 0; i < itemNum; i++)
			{
				itemSizeArray[i] = itemSize;
			}

			AddMainMenuItem(itemNum, itemSizeArray, spaceBetweenItem, itemTitles);

			delete[] itemSizeArray;
		}
	}

	void CFirstScreenListControl::AddMainMenuItem(int itemNum, float *itemSize, float spaceBetweenItem, char** itemTitles)
	{
		HALO_ASSERT(itemNum > 0 && itemSize != NULL && spaceBetweenItem >=0);
		HALO_ASSERT(itemTitles != NULL);
		for (int i = 0; i < itemNum; i++)
		{
			HALO_ASSERT(itemTitles[i] != NULL);
		}

		t_AddItem(itemNum, itemSize, spaceBetweenItem);
		for (int i = 0; i < itemNum; i++)
		{
			TMainMenuItem* mainItem = (TMainMenuItem*)t_itemList.at(i);
			if (NULL != mainItem)
			{
				mainItem->mainMenuWidth = itemSize[i];
				mainItem->titleContent = new char[strlen(itemTitles[i]) + 1];

				if (NULL != mainItem->titleContent)
				{
					strncpy(mainItem->titleContent, itemTitles[i], strlen(itemTitles[i]) + 1);
				}
			}
		}
	}

	void CFirstScreenListControl::AddSubItem(int mainMenuIndex, float itemSize, float spaceBetweenItem, float enlargeFocusItemSize, const char* titleContent)
	{
		HALO_ASSERT(mainMenuIndex >= 0 && mainMenuIndex < (int)t_itemList.size());
		HALO_ASSERT(itemSize > 0 && spaceBetweenItem >= 0 && enlargeFocusItemSize >= 0);
		HALO_ASSERT(titleContent != NULL);

		TMainMenuItem *mainItem = dynamic_cast<TMainMenuItem*>(t_itemList[mainMenuIndex]);
		if (NULL == mainItem)
		{
			return;
		}
		
		mainItem->subMenuWidth += itemSize;
		m_enlargeFocusItemSize = enlargeFocusItemSize;
		mainItem->subItemSpaceList.push_back(itemSize);
		char* subTitle = new char[strlen(titleContent) + 1];
		if (NULL != subTitle)
		{
			strncpy(subTitle, titleContent, strlen(titleContent) + 1);
			mainItem->subItemTitleList.push_back(subTitle);
		}
	}

	void CFirstScreenListControl::SetScrollItemNumber(int mainMenuIndex, int itemNumber)
	{
		HALO_ASSERT(mainMenuIndex >= 0 && mainMenuIndex < (int)t_itemList.size() && itemNumber >= 0);
		TMainMenuItem *mainItem = dynamic_cast<TMainMenuItem*>(t_itemList[mainMenuIndex]);
		if (mainItem)
		{
			mainItem->scrollItemNumber = itemNumber;
		}
	}

	void CFirstScreenListControl::ExpandMainMenu(int mainMenuIndex)
	{
		HALO_ASSERT(mainMenuIndex >= 0 && mainMenuIndex < (int)t_itemList.size());
		if (mainMenuIndex == m_curExpanedMainItem)
		{
			return;
		}

		for (int i = 0; i < (int)t_itemList.size(); i++)
		{
			TMainMenuItem *mainItem = (TMainMenuItem*)t_itemList[i];

			if (NULL != mainItem->subMenuList->m_subListExpandAni && true == mainItem->subMenuList->m_subListExpandAni->IsPlaying())
			{
				return;
			}
		}

		if (false == t_IsOnAnimation(ITEM_GROUP_POS_TRANS))
		{
			TMainMenuItem *mainItem = dynamic_cast<TMainMenuItem*>(t_itemList[mainMenuIndex]);
			if (NULL == mainItem)
			{
				return;
			}

			mainItem->subMenuList->SetParent(mainItem->window->Parent());
			mainItem->subMenuList->SetPosition(mainItem->rect.x, mainItem->rect.y - m_subTitleHeight - m_subTitleSpace);

			mainItem->alpha = 0;
			m_SetExpandAniDuration();

			if (0 <= m_curExpanedMainItem)
			{
				float curExpandItemXToRoot = mainItem->rect.x + t_itemGroupRect.x;

				TMainMenuItem *lastExpandedItem = dynamic_cast<TMainMenuItem*>(t_itemList[m_curExpanedMainItem]);
				if (NULL == lastExpandedItem)
				{
					return;
				}
				
				lastExpandedItem->alpha = 255;
				lastExpandedItem->subMenuList->Shrink(mainItem->mainMenuWidth / (mainItem->subMenuWidth + m_enlargeFocusItemSize));

				int indexArray[2] = { m_curExpanedMainItem, mainMenuIndex };
				float spaceArray[2] = { lastExpandedItem->mainMenuWidth, mainItem->subMenuWidth + m_enlargeFocusItemSize };

				CLinearListControl::t_SetItemSpace(2, indexArray, spaceArray, m_expandShrinkTrans);

				if (m_curExpanedMainItem > mainMenuIndex)
				{
					lastExpandedItem->m_subMenuPosAni->SetDestination(lastExpandedItem->rect.x);
					lastExpandedItem->m_subMenuPosAni->Play();
				}

				float destExpandItemXToRoot = mainItem->rect.x + t_itemGroupRect.x;

				if (destExpandItemXToRoot != curExpandItemXToRoot)
				{
					t_itemGroupRect.x = curExpandItemXToRoot - mainItem->rect.x;

// 					t_itemScrollAni->SetDestination(t_itemGroupRect.x, t_itemGroupRect.y);
// 					t_itemScrollAni->Play();
				}
			}
			else
			{
				CLinearListControl::t_SetItemSpace(mainMenuIndex, mainItem->subMenuWidth + m_enlargeFocusItemSize, m_expandShrinkTrans);
			}

			m_curExpanedMainItem = mainMenuIndex;

			mainItem->m_subMenuPosAni->SetDestination(mainItem->rect.x);
			mainItem->m_subMenuPosAni->Play();

			mainItem->subMenuList->LoadData();
			mainItem->subMenuList->Show();

			mainItem->subMenuList->SetPivotPoint(0.0f, 0.0f, 1.0f);
			mainItem->subMenuList->SetScale(mainItem->mainMenuWidth / (mainItem->subMenuWidth + m_enlargeFocusItemSize), 1.0f, 1.0f);
			mainItem->subMenuList->Expand();

			//handle main menu title
			m_mainTitle->SetScale(0.0f, 1.0f, 1.0f);
#ifdef VOLT22_SUPPORT
#else
			m_mainTitle->SetText(mainItem->titleContent);
#endif
			m_mainTitle->Show();
			m_mainTitleScaleX->SetDestination(1.0f);
			m_mainTitleScaleX->Play();

			m_expandShrinkTrans->Play();
		}
	}

	void CFirstScreenListControl::ShrinkMainMenu(int mainMenuIndex)
	{
		HALO_ASSERT(mainMenuIndex >= 0 && mainMenuIndex < (int)t_itemList.size());

		if (false == t_IsOnAnimation(ITEM_GROUP_POS_TRANS))
		{
			TMainMenuItem *mainItem = dynamic_cast<TMainMenuItem*>(t_itemList[mainMenuIndex]);
			if (NULL != mainItem)
			{
				mainItem->subMenuList->Shrink(mainItem->mainMenuWidth / (mainItem->subMenuWidth + m_enlargeFocusItemSize));
				CLinearListControl::t_SetItemSpace(mainMenuIndex, mainItem->mainMenuWidth, m_expandShrinkTrans);
				m_mainTitleScaleX->SetDestination(0.0f);
				m_mainTitleScaleX->Play();

				m_subTitleScaleX->SetDestination(0.0f);
				m_subTitleScaleX->Play();
				m_curExpanedMainItem = -1;

				m_expandShrinkTrans->Play();
			}
		}
	}


	void CFirstScreenListControl::SetFocusMargin(TMargin margin)
	{
		m_focusMargin[0] = (float)(margin.left);
		m_focusMargin[1] = (float)(margin.right);
	}

	void CFirstScreenListControl::SetMaxMargin(float startMargin, float endMargin)
	{
		float x, y, w, h;
		GetClipArea(x, y, w, h);

		HALO_ASSERT(startMargin + endMargin < w);

		m_maxMargin[0] = startMargin;
		m_maxMargin[1] = endMargin;
	}


	void CFirstScreenListControl::AddListListener(IFirstScreenListListener *listener)
	{
		HALO_ASSERT(listener != NULL);

		m_listenerSet->Add(listener);
	}

	void CFirstScreenListControl::SetExpandAnimationDuration(int duration)
	{
		HALO_ASSERT(duration >= 0);
		m_expandAniDuration = duration;
	}

	void CFirstScreenListControl::SetScrollSpeed(float pixPerMillisecond)
	{
		HALO_ASSERT(pixPerMillisecond >= 0);
		m_itemScrollSpeed = pixPerMillisecond;
	}

	IFirstScreenDataSource* CFirstScreenListControl::DataSource(void)
	{
		return m_dataSource;
	}

	bool CFirstScreenListControl::OnMouseMoved(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		m_DealMainMenuScrolling(ptrMouseEvent->GetX(), ptrMouseEvent->GetY());
		return true;
	}

	bool CFirstScreenListControl::OnMousePointerIn(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		return true;
	}

	bool CFirstScreenListControl::OnMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent)
	{
		return true;
	}

	bool CFirstScreenListControl::t_OnMousePointerIn(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		return true;
	}

	bool CFirstScreenListControl::t_OnMousePointerOut(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		return true;
	}

	bool CFirstScreenListControl::t_OnMouseMoved(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		if (SUB_ITEM_NORMAL != m_subItemLeaveStatus)
		{
			return true;
		}

		m_DealMainMenuScrolling(ptrMouseEvent->GetX(), ptrMouseEvent->GetY());

		float mouseX;
		mouseX = ptrMouseEvent->GetX();

		TMainMenuItem* mainItem = (TMainMenuItem*)item;

		float centerGloableX = mainItem->rect.x;
		IActor *parent = mainItem->window->Parent();
		while (parent != NULL)
		{
			float x, y;
			parent->GetPosition(x, y);
			centerGloableX += x;

			parent = parent->Parent();
		}
		centerGloableX += mainItem->rect.w / 2;

		float mouseOffset = mouseX - centerGloableX;
		int nextMainItemIndex = mainItem->index;
		if (mouseOffset > 0)
		{
			nextMainItemIndex++;
		}
		else if (mouseOffset < 0)
		{
			nextMainItemIndex--;
		}
		else
		{
			return true;
		}

		int deltaAlpha = (int)(abs(mouseOffset) / item->rect.w * 2 * (255 - 200) / 2);

		if (NULL == mainItem->subMenuList || false == mainItem->subMenuList->FlagExpanded())
		{
			item->alpha = 255 - deltaAlpha;

			if (0 <= item->alpha && 255 >= item->alpha)
			{
				item->window->SetAlpha(item->alpha);
			}
		}

		if (nextMainItemIndex >= 0 && nextMainItemIndex < (int)t_itemList.size())
		{
			TMainMenuItem *nextMainItem = (TMainMenuItem*)t_itemList[nextMainItemIndex];

			if (NULL == nextMainItem->subMenuList || false == nextMainItem->subMenuList->FlagExpanded())
			{
				if (deltaAlpha <= 55 && deltaAlpha >= -200)
				{
					t_itemList.at(nextMainItemIndex)->window->SetAlpha(200 + deltaAlpha);
				}
			}
		}

		return true;
	}

	bool CFirstScreenListControl::t_MouseButtonPressed(TItem* item, IMouseEvent* ptrMouseEvent)
	{
		if (SUB_ITEM_NORMAL != m_subItemLeaveStatus)
		{
			return true;
		}

		TMainMenuItem *mainItem = dynamic_cast<TMainMenuItem*>(item);

		if (mainItem)
		{
			if (false == mainItem->subMenuList->FlagExpanded())
			{
				ExpandMainMenu(mainItem->index);
			}
		}

		return true;
	}

	bool CFirstScreenListControl::t_MoveFocusBar(EDirection direction)
	{
		return true;
	}

	void CFirstScreenListControl::t_BindDataListToItemList(void)
	{
		HALO_ASSERT((int)t_itemList.size() == m_dataSource->NumOfMainMenuData());

		for (int i = 0; i < m_dataSource->NumOfMainMenuData(); i++)
		{
			t_itemList[i]->data = m_dataSource->MainMenuData(i);
		}

		t_UpdateInMemoryItems(true);

		for (int i = 0; i < (int)t_itemList.size(); i++)
		{
			t_RefreshItemPosition(t_itemList[i]);
		}
	}

	CFirstScreenListControl::TLinearItem* CFirstScreenListControl::t_AllocLinearItem(void)
	{
		TMainMenuItem *item = new TMainMenuItem(this);
		if (NULL != item)
		{
			item->subMenuList = new CMSubMenuList;
			item->scrollPlayer = new CScrollPlayer;
			item->alpha = 200;

			item->m_subMenuPosAni = new TransitionBase;
		}
		
		return item;
	}

	void CFirstScreenListControl::t_FreeLinearItem(TLinearItem *item)
	{
		TMainMenuItem *mainItem = (TMainMenuItem*)item;
		delete mainItem->subMenuList;
		delete mainItem->scrollPlayer;
		delete mainItem->m_subMenuPosAni;
		delete mainItem;
	}

	void CFirstScreenListControl::t_GetRealItems(TLinearItem *item, std::vector<TItem*> &itemList)
	{
		itemList.push_back(item);
	}

	void CFirstScreenListControl::t_GetItemWindowPivotPoint(TItem *item, float &pivotX, float &pivotY, float &pivotZ)
	{
		pivotX = 0.5f;
		pivotY = 0.5f;
		pivotZ = 0.5f;
	}

	void CFirstScreenListControl::t_OnItemDataUnload(TItem *item)
	{
		TMainMenuItem *mainItem = dynamic_cast<TMainMenuItem*>(item);
		HALO_ASSERT(NULL != mainItem);

		if (mainItem)
		{
			CMSubMenuList *subMenuList = mainItem->subMenuList;

			if (subMenuList)
			{
				if (true == subMenuList->FlagExpanded())
				{
				}
			}			
		}	
	}

	void CFirstScreenListControl::t_OnItemDataSyncLoad(TItem *item)
	{
		TMainMenuItem *mainItem = dynamic_cast<TMainMenuItem*>(item);
		HALO_ASSERT(NULL != mainItem);
		
		if (NULL == mainItem)
		{
			return;
		}

		CMSubMenuList *subMenuList = mainItem->subMenuList;

		float width, height;
		width = mainItem->rect.w;
		height = mainItem->rect.h;

		if (false == subMenuList->FlagExpanded())
		{
		}
		else
		{
			subMenuList->Initialize(mainItem->window, this, mainItem->index, m_enlargeFocusItemSize, mainItem->subMenuWidth + m_enlargeFocusItemSize, height + m_subTitleHeight + m_subTitleSpace, m_subTitleHeight, m_subTitleSpace);
			subMenuList->SetRendererProvider(t_rendererProvider);
			subMenuList->AddListListener(this);
			subMenuList->AddMouseListener(this);
			subMenuList->SetPivotPoint(0.0f, 0.0f, 0.5f);
			subMenuList->SetScale(0.0f, 1.0f, 1.0f);
			subMenuList->EnableUnload(false);

			subMenuList->t_RegisterMultiObjTransition(m_subItemLeaveEntryTrans, ITEM_POSITION_TRANS | ITEM_ALPHA_TRANS | ITEM_SIZE_TRANS | ITEM_SCALEX_TRANS | ITEM_SCALEY_TRANS);

			mainItem->m_subMenuPosAni->Initialize(false);
			mainItem->subMenuList->BindTransition(mainItem->m_subMenuPosAni, IActor::ACTOR_ANI_POSITION_X);
			mainItem->subMenuList->SetPivotPoint(0.0f, 0.0f, 1.0f);

			for (int i = 0; i < (int)mainItem->subItemSpaceList.size(); i++)
			{
				subMenuList->AddItem(mainItem->subItemSpaceList[i]);
			}

			int numOfSubMenuItem = (int)mainItem->subMenuList->t_itemList.size();

			if (1 < numOfSubMenuItem)
			{
				CMSubMenuList::TSubMenuItem *item = (CMSubMenuList::TSubMenuItem*)mainItem->subMenuList->t_itemList[0];
				item->rightItem = (CMSubMenuList::TSubMenuItem*)mainItem->subMenuList->t_itemList[1];

				item = (CMSubMenuList::TSubMenuItem*)mainItem->subMenuList->t_itemList[numOfSubMenuItem - 1];
				item->leftItem = (CMSubMenuList::TSubMenuItem*)mainItem->subMenuList->t_itemList[numOfSubMenuItem - 2];
			}

			for (int i = 1; i < numOfSubMenuItem - 1; i++)
			{
				CMSubMenuList::TSubMenuItem *item = (CMSubMenuList::TSubMenuItem*)mainItem->subMenuList->t_itemList[i];
				item->leftItem = (CMSubMenuList::TSubMenuItem*)mainItem->subMenuList->t_itemList[i - 1];
				item->rightItem = (CMSubMenuList::TSubMenuItem*)mainItem->subMenuList->t_itemList[i + 1];
			}

			for (int j = 0; j < m_dataSource->NumOfSubData(mainItem->index); j++)
			{
				subMenuList->SetDataSource(m_dataSource->SubMenuDataSource(mainItem->index));
			}
		}

		CFirstScreenListControlListenerSet::TFirstScreenListListenerData data;
		data.type = EVENT_ITEM_LOAD;
		data.param[0] = mainItem->index;

		m_listenerSet->Process(&data);

		//load scroll player data
		CScrollPlayer* scrollPlayer = mainItem->scrollPlayer;
		CScrollPlayer::T_ScrollPlayerAttr attr(width, height);
		attr.itemNum = mainItem->scrollItemNumber;
		attr.timeInterval = 2000;
		scrollPlayer->Initialize(item->window, &attr);
		scrollPlayer->SetBackgroundColor(*CLUTTER_COLOR_Gray);
		scrollPlayer->SetPosition(0, 0);
		scrollPlayer->SetListener(this);
		for (int i = 0; i < m_dataSource->NumOfScrollData(mainItem->index); i++)
		{
			scrollPlayer->SetDataSource(m_dataSource->ScrollDataSource(mainItem->index));
		}
		scrollPlayer->SetRendererProvider(t_rendererProvider);
		scrollPlayer->LoadData();
		scrollPlayer->Show();
		scrollPlayer->StartTimer();
	}

	void CFirstScreenListControl::t_OnItemDataAsyncLoad(TItem *item)
	{

	}

	void CFirstScreenListControl::t_FocusChangeStart(const TItem *from, const TItem *to)
	{

	}

	void CFirstScreenListControl::t_FocusChangeFinish(const TItem *from, const TItem *to)
	{

	}

	TValue2f CFirstScreenListControl::t_GetRealPointBaseItemGroup(TRect rect, TRect baseOnRect)
	{
		TValue2f point(rect.x, rect.y);
		return point;
	}

	TValue2f CFirstScreenListControl::t_GetLogicalPosition(TRect rect, TRect baseOnRect)
	{
		TValue2f point(rect.x, rect.y);
		return point;
	}

	TRect CFirstScreenListControl::t_InitRectOfLoadingItem(TItem *item, int reason)
	{
		return item->rect;
	}

	void CFirstScreenListControl::t_GetInMemoryItemsOfSubClass(TRect visibleArea, std::vector<TItem*> &loadItem, std::vector<TItem*> &unloadItem, std::vector<TItem*> &noChangeItem, int reason)
	{
		return;
		for (int i = 0; i < (int)loadItem.size(); i++)
		{
			TMainMenuItem *mainItem = (TMainMenuItem*)loadItem[i];

			if (true == mainItem->subMenuList->FlagExpanded())
			{
				mainItem->subMenuList->t_UpdateInMemoryItems(true, reason);
			}
		}

		for (int i = 0; i < (int)noChangeItem.size(); i++)
		{
			TMainMenuItem *mainItem = (TMainMenuItem*)noChangeItem[i];

			if (true == mainItem->subMenuList->FlagExpanded())
			{
				mainItem->subMenuList->t_UpdateInMemoryItems(true, reason);
			}
		}
	}

	void CFirstScreenListControl::OnSubItemSyncLoad(int mainMenuIndex, TItem *item)
	{
		TLinearItem *subItem = (TLinearItem*)(item);

		CFirstScreenListControlListenerSet::TFirstScreenListListenerData data;
		data.type = EVENT_SUB_ITEM_LOAD;
		data.param[0] = mainMenuIndex;
		data.param[1] = subItem->index;

		m_listenerSet->Process(&data);
	}

	void CFirstScreenListControl::OnSubItemASyncLoad(int mainMenuIndex, TItem *item)
	{

	}

	void CFirstScreenListControl::OnSubItemUnload(int mainMenuIndex, TItem *item)
	{

	}

	void CFirstScreenListControl::OnFocusChangeTo(int mainMenuIndex, int from, int to)
	{
	}

	void CFirstScreenListControl::t_OnRegisterAnimationCallback(ITimeLine *timeLine, EAniEventType aniCallbackType)
	{
		CMultiObjectTransition *trans = dynamic_cast<CMultiObjectTransition*>(timeLine);

		if (trans == m_subItemLeaveEntryTrans)
		{
			if (ANI_FINISH == aniCallbackType)
			{
				if (SUB_ITEM_LEAVING == m_subItemLeaveStatus)
				{
					m_subItemLeaveStatus = SUB_ITEM_LEAF;
				}
				else if (SUB_ITEM_LEAF == m_subItemLeaveStatus)
				{
					m_subItemLeaveStatus = SUB_ITEM_NORMAL;
				}
			}
		}
	}

	void CFirstScreenListControl::OnItemLoad(class CScrollPlayer *scrollPlayer, int scrollDataIndex)
	{
		int itemIndex = m_ScrollPlayerIndex(scrollPlayer);
		if (itemIndex == -1)
		{
			return;
		}
		TMainMenuItem* mainItem = (TMainMenuItem*)t_itemList.at(itemIndex);
		CFirstScreenListControlListenerSet::TFirstScreenListListenerData data;
		data.type = CFirstScreenListControl::EVENT_SCROLL_ITEM_LOAD;
		data.param[0] = mainItem->index;
		data.param[1] = scrollDataIndex;

		m_listenerSet->Process(&data);
	}

	void CFirstScreenListControl::m_SetExpandAniDuration(void)
	{
		m_mainTitleScaleX->SetDuration(m_expandAniDuration);
		m_subTitleScaleX->SetDuration(m_expandAniDuration);

		t_SetAnimationDuration(m_expandAniDuration);

		for (int i = 0; i < (int)t_itemList.size(); i++)
		{
			TMainMenuItem *mainItem = (TMainMenuItem*)t_itemList[i];

			if (NULL != mainItem->subMenuList && NULL != mainItem->subMenuList->m_subListExpandAni && true == mainItem->subMenuList->m_subListExpandAni->IsInitialized())
			{
				mainItem->subMenuList->m_subListExpandAni->SetDuration(m_expandAniDuration);
				mainItem->subMenuList->m_alphaAni->SetDuration(m_expandAniDuration);
				mainItem->m_subMenuPosAni->SetDuration(m_expandAniDuration);
			}
		}
	}

	void CFirstScreenListControl::m_SetScrollAniDuration(float scrollDistance)
	{
		t_SetAnimationDuration((int)(scrollDistance / m_itemScrollSpeed));
	}

	int CFirstScreenListControl::m_ScrollPlayerIndex(CScrollPlayer* player)
	{
		for (int i = 0; i < (int)t_itemList.size(); i++)
		{
			TMainMenuItem* item = (TMainMenuItem*)t_itemList.at(i);
			if (item->scrollPlayer == player)
			{
				return i;
			}
		}
		return -1;
	}

	void CFirstScreenListControl::OnItemUnload(class CScrollPlayer *scrollPlayer, int scrollDataIndex)
	{

	}

	void CFirstScreenListControl::m_DealMainMenuScrolling(float mouseX, float mouseY)
	{
		if (SUB_ITEM_NORMAL != m_subItemLeaveStatus)
		{
			return;
		}
		
		if (0 <= m_curExpanedMainItem && true == ((TMainMenuItem*)t_itemList[m_curExpanedMainItem])->subMenuList->m_subListExpandAni->IsPlaying())
		{
			return;
		}

		for (IActor *window = this; NULL != window; window = window->Parent())
		{
			float x, y;
			window->GetPosition(x, y);
			mouseX -= x;
			mouseY -= y;
		}

		if (mouseX > t_listWidth - m_focusMargin[1])
		{
			if (false == t_IsOnAnimation(ITEM_GROUP_POS_TRANS))
			{
				float x, y;
				t_itemGroup->GetPosition(x, y);

				TRect lastItemRect;
				TMainMenuItem *lastMainItem = (TMainMenuItem*)t_itemList[t_itemList.size() - 1];
				if (true == lastMainItem->subMenuList->FlagExpanded())
				{
					lastItemRect = lastMainItem->subMenuList->t_itemList[lastMainItem->subMenuList->t_itemList.size() - 1]->rect;
				}
				else
				{
					lastItemRect = lastMainItem->rect;
				}

				lastItemRect.x = lastItemRect.x + lastItemRect.w - t_listWidth + m_maxMargin[1];
				lastItemRect.y = 0.0f;

				m_SetScrollAniDuration(abs(lastItemRect.x + t_itemGroupRect.x));
				ScrollVisibleArea(lastItemRect);
			}
		}
		else if (mouseX < m_focusMargin[0])
		{
			if (false == t_IsOnAnimation(ITEM_GROUP_POS_TRANS))
			{
				float x, y;
				t_itemGroup->GetPosition(x, y);

				TRect firstItemRect;
				firstItemRect.x = -m_maxMargin[0];
				firstItemRect.y = 0.0f;
				firstItemRect.w = t_listWidth;
				firstItemRect.h = t_listHeight;

				m_SetScrollAniDuration(abs(firstItemRect.x + t_itemGroupRect.x));
				ScrollVisibleArea(firstItemRect);
			}
		}
		else
		{
			m_StopScrollMainMenu();
		}
	}

	void CFirstScreenListControl::m_StopScrollMainMenu(void)
	{
		if (0 <= m_curExpanedMainItem && true == ((TMainMenuItem*)t_itemList[m_curExpanedMainItem])->subMenuList->m_subListExpandAni->IsPlaying())
		{
			return;
		}

		if (true == t_IsOnAnimation(ITEM_GROUP_POS_TRANS))
		{
			float x, y;

			t_itemGroup->GetPosition(x, y);

			//t_itemScrollAni->Pause();

			t_itemGroup->GetPosition(x, y);

			t_itemGroupRect.x = x;
			t_itemGroupRect.y = y;
		}
	}

	void CFirstScreenListControl::PlaySubItemLeaveAni(int mainItemIndex, int subItemIndex)
	{
		if (SUB_ITEM_NORMAL != m_subItemLeaveStatus)
		{
			return;
		}

		m_subItemLeaveStatus = SUB_ITEM_LEAVING;

		TMainMenuItem* mainMenuItem = (TMainMenuItem*)t_itemList[mainItemIndex];
		RemoveClipArea();
		mainMenuItem->subMenuList->RemoveClipArea();

		m_mainTitle->Hide();
		m_subTitle->Hide();

		IStage* stage = IStage::GetInstance();
		float width, height;
		stage->GetSize(width, height);

		CMSubMenuList::TSubMenuItem* subMenuItem = (CMSubMenuList::TSubMenuItem*)mainMenuItem->subMenuList->t_itemList[subItemIndex];

		float subItemXToScreen = subMenuItem->rect.x + mainMenuItem->rect.x + t_itemGroupRect.x;

		for (int i = 0; i < (int)t_itemList.size(); i++)
		{
			TLinearItem* mainItem = t_itemList[i];

			if (i < mainItemIndex)
			{
				mainItem->alpha = 0;
				mainItem->rect.x -= (width - subMenuItem->rect.w) / 2;
			}
			else if (i > mainItemIndex)
			{
				mainItem->alpha = 0;
				mainItem->rect.x += (width - subMenuItem->rect.w) / 2;
			}
			
			t_RefreshItemPosition(mainItem, m_subItemLeaveEntryTrans);
		}
		
		for (int i = 0; i < (int)mainMenuItem->subMenuList->t_itemList.size(); i++)
		{
			TLinearItem* linearItem = mainMenuItem->subMenuList->t_itemList[i];
			CMSubMenuList::TSubMenuItem *subItem = dynamic_cast<CMSubMenuList::TSubMenuItem*>(linearItem);

			HALO_ASSERT(NULL != subItem);
			if (NULL == subItem)
			{
				continue;
			}

			subItem->alphaBak = subItem->alpha;
			subItem->alpha = 0;

			TValue1i destAlpha(0);
			m_subItemLeaveEntryTrans->SetDestination(subItem->window_bg, IActor::ACTOR_ANI_ALPHA, &destAlpha);

			if (i < subMenuItem->index)
			{
				subItem->rect.x -= (width - subMenuItem->rect.w) / 2;
			}
			else if (i > subMenuItem->index)
			{
				subItem->rect.x += (width - subMenuItem->rect.w) / 2;
			}
			else
			{
				subItem->window_bg->SetPivotPoint(0.0f, 1.0f, 1.0f);

				double scaleX, scaleY, scaleZ;
				subItem->window_bg->GetScale(scaleX, scaleY, scaleZ);

				m_leafSubItemScaleVal.val[0] = (float)scaleX;
				m_leafSubItemScaleVal.val[1] = (float)scaleY;

				TValue2f destPos(subItem->rect.x - subItemXToScreen, subItem->rect.y);
				m_subItemLeaveEntryTrans->SetDestination(subItem->window_bg, IActor::ACTOR_ANI_POSITION, &destPos);

				TValue1f destXScale(width / subItem->rect.w);
				m_subItemLeaveEntryTrans->SetDestination(subItem->window_bg, IActor::ACTOR_ANI_SCALE_X, &destXScale);
				
				TValue1f destYScale(height / subItem->rect.h);
				m_subItemLeaveEntryTrans->SetDestination(subItem->window_bg, IActor::ACTOR_ANI_SCALE_Y, &destYScale);
			}

			mainMenuItem->subMenuList->t_RefreshItemPosition(subItem, m_subItemLeaveEntryTrans);
		}

		m_subItemLeaveEntryTrans->Play();
	}

	void CFirstScreenListControl::PlaySubItemEntranceAni(int mainItemIndex, int subItemIndex)
	{
		if (SUB_ITEM_LEAF != m_subItemLeaveStatus)
		{
			return;
		}

		TMainMenuItem* mainMenuItem = (TMainMenuItem*)t_itemList[mainItemIndex];

		m_mainTitle->Show();
		m_subTitle->Show();

		IStage* stage = IStage::GetInstance();
		float width, height;
		stage->GetSize(width, height);

		CMSubMenuList::TSubMenuItem* subMenuItem = (CMSubMenuList::TSubMenuItem*)mainMenuItem->subMenuList->t_itemList[subItemIndex];

		for (int i = 0; i < (int)t_itemList.size(); i++)
		{
			TLinearItem* mainItem = t_itemList[i];

			if (i < mainItemIndex)
			{
				mainItem->alpha = 200;
				mainItem->rect.x += (width - subMenuItem->rect.w) / 2;
			}
			else if (i > mainItemIndex)
			{
				mainItem->alpha = 200;
				mainItem->rect.x -= (width - subMenuItem->rect.w) / 2;
			}
			t_RefreshItemPosition(mainItem, m_subItemLeaveEntryTrans);
		}

		for (int i = 0; i < (int)mainMenuItem->subMenuList->t_itemList.size(); i++)
		{
			TLinearItem* linearItem = mainMenuItem->subMenuList->t_itemList[i];
			CMSubMenuList::TSubMenuItem *subItem = dynamic_cast<CMSubMenuList::TSubMenuItem*>(linearItem);

			HALO_ASSERT(NULL != subItem);
			if (NULL == subItem)
			{
				continue;
			}

			subItem->alpha = subItem->alphaBak;

			if (i < subMenuItem->index)
			{
				subItem->rect.x += (width - subMenuItem->rect.w) / 2;
			}
			else if (i > subMenuItem->index)
			{
				subItem->rect.x -= (width - subMenuItem->rect.w) / 2;
			}
			else
			{
				subItem->window_bg->SetPivotPoint(0.0f, 1.0f, 1.0f);

				TValue2f destPos(subItem->rect.x, subItem->rect.y);
				m_subItemLeaveEntryTrans->SetDestination(subItem->window_bg, IActor::ACTOR_ANI_POSITION, &destPos);

				TValue1f destXScale(m_leafSubItemScaleVal.val[0]);
				m_subItemLeaveEntryTrans->SetDestination(subItem->window_bg, IActor::ACTOR_ANI_SCALE_X, &destXScale);

				TValue1f destYScale(m_leafSubItemScaleVal.val[1]);
				m_subItemLeaveEntryTrans->SetDestination(subItem->window_bg, IActor::ACTOR_ANI_SCALE_Y, &destYScale);
			}

			if (255 != subItem->alpha)
			{
				TValue1i destAlpha(255 - subItem->alpha);
				m_subItemLeaveEntryTrans->SetDestination(subItem->window_bg, IActor::ACTOR_ANI_ALPHA, &destAlpha);
			}

			subItem->alphaBak = -1;

			mainMenuItem->subMenuList->t_RefreshItemPosition(subItem, m_subItemLeaveEntryTrans);
		}

		m_subItemLeaveEntryTrans->Play();
	}

	const char* CFirstScreenListControl::GetActorType(void)
	{
		return "FirstScreenListControl";
	}
}