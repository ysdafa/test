#include "Halo1_0.h"

namespace HALO
{
	CLinearListControl::CLinearListControl(void)
	{
		m_windowStartItem = m_windowEndItem = -1;
		m_titleHeight = 0;
		m_titleSpace = 0;
	}

	CLinearListControl::~CLinearListControl(void)
	{
		m_windowStartItem = m_windowEndItem = -1;

		for (int i = (int)t_itemList.size() - 1; i >= 0; i--)
		{
			delete t_itemList[i];
		}

		t_itemList.clear();
	}

	void CLinearListControl::GetWindowItemRange(int &startItemIndex, int &endItemIndex)
	{
		if (NULL != startItemIndex)
		{
			startItemIndex = m_windowStartItem;
		}

		if (NULL != endItemIndex)
		{
			endItemIndex = m_windowEndItem;
		}
	}

	void CLinearListControl::CompareIndexRange(int oldStart, int oldEnd, int newStart, int newEnd, int maxIndex, std::vector<int> &loadItem, std::vector<int> &unloadItem, std::vector<int> &noChangeItem)
	{
		if (-1 == oldStart)
		{
			if (0 <= newStart && 0 <= newEnd)
			{
				for (int i = newStart; i <= newEnd; i++)
				{
					loadItem.push_back(i);
				}
			}
		}
		else
		{
			if (0 > newStart || 0 > newEnd)
			{
				for (int i = oldStart; i <= oldEnd && i < maxIndex; i++)
				{
					unloadItem.push_back(i);
				}
			}
			else if (oldStart <= newStart)
			{
				//OldStart......NewStart
				if (newStart <= oldEnd)
				{
					//OldStart......NewStart......OldEnd
					if (oldEnd <= newEnd)
					{
						//OldStart......NewStart......OldEnd......NewEnd
						for (int i = oldStart; i < newStart; i++)
						{
							unloadItem.push_back(i);
						}

						for (int i = newStart; i <= oldEnd; i++)
						{
							noChangeItem.push_back(i);
						}

						for (int i = oldEnd + 1; i <= newEnd; i++)
						{
							loadItem.push_back(i);
						}
					}
					else
					{
						//OldStart......NewStart......NewEnd......OldEnd
						for (int i = oldStart; i < newStart; i++)
						{
							unloadItem.push_back(i);
						}

						for (int i = newStart; i <= newEnd; i++)
						{
							noChangeItem.push_back(i);
						}

						for (int i = newEnd + 1; i <= oldEnd && i < maxIndex; i++)
						{
							unloadItem.push_back(i);
						}
					}
				}
				else
				{
					//OldStart......OldEnd......NewStart
					for (int i = oldStart; i <= oldEnd; i++)
					{
						unloadItem.push_back(i);
					}

					for (int i = newStart; i <= newEnd; i++)
					{
						loadItem.push_back(i);
					}
				}
			}
			else
			{
				//NewStart......OldStart
				if (oldStart <= newEnd)
				{
					//NewStart......OldStart......NewEnd
					if (newEnd <= oldEnd)
					{
						//NewStart......OldStart......NewEnd......OldEnd
						for (int i = newStart; i < oldStart; i++)
						{
							loadItem.push_back(i);
						}

						for (int i = oldStart; i <= newEnd; i++)
						{
							noChangeItem.push_back(i);
						}

						for (int i = newEnd + 1; i <= oldEnd; i++)
						{
							unloadItem.push_back(i);
						}
					}
					else
					{
						//NewStart......OldStart......OldEnd......NewEnd
						for (int i = newStart; i < oldStart; i++)
						{
							loadItem.push_back(i);
						}

						for (int i = oldEnd + 1; i <= newEnd; i++)
						{
							loadItem.push_back(i);
						}
					}
				}
				else
				{
					//NewStart......NewEnd......OldStart
					for (int i = oldStart; i <= oldEnd; i++)
					{
						unloadItem.push_back(i);
					}

					for (int i = newStart; i <= newEnd; i++)
					{
						loadItem.push_back(i);
					}
				}
			}
		}
	}

	const char* CLinearListControl::GetActorType(void)
	{
		return "LinearListControl";
	}
	
	bool CLinearListControl::t_Initialize(IActor *parent, const TLinearListControlAttr &attr)
	{
		bool ret = CDataListControl::t_Initialize(parent, attr);
		m_titleHeight = attr.titleHeight;
		m_titleSpace = attr.titleSpace;
		if (true == ret)
		{
			t_type = attr.type;
			m_itemGroupSpace = 0;
		}

		return ret;
	}

	bool CLinearListControl::t_Initialize(Widget *parent, const TLinearListControlAttr &attr)
	{
		bool ret = CDataListControl::t_Initialize(parent, attr);
		m_titleHeight = attr.titleHeight;
		m_titleSpace = attr.titleSpace;
		if (true == ret)
		{
			t_type = attr.type;
			m_itemGroupSpace = 0;
		}

		return ret;
	}

	void CLinearListControl::t_AddItem(int itemNum, float *itemSpaceArray, float spaceBetweenItem /*= 0*/)
	{
		for (int i = 0; i < itemNum; i++)
		{
			TLinearItem *item = t_AllocLinearItem();
			item->spaceToNext = spaceBetweenItem;
			int index = item->index = (int)t_itemList.size();

			m_itemGroupSpace += itemSpaceArray[i];

			if (TYPE_VERTICAL == t_type)
			{
				item->rect.x = 0.0f;
				item->rect.y = index == 0 ? 0.0f : t_itemList[index - 1]->rect.y + t_itemList[index - 1]->rect.h + t_itemList[index - 1]->spaceToNext;
				item->rect.w = t_listWidth;
				item->rect.h = itemSpaceArray[i];
			}
			else
			{
				item->rect.x = index == 0 ? 0.0f : t_itemList[index - 1]->rect.x + t_itemList[index - 1]->rect.w + t_itemList[index - 1]->spaceToNext;
				item->rect.y = m_titleHeight + m_titleSpace;
				item->rect.w = itemSpaceArray[i];
				item->rect.h = t_listHeight - item->rect.y;
			}

			t_itemList.push_back(item);
		}

		if (TYPE_VERTICAL == t_type)
		{
			t_SetItemGroupSize(t_listWidth, m_itemGroupSpace);
		}
		else
		{
			t_SetItemGroupSize(m_itemGroupSpace, t_listHeight);
		}
	}

	void CLinearListControl::t_InsertItem(int insertPosition, int itemNum, float *itemSpaceArray)
	{
		for (int i = 0; i < itemNum; i++)
		{
			TLinearItem *item = t_AllocLinearItem();
			if (TYPE_VERTICAL == t_type)
			{
				item->rect.w = t_listWidth;
				item->rect.h = itemSpaceArray[i];
			}
			else
			{
				item->rect.w = itemSpaceArray[i];
				item->rect.h = t_listHeight;
			}

			m_itemGroupSpace += itemSpaceArray[i];

			t_itemList.insert(t_itemList.begin() + insertPosition, item);
		}

		for (int i = insertPosition; i < (int)t_itemList.size(); i++)
		{
			TLinearItem *item = t_itemList[i];
			item->index = i;

			if (TYPE_VERTICAL == t_type)
			{
				item->rect.x = 0.0f;
				item->rect.y = item->index == 0 ? 0.0f : t_itemList[item->index-1]->rect.y + t_itemList[item->index-1]->rect.h;
			}
			else
			{
				item->rect.x = item->index == 0 ? 0.0f : t_itemList[item->index-1]->rect.x + t_itemList[item->index-1]->rect.w;
				item->rect.y = 0.0f;
			}
		}

		if (TYPE_VERTICAL == t_type)
		{
			t_SetItemGroupSize(t_listWidth, m_itemGroupSpace);
		}
		else
		{
			t_SetItemGroupSize(m_itemGroupSpace, t_listHeight);
		}
	}

	TRect CLinearListControl::t_DelelteItem(int fromItem, int deleteItemNum)
	{
		if (0 > fromItem || fromItem + deleteItemNum > (int)t_itemList.size())
		{
			return t_itemGroupRect;
		}

		TRect windowRect = t_WindowRect();

		int toItem = fromItem + deleteItemNum - 1;

		float startPos;
		if (0 == fromItem)
		{
			startPos = 0.0f;
		}
		else
		{
			startPos = t_itemList[fromItem - 1]->ElementEndPosition();
		}

		for (int i = fromItem + deleteItemNum; i < (int)t_itemList.size(); i++)
		{
			TLinearItem *item = t_itemList[i];

			if (TYPE_VERTICAL == t_type)
			{
				item->rect.y = startPos;
				startPos += item->rect.h;
			}
			else
			{
				item->rect.x = startPos;
				startPos += item->rect.w;
			}
		}

		for (int i = fromItem + deleteItemNum - 1; i >= fromItem; i--)
		{
			t_FreeLinearItem(t_itemList[i]);
		}

		t_itemList.erase(t_itemList.begin() + fromItem, t_itemList.begin() + fromItem + deleteItemNum);

		if (fromItem <= m_windowStartItem)
		{
			//from......start
			if (toItem < m_windowStartItem)
			{
				//from......to......start
				m_windowStartItem -= deleteItemNum;
				m_windowEndItem -= deleteItemNum;

				if (TYPE_VERTICAL == t_type)
				{
					windowRect.y = t_itemList[m_windowStartItem]->rect.y;
				} 
				else
				{
					windowRect.x = t_itemList[m_windowStartItem]->rect.x;
				}
			}
			else
			{
				//from......start......to

				if (toItem < m_windowEndItem)
				{
					//from......start......to......end
					m_windowStartItem = fromItem;
					m_windowEndItem -= deleteItemNum;

					if (TYPE_VERTICAL == t_type)
					{
						windowRect.y = t_itemList[m_windowStartItem]->rect.y;
					} 
					else
					{
						windowRect.x = t_itemList[m_windowStartItem]->rect.x;
					}
				}
				else
				{
					//from......start......end......to
					m_windowStartItem = -1;
					m_windowEndItem = -1;

					if (0 == (int)t_itemList.size())
					{
						if (TYPE_VERTICAL == t_type)
						{
							windowRect.y = 0.0f;
						}
						else
						{
							windowRect.x = 0.0f;
						}
					}
					else if (toItem < (int)t_itemList.size() - 1)
					{
						if (TYPE_VERTICAL == t_type)
						{
							windowRect.y = t_itemList[toItem + 1]->rect.y;
						}
						else
						{
							windowRect.x = t_itemList[toItem + 1]->rect.x;
						}
					}
					else
					{
						if (TYPE_VERTICAL == t_type)
						{
							windowRect.y = t_itemList[fromItem - 1]->rect.y;
						}
						else
						{
							windowRect.x = t_itemList[fromItem - 1]->rect.x;
						}
					}
				}
			}
		}
		else
		{
			//start......from
			if (toItem < m_windowEndItem)
			{
				//start......from......to......end
				m_windowEndItem -= deleteItemNum;
			}
			else
			{
				//start......from......end......to
				m_windowEndItem = fromItem - 1;
			}
		}

		if (0 != t_itemList.size())
		{
			TRect &lastItemRect = t_itemList[t_itemList.size() - 1]->rect;
			TRect &firstItemRect = t_itemList[0]->rect;

			if (TYPE_VERTICAL == t_type)
			{
				if (lastItemRect.y + lastItemRect.h < windowRect.y + windowRect.h)
				{
					if (lastItemRect.y + lastItemRect.h - firstItemRect.y >= windowRect.h)
					{
						windowRect.y = lastItemRect.y + lastItemRect.h - windowRect.h;
					}
					else
					{
						windowRect.y = 0;
					}
				}
			}
			else
			{
				if (lastItemRect.x + lastItemRect.w < windowRect.x + windowRect.w)
				{
					if (lastItemRect.x + lastItemRect.w - firstItemRect.x >= windowRect.w)
					{
						windowRect.x = lastItemRect.x + lastItemRect.w - windowRect.w;
					}
					else
					{
						windowRect.x = 0;
					}
				}
			}

			for (int i = fromItem; i < (int)t_itemList.size(); i++)
			{
				TLinearItem *item = t_itemList[i];

				item->index = i;
				t_RefreshItemPosition(item);
			}
		}
		else
		{
			t_focusedItem = NULL;
		}

		return windowRect;
	}

	void CLinearListControl::t_SetItemSpace(int itemIndex, float itemSpace, CMultiObjectTransition *trans)
	{
		TLinearItem *item = t_itemList[itemIndex];
		float offset = 0.0f;

		if (TYPE_VERTICAL == t_type)
		{
			offset = itemSpace - item->rect.h;
			m_itemGroupSpace += offset;
			t_SetItemGroupSize(t_listWidth, m_itemGroupSpace);
		}
		else
		{
			offset = itemSpace - item->rect.w;
			m_itemGroupSpace += offset;
			t_SetItemGroupSize(m_itemGroupSpace, t_listHeight);
		}


		if (TYPE_VERTICAL == t_type)
		{
			item->rect.h = itemSpace;
			t_RefreshItemPosition(item, trans);

			for (int i = itemIndex + 1; i < (int)t_itemList.size(); i++)
			{
				item = t_itemList[i];
				item->rect.y += offset;
				t_RefreshItemPosition(item, trans);
			}
		}
		else
		{
			item->rect.w = itemSpace;
			t_RefreshItemPosition(item, trans);

			for (int i = itemIndex + 1; i < (int)t_itemList.size(); i++)
			{
				item = t_itemList[i];
				item->rect.x += offset;
				t_RefreshItemPosition(item, trans);
			}
		}

		t_UpdateInMemoryItems(NULL == trans);
	}

	void CLinearListControl::t_SetItemSpace(int numOfChangeItem, int itemIndex[], float itemSpace[], CMultiObjectTransition *trans)
	{
		for (int i = 0; i < numOfChangeItem; i++)
		{
			if (TYPE_VERTICAL == t_type)
			{
				t_itemList[itemIndex[i]]->rect.h = itemSpace[i];
			}
			else
			{
				t_itemList[itemIndex[i]]->rect.w = itemSpace[i];
			}
		}

		if (TYPE_VERTICAL == t_type)
		{
			float curY = 0.0f;
			for (int i = 0; i < (int)t_itemList.size(); i++)
			{
				TLinearItem *item = (TLinearItem*)t_itemList[i];
				item->rect.y = curY;
				t_RefreshItemPosition(item, trans);

				curY += item->rect.h + item->spaceToNext;
			}
		}
		else
		{
			float curX = 0.0f;
			for (int i = 0; i < (int)t_itemList.size(); i++)
			{
				TLinearItem *item = (TLinearItem*)t_itemList[i];
				item->rect.x = curX;
				t_RefreshItemPosition(item, trans);

				curX += item->rect.w + item->spaceToNext;
			}
		}

		t_UpdateInMemoryItems(NULL == trans);
	}

	void CLinearListControl::t_GetInMemoryItems(TRect lastVisibleArea, TRect visibleArea, std::vector<TItem*> &loadItem, std::vector<TItem*> &unloadItem, std::vector<TItem*> &noChangeItem, int reason /*= -1*/)
	{
		int newStartItem = -1, newEndItem = -1;

		if (TYPE_VERTICAL == t_type)
		{
			newStartItem = m_ItemIndexCrossByLine(visibleArea.y, true);

			if (0 <= newStartItem)
			{
				newEndItem = m_ItemIndexCrossByLine(visibleArea.y + visibleArea.h, false);
			}
		}
		else
		{
			newStartItem = m_ItemIndexCrossByLine(visibleArea.x, true);

			if (0 <= newStartItem)
			{
				newEndItem = m_ItemIndexCrossByLine(visibleArea.x + visibleArea.w, false);
			}
		}

		m_GetItemChangeInfo(m_windowStartItem, m_windowEndItem, newStartItem, newEndItem, loadItem, unloadItem, noChangeItem);

		t_GetInMemoryItemsOfSubClass(visibleArea, loadItem, unloadItem, noChangeItem, reason);

		m_windowStartItem = newStartItem;
		m_windowEndItem = newEndItem;
	}

	int CLinearListControl::m_ItemIndexCrossByLine(float linePos, bool flagStartLine)
	{
		int eleCnt = t_itemList.size();

		float firstItemStart = t_itemList[0]->ElementStartPosition();
		float lastItemEnd = t_itemList[eleCnt - 1]->ElementEndPosition();

		int itemIndex = -1;

		int begin = 0, end = eleCnt - 1;

		if (true == flagStartLine)
		{
			if (lastItemEnd <= linePos)
			{
				//printf("No element in area\n");
				itemIndex = -1;
			}
			else
			{
				//Get begin element
				if (firstItemStart >= linePos)
				{
					itemIndex = 0;
				}
				else
				{
					do
					{
						if (begin + 1 == end && (begin + end) / 2 == itemIndex)
						{
							itemIndex = (begin + end) / 2 + 1;
						}
						else
						{
							itemIndex = (begin + end) / 2;
						}

						if (end - begin == 1)
						{
							if (t_itemList[begin]->ElementEndPosition() < linePos && t_itemList[end]->ElementStartPosition() >= linePos)
							{
								itemIndex = end;
								break;
							}
						}

						TLinearItem *element = t_itemList[itemIndex];

						if (element->ElementStartPosition() <= linePos && element->ElementEndPosition() > linePos)
						{
							break;
						}
						else if (element->ElementEndPosition() <= linePos)
						{
							begin = itemIndex;
						}
						else
						{
							end = itemIndex;
						}
					} while (begin != end);
				}
			}
		}
		else
		{
			if (firstItemStart >= linePos)
			{
				//printf("No element in area\n");
				itemIndex = -1;
			}
			else
			{
				do 
				{
					if (begin + 1 == end && (begin + end) / 2 == itemIndex)
					{
						itemIndex = (begin + end) / 2 + 1;
					}
					else
					{
						itemIndex = (begin + end) / 2;
					}

					if (end - begin == 1)
					{
						if (t_itemList[begin]->ElementEndPosition() < linePos && t_itemList[end]->ElementStartPosition() >= linePos)
						{
							itemIndex = begin;
							break;
						}
					}

					TLinearItem *element = t_itemList[itemIndex];

					if (element->ElementStartPosition() < linePos && element->ElementEndPosition() >= linePos)
					{
						break;
					}
					else if (element->ElementEndPosition() < linePos)
					{
						begin = itemIndex;
					} 
					else
					{
						end = itemIndex;
					}
				} while (begin != end);
			}
		}

		return itemIndex;
	}

	void CLinearListControl::m_GetItemChangeInfo(int oldStart, int oldEnd, int newStart, int newEnd, std::vector<TItem*> &loadItem, std::vector<TItem*> &unloadItem, std::vector<TItem*> &noChangeItem)
	{
		std::vector<int> loadIndexList;
		std::vector<int> unloadIndexList;
		std::vector<int> noChangeIndexList;

		CompareIndexRange(oldStart, oldEnd, newStart, newEnd, t_itemList.size(), loadIndexList, unloadIndexList, noChangeIndexList);

		for (int i = 0; i < (int)loadIndexList.size(); i++)
		{
			t_GetRealItems(t_itemList[loadIndexList[i]], loadItem);
		}

		for (int i = 0; i < (int)unloadIndexList.size(); i++)
		{
			t_GetRealItems(t_itemList[unloadIndexList[i]], unloadItem);
		}

		for (int i = 0; i < (int)noChangeIndexList.size(); i++)
		{
			TLinearItem *item = t_itemList[noChangeIndexList[i]];
			if (NULL == item->window)
			{
				t_GetRealItems(item, loadItem);
			}
			else
			{
				t_GetRealItems(item, noChangeItem);
			}
		}
	}
}