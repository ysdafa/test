#include "Halo.h"
#include "Halo1_0.h"

namespace HALO
{

	ICompositeImage* ICompositeImage::CreateInstance(IActor* parent, float width, float height)
	{
		CCompositeImage* image = dynamic_cast<CCompositeImage*>(Instance::CreateInstance(CLASS_ID_ICOMPOSITEIMAGE));

		if (NULL != image)
		{
			image->Initialize(parent, width, height);
		}

		return image;
	}

	ICompositeImage* ICompositeImage::CreateInstance(Widget* parent, float width, float height)
	{
		CCompositeImage* image = dynamic_cast<CCompositeImage*>(Instance::CreateInstance(CLASS_ID_ICOMPOSITEIMAGE));

		if (NULL != image)
		{
			image->Initialize(parent, width, height);
		}

		return image;
	}

}