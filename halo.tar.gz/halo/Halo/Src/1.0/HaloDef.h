#ifndef _HALODEF_H_
#define _HALODEF_H_

using namespace HALO;

#define HALO_MAX(a,b)            (((a) > (b)) ? (a) : (b))
#define HALO_MIN(a,b)            (((a) < (b)) ? (a) : (b))


#define  D_SET_HALO_ACTOR(gobj, val)  (g_object_set_data((gobj), "HaloActor2ClutterActor", (val)))
#define  D_GET_HALO_ACTOR(gobj)       (static_cast<CActor*>(g_object_get_data((gobj), "HaloActor2ClutterActor")))

#define  D_SET_HALO_WIDGET_EXTENSION(gobj, val)  (g_object_set_data((gobj), "HaloWidgetHelper2ClutterActor", (val)))
#define  D_GET_HALO_WIDGET_EXTENSION(gobj)       (static_cast<CWidgetExtension*>(g_object_get_data((gobj), "HaloWidgetHelper2ClutterActor")))

#ifdef WIN32
#define  SNPRINTF _snprintf_s 
#else
#define  SNPRINTF snprintf
#endif

#ifdef VOLT22_SUPPORT
#include "Effect.h"
#include "WidgetUtilities.h"
#include "event_const.h"
#include "RemotePtr.h"
#include "WidgetGraphics.h"

#include "TransitionListenerProxy.h"
#include "TransitionGraphics.h"
#include "TransitionProxy.h"

#include "ActorMessages.h"
#include "ActorGraphics.h"
#include "ActorProxy.h"

#include "HaloImageGraphics.h"
#include "HaloImageProxy.h"

typedef class ActorProxy ActorBase;
typedef class TransitionProxy TransitionBase;
typedef class Transition1iProxy CTransition;
typedef class Transition1fProxy CTransition;
typedef class Transition2fProxy CTransition;
typedef class TransitionListenerProxy TransitionListener;

#else // #ifndef VOLT22_SUPPORT

typedef class CActor ActorBase;
typedef class CTransition TransitionBase;
typedef class ITimeLineListener TransitionListener;

#endif //VOLT22_SUPPORT


#endif  //_HALODEF_H_