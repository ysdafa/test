#ifndef _HALO_CFOVEAANIMATOR_H_
#define _HALO_CFOVEAANIMATOR_H_

namespace HALO
{
	class HALO_API CFoveaAnimator : public IFoveaAnimator
	{
		public:
			CFoveaAnimator();
			~CFoveaAnimator();
			virtual float CalculateFoveaTransX(int width, int height, int posX, int posY, int cursorX, int cursorY, int cursorRadius);
			virtual float CalculateFoveaTransText(int width, int height, int centerX, int centerY, int cursorX, int cursorY);
			virtual void SetCurve(int curve);
			virtual void SetScaleFactor(float factor);
		private:
			float m_scaleFactor;
			int m_interpolatorType;
	};

}
#endif
