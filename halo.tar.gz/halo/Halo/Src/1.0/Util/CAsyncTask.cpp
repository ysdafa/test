#include "Halo1_0.h"

static HALO::util::Logger LOGGER("AsyncTask");

namespace HALO
{
	extern HALO::CEventManager* g_pEventManager;
	extern HALO::CThreadPool* g_pThreadPoolExecutor;

	class CFutureTask : public IRunnable
	{
	public:
		CFutureTask();
		CFutureTask(CAsyncTask* pTask);
		virtual ~CFutureTask();
	private:
		CAsyncTask* task;
	public:
		virtual void Run(void);
	};

	ITaskListener::ITaskListener()
	{
		if (g_pEventManager)
		{
			g_pEventManager->AddAsyncTaskListener(this);
		}
	}

	ITaskListener::~ITaskListener()
	{
		if (g_pEventManager)
		{
			g_pEventManager->RemoveAsyncTaskListener(this);
		}
	}
	bool ITaskListener::Process(IEvent* event)
	{
		H_LOG_TRACE(LOGGER, "ITaskListener::Process ");
		IAsyncTask* pTask = NULL;
		event->GetPointor("task", (void**)&pTask);
		if (!(m_task && pTask && pTask == m_task))
		{
			H_LOG_TRACE(LOGGER, "ITaskListener::Process: task error");
			return false;
		}
		void* result = NULL;
		if (!event->GetPointor("result", &result))
		{
			H_LOG_TRACE(LOGGER, "ITaskListener::Process: get result pointer error");
			return false;
		}
		if (event->IsEventType("samsung.tv.halo.system.async.update"))
		{
			H_LOG_TRACE(LOGGER, "ITaskListener::Process: OnUpdate ");
			OnUpdate(result);
		}
		else if (event->IsEventType("samsung.tv.halo.system.async.finish"))
		{
			H_LOG_TRACE(LOGGER, "ITaskListener::Process: OnFinish ");
			OnFinish(result);
		}
		return true;
	}

	CFutureTask::CFutureTask(){};
	CFutureTask::CFutureTask(CAsyncTask* pTask):task(pTask)
	{ 
	}
	CFutureTask::~CFutureTask()
	{
	}
	void CFutureTask::Run(void)
	{
		task->PostResult(task->DoInBackground(task->GetParams()));
	}

	CAsyncTask::CAsyncTask():
		m_bInitializedFlag(false),
		m_pExecutor(NULL),
		m_pTask(NULL), 
		m_pParams(NULL),
		m_pResult(NULL),
		m_pTaskListener(NULL), 
		m_taskStatus(E_HALO_ASYNC_STATUS_INIT),
		m_mainThreadID(0),
		m_subThreadID(0)
	{
	}
	
	CAsyncTask::~CAsyncTask()
	{
		m_csTaskStatusLock.Lock();
		if (m_taskStatus == E_HALO_ASYNC_STATUS_RUNNING)
		{
			Cancel();
		}
		m_csTaskStatusLock.Unlock();
		if (m_pTask)
		{
			delete m_pTask;
		}
		m_csTaskStatusLock.Destroy();
	}
	bool CAsyncTask::Initialize(void)
	{
		H_LOG_TRACE(LOGGER, "CAsyncTask::Initialize ");
		m_csTaskStatusLock.Create();
		m_taskStatus = E_HALO_ASYNC_STATUS_PENDING;
		m_pExecutor = g_pThreadPoolExecutor;
		m_pTask = new CFutureTask(this);
		ASSERT(m_pTask);
		if (m_pTask == NULL)
		{
			return false;
		}
		m_mainThreadID = CThreadSelf::Id();
		m_bInitializedFlag = true;
		return true;
	}
	
	bool CAsyncTask::Initialize(void* params)
	{
		H_LOG_TRACE(LOGGER, "CAsyncTask::Initialize with params ");
		Initialize();
		m_pParams = params;
		return true;
	}
	bool CAsyncTask::Initialize(void* params, IThreadPool* threadPool)
	{
		H_LOG_TRACE(LOGGER, "CAsyncTask::Initialize with params and treadPool");
		Initialize(params);
		CThreadPool* tmpThreadPool = dynamic_cast<CThreadPool*>(threadPool);
		if (tmpThreadPool != NULL)
		{
			m_pExecutor = tmpThreadPool;
		}
		return true;
	}
	bool CAsyncTask::IsInitialized(void) const
	{
		H_LOG_TRACE(LOGGER, "CAsyncTask::IsInitialized: m_bInitializedFlag = " << m_bInitializedFlag);
		return m_bInitializedFlag;
	}

	void* CAsyncTask::GetParams(void)
	{
		H_LOG_TRACE(LOGGER, "CAsyncTask::GetParams ");
		return m_pParams;
	}
	
	bool CAsyncTask::Execute(void)
	{
		H_LOG_TRACE(LOGGER, "CAsyncTask::Execute ");
		ASSERT(IsInitialized() == true);
		if (!IsInitialized())
		{
			return false;
		}
		ASSERT(CThreadSelf::Id() == m_mainThreadID);
		if (CThreadSelf::Id() != m_mainThreadID)
		{
			return false;
		}
		m_csTaskStatusLock.Lock();
		m_taskStatus = E_HALO_ASYNC_STATUS_RUNNING;
		m_pExecutor->Execute(m_pTask);
		m_csTaskStatusLock.Unlock();
		return true;
	}

	void* CAsyncTask::DoInBackground(void* params)
	{
		H_LOG_TRACE(LOGGER, "CAsyncTask::DoInBackground ");
		ASSERT(IsInitialized() == true);
		m_subThreadID = CThreadSelf::Id();
		void* ret = NULL;
		if (m_pTaskListener)
		{
			ret = m_pTaskListener->OnStart(params);
		}
		m_csTaskStatusLock.Lock();
		m_taskStatus = E_HALO_ASYNC_STATUS_STOP;
		m_csTaskStatusLock.Unlock();

		return ret;
	}

	void CAsyncTask::PostResult(void* result)
	{
		H_LOG_TRACE(LOGGER, "CAsyncTask::PostResult ");
		ASSERT(IsInitialized() == true);
		ASSERT(CThreadSelf::Id() == m_subThreadID);
		CSystemEvent event;
		event.SetEventType("samsung.tv.halo.system.async.finish");
		event.PutPointor("task", this);
		event.PutPointor("result", result);
		g_pEventManager->SendEventLocal(&event);
	}

	bool CAsyncTask::Update(void* result)
	{
		H_LOG_TRACE(LOGGER, "CAsyncTask::Update ");
		ASSERT(IsInitialized() == true);
		if (!IsInitialized())
		{
			return false;
		}
		ASSERT(CThreadSelf::Id() == m_subThreadID);
		if (CThreadSelf::Id() != m_subThreadID)
		{
			return false;
		}
		CSystemEvent event;
		event.SetEventType("samsung.tv.halo.system.async.update");
		event.PutPointor("task", this);
		event.PutPointor("result", result);
		g_pEventManager->SendEventLocal(&event);
		return true;
	}

	void CAsyncTask::Cancel(void)
	{
		H_LOG_TRACE(LOGGER, "CAsyncTask::Cancel ");
		ASSERT(IsInitialized() == true);
		if (!IsInitialized())
		{
			return;
		}
		ASSERT(CThreadSelf::Id() == m_mainThreadID);
		if (CThreadSelf::Id() != m_mainThreadID)
		{
			return;
		}

		m_pExecutor->Cancel(m_pTask);

		m_csTaskStatusLock.Lock();
		m_taskStatus = E_HALO_ASYNC_STATUS_STOP;
		m_csTaskStatusLock.Unlock();

		if (m_pTaskListener)
		{
			m_pTaskListener->OnCancel(m_pParams);
		}
	}

	bool CAsyncTask::SetTaskListener(ITaskListener* taskListener)
	{
		H_LOG_TRACE(LOGGER, "CAsyncTask::SetTaskListener ");
		ASSERT(IsInitialized() == true);
		if (!IsInitialized())
		{
			return false;
		}
		ASSERT(CThreadSelf::Id() == m_mainThreadID);
		if (CThreadSelf::Id() != m_mainThreadID)
		{
			return false;
		}
		m_pTaskListener = taskListener;
		return true;
	}
		
	bool CAsyncTask::RemoveTaskListener(ITaskListener* taskListener) 
	{
		H_LOG_TRACE(LOGGER, "CAsyncTask::RemoveTaskListener ");
		ASSERT(IsInitialized() == true);
		if (!IsInitialized())
		{
			return false;
		}
		ASSERT(CThreadSelf::Id() == m_mainThreadID);
		if (CThreadSelf::Id() != m_mainThreadID)
		{
			return false;
		}
		if (m_pTaskListener == taskListener)
		{
			m_pTaskListener = NULL;
			return true;
		}
		return false;
	}
}
