#ifndef _CUTILITY_H_
#define _CUTILITY_H_

namespace HALO
{
	class CUtility : virtual public IUtility
	{
	public:
		virtual bool ExtractForegroundColor(unsigned int from_r, unsigned int from_g, unsigned int from_b, unsigned int *to_r, unsigned int * to_g, unsigned int* to_b);
		virtual bool GetCurrentResolution(int& hRes, int& vRes);

		//! Destroy asynchronous
		virtual bool AsyncRelease(Widget* target);

	};
}

#endif //_IUTILITY_H_
