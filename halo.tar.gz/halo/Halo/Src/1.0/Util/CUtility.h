#ifndef _CUTILITY_H_
#define _CUTILITY_H_

namespace HALO
{
	class CUtility : virtual public IUtility
	{
	public:
		CUtility();
		~CUtility();
		virtual bool ExtractForegroundColor(unsigned int from_r, unsigned int from_g, unsigned int from_b, unsigned int *to_r, unsigned int * to_g, unsigned int* to_b);
		virtual ColorCategory ExtractIconColor(unsigned int from_r, unsigned int from_g, unsigned int from_b);

		virtual bool GetCurrentResolution(int& hRes, int& vRes);
		virtual EResolution GetCurrentResolution(void);

		//! Destroy asynchronous
		virtual bool AsyncRelease(Widget* target);
		virtual bool AsyncReleaseListenerSet(ListenerSet* target);

		
		virtual void SetOrientation(EOrientation orientation);
		//! Get Orientation
		virtual EOrientation GetOrientation(void ) const;

		//! Change Orientation
		virtual void ApplyOrientation(void);

		virtual float GetInterpolatedValue(int type, float input);

		virtual void EnableHighContrast(const bool enable);
		virtual bool IsHighContrastEnabled(void) const;

		virtual void EnableEnlarge(const bool enable);
		virtual bool IsEnlargeEnabled(void) const;
		virtual bool IsCursorVisible(void);
		virtual void Enable720P(const bool enable);
		virtual bool Is720PEnabled(void) const;
	private:
		bool m_initResolution(void);
	private:
		EOrientation m_orientation;
		bool m_flagHighContrast;
		bool m_flagEnlarge;
		bool m_flag720P;
		static EResolution m_resolution;
		static int m_hRes;
		static int m_vRes;
		
	};
}

#endif //_IUTILITY_H_
