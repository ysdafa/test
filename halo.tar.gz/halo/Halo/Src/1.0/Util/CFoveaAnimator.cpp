#include "Halo1_0.h"
#include <iterator>
static HALO::util::Logger LOGGER("FoveaAnimator");

namespace HALO
{
	CFoveaAnimator::CFoveaAnimator():
		m_scaleFactor(1.0f),
		m_interpolatorType(0)
	{

	}

	CFoveaAnimator::~CFoveaAnimator()
	{

	}
	float CFoveaAnimator::CalculateFoveaTransX(int width, int height, int posX, int posY, int cursorX, int cursorY, int cursorRadius)
	{
		float transX = 0;
		float w = width / 2.0f;
		float h = height / 2.0f;
		float p1_x = 0;
		float p1_y = 0;
		float p2_x = 0;
		float p2_y = 0;

		if( posY == cursorY ) // case 3
		{
			p1_y = p2_y = cursorY;
			float a = 1.0f;
			float b = -posX;
			float c = (posX * posX) - (w * w);
			p1_x = (-b + sqrt(b*b - a*c))/a;
			p2_x = (-b - sqrt(b*b - a*c))/a;

		}else if( posX == cursorX ) // case 4 
		{
			p1_x = p2_x = cursorX;
			float a = 1.0f;
			float b = -posY;
			float c = (posY * posY) - (h * h);
			p1_y = (-b + sqrt(b*b - a*c))/a;
			p2_y = (-b - sqrt(b*b - a*c))/a;

		}else{	// case 1, case 2
			float x1 = 0;
			float x2 = (float)(cursorX - posX);
			float y1 = 0;
			float y2 = (float)(cursorY - posY);

			float G = (y2 - y1) / ( x2 -x1 );
			
			float a = h * h + w * w * G * G;
			float b = -(x1 * h * h + x1 * G * G * w * w);
			float c = h * h * x1 * x1 + G * G * w * w * x1 * x1 - w * w * h * h;

			p1_x = (-b + sqrt(b*b - a*c))/a;
			p2_x = (-b - sqrt(b*b - a*c))/a;

			p1_y = G * (p1_x - x1) + y1;
			p2_y = G * (p2_x - x1) + y1;
			p1_x += posX;	p2_x += posX;
			p1_y += posY;	p2_y += posY;
		}
		
		float dis = sqrt( (p1_x - p2_x) * (p1_x - p2_x) + (p1_y - p2_y) * (p1_y - p2_y) ) / 2.0f;
		float result = sqrt( (float)( posX - cursorX ) * ( posX - cursorX ) + (float)( posY - cursorY ) * ( posY - cursorY ));
		float total = cursorRadius + dis;
		if( result > total )
		{
			transX = 0;
		}
		else
		{
			transX = 1 - result/total;
		}

		H_LOG_TRACE(LOGGER, "transX : " << transX);
		return transX;
	}

	float CFoveaAnimator::CalculateFoveaTransText(int width, int height, int centerX, int centerY, int cursorX, int cursorY)
	{
		float w = 2.0f * abs(cursorX - centerX);
		float h = 2.0f * abs(cursorY - centerY);
							
		float cursorRectW, cursorRectH;
		if (w / width > h / height)
		{
			cursorRectW = w;
			cursorRectH = height * w / width;
		}
		else
		{
			cursorRectH = h;
			cursorRectW = width * h / height;
		}
		float transText = 1 - sqrt((cursorRectW * cursorRectH) / (width * height));
		H_LOG_TRACE(LOGGER, "transText : " << transText);
		return transText;
	}
	
	void CFoveaAnimator::SetCurve(int curve)
	{
		H_LOG_TRACE(LOGGER, "SetCurve : " << curve);
		m_interpolatorType = curve;
	}

	void CFoveaAnimator::SetScaleFactor(float factor)
	{
		H_LOG_TRACE(LOGGER, "SetScaleFactor : " << factor);
		m_scaleFactor = factor;
	}

}

