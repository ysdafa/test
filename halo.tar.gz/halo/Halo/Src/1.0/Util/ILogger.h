#ifndef _HALO_CLOGGER_H
#define _HALO_CLOGGER_H

#include <cstddef>
#include <string>

#ifdef USE_LOG4CPLUS
#include <log4cplus/helpers/threads.h>
#include <log4cplus/logger.h>
#else
#include <sstream>

#ifdef USE_DLOG
#include <dlog.h>
#endif
#endif

namespace HALO
{

namespace util
{

#ifdef USE_LOG4CPLUS
#define H_LOG_TRACE(logger, msg) LOG4CPLUS_TRACE((logger).GetLogger(), msg)
#define H_LOG_DEBUG(logger, msg) LOG4CPLUS_DEBUG((logger).GetLogger(), msg)
#define H_LOG_INFO(logger, msg) LOG4CPLUS_INFO((logger).GetLogger(), msg)
#define H_LOG_WARN(logger, msg) LOG4CPLUS_WARN((logger).GetLogger(), msg)
#define H_LOG_ERROR(logger, msg) LOG4CPLUS_ERROR((logger).GetLogger(), msg)
#define H_LOG_FATAL(logger, msg) LOG4CPLUS_FATAL((logger).GetLogger(), msg)
#else
#define H_LOG_TRACE(logger, msg) do { \
	H_LOG_WRITE((logger), HALO::util::Logger::kInfo, msg); \
} while(0)
#define H_LOG_DEBUG(logger, msg) do { \
	H_LOG_WRITE((logger), HALO::util::Logger::kDebug, msg); \
} while(0)
#define H_LOG_INFO(logger, msg) do { \
	H_LOG_WRITE((logger), HALO::util::Logger::kInfo, msg); \
} while(0)
#define H_LOG_WARN(logger, msg) do { \
	H_LOG_WRITE((logger), HALO::util::Logger::kWarn, msg); \
} while(0)
#define H_LOG_ERROR(logger, msg) do { \
	H_LOG_WRITE((logger), HALO::util::Logger::kMajor, msg); \
} while(0)
#define H_LOG_FATAL(logger, msg) do { \
	H_LOG_WRITE((logger), HALO::util::Logger::kFatal, msg); \
} while(0)

#define H_LOG_0_PARAM(lvl, logger) H_LOG_##lvl(logger, "[0x" << this <<"]");
#define H_LOG_1_PARAM(lvl, logger, p1) H_LOG_##lvl(logger, "[0x" << this <<"] " << #p1 << "(" <<  p1 << ")");
#define H_LOG_2_PARAM(lvl, logger, p1, p2) H_LOG_##lvl(logger, "[0x" << this <<"] " << #p1 << "(" <<  p1 << "), " << #p2 << "(" <<  p2 << ")");
#define H_LOG_3_PARAM(lvl, logger, p1, p2, p3) H_LOG_##lvl(logger, "[0x" << this <<"] " << #p1 << "(" <<  p1 << "), " << #p2 << "(" <<  p2 << "), " << #p3 << "(" <<  p3 << ")");

#if !defined(WIN32) && !defined(LINUX_BUILD)
#define H_LOG_WRITE(logger, level, msg) do { \
  std::ostringstream os; \
  os << msg; \
  (logger).Log(__FILE__, __func__, __LINE__, (level), "HALO", os.str()); \
} while(0)
#else
#define H_LOG_WRITE(logger, level, msg) do { \
	std::ostringstream os; \
	os << msg; \
	(logger).Log(__FILE__, __FUNCTION__, __LINE__, (level), "HALO", os.str()); \
} while(0)
#endif

#endif

class Logger
{
  public:
    enum LogLevel { kFatal, kMajor, kWarn, kDebug, kInfo };

  public:
    Logger(const std::string &aName = "");
    virtual ~Logger();

    static void Configure(const std::string &aConfigPath);

    static void SetLogLevel(const LogLevel aLevel);

    static const char* LevelToString(const LogLevel aLevel);

	static LogLevel StringToLevel(const char *aLevelStr);

#ifdef USE_LOG4CPLUS
    log4cplus::Logger GetLogger() const 
	{ 
		return logger_; 
	}

    static log4cplus::LogLevel Log4CplusLevel(const LogLevel aLevel);
#else
    void Log(const char *aFile, const char *aFunc, const unsigned int aLine,
             const LogLevel aLevel, const char *aDlogTag, std::string aMsg) const;
#endif

  private:
#ifdef USE_LOG4CPLUS
    log4cplus::Logger logger_;
#else
    std::string name_;
    static LogLevel level_;
#endif
};

} /* namespace util */
} /* namespace HALO */

#endif /* _HALO_CLOGGER_H */
