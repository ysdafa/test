#include "Halo1_0.h"


namespace HALO
{
	IFoveaAnimator* IFoveaAnimator::m_foveaAnimator = NULL;
	IFoveaAnimator* IFoveaAnimator::GetInstance(void)
	{
		if( m_foveaAnimator == NULL)
		{
			m_foveaAnimator = (CFoveaAnimator*)Instance::CreateInstance(CLASS_ID_IFOVEAANIMATOR);
		}
		return (IFoveaAnimator*)m_foveaAnimator;
	}
}

