#ifndef _HALO_CDBUS_H_
#define _HALO_CDBUS_H_

#include <string.h>
#include <glib.h>                               
#ifdef _WIN32
#include <dbus/dbus.h>
#include "CDbusGlib.h"
#else                              
#include <dbus/dbus-glib.h>    
#include <dbus/dbus.h>  
#include <dbus/dbus-glib-lowlevel.h>
#endif

namespace HALO
{
	typedef std::list<std::string> RegEventList;

	class CDbus
	{
	public:
		CDbus();
		virtual ~CDbus();

		//! Initilize
		bool DbusInit(const char *appName);

		//! Send, if processName = NULL, send signal, else method call
		bool DbusSendEvent(const char *processName, const char *eventName, const char *eventData, char **resData, bool bAsysn);

		//! Receive, event pushed to queue
		void DbusRegEvent(const char *name);
		void DbusUnregEvent(const char *name);
		
	protected:
		bool t_SendSignal(int type, const char *eventName, const char *eventData);
		bool t_SendMethodcall(int type, const char *processName, const char *eventName, const char *eventData, char **resData, bool bAsysn);
		bool t_PushClutterQueue(const char *eventData);
		bool t_SyncEventProcess(const char *eventData, char **resData);

		static DBusHandlerResult t_SignalFilter (DBusConnection *connection, DBusMessage *message, void *user_data);
	private:
		DBusConnection *m_bus;
		DBusError m_error; 
		//char *m_name;
		RegEventList *m_regEventList;

		void m_RegEventName(const char * eventName);
		void m_UnregEvenName(const char * eventName);
		bool m_IsRegEvent(const char * eventName);
	};
}

#endif

