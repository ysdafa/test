#ifndef WIN32

#include "Halo1_0.h"

static HALO::util::Logger LOGGER("AudioUI");

namespace HALO
{
	IAudioUI* IAudioUI::m_audioUI = NULL;
	
	IAudioUI* IAudioUI::GetInstance(void)
	{
		if (m_audioUI == NULL)
		{
			H_LOG_DEBUG(LOGGER, "Instance::CreateInstance" );
			m_audioUI = (IAudioUI*)Instance::CreateInstance(CLASS_ID_IAUDIOUI);
		}
		return m_audioUI;
	}
}

#endif // !WIN32
