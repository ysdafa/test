#if !defined(WIN32) && !defined(LINUX_BUILD)
#include "Halo1_0.h"
#include "TTSEngine.h"

static HALO::util::Logger LOGGER("TTS");

namespace HALO
{
	const char* VCONF_KEY_ACCESSIBILITY_TTS = "db/menu/accessibility/tts";
	
	static void tts_state_changed_cb(tts_h tts, tts_state_e previous, tts_state_e current, void* user_data)
	{
		return;
	}

	static void tts_utt_started_cb(tts_h tts, int utt_id, void* user_data)
	{	
		return;
	}

	static void tts_utt_completed_cb(tts_h tts, int utt_id, void* user_data)
	{

	}
		
	TTSEngine& TTSEngine::Instance()
	{
	  static TTSEngine singleton;
	  return singleton;
	}
	
	TTSEngine::TTSEngine()
	{
		m_mode=TTS_MODE_SCREEN_READER;
		int ret;
		int flag = 0;
		
		vconf_get_int(VCONF_KEY_ACCESSIBILITY_TTS, &flag);
		if( flag )
		{
			m_ttsOn = true;	
			H_LOG_TRACE(LOGGER,"tts mode on");
		}
		else{
			m_ttsOn = false;
			H_LOG_TRACE(LOGGER,"tts mode off");
		}
		
		vconf_notify_key_changed(VCONF_KEY_ACCESSIBILITY_TTS, m_VconfKeyChangeCb, NULL);
				
		ret = tts_create(&m_tts);
		if (TTS_ERROR_NONE != ret)
		{
			H_LOG_TRACE(LOGGER,"tts_create_fail");
		}

		ret = tts_set_mode(m_tts, m_mode);
		if (TTS_ERROR_NONE != ret)
		{
			H_LOG_TRACE(LOGGER,"tts_setmode fail");
			tts_destroy(m_tts);
		}

		ret = tts_set_state_changed_cb(m_tts, tts_state_changed_cb, NULL);
		if (TTS_ERROR_NONE != ret)
		{
			H_LOG_TRACE(LOGGER,"tts_set_stage_changed fail");
			tts_destroy(m_tts);	
		}

		ret = tts_set_utterance_started_cb(m_tts, tts_utt_started_cb, NULL);
		if (TTS_ERROR_NONE != ret)
		{	
			H_LOG_TRACE(LOGGER,"tts_set_utterance_started fail");
			tts_destroy(m_tts);	
		}

		ret = tts_set_utterance_completed_cb(m_tts, tts_utt_completed_cb, NULL);
		if (TTS_ERROR_NONE != ret)
		{
			H_LOG_TRACE(LOGGER,"tts_set_utterance_completed fail");
			tts_destroy(m_tts);	
		}
	

		ret = tts_prepare(m_tts);	
		if (TTS_ERROR_NONE != ret) 
		{
			H_LOG_TRACE(LOGGER,"tts_prepare fail");		
			tts_destroy(m_tts);
		}
		
		H_LOG_TRACE(LOGGER,"tts init success");
	
	}
	TTSEngine::~TTSEngine() 
	{
	
	}

	void TTSEngine::m_VconfKeyChangeCb(keynode_t *keyNode, void *dt)
	{
		int flag;
		vconf_get_int(VCONF_KEY_ACCESSIBILITY_TTS, &flag);
		if(flag > 0)
			TTSEngine::Instance().SetState(true);
		else
			TTSEngine::Instance().SetState(false);
	}

	void TTSEngine::SetText(const std::string text)
	{
		if( m_ttsOn )
		{
			m_text = text;
		}
	}

	void TTSEngine::StopAndPlay()
	{
		if( m_ttsOn )
		{
			int utt_id;
			tts_stop(m_tts);
			tts_add_text(m_tts, m_text.c_str(), NULL, TTS_VOICE_TYPE_AUTO, TTS_SPEED_AUTO, &utt_id);
			tts_play(m_tts);
		}
	}

	void TTSEngine::Play()
	{
		if( m_ttsOn )
		{
			int utt_id;
			int ret;
			ret = tts_add_text(m_tts, m_text.c_str(), NULL, TTS_VOICE_TYPE_AUTO, TTS_SPEED_AUTO, &utt_id);
			H_LOG_TRACE(LOGGER, "tts_add_text result :"<<ret);
			tts_play(m_tts);		
		}
	}	

	void TTSEngine::Stop()
	{
		if( m_ttsOn )
		{
			tts_stop(m_tts);
		}
	}

	void TTSEngine::SetState(bool state)
	{
		m_ttsOn = state;
		
		if( m_ttsOn )
			H_LOG_TRACE(LOGGER,"tts mode on");
		else
			H_LOG_TRACE(LOGGER,"tts mode off");
	}

	bool TTSEngine::GetState()
	{
		return m_ttsOn;
	}
}
#endif
		




