#include "TTSEngine.h"

static HALO::util::Logger LOGGER("TTS");

namespace HALO
{
	static void __tts_test_state_changed_cb(tts_h tts, tts_state_e previous, tts_state_e current, void* user_data)
	{
		if (TTS_STATE_CREATED == previous && TTS_STATE_READY == current)
		{		
			TTSEngine::Instance().__tts_test_play(tts);
		}
		return;
	}

	static void __tts_test_utt_started_cb(tts_h tts, int utt_id, void* user_data)
	{	
		return;
	}

	static void __tts_test_utt_completed_cb(tts_h tts, int utt_id, void* user_data)
	{

	}
		

	TTSEngine& TTSEngine::Instance()
	{
	  static TTSEngine singleton;
	  return singleton;
	}
	
	TTSEngine::TTSEngine()
	{
		memset(m_text, 0, 1000);
		snprintf(m_text, 100, "%s", "tts start");	
		m_mode = TTS_MODE_DEFAULT;

		int ret;
		int utt_id;	
				
		ret = tts_create(&m_tts);
		if (TTS_ERROR_NONE != ret)
		{
			H_LOG_TRACE(LOGGER,"tts_create_fail");
		}

		ret = tts_set_mode(m_tts, m_mode);
		if (TTS_ERROR_NONE != ret)
		{
			H_LOG_TRACE(LOGGER,"tts_setmode fail");
			tts_destroy(m_tts);
		}

		ret = tts_set_state_changed_cb(m_tts, __tts_test_state_changed_cb, NULL);
		if (TTS_ERROR_NONE != ret)
		{
			H_LOG_TRACE(LOGGER,"tts_set_stage_changed fail");
			tts_destroy(m_tts);	
		}

		ret = tts_set_utterance_started_cb(m_tts, __tts_test_utt_started_cb, NULL);
		if (TTS_ERROR_NONE != ret)
		{	
			H_LOG_TRACE(LOGGER,"tts_set_utterance_started fail");
			tts_destroy(m_tts);	
		}

		ret = tts_set_utterance_completed_cb(m_tts, __tts_test_utt_completed_cb, NULL);
		if (TTS_ERROR_NONE != ret)
		{
			H_LOG_TRACE(LOGGER,"tts_set_utterance_completed fail");
			tts_destroy(m_tts);	
		}
	

		ret = tts_prepare(m_tts);	
		if (TTS_ERROR_NONE != ret) 
		{
			H_LOG_TRACE(LOGGER,"tts_prepare fail");		
			tts_destroy(m_tts);
		}
	
	}
	TTSEngine::~TTSEngine() 
	{
	
	}

	void TTSEngine::SetText(const std::string text)
	{
		memset(m_text, 0, 1000);	
		snprintf(m_text, 1000, "%s", text.c_str());
			
	}

	bool TTSEngine::__tts_test_destroy(void *data)
	{	
		int ret;

		ret = tts_stop((tts_h)data );
		ret = tts_unprepare((tts_h)data);	
		ret = tts_destroy((tts_h)data  );
		return false;
	}

	bool TTSEngine::__tts_test_play(void *data)
	{	
		int utt_id;	
		int ret;	
		
		ret = tts_add_text((tts_h)data, m_text, NULL, TTS_VOICE_TYPE_AUTO, TTS_SPEED_AUTO, &utt_id);		
		
		ret = tts_play((tts_h)data);
		return false;
	}

	void TTSEngine::StopAndPlay()
	{
		int utt_id;
		tts_stop(m_tts);
		tts_add_text(m_tts, m_text, NULL, TTS_VOICE_TYPE_AUTO, TTS_SPEED_AUTO, &utt_id);
		tts_play(m_tts);
	}

	void TTSEngine::Play()
	{
		int utt_id;
		int ret;
		ret = tts_add_text(m_tts, m_text, NULL, TTS_VOICE_TYPE_AUTO, TTS_SPEED_AUTO, &utt_id);
		H_LOG_TRACE(LOGGER, "tts_add_text result :"<<ret);
		tts_play(m_tts);		
	}	

	void TTSEngine::Stop()
	{
		tts_stop(m_tts);
	}
}

		




