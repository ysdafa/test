#include "Halo1_0.h"

#include <sys/types.h>

#ifdef WIN32
#include <time.h>
#include <process.h>
#include <io.h>
#include <pthread.h>
#else
#include <unistd.h>
#include <strings.h>
#endif

#ifdef USE_LOG4CPLUS
#include <log4cplus/configurator.h>
#endif

namespace HALO
{
namespace util
{

#ifdef USE_LOG4CPLUS
#else
Logger::LogLevel Logger::level_ = Logger::kFatal;
#endif

Logger::Logger(const std::string &aName):
#ifdef USE_LOG4CPLUS
  logger_(log4cplus::Logger::getInstance(aName))
#else
  name_(aName)
#endif
{
}

Logger::~Logger()
{
}

void Logger::Configure(const std::string &aConfigPath)
{
#ifdef USE_LOG4CPLUS
  log4cplus::PropertyConfigurator config(aConfigPath);
  config.configure();
#endif
}

void Logger::SetLogLevel(const LogLevel aLevel)
{
#ifdef USE_LOG4CPLUS
  log4cplus::Logger::getRoot().setLogLevel(Log4CplusLevel(aLevel));
#else
  level_ = aLevel;
#endif
}

const char* Logger::LevelToString(const LogLevel aLevel)
{
  switch(aLevel)
  {
    case kFatal: return "Fatal";
    case kMajor: return "Major";
    case kWarn: return "Warn";
    case kDebug: return "Debug";
    case kInfo: return "Info";
    default: return "???";
  }
}


Logger::LogLevel Logger::StringToLevel(const char *aLevelStr)
{
	#ifdef WIN32
	if (aLevelStr == NULL) return kFatal;
	else if(_stricmp(aLevelStr, "major") == 0) return kMajor;
	else if(_stricmp(aLevelStr, "warn") == 0) return kWarn;
	else if(_stricmp(aLevelStr, "debug") == 0) return kDebug;
	else if(_stricmp(aLevelStr, "info") == 0) return kInfo;
	else return kFatal;
	#else
	if (aLevelStr == NULL) return kFatal;
	else if(strcasecmp(aLevelStr, "major") == 0) return kMajor;
	else if(strcasecmp(aLevelStr, "warn") == 0) return kWarn;
	else if(strcasecmp(aLevelStr, "debug") == 0) return kDebug;
	else if(strcasecmp(aLevelStr, "info") == 0) return kInfo;
	else return kFatal;
	#endif
}

#ifdef USE_LOG4CPLUS
log4cplus::LogLevel Logger::Log4CplusLevel(const LogLevel aLevel)
{
  switch (aLevel)
  {
    case kMajor: return log4cplus::ERROR_LOG_LEVEL;
    case kWarn: return log4cplus::WARN_LOG_LEVEL;
    case kDebug: return log4cplus::DEBUG_LOG_LEVEL;
    case kInfo: return log4cplus::TRACE_LOG_LEVEL;
    case kFatal:
    default: return log4cplus::FATAL_LOG_LEVEL;
  }
}
#else
void Logger::Log(const char *aFile, const char *aFunc, const unsigned int aLine,
                 const LogLevel aLevel, const char *aDlogTag, std::string aMsg) const
{
  time_t time_stamp = time(NULL);
#ifdef WIN32
  struct tm* tm_buf = localtime(&time_stamp);
  char date_buf[20];
  if (strftime(date_buf, 20, "%Y-%m-%dT%H:%M:%S", tm_buf) == 0) date_buf[0] = '\0';

  const char *file_name = strrchr(aFile, '/') ? strrchr(aFile, '/') + 1 : aFile;

  static const char *fmt = "[Halo|%s|%lu|%lu|%s:%s:%d] %s\n";
#else
  struct tm tm_buf;
  localtime_r(&time_stamp, &tm_buf);
  char date_buf[20];
  if (strftime(date_buf, 20, "%Y-%m-%dT%H:%M:%S", &tm_buf) == 0) date_buf[0] = '\0';

  const char *file_name = strrchr(aFile, '/') ? strrchr(aFile, '/') + 1 : aFile;

  static const char *fmt = "[Halo|%s|%lu|%lu|%s:%s:%d] %s\n";
#endif

#ifdef USE_DLOG
  log_priority prio = DLOG_VERBOSE;

  switch (aLevel)
  {
    case kFatal:
      prio = DLOG_FATAL;
      break;
    case kMajor:
      prio = DLOG_ERROR;
      break;
    case kWarn:
      prio = DLOG_WARN;
      break;
    case kDebug:
      prio = DLOG_DEBUG;
      break;
    case kInfo:
      prio = DLOG_VERBOSE;
      break;
    default:
      break;
  }

  /* Log every msg.  Filtering is done by dlog/dlogutil. */
  __dlog_print(LOG_ID_MAIN, prio, aDlogTag, fmt,
               date_buf, getpid(), pthread_self(),
               file_name, aFunc, aLine, aMsg.c_str());
#else
  if (aLevel > level_) return;

#ifdef WIN32
  unsigned long thd = (unsigned long)pthread_self().p;
  printf(fmt,
	  date_buf, getpid(), thd,
	  file_name, aFunc, aLine, aMsg.c_str());
#else
  printf(fmt,         
	  date_buf, getpid(), pthread_self(),
	  file_name, aFunc, aLine, aMsg.c_str());
#endif

#endif /* USE_DLOG */
}
#endif /*USE_LOG4CPLUS */

} /* namespace util */
} /* namespace HALO */
