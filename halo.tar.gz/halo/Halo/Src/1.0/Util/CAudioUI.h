#ifndef WIN32

#ifndef _HALO_CAUDIOUI_H_
#define _HALO_CAUDIOUI_H_

namespace HALO
{
	class HALO_API CAudioUI : public IAudioUI
	{
		public:
			CAudioUI();
			~CAudioUI();
			virtual bool Play(int pattern);
			
	};

}
#endif
#endif
