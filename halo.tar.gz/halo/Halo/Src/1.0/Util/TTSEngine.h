#include "Halo1_0.h"

#if !defined(WIN32) && !defined(LINUX_BUILD)
#include <tts.h>

namespace HALO
{
	class TTSEngine
	{
	public:
		static TTSEngine& Instance();
		void SetText(const std::string text);
		void StopAndPlay();
		void Play();
		void Stop();
		void SetState(bool state);
		bool GetState();
					
	private:
		TTSEngine();
		~TTSEngine();
		static void m_VconfKeyChangeCb(keynode_t *keyNode, void *dt);
		
		tts_h m_tts;
		std::string m_text;
		tts_mode_e m_mode;	
		bool m_ttsOn;

	};
}
#endif
