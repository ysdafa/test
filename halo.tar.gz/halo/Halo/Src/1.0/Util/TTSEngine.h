#include "Halo1_0.h"

#include <tts.h>

namespace HALO
{
	class TTSEngine
	{
	public:
		static TTSEngine& Instance();
		void SetText(const std::string text);
		bool __tts_test_destroy(void *data);
		bool __tts_test_play(void *data);
		//void __tts_test_state_changed_cb(tts_h tts, tts_state_e previous, tts_state_e current, void* user_data);
		//void __tts_test_utt_started_cb(tts_h tts, int utt_id, void* user_data);
		//void __tts_test_utt_completed_cb(tts_h tts, int utt_id, void* user_data);
		void StopAndPlay();
		void Play();
		void Stop();
			
	private:
		TTSEngine();
		~TTSEngine();

		tts_h m_tts;
		char m_text[1000];
		tts_mode_e m_mode;	

	};
}
