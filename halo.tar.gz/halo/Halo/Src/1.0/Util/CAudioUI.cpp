#ifndef WIN32

#include "Halo1_0.h"
#include <feedback/feedback.h>

static HALO::util::Logger LOGGER("AudioUI");

namespace HALO
{
	CAudioUI::CAudioUI()
	{
		int ret = feedback_initialize();
		H_LOG_TRACE(LOGGER, "feedback initialize ret:"<<ret);
		if (ret != FEEDBACK_ERROR_NONE) {
			H_LOG_TRACE(LOGGER, "feedback initialize fail:"<<ret);
		}
	}

	CAudioUI::~CAudioUI()
	{
		
		int ret = feedback_deinitialize();
		H_LOG_TRACE(LOGGER, "feedback deinitialize ret:"<<ret);
		if (ret != FEEDBACK_ERROR_NONE) {
			H_LOG_TRACE(LOGGER, "feedback deinitialize fail:"<<ret);
		}
	}

	bool CAudioUI::Play(int pattern)
	{
		int ret = -1;
		switch (pattern)
		{
			case 0:
				ret = feedback_play(FEEDBACK_PATTERN_MOVE_NAVIGATION);		
				break;
			case 1:
				ret = feedback_play(FEEDBACK_PATTERN_MOVE_PANEL);		
				break;
			case 2:
				ret = feedback_play(FEEDBACK_PATTERN_MOVE_BACK);		
				break;
			case 3:
				ret = feedback_play(FEEDBACK_PATTERN_MOVE_NOKEY);		
				break;
			case 4:
				ret = feedback_play(FEEDBACK_PATTERN_SELECT);		
				break;
			case 5:
				ret = feedback_play(FEEDBACK_PATTERN_CANCEL);		
				break;
			case 6:
				ret = feedback_play(FEEDBACK_PATTERN_KEY0);		
				break;
			case 7:
				ret = feedback_play(FEEDBACK_PATTERN_KEY1);		
				break;
			case 8:
				ret = feedback_play(FEEDBACK_PATTERN_POPUP);		
				break;
			case 9:
				ret = feedback_play(FEEDBACK_PATTERN_VOICE_RESPONSE);		
				break;
			case 10:
				ret = feedback_play(FEEDBACK_PATTERN_OSK_BACKSPACE);		
				break;
			case 11:
				ret = feedback_play(FEEDBACK_PATTERN_OSK_ENTER);		
				break;
			case 12:
				ret = feedback_play(FEEDBACK_PATTERN_OSK_KEYPAD);		
				break;
			case 13:
				ret = feedback_play(FEEDBACK_PATTERN_OSK_SPACE);		
				break;
			case 14:
				ret = feedback_play(FEEDBACK_PATTERN_TAP);		
				break;
			case 15:
				ret = feedback_play(FEEDBACK_PATTERN_SIP);		
				break;
			case 16:
				ret = feedback_play(FEEDBACK_PATTERN_SIP_BACKSPACE);		
				break;
			default:
				break;
		}
				
		H_LOG_TRACE(LOGGER, "feedback play ret:"<<ret);
		if (ret != FEEDBACK_ERROR_NONE) {
			H_LOG_TRACE(LOGGER, "feedback play fail:"<<ret);
		}
				
	}
	
}
#endif
