#include "Halo1_0.h"

static HALO::util::Logger LOGGER("Bundle");

namespace HALO
{
	CBundle::CBundle()
	{
		m_pBundle = NULL;
	}

	CBundle::CBundle(const CBundle& that)
	{
		m_pBundle = NULL;
		TKeyVal* new_kv = NULL;
		TKeyVal* kv = that.m_pBundle;
		while (kv)
		{
			new_kv = new TKeyVal(*kv);
			new_kv->next = m_pBundle;
			m_pBundle = new_kv;
			kv = kv->next;
		}
	}

	CBundle::~CBundle()
	{
		TKeyVal* temp = NULL;
		while (m_pBundle)
		{
			temp = m_pBundle->next;
			delete m_pBundle;
			m_pBundle = temp;
		}
	}

	CBundle& CBundle::operator=(const CBundle& that)
	{
		TKeyVal* temp = NULL;
		while (m_pBundle)
		{
			temp = m_pBundle->next;
			delete m_pBundle;
			m_pBundle = temp;
		}
		TKeyVal* kv = that.m_pBundle;
		while (kv)
		{
			temp = new TKeyVal(*kv);
			temp->next = m_pBundle;
			m_pBundle = temp;
			kv = kv->next;
		}
		return *this;
	}
	
	CBundle::TKeyVal* CBundle::m_pKeyValNew(TKeyVal *kv, const char *key, const int type, const void* val, const size_t size)
	{
		int must_free_obj;
		must_free_obj = kv ? 0 : 1;

		if (!kv)
		{
			kv = new TKeyVal;		
		}

		//key
		if (kv->key)
		{
			m_KeyValFree(kv, must_free_obj);
			return NULL;
		}
		kv->key = strdup(key);
		if (!kv->key)
		{
			m_KeyValFree(kv, must_free_obj);
			return NULL;
		}

		//elementa of primitive types
		kv->type = type;
		kv->size = size;

		if (size)
		{
			kv->val = new char[size];
			if (!kv->val)
			{
				m_KeyValFree(kv, 1);
			}
			if (val) 
			{
				memcpy(kv->val, val, size);
			}	
		}

		return kv;
	}

	void CBundle::m_KeyValFree(TKeyVal* kv, int object)
	{
		if (!kv) 
		{
			return;
		}

		if (kv->key)
		{
			delete (kv->key);
			kv->key = NULL;
		}

		if (NULL != kv->val) 
		{
			delete (static_cast<char*>(kv->val));
			kv->val = NULL;
		}

		if(object)
		{
			delete kv;
		}
		
		return;
	}

	int CBundle::m_KeyValGetData(TKeyVal* kv, int* type, void** val, size_t* size)
	{
		if (!kv) 
		{
			return -1;
		}
		if (type) 
		{
			*type = kv->type;
		}
		if (val) 
		{
			*val = kv->val;
		}
		if (size) 
		{
			*size = kv->size;
		}
		
		return 0;
	}

	size_t CBundle::m_KeyValGetEncodedSize(TKeyVal* kv)
	{
		if (!kv) 
		{
			return 0;
		}

		size_t enconde_size = sizeof(size_t)
								+ sizeof(int)
								+ sizeof(size_t)
								+ strlen(kv->key) + 1
								+ sizeof(size_t)
								+ kv->size;

		return enconde_size;
	}

	size_t CBundle::m_KeyValEncode(TKeyVal *kv, unsigned char **byte, size_t *byte_len)
	{
		static const size_t sz_type = sizeof(int);
		static const size_t sz_keysize = sizeof(size_t);
		size_t sz_key = strlen(kv->key) + 1;
		static const size_t sz_size = sizeof(size_t);
		size_t sz_val = kv->size;

		*byte_len = m_KeyValGetEncodedSize(kv);
		*byte = new unsigned char[*byte_len];
		if (!*byte) 
		{
			return 0;
		}

		unsigned char *p = *byte;
		
		memcpy(p, byte_len, sizeof(size_t)); p += sizeof(size_t);
		memcpy(p, &(kv->type), sz_type); p += sz_type;
		memcpy(p, &sz_key, sz_keysize); p += sz_keysize;
		memcpy(p, kv->key, sz_key); p += sz_key;
		memcpy(p, &(kv->size), sz_size); p += sz_size;
		memcpy(p, kv->val, sz_val); p += sz_val;

		return *byte_len;
	}

	size_t CBundle::m_KeyValDecode(unsigned char *byte, TKeyVal **kv)
	{
		static const size_t sz_byte_len = sizeof(size_t);
		static const size_t sz_type = sizeof(int);
		static const size_t sz_keysize = sizeof(size_t);
		static const size_t sz_size = sizeof(size_t);

		unsigned char *p = byte;

		size_t byte_len = *((size_t *)p); p += sz_byte_len;
		int type = *((int *)p); p += sz_type;
		size_t keysize = *((size_t *)p); p += sz_keysize;
		char *key = (char *)p; p += keysize;
		size_t size = *((size_t *)p); p += sz_size;
		void* val = (void *)p; p += size;

		if(kv) 
		{
			*kv = m_pKeyValNew(*kv, key, type, val, size);	// If *kv != NULL, use given kv
		}

		return byte_len;
	}

	CBundle::TKeyVal* CBundle::m_pFindKeyVal(const char* key)
	{
		TKeyVal* kv;
		if (!key)
		{
			return NULL;
		}
		
		kv = m_pBundle;
		while (kv != NULL)
		{
			if ( 0 == strcmp(key, kv->key))
			{
				return kv;
			}
			kv = kv->next;
		}

		/* Not found */
		return NULL;
	}

	int CBundle::m_AppendKeyVal(TKeyVal* new_kv)
	{	
		new_kv->next = m_pBundle;
		m_pBundle = new_kv;

		return 0;
	}
	
	int CBundle::m_AddKeyVal(const char* key, const void* val, const size_t size, const int type)
	{
		if (NULL == key || 0 == strlen(key))
		{
			return -1;
		}

		TKeyVal* kv = m_pFindKeyVal(key);
		if (kv)
		{ 
			return -1;   /* Key already exists*/
		}

		TKeyVal *new_kv = NULL;
		new_kv = m_pKeyValNew(NULL, key, type, val, size);

		if (!new_kv) 
		{
			return -1;
		}
		
		int flag = m_AppendKeyVal(new_kv);
		
		if (!flag)
		{
			return 0;
		}
		else 
		{
			return -1;
		}
	}

	int CBundle::m_GetVal(const char* key, const int type, void** val, size_t* size)
	{
		TKeyVal* kv = m_pFindKeyVal(key);
		if (!kv)
		{
			return -1;
		} //Key doesn't exist
		
		if (BUNDLE_TYPE_ANY != type && type != kv->type)
		{
			return -1;
		}

		int flag = m_KeyValGetData(kv, NULL, val, size);
		
		if (!flag)
		{
			return 0;
		}
		else 
		{
			return -1;
		}
	}

	int CBundle::EncodeBundle(unsigned char** r, int* len)
	{
		H_LOG_TRACE(LOGGER, "CBundle::EncodeBundle");
		TKeyVal* kv;
		unsigned char* m;
		unsigned char* p;
		unsigned char* byte;
		size_t byte_len;

		/* calculate memory size */
		size_t msize = 0;	// Sum of required size

		kv = m_pBundle;
		while (kv != NULL )
		{
			msize += m_KeyValGetEncodedSize(kv);
			kv = kv->next;
		}
		m = new unsigned char[msize];
		p = m;
		if (!m) 
		{
			return -1;
		}

		kv = m_pBundle;
		while (kv != NULL)
		{
			byte = NULL;
			byte_len = 0;

			m_KeyValEncode(kv, &byte, &byte_len);

			memcpy(p, byte, byte_len); 
			p += byte_len;

			kv = kv->next;

			delete[] byte;
		}

		if (NULL != r)
		{
			*r = (unsigned char*)g_base64_encode(m, msize);
			if (NULL != len) 
			{
				*len = strlen((char*)*r);
			}
		}

		delete[] m;

		return 0;
	}

	int CBundle::DecodeBundle(const unsigned char* r, const int data_size)
	{
		H_LOG_TRACE(LOGGER, "CBundle::DecodeBundle(" << data_size << ")");
		unsigned char* p_r;
		unsigned char* d_str;
		unsigned int d_len_raw;
		
		if (NULL == r)
		{
			return 0;
		}

		d_str = g_base64_decode((char*)r, (gsize*)&d_len_raw);

		p_r = d_str;

		size_t bytes_read;
		TKeyVal* kv;

		while (p_r < d_str + d_len_raw - 1)
		{
			kv = NULL;

			bytes_read = m_KeyValDecode(p_r, &kv);

			if (kv) 
			{
				m_AppendKeyVal(kv);
			}
			else
			{
				break;
			}

			p_r += bytes_read;
		}

		delete d_str;
		
		return 0;
	}
	
	int CBundle::AddInt(const char* key, int value)
	{
		H_LOG_TRACE(LOGGER, "CBundle::AddInt(" << key <<", " << value << ")");
		char buf[12];

		SNPRINTF(buf, 12, "%d", value);
		
		return m_AddKeyVal(key, buf, strlen(buf)+1, BUNDLE_TYPE_INT);
	}

	int CBundle::AddLong(const char* key, long value)
	{
		H_LOG_TRACE(LOGGER, "CBundle::AddLong(" << key <<", " << value << ")");
		char buf[32];

		SNPRINTF(buf, 32, "%ld", value);
		
		return m_AddKeyVal(key, buf, strlen(buf)+1, BUNDLE_TYPE_LONG);
	}

	int CBundle::AddDouble(const char* key, double value)
	{
		H_LOG_TRACE(LOGGER, "CBundle::AddDouble(" << key <<", " << value << ")");
		char buf[32];

		SNPRINTF(buf, 32, "%.15f", value);
	
		return m_AddKeyVal(key, buf, strlen(buf)+1, BUNDLE_TYPE_DOUBLE);
	}

	int CBundle::AddFloat(const char* key, float value)
	{
		H_LOG_TRACE(LOGGER, "CBundle::AddFloat(" << key <<", " << value << ")");
		char buf[32];

		SNPRINTF(buf, 32, "%.7f", value);
		
		return m_AddKeyVal(key, buf, strlen(buf)+1, BUNDLE_TYPE_FLOAT);
	}
	
	int CBundle::AddChar(const char* key, char value)
	{
		H_LOG_TRACE(LOGGER, "CBundle::AddChar(" << key <<", " << value << ")");
		char buf[32];

		SNPRINTF(buf, 32, "%c", value);

		return m_AddKeyVal(key, &value, strlen(buf)+1, BUNDLE_TYPE_CHAR);
	}

	int CBundle::AddString(const char* key, const char* value)
	{
		H_LOG_TRACE(LOGGER, "CBundle::AddString(" << key <<", " << value << ")");
		return m_AddKeyVal(key, value, strlen(value)+1, BUNDLE_TYPE_STR);
	}

	int CBundle::IntValue(const char* key, int& value)
	{	
		H_LOG_TRACE(LOGGER, "CBundle::IntValue(" << key << ")");
		int flag = 0;
		void* buf = NULL;

		flag = m_GetVal(key, BUNDLE_TYPE_INT, (void **)&buf, NULL);

		if (flag || buf == NULL)
		{
			H_LOG_FATAL(LOGGER, "CBundle::IntValue m_GetVal error");
			return -1;
		}
		value = atoi((char*)buf);	
		H_LOG_TRACE(LOGGER, "CBundle::IntValue: value = " << value);

		return 0;
	}
	int CBundle::LongValue(const char* key, long& value)
	{
		H_LOG_TRACE(LOGGER, "CBundle::LongValue(" << key << ")");
		void* buf = NULL;

		m_GetVal(key, BUNDLE_TYPE_LONG, (void **)&buf, NULL);

		if (buf == NULL)
		{
			H_LOG_FATAL(LOGGER, "CBundle::LongValue m_GetVal error");
			return -1;
		}
		value = atol((char*)buf);
		H_LOG_TRACE(LOGGER, "CBundle::LongValue: value = " << value);

		return 0;
	}

	int CBundle::DoubleValue(const char* key, double& value)
	{
		H_LOG_TRACE(LOGGER, "CBundle::DoubleValue(" << key << ")");
		int flag;

		void* buf = NULL;

		flag = m_GetVal(key, BUNDLE_TYPE_DOUBLE, (void**)&buf, NULL);

		if (flag || buf == NULL)
		{
			H_LOG_FATAL(LOGGER, "CBundle::DoubleValue m_GetVal error");
			return -1;
		}
		value = atof((char*)buf);
		H_LOG_TRACE(LOGGER, "CBundle::DoubleValue: value = " << value);

		return 0;
	}

	int CBundle::FloatValue(const char* key, float& value)
	{
		H_LOG_TRACE(LOGGER, "CBundle::FloatValue(" << key << ")");
		int flag;

		void* buf = NULL;

		flag = m_GetVal(key, BUNDLE_TYPE_FLOAT, (void**)&buf, NULL);

		if (flag || buf == NULL)
		{
			H_LOG_FATAL(LOGGER, "CBundle::FloatValue m_GetVal error");
			return -1;
		}
		value = static_cast<float>(atof((char*)buf));
		H_LOG_TRACE(LOGGER, "CBundle::FloatValue: value = " << value);
		
		return 0;
	}

	int CBundle::CharValue(const char* key, char& value)
	{
		H_LOG_TRACE(LOGGER, "CBundle::CharValue(" << key << ")");
		int flag;

		void* buf = NULL;

		flag = m_GetVal(key, BUNDLE_TYPE_CHAR, (void**)&buf, NULL);

		if (flag || buf == NULL)
		{
			H_LOG_FATAL(LOGGER, "CBundle::CharValue m_GetVal error");
			return -1;
		}
		value = *(char*)buf;
		H_LOG_TRACE(LOGGER, "CBundle::CharValue: value = " << value);

		return 0;
	}

	int CBundle::StringValue(const char* key, char** value)
	{
		H_LOG_TRACE(LOGGER, "CBundle::StringValue(" << key << ")");
		return m_GetVal(key, BUNDLE_TYPE_STR, (void**)value, NULL);
	}

}//end namespace
