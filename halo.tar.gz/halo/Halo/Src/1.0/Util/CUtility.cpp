#include "Halo1_0.h"

#include "ua_extract_color.h"

#ifdef _WIN32
#include <winuser.h>
#else
namespace HALO { 
#include <X11/X.h> 
#include <X11/Xlib.h> 
#include <X11/Xutil.h> 
#include <utilX.h>
}
#endif

static HALO::util::Logger LOGGER("Utility");

namespace HALO
{
	bool CUtility::ExtractForegroundColor(unsigned int from_r, unsigned int from_g, unsigned int from_b, unsigned int *to_r, unsigned int * to_g, unsigned int* to_b)
	{
		return ua_extract_foreground_color_get(from_r, from_g, from_b, to_r, to_g, to_b);
	} 

	bool CUtility::GetCurrentResolution(int& hRes, int& vRes)
	{
		bool ret = false;
#ifdef _WIN32
		hRes = GetSystemMetrics(SM_CXSCREEN);
		vRes = GetSystemMetrics(SM_CYSCREEN);
		ret = true;
#else
		Display* display = XOpenDisplay(NULL);
		ret = utilx_get_current_resolution(display, &hRes, &vRes) == 0;
		H_LOG_TRACE(LOGGER, "Resolution: " << hRes << " * " << vRes);
		XCloseDisplay(display);
#endif
		return ret;
	}

	bool CUtility::AsyncRelease(Widget* target)
	{
		IEventManager* pEventManager = IEventManager::GetInstance();
		if (NULL == pEventManager)
		{
			return false;
		}

		ISystemEvent* pAsyncDestroyEvent = ISystemEvent::CreateInstance();
		if (NULL == pAsyncDestroyEvent)
		{
			return false;
		}

		pAsyncDestroyEvent->SetEventType("samsung.tv.halo.system.asyncrelease");
		pAsyncDestroyEvent->PutPointor("Target", target);

		pEventManager->SendEventLocal(pAsyncDestroyEvent);

		pAsyncDestroyEvent->Release();
		return true;
	}

}

