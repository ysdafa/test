#include "Halo1_0.h"

#include "ua_extract_color.h"
#include "interpolate.h"

#ifdef _WIN32
#include <winuser.h>
#elif defined LINUX_BUILD
#else
#include "reverseOSD.h"
namespace HALO { 
#include <X11/X.h> 
#include <X11/Xlib.h> 
#include <X11/Xutil.h> 
#include <utilX.h>
}
#endif

static HALO::util::Logger LOGGER("Utility");

namespace HALO
{
	IUtility::EResolution CUtility::m_resolution = IUtility::RESOLUTION_1080;
	int CUtility::m_hRes = 1920;
	int CUtility::m_vRes = 1080;
	
	CUtility::CUtility() :m_orientation(ORIENTATION_LEFT_TO_RIGHT), m_flagHighContrast(false), m_flagEnlarge(false), m_flag720P(false)
	{
		m_initResolution();
	}
	CUtility::~CUtility()
	{

	}
	bool CUtility::ExtractForegroundColor(unsigned int from_r, unsigned int from_g, unsigned int from_b, unsigned int *to_r, unsigned int * to_g, unsigned int* to_b)
	{
		return ua_extract_foreground_color_get(from_r, from_g, from_b, to_r, to_g, to_b);
	} 

	IUtility::ColorCategory CUtility::ExtractIconColor(unsigned int from_r, unsigned int from_g, unsigned int from_b)
	{
		return (ColorCategory)ua_extract_icon_color_get(from_r, from_g, from_b);
	}

	bool CUtility::GetCurrentResolution(int& hRes, int& vRes)
	{
		hRes = m_hRes;
		vRes = m_vRes;

		return true;
	}

	IUtility::EResolution CUtility::GetCurrentResolution(void)
	{
		//H_LOG_TRACE(LOGGER, "CUtility::GetCurrentResolution: m_resolution = " << m_resolution);

		return m_resolution;
	}

	bool CUtility::m_initResolution(void)
	{
		bool ret = false;
#ifdef _WIN32
		m_hRes = GetSystemMetrics(SM_CXSCREEN);
		m_vRes = GetSystemMetrics(SM_CYSCREEN);
		ret = true;
#elif defined LINUX_BUILD
		m_hRes = 1920;
		m_vRes = 1080;
#else
		Display* display = XOpenDisplay(NULL);
		ret = utilx_get_current_resolution(display, &m_hRes, &m_vRes) == 0;
		H_LOG_TRACE(LOGGER, "Resolution: " << m_hRes << " * " << m_vRes);
		XCloseDisplay(display);
#endif
		if (m_flag720P == false && m_vRes < 1080)
		{
			m_hRes = 1920;
			m_vRes = 1080;
			ret = true;
		}
		
		if (1280 == m_hRes && 720 == m_vRes)
		{
			m_resolution = RESOLUTION_720;
		}
		else //default
		{
			m_resolution = RESOLUTION_1080;
		}

		return ret;
	}

	bool CUtility::AsyncRelease(Widget* target)
	{
		IEventManager* pEventManager = IEventManager::GetInstance();
		if (NULL == pEventManager)
		{
			return false;
		}

		return pEventManager->AsyncRelease(target);
	}
	
	bool CUtility::AsyncReleaseListenerSet(ListenerSet* target)
	{
		IEventManager* pEventManager = IEventManager::GetInstance();
		if (NULL == pEventManager)
		{
			return false;
		}

		return pEventManager->AsyncReleaseListenerSet(target);
	}

	void CUtility::SetOrientation(EOrientation orientation)
	{
		if (m_orientation == orientation)
		{
			return;
		}
		Widget* root = NULL;
		Widget* child = NULL;
		CTextWidgetEx* childTextWidgetEx = NULL;
		CImageWidgetEx* childImageWidgetEx = NULL;
		CWidgetEx* childWidgetEx = NULL;

		m_orientation = orientation;

		VoltFullProcessRuntime *runtime = static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

		if (runtime)
		{
			root = dynamic_cast<Widget*>(runtime->GetSceneRoot());
		}

		if (root == NULL)
		{
			IStage* stage = IStage::GetInstance();
			root = dynamic_cast<Widget*>(stage->RootActor());
		}

		if (root)
		{
			unsigned int childCount = root->getChildCount();
			for (unsigned int i = 0; i < childCount; ++i)
			{
				child = root->getChildByIndex(i);
				if (childTextWidgetEx = dynamic_cast<CTextWidgetEx*>(child))
				{
					childTextWidgetEx->UpdateOrientation(orientation);
				}
				else if (childImageWidgetEx = dynamic_cast<CImageWidgetEx*>(child))
				{
					childImageWidgetEx->UpdateOrientation(orientation);
				}
				else if (childWidgetEx = dynamic_cast<CWidgetEx*>(child))
				{
					childWidgetEx->UpdateOrientation(orientation);
				}
				else
				{
					H_LOG_WARN(LOGGER, "Not Halo uielement, can not reverse!");
				}
			}
		}
	}

	EOrientation CUtility::GetOrientation(void) const
	{
		EOrientation orientation = m_orientation;
		//H_LOG_TRACE(LOGGER, "CUtility::GetOrientation, orientation :" << (orientation == ORIENTATION_LEFT_TO_RIGHT ? "left-to-right" : "right-to-left"));
		return orientation;
	}
	void CUtility::ApplyOrientation(void)
	{
		EOrientation orientation = ORIENTATION_LEFT_TO_RIGHT;
#if !defined(WIN32) && !defined(LINUX_BUILD)
		orientation = ua_UI_orientation_get() == UA_RTL_UI_ORIENTATION ? ORIENTATION_RIGHT_TO_LEFT : ORIENTATION_LEFT_TO_RIGHT;
#endif
		m_orientation = orientation;
		H_LOG_TRACE(LOGGER, "CUtility::ChangeOrientation, orientation :" << (orientation == ORIENTATION_LEFT_TO_RIGHT? "left-to-right":"right-to-left"));

		Widget* root = NULL;

		VoltFullProcessRuntime *runtime = static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

		if (runtime)
		{
			root = dynamic_cast<Widget*>(runtime->GetSceneRoot());
		}

		if (root == NULL)
		{
			IStage* stage = IStage::GetInstance();
			root = dynamic_cast<Widget*>(stage->RootActor());
		}

		if (root)
		{
			CWidgetExtension* childWidgetEx = NULL;
			unsigned int childCount = root->getChildCount();
			for (unsigned int i = 0; i < childCount; ++i)
			{
				if (childWidgetEx = dynamic_cast<CWidgetExtension*>(root->getChildByIndex(i)))
				{
					childWidgetEx->UpdateOrientation(orientation);
				}
				else
				{
					H_LOG_WARN(LOGGER, "Not Halo uielement, can not reverse!");
				}
			}
		}
	}
	float CUtility::GetInterpolatedValue(int type, float input)
	{
		H_LOG_TRACE(LOGGER, "type: " << type << "input: " << input);
		return ua_interpolated_value_get((Ua_Interpolator_Type)type,input);		
	}

	void CUtility::EnableHighContrast(const bool enable)
	{
		H_LOG_TRACE(LOGGER, "enable: " << enable);
		if (m_flagHighContrast == enable)
		{
			return;
		}
		Widget* root = NULL;
		Widget* child = NULL;
		CWidgetExtension* childWidgetEx = NULL;

		m_flagHighContrast = enable;

		VoltFullProcessRuntime *runtime = static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

		if (runtime)
		{
			root = dynamic_cast<Widget*>(runtime->GetSceneRoot());
		}

		if (root == NULL)
		{
			IStage* stage = IStage::GetInstance();
			root = dynamic_cast<Widget*>(stage->RootActor());
		}

		if (root)
		{
			unsigned int childCount = root->getChildCount();
			for (unsigned int i = 0; i < childCount; ++i)
			{
				child = root->getChildByIndex(i);
				if (childWidgetEx = dynamic_cast<CWidgetExtension*>(root->getChildByIndex(i)))
				{
					childWidgetEx->EnableHighContrast(enable);
				}
				else
				{
					H_LOG_WARN(LOGGER, "Not Halo uielement, can not high contrast!");
				}
			}
		}
	}

	bool CUtility::IsHighContrastEnabled(void) const
	{
		return m_flagHighContrast;
	}

	void CUtility::EnableEnlarge(const bool enable)
	{
		H_LOG_TRACE(LOGGER, "enable: " << enable);
		if (m_flagEnlarge == enable)
		{
			return;
		}
		Widget* root = NULL;
		Widget* child = NULL;
		CWidgetExtension* childWidgetEx = NULL;

		m_flagEnlarge = enable;

		VoltFullProcessRuntime *runtime = static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

		if (runtime)
		{
			root = dynamic_cast<Widget*>(runtime->GetSceneRoot());
		}

		if (root == NULL)
		{
			IStage* stage = IStage::GetInstance();
			root = dynamic_cast<Widget*>(stage->RootActor());
		}

		if (root)
		{
			unsigned int childCount = root->getChildCount();
			for (unsigned int i = 0; i < childCount; ++i)
			{
				child = root->getChildByIndex(i);
				if (childWidgetEx = dynamic_cast<CWidgetExtension*>(root->getChildByIndex(i)))
				{
					childWidgetEx->EnableEnlarge(enable);
				}
				else
				{
					H_LOG_WARN(LOGGER, "Not Halo uielement, can not enlarge!");
				}
			}
		}
	}

	bool CUtility::IsEnlargeEnabled(void) const
	{
		return m_flagEnlarge;
	}

	bool CUtility::IsCursorVisible(void)
	{
		bool isCursorVisible = false;
		if (IDeviceManager::GetInstance())
		{
			isCursorVisible = IDeviceManager::GetInstance()->IsCursorVisible();
		}
		return isCursorVisible;
	}
	
	void CUtility::Enable720P(const bool enable)
	{
		//m_flag720P = enable;
		if (m_flag720P != enable)
		{
			m_initResolution();
		}
	}

	bool CUtility::Is720PEnabled(void) const
	{
		return m_flag720P;
	}
}

