#ifndef _HALO_NOCOPY_H_
#define _HALO_NOCOPY_H_
namespace HALO
{
	class INoCopy
	{
	protected:
		INoCopy(){}
		~INoCopy(){}
	private:
		INoCopy(const INoCopy&);
		const INoCopy& operator=(const INoCopy&);
	};
}
#endif