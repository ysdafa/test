#include "Halo1_0.h"

namespace HALO
{
	IUtility* IUtility::g_Utility = NULL;

	IUtility* IUtility::GetInstance(void)
	{
		if (g_Utility == NULL)
		{
			g_Utility = (IUtility*)Instance::CreateInstance(CLASS_ID_IUTILITY);
		}
		return g_Utility;
	}
}