#ifndef _HALO_CDBUS_GLIB_H_
#define _HALO_CDBUS_GLIB_H_

#include <glib.h>
#include <dbus/dbus.h>

namespace HALO
{
	typedef struct
	{
		GMainContext *context;      /**< the main context */
		GSList *ios;                /**< all IOHandler */
		GSList *timeouts;           /**< all TimeoutHandler */
		DBusConnection *connection; /**< NULL if this is really for a server not a connection */
		GSource *message_queue_source; /**< DBusGMessageQueue */
	} ConnectionSetup;

	typedef struct
	{
	  GSource source; /**< the parent GSource */
	  DBusConnection *connection; /**< the connection to dispatch */
	} DBusGMessageQueue;

	typedef struct
	{
	  ConnectionSetup *cs;
	  GSource *source;
	  DBusWatch *watch;
	} IOHandler;

	typedef struct
	{
	  ConnectionSetup *cs;
	  GSource *source;
	  DBusTimeout *timeout;
	} TimeoutHandler;

	void dbus_connection_setup_with_g_main (DBusConnection *connection, GMainContext *context);
}


#endif