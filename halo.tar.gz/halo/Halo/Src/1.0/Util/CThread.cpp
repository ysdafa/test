#ifdef WIN32
#include   <windows.h>
#include   <process.h>
#else
#include <pthread.h>
#include <errno.h>
#include <semaphore.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <limits.h>
#include <sys/prctl.h>
#include <string.h>
#include <syscall.h>
#endif

#ifndef WIN32 //#ifdef _LINUX
pthread_mutex_t TimeMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t TimeZoneMutex = PTHREAD_MUTEX_INITIALIZER;
#if defined(_USE_SYSTEM_TIME_)
struct timespec gTimeOffset;
#else
struct timeval gTimeOffset;
#endif
#endif


#include "Halo1_0.h"

#ifndef WIN32 //#if defined(_LINUX)
#ifndef _NO_SCHED_YIELD
int max_yield_counter = CONFIG_MAXIMUM_YIELD_COUNTER;
#endif
#endif

#ifndef INFINITY
#define INFINITY ~0
#endif

static HALO::util::Logger LOGGER("Thread");

namespace HALO
{





/*!
 *\fn bool CSemaphore::Create(int count)
 *
 * This function creates a CSemaphore object.
 *
 * \param count Semaphore counter
 * \return true on success, otherwise false.
 *
 * \pre Instance should have allocated memory
 *        and should not be already created.
 *
 * \post It should return true on successful creation
 *  of instance and can be used now for other
 *  CSemaphore operations.
 *
 * \see CSemaphore::Destroy()
 *
 * \par Example:
 * - See \ref sec_pcsemaphore_all
 */
bool CSemaphore::Create(int count)
{
#ifndef WIN32 //#ifdef _LINUX
	int ret = 0;
	if((ret = pthread_mutex_lock(&TimeMutex)) != 0)
        {
			ASSERT(false && "CSemahore::Create() : pthread_mutex_lock()");
        }
#endif

	ASSERT(FlagCreate() == false);

#if defined WIN32

	m_id = ::CreateSemaphore(NULL, (long)count, 0x7fffffff, NULL);
	ASSERT(m_id != NULL);

#else //#elif defined _LINUX

	pthread_cond_t cond   = PTHREAD_COND_INITIALIZER;

	m_id = new TSemaphore;
	ASSERT(m_id != NULL);

	if (m_id != NULL)
	{
		m_id->cond  = cond;
		m_id->count = count;
	}
#endif

#ifndef WIN32 //#ifdef _LINUX
	if((ret = pthread_mutex_unlock(&TimeMutex)) != 0)
        {
			ASSERT(false && "CSemahore::Create() : pthread_mutex_unlock()");
        }
#endif

	return m_id != NULL;
}

/*!
 *\fn void CSemaphore::Destroy()
 *
 * This function destroys the CSemaphore object.
 * 
 * \pre Instance should be already created        
 *
 * \post It should return true on successful destruction
 *  of instance and cannot be used now for other opeartions.
 *
 * \see CSemaphore::Create()
 *
 * \par Example:
 * - See \ref sec_pcsemaphore_all
 */
void CSemaphore::Destroy()
{
#ifndef WIN32 //#ifdef _LINUX
	int ret = 0;
	if((ret = pthread_mutex_lock(&TimeMutex)) != 0)
        {
            ASSERT(false && "CSemaphore::Destroy() : pthread_mutex_lock()");
        }
#endif

	ASSERT(FlagCreate() == true);

#if defined WIN32
	::CloseHandle(m_id);
#else //#elif defined _LINUX
	if((ret = pthread_cond_destroy(&m_id->cond)) != 0) 
	{
		ASSERT(false && "CSemaphore::Destroy() : pthread_cond_destroy()");
	}
	delete m_id;
#endif

	m_id = NULL;

#ifndef WIN32 //#ifdef _LINUX
	if((ret = pthread_mutex_unlock(&TimeMutex)) != 0)
        {
            ASSERT(false && "CSemaphore::Destroy() : pthread_mutex_unlock()");
        }
#endif

	return;
}




#if defined WIN32

void CSemaphore::Take(void)
{
	ASSERT(FlagCreate() == true);

	switch(::WaitForSingleObject(m_id, INFINITE))
	{
	case WAIT_OBJECT_0:
		return;
	default:
		ASSERT("Take semaphore fail.");
	}

	return;
}




bool CSemaphore::Try(unsigned long msec)
{
	ASSERT(FlagCreate() == true);

	if (msec == (unsigned long) INFINITY)
	{
		Take();

		return true;
	}

	return ::WaitForSingleObject(m_id, msec) == WAIT_OBJECT_0;
}




void CSemaphore::Give(void)
{
	ASSERT(FlagCreate() == true);

	::ReleaseSemaphore(m_id, 1, NULL);

	return;
}

#endif




#ifndef WIN32 //#if defined _LINUX

void CSemaphore::Take(void)
{
	int ret = 0;
	if((ret = pthread_mutex_lock(&TimeMutex)) != 0)
        {
            ASSERT(false && "CSemaphore::Take() : pthread_mutex_lock()");
        }
	ASSERT(FlagCreate() == true);

	while (m_id->count <= 0)
	{
		if((ret = pthread_cond_wait(&m_id->cond, &TimeMutex)) != 0)
		{
			ASSERT(false && "CSemaphore::Take() : pthread_cond_wait()");
		}
	}

	m_id->count--;

	if((ret = pthread_mutex_unlock(&TimeMutex)) != 0)
        {
            ASSERT(false && "CSemaphore::Take() : pthread_mutex_unlock()");
        }

	return;
}




bool CSemaphore::Try(unsigned long msec)
{
#if !defined(_USE_SYSTEM_TIME_)
    struct timeval  now;
#endif
	struct timespec timeout;
	int             ret = 0;
	bool            tf;

	ASSERT(FlagCreate() == true);
    // msec arg has to be smaller than LONG_MAX.
    // because it will be added and be stored to time_t(signed long) type
    // fields.
    // ASSERT(msec <= LONG_MAX);

	if (msec == (unsigned long) INFINITY) {
		Take();
		return true;
	}
	if((ret = pthread_mutex_lock(&TimeMutex)) != 0)
        {
                ASSERT(false && "CSemahore::Try() : pthread_mutex_lock()");
        }


	if (msec == 0) {
		if (m_id->count <= 0) {
			tf = false;
		}
		else {
			m_id->count--;
			tf = true;
		}
        goto end;
	}

    while (m_id->count <= 0) {
#if defined(_USE_SYSTEM_TIME_)
        timeout.tv_sec  = msec / 1000;
        timeout.tv_nsec = ( msec % 1000 ) * 1000000;

        ret = pthread_cond_timedwait_relative(&m_id->cond, &TimeMutex, &timeout);
#else
        now.tv_sec  = 0;
        now.tv_usec = 0;
        ret = gettimeofday(&now, NULL);
        if (ret != 0)
        {
            ASSERT("CSemaphore::Try() : gettimeofday()");
            tf = false; goto end;
        }

        timeout.tv_sec  = now.tv_sec  + (msec / 1000);
        timeout.tv_nsec = now.tv_usec + (msec % 1000) * 1000;
        while (timeout.tv_nsec >= 1000000) {
            timeout.tv_nsec -= 1000000;
            timeout.tv_sec++;
        }
        timeout.tv_nsec *= 1000;

        ret = pthread_cond_timedwait(&m_id->cond, &TimeMutex, &timeout);
#endif
        if (ret != 0)
        {
            if(ret != ETIMEDOUT)
            {
                ASSERT(false && "CSemahore::Try() : pthread_cond_timedwait()");
            }
            tf = false; goto end;
        }
    }

	m_id->count--;
	tf = true;

end:
	if((ret = pthread_mutex_unlock(&TimeMutex)) != 0)
        {
            ASSERT(false && "CSemahore::Try() : pthread_mutex_unlock()");
        }
	return tf;
}




void CSemaphore::Give(void)
{
    int ret = 0;
    if((ret = pthread_mutex_lock(&TimeMutex)) != 0)
    {
            ASSERT(false && "CSemahore::Give() : pthread_mutex_lock()");
    }
    ASSERT(FlagCreate() == true);
    m_id->count++;
    if((ret = pthread_cond_signal(&m_id->cond)) != 0)
    {
        ASSERT(false && "CSemahore::Give() : pthread_cond_signal()");
    }

    if((ret = pthread_mutex_unlock(&TimeMutex)) != 0)
    {
            ASSERT(false && "CSemahore::Give() : pthread_mutex_unlock()");
    }

#ifndef _NO_SCHED_YIELD
    //if (!semCounter--) {
    //    // Do not use sleep here. In ARM CPU, Kernel Tick is 100Hz.
    //    // If you call Sleep(1) here, this thread sleep during 10ms.
    //    // PCTime::Sleep(1);

    //    sched_yield();
    //    semCounter = max_yield_counter;

    //}
#endif



    return;
}

#endif




#if defined WIN32

unsigned long CThreadSelf::Id(void)
{
	return (unsigned long)GetCurrentThreadId();
}

#endif


bool CThreadSelf::SetPriority(int priority)
{
#ifndef WIN32 //#if defined _LINUX

	switch (priority)
	{
		case CThread::PRIORITY_HIGH:
			if(setpriority(PRIO_PROCESS, syscall(__NR_gettid), -10) != 0)
			{
				ASSERT("CThreadSelf::SetPriority() : setpriority()[H]");
				return false;
			}
//			param.sched_priority = 60;
			break;
		case CThread::PRIORITY_NORMAL:
			if(setpriority(PRIO_PROCESS, syscall(__NR_gettid), 0) != 0)
			{
				ASSERT("CThreadSelf::SetPriority() : setpriority()[N]");
				return false;
			}
//			param.sched_priority = 50;
			break;
		case CThread::PRIORITY_LOW:
			if(setpriority(PRIO_PROCESS, syscall(__NR_gettid), 10) != 0)
			{
				ASSERT("CThreadSelf::SetPriority() : setpriority()[L]");
				return false;
			}
//			param.sched_priority = 40;
			break;
		default:
			return false;
	}

#elif defined WIN32

	switch (priority)
	{
		case CThread::PRIORITY_HIGH:
			return SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL) != 0;
		case CThread::PRIORITY_NORMAL:
			return SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_NORMAL) != 0;
		case CThread::PRIORITY_LOW:
			return SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL) != 0;
		default:
			return false;
	}

#endif
	return true;
}


	CThread::CThread(void) : 
	m_pRunnable(NULL),
	m_bRun(false)
	{
	}

	CThread::~CThread(void)
	{
	}

	CThread::CThread(IRunnable * pRunnable) : m_ThreadName(""), m_pRunnable(pRunnable), m_bRun(false)
	{
	}

	CThread::CThread(const char * ThreadName, IRunnable * pRunnable) : m_ThreadName(ThreadName), m_pRunnable(pRunnable), m_bRun(false)
	{
	}

	CThread::CThread(std::string ThreadName, IRunnable * pRunnable) : m_ThreadName(ThreadName), m_pRunnable(pRunnable), m_bRun(false)
	{
	}

	bool CThread::Start()
	{
		H_LOG_TRACE(LOGGER, "CThread::Start");
		if(m_bRun)
		{
			return true;
		}
#if	defined WIN32
		m_handle = (HANDLE)_beginthreadex(NULL, 0, StaticThreadFunc, this, 0, (unsigned int*)&m_ThreadID);
		m_bRun = (NULL != m_handle);
#else //#elif defined _LINUX
		pthread_attr_t attr;
		pthread_attr_init(&attr);
		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
		//pthread_attr_setstacksize(&attr, stackSize);
		m_bRun = pthread_create((pthread_t*)&m_ThreadID, &attr, StaticThreadFunc, this);
		pthread_attr_destroy(&attr);
#endif
		return m_bRun;
	}

	void CThread::Run()
	{
		H_LOG_TRACE(LOGGER, "CThread::Run");
		if(!m_bRun)
		{
			return;
		}
		if(NULL != m_pRunnable)
		{
			m_pRunnable->Run();
		}
		m_bRun = false;
	}

	void CThread::Join(int timeout)
	{
		H_LOG_TRACE(LOGGER, "CThread::Join(" << timeout << ")");
#if defined WIN32
		if(NULL == m_handle || !m_bRun)
		{
			return;
		}
		if(timeout <= 0)
		{
			timeout = INFINITE;
		}
		::WaitForSingleObject(m_handle, timeout);
#else //#elif defined _LINUX
		void* status;
		pthread_join(m_ThreadID, &status);
#endif
	}

#ifdef WIN32
	void CThread::Resume()
	{
		H_LOG_TRACE(LOGGER, "CThread::Resume");
		if(NULL == m_handle || !m_bRun)
		{
			return;
		}
		::ResumeThread(m_handle);
	}

	void CThread::Suspend()
	{
		H_LOG_TRACE(LOGGER, "CThread::Suspend");
		if(NULL == m_handle || !m_bRun)
		{
			return;
		}
		::SuspendThread(m_handle);
	}
#endif

	bool CThread::Terminate(unsigned long ExitCode)
	{
		H_LOG_TRACE(LOGGER, "CThread::Join(" << ExitCode << ")");
#if defined WIN32
		if(NULL == m_handle || !m_bRun)
		{
			return true;
		}
		if(::TerminateThread(m_handle, ExitCode))
		{
			::CloseHandle(m_handle);
			return true;
		}
#else //#elif defined _LINUX
		if (pthread_cancel(m_ThreadID) == 0)
		{
			return true;
		}
#endif
		return false;
	}

	unsigned long CThread::GetThreadID()
	{
		H_LOG_TRACE(LOGGER, "CThread::GetThreadID m_ThreadID = " << m_ThreadID);
		return m_ThreadID;
	}

	std::string CThread::GetThreadName()
	{
		H_LOG_TRACE(LOGGER, "CThread::GetThreadName m_ThreadName = " << m_ThreadName);
		return m_ThreadName;
	}

	void CThread::SetThreadName(std::string ThreadName)
	{
		H_LOG_TRACE(LOGGER, "CThread::SetThreadName(" << ThreadName.c_str() << ")");
		m_ThreadName = ThreadName;
	}

	void CThread::SetThreadName(const char * ThreadName)
	{
		H_LOG_TRACE(LOGGER, "CThread::SetThreadName");
		if(NULL == ThreadName)
		{
			m_ThreadName = "";
		}
		else
		{
			m_ThreadName = ThreadName;
		}
	}
#if defined WIN32
	unsigned int CThread::StaticThreadFunc(void * arg)
	{
		H_LOG_TRACE(LOGGER, "CThread::StaticThreadFunc");
		if (arg == NULL)
		{
			return 0;
		}
		CThread * pThread = (CThread *)arg;
		pThread->Run();
		return 0;
	}
#else //#elif defined _LINUX
	void* CThread::StaticThreadFunc(void* arg)
	{
		H_LOG_TRACE(LOGGER, "CThread::StaticThreadFunc");
		if (arg == NULL)
		{
			return NULL;
		}
		CThread* pThread = (CThread*) arg;
		pThread->Run();
		return NULL;
	}
#endif
}
