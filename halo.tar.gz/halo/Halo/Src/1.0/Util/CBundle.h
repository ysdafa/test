#ifndef _BUNDLE_H_
#define _BUNDLE_H_

namespace HALO
{
	class CBundle
	{
	public:
		//! Each bundle keyval have a type.
		typedef enum E_BUNDLE_TYPE
		{
			BUNDLE_TYPE_NONE = -1,
			BUNDLE_TYPE_ANY = 0,
			BUNDLE_TYPE_INT,
			BUNDLE_TYPE_LONG,
			BUNDLE_TYPE_DOUBLE,
			BUNDLE_TYPE_FLOAT,
			BUNDLE_TYPE_CHAR,
			BUNDLE_TYPE_STR,
		}EBundleType;

		//!Key_val attribute
		typedef struct T_KEYVAL
		{
			int type;
			char* key;
			void* val;
			size_t size;

			struct T_KEYVAL* next;
			T_KEYVAL(): type(0), key(NULL), val(NULL), size(0), next(NULL)
			{
			}
			~T_KEYVAL()
			{
				if(key) 
				{
					delete[] key;
				}
				if(val) 
				{
					char* wval = static_cast<char*>(val);
					delete[] wval;
				}
			}
			T_KEYVAL(const T_KEYVAL& that)
			{
				type = that.type;
				key = new char[strlen(that.key)+1];
				memcpy(key, that.key, strlen(that.key)+1);
				size = that.size;
				val = new char[size];
				memcpy(val, that.val, size);
			}
			T_KEYVAL& operator=(const T_KEYVAL& that)
			{
				type = that.type;
				key = new char[strlen(that.key)+1];
				//strncpy(key, that.key, strlen(that.key));
				memcpy(key, that.key, strlen(that.key)+1);
				size = that.size;
				val = new char[size];
				memcpy(val, that.val, size);

				return *this;
			}
		}TKeyVal;

	public:
		CBundle();
		CBundle(const CBundle&);
		virtual ~CBundle();
		CBundle& operator=(const CBundle& that);

		//! Add key-val into bundle
		int AddInt(const char* key, int value);
		int AddLong(const char* key, long value);
		int AddDouble(const char* key, double value);
		int AddFloat(const char* key, float value);
		int AddChar(const char* key, char value);
		int AddString(const char* key, const char* value);

		//! Get value from the key
		int IntValue(const char* key, int& value);
		int LongValue(const char* key, long& value);
		int DoubleValue(const char* key, double& value);
		int FloatValue(const char* key, float& value);
		int CharValue(const char* key, char& value);
		int StringValue(const char* key, char** value);

		//! Encode and Decode
		int EncodeBundle(unsigned char** r, int* len);
		int DecodeBundle(const unsigned char* r, const int data_size);
	private:
		TKeyVal* m_pBundle;

		TKeyVal* m_pFindKeyVal(const char* key);
		int m_AddKeyVal(const char* key, const void* val, const size_t size, const int type);
		int m_GetVal(const char* key, const int type, void** val, size_t* size);
		int m_AppendKeyVal(TKeyVal* new_kv);
		
		TKeyVal* m_pKeyValNew(TKeyVal* kv, const char* key, const int type, const void* val, const size_t size);
		void m_KeyValFree(TKeyVal* kv, int do_free_object);
		int m_KeyValGetData(TKeyVal* kv, int* type, void** val, size_t* size);
		size_t m_KeyValGetEncodedSize(TKeyVal* kv);
		size_t m_KeyValEncode(TKeyVal* kv, unsigned char** byte, size_t* byte_len);
		size_t m_KeyValDecode(unsigned char* byte, TKeyVal** kv);
	};
}
#endif /* _BUNDLE_H_ */