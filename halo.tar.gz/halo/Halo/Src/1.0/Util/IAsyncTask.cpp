#include "Halo1_0.h"

namespace HALO
{
	IAsyncTask* IAsyncTask::CreateInstance(void)
	{
		CAsyncTask* task = (CAsyncTask*)Instance::CreateInstance(CLASS_ID_IASYNCTASK);
		if (task)
		{
			task->Initialize();
		}
		return (IAsyncTask*)task;
	}

	IAsyncTask* IAsyncTask::CreateInstance(void* params)
	{
		CAsyncTask* task = (CAsyncTask*)Instance::CreateInstance(CLASS_ID_IASYNCTASK);
		if (task)
		{
			task->Initialize(params);
		}
		return (IAsyncTask*)task;
	}

	IAsyncTask* IAsyncTask::CreateInstance(void* params, IThreadPool* threadPool)
	{
		CAsyncTask* task = (CAsyncTask*)Instance::CreateInstance(CLASS_ID_IASYNCTASK);
		if (task)
		{
			task->Initialize(params, threadPool);
		}
		return (IAsyncTask*)task;
	}
}