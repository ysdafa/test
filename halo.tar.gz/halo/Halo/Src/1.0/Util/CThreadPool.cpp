#include "Halo1_0.h"
#include "CThread.h"
#ifdef _WIN32
#include <windows.h>
#endif

static HALO::util::Logger LOGGER("ThreadPool");

namespace HALO
{
	CThreadPool::CWorker::CWorker(CThreadPool * pThreadPool, IRunnable * pFirstTask) : 
	m_pThreadPool(pThreadPool),
	m_pFirstTask(pFirstTask),
	m_bRun(true)
	{
	
	}

	CThreadPool::CWorker::~CWorker()
	{
	}

	void CThreadPool::CWorker::Run()
	{
		H_LOG_TRACE(LOGGER, "CThreadPool::Run ");
		while(m_bRun)
		{
			if(NULL == m_pFirstTask)
			{
				m_pCurrentTask = m_pThreadPool->GetTask();
			}
			else
			{
				m_pCurrentTask = m_pFirstTask;
				m_pFirstTask = NULL;
			}

			if(NULL == m_pCurrentTask)
			{
				m_pThreadPool->m_threadPoolLock.Lock();
				if(m_pThreadPool->GetThreadPoolSize() > m_pThreadPool->m_minThreads)
				{
					ThreadPoolItr itr = m_pThreadPool->m_WorkingThreadPool.begin();
					while (itr != m_pThreadPool->m_WorkingThreadPool.end())
					{
						if (*itr == this)
						{
							m_pThreadPool->m_WorkingThreadPool.erase(itr);
							break;
						}
						++itr;
					}
					m_pThreadPool->m_TrashThreadPool.insert(this);
					m_bRun = false;
				}
				else
				{
					ThreadPoolItr itor = m_pThreadPool->m_WorkingThreadPool.find(this);
					if (itor != m_pThreadPool->m_WorkingThreadPool.end())
					{
						m_pThreadPool->m_WorkingThreadPool.erase(itor);
					}
					ThreadPoolItr iter = m_pThreadPool->m_PendingThreadPool.find(this);
					if (iter == m_pThreadPool->m_PendingThreadPool.end())
					{
						m_pThreadPool->m_PendingThreadPool.insert(this);
					}
					ThreadPoolItr itr = m_pThreadPool->m_TrashThreadPool.begin();
					while(itr != m_pThreadPool->m_TrashThreadPool.end())
					{
						(*itr)->Join();
						delete (*itr);
						m_pThreadPool->m_TrashThreadPool.erase(itr);
						itr = m_pThreadPool->m_TrashThreadPool.begin();
					}
				}

				m_pThreadPool->m_threadPoolLock.Unlock();
				continue;
			}
			else
			{
				m_pThreadPool->m_threadPoolLock.Lock();
				// Make sure iterator is deconstructed before run.
				{
					ThreadPoolItr itor = m_pThreadPool->m_PendingThreadPool.find(this);
					if (itor != m_pThreadPool->m_PendingThreadPool.end())
					{
						m_pThreadPool->m_PendingThreadPool.erase(itor);
						m_pThreadPool->m_WorkingThreadPool.insert(this);
					}
				}
				m_pThreadPool->m_threadPoolLock.Unlock();
				m_pCurrentTask->Run();
				m_pCurrentTask = NULL;
			}
		}
	}

	bool CThreadPool::CWorker::CancelTask(IRunnable* pCurrentTask)
	{
		H_LOG_TRACE(LOGGER, "CThreadPool::CancelTask ");
		if (m_pCurrentTask == pCurrentTask)
		{
			Terminate(1);
			return true;
		}
		return false;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////

	CThreadPool::CThreadPool(void) : 
		m_bInitializedFlag(false),
		m_bRun(false),
		m_bEnableInsertTask(false)
	{
		m_tasksLock.Create();
		m_threadPoolLock.Create();
		m_threadTaskSem.Create(0);
	}

	CThreadPool::~CThreadPool(void)
	{
		m_threadPoolLock.Lock();
		m_tasksLock.Lock();
		Terminate();
		m_tasksLock.Destroy();
		m_threadPoolLock.Destroy();
		m_threadTaskSem.Destroy();
	}

	//! Create Thread Pool with default maxThreadCount(30), default minReserveThreadCount(0), default maxPendingTaskCount(-1, no limit)
	bool CThreadPool::Initialize(void) 
	{
		H_LOG_TRACE(LOGGER, "CThreadPool::Initialize ");
		m_minThreads = 0;
		m_maxThreads = 30;
		m_maxPendingTasks = -1;
		m_bRun = true;
		m_bEnableInsertTask = true;
		m_bInitializedFlag = true;
		return true;
	}

	//! Create Thread Pool with given maxThreadCount, default minReserveThreadCount(0), default maxPendingTaskCount(-1, no limit)
	bool CThreadPool::Initialize(int maxThreadCount) 
	{
		H_LOG_TRACE(LOGGER, "CThreadPool::Initialize with maxThreadCount");
		if(maxThreadCount <= 0)
		{
			return false;
		}
		m_minThreads = 0;
		m_maxThreads = maxThreadCount;
		m_maxPendingTasks = -1;
		m_bRun = true;
		m_bEnableInsertTask = true;
		m_bInitializedFlag = true;
		return true;
	}

	//! Create Thread Pool with given maxThreadCount, given minReserveThreadCount, default maxPendingTaskCount(-1, no limit)
	bool CThreadPool::Initialize(int maxThreadCount, int minReserveTheadCount) 
	{
		H_LOG_TRACE(LOGGER, "CThreadPool::Initialize with maxThreadCount and minReserveTheadCount");
		if(minReserveTheadCount < 0)
		{
			return false;
		}
		if(maxThreadCount <= 0)
		{
			return false;
		}
		m_minThreads = minReserveTheadCount;
		m_maxThreads = maxThreadCount;
		m_maxPendingTasks = -1;
		m_bRun = true;
		m_bEnableInsertTask = true;
		m_bInitializedFlag = true;
		return true;
	}

	//! Create Thread Pool with given maxThreadCount, given minReserveThreadCount, given maxPendingTaskCount
	bool CThreadPool::Initialize(int maxThreadCount, int minReserveTheadCount, int maxPendingTaskCount) 
	{
		H_LOG_TRACE(LOGGER, "CThreadPool::Initialize with maxThreadCount, minReserveTheadCount and maxPendingTaskCount");
		if(minReserveTheadCount < 0)
		{
			return false;
		}
		if(maxThreadCount <= 0)
		{
			return false;
		}
		if (maxPendingTaskCount < -1)
		{
			return false;
		}
		m_minThreads = minReserveTheadCount;
		m_maxThreads = maxThreadCount;
		m_maxPendingTasks = maxPendingTaskCount;
		m_bRun = true;
		m_bEnableInsertTask = true;
		m_bInitializedFlag = true;
		return true;
	}

	//! Check if the instance was created
	bool CThreadPool::IsInitialized(void) const
	{
		H_LOG_TRACE(LOGGER, "CThreadPool::IsInitialized: m_bInitializedFlag = " << m_bInitializedFlag);
		return m_bInitializedFlag;
	}

	bool CThreadPool::Execute(IRunnable * pRunnable)
	{
		H_LOG_TRACE(LOGGER, "CThreadPool::Execute ");
		ASSERT(IsInitialized() == true);
		if(!m_bEnableInsertTask)
		{
			return false;
		}
		if(NULL == pRunnable)
		{
			return false;
		}
		if (m_PendingThreadPool.size() > 0)
		{
			m_tasksLock.Lock();
			m_Tasks.push_back(pRunnable);
			m_tasksLock.Unlock();
			m_threadTaskSem.Give();
		}
		else if (m_WorkingThreadPool.size() < m_maxThreads)
		{
			CWorker * pWorker = new CWorker(this, pRunnable);
			if(NULL == pWorker)
			{
				return false;
			}
			m_threadPoolLock.Lock();
			m_WorkingThreadPool.insert(pWorker);	

			m_threadPoolLock.Unlock();
			pWorker->Start();
		}
		else
		{
			if(m_maxPendingTasks != -1 && static_cast<int>(m_Tasks.size()) >= m_maxPendingTasks)
			{
				return false;
			}
			else
			{
				m_tasksLock.Lock();
				m_Tasks.push_back(pRunnable);
				m_tasksLock.Unlock();
				m_threadTaskSem.Give();
			}
		}
		return true;
	}

	IRunnable * CThreadPool::GetTask()
	{
		H_LOG_TRACE(LOGGER, "CThreadPool::GetTask ");
		ASSERT(IsInitialized() == true);
		IRunnable * Task = NULL;
		if (m_threadTaskSem.Try(1000) == false)
		{
			H_LOG_TRACE(LOGGER, "CThreadPool::GetTask: m_threadTaskSem.Try error");
			return NULL;
		}
		if (!m_tasksLock.Try(100))
		{
			H_LOG_TRACE(LOGGER, "CThreadPool::GetTask: m_tasksLock.Try error");
			return NULL;
		}
		if(!m_Tasks.empty())
		{
			Task = m_Tasks.front();
			m_Tasks.pop_front();
		}
		m_tasksLock.Unlock();
		return Task;
	}

	unsigned int CThreadPool::GetThreadPoolSize()
	{
		ASSERT(IsInitialized() == true);
		m_threadPoolLock.Lock();
		unsigned int ret = m_WorkingThreadPool.size() + m_PendingThreadPool.size();
		m_threadPoolLock.Unlock();
		H_LOG_TRACE(LOGGER, "CThreadPool::GetThreadPoolSize: ret = " << ret);
		return ret;
	}

	bool CThreadPool::Cancel(IRunnable* pRunnable)
	{
		H_LOG_TRACE(LOGGER, "CThreadPool::Cancel");
		ASSERT(IsInitialized() == true);
		bool ret = false;
		m_tasksLock.Lock();
		TasksItr itr = m_Tasks.begin();
		while(itr != m_Tasks.end())
		{
			if (*itr == pRunnable)
			{
				m_Tasks.erase(itr);
				ret = true;
				break;
			}
			++itr;
		}
		m_tasksLock.Unlock();

		if (ret)
		{
			return ret;
		}

		m_threadPoolLock.Lock();
		ThreadPoolItr itor = m_WorkingThreadPool.begin();
		while(itor != m_WorkingThreadPool.end())
		{
			if ((*itor)->CancelTask(pRunnable))
			{
				delete (*itor);
				m_WorkingThreadPool.erase(itor);
				ret = true;
				break;
			}
			++itor;
		}
		m_threadPoolLock.Unlock();
		return ret;
	}

	void CThreadPool::Terminate()
	{
		H_LOG_TRACE(LOGGER, "CThreadPool::Terminate");
		ASSERT(IsInitialized() == true);
		m_bEnableInsertTask = false;

		m_bRun = false;
		m_minThreads = 0;
		m_maxThreads = 0;
		m_maxPendingTasks = 0;
		ThreadPoolItr it = m_WorkingThreadPool.begin();
		while(it != m_WorkingThreadPool.end())
		{
			(*it)->Terminate(1);
			(*it)->Join();
			delete (*it);
			m_WorkingThreadPool.erase(it);
			it = m_WorkingThreadPool.begin();
		}

		ThreadPoolItr itr = m_TrashThreadPool.begin();
		while(itr != m_TrashThreadPool.end())
		{
			(*itr)->Join();
			delete (*itr);
			m_TrashThreadPool.erase(itr);
			itr = m_TrashThreadPool.begin();
		}

		ThreadPoolItr itor = m_PendingThreadPool.begin();
		while(itor != m_PendingThreadPool.end())
		{
			(*itor)->Terminate(1);
			(*itor)->Join();
			delete (*itor);
			m_PendingThreadPool.erase(itor);
			itor = m_PendingThreadPool.begin();
		}

		m_Tasks.clear();

	}
}
