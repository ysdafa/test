#ifndef __THREAD_H__
#define __THREAD_H__

#include <string>
namespace HALO
{
#if defined WIN32

typedef void TSemaphore;

#else //#elif defined _LINUX
#define CONFIG_MAXIMUM_YIELD_COUNTER 16

struct TSemaphore
{
	pthread_cond_t  cond;
	int             count;
};



#ifndef _NO_SCHED_YIELD
//static unsigned char semCounter = CONFIG_MAXIMUM_YIELD_COUNTER;
#endif

extern "C" unsigned long pthread_self(void) throw ();

#endif

class CSemaphore
{
private:
	TSemaphore* m_id;

public:

	CSemaphore(void) { m_id = NULL; }
	virtual ~CSemaphore(void) { ASSERT(FlagCreate() == false); }

	//! Create the instance
	bool Create(int count);
	//! Check if the instance was created
	bool FlagCreate(void) { return m_id != NULL; }
	//! Destroy the instance
	virtual void Destroy(void);

	//! Decreases the counter of CSemaphore.
	void Take(void);
	//! Trys to decrease the counter of CSemaphore.
	bool Try(unsigned long msec = 0);
	//! Increases the counter of CSemaphore.
	void Give(void);
};	

//! ThreadSelf namespace
/*!
 * \ingroup os
 *
 * CThreadSelf namespace supplies the Id function.
 */
class CThreadSelf
{
private:

	CThreadSelf(void) {}

public:

	//! Returns the ID of the current executing thread.
	static unsigned long Id(void);

	static bool SetPriority(int priority);
};

/*!
 *\fn int CThreadSelf::Id(void)
 *
 * This function returns the ID of the current executing thread.
 *
 * \return ID of current executing thread
 *  
 * \pre Instance should be already Created.
 *
 * \post It should return the ID of the current executing thread.
 *        
 * \see CThread::Id()
 *        
 * \par Example:
 * - See \ref sec_pcthreadself_all
 */
#ifndef WIN32//#if defined(_LINUX)

inline unsigned long CThreadSelf::Id(void)
{
	return (unsigned long)pthread_self();
}

#endif


//! Mutex class
/*!
 * \ingroup os
 *
 * CMutex class provides functions used to create and manage mutexes.
 */
class CMutex
{
private:
	CSemaphore m_sem;
	unsigned long m_threadId;
	int         m_count;

public:
	//! The destructor of CMutex.
	virtual ~CMutex(void) { ASSERT(FlagCreate() == false); }

	//! Create the instance
	bool Create(void);
	//! Check if the instance was created
	bool FlagCreate(void) { return m_sem.FlagCreate(); }
	//! Destroy the instance
	virtual void Destroy(void);

	//! Locks the created CMutex object.
	void Lock(void);
	//! Tries to lock the CMutex object.
	bool Try(unsigned long msec = 0);
	//! Unlocks the CMutext object.
	bool Unlock(void);
};




/*!
 *\fn bool CMutex::Create(void)
 *
 * This function creates a CMutex object.
 *
 * \return true on success, otherwise false.
 *  
 * \pre Instance should have allocated memory and
 *        should not be already created. 
 *
 * \post It should return true after successful creation.
 * The instance will be available now for CMutex
 * operations. 
 *
 * \see Destroy()
 *
 * \par Example:
 * - See \ref sec_pcmutex_createdestlock
 */
inline bool CMutex::Create(void)
{
	ASSERT(FlagCreate() == false);

	m_threadId = 0;
	m_count = 0;

	if (m_sem.Create(1) == false)
	{
		return false;
	}


	return true;
}




/*!
 *\fn  void CMutex::Destroy(void)
 *
 * This function destroys the CMutex object.
 *
 * \return true on success, otherwise false.
 *  
 * \pre Instance should be already created.
 *
 * \post It should return true after successful destruction.
 * The instance cannot be used now for CMutex operations. 
 *        
 * \see Create()
 *
 * \par Example:
 * - See \ref sec_pcmutex_createdestlock
 */
inline void CMutex::Destroy(void)
{
	ASSERT(FlagCreate() == true);

	m_sem.Destroy();

	return;
}




/*!
 *\fn  void CMutex::Lock(void)
 *
 * This function locks the created CMutex object.
 *
 * \pre The instance should be already created.
 *
 * \post The locked mutex cannot be used by another thread
 *         until unlocked by same thread.
 *
 * \see Unlock(), Try()
 *
 * \par Example:
 * - See \ref sec_pcmutex_createdestlock
 */
inline void CMutex::Lock(void)
{
	ASSERT(FlagCreate() == true);

	if (m_threadId == CThreadSelf::Id())
	{
		m_count++;

		return;
	}

	m_sem.Take();

	m_threadId = CThreadSelf::Id();
	m_count    = 1;

	return;
}




/*!
 *\fn  bool CMutex::Try(unsigned long msec)
 *
 * If this function succeeds, the memeber variable that saves the
 * thread ID will be set to the current thread ID.
 *
 * \return true on success, otherwise false.
 *
 * \param[in] msec Timeout value in milliseconds
 *
 * \pre The instance should be already created.
 *
 * \post Incase of successful Try,the locked mutex cannot be used
 *  by another thread until unlocked by same thread.     
 *        
 * \see Lock(), Unlock()
 *
 * \par Example:
 * - See \ref sec_pcmutex_createdesttry
 */
inline bool CMutex::Try(unsigned long msec)
{
	ASSERT(FlagCreate() == true);

	if (m_threadId == CThreadSelf::Id())
	{
		m_count++;

		return true;
	}

	if (m_sem.Try(msec) == false)
	{
		return false;
	}

	m_threadId = CThreadSelf::Id();
	m_count    = 1;

	return true;
}



/*!
 *\fn  bool CMutex::Unlock(void)
 *
 * This function unlocks the CMutex object.
 *
 * \return true on success, otherwise false.
 *
 * \pre Instance should be already created.
 *
 * \post Locked mutex cannot be used by another thread
 *  until unlocked by same thread.
 *        
 * \see Lock(), Try()
 *
 * \par Example:
 * - See \ref sec_pcmutex_createdestlock
 */
inline bool CMutex::Unlock(void)
{
	ASSERT(FlagCreate() == true);

	if (m_threadId != CThreadSelf::Id())
	{
		return false;
	}

	m_count--;

	if (m_count > 0)
	{
		return true;
	}

	m_threadId = 0;

	m_sem.Give();

	return true;
}

class IRunnable
{
public:
	virtual ~IRunnable() {};
	virtual void Run() = 0;
};

class CThread : public IRunnable
{
private:
	explicit CThread(const CThread & rhs);

public:
	enum TPriorityType
	{
		PRIORITY_HIGH,
		PRIORITY_NORMAL,
		PRIORITY_LOW,
	};
	CThread();
	CThread(IRunnable * pRunnable);
	CThread(const char * ThreadName, IRunnable * pRunnable = NULL);
	CThread(std::string ThreadName, IRunnable * pRunnable = NULL);
	~CThread(void);

	bool Start();

	virtual void Run();

	void Join(int timeout = -1);
#ifdef WIN32
	void Resume();
	void Suspend();
#endif
	bool Terminate(unsigned long ExitCode);

	unsigned long GetThreadID();
	std::string GetThreadName();
	void SetThreadName(std::string ThreadName);
	void SetThreadName(const char * ThreadName);

private:
#if defined WIN32
	static unsigned int WINAPI StaticThreadFunc(void * arg);
#else //#elif defined _LINUX
	static void* StaticThreadFunc(void* arg);
#endif

private:
#ifdef WIN32
	HANDLE m_handle;
#endif
	std::string m_ThreadName;
	unsigned long m_ThreadID;
	IRunnable * const m_pRunnable;	
	volatile bool m_bRun;
};
}
#endif