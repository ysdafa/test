#ifndef __CTHREAD_POOL_
#define __CTHREAD_POOL_

namespace HALO
{
class CThreadPool : public IThreadPool
{
public:
	CThreadPool(void);
	~CThreadPool(void);

	//! Create Thread Pool with default maxThreadCount(30), default minReserveThreadCount(0), default maxPendingTaskCount(-1, no limit)
	virtual bool Initialize(void) ;

	//! Create Thread Pool with given maxThreadCount, default minReserveThreadCount(0), default maxPendingTaskCount(-1, no limit)
	virtual bool Initialize(int maxThreadCount) ;

	//! Create Thread Pool with given maxThreadCount, given minReserveThreadCount, default maxPendingTaskCount(-1, no limit)
	virtual bool Initialize(int maxThreadCount, int minReserveTheadCount) ;

	//! Create Thread Pool with given maxThreadCount, given minReserveThreadCount, given maxPendingTaskCount
	virtual bool Initialize(int maxThreadCount, int minReserveTheadCount, int maxPendingTaskCount) ;

	//! Check if the instance was created
	virtual bool IsInitialized(void) const;

	//! Destroy Thread Pool
	//virtual void Destroy(void) ;

	// Execute task
	bool Execute(IRunnable * pRunnable);

	// Cancel task
	bool Cancel(IRunnable* pRunnable);

	// Terminate task
	void Terminate();

	// Get count of thread, include busy thread and pending thread
	unsigned int GetThreadPoolSize();

private:
	// Get next task, return NULL if no task.
	IRunnable * GetTask();

private:
	class CWorker : public CThread
	{
	public:
		CWorker(CThreadPool * pThreadPool, IRunnable * pFirstTask = NULL);
		~CWorker();
		void Run();
		bool CancelTask(IRunnable* pCurrentTask);
	private:
		CThreadPool * m_pThreadPool;
		IRunnable * m_pFirstTask;
		IRunnable * m_pCurrentTask;
		volatile bool m_bRun;
	};

	typedef std::set<CWorker *> ThreadPool;
	typedef std::list<IRunnable *> Tasks;
	typedef Tasks::iterator TasksItr;
	typedef ThreadPool::iterator ThreadPoolItr;

	ThreadPool m_WorkingThreadPool;
	ThreadPool m_PendingThreadPool;
	ThreadPool m_TrashThreadPool;
	Tasks m_Tasks;

	CMutex m_tasksLock;
	CMutex m_threadPoolLock;
	CSemaphore m_threadTaskSem;

	volatile bool m_bInitializedFlag;
	volatile bool m_bRun;
	volatile bool m_bEnableInsertTask;
	volatile unsigned int m_minThreads;
	volatile unsigned int m_maxThreads;
	volatile int m_maxPendingTasks;
};
}
#endif