#ifndef _CASYNCTASK_H_
#define _CASYNCTASK_H_
#include "CThread.h"
#include "CThreadPool.h"
namespace HALO
{
	class CAsyncTask : public IAsyncTask
	{
	public:
		enum EAsyncTaskStatus
		{
			E_HALO_ASYNC_STATUS_INIT,
			E_HALO_ASYNC_STATUS_PENDING,
			E_HALO_ASYNC_STATUS_RUNNING,
			E_HALO_ASYNC_STATUS_PAUSE,
			E_HALO_ASYNC_STATUS_CANCELING,
			E_HALO_ASYNC_STATUS_STOP,
		};
	public:
		CAsyncTask();
		~CAsyncTask();

		virtual bool Initialize(void);
		virtual bool Initialize(void* params);
		virtual bool Initialize(void* params, IThreadPool* threadPool);
		virtual bool IsInitialized(void) const;

		void* GetParams(void);
	
		virtual bool Execute(void);

		void* DoInBackground(void* params);

		void PostResult(void* result);

		bool Update(void* result);

		void Cancel(void);

		virtual bool SetTaskListener(ITaskListener* taskListener) ;
		
		virtual bool RemoveTaskListener(ITaskListener* taskListener) ;

	private:
		bool m_bInitializedFlag;
		CThreadPool* m_pExecutor;
		IRunnable* m_pTask;
		void* m_pParams;
		void* m_pResult;
		ITaskListener* m_pTaskListener;
		EAsyncTaskStatus m_taskStatus;
		CMutex m_csTaskStatusLock;
		unsigned long m_mainThreadID;
		unsigned long m_subThreadID;
	};
}

#endif