#include "Halo1_0.h"

#define DOBJECT_PATH "/org/tizen/uifw/dbus"
#define DINTERFACE_NAME	"org.tizen.uifw.dbus"

using namespace std;

static HALO::util::Logger LOGGER("Dbus");

namespace HALO
{
	CDbus::CDbus() : m_bus(NULL), m_regEventList(NULL)
	{		
	}

	CDbus::~CDbus()
	{
		//m_bus connection need not been closed, because the connection through dbus_bus_get() 
		//is shared connection and managered by libdbus.
		//args from  dbus_message_get_args does not alloc memery, because dbus has already do it.
		if (m_regEventList)
		{
			delete m_regEventList;
			m_regEventList = NULL;
		}
	}

	bool CDbus::DbusInit(const char *appName)
	{
		H_LOG_TRACE(LOGGER, "CDbus::DbusInit(" << appName << ")");
		HALO_ASSERT(appName != NULL);
#ifdef USE_DBUS
		m_regEventList = new RegEventList;

		dbus_error_init(&m_error); 
		
		m_bus = dbus_bus_get(DBUS_BUS_SESSION, &m_error);    
		if (!m_bus) 
		{                               
			//g_warning("[DbusInit]dbus_bus_get error: %s", m_error.message);   
			H_LOG_FATAL(LOGGER, "CDbus::DbusInit dbus_bus_get error: " << m_error.message);
		                                    
		  	dbus_error_free(&m_error);              
		  	return false;   
		}   
		
		dbus_connection_setup_with_g_main(m_bus, NULL);   

		//! Request process name
		dbus_bus_request_name(m_bus, appName, DBUS_NAME_FLAG_REPLACE_EXISTING, &m_error); 	
		//g_print("dbus_bus_request_name = %s, ret = %d\n", appName, ret);

		dbus_bus_add_match(m_bus, "type='signal',interface='org.tizen.uifw.dbus',path='/org/tizen/uifw/dbus'", &m_error);  
		//dbus_bus_add_match(m_bus, "type='method_call',interface='org.tizen.uifw.dbus',path='/org/tizen/uifw/dbus'", &m_error);  

		dbus_connection_add_filter(m_bus, t_SignalFilter, this, NULL);  

#endif
	 	return true;
	}

	bool CDbus::DbusSendEvent(const char *processName, const char *eventName, const char *eventData, char **resData, bool bAsysn)
	{
		H_LOG_TRACE(LOGGER, "CDbus::DbusSendEvent ");
		HALO_ASSERT(processName != NULL && eventName != NULL);
		//! Signal
		if (NULL == processName)
		{
			return t_SendSignal(DBUS_TYPE_STRING, eventName, eventData);
		}
		//! Method call
		else 
		{
			return t_SendMethodcall(DBUS_TYPE_STRING, processName, eventName, eventData, resData, bAsysn);
		}
		
	}
	
	bool CDbus::t_SendSignal(int type, const char *eventName, const char *eventData)
	{
		H_LOG_TRACE(LOGGER, "CDbus::t_SendSignal ");
		DBusMessage *message;  
		DBusMessageIter args;	
		
		message = dbus_message_new_signal(DOBJECT_PATH, DINTERFACE_NAME, eventName); 	
		if (!message)
		{
			//g_error("[t_SendSignal]create signal message error\n");
			H_LOG_FATAL(LOGGER, "CDbus::t_SendSignal create signal message error ");
			return FALSE;
		}
		
		dbus_message_iter_init_append(message, &args);
		if (!dbus_message_iter_append_basic(&args, type, &eventData))
		{
			//g_print("[t_SendSignal]Out Of Memory!\n"); 
			H_LOG_FATAL(LOGGER, "CDbus::t_SendSignal Out Of Memory! ");
			return FALSE;
		}
		else
		{
			//g_print("Send message: %s\n", eventData); 
			H_LOG_TRACE(LOGGER, "CDbus::t_SendSignal Send message: " << eventData);
		}

		bool ret = (dbus_connection_send(m_bus, message, NULL) == 1); 

		dbus_connection_flush(m_bus);  
		dbus_message_unref(message); 

		return ret;
	}

	bool CDbus::t_SendMethodcall(int type, const char *processName, const char *eventName, const char *eventData, char **resData, bool bAsysn)
	{
		H_LOG_TRACE(LOGGER, "CDbus::t_SendMethodcall ");
		DBusMessage *message;  
		DBusMessage *reply;  
		DBusPendingCall* pending;
		DBusMessageIter args;	
		dbus_bool_t stat;
		
		message = dbus_message_new_method_call (processName, DOBJECT_PATH, DINTERFACE_NAME, eventName); 	
		if (!message)
		{
			//g_error("[t_SendMethodcall]create method message error\n");
			H_LOG_FATAL(LOGGER, "CDbus::t_SendMethodcall create method message error ");
			return FALSE;
		}

		//dbus_message_append_args(message, DBUS_TYPE_STRING, "ding!", DBUS_TYPE_INVALID); 		
		dbus_message_iter_init_append(message, &args);
		if (!dbus_message_iter_append_basic(&args, type, &eventData))
		{
			//g_print("[t_SendMethodcall]Out Of Memory 1!\n"); 
			H_LOG_FATAL(LOGGER, "CDbus::t_SendMethodcall Out Of Memory 1! ");
			return FALSE;
		}
		else
		{
			//g_print("Send message: %s\n", eventData); 
			H_LOG_TRACE(LOGGER, "CDbus::t_SendMethodcall Send message: " << eventData);
		}
		
		if (bAsysn == false) //! Synchronously
		{
			if(!dbus_connection_send_with_reply(m_bus, message, &pending, -1))
			{ 
				//g_print("[t_SendMethodcall]Out of Memory 2!");
				H_LOG_FATAL(LOGGER, "CDbus::t_SendMethodcall Out of Memory 2! ");
				return FALSE;
			}     

			if(pending == NULL)
			{
				//g_print("[t_SendMethodcall]Pending Call NULL: connection is disconnected ");
				H_LOG_FATAL(LOGGER, "CDbus::t_SendMethodcall Pending Call NULL: connection is disconnected ");
				dbus_message_unref(message);
				return FALSE;
			} 

			dbus_connection_flush(m_bus);
			dbus_message_unref(message);  

			//! Reply	
			dbus_pending_call_block(pending); 
		
			reply = dbus_pending_call_steal_reply (pending); 
			if (reply == NULL)
			{
		 		//g_print("[t_SendMethodcall]Reply Null/n");
		 		H_LOG_FATAL(LOGGER, "CDbus::t_SendMethodcall Reply Null ");
				return FALSE;
			}
		
			//! Free the pending message handle 
			dbus_pending_call_unref(pending); 
		
			//! Read the reply 
			if (!dbus_message_iter_init(reply, &args)) 
			{
				//g_print("[t_SendMethodcall]Reply has no arguments!\n");
				H_LOG_FATAL(LOGGER, "CDbus::t_SendMethodcall Reply has no arguments ");
				return FALSE;
			}
			else if (dbus_message_iter_get_arg_type(&args) == DBUS_TYPE_BOOLEAN)
			{
				dbus_message_iter_get_basic (&args, &stat);
				//g_print("Got Reply: %d\n", stat);

				if ((int)stat == 1)
				{
					 if (!dbus_message_iter_next(&args)) 
					 {
						//g_print("[t_SendMethodcall]Reply has too few arguments!/n");
						H_LOG_FATAL(LOGGER, "CDbus::t_SendMethodcall Reply has too few arguments ");
						return FALSE;
					 }
					else if (dbus_message_iter_get_arg_type (&args) != DBUS_TYPE_STRING)
					{
						//g_print("[t_SendMethodcall]Reply is not string!/n");
						H_LOG_FATAL(LOGGER, "CDbus::t_SendMethodcall Reply is not string ");
						return FALSE;
					 }
					else
					{
						dbus_message_iter_get_basic(&args, resData);
					}

				}
				else
				{
					//g_print("[t_SendMethodcall]Reply first value is false !/n");
					H_LOG_FATAL(LOGGER, "CDbus::t_SendMethodcall Reply first value is false ");
					return FALSE;
				}
			}		
			else
			{
				//g_print("[t_SendMethodcall]No Reply! \n");
				H_LOG_FATAL(LOGGER, "CDbus::t_SendMethodcall No Reply ");
				return FALSE;
			}
		}
		else //! Synchronously
		{
			bool ret = (dbus_connection_send(m_bus, message, NULL) == 1); 			

			dbus_connection_flush(m_bus);   

			dbus_message_unref(message); 

			if (false == ret)
			{
				H_LOG_FATAL(LOGGER, "CDbus::t_SendMethodcall ret == false ");
				return false;
			}
		}
		
		return true;  
	}

	void CDbus::DbusRegEvent(const char *name)
	{
		H_LOG_TRACE(LOGGER, "CDbus::DbusRegEvent(" << name << ")");
		HALO_ASSERT(name != NULL);
		//! Change '.' to '_' of name
		int strl = strlen(name);
		char *eventName = new char[strl+1];
		memcpy(eventName, name, strl+1);
		for (int i = 0; i < strl; i++)
		{
			if (eventName[i] == '.')
			{
				eventName[i] = '_';
			}
		}
		m_RegEventName(eventName);
		delete [] eventName;
		eventName = NULL;
	}

	void CDbus::DbusUnregEvent(const char *name)
	{
		H_LOG_TRACE(LOGGER, "CDbus::DbusUnregEvent(" << name << ")");
		HALO_ASSERT(name != NULL);
		//! Change '.' to '_' of name
		int strl = strlen(name);
		char *eventName = new char[strl+1];
		memcpy(eventName, name, strl+1);
		for (int i = 0; i < strl; i++)
		{
			if (eventName[i] == '.')
			{
				eventName[i] = '_';
			}
		}

		m_UnregEvenName(eventName);
		delete[] eventName;
		eventName = NULL;
	}

	void CDbus::m_RegEventName(const char * eventName)
	{
		H_LOG_TRACE(LOGGER, "CDbus::m_RegEventName(" << eventName << ")");
		HALO_ASSERT(eventName);
		RegEventList::iterator iter = m_regEventList->begin();

		while( iter != m_regEventList->end() )
		{
			if (*iter == eventName)
			{
				return;
			}
			iter++;
		}

		m_regEventList->push_back(eventName);
	}
		
	void CDbus::m_UnregEvenName(const char * eventName)
	{
		H_LOG_TRACE(LOGGER, "CDbus::m_UnregEvenName(" << eventName << ")");
		HALO_ASSERT(eventName);
		RegEventList::iterator iter = m_regEventList->begin();

		while (iter != m_regEventList->end())
		{
			if (*iter == eventName)
			{
				m_regEventList->erase(iter);
				return;
			}
			iter++;
		}
	}

	bool CDbus::m_IsRegEvent(const char * eventName)
	{
		RegEventList::iterator iter = m_regEventList->begin();

		while (iter != m_regEventList->end())
		{
			if (*iter ==  eventName)
			{
				return true;
			}
			iter++;
		}
		return false;
	}

	DBusHandlerResult CDbus::t_SignalFilter (DBusConnection *connection, DBusMessage *message, void *user_data)
	{
		H_LOG_TRACE(LOGGER, "CDbus::t_SignalFilter");
		CDbus *pThis = (CDbus *)user_data;

		//const char *name = pThis->m_name;
		char *s = NULL;
		char *m = NULL;
		char *res = NULL;
		DBusMessage *reply = NULL;
		//DBusMessageIter args;	
		dbus_bool_t r = FALSE;		
		DBusError error;   
		
		dbus_error_init(&error); 

		//! Check the signal is Disconnected or not
		if (dbus_message_is_signal(message, DBUS_INTERFACE_LOCAL, "Disconnected")) 
		{               
			return DBUS_HANDLER_RESULT_HANDLED;   
		}   

		//! Signal 1 to n
		string regEventName;
		RegEventList::iterator iter = pThis->m_regEventList->begin();

		while (iter != pThis->m_regEventList->end())
		{
			regEventName = (*iter);

			//! Start
			if (dbus_message_is_signal(message, DINTERFACE_NAME, regEventName.c_str())) 
			{  			
				if(strcmp(dbus_message_get_path(message), DOBJECT_PATH) == 0)
				{
					if (dbus_message_get_args(message, &error, DBUS_TYPE_STRING, &s, DBUS_TYPE_INVALID)) 
					{   
						//g_print("Push queue: %s\n", s);   
						//! Put the data to ClutterEvent queue
						pThis->t_PushClutterQueue(s);
						//g_print("%s\n",s);
					}    
					else 
					{                                    
				 		//g_print("[t_SignalFilter]Receive signal error: %s\n", error.message);   
				 		H_LOG_FATAL(LOGGER, "CDbus::t_SignalFilter Receive signal error:: " << error.message);
				 		dbus_error_free (&error);   
					}   
				}
			
				return DBUS_HANDLER_RESULT_HANDLED;   
			} 	
			//! Method call 1 to 1
			else if(dbus_message_is_method_call(message, DINTERFACE_NAME, regEventName.c_str()))
			{ 			
				if(strcmp(dbus_message_get_path(message), DOBJECT_PATH) == 0)
				{	
					if (dbus_message_get_args(message, &error, DBUS_TYPE_STRING, &m, DBUS_TYPE_INVALID)) 
					{
						//g_print("Receive method: %s\n", m);  
						pThis->t_SyncEventProcess(m, &res);
						//g_print("%s\n",m);
					}
					else 
					{                                    
				 		//g_print("[t_SignalFilter]Receive method error: %s\n", error.message);   
				 		H_LOG_FATAL(LOGGER, "CDbus::t_SignalFilter Receive method error:: " << error.message);
				 		dbus_error_free (&error);   
					} 

					//! Return reply
					if (res)
					{
						r = true;
						reply = dbus_message_new_method_return(message);
						if (reply == NULL)
						{
							return DBUS_HANDLER_RESULT_NEED_MEMORY;
						}
						dbus_bool_t ret = dbus_message_append_args(reply, DBUS_TYPE_BOOLEAN, &r, DBUS_TYPE_STRING, &res, DBUS_TYPE_INVALID);

						if (ret != FALSE)
						{
							dbus_connection_send(connection, reply, NULL);
						}
					
						dbus_message_unref(reply);
					}
				}
				else
				{
					//g_print("[t_SignalFilter]Method error \n");  
					H_LOG_FATAL(LOGGER, "CDbus::t_SignalFilter Method error ");

					r = false;
					reply = dbus_message_new_method_return(message);
					if (reply == NULL)
					{
						return DBUS_HANDLER_RESULT_NEED_MEMORY;
					}
					dbus_message_append_args(reply, DBUS_TYPE_BOOLEAN, &r, DBUS_TYPE_INVALID);

					dbus_connection_send(connection, reply, NULL);
					dbus_message_unref(reply);								
				}
			   
			}
			//! No match message
			else
			{
				//g_print("No match message! \n");
				H_LOG_TRACE(LOGGER, "CDbus::t_SignalFilter No match message! ");
			}
			//! End

			iter++;
		}		
		
		return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;   
	}

	bool CDbus::t_PushClutterQueue(const char *eventData)
	{
		H_LOG_TRACE(LOGGER, "CDbus::t_PushClutterQueue ");
		
		char *type = NULL;

		CCustomEvent *evt;
		evt = new CCustomEvent;
		int len = strlen(eventData);
		int ret = evt->DecodeBundle((const unsigned char *)eventData,len);
		if (ret == 1)
		{
			//g_print("decode right \n", ret);
			//! Decode the event type
			evt->GetString("EventType", &type);
			if (NULL == type)
			{
				H_LOG_TRACE(LOGGER, "CDbus::t_PushClutterQueue type == NULL ");
				return false;
			}
		}
		else
		{
			//g_print("[t_PushClutterQueue]bundle malloc error \n");
			H_LOG_FATAL(LOGGER, "CDbus::t_PushClutterQueue DecodeBundle error ");
		}
		//g_print("[t_PushClutterQueue]CDbus::t_PushClutterQueue \n");
		IEventManager* pEventManager = IEventManager::GetInstance();
		
		if (pEventManager != NULL)
		{
			evt->SetEventType(pEventManager->GetEventType(type));
			pEventManager->SendEventLocal(evt);
		}

		evt->Release();

		return true;
	}

	bool CDbus::t_SyncEventProcess(const char *eventData, char **resData)
	{
		H_LOG_TRACE(LOGGER, "CDbus::t_SyncEventProcess");
		//! Req
		char *type = NULL;

		CCustomEvent *evt;
		evt = new CCustomEvent;
		int len = strlen(eventData);
		int ret = evt->DecodeBundle((const unsigned char *)eventData,len);
		if (ret == 1)
		{
			//g_print("decode right \n", ret);
			//! Decode the event type
			evt->GetString("EventType", &type);
			if (NULL == type)
			{
				H_LOG_FATAL(LOGGER, "CDbus::t_SyncEventProcess type == NULL");
				return false;
			}

		}
		else
		{
			//g_print("[t_SyncEventProcess]bundle malloc error \n");
			H_LOG_FATAL(LOGGER, "CDbus::t_SyncEventProcess DecodeBundle error");
		}
		//g_print("[t_SyncEventProcess]CDbus::t_SyncEventProcess \n");

		//! Res
		CCustomEvent *res;
		res = new CCustomEvent;

		IEventManager* pEventManager = IEventManager::GetInstance();

		if (pEventManager != NULL)
		{
			evt->SetEventType(pEventManager->GetEventType(type));		
			pEventManager->SendEventLocalSync(evt, res);
		}
	
		//! Decode
		res->EncodeBundle((unsigned char **)resData, &len);

		evt->Release();
		res->Release();

		return true;
	}
	
}

