#include "Halo1_0.h"

namespace HALO
{
	//! Create Thread Pool with default maxThreadCount(30), default minReserveThreadCount(0), default maxPendingTaskCount(-1, no limit)
	IThreadPool* IThreadPool::CreateInstance(void)
	{
		CThreadPool* threadPool = (CThreadPool*)Instance::CreateInstance(CLASS_ID_ITHREADPOOL);
		if (threadPool)
		{
			threadPool->Initialize();
		}
		return (IThreadPool*)threadPool;
	}

	//! Create Thread Pool with given maxThreadCount, default minReserveThreadCount(0), default maxPendingTaskCount(-1, no limit)
	IThreadPool* IThreadPool::CreateInstance(int maxThreadCount)
	{
		CThreadPool* threadPool = (CThreadPool*)Instance::CreateInstance(CLASS_ID_ITHREADPOOL);
		if (threadPool)
		{
			threadPool->Initialize(maxThreadCount);
		}
		return (IThreadPool*)threadPool;
	}

	//! Create Thread Pool with given maxThreadCount, given minReserveThreadCount, default maxPendingTaskCount(-1, no limit)
	IThreadPool* IThreadPool::CreateInstance(int maxThreadCount, int minReserveTheadCount)
	{
		CThreadPool* threadPool = (CThreadPool*)Instance::CreateInstance(CLASS_ID_ITHREADPOOL);
		if (threadPool)
		{
			threadPool->Initialize(maxThreadCount, minReserveTheadCount);
		}
		return (IThreadPool*)threadPool;
	}

	//! Create Thread Pool with given maxThreadCount, given minReserveThreadCount, given maxPendingTaskCount
	IThreadPool* IThreadPool::CreateInstance(int maxThreadCount, int minReserveTheadCount, int maxPendingTaskCount)
	{
		CThreadPool* threadPool = (CThreadPool*)Instance::CreateInstance(CLASS_ID_ITHREADPOOL);
		if (threadPool)
		{
			threadPool->Initialize(maxThreadCount, minReserveTheadCount, maxPendingTaskCount);
		}
		return (IThreadPool*)threadPool;
	}
}