#include <string.h>
#include <stdio.h>

#include "ScriptBridge.h"
#include "logger.h"
#include "v8/v8.h"

using namespace v8;
namespace Bridge
{
	class LogBridge: public ScriptInstanceBridge
	{
	public:
		LogBridge();
		virtual ~LogBridge();
		static std::string LOGGER_NAME;

	protected:
		virtual inline const char* getScriptClassName() const
		{
			return "Log";
		}
		virtual void mapScriptInterface(ScriptContext& aContext);
		virtual void* constructFromScript(const ScriptArray &aArgs);
		virtual inline void destroyFromScript(void *aDestroyedObject)
		{
			// got nothing to do for now..
		}

		static ScriptObject HandlePrint(LogBridge *aSelf, const ScriptArray &aArgs);
		static ScriptObject HandleDebug(LogBridge *aSelf, const ScriptArray &args);
		static ScriptObject HandleError(LogBridge *aSelf, const ScriptArray &args);
		static ScriptObject HandleFatal(LogBridge *aSelf, const ScriptArray &args);
		static ScriptObject HandleInfo(LogBridge *aSelf, const ScriptArray &args);

		static volt::util::Logger logger_;
	};
}
