/*
 * SceneRootBridge.h
 *
 *  Created on: Jun 24, 2013
 *      Author: reza
 */

#ifndef SCENEROOTBRIDGE_H_
#define SCENEROOTBRIDGE_H_

#include "ScriptBridge.h"
#include "SceneRoot.h"
#include "WidgetBridge.h"

namespace Bridge
{

class SceneRootBridge : public ScriptInstanceBridge
{
  public:

    SceneRootBridge(SceneRoot* root) : ScriptInstanceBridge(root) {}

    virtual void mapScriptInterface(ScriptContext& context);
    virtual const char* getScriptClassName() const
    {
      return "scene";
    };

    static ScriptObject getSize(SceneRoot* self);
    static void setSize(SceneRoot* self, ScriptObject value);

    static ScriptObject getColor(SceneRoot* self);
    static void setColor(SceneRoot* self, ScriptObject value);

    static ScriptObject getChildCount(SceneRoot* self, const ScriptArray& args);
    static ScriptObject addChild(SceneRoot* self, const ScriptArray& args);
    static ScriptObject getChild(SceneRoot* self, const ScriptArray& args);
    static ScriptObject removeChild(SceneRoot* self, const ScriptArray& args);
    static ScriptObject getDescendent(SceneRoot* self, const ScriptArray& args);
    static ScriptObject getAncestor(SceneRoot* self, const ScriptArray& args);
    static ScriptObject handleDestroyChildren(SceneRoot* self, const ScriptArray& args);
    static ScriptObject getKeyFocus(SceneRoot* self, const ScriptArray& args);
    static ScriptObject setKeyFocus(SceneRoot* self, const ScriptArray& args);
    static ScriptObject clearKeyFocus(SceneRoot* self, const ScriptArray& args);

    static ScriptObject show(SceneRoot* self, const ScriptArray& args);
    static ScriptObject hide(SceneRoot* self, const ScriptArray& args);


};

} /* namespace Bridge */
#endif /* SCENEROOTBRIDGE_H_ */
