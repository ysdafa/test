/*
 * VoltUtilityBridge.h
 *
 *  Created on: August 11, 2014
 *      Author: Backki Kim
 */

#ifndef SAMSUNG_KINGSCANYON_VDUTILBRIDGE_H_
#define SAMSUNG_KINGSCANYON_VDUTILBRIDGE_H_

#include <sys/time.h>
#include "ScriptBridge.h"

#include "logger.h"

namespace Bridge
{
  class VDUtilBridge : public ScriptInstanceBridge
  {
    public:

      VDUtilBridge();

      virtual ~VDUtilBridge();

      static std::string LOGGER_NAME;

    protected:

      virtual inline const char* getScriptClassName() const
      {
        return "VDUtil";
      }

      virtual void mapScriptInterface(ScriptContext& aContext);

      virtual void* constructFromScript(const ScriptArray &aArgs);

      virtual inline void destroyFromScript(void *aDestroyedObject)
      {
        // got nothing to do for now..
      }

      static ScriptObject HandleVDSetTimeOfDay(VDUtilBridge *aSelf, const ScriptArray &aArgs);
      static ScriptObject HandleVDGetTimeOfDay(VDUtilBridge *aSelf, const ScriptArray &aArgs);
      static ScriptObject HandleVDLocalTime(VDUtilBridge *aSelf, const ScriptArray &aArgs);
      static ScriptObject HandleVDGetTimeZone(VDUtilBridge *aSelf, const ScriptArray &aArgs);
      static ScriptObject HandleGetProcMemory(VDUtilBridge *aSelf, const ScriptArray &aArgs);
      static ScriptObject HandleFirstScreenReady(VDUtilBridge *aSelf, const ScriptArray &aArgs);
      static ScriptObject HandleIsExistWASTempFile(VDUtilBridge *aSelf, const ScriptArray &aArgs);
      static ScriptObject HandleHeapSnapShot(VDUtilBridge *aSelf, const ScriptArray &aArgs);
      static ScriptObject HandleGetXWindowID(VDUtilBridge *aSelf, const ScriptArray &aArgs);
	  static ScriptObject HandleVDAnnotate(VDUtilBridge *aSelf, const ScriptArray &aArgs);	  
	  static ScriptObject HandleVDRaiseXWindow(VDUtilBridge *aSelf, const ScriptArray &aArgs);
	  static ScriptObject HandleGetMLSstate(VDUtilBridge *aSelf, const ScriptArray &aArgs);
      
    protected:
      static volt::util::Logger logger_;
  };

} /* namespace Bridge */
#endif /* SAMSUNG_KINGSCANYON_VDUTILBRIDGE_H_ */
