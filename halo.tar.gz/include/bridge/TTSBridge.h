/*
* TTSBridge.h
*
*  Created on: August 11, 2014
*      Author: Backki Kim
*/

#ifndef SAMSUNG_KINGSCANYON_TTSBRDIGE_H_
#define SAMSUNG_KINGSCANYON_TTSBRDIGE_H_

#include "ScriptBridge.h"

#include "logger.h"

namespace Bridge
{
	class TTSBridge : public ScriptInstanceBridge
	{
	public:

		TTSBridge();

		virtual ~TTSBridge();

		static std::string LOGGER_NAME;

	protected:

		virtual inline const char* getScriptClassName() const
		{
			return "TTS";
		}

		virtual void mapScriptInterface(ScriptContext& aContext);

		virtual void* constructFromScript(const ScriptArray &aArgs);

		virtual inline void destroyFromScript(void *aDestroyedObject)
		{
			// got nothing to do for now..
		}

		static ScriptObject HandlePlayText(TTSBridge *aSelf, const ScriptArray &aArgs);
	};

} /* namespace Bridge */
#endif /* SAMSUNG_KINGSCANYON_TTSBRDIGE_H_ */
