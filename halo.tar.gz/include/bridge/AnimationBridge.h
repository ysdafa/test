#ifndef __ANIMATION_BRIDGE_H_INCL__
#define __ANIMATION_BRIDGE_H_INCL__

#include "ScriptBridge.h"
#include "Animation.h"
#include <unordered_map>

namespace Bridge
{

/* Bridge for AnimationHandles. These are retuned to
 *  JavaScript when an animation is created, and can be used
 *  to control the running animation */
class AnimationHandleBridge : public ScriptBridge
{

  protected:
    /**
     * Bind callbacks to all getters, setters, and functions that should be exposed to javascript.
     * This function will be called once when the v8 binder is first initialized.
     * @param[in] context The context to which to which properties and methods of the object should be exposed. ScriptContext
     * wraps the methods that enable the mapping.
     */
    virtual void mapScriptInterface(ScriptContext &);

    virtual const char* getScriptClassName() const
    {
      return "AnimationHandle";
    }

    virtual void destroyFromScript(void* pointerToDestroyedObject)
    {
      volt::graphics::AnimationHandle* handle = reinterpret_cast<volt::graphics::AnimationHandle*>(pointerToDestroyedObject);
      handle->release();
    }

    virtual void* constructFromScript(const ScriptArray& args)
    {
      return NULL;  //This should never be constructed from script...
    }

};

/*
 *  AnimationBridge bridges the animation object class. It also
 *  contains the implemenation of the bridging logic for widget.animate and widget.cancelAnimation (these functions actually map
 *  to animation object functions)
 */
class AnimationBridge : public ScriptBridge
{
    static AnimationHandleBridge handleBridge;

  protected:

    virtual inline const char* getScriptClassName() const
    {
      return "Animation";
    }

    virtual void mapScriptInterface(ScriptContext& context);

    virtual void* constructFromScript(const ScriptArray& args);

    virtual inline void destroyFromScript(void* destroyedObject);

    //need to initailize the AnimationHandleBridge, since it is not exposed directly to ScriptEngine
    virtual void contextReady()
    {
      handleBridge.contextReady();
    }

  public:
    //These are Animation object functions, which are represented JS side as functions on Widget objects.
    static ScriptObject parseAnimateFunctionParams(volt::graphics::Widget* widget, const ScriptArray& args);
    static ScriptObject parseCancelAnimateFunction(volt::graphics::Widget* widget, const ScriptArray& args);

    static void onAnimationFinished(const ScriptFunction& callback);

    static ScriptObject addCompleteCallback(volt::graphics::IAnimationCallbacks* self, const ScriptArray& args);
    static ScriptObject addKeyCallback(volt::graphics::IAnimationCallbacks* self, const ScriptArray& args);


  private:

    static std::unordered_map<std::string, volt::graphics::AnimatableProperty> propMap;

    static ScriptObject addProperty(volt::graphics::Animation* self, const ScriptArray& args);
    static ScriptObject addPropertyRelative(volt::graphics::Animation* self, const ScriptArray& args);
    static ScriptObject addPropertyWithBezier(volt::graphics::Animation* self, const ScriptArray& args);
    static ScriptObject addPropertyRelativeWithBezier(volt::graphics::Animation* self, const ScriptArray& args);

    static ScriptObject addKey(volt::graphics::Animation* self, const ScriptArray& args);
    static ScriptObject addRelativeKey(volt::graphics::Animation* self, const ScriptArray& args);

    static ScriptObject addKeyframe(volt::graphics::Animation* self, const ScriptArray& args, bool hasKey, bool isRelative, bool hasBezier);

    static bool parseAnimationParams(const ScriptArray& args, volt::graphics::Animation& result, float key, bool isRelative, int argsOffset, bool useBezier);
    static TweenMode deserializeTweenMode(std::string tweenStr);
    static volt::graphics::AnimatableProperty parseProperty(std::string property);
    static void parseAnimationValueObject(ScriptObject values, std::string property, TweenMode tweenMode, volt::graphics::Animation& result,
                                          float key, bool isRelative, volt::graphics::BezierCurve customEasingCurve);

    //throws VoltJsRuntimeException if obj is not a bezier curve
    static volt::graphics::BezierCurve getBezierControlPoints(const ScriptObject& obj);
};


}
#endif // __ANIMATION_BRIDGE_H_INCL__
