/*
 * AulBridge.h
 *
 *  Created on: June 26, 2014
 *      Author: Joe Yee
 */

#ifndef SAMSUNG_KINGSCANYON_AULBRIDGE_H_
#define SAMSUNG_KINGSCANYON_AULBRIDGE_H_

#include "ScriptBridge.h"
#include "TizenAul.h"
#include <map>

#include "logger.h"

namespace Bridge
{
class AulBridge : public ScriptBridge
{
  public:

#if defined(BUILD_FOR_TV) && defined(TIZEN)
    struct CallbackMessage
    {
      TizenAul *aul;
      bundle *aulBundle;
    };
#endif

    typedef std::map<TizenAul*, ScriptFunction> CALLBACK_MAP;

    AulBridge();

    virtual ~AulBridge();

#if defined(BUILD_FOR_TV) && defined(TIZEN)
    static void ProxyLaunchServiceCallback(TizenAul *aSelf, bundle *b);

    static void FireLaunchServiceCallback(CallbackMessage *msg);

    static bundle *extractArguments(ScriptObject &args);
#endif

    static std::string LOGGER_NAME;

  protected:

    /**
     * Bridge to Launch an AUL App.
     * @param[in] aSelf An instance of AulApp class.
     * @param[in] aArgs Arguments given by the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleLaunchApp(TizenAul *aSelf, const ScriptArray &aArgs);

    /**
     * Bridge to Open an AUL App service.
     * @param[in] aSelf An instance of AulApp class.
     * @param[in] aArgs Arguments given by the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleOpenSerivce(TizenAul *aSelf, const ScriptArray &aArgs);

    /**
     * Bridge to Close an AUL App.
     * @param[in] aSelf An instance of AulApp class.
     * @param[in] aArgs Arguments given by the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleTerminate(TizenAul *aSelf, const ScriptArray &aArgs);

    virtual inline const char* getScriptClassName() const
    {
      return "Aul";
    }

    virtual void mapScriptInterface(ScriptContext& aContext);

    virtual void* constructFromScript(const ScriptArray &aArgs);

    virtual inline void destroyFromScript(void *aDestroyedObject)
    {
      TizenAul *object = reinterpret_cast<TizenAul *>(aDestroyedObject);
      callbackMap.erase(object);

      delete object;
    }

    static volt::util::Logger logger_;
    static CALLBACK_MAP callbackMap;
};

} /* namespace Bridge */
#endif /* SAMSUNG_KINGSCANYON_AULBRIDGE_H_ */
