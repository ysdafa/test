#ifndef SAMSUNG_KINGSCANYON_VOLTWORKER_BRIDGE_H_
#define SAMSUNG_KINGSCANYON_VOLTWORKER_BRIDGE_H_

#include "ScriptBridge.h"
#include "VoltWorker.h"

namespace Bridge
{

class VoltWorkerBridge : public ScriptBridge
{
  public:
    VoltWorkerBridge();
    virtual ~VoltWorkerBridge();

    /**
     * Call the onMessage callback for the message received from the indicated
     * worker (via the Volt.postMessage method).
     *
     * @param[in] aID ID of the worker that sent this message.
     * @param[in] aMsg Received message.
     *
     * @return true on success, false otherwise.
     */
    bool HandleWorkerMessage(const std::string &aID,
                             const std::string &aMsg);

    /**
     * Call the onCommand callback for the command received from the indicated
     * worker (via the Volt.execCommand method).
     *
     * @param[in] aID ID of the worker that sent this command.
     * @param[in] aCmd Received command.
     * @param[out] aResult Execution result.
     *
     * @return true on success, false otherwise.
     */
    bool HandleWorkerCommand(const std::string &aID,
                             const std::string &aCmd,
                             std::string &aResult);


    /**
     * Call the onError callback for associated with the indicated
     * worker.
     * Typically this is fired when there is an unhandled JS exception in the
     * worker process.
     *
     * @param[in] aID ID of the worker that sent this message.
     * @param[in] aMsg Exception message.
     *
     * @return true on success, false otherwise.
     */
    bool HandleWorkerError(const std::string &aID,
                           const std::string &aMsg);

    static VoltWorker* FindWorker(const std::string &aID);

  protected:
    static void AssignOnMessageCallback(VoltWorker *aWorker,
                                        ScriptFunction aJsCallback);

    static void AssignOnCommandCallback(VoltWorker *aWorker,
                                        ScriptFunction aJsCallback);

    static void AssignOnErrorCallback(VoltWorker *aWorker,
                                      ScriptFunction aJsCallback);

    static ScriptObject HandlePostMessage(VoltWorker *aWorker,
                                          const ScriptArray &aArgs);

    static ScriptObject HandleExecCommand(VoltWorker *aWorker,
                                          const ScriptArray &aArgs);

    static ScriptObject HandleOnMessage(VoltWorker *aWorker,
                                        const ScriptArray &aArgs);

    static ScriptObject GetOnMessage(VoltWorker *aWorker);
    static void SetOnMessage(VoltWorker *aWorker, ScriptObject aObj);

    static ScriptObject GetOnCommand(VoltWorker *aWorker);
    static void SetOnCommand(VoltWorker *aWorker, ScriptObject aObj);

    static ScriptObject GetOnError(VoltWorker *aWorker);
    static void SetOnError(VoltWorker *aWorker, ScriptObject aObj);

    static ScriptObject GetIsRunning(VoltWorker *aWorker);
    static void SetIsRunning(VoltWorker *aWorker, ScriptObject aObj);

    static ScriptObject HandleTerminate(VoltWorker *aWorker,
                                        const ScriptArray &aArgs);

    /* Redefined virtuals */

    virtual inline const char* getScriptClassName() const
    {
      return "VoltWorker";
    }

    virtual void mapScriptInterface(ScriptContext& aContext);

    virtual void* constructFromScript(const ScriptArray &aArgs);

    virtual inline void destroyFromScript(void *aDestroyedObject)
    {
      VoltWorker *worker = reinterpret_cast<VoltWorker *>(aDestroyedObject);
      delete worker;
    }

  private:
    static std::map<std::string, VoltWorker *> workers_;
};

} /* namespace Bridge */
#endif
