/*
 * ResourceBridge.h
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#ifndef SAMSUNG_KINGSCANYON_RESOURCE_BRIDGE_H
#define SAMSUNG_KINGSCANYON_RESOURCE_BRIDGE_H

#include "ScriptBridge.h"
#include "IORequest.h"
#include "ResourceRequest.h"

#include <glib.h>

#include "logger.h"

namespace Bridge
{

class ResourceBridge : public ScriptBridge
{
  public:
    static std::string LOGGER_NAME;

  public:
    ResourceBridge();
    virtual ~ResourceBridge();

  protected:
    /**
     * Handle the "addHeader" API call from the JS.
     * @param[in] aReqInfo Request information given from the JS.
     * @param[in] aArgs Arguments given by the JS.
     * @return ScriptObject.
     */
    static ScriptObject HandleAddHeader(ResourceRequest *aReqInfo,
                                        const ScriptArray &aArgs);

    /**
    * Handle the "removeHeader" API call from the JS.
    * @param[in] aReqInfo Request information given from the JS.
    * @param[in] aArgs Arguments given by the JS.
    * @return ScriptObject.
    */
    static ScriptObject HandleRemoveHeader(ResourceRequest *aReqInfo,
                                           const ScriptArray &aArgs);

    static ScriptObject HandleClearHeaders(ResourceRequest *aReqInfo,
                                           const ScriptArray &aArgs);

    static ScriptObject HandleReplaceHeader(ResourceRequest *aReqInfo,
                                            const ScriptArray &aArgs);

    static ScriptObject HandleAssignHeaders(ResourceRequest *aReqInfo,
                                            const ScriptArray &aArgs);

    /**
     * Handle the "setHeaders" API call from the JS.
     * @param[in] aReqInfo Request information given from the JS.
     * @param[in] aArgs Arguments given by the JS.
     * @return ScriptObject.
     */
    static ScriptObject HandleSetHeaders(ResourceRequest *aReqInfo,
                                         const ScriptArray &aArgs);

    /**
     * Handle the "setHeaders" API call from the JS.
     * @param[in] aReqInfo Request information given from the JS.
     * @param[in] aArgs Arguments given by the JS.
     * @return ScriptObject.
     */
    static ScriptObject HandleSetHeaderBlock(ResourceRequest *aReqInfo,
        const ScriptArray &aArgs);

    /**
     * Handle the "Process" API call from the JS.
     * @param[in] aReqInfo Request information given from the JS.
     * @param[in] aArgs Arguments given by the JS.
     * @return ScriptObject.
     */
    static ScriptObject HandleProcess(ResourceRequest *aReqInfo,
                                      const ScriptArray &aArgs);

    /**
     * Handle the "Cancel" API call from the JS.
     * @param[in] aReqInfo Request information given from the JS.
     * @param[in] aArgs Arguments given by the JS.
     * @return ScriptObject.
     */
    static ScriptObject HandleCancel(ResourceRequest *aReqInfo,
                                     const ScriptArray &aArgs);

    /**
     * Callback to be called by ResourceManager when the request completes.
     * This would simply schedule FireOnCompleteCallbacks to be called in clutter's
     * main thread.
     * @param[in] aReqInfo Completed request.
     * @param[in] aJsCallback Callback in the JS to execute.
     */
    static void OnComplete(Resource::IORequest::SharedPtr aRequest,
                           const ScriptFunction &aJsSuccessCallback,
                           const ScriptFunction &aJsErrorCallback,
                           const ScriptFunction &aJsCompleteCallback,
                           const ScriptFunction &aJsCallback);

	static void OnCacheRead(Resource::IORequest::SharedPtr aRequest,
						const ScriptFunction &aJsCacheCallback);

    /**
     * Execute the JS callback.
     * @param[in] aData Data of the completed asynchronous event.
     * @return FALSE.
     */
    static gboolean FireOnCompleteCallbacks(gpointer aData);
	static gboolean FireOnCacheReadCallbacks(gpointer aData);

    /**
     * Utility function to create a ScriptObject object containing the data
     * for the response received for the given request.
     * @param[in] aRequest Originating request for the response.
     * @return ScriptObject instance with the response data.
     */
    static ScriptObject
    CreateResponseScriptObject(const Resource::IORequest::SharedPtr aRequest);

    static ScriptObject
    CreateDirResponseScriptObject(const Resource::IORequest::SharedPtr aRequest);

    static ScriptObject getResourceRequestData(ResourceRequest* self);

    static void setResourceRequestData(ResourceRequest* self, ScriptObject value);

    /* Redefined virtuals */

    virtual inline const char* getScriptClassName() const
    {
      return "ResourceRequest";
    }

    virtual void mapScriptInterface(ScriptContext& aContext);

    virtual void* constructFromScript(const ScriptArray &aArgs);

    virtual inline void destroyFromScript(void *aDestroyedObject)
    {
      ResourceRequest *object =
        reinterpret_cast<ResourceRequest *>(aDestroyedObject);
      delete object;
    }

  protected:
    volt::util::Logger logger_;
};

} /* namespace Bridge */
#endif /* SAMSUNG_KINGSCANYON_RESOURCE_BRIDGE_H */
