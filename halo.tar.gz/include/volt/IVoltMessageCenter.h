#ifndef _I_VOLT_MESSAGE_CENTER_H_
#define _I_VOLT_MESSAGE_CENTER_H_

#include "MessageCenter.h"

class IVoltMessageCenter
{
  public:
    /** Initialize internal state. */
    virtual void Initialize() = 0;

    /**
     * Initialize internal state on the application process.
     *
     * @return true on success, false otherwise.
     */
    virtual bool InitializeOnApp() = 0;

    /**
     * Initialize internal state on a worker process.
     *
     * @return true on success, false otherwise.
     */
    virtual bool InitializeOnWorker() = 0;

    /**
     * Perform preparation just before starting the worker process.
     * This function is called from the parent process.
     *
     * @param[in] aWorkerID ID of the to-be-created worker.
     *
     * @return true on success, false otherwise.
     */
    virtual bool PrepareWorker(const std::string &aWorkerID) = 0;

    /**
     * Initialize internal state on the graphics process.
     *
     * @return true on success, false otherwise.
     */
    virtual bool InitializeOnGfx() = 0;

    /** Wait/block until the graphics process is ready. */
    virtual void WaitForGfxReady() = 0;

    /**
     * Get the ID of this IVoltMessageCenter instance.
     */
    virtual const std::string& ID() const = 0;

    /**
     * Get the ID of the current Volt process.
     * @return ID of the current Volt process.
     */
    virtual const std::string& ProcessID() const = 0;

    /**
     * Get the ID of the master application process.
     * @return ID of the master application process.
     */
    virtual const std::string& AppProcessID() const = 0;

    /**
     * Get the ID of the graphics process.
     * @return ID of the graphics process.
     */
    virtual const std::string& GfxProcessID() const = 0;

    /**
     * Get the ID of the parent process.
     * @return ID of the parent process.
     */
    virtual const std::string& ParentProcessID() const = 0;

    /**
     * Register a default message handler on a Volt process.
     * @param[in] aID ID of the Volt process.
     * @param[in] aHandler Default message handler.
     */
    virtual void RegisterHandlerOnProc(const std::string &aID,
                                       volt::util::ipc::MessageCenter::MessageHandler aHandler) = 0;

    /**
     * Register a message handler for the specific group on a
     * Volt process.
     * @param[in] aID ID of the Volt process.
     * @param[in] aGroup Message group.
     * @param[in] aHandler Gruop message handler.
     */
    virtual void RegisterHandlerOnProc(const std::string &aID,
                                       const volt::util::ipc::MessageGroup aGroup,
                                       volt::util::ipc::MessageCenter::MessageHandler aHandler) = 0;

    /**
     * Register a message handler for the specific type on a
     * Volt process.
     * @param[in] aID ID of the Volt process.
     * @param[in] aType Message type.
     * @param[in] aHandler Type message handler.
     */
    virtual void RegisterHandlerOnProc(const std::string &aID,
                                       const volt::util::ipc::MessageType aType,
                                       volt::util::ipc::MessageCenter::MessageHandler aHandler) = 0;

    /**
     * Post a message to a Volt process.
     *
     * @param[in] aID ID of the Volt process.
     * @param[in] aType Message type.
     *
     * @return true on success, false otherwise.
     */
    virtual bool PostMsgToProc(const std::string &aID,
                               volt::util::ipc::MessageType aType) = 0;

    /**
     * Post a message to a Volt process with an associated data.
     *
     * The data given should be "flat" (no complex data types that require
     * dynamic memory allocation).
     *
     * @param[in] aID ID of the Volt process.
     * @param[in] aType Message type.
     * @param[in] aData Data associated with the message.
     * @param[in] aSize Size of the data.
     *
     * @return true on success, false otherwise.
     */
    virtual bool PostMsgToProc(const std::string &aID,
                               volt::util::ipc::MessageType aType,
                               void *aData,
                               const size_t aSize) = 0;

    /**
     * Execute a command on a Volt process.
     * This function blocks until the execution completes.
     * The supplied result handler will be called when the execution finishes.
     *
     * @param[in] aID ID of the Volt process.
     * @param[in] aType Command type.
     * @param[in] aHandler Result handler.
     *
     * @return true on success, false otherwise.
     */
    virtual bool ExecuteOnProc(const std::string &aID,
                               volt::util::ipc::MessageType aType,
                               volt::util::ipc::MessageCenter::ResultHandler aHandler) = 0;

    /**
     * Execute a command on a Volt process with an associated data.
     * This function blocks until the execution completes.
     * The supplied result handler will be called when the execution finishes.
     *
     * The data given should be "flat" (no complex data types that require
     * dynamic memory allocation).
     *
     * @param[in] aID ID of the Volt process.
     * @param[in] aType Command type.
     * @param[in] aHandler Result handler.
     * @param[in] aData Data associated with the message.
     * @param[in] aSize Size of the data.
     *
     * @return true on success, false otherwise.
     */
    virtual bool ExecuteOnProc(const std::string &aID,
                               volt::util::ipc::MessageType aType,
                               volt::util::ipc::MessageCenter::ResultHandler aHandler,
                               void *aData, const size_t aSize) = 0;

    /**
     * Register a default message handler on this Volt process.
     * @param[in] aHandler Default message handler.
     */
    virtual void RegisterHandlerOnSelf(volt::util::ipc::MessageCenter::MessageHandler aHandler)
    {
      RegisterHandlerOnProc(ProcessID(), aHandler);
    }

    /**
     * Register a message handler for the specific group on this
     * Volt process.
     * @param[in] aGroup Message group.
     * @param[in] aHandler Gruop message handler.
     */
    virtual void RegisterHandlerOnSelf(const volt::util::ipc::MessageGroup aGroup,
                                       volt::util::ipc::MessageCenter::MessageHandler aHandler)
    {
      RegisterHandlerOnProc(ProcessID(), aGroup, aHandler);
    }

    /**
     * Register a message handler for the specific type on this
     * Volt process.
     * @param[in] aType Message type.
     * @param[in] aHandler Type message handler.
     */
    virtual void RegisterHandlerOnSelf(const volt::util::ipc::MessageType aType,
                                       volt::util::ipc::MessageCenter::MessageHandler aHandler)
    {
      RegisterHandlerOnProc(ProcessID(), aType, aHandler);
    }

    /**
     * Post a message to this Volt process.
     *
     * @param[in] aType Message type.
     *
     * @return true on success, false otherwise.
     */
    virtual bool PostMsgToSelf(volt::util::ipc::MessageType aType)
    {
      return PostMsgToSelf(aType, NULL, 0);
    }

    /**
     * Post a message to this Volt process with an associated data.
     *
     * The data given should be "flat" (no complex data types that require
     * dynamic memory allocation).
     *
     * @param[in] aType Message type.
     * @param[in] aData Data associated with the message.
     * @param[in] aSize Size of the data.
     *
     * @return true on success, false otherwise.
     */
    virtual bool PostMsgToSelf(volt::util::ipc::MessageType aType,
                               void *aData,
                               const size_t aSize)
    {
      return PostMsgToProc(ProcessID(), aType, aData, aSize);
    }

    /**
     * Execute a command on this Volt process.
     * This function blocks until the execution completes.
     * The supplied result handler will be called when the execution finishes.
     *
     * @param[in] aType Command type.
     * @param[in] aHandler Result handler.
     *
     * @return true on success, false otherwise.
     */
    virtual bool ExecuteOnSelf(volt::util::ipc::MessageType aType,
                               volt::util::ipc::MessageCenter::ResultHandler aHandler)
    {
      return ExecuteOnSelf(aType, aHandler, NULL, 0);
    }

    /**
     * Execute a command on this Volt process with an associated data.
     * This function blocks until the execution completes.
     * The supplied result handler will be called when the execution finishes.
     *
     * The data given should be "flat" (no complex data types that require
     * dynamic memory allocation).
     *
     * @param[in] aType Command type.
     * @param[in] aHandler Result handler.
     * @param[in] aData Data associated with the message.
     * @param[in] aSize Size of the data.
     *
     * @return true on success, false otherwise.
     */
    virtual bool ExecuteOnSelf(volt::util::ipc::MessageType aType,
                               volt::util::ipc::MessageCenter::ResultHandler aHandler,
                               void *aData, const size_t aSize)
    {
      return ExecuteOnProc(ProcessID(), aType, aHandler, aData, aSize);
    }

    /**
     * Start a main loop to receive incoming messages on this Volt
     * process.
     * This function does not return until StopMainLoop is called.
     */
    virtual void StartMainLoop() = 0;

    /**
     * Start a main loop to receive incoming messages on this Volt
     * process.
     * This function creates a thread to run the main loop.
     */
    virtual void StartMainLoopThread() = 0;

    /**
     * Stop the main loop on this Volt process.
     */
    virtual void StopMainLoop() = 0;

    /**
     * Join the thread running the main loop on this Volt process.
     */
    virtual void JoinMainLoopThread() = 0;

    /**
     * Register a default message handler on the application process.
     * @param[in] aHandler Default message handler.
     */
    virtual void RegisterHandlerOnApp(volt::util::ipc::MessageCenter::MessageHandler aHandler)
    {
      RegisterHandlerOnProc(AppProcessID(), aHandler);
    }

    /**
     * Register a message handler for the specific group on the
     * application process.
     * @param[in] aGroup Message group.
     * @param[in] aHandler Gruop message handler.
     */
    virtual void RegisterHandlerOnApp(const volt::util::ipc::MessageGroup aGroup,
                                      volt::util::ipc::MessageCenter::MessageHandler aHandler)
    {
      RegisterHandlerOnProc(AppProcessID(), aGroup, aHandler);
    }

    /**
     * Register a message handler for the specific type on the
     * application process.
     * @param[in] aType Message type.
     * @param[in] aHandler Type message handler.
     */
    virtual void RegisterHandlerOnApp(const volt::util::ipc::MessageType aType,
                                      volt::util::ipc::MessageCenter::MessageHandler aHandler)
    {
      RegisterHandlerOnProc(AppProcessID(), aType, aHandler);
    }

    /**
     * Register a default message handler on a worker process.
     * @param[in] aID ID of the worker.
     * @param[in] aHandler Default message handler.
     */
    virtual void RegisterHandlerOnWorker(const std::string &aID,
                                         volt::util::ipc::MessageCenter::MessageHandler aHandler)
    {
      RegisterHandlerOnProc(aID, aHandler);
    }

    /**
     * Register a message handler for the specific group on a
     * worker process.
     * @param[in] aID ID of the worker.
     * @param[in] aGroup Message group.
     * @param[in] aHandler Gruop message handler.
     */
    virtual void RegisterHandlerOnWorker(const std::string &aID,
                                         const volt::util::ipc::MessageGroup aGroup,
                                         volt::util::ipc::MessageCenter::MessageHandler aHandler)
    {
      RegisterHandlerOnProc(aID, aGroup, aHandler);
    }

    /**
     * Register a message handler for the specific type on a
     * worker process.
     * @param[in] aID ID of the worker.
     * @param[in] aType Message type.
     * @param[in] aHandler Type message handler.
     */
    virtual void RegisterHandlerOnWorker(const std::string &aID,
                                         const volt::util::ipc::MessageType aType,
                                         volt::util::ipc::MessageCenter::MessageHandler aHandler)
    {
      RegisterHandlerOnProc(aID, aType, aHandler);
    }

    /**
     * Register a default message handler on the graphics process.
     * @param[in] aHandler Default message handler.
     */
    virtual void RegisterHandlerOnGfx(volt::util::ipc::MessageCenter::MessageHandler aHandler)
    {
      RegisterHandlerOnProc(GfxProcessID(), aHandler);
    }

    /**
     * Register a message handler for the specific group on the
     * graphics process.
     * @param[in] aGroup Message group.
     * @param[in] aHandler Gruop message handler.
     */
    virtual void RegisterHandlerOnGfx(const volt::util::ipc::MessageGroup aGroup,
                                      volt::util::ipc::MessageCenter::MessageHandler aHandler)
    {
      RegisterHandlerOnProc(GfxProcessID(), aGroup, aHandler);
    }

    /**
     * Register a message handler for the specific type on the
     * graphics process.
     * @param[in] aType Message type.
     * @param[in] aHandler Type message handler.
     */
    virtual void RegisterHandlerOnGfx(const volt::util::ipc::MessageType aType,
                                      volt::util::ipc::MessageCenter::MessageHandler aHandler)
    {
      RegisterHandlerOnProc(GfxProcessID(), aType, aHandler);
    }

    /**
     * Start a main loop to receive incoming messages on the applicaiton
     * process.
     * This function does not return until StopAppMainLoop is called.
     */
    virtual void StartAppMainLoop()
    {
      StartMainLoop();
    }

    /**
     * Stop the main loop on the application process.
     */
    virtual void StopAppMainLoop()
    {
      StopMainLoop();
    }

    /**
     * Start a main loop to receive incoming messages on a worker
     * process.
     * This function does not return until StopWorkerMainLoop is called.
     *
     * @param[in] aID ID of the worker.
     */
    virtual void StartWorkerMainLoop(const std::string &aID)
    {
      StartMainLoop();
    }

    /**
     * Stop the main loop on a worker process.
     *
     * @param[in] aID ID of the worker.
     */
    virtual void StopWorkerMainLoop(const std::string &aID)
    {
      StopMainLoop();
    }

    /**
     * Start a main loop to receive incoming messages on the graphics
     * process.
     * This function creates a thread to run the main loop.
     */
    virtual void StartGfxMainLoop()
    {
      StartMainLoopThread();
    }

    /**
     * Stop the main loop on the graphics process.
     */
    virtual void StopGfxMainLoop()
    {
      StopMainLoop();
    }

    /**
     * Join the thread running the main loop on the graphics process.
     */
    virtual void JoinGfxMainLoop()
    {
      JoinMainLoopThread();
    }

    /**
     * Check if the calling process is the graphics process.
     * @return true if the current process is the graphics process.
     */
    virtual bool IsGfxProcess() const
    {
      return ProcessID() == GfxProcessID();
    }

    /**
     * Post a message to an application process.
     *
     * @param[in] aType Message type.
     *
     * @return true on success, false otherwise.
     */
    virtual bool PostMsgToApp(volt::util::ipc::MessageType aType)
    {
      return PostMsgToProc(AppProcessID(), aType);
    }

    /**
     * Post a message to an application process with an associated data.
     *
     * The data given should be "flat" (no complex data types that require
     * dynamic memory allocation).
     *
     * @param[in] aType Message type.
     * @param[in] aData Data associated with the message.
     * @param[in] aSize Size of the data.
     *
     * @return true on success, false otherwise.
     */
    virtual bool PostMsgToApp(volt::util::ipc::MessageType aType,
                              void *aData,
                              const size_t aSize)
    {
      return PostMsgToProc(AppProcessID(), aType, aData, aSize);
    }

    /**
     * Post a message to a worker process.
     *
     * @param[in] aID ID of the worker.
     * @param[in] aType Message type.
     *
     * @return true on success, false otherwise.
     */
    virtual bool PostMsgToWorker(const std::string &aID,
                                 volt::util::ipc::MessageType aType)
    {
      return PostMsgToProc(aID, aType);
    }

    /**
     * Post a message to a worker process with an associated data.
     *
     * The data given should be "flat" (no complex data types that require
     * dynamic memory allocation).
     *
     * @param[in] aID ID of the worker.
     * @param[in] aType Message type.
     * @param[in] aData Data associated with the message.
     * @param[in] aSize Size of the data.
     *
     * @return true on success, false otherwise.
     */
    virtual bool PostMsgToWorker(const std::string &aID,
                                 volt::util::ipc::MessageType aType,
                                 void *aData,
                                 const size_t aSize)
    {
      return PostMsgToProc(aID, aType, aData, aSize);
    }

    /**
     * Post a message to the graphics process.
     *
     * @param[in] aType Message type.
     *
     * @return true on success, false otherwise.
     */
    virtual bool PostMsgToGfx(volt::util::ipc::MessageType aType)
    {
      return PostMsgToProc(GfxProcessID(), aType);
    }

    /**
     * Post a message to the graphics process with an associated data.
     *
     * The data given should be "flat" (no complex data types that require
     * dynamic memory allocation).
     *
     * @param[in] aType Message type.
     * @param[in] aData Data associated with the message.
     * @param[in] aSize Size of the data.
     *
     * @return true on success, false otherwise.
     */
    virtual bool PostMsgToGfx(volt::util::ipc::MessageType aType,
                              void *aData,
                              const size_t aSize)
    {
      return PostMsgToProc(GfxProcessID(), aType, aData, aSize);
    }

    /**
     * Execute a command on an application process.
     * This function blocks until the execution completes.
     * The supplied result handler will be called when the execution finishes.
     *
     * @param[in] aType Command type.
     * @param[in] aHandler Result handler.
     *
     * @return true on success, false otherwise.
     */
    virtual bool ExecuteOnApp(volt::util::ipc::MessageType aType,
                              volt::util::ipc::MessageCenter::ResultHandler aHandler)
    {
      return ExecuteOnProc(AppProcessID(), aType, aHandler);
    }

    /**
     * Execute a command on an application process with an associated data.
     * This function blocks until the execution completes.
     * The supplied result handler will be called when the execution finishes.
     *
     * The data given should be "flat" (no complex data types that require
     * dynamic memory allocation).
     *
     * @param[in] aType Command type.
     * @param[in] aHandler Result handler.
     * @param[in] aData Data associated with the message.
     * @param[in] aSize Size of the data.
     *
     * @return true on success, false otherwise.
     */
    virtual bool ExecuteOnApp(volt::util::ipc::MessageType aType,
                              volt::util::ipc::MessageCenter::ResultHandler aHandler,
                              void *aData,
                              const size_t aSize)
    {
      return ExecuteOnProc(AppProcessID(), aType, aHandler, aData, aSize);
    }

    /**
     * Execute a command on a worker process.
     * This function blocks until the execution completes.
     * The supplied result handler will be called when the execution finishes.
     *
     * @param[in] aID ID of the worker.
     * @param[in] aType Command type.
     * @param[in] aHandler Result handler.
     *
     * @return true on success, false otherwise.
     */
    virtual bool ExecuteOnWorker(const std::string &aID,
                                 volt::util::ipc::MessageType aType,
                                 volt::util::ipc::MessageCenter::ResultHandler aHandler)
    {
      return ExecuteOnProc(aID, aType, aHandler);
    }

    /**
     * Execute a command on a worker process with an associated data.
     * This function blocks until the execution completes.
     * The supplied result handler will be called when the execution finishes.
     *
     * The data given should be "flat" (no complex data types that require
     * dynamic memory allocation).
     *
     * @param[in] aID ID of the worker.
     * @param[in] aType Command type.
     * @param[in] aHandler Result handler.
     * @param[in] aData Data associated with the message.
     * @param[in] aSize Size of the data.
     *
     * @return true on success, false otherwise.
     */
    virtual bool ExecuteOnWorker(const std::string &aID,
                                 volt::util::ipc::MessageType aType,
                                 volt::util::ipc::MessageCenter::ResultHandler aHandler,
                                 void *aData, const size_t aSize)
    {
      return ExecuteOnProc(aID, aType, aHandler, aData, aSize);
    }

    /**
     * Execute a command on the graphics process.
     * This function blocks until the execution completes.
     * The supplied result handler will be called when the execution finishes.
     *
     * @param[in] aType Command type.
     * @param[in] aHandler Result handler.
     *
     * @return true on success, false otherwise.
     */
    virtual bool ExecuteOnGfx(volt::util::ipc::MessageType aType,
                              volt::util::ipc::MessageCenter::ResultHandler aHandler)
    {
      return ExecuteOnProc(GfxProcessID(), aType, aHandler);
    }

    /**
     * Execute a command on the graphics process with an associated data.
     * This function blocks until the execution completes.
     * The supplied result handler will be called when the execution finishes.
     *
     * The data given should be "flat" (no complex data types that require
     * dynamic memory allocation).
     *
     * @param[in] aType Command type.
     * @param[in] aHandler Result handler.
     * @param[in] aData Data associated with the message.
     * @param[in] aSize Size of the data.
     *
     * @return true on success, false otherwise.
     */
    virtual bool ExecuteOnGfx(volt::util::ipc::MessageType aType,
                              volt::util::ipc::MessageCenter::ResultHandler aHandler,
                              void *aData,
                              const size_t aSize)
    {
      return ExecuteOnProc(GfxProcessID(), aType, aHandler, aData, aSize);
    }
};

#endif
