#ifndef SAMSUNG_KINGSCANYON_CACHE_MANAGER_H
#define SAMSUNG_KINGSCANYON_CACHE_MANAGER_H

#include "IORequest.h"
#include "logger.h"
#include "MruBoostMultiIndex.h"

namespace Resource
{

class CacheManager
{
  public:
    static volt::util::Logger LOGGER;

  public:
    static CacheManager& Instance();

    std::string GetCachePath(const std::string &aKey) const;

    bool GetCachedResponse(IORequest::SharedPtr aRequest);

    bool TryCache(const IOResponse::SharedPtr aResponse);

    void RemoveCachedResponse(const std::string& cacheKey);

    void Flush();

    void SetMaxSize(std::size_t max_size);

    void CachedResponseAccessed(const IOResponse::SharedPtr aResponse);

    void SaveCatalog() const;

  private:
    CacheManager();
    ~CacheManager();

    class CachedItem
    {
      public:
        CachedItem() : sizeOnDisk_(0) {}
        CachedItem(const std::string& cacheKeyIn, std::size_t sizeOnDiskIn,
                   const std::string& uriIn) :
          cacheKey_(cacheKeyIn), sizeOnDisk_(sizeOnDiskIn), uri_(uriIn) {}

        bool isValid()
        {
          return uri_.length() && cacheKey_.length();
        }
        std::string getHash() const
        {
          return uri_;
        }
        std::size_t size() const
        {
          return sizeOnDisk_;
        }

      private:
        PROPERTY_CONST_REF(std::string, cacheKey);
        PROPERTY(std::size_t, sizeOnDisk);
        PROPERTY_CONST_REF(std::string, uri);

        /* serialization support */

        friend class boost::serialization::access;

        template<class Archive>
        void serialize(Archive& ar,const unsigned int)
        {
          LOG_DEBUG(LOGGER, "Serialize: " << uri());

          ar & cacheKey_;
          ar & sizeOnDisk_;
          ar & uri_;

          LOG_DEBUG(LOGGER, "CacheKey: " << cacheKey_);
          LOG_DEBUG(LOGGER, "SizeOnDisk: " << sizeOnDisk_);
          LOG_DEBUG(LOGGER, "Uri: " << uri_);
        }

    };

    // Cache Catalog
    mru_list<CachedItem> mru_cache;
};

} /* namespace Resource */

#endif
