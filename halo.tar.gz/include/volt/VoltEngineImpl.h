#pragma once

#include "VoltEngine.h"

#include <glib.h>

#include "logger.h"

class VoltEngineImpl : public VoltEngine
{
  public:
    static volt::util::Logger LOGGER;

  public:
    VoltEngineImpl();
    virtual ~VoltEngineImpl();

    /* From VoltEngine */
    virtual void SetDrmLicense(const std::string &aPath);
    virtual bool ParseOptions(int aArgc, char **aArgv);
    virtual bool Initialize(int aArgc, char **aArgv,
                            const ExternalData &aData);
    virtual bool Run();
    virtual void Cleanup();
    virtual void Quit();
    virtual bool ShouldReturnToPrevAppOnExit();

    virtual SceneRoot* GetSceneRoot() const;

    virtual void ShowUI(const VoltEventArgsMap &aData = VoltEventArgsMap());
    virtual void HideUI(const VoltEventArgsMap &aData = VoltEventArgsMap());
    virtual bool UIHidden() const;
    virtual void ResetApp(const VoltEventArgsMap &aData = VoltEventArgsMap());

    virtual uint8_t ProcessType() const;

  private:
    void ParseConfig(int aArgc, char **aArgv);
    void ApplyConfig(int aArgc, char **aArgv);

    static gboolean DoShowUI(gpointer aData);
    static gboolean DoHideUI(gpointer aData);
    static gboolean DoResetApp(gpointer aData);

  private:
    uint8_t process_type_;
    bool hidden_;

    typedef std::pair<VoltEngineImpl *, VoltEventArgsMap> InterthreadData;
};
