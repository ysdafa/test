/*
 * BlurEffect.h
 *
 *  Created on: Aug 6, 2013
 *      Author: Jim DiNunzio
 */

#ifndef BLUREFFECT_H
#define BLUREFFECT_H

#include "Widget.h"
#include "Effect.h"

class BlurEffect : public Effect
{
  public:
    BlurEffect()
    {
      setEffect(clutter_blur_effect_new());
    }
    virtual ~BlurEffect() {}
};

#endif // BLUREFFECT_H
