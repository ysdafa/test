/*
 * TextWidget.h
 *
 *  Created on: May 21, 2013
 *      Author: reza
 */

#ifndef TEXTWIDGET_H_
#define TEXTWIDGET_H_

#include <pango/pango.h>

#include "Widget.h"

namespace volt
{
namespace graphics
{
enum VerticalLayoutAlignment
{
  Top, Middle, Bottom
};

/**
 * A Widget that displays text.
 */
class TextWidget : public Widget
{
    /** The text this Widget displays */
    std::string text;

    ClutterActor* textActor;

    VerticalLayoutAlignment valign;

    static PangoFontDescription *defaultFontDescription;
    static PangoFontDescription *defaultAppFontDescription;

    Vector2 getTextSize() const;
    float getFontHeight() const;

    static void onResize(GObject* object, GParamSpec* paramSpec, gpointer data);

    void recalculateVerticalOffset();

  public:
    TextWidget( float x, float y, std::string text, std::string fontName, Widget* parent = nullptr, Color textColor = Color(255, 255, 255, 255));

    virtual ~TextWidget() {}

    virtual ClutterActor* getAnimationActor(AnimatableProperty);

    /** The text this Widget displays */
    std::string getText() const;
    void setText(const std::string& text);

    /** The font and font-size used by the text. eg: "Helvetica 10pt" */
    std::string getFontName() const;
    void setFontName(const std::string& fontName);

    /** The text color (not the background color) */
    Color getTextColor() const;
    void setTextColor(const Color& newColor);

    LayoutAlignment getHorizontalAlignment() const;
    void setHorizontalAlignment(LayoutAlignment);

    VerticalLayoutAlignment getVerticalAlignment() const
    {
      return valign;
    }
    void setVerticalAlignment(VerticalLayoutAlignment);

    bool getUseEllipses() const;
    void setUseEllipses(bool useEllipses);

    void setSingleLineMode(bool useSingleLineMode);
    bool getSingleLineMode() const;

    bool getJustifyText() const
    {
      return clutter_text_get_justify(CLUTTER_TEXT(textActor));
    }
    void setJustifyText(bool justify)
    {
      clutter_text_set_justify(CLUTTER_TEXT(textActor), justify);
    }

    int getLineSpacing() const;
    void setLineSpacing(int spacing);

    int getHeightInLines() const;
    void setHeightInLines(int lines);

    int charIndexAtCoordinate(Vector2) const;
    Vector2 coordinateAtCharIndex(int) const;

    float getLineHeight() const;

    float getTextOverflow() const;
    float getTextOverflowLines() const;

    void insertText(std::string text, int charIndex);
    void removeText(int charIndex, int length);
    void removeText(int charIndex);

    void setHasShadow(bool hasShadow);
    bool getHasShadow() const;

    void setShadowXOffset(float xOffset);
    float getShadowXOffset() const;

    void setShadowYOffset(float yOffset);
    float getShadowYOffset() const;

    void setShadowColor(const Color& color);
    Color getShadowColor() const;

    bool isRightToLeft() const;

    /**
     * Set the default font to be used by TextWidget.
     * @param[in] aFont Default font.
     */
    static void setDefaultFont(const std::string aFont);
    static void setDefaultAppFont(const std::string aFont);

    /**
     * Canonicalize the given font description.
     * This function may update the input font description with the
     * canonicalized description.  It may also update the font family to the
     * default set by setDefaultFont if necessary.
     *
     * @param[in] aFont Original font description.
     * @return Reference to aFont which would contain the canonicalized
     * description.
     */
    static std::string& canonicalizeFont(std::string &aFont);

};
};
};
#endif /* TEXTWIDGET_H_ */
