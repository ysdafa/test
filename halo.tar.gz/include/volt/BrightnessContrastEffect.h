/*
 * BrightnessContrastEffect.h
 *
 *  Created on: Aug 6, 2013
 *      Author: Jim DiNunzio
 */

#ifndef BRIGHTNESSCONTRASTEFFECT_H
#define BRIGHTNESSCONTRASTEFFECT_H

#include "Widget.h"
#include "Effect.h"

class BrightnessContrastEffect : public Effect
{
  public:
    static const char* BRIGHTNESS_TRANSITION_NAME;
    static const char* CONTRAST_TRANSITION_NAME;
    static const char* EFFECT_NAME;

    BrightnessContrastEffect();
    virtual ~BrightnessContrastEffect();

    void setBrightness(float brightness);
    float getBrightness() const;
    void setContrast(float contrast);
    float getContrast() const;
};

#endif // BRIGHTNESSCONTRASTEFFECT_H

