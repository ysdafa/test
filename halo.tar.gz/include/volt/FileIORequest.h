/*
 * FileIORequest.h
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#ifndef SAMSUNG_KINGSCANYON_FILE_IO_REQUEST_H
#define SAMSUNG_KINGSCANYON_FILE_IO_REQUEST_H

#include "IORequest.h"
#include "DirIORequest.h"
#include <event2/event.h>

#include "macros.h"

namespace Resource
{

/**
 * This class is responsible for handling file IO.
 */
class FileIORequest : public Resource::IORequest
{
  public:
    static const std::string LOGGER_NAME;

    typedef boost::shared_ptr<FileIORequest> SharedPtr;

    typedef bool (AllowedPathCheckFunc)(const char *);
    static AllowedPathCheckFunc *AllowedPathChecker;

  public:
    /**
     * Construct with path.
     * @param[in] aPath URL of the request.
     */
    FileIORequest(const std::string &aPath);
    virtual ~FileIORequest();

    /**
     * Normalize the URI/path to an absolute path.
     * If the normalized path is not contained within the root path, then this
     * function would return false.
     * All access to local file resource should first call this function to
     * make sure that the file can be accessed.  The path stored in
     * aNormalized should be used as the real path to the resource (this may
     * be different from what was originally in aUri).
     * Care should be taken if using this API from multiple threads as this is
     * not thread-safe yet.
     *
     * @param[in] aUri URI/path of the file.
     * @param[out] aNormalized Normalized path.
     * @return Bitmask of the permission flags (PERM_R, PERM_W).
     */
    static unsigned char NormalizePath(const std::string &aUri,
                                       std::string &aNormalized);

    // resolves uri to volt path and returns permission level
    // at that location. this works even when the path may not even
    // exist!
    static unsigned char VoltPath(const std::string &aUri,
                                  std::string &aVoltPath);

    // finds the first valid absolute path, if recursive is turned on
    // it will keep climbing up until the first valid path is found
    static std::string AbsoluteFilePath(const std::string &aPath);

    // utility function to write to a file
    static bool Write(const std::string &path, const char* data,
                      size_t length, std::string &reason);

    // utilty function to delete file at path
    static bool Delete(const std::string &path);

    static void SetLicensePath(const std::string &aPath);

    static const std::string& GetLicensePath();

    /**
     * Registers asynchronous event for this IO operation with libEvent.
     * @param[in] aEvent event_base of the event loop to use.
     * @return true on success, false otherwise.
     */
    bool RegisterEvent(struct event_base *aEventBase);

    /* Redfined virtuals */

    virtual void InitResponse();
    virtual bool Execute();
    virtual bool IsValid() const;

  private:
    bool ReadFile();
    bool ReadEncryptedFile();

    bool ExecuteDelete();
    bool ExecuteWrite();

    /**
     * Callback to be called by libEvent when an event is ready.
     * @param[in] aFd File desciptor (should be fd_).
     * @param[in] aEvent Type of event.
     * @param[in] aSelf Pointer to FileIORequest object.
     */
    static void EventCallback(int aFd, short aEvent, void *aSelf);

  private:
    volt::util::Logger logger_; /**< Logger. */

    int fd_; /** File descriptor of the file to be handled. */
    struct event *event_; /**< Pipe event. */

    bool is_valid_path_; /**< Flag for file validity. */

    PROPERTY_CONST_REF(std::string, path);

    unsigned char permission_;

    static std::string license_path_;
};

} /* namespace Resource */

#endif /* SAMSUNG_KINGSCANYON_FILE_IO_REQUEST_H */
