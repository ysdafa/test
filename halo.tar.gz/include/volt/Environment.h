/*
 * Environment.h
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#ifndef SAMSUNG_KINGSCANYON_ENVIRONMENT_H
#define SAMSUNG_KINGSCANYON_ENVIRONMENT_H

#include <string>

#include "macros.h"

namespace volt
{

/**
 * This class handles detection of the running environment.
 * For example, the class can be used to get the device information, current
 * CPU usage, available memory, etc.
 */
class Environment
{
  public:
    /* Supported device type. */
    enum DeviceType { kDeviceDefault,
                      kDeviceTV,
                      kDeviceBD,
                      kDevicePC,
                      kDeviceInvalid
                    };

    /**
     * Utility function to convert string to DeviceType enum.
     * @param[in] aType String representation of DeviceType.
     * @return DeviceType enum corresponding to aType.
     */
    static DeviceType StringToDeviceType(const std::string &aType);

    /**
     * Utility function DeviceType enum to convert string.
     * @param[in] aType DeviceType enum.
     * @return String representation corresponding to aType.
     */
    static const std::string& DeviceTypeToString(const DeviceType aType);

  public:
    Environment();
    ~Environment();

    /**
     * Detect and update device information.
     */
    void UpdateDeviceInfo();

  private:
    bool SaveDeviceInfoCache();
    bool LoadDeviceInfoCache();

  private:
    PROPERTY(DeviceType, device_type); /**< Device type. */
    PROPERTY_CONST_REF(std::string, device_code); /**< Device code. */

    PROPERTY_CONST_REF(std::string, cache_file); /**< Cache fil name */
};

} /* namespace volt */

#endif /* SAMSUNG_KINGSCANYON_ENVIRONMENT_H */
