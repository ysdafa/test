#ifndef VOLT_PROCESS_RUNTIME_H
#define VOLT_PROCESS_RUNTIME_H

#include "VoltProcessManager.h"

#ifdef BUILD_FOR_TV
#include "CSefPluginWrapper.h"
#endif

class VoltProcessRuntime : public IVoltProcessRuntime
{
  public:
    VoltProcessRuntime();
    virtual ~VoltProcessRuntime();

    static void GetScreenDimensions(int &aWidth, int &aHeight,
                                    int &aWindowWidth, int &aWindowHeight,
                                    float &aScaleX, float &aScaleY);

    static void ChangeScreenResolution(const int aWidth, const int aHeight);

    static void GetTimeOfDay(struct timeval &aResult);

#if defined(BUILD_FOR_TV) && defined(BUILD_EMP)
    /** Class to call API's of other plugin's via SEF. */
    class SimpleSefClient : public sef::CSefPluginWrapper
    {
      public:
        SimpleSefClient() : CSefPluginWrapper(sef::CClientAppFactory::SEF_CLIENT_WEBKIT)
        {
        }

        virtual ~SimpleSefClient()
        {
        }

        virtual bool OnEvent(int, string, string)
        {
          /* Don't care... */
          return true;
        }
    };
#endif

    virtual void RegisterEventHandlers(const VoltEngine::EventHandlers &Handlers);

    /* From IVoltProcessRuntime */
    virtual bool Initialize(int aArgc, char **aArgv,
                            const VoltEngine::ExternalData &aDAta);
  protected:
    static time_t GetTimeOffset();

  protected:
    VoltEngine::EventHandlers event_handlers_;
};

#endif
