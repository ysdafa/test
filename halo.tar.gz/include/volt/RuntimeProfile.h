/*
 * RuntimeProfile.h
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#ifndef SAMSUNG_KINGSCANYON_RUNTIME_PROFILE_H
#define SAMSUNG_KINGSCANYON_RUNTIME_PROFILE_H

#include <boost/program_options.hpp>

#include "Environment.h"
#include "macros.h"

namespace volt
{

/**
 * This class is responsible managing runtime performance profiles.
 * A profile is a set of key-value pair defining various runtime
 * attributes/properties of VOLT.
 * For example, a profile for BDP can limit the animation framerate to 10.
 */
class RuntimeProfile
{
  public:
    RuntimeProfile();
    ~RuntimeProfile();

    /**
     * Set profile based on the running device.
     * @param[in] aDeviceType Type of device (eg TV).
     * @param[in] aDeviceCode Code unique to each device.
     */
    void SetDeviceProfile(const Environment::DeviceType aDeviceType,
                          const std::string &aDeviceCode);

  private:
    /** Supported profile options. */
    boost::program_options::options_description profile_options_;
    /** Parsed profile definition. */
    boost::program_options::variables_map profile_;

    PROPERTY_RO(int, target_fps); /**< Target FPS. */
    PROPERTY_RO(int, max_cache_size); /**< Max cache size. */
};

} /* namespace volt */

#endif /* SAMSUNG_KINGSCANYON_RUNTIME_PROFILE_H */
