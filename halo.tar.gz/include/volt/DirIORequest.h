/*
 * DirIORequest.h
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#ifndef SAMSUNG_KINGSCANYON_DIRECTORY_IO_REQUEST_H
#define SAMSUNG_KINGSCANYON_DIRECTORY_IO_REQUEST_H

#include "IORequest.h"

#include <event2/event.h>

#include "macros.h"

namespace Resource
{

/* File permission bits. */
enum
{
  PERM_NO_ACCESS = 0,
  PERM_W = 2,
  PERM_R = 4
};

struct FileInfo
{
  FileInfo(std::string aName, int aSize = -1);

  std::string name;
  int size;
};

struct DirInfo
{
  DirInfo(std::string aName);

  std::string name;
  std::vector<DirInfo> directories;
  std::vector<FileInfo> files;
};

/**
 * This class is responsible for handling file IO.
 */
class DirIORequest : public Resource::IORequest
{
  public:

    static const std::string LOGGER_NAME;

    typedef boost::shared_ptr<DirIORequest> SharedPtr;

    static bool Create(const std::string &aPath, bool recursive = true);

    static bool Read(DirInfo &info, const std::string &parentPath, bool recursive = false);

    static bool Delete(const std::string &aPath, bool recursive = false);

    static bool IsDirectory(std::string &path);

    static std::string GetParentPath(std::string &path);

  public:
    /**
     * Construct with path.
     * @param[in] aPath URL of the request.
     */
    DirIORequest(const std::string &aPath);
    virtual ~DirIORequest();

    /* Redfined virtuals */
    virtual void InitResponse();
    virtual bool Execute();
    virtual bool IsValid() const;

    const DirInfo *GetDirectoryInfo() const;

  private:
    bool ExecuteCreate();
    bool ExecuteDelete();
    bool ExecuteRead();

    volt::util::Logger logger_; /**< Logger. */

    bool is_valid_path_; /**< Flag for file validity. */

    PROPERTY_CONST_REF(std::string, path);

    unsigned char permission_;

    DirInfo info_;
};

} /* namespace Resource */

#endif /* SAMSUNG_KINGSCANYON_DIRECTORY_IO_REQUEST_H */
