/*
 * FirstScreenListWidget.h
 *
 *  Created on: Jul 29, 2013
 *      Author: reza
 */

#ifndef FIRSTSCREENLISTWIDGET_H_
#define FIRSTSCREENLISTWIDGET_H_

#include "Widget.h"
#include "logger.h"
#include "ScriptBridge.h"
#include <vector>

using namespace Bridge;

/*
 * Abstract Base class of all Widgets which impose positioning on their children
 */

namespace volt
{
namespace graphics
{

class FirstScreenListItem 
{
public:
	ClutterActor* container;
	ClutterActor* mainImage;
	ClutterActor* titleBox;
	ClutterActor* title1;
	ClutterActor* title2;
	ClutterActor* iconBox;
	ClutterActor* icon1;
	ClutterActor* icon2;
	ClutterActor* icon3;
	ClutterActor* icon4;
	ClutterActor* icon5;
	ClutterActor* border;
};

class FirstScreenCategory 
{
public:
	ClutterActor* categoryWrapper;
	ClutterActor* categoryTitle;
	ClutterActor* listWrapper;
	ClutterActor* color;
	ClutterActor* liveParent1;
	ClutterActor* liveParent2;
	ClutterActor* post1;
	ClutterActor* post2;
	ClutterActor* post3;
	ClutterActor* post4;
	ClutterActor* post5;
	ClutterActor* post6;
};

class FirstScreenContents
{
public:
	ClutterActor* contentsWrapper;
	ClutterActor* dominant;
	ClutterActor* titleParent;
	ClutterActor* main;
	ClutterActor* overRay;
	ClutterActor* normalTitle;
	ClutterActor* focusTitle;
	Color dominantColor;
	int index;
	std::string categoryType;
};

class FirstScreenListWidget : public Widget
{
public:
	FirstScreenListWidget(Widget* parent);
    virtual ~FirstScreenListWidget() {}

	//void createCategory(FirstScreenCategory* Item, ClutterActor* parent);
	void createChild(FirstScreenCategory* Item);
	void createContents(FirstScreenContents* Item);
	
	void removeCategory(int categoryIndex);
	void removeContents(int categoryIndex, int contentsIndex);
	
	int addItem(FirstScreenListItem* item);

	int size();
	int clear();

	int getSelectedItemPos();

	void sendKeyEvent(int keyType, int keyCode);
	void startAnimation();
	void stopAnimation();
	
	void setOnItemSelectedListener(ScriptFunction callback);
	void setOnItemLongPressedListener(ScriptFunction callback);
	void setOnItemChangedListener(ScriptFunction callback);

public:
	ScriptFunction onItemSelectedListener;
	ScriptFunction onItemLongPressedListener;
	ScriptFunction onItemChangedListener;
};

} /* namespace Bridge */
}
#endif /* FIRSTSCREENLISTWIDGET_H_ */
