/*
 * Effect.h
 *
 *  Created on: Jun 27, 2013
 *      Author: reza
 */

#ifndef EFFECT_H_
#define EFFECT_H_

#include <clutter/clutter.h>

/**
 * Base class of all effects. An effect modifies the way an Widget is drawn in some way
 */
class Effect
{

    friend class Widget;

  private:
    ClutterEffect* effect;

  protected:
    void setEffect(ClutterEffect* effectIn)
    {
      if (effect)
      {
        g_object_unref(effect);
      }

      effect = effectIn;
    }

  public:
    Effect() :effect(nullptr) {};
    virtual ~Effect() {}

    virtual ClutterEffect* getEffect() const
    {
      return effect;
    }
    void enable()
    {
      clutter_actor_meta_set_enabled(CLUTTER_ACTOR_META(getEffect()), true);
    }
    void disable()
    {
      clutter_actor_meta_set_enabled(CLUTTER_ACTOR_META(getEffect()), false);
    }
};

#endif /* EFFECT_H_ */
