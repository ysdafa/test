/*
 * FrameWidget.h
 *
 *  Created on: Jul 29, 2013
 *      Author: reza
 */

#ifndef FRAMEWIDGET_H_
#define FRAMEWIDGET_H_

#include "LayoutWidget.h"

namespace volt
{
namespace graphics
{

/**
 * A widget layout used for centering or justifying things
 */
class FrameWidget : public LayoutWidget
{
  public:


    FrameWidget( float x, float y, float width, float height, Widget* parent,
                 LayoutOrientation aOrientation = Horizontal,
                 LayoutAlignment aAlignX = Center, LayoutAlignment aAlignY = Center);

    virtual ~FrameWidget() {}


    /** Get the orientation of this Layout, either horizontal or vertical */
    LayoutOrientation getOrientation() const
    {
      return orientation;
    }

    /** Sets the orientation of this Layout to either horizontal or vertical */
    void setOrientation(LayoutOrientation);

    /** Get the horizontal alignment of children widgets. */
    LayoutAlignment getAlignX() const
    {
      return alignX;
    }

    /** Set the horizontal alignment of children widgets. */
    void setAlignX(LayoutAlignment);

    /** Get the vertical alignment of children widgets. */
    LayoutAlignment getAlignY() const
    {
      return alignY;
    }

    /** Set the vertical alignment of children widgets. */
    void setAlignY(LayoutAlignment);

    /**  Add a child widget. The child Widget's x and y properties will be taken over by this Layout.
     * @param[in] child The Widget to add to Layout
     * @param[in] index Optional. The index to put the new child in (shifting other children about as needed. Child-index determines
     * draw order. If not provided the child is added as the last child.
     * @return The index at which the child was added.*/
    virtual int addChild(Widget* child, int index = -1);

    /** Remove the widget at the given index from the children list. */
    virtual void removeChild(Widget* target);

  private:

    static void setAlignment(ClutterActor* actor, LayoutAlignment alignmentX, LayoutAlignment alignmentY);

    LayoutAlignment alignX;
    LayoutAlignment alignY;
};
};
};

#endif /* FRAMEWIDGET_H_ */
