#ifndef VOLT_EMP_ENGINE_VOLT_H
#define VOLT_EMP_ENGINE_VOLT_H

#include <thread>

#include "EmpApp.h"
#include "EmpEngine.h"
#include "logger.h"

#include "Volt.h"

namespace sef
{

class EmpEngineVolt : public CEmpEngineBase
{
  public:
    static std::string LOGGER_NAME;

  public:
    EmpEngineVolt();
    virtual ~EmpEngineVolt();

    /**
     * Volt thread entry point.
     */
    void operator()();

    /* From CEmpEngineBase */
    virtual bool Execute(std::string &aReturn,
                         const std::string &aCmd,
                         const std::string &aParam1,
                         const std::string &aParam2,
                         const std::string &aParam3,
                         const std::string &aParam4);

    virtual bool ExecuteWithParamList(std::string &aReturn,
                                      const std::string &aCmd,
                                      const ParamList &aParams);
  private:
    void SendExitEvent();
    bool MountWidgetImage();

  private:
    static std::string volt_app_data_base_path_;

  private:
    volt::util::Logger logger_; /**< Logger. */
    std::string log_level_; /**< Initial log level. */
    std::string volt_app_id_; /**< Application ID. */
    std::string volt_app_path_; /**< Path to the Volt app JS. */
    std::string volt_app_data_path_; /**< Path to write/read app data. */
    std::string volt_app_name_; /**< Name of the Volt app JS. */
    std::string volt_app_icon_path_; /**< Path to the Volt app icon. */
    std::string volt_app_width_; /**< App width */
    std::string volt_app_height_; /**< App height */
    std::vector<char *> volt_options_; /**< Volt config flags. */
    std::thread thread_; /**< Handle for Volt thread. */

    VoltEngine *engine_;
};

} /* namespace sef */

#endif
