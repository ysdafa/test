#ifndef __ANIMATION_SPEC_H_INCL__
#define __ANIMATION_SPEC_H_INCL__

#include <clutter/clutter.h>
#include <string>
#include <map>
#include <vector>
#include "Widget.h"
#include "WidgetUtilities.h"

namespace volt
{
namespace graphics
{

/** Simple Bezier curve definition with two 2D control points */
struct BezierCurve
{
  Vector2 control1;
  Vector2 control2;

  BezierCurve() : control1(), control2() {}
};

/**
Structure representing an animation of a single property.
*/
class AnimationSpec
{

  public:

    //Keyframe data kept in parallel sorted lists. This is format they will be needed in to apply to an actor
    std::vector<double> keys;
    std::vector<GValue> values;
    std::vector<ClutterAnimationMode> tweenModes;
    std::vector<bool> relativeKeyFlags;
    BezierCurve customTweeningCurve;

    AnimatableProperty property;

    WidgetPropertyType type;

    bool useKeys, hasRelativeKeys;

    AnimationSpec() : property(InvalidAnimation), type(Byte), useKeys(false), hasRelativeKeys(false) {};
    AnimationSpec(AnimatableProperty aprop, WidgetPropertyType atype) : property(aprop), type(atype), useKeys(false), hasRelativeKeys(false) {}

    void addKey(double key, TweenMode tweenMode, const GValue& value, bool isRelative = false);

    void setBezierCurve(const BezierCurve&);

    ClutterTransition* getTransition(Widget* widget, bool isAnimatingRoundedCorners) const;

    static const char* voltAnimatableToClutter(AnimatableProperty voltProperty);

    const char* getClutterPropertyName() const
    {
      return voltAnimatableToClutter(property);
    }


  private:

    ClutterTransition* createTransition(AnimatableProperty property, bool makeInt, const std::vector<GValue>& keyValues,
                                        ClutterActor* actor, WidgetPropertyType animType ) const;
    ClutterTransition* createColorTransition(AnimatableProperty property, Color color, int rgba, ClutterActor* actor) const;
    ClutterTransition* createVector2Transition(AnimatableProperty property, Vector2 vec, bool isY, ClutterActor* actor) const;
    GValue getActorRelativeValue(ClutterActor* actor, const char* prop, WidgetPropertyType animType, GValue offset) const;

};
};
};

#endif // __ANIMATION_SPEC_H_INCL__

