/*
 * IOManager.h
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#ifndef SAMSUNG_KINGSCANYON_NETWORK_IO_REQUEST_H
#define SAMSUNG_KINGSCANYON_NETWORK_IO_REQUEST_H

#include <boost/serialization/base_object.hpp>
#include <curl/curl.h>

#include "IORequest.h"
#include "logger.h"

namespace Resource
{

class NetworkIORequest;

class NetworkIOResponse : public Resource::IOResponse
{
  public:
    static volt::util::Logger LOGGER;

    typedef boost::shared_ptr<NetworkIOResponse> SharedPtr;

  public:
    NetworkIOResponse();
    NetworkIOResponse(const NetworkIORequest &aRequest);
    virtual ~NetworkIOResponse();

    /**
     * Handle received header.
     * @param[in] aBuffer Buffer with header.
     * @param[in] aSize Size of aBuffer.
     * @return aSize on sucess.
     */
    size_t ParseHeader(const char *aBuffer, size_t aSize,
                       NetworkIOResponse::SharedPtr response);

    /* Redfined virtuals */
    virtual bool IsCacheable() const;
    virtual bool IsExpired() const;

    template<class Archive>
    void serialize(Archive &aArchive, const unsigned int aVersion)
    {
      LOG_DEBUG(LOGGER, "Serialize: " << uri());
      LOG_DEBUG(LOGGER, "Version: " << aVersion);

      /* Serialize base class first */
      aArchive & boost::serialization::base_object<IOResponse>(*this);

      aArchive & is_cacheable_;
      aArchive & date_;
      aArchive & max_age_;
      aArchive & expires_;
      aArchive & last_modified_;
      aArchive & etag_;

      LOG_DEBUG(LOGGER, "Cacheable: " << (is_cacheable_ ? "true" : "false"));
      LOG_DEBUG(LOGGER, "Date: " << date_);
      LOG_DEBUG(LOGGER, "Max-Age: " << max_age_);
      LOG_DEBUG(LOGGER, "Expires: " << expires_);
      LOG_DEBUG(LOGGER, "Last-Modified: " << last_modified_);
      LOG_DEBUG(LOGGER, "Etag: " << etag_);
    }

  private:
    PROPERTY(bool, is_cacheable);
    PROPERTY(volt::util::Time, date);
    PROPERTY(volt::util::Time, max_age);
    PROPERTY(volt::util::Time, expires);
    PROPERTY(volt::util::Time, last_modified);
    PROPERTY_REF(std::string, etag);
};

/**
 * This class holds the data and callbacks to handle single HTTP transaction.
 */
class NetworkIORequest : public Resource::IORequest
{
  public:
    typedef boost::shared_ptr<NetworkIORequest> SharedPtr;

  public:
    /**
     * Construct with URL.
     * @param[in] aUrl URL of the request.
     */
    NetworkIORequest(const std::string &aUrl);
    virtual ~NetworkIORequest();

    CURL* curl_handle() const;

    /* Redefined virtuals */

    virtual bool Execute();

    /**
     * Callback registered with curl for header events.
     * @param[in] aBuffer Buffer with header data.
     * @param[in] aSize Size of each data member.
     * @arapm[in] aNumMemb Number of data members.
     * @param[in] aSelf Pointer to NetworkIORequest object.
     * @return aSize * aNumMemb on sucess.
     */
    static size_t HeaderCallback(void *aBuffer, size_t aSize, size_t aNumMemb,
                                 void *aSelf);

    /**
     * Callback registered with curl for data events.
     * @param[in] aBuffer Buffer with data.
     * @param[in] aSize Size of each data member.
     * @arapm[in] aNumMemb Number of data members.
     * @param[in] aSelf Pointer to NetworkIORequest object.
     * @return aSize * aNumMemb on sucess.
     */
    static size_t DataCallback(void *aBuffer, size_t aSize, size_t aNumMemb,
                               void *aSelf);

    /**
     * Print the stats for the completed request (eg total time).
     */
    void PrintStats() const;

    virtual void InitResponse();
    virtual bool ValidateCachedResponseBeforeRequest();
    virtual bool ValidateCachedResponseAfterRequest();
    virtual void SetHeaders(const ResourceRequest::HeaderList &aHeaders);
    virtual void Finalize();
    virtual void FinalizeResponse();
    virtual bool IsValid() const;
    virtual bool ShouldCacheResponse() const;

    /**
     * Initialize shared state required to maintain single state for cookies.
     * This MUST be called before any of the network request is made.
     */
    static void InitSharedState();
    /**
     * Clean the shared state.
     * This MUST be called after all internal CURL handles are freeed (ie
     * after NetworkIORequest objects are destroyed.)
     */
    static void CleanSharedState();

  private:
    CURL *curl_handle_; /**< Handle used by curl. */
    struct curl_slist *headers_;
    FILE *file_; /* Used for PUT method. */

    char error_buf_[CURL_ERROR_SIZE];
};

} /* namespace Resource */

#endif /* SAMSUNG_KINGSCANYON_NETWORK_IO_REQUEST_H */
