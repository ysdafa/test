#pragma once

/* Include all headers for the Volt library */
#include "Version.h"
#include "VoltEventArgs.h"
#include "VoltEngine.h"

typedef void(*funcP)();
typedef void(*funcP2)(void*);

extern void* GetMainStage();
extern void RegisterPluginBridge(Bridge::ScriptBridge*);
