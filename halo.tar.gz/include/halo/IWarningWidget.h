#ifndef _IWARNINGWIDGET_H_
#define _IWARNINGWIDGET_H_
#define WARNING_DISPLAY_TIME 3000

namespace HALO
{
	class HALO_API IWarningWidget : virtual public IDefaultWindow
	{
	public:
		enum E_WARNING_TYPE
		{
			WARNING_WITH_LOADING = 0,		//!< warning widget with loading type.
			WARNING_WITHOUT_LOADING = 1,	//!< warning widget without loading type.
		};

		typedef struct T_WARNINGWIDGET_ATTR
		{
			int timer;					//!< the timer value.
			const char* pMessage;		//!< the text.
			E_WARNING_TYPE waringtype ;	//!< the warning widget type.
		}TWarningWidgetAttr;
	public:
		/*!
		\brief               Create a new warning widget
		\param               parent:[in] The parent of warning widget. 
		\param               attr:[in] The warning widget attribute. 
		\return              HALO::IWarningWidget *: A pointer to new Warning widget
		*/
		static IWarningWidget* CreateInstance(IActor* parent, const TWarningWidgetAttr &attr);
	public:
		/*!
		\brief               Show the warning widget.
		\return              None
		*/
		virtual void Show() = 0;
		/*!
		\brief               Set warning widget timer.
		\param               nTimer:[in] The setting timer. 
		\return              None
		*/
		virtual void SetTimer(int nTimer) = 0;
		/*!
		\brief               Hide the warning widget.
		\return              None
		*/
		virtual void Hide( void ) = 0;
		/*!
		\brief               Set the text which will show by warning widget.
		\param               pMessage:[in] The text which will be shown. 
		\return              None
		*/
		virtual void SetMessageText(const char* pMessage) = 0;
		/*!
		\brief               Set the text color
		\param               textcolor:[in] The color which will be set by text. 
		\return              None
		*/
		virtual void SetMessageTextColor(const ClutterColor textcolor) = 0;
	};
}
#endif