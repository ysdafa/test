#ifndef _HALLO_IBUTTON_H_
#define _HALLO_IBUTTON_H_

namespace HALO
{
	class HALO_API IButtonListener : public IListener
	{
	public:
		enum EButtonClickType
		{
			TYPE_MOUSE = 0,
			TYPE_RETRUN_KEY,

			TYPE_MAX,
		};
		//! Button clicked listener 
		virtual bool OnButtonClicked(class IButton* button, EButtonClickType type) { return false; }
	};

	class HALO_API IButton : virtual public IActor
	{
	public:
		enum EButtonState
		{
			STATE_NORMAL = 0,				//!< State normal 
			STATE_FOCUSED,					//!< State focused 
			STATE_SELECTED,					//!< State selected(mouse pressed or return key pressed) 
			STATE_ROLL_OVER,				//!< State Roll over 
			STATE_FOCUSED_ROLL_OVER,		//!< State focused and Roll over 
			STATE_DISABLED,					//!< State disabled by function Enable(false)
			STATE_DISABLED_FOCUSED,			//!< disabled and focused
			STATE_ALL						//!< state for setting all state at once.
		};

	public:
		/*!
		\brief               Create an instance of button
		\remarks             If parent is NULL, this button will be a child of the Stage. The parent is not recommended to be NULL.
		\param               parent:[in] The parent of this button.
		\param               width: [in] The width of the button.
		\param               height:[in] The height of the button.
		\return              HALO::IButton *: The newly created button.
		\see
		*/
		static IButton* CreateInstance(IActor* parent, float width, float height);

	public:

		virtual void SetBackgroundColor(EButtonState state, const ClutterColor& color) = 0;
		virtual const ClutterColor& BackgroundColor(EButtonState state) = 0;

		virtual void SetBorderColor(EButtonState state, const ClutterColor& color) = 0;
		virtual const ClutterColor& BorderColor(EButtonState state) = 0;

		virtual void SetBorderWidth(EButtonState state, float width) = 0;
		virtual float BorderWidth(EButtonState state) = 0;

		virtual void SetIconImage(EButtonState state, const std::string& iconPath) = 0;
		virtual const std::string& IconImage(EButtonState state) = 0;

		virtual void SetIconAlpha(EButtonState state, int alpha) = 0;
		virtual int IconAlpha(EButtonState state) = 0;
		/*!
		\brief:   Sets image buffer for a specific(or all) state                                                        
		\param:   EButtonState state		 [in] Button State for which image buffer needs to be set
		\param:   IImageBuffer * imageBuffer [in] Image buffer to be set
		\return:  void    
		\see:     ImageBuffer 
		*/
		virtual void SetBackgroundImage(EButtonState state, const std::string& imagePath) = 0;

		/*!
		\brief:   Get image buffer for a state                                                         
		\param:   EButtonState state [in] Button State for which image buffer needs to be obtained
		\return:  IImageBuffer*:   Image buffer for the input state 
		\see:     SetImage
		*/
		virtual const std::string& BackgroundImage(EButtonState state) = 0;

		/*!
		\brief:   Sets text string for a specific(or all) state                                                            
		\param:   EButtonState state 	[in] Button State for which text string needs to be set
		\param:   const char * text		[in] Text string to be set
		\return:  void:   
		\see:	  Text                                                                   
		*/
		virtual void SetText(EButtonState state, const std::string& text) = 0;

		/*!
		\brief:   Gets text string for a state                                                     
		\param:   EButtonState state [in] Button State for which text string needs to be obtained
		\return:  const char*:   Text string for the input state
		\see:	  SetText                                                                     
		*/
		virtual const std::string& Text(EButtonState state) = 0;

		/*!
		\brief:   Sets text color for a specific(or all) state                                                            
		\param:   EButtonState state       [in] Button State for which text color needs to be set
		\param:   const ClutterColor color [in] Text color to be set
		\return:  void   
		\see:     TextColor                                                             
		*/
		virtual void SetTextColor(EButtonState state, const ClutterColor& color) = 0;

		/*!
		\brief:   Gets text color for a state                                                           
		\param:   EButtonState state	[in] Button State for which text color needs to be obtained
		\return:  const ClutterColor&:  Text color for the input state 
		\see:     SetTextColor                                                                 
		*/
		virtual const ClutterColor& TextColor(EButtonState state) = 0;

		/*!
		\brief:   Sets text font for a specific(or all) state                                                        
		\param:   EButtonState state [in] Button State for which text font needs to be set
		\param:   char * font		 [in] Text font to be set
		\return:  void:   
		\see:     TextFont                                                              
		*/
		virtual void SetFontSize(EButtonState state, int fontSize) = 0;
		
		/*!
		\brief:   Gets text font for a state
		\param:   EButtonState state	[in] Button State for which text font needs to be obtained
		\return:  const ClutterColor&:  Text font for the input state
		\see:     SetTextFont
		*/
		virtual int FontSize(EButtonState state) = 0;

		/*!
		\brief:   Get IText actor instance                                
		\remarks: 	
			A button class has a IText instance as a member.\n
			If an user wants to add some animations or change properties of the text drawing,\n
			user can get the IText instance by using this function.\n
			IButton class doesn't have any function to change the IText.\n
			Users have to apply their modification themselves through this function.\n
		\param:   void
		\return:  IText*:   IText instance that is a member of button class.                                    
		\see:     ImageActor                       
		*/
		virtual IText* TextActor(void) = 0;

		/*!
		\brief:   Get IImage actor instance
		\remarks:
		A button class has a IImage instance as a member.\n
		If an user wants to add some animations or change properties of the image drawing,\n
		user can get the IImage instance by using this function.\n
		IButton class doesn't have any function to change the IImage.\n
		Users have to apply their modification themselves through this function.\n
		\param:   void
		\return:  IImage*:   IImage instance that is a member of button class.
		\see:     TextActor
		*/
		virtual IImage* IconActor(void) = 0;

		virtual ICompositeImage* BackGroundImageActor(void) = 0;

		virtual bool AddListener(IButtonListener* listener) = 0;

		virtual bool RemoveListener(IButtonListener* listener) = 0;
	};
}

#endif
