#ifndef _HALO_H_
#define _HALO_H_

#if 0
#define PRINT(...) printf(__VA_ARGS__)
#else
#define PRINT(...)
#endif

#ifndef ASSERT
#define ASSERT(expr) g_assert(expr)
#endif

#ifdef WIN32
#define HALO_API __declspec(dllexport)
//#include <vld.h>
//#define USE_DBUS
#else
#define HALO_API
#define USE_DBUS
#define USE_DLOG
#endif

#include <stdio.h>
#include <stdlib.h>
#include <set>
#include <string.h>
#include <vector>
#include <map>
#include <list>
#include <math.h>
#include <cogl/cogl.h>
#include <cogl-pango/cogl-pango.h>
#include <clutter/clutter.h>

#include "Lib.h"
#include "IDataType.h"
#include "IListener.h"

//VOLT
#include "Widget.h"
#include "TextWidget.h"
#include "ImageWidget.h"
#include "Animation.h"
#include "SceneRoot.h"
#include "VoltFullProcessRuntime.h"

#ifndef WIN32
using namespace volt::graphics;
#endif

//UTIL
#include "IUtility.h"
#include "ILogger.h"

//GWES
#include "IAction.h"
#include "IEvent.h"
#include "ISerializable.h"
#include "IEventManager.h"
#include "IListener.h"
#include "IDevice.h"
#include "IAnimation.h"
#include "ILayout.h"
#include "IEffect.h"
#include "IActor.h"
#include "IStage.h"
#include "IDimWindow.h"
#include "IDeviceManager.h"
#include "IThreadPool.h"
#include "IAsyncTask.h"

//Controls
#include "IImageBuffer.h"
#include "IText.h"
#include "IImage.h"
#include "ICompositeImage.h"
#include "IMultiImage.h"
#include "IButton.h"
#include "IThumbnail.h"
#include "IDataSource.h"
#include "IRendererProvider.h"
#include "IDataListControl.h"
#include "ISingleLineListControl.h"
#include "IGridListControl.h"
#include "IFirstScreenListControl.h"
#include "IMatrixListControl.h"
#include "ILabel.h"
#include "IRectangle.h"
#include "IPageControl.h"
#include "IProgress.h"
#include "IScroll.h"
#include "ISlider.h"
#include "IRichText.h"
#include "ISelectButton.h"
#include "ISelectButtonGroup.h"
#include "IToggleButton.h"
#include "ICategoryTab.h"
#include "IListItem.h"
#include "IToolTip.h"
#include "ILoading.h"
#include "IVideoActor.h"

//Widgets
#include "IActionPopup.h"
#include "IDefaultWindow.h"
#include "IMessageBox.h"
#include "IWarningWidget.h"
#include "IWizardWidget.h"
#include "ISpinButton.h"
#include "IPopupRating.h"
#include "IPinPopup.h"
#include "IInputBox.h"

namespace HALO
{
	//! Halo versions
	enum HALO_API EHaloVersion
	{
		HALO_VERSION_1_0,		//!< Halo verion 1.0
		HALO_VERSION_LATEST		//!< The lastest halo version
	};

	/*!
	\brief:			Initialize the Halo
	\remarks:		Internally calls the Initialize(NULL, NULL, version).
	\param:			EHaloVersion version, [in] The version of Halo want to be initialized.
	\return:		true: success, false: failed.
	\par Example:	
	\code       
					int main(int argc, char **argv)
					{
						HALO::Initialize();

						//initialize your UI here.

						HALO::Main();
						HALO::Finalize();
						return true;
					}
	\endcode       
	\see:			bool HALO_API Initialize(int aArgc, char **aArgv, EHaloVersion version = HALO_VERSION_LATEST)
	*/
	bool HALO_API Initialize(EHaloVersion version = HALO_VERSION_LATEST);
	
	/*!
	\brief:			Initialize the Halo
	\remarks:		clutter is initialized here
	\param:			int aArgc, [in] directly passed to clutter_init(&argc, &argv)
	\param:			char **aArgv, [in] directly passed to clutter_init(&argc, &argv)
	\param:			EHaloVersion version, [in] The version of Halo want to be initialized.
	\return:		true: success, false: failed.
	\par Example:	
	\code       
					int main(int argc, char **argv)
					{
						HALO::Initialize(argc, argv, HALO::HALO_VERSION_1_0);

						//initialize your UI here.

						HALO::Main();
						HALO::Finalize();
						return true;
					}
	\endcode       
	\see:			bool HALO_API Initialize(int aArgc, char **aArgv, EHaloVersion version = HALO_VERSION_LATEST)
	\note:			In Linux environment, this function with argc & argv need to be called, otherwise clutter will fail to init.
	*/
	bool HALO_API Initialize(int aArgc, char **aArgv, EHaloVersion version = HALO_VERSION_LATEST);

	/*!
	\brief:			Run the main loop
	\remarks:		Run clutter main loop inside
	\param:			void
	\return:		void
	\see:			bool HALO_API Initialize(EHaloVersion version = HALO_VERSION_LATEST);
					bool HALO_API Initialize(int aArgc, char **aArgv, EHaloVersion version = HALO_VERSION_LATEST);
	\note:			
	*/
	void HALO_API Main(void);
	
	/*!
	\brief:			Release the resources inside Halo
	\remarks:		Should be called after quit the main loop. Normally just behind HALO::Main.
	\param:			void
	\return:		void
	\see:			bool HALO_API Initialize(EHaloVersion version = HALO_VERSION_LATEST);
					bool HALO_API Initialize(int aArgc, char **aArgv, EHaloVersion version = HALO_VERSION_LATEST);
	\note:			
	*/
	void HALO_API Finalize(void);

	/*!
	\brief:			Get the current initialized Halo version
	\param:			void
	\return:		EHaloVersion, the Halo version is returned.
	\see:			bool HALO_API Initialize(EHaloVersion version = HALO_VERSION_LATEST);
					bool HALO_API Initialize(int aArgc, char **aArgv, EHaloVersion version = HALO_VERSION_LATEST);
	\note:			
	*/
	EHaloVersion HALO_API Version(void);

	void HALO_API PreInitialize(void);
};

#endif
