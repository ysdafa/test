#ifndef _ISINGLELINELISTCONTROL_H_
#define _ISINGLELINELISTCONTROL_H_

namespace HALO
{
	class HALO_API ISingleLineListControlListener : public IListener
	{
	public:
/*!
\brief               The sync data load callback.
\remarks             When ISingleLineListControl need to load data by sync type, it will notify user by this callback function.
\param               list: [in] The pointer of control. 
\param               data: [in] The data which need to load. 
\param               itemIndex: [in] The data's index of whole data. 
\return              bool: True means load success, false means fail.
\note                N/A
*/
		virtual bool OnItemLoaded(class ISingleLineListControl* list, IData *data, int itemIndex)   { return false; }

/*!
\brief               The data unload callback.
\remarks             When ISingleLineListControl need to unload data, it will notify user by this callback function.
\param               list: [in] The pointer of control. 
\param               data: [in] The data which need to unload. 
\param               itemIndex: [in] The data's index of whole data. 
\return              bool: True means unload success, false means fail.
\note                N/A
*/
		virtual bool OnItemUnloaded(class ISingleLineListControl* list, IData *data, int itemIndex) { return false; }

/*!
\brief               The async data load callback.
\remarks             When ISingleLineListControl need to load data by async type, it will notify user by this callback function.
\param               list: [in] The pointer of control. 
\param               data: [in] The data which need to load. 
\param               itemIndex: [in] The data's index of whole data. 
\return              bool: True means load success, false means fail.
\note                N/A
*/
		virtual bool OnAsyncItemLoad(class ISingleLineListControl *list, IData *data, int itemIndex) { return false; }


		//! Focus change listener
		virtual bool OnFocusChanged(class ISingleLineListControl *list, int fromItemIndex, int toItemIndex) { return false; }

		//! Focus change motion start listener
		virtual bool OnFocusChangeMotionStart(class ISingleLineListControl* list, int fromItemIndex, int toItemIndex) { return false; }

		//! If there's no more move for MoveFocus() function.
		virtual bool OnMoveOut(class ISingleLineListControl* list, EDirection direction, int fromItemIndex) { return false; }

		//! Item clicked listener 
		virtual bool OnItemClicked(class ISingleLineListControl* list, int itemIndex) { return false; }

		//! Item long pressed enter key listener
		virtual bool OnEnterKeyLongPressed(class ISingleLineListControl *list, int itemIndex) { return false; }
	};

	class HALO_API ISingleLineListControl : virtual public IDataListControl
	{
	public:
		struct TSingleLineListControlAttr : public TDataListControlAttr
		{
		public:
			EDirectionType type; //!< Define whether the control is vertical or horizontal.

			TSingleLineListControlAttr(float inWidth, float inHeight, EDirectionType inType) :
			TDataListControlAttr(inWidth, inHeight), type(inType) {};
		};

		enum ESingleLineAniType
		{
			ANITYPE_FOCUS_MOVE = 0,   //!< animation type is focus moving
			ANITYPE_LOOP,      //!< animation type is style transformation
			
			ANITYPE_MAX				  //!< end of enum value
		};

/*!
\brief               Create the instance.
\param               parent: [in] The parent actor of the control. 
\param               attr: [in] The attribute of control. 
\return              HALO::ISingleLineListControl *: The instance of the control.
\note                N/A
*/
		static ISingleLineListControl* CreateInstance(IActor *parent, const TSingleLineListControlAttr &attr);

		static ISingleLineListControl* CreateInstance(Widget *parent, const TSingleLineListControlAttr &attr);

/*!
\brief               Get the number of all items.
\return              int: The number of all items. 
\note                N/A
*/
		virtual int NumofItem(void) = 0;

/*!
\brief               Add items.
\remarks             Different items can have different spaces.
\param               itemNum: [in] The number of added items. 
\param               itemSpaceArray: [in] The space array of the items. 
\return              None
\note                N/A
*/
		virtual void AddItem(int itemNum, float *itemSpaceArray) = 0;

/*!
\brief               Add items.
\remarks             Every items have the same space.
\param               itemNum: [in] The number of added items. 
\param               itemSpace: [in] The space of the items. 
\return              None
\note                N/A
*/
		virtual void AddItem(int itemNum, float itemSpace) = 0;

/*!
\brief               Insert items at designated position.
\remarks             Different items can have different spaces.
\param               insertPosition: [in] The index of insert. 
\param               itemNum: [in] The number of insert items. 
\param               itemSpaceArray: The space array of the insert items. 
\return              None
\note                N/A
*/
		virtual void InsertItem(int insertPosition, int itemNum, float *itemSpaceArray) = 0;

/*!
\brief               Insert items at designated position.
\remarks             Every items have the same space.
\param               insertPosition: [in] The index of insert. 
\param               itemNum: [in] The number of insert items. 
\param               itemSpace: The space of the insert items. 
\return              None
\note                N/A
*/
		virtual void InsertItem(int insertPosition, int itemNum, float itemSpace) = 0;

/*!
\brief               Delete items.
\param               fromItem: [in] The first item to delete. 
\param               deleteItemNum: [in] The number of delete items. 
\return              None
\note                N/A
*/
		virtual void DeleteItem(int fromItem, int deleteItemNum) = 0;

/*!
\brief               Set the duration of animations in control
\param               aniType: [in] The animationType. 
\param               duration: [in] The duration of animation. 
\return              None
\note                N/A
*/
		virtual void SetAnimationDuration(ESingleLineAniType aniType, int duration) = 0;

/*!
\brief               Set the margin of control.
\param               margin: [in] The margin of control. 
\return              None
\note                N/A
*/
		virtual void SetMargin(TMargin margin) = 0;

/*!
\brief               Set the space of one item.
\param               itemIndex: The index of the item which shall change its space. 
\param               itemSpace: The space that the item need to change to. 
\return              None
\note                N/A
*/
		virtual void SetItemSpace(int itemIndex, float itemSpace) = 0;

/*!
\brief               Set the spaces of several items.
\param               numOfChangeItem: The number of items that need to change their spaces. 
\param               itemIndex: [in] The itemIndex array. 
\param               itemSpace: [in] The space array. 
\return              None
\note                N/A
*/
		virtual void SetItemSpace(int numOfChangeItem, int itemIndex[], float itemSpace[]) = 0;

/*!
\brief               Get the dataSource of control.
\remarks             The dataSource is used to store the data pointer.
\return              HALO::ISingleLineDataSource *: The pointer of dataSource. 
\note                N/A
*/
		virtual ISingleLineDataSource * GetDataSource(void) = 0;

/*!
\brief               Set the itemIndex that need to be focused.
\param               itemIndex: [in] The index of focused item. 
\return              None
\note                N/A
*/
		virtual void SetFocusItemIndex(const int itemIndex) = 0;

/*!
\brief               Get the index of focused item.
\return              int: [in] The index of focused item. 
\note                N/A
*/
		virtual int FocusItemIndex(void) const = 0;

/*!
\brief               Add the listListener to control.
\param               listener: [in] The pointer of listener. 
\note                N/A
*/
		virtual void AddListListener(ISingleLineListControlListener *listener) = 0;

/*!
\brief               Update one item.
\remarks             If user want to redraw one item, user can call this API.
\param               itemIndex: [in] The index of redraw item. 
\note                N/A
*/
		virtual void UpdateUI(int itemIndex) = 0;
	};
}
#endif
