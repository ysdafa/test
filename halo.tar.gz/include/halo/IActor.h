#ifndef _HALO_IACTOR_H_
#define _HALO_IACTOR_H_

namespace HALO
{
	//class HALO_API IActorListener : public IListener
	//{
	//public:
	//	virtual bool OnFirstFocusIn(class IActor *actor) {return false;}
	//};

	class HALO_API IActor : virtual public IWidgetExtension, public Instance
	{
	public:
		struct TWindowAttr
		{
			float width;     //!< actor(window) width
			float height;    //!< actor(window) height

			ClutterColor bgColor;  //!< background color

			int alpha;  //!< Opacity of an actor, between 0 (fully transparent) and 255 (fully opaque), default value:255. 

			TVector3<float>  position;       //!< 3D coordinate of the window relative to its parent 
			TVector3<float>  pivotPoint;     //!< the "pivot-point" around which the scaling and rotation transformations occur. value range (0.0 ~ 1.0)
			TVector3<double> rotationAngle;  //!< the rotation angle
			TVector3<double> scaleFactor;    //!< the scale factor of the actor

			TWindowAttr(float w, float h) :width(w), height(h), alpha(255),
				position(0.0, 0.0, 0.0), pivotPoint(0.0, 0.0, 0.0), rotationAngle(0.0, 0.0, 0.0), scaleFactor(1.0, 1.0, 1.0) {}
		};

		//typedef std::vector<IAction*> TActionList;

	public:
		/*!
		\brief               Creates a new actor(window)
		\remarks             if parent is NULL, this actor will be a child of the Stage. The parent is not recommended to NULL.
		\param			     parent: [in] The parent of this Actor.
		\param               width: [in] Width of Actor in pixels.
		\param               height: [in] Height of Actor in pixels.
		\return              HALO::IActor *: The newly created Actor
		\par Example:
		\code
		IActor* actor = CreateInstance(IStage::GetInstance()->RootActor(), 800, 480);
		\endcode
		\see                 IStage::GetInstance()
		*/
		static IActor* CreateInstance(Widget* parent, float width, float height);

		/*!
		\brief               Creates a new actor(window)
		\remarks             if parent is NULL, this actor will be a child of the Stage. The parent is not recommended to NULL.
		\param			     parent: [in] The parent of this Actor.  
		\param               width: [in] Width of Actor in pixels. 
		\param               height: [in] Height of Actor in pixels. 
		\return              HALO::IActor *: The newly created Actor
		\par Example:
		\code
			IActor* actor = CreateInstance(IStage::GetInstance()->RootActor(), 800, 480);
		\endcode
		\see                 IStage::GetInstance()
		*/
		static IActor* CreateInstance(IActor* parent, float width, float height);

		/*!
		\brief               Create an instance of actor(window)
		\remarks             if parent is NULL, this actor will be a child of the Stage. The parent is not recommended to NULL.
		\param               parent: [in] The parent of this Actor. 
		\param               attr: [in] actor(window) attributes. 
		\return              HALO::IActor *: The newly created Actor
		\par Example:
		\code
			IActor::TWindowAttr attr(800, 480);
			attr.bgColor = *CLUTTER_COLOR_Blue;
			attr.alpha = 150;
			IActor* actor = CreateInstance(IStage::GetInstance()->RootActor(), attr);
		\endcode
		\see                 IStage::GetInstance()
		*/
		static IActor* CreateInstance(IActor* parent, const TWindowAttr &attr);

	public:
		/*!
		\brief               Sets the parent of actor
		\remarks             if parent is NULL, this actor will be a child of the Stage. The parent is not recommended to NULL.
		\param               parent: [in] The new parent. 
		\return              None
		*/
		virtual void SetParent(IActor* parent) = 0;

		/*!
		\brief               Returns the parent of this actor
		\return              HALO::IActor *: The parent of this actor 
		*/
		virtual IActor* Parent(void) const = 0;

		/*!
		\brief               Sets the background color of the window
		\param               color: [in] The background color. 
		\return              None
		*/
		virtual void SetBackgroundColor(const ClutterColor &color) = 0;

		/*!
		\brief               Sets the size of the actor
		\param               width: [in] The new requested width, in pixels. 
		\param               height: [in] The new requested height, in pixels. 
		\return              None
		*/
		virtual void Resize(float width, float height) = 0;
		 
		/*!
		\brief               Gets the size of the actor
		\param               width: [out] The width of the actor, in pixels. 
		\param               height: [out] The height of the actor, in pixels. 
		\return              None
		*/
		virtual void GetSize(float &width, float &height) = 0;

		/*!
		\brief               Sets the actor's position
		\remarks             The position is relative to its parent, and (0, 0, 0) presents left-top within parent
		\param               x: [in] The new requested position on the X axis. 
		\param               y: [in] The new requested position on the Y axis. 
		\param               z: [in] The new requested position on the Z axis. 
		\return              None
		*/
		virtual void SetPosition(float x, float y, float z) = 0;
		/*!
		\brief               Gets the actor's position
		\param               x: [out] The position on the X axis. 
		\param               y: [out] The position on the Y axis. 
		\param               z: [out] The position on the Z axis. 
		\return              None
		*/
		virtual void GetPosition(float &x, float &y, float &z) = 0;
		/*!
		\brief               Sets the actor's position without changing Z axis position
		\remarks             The position is relative to its parent, and (0, 0) presents left-top within parent
		\param               x: [in] The new requested position on the X axis. 
		\param               y: [in] The new requested position on the Y axis. 
		\return              None
		*/
		virtual void SetPosition(float x, float y) = 0;
		/*!
		\brief               Gets the actor's position on X and Y axis.
		\param               x: [out] The position on the X axis. 
		\param               y: [out] The position on the Y axis. 
		\return              None
		*/
		virtual void GetPosition(float &x, float &y) = 0;

		/*!
		\brief               Sets the layout delegate object that will be used to lay out the children of the actor. 
		\param               layout: [in] a layout manager. 
		\return              Return true if successed, otherwise return false. 
		*/
		virtual bool SetLayout(ILayout* layout) = 0;
		/*!
		\brief               Return the layout manager that is installed on this window
		\return              HALO::ILayout *: a pointer to the layout manager 
		*/
		virtual ILayout* Layout(void) = 0;
		///*!
		//\brief               Sets direction orientation
		//\remarks             Write remarks here
		//\param               orientation: [in] the new requested orientation direction. 
		//\return              None
		//\see                 EOrientation
		//*/
		//virtual void SetOrientation(EOrientation orientation) = 0;
		///*!
		//\brief               Return the direction orientation
		//\param               flagReferParent: [in] if refer to parent's orientation. 
		//\return              EOrientation: the orientation direction 
		//*/
		//virtual EOrientation Orientation(bool flagReferParent) = 0;

		/*!
		\brief               Shows the window
		\return              None
		*/
		virtual void Show(void) = 0;
		/*!
		\brief               Hides the window
		\return              None
		*/
		virtual void Hide(void) = 0;
		/*!
		\brief               Checks whether the window is shown
		\return              bool: return true if the window is visible, otherwise return false 
		*/
		virtual bool FlagShow(void) = 0;

		/*!
		\brief               Sets whether the window should be clipped to the same size as its allocation
		\param               enable: [in] true to apply a clip tracking the allocation
		\return              None
		*/
		virtual void EnableClipOverflow(bool enable) = 0;
		/*!
		\brief               Retrieves whether or not to hide(clip) overflow
		\return              true if the window is clipped to its allocation
		*/
		virtual bool IsClipOverflowEnabled(void) = 0;

		/*!
		\brief               Sets clip area for the window
		\remarks             The window includes its children will be cropped if out of the range
		\param               x: [in] X offset of the clip rectangle. 
		\param               y: [in] Y offset of the clip rectangle. 
		\param               width: [in] Width of the clip rectangle. 
		\param               height: [in] Height of the clip rectangle. 
		\return              None
		*/
		virtual void SetClipArea (float x, float y, float width, float height) = 0;
		/*!
		\brief               Gets clip area for the window
		\param               x: [out] X offset of the clip rectangle. 
		\param               y: [out] Y offset of the clip rectangle. 
		\param               width: [out] Width of the clip rectangle. 
		\param               height: [out] Height of the clip rectangle. 
		\return              None
		*/
		virtual void GetClipArea(float &x, float &y, float &width, float &height) = 0;
		/*!
		\brief               Removes clip area from the window
		\return              None
		*/
		virtual void RemoveClipArea (void) = 0;
		/*!
		\brief               Checks whether the window has a clip area or not
		\return              bool: true if the window has a clip area set
		*/
		virtual bool FlagClip (void) = 0;

		/*!
		\brief               Sets the window's opacity
		\remarks             between 0 (fully transparent) and 255 (fully opaque)
		\param               alpha: [in] the new requested opacity of the window. 
		\return              None
		*/
		virtual void SetAlpha(int alpha) = 0;
		/*!
		\brief               Retrieves the opacity value of a window
		\return              int: the opacity of the window
		*/
		virtual int Alpha(void) = 0;

		/*!
		\brief               Sets the position of the "pivot-point" 
		\remarks             "pivot-point" around which the scaling and rotation transformations occur. value range (0.0 ~ 1.0)
		\param               xPivot: [in] the normalized X coordinate of the pivot point. 
		\param               yPivot: [in] the normalized Y coordinate of the pivot point. 
		\param               zPivot: [in] the Z coordinate of the actor's pivot point. 
		\return              None
		*/
		virtual void SetPivotPoint(float xPivot, float yPivot, float zPivot) = 0;
		/*!
		\brief               Gets the position of the "pivot-point" 
		\remarks             "pivot-point" around which the scaling and rotation transformations occur. value range (0.0 ~ 1.0)
		\param               xPivot: [out] the normalized X coordinate of the pivot point. 
		\param               yPivot: [out] the normalized Y coordinate of the pivot point. 
		\param               zPivot: [out] the Z coordinate of the actor's pivot point. 
		\return              None
		*/
		virtual void GetPivotPoint(float &xPivot, float &yPivot, float &zPivot) = 0;
		/*!
		\brief               Sets the rotation angle of a window
		\remarks             The rotate transformation is relative the the "pivot-point". 
		\param               xAngle: [in] The angle of rotation on X axis. 
		\param               yAngle: [in] The angle of rotation on Y axis. 
		\param               zAngle: [in] The angle of rotation on Z axis. 
		\return              None
		*/
		virtual void SetRotation(double xAngle, double yAngle, double zAngle) = 0;
		/*!
		\brief               Gets the rotation angle of a window
		\param               xAngle: [out] The angle of rotation on X axis. 
		\param               yAngle: [out] The angle of rotation on Y axis. 
		\param               zAngle: [out] The angle of rotation on Z axis. 
		\return              None
		*/
		virtual void GetRotation(double &xAngle, double &yAngle, double &zAngle) = 0;
		/*!
		\brief               Scales a window with the given factors
		\remarks             The scale transformation is relative the the "pivot-point". 
		\param               xFactor: [in] double factor to scale actor by horizontally. 
		\param               yFactor: [in] double factor to scale actor by vertically. 
		\param               zFactor: [in] the scaling factor along the Z axis. 
		\return              None
		*/
		virtual void SetScale(double xFactor, double yFactor, double zFactor) = 0;
		/*!
		\brief               Get a window's scale factors
		\param               xFactor: [out] double factor to scale actor by horizontally. 
		\param               yFactor: [out] double factor to scale actor by vertically. 
		\param               zFactor: [out] the scaling factor along the Z axis. 
		\return              None
		*/
		virtual void GetScale(double &xFactor, double &yFactor, double &zFactor) = 0;

		/*!
		\brief               Adds effect to window
		\param               effect: [in] an IEffect. 
		\return              None
		*/
		virtual void AddEffect(IEffect* effect) = 0;
		/*!
		\brief               Removes effect from window
		\param               effect: [in] an IEffect. 
		\return              None
		*/
		virtual void RemoveEffect(IEffect* effect) = 0;
		/*!
		\brief               Clear all effects that is installed on this window
		\return              None
		*/
		virtual void ClearEffects(void) = 0;

		/*!
		\brief               Add a child ClutterActor to this window
		\param               actor: [in] a ClutterActor. 
		\return              None
		*/
		virtual void AddChild(ClutterActor *actor) = 0;

		/*!
		\brief               Retrieves the number of children
		\return              int: The number of children of the window 
		*/
		virtual int  NumOfChildren(void) = 0;
		/*!
		\brief               Retrieves the window at the given index inside the list of children of the window
		\param               index: [in] index of a requested child. 
		\return              HALO::IActor *: a pointer to a actor, or NULL 
		*/
		virtual IActor* GetChild(int index) = 0;
		/*!
		\brief               Destroys all children of this window
		\return              None
		*/
		virtual void DestroyAllChildren(void) = 0;

		/*!
		\brief               Sets itself to be above sibling in the list of children of its parent
		\remarks             If sibling is NULL,will raises this window to the top of the parent window's stack.
		\param               sibling:[in] a sibling of the window. 
		\return              bool: true
		*/
		virtual bool Raise(IActor* sibling) = 0;
		/*!
		\brief               Sets itself to be below sibling in the list of children of its parent
		\remarks             If sibling is NULL,will lower this window to the bottom of the parent window's stack.
		\param               sibling: [in] a sibling of the window. 
		\return              bool: true
		*/
		virtual bool Lower(IActor* sibling) = 0;

		/*!
		\brief               Sets whether the window can receive input events
		\param               flagEnable: [in] true to enable the window, and false to disable the window. 
		\return              None
		*/
		//virtual void Enable(bool flagEnable) = 0;
		/*!
		\brief               Checks whether the window can receive input events
		\return              bool: return true if the window is enabled, otherwise return false
		*/
		//virtual bool IsEnabled(void) = 0;

		/*!
		\brief               Sets whether the window should focus when mouse pointer in
		\param               flagEnable: [in] the enable switch. 
		\return              None
		*/
		//virtual void EnablePointerFocus(bool enable) = 0;
		/*!
		\brief               Checks if the window auto focus when mouse pointer in
		\return              bool: return true if focus when pointer in property is set, otherwise return false
		*/
		//virtual bool IsPointerFocusEnabled(void) = 0;
		
		/*!
		\brief               Set whether the window can have focus.
		\param               flagFocusable: [in] the focus enable switch. 
		\return              None
		*/
		//virtual void EnableFocus(bool flagFocusable) = 0;
		/*!
		\brief               Checks whether the window can set focus.
		\remarks             Default value: false
		\return              bool: return true if the window can be focused, otherwise return false
		*/
		//virtual bool IsFocusEnabled(void) = 0;

		/*!
		\brief               Gives the keyboard input focus to this window .
		\remarks             If the window is invisible or disabled or focus disabled,  the window cann't accept focus
		\return              bool: return true if the window gets the focus
		\par Example:
		\code
			IActor* actor = CreateInstance(IStage::GetInstance()->RootActor(), 800, 480);
			actor->show();
			actor->EnableFocus();
			actor->SetFocus();
		\endcode
		\see                 EnableFocus()
		*/
		//virtual bool SetFocus(void) = 0;
		/*!
		\brief               Takes keyboard input focus from the widget
		\remarks             If param autoFocus is true, the focus will pass to the previous focused window, otherwise the Stage will get the focus.
		\param               autoFocus: [in] whether set focus to previous window while the will lose focus. 
		\return              bool: return true is the window loses the focus
		*/
		//virtual bool KillFocus(bool autoFocus = true) = 0;
		/*!
		\brief               Check whether the window has the keyboard input focus.
		\return              bool: return true if the window is a focus-window 
		*/
		//virtual bool IsFocused(void) = 0;

		/*!
		\brief               Sets the tab focus window at direction @dir
		\param               dir: [in] 4-direction direction. 
		\param               tabWindow:[in] a window. 
		\return              None
		\see                 MoveTab()
		*/
		//virtual void SetTabWindow(EDirection dir, IActor* tabWindow) = 0;
		/*!
		\brief               Retrieves the tab window at direction @dir
		\param               dir: [in] 4-direction direction. 
		\return              HALO::IActor *: the window at direction dir 
		\see                 MoveTab()
		*/
		//virtual IActor* TabWindow(EDirection dir) = 0;
		/*!
		\brief               Moves the focus to the window sets as the direction @dir tab window
		\param               dir: [in] Explain parameter here. 
		\return              bool: returns true if it can find a new window in direction dir 
		\see                 SetTabWindow()
		*/
		//virtual bool MoveTab(EDirection dir) = 0;

		//! Returns a ClutterActor binded to the actor
		virtual ClutterActor* Actor(void) = 0;

		//! Get the ActionList added to the actor.
		//virtual TActionList* GetActionList(void) = 0;

	public:
		//! Grab event, Only ClutterInputDevice of types CLUTTER_POINTER_DEVICE and CLUTTER_KEYBOARD_DEVICE can hold a grab.
		//virtual void GrabDeviceEvent(IDevice* device) = 0; 
		//! Ungrab device event
		//virtual void UnGrabDeviceEvent(IDevice* device) = 0;

		//! Add Actions
		//virtual bool AddAction(IAction* pAction) = 0;
		//! Remove Actions
		//virtual bool RemoveAction(IAction* pAction) = 0;

		//! Add Focus Listener
		//virtual bool AddFocusListener(IFocusListener* pListener) = 0;
		//! Remove Focus Listener
		//virtual bool RemoveFocusListener(IFocusListener* pListener) = 0;

		//!Add mouse listeners
		//virtual bool AddMouseListener(IMouseListener* pAddListener) = 0;
		//!Remove mouse listeners
		//virtual bool RemoveMouseListener(IMouseListener* pRemoveListener) = 0;

		//! Add Touch Listener
		//virtual bool AddTouchListener(ITouchListener* pAddListener) = 0;
		//! Remove Touch Listener
		//virtual bool RemoveTouchListener(ITouchListener* pRemoveListener) = 0;

		//! Add Keyboard Listener
		//virtual bool AddKeyboardListener(IKeyboardListener* pAddListener) = 0;
		//! Remove Keyboard Listener
		//virtual bool RemoveKeyboardListener(IKeyboardListener* pRemoveListener) = 0;

		//! Add Audio Listener
		//virtual bool AddAudioListener(IAudioListener* pAddListener) = 0;
		//! Remove Audio Listener
		//virtual bool RemoveAudioListener(IAudioListener* pRemoveListener) = 0;

		//! Add RemoteControl Listener
		//virtual bool AddRemoteControlListener(IRemoteControlListener* pAddListener) = 0;
		//! Remove RemoteControl Listener
		//virtual bool RemoveRemoteControlListener(IRemoteControlListener* pRemoveListener) = 0;

		//! Add RemoteControl Listener
		//virtual bool AddRidgeListener(IRidgeListener* pAddListener) = 0;
		//! Remove RemoteControl Listener
		//virtual bool RemoveRidgeListener(IRidgeListener* pRemoveListener) = 0;

		//! Add ActorListener
		//virtual bool AddActorListener(IActorListener *pActorListener) = 0;
		//! Remove ActorListener
		//virtual bool RemoveActorListener(IActorListener *pActorListener) = 0;

		//! Add cursor Listener
		//virtual bool AddCursorStateChangeListener(ICursorListener* pAddListener) = 0;
		//! Remove cursor Listener
		//virtual bool RemoveCursorStateChangeListener(ICursorListener* pRemoveListener) = 0;

		//! Add click Listener
		//virtual bool AddClickListener(IClickListener* pAddListener) = 0;
		//! Remove click Listener
		//virtual bool RemoveClickListener(IClickListener* pRemoveListener) = 0;

		//! Add Semantic Listener
		//virtual bool AddSemanticEventListener(ISemanticEventListener* pAddListener) = 0;
		//! Remove Semantic Listener
		//virtual bool RemoveSemanticEventListener(ISemanticEventListener* pRemoveListener) = 0;

		//! Add drag Listener
		//virtual bool AddDragListener(IDragListener* pAddListener) = 0;
		//! Remove drag Listener
		//virtual bool RemoveDragListener(IDragListener* pRemoveListener) = 0;

		//! Add gesture Listener
		//virtual bool AddGestureListener(IGestureListener* pAddListener) = 0;
		//! Remove gesture Listener
		//virtual bool RemoveGestureListener(IGestureListener* pRemoveListener) = 0;
		
		//! Add key long press Listener
		//virtual bool AddKeyLongPressListener(IKeyLongPressListener* pAddListener) = 0;
		//! Remove key long press Listener
		//virtual bool RemoveKeyLongPressListener(IKeyLongPressListener* pRemoveListener) = 0;

		//! Add key combination Listener
		//virtual bool AddKeyCombinationListener(IKeyCombinationListener* pAddListener) = 0;
		//! Remove key combination Listener
		//virtual bool RemoveKeyCombinationListener(IKeyCombinationListener* pRemoveListener) = 0;
		//!Add cursor listeners
		//virtual bool AddCursorListener(ICursorListener* pAddListener) = 0;
		//!Remove cursor listeners
		//virtual bool RemoveCursorListener(ICursorListener* pRemoveListener) = 0;

		//! Get actor type
		virtual const char* GetActorType(void) = 0;
	};
}
#endif
