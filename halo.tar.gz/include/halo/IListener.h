#ifndef _ILISTENER_H_
#define _ILISTENER_H_

namespace HALO
{
	class IWidgetExtension;
	class IActor;
	class IEvent;
	class IMouseEvent;
	class IKeyboardEvent;
	class ITouchEvent;
	class IRidgeEvent;
	class IMotionEvent;
	class ISensorEvent;
	class ICursorEvent;
	class IRemoconEvent;
	class IClickEvent;
	class ILongPressEvent;
	class IFocusEvent;
	class IDragEvent;
	class IGestureEvent;

	class HALO_API IListener
	{
	public:
		IListener(){};
		virtual ~IListener(){};
	};

	typedef IListener* IListenerPtr;

	class HALO_API IFocusListener: public IListener
	{
	public:
		//! The callback function when focus-in.
		virtual bool OnFocusIn(IWidgetExtension* pWindow) { return false; }

		//! The callback function when focus-out.
		virtual bool OnFocusOut(IWidgetExtension* pWindow) { return false; }
	};

	class HALO_API IMouseListener: public IListener
	{
	public:
		//! The callback function when mouse button press.
		virtual bool OnMouseButtonPressed(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent) { return false; }

		//! The callback function when mouse button release.
		virtual bool OnMouseButtonReleased(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent) { return false; }

		//! The callback function when mouse move.
		virtual bool OnMouseMoved(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent) { return false; }

		//! The callback function when mouse wheel.
		virtual bool OnMouseWheel(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent) { return false; }

		//! The callback function when mouse pointer click.
		virtual bool OnMouseClicked(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent) { return false; }

		//! The callback function when mouse pointer in.
		virtual bool OnMousePointerIn(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent) { return false; }

		//! The callback function when mouse pointer out.
		virtual bool OnMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent) { return false; }

		//add 
		//! The callback function when mouse button press on capture phase.
		virtual bool OnCapturedMouseButtonPressed(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent) { return false; }

		//! The callback function when mouse button release on capture phase.
		virtual bool OnCapturedMouseButtonReleased(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent) { return false; }

		//! The callback function when mouse move on capture phase.
		virtual bool OnCapturedMouseMoved(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent) { return false; }

		//! The callback function when mouse wheel on capture phase.
		virtual bool OnCapturedMouseWheel(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent) { return false; }

		//! The callback function when mouse click on capture phase.
		virtual bool OnCapturedMouseClicked(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent) { return false; }

		//! The callback function when mouse pointer in on capture phase.
		virtual bool OnCapturedMousePointerIn(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent) { return false; }

		//! The callback function when mouse pointer in on capture phase.
		virtual bool OnCapturedMousePointerOut(IWidgetExtension* pWindow, IMouseEvent* ptrMouseEvent) { return false; }
	};

	class HALO_API ITouchListener: public IListener
	{
	public:
		//! The callback function when touch pressed.
		virtual bool OnTouchPressed(IWidgetExtension* pWindow, ITouchEvent* ptrTouchEvent) { return false; }

		//! The callback function when touch released.
		virtual bool OnTouchReleased(IWidgetExtension* pWindow, ITouchEvent* ptrTouchEvent) { return false; }

		//! The callback function when touch moved.
		virtual bool OnTouchMoved(IWidgetExtension* pWindow, ITouchEvent* ptrTouchEvent) { return false; }

		//! The callback function when touch tap.
		virtual bool OnTouchTap(IWidgetExtension* pWindow, ITouchEvent* ptrTouchEvent) { return false; }

		//! The callback function when touch flicked.
		virtual bool OnTouchFlicked(IWidgetExtension* pWindow, ITouchEvent* ptrTouchEvent) { return false; }

		//! The callback function when touch pinched.
		virtual bool OnTouchPinched(IWidgetExtension* pWindow, ITouchEvent* ptrTouchEvent) { return false; }

		//! The callback function when touch stretched.
		virtual bool OnTouchStretched(IWidgetExtension* pWindow, ITouchEvent* ptrTouchEvent) { return false; }

		//! The callback function when touch long-pressed.
		virtual bool OnTouchLongPressed(IWidgetExtension* pWindow, ITouchEvent* ptrTouchEvent) { return false; }
	};

	class HALO_API IKeyboardListener: public IListener
	{
	public:
		//! The callback function when key pressed.
		virtual bool OnKeyPressed(IWidgetExtension* pThis, IKeyboardEvent* event) { return false; }

		//! The callback function when key released.
		virtual bool OnKeyReleased(IWidgetExtension* pWindow, IKeyboardEvent* ptrKeyboardEvent) { return false; }

		//! The callback function when key pressed on capture phase.
		virtual bool OnCapturedKeyPressed(IWidgetExtension* pWindow, IKeyboardEvent* ptrKeyboardEvent) { return false; }

		//! The callback function when key pressed on capture phase.
		virtual bool OnCapturedKeyReleased(IWidgetExtension* pWindow, IKeyboardEvent* ptrKeyboardEvent) {return false;}
	};

	class HALO_API IAudioListener: public IListener
	{
	public:
	//		virtual bool IfAudioEvent(IActor* pWindow, const PTEvent* ptrEvent, void* userData) { return false; }
	};

	class HALO_API IMotionListener: public IListener
	{
	public:
		//! The callback function when motion tilt.
		virtual bool OnMotionTilt(IWidgetExtension* pWindow, IMotionEvent* pMotionEvent) { return false; }

		//! The callback function when motion roll.
		virtual bool OnMotionRoll(IWidgetExtension* pWindow, IMotionEvent* pMotionEvent) { return false; }

		//! The callback function when motion panning.
		virtual bool OnMotionPanning(IWidgetExtension* pWindow, IMotionEvent* pMotionEvent) { return false; }

		//! The callback function when motion snap.
		virtual bool OnMotionSnap(IWidgetExtension* pWindow, IMotionEvent* pMotionEvent) { return false; }
	};

	class HALO_API IRemoteControlListener: public IListener
	{
	public:
		//! The callback function when remotecontrol key pressed.
		virtual bool OnKeyPressed(IWidgetExtension* pWindow, IRemoconEvent* pRemoteControlEvent) { return false; }

		//! The callback function when remotecontrol key released.
		virtual bool OnKeyReleased(IWidgetExtension* pWindow, IRemoconEvent* pRemoteControlEvent) { return false; }

		//! The callback function when remotecontrol key long-pressed.
		virtual bool OnKeyLongPressed(IWidgetExtension* pWindow, IRemoconEvent* pRemoteControlEvent) { return false; }	
	};

	class HALO_API IRidgeListener: public IListener
	{
	public:
		//! The callback function when ridge on.
		virtual bool OnRidgeOn(IWidgetExtension* pWindow, IRidgeEvent* pRidgeEvent) { return false; }

		//! The callback function when ridge off.
		virtual bool OnRidgeOff(IWidgetExtension* pWindow, IRidgeEvent* pRidgeEvent) { return false; }

		//! The callback function when ridge move.
		virtual bool OnRidgeMove(IWidgetExtension* pWindow, IRidgeEvent* pRidgeEvent) { return false; }

		//! The callback function when ridge flick.
		virtual bool OnRidgeFlick(IWidgetExtension* pWindow, IRidgeEvent* pRidgeEvent) { return false; }
	};

	class HALO_API ICursorListener: public IListener
	{
	public:
		//! The callback function when cursor show.
		virtual bool OnShown(IWidgetExtension* pApp, ICursorEvent* pCursorEvent) { return false; }

		//! The callback function when cursor hide.
		virtual bool OnHidden(IWidgetExtension* pApp, ICursorEvent* pCursorEvent) { return false; }

		//! The callback function when cursor change device type.
		virtual bool OnDeviceTypeChanged(IWidgetExtension* pHandler, ICursorEvent* pCursorEvent) { return false; }
	};

	class HALO_API ISensorListener : public IListener
	{
	public:
		//! The callback function when sensor start.
		virtual bool OnSensorStart(IWidgetExtension* pWindow, ISensorEvent* pSensorEvent) { return false; }

		//! The callback function when sensor move.
		virtual bool OnSensorMoved(IWidgetExtension* pWindow, ISensorEvent* pSensorEvent) { return false; }

		//! The callback function when sensor end.
		virtual bool OnSensorEnd(IWidgetExtension* pWindow, ISensorEvent* pSensorEvent) { return false; }
	};

	class HALO_API IClickListener : public IListener
	{
	public:
		//! The callback function when mouse click.
		virtual bool OnClicked(IWidgetExtension* pWindow, IEvent* pClickEvent) { return false; }

		//! The callback function when mouse long-press.
		virtual bool OnLongPress(IWidgetExtension* pWindow, ILongPressEvent* pLongPressEvent) { return false; }
	};

	class ISemanticEventListener : public IListener
	{
	public:
		//! The callback function when Semantic event occur.
		virtual bool OnSemanticEvent(IWidgetExtension* pWindow, IEvent* pEvent){return false;}
	};

	class ISystemEventListener : public IListener
	{
	public:
		//! The callback function when quit systemevent occur.
		virtual bool OnSystemQuit(IEvent* pEvent){return false;}

		//! The callback function when cursor become visible 
		virtual bool OnCursorVisible(IEvent* pEvent){return false;}

		//! The callback function when cursor become hidden
		virtual bool OnCursorHidden(IEvent* pEvent){return false;}
	};
	
	class ICustomEventListener : public IListener
	{
	public:
		//! The callback function when custom event occur.
		virtual bool OnCustomEvent(IEvent* pEvent){ return false; }

		//! The callback function when custom sync-event occur.
		virtual bool OnCustomEventSync(IEvent* pEvent, IEvent* pReply){return false;}
	};

	//! Drag listener
	class HALO_API IDragListener : public IListener
	{
	public:
		//! The callback function when drag-action begin signal occur.
		virtual bool OnDragBegin(IWidgetExtension* pWindow, IDragEvent* pDragEvent) { return false; }

		//! The callback function when drag-action end signal occur.
		virtual bool OnDragEnd(IWidgetExtension* pWindow, IDragEvent* pDragEvent) { return false; }

		//! The callback function when drag-action motion signal occur.
		virtual bool OnDragMotion(IWidgetExtension* pWindow, IDragEvent* pDragEvent) { return false; }

		//! The callback function when drag-hold motion signal occur.
		virtual bool OnDragHold(IWidgetExtension* pWindow, IDragEvent* pDragEvent) { return false; }

		//virtual bool IfDragProgress(IActor* pWindow, IDragEvent* pDragEvent) { return false; }
	};

	//! Gesture listener
	class HALO_API IGestureListener : public IListener
	{
	public:
		//! The callback function when gesture-action begin signal occur.
		virtual bool OnGestureBegin(IWidgetExtension* pWindow, IGestureEvent* pGestureEvent) { return false; }

		//! The callback function when gesture-action end signal occur.
		virtual bool OnGestureEnd(IWidgetExtension* pWindow, IGestureEvent* pGestureEvent) { return false; }

		//! The callback function when gesture-action cancel signal occur.
		virtual bool OnGestureCancel(IWidgetExtension* pWindow, IGestureEvent* pGestureEvent) { return false; }

		//! The callback function when gesture-action progress signal occur.
		virtual bool OnGestureProgress(IWidgetExtension* pWindow, IGestureEvent* pGestureEvent) { return false; }
	};
	
	//! Key Long Press listener
	class HALO_API IKeyLongPressListener : public IListener
	{
	public:
		//! The callback function when key longpress.
		virtual bool OnKeyLongPress(IWidgetExtension* pWindow, IKeyboardEvent* pKeyboardEvent) { return false; }
	};
	
	//! Key Combination Listener
	class IKeyCombinationListener : public IListener
	{
	public:
		//! The callback function when combinatin-key press.
		virtual bool OnKeyCombination(IWidgetExtension* pWindow, IKeyboardEvent* pKeyboardEvent, void* userdata) { return false; }
	};

} /* namespace HALO */
#endif /* _ILISTENER_H_ */
