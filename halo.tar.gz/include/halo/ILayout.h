#ifndef _HALO_ILAYOUT_H_
#define _HALO_ILAYOUT_H_

namespace HALO
{
	class IActor;
	class HALO_API ILayout : public Instance
	{
	public:
		/*!
		\brief               Sets the horizontal alignment policy of a IActor, in case the actor received extra horizontal space
		\param               self [in] a IActor 
		\param               align [in] the horizontal alignment policy 
		*/
		virtual void SetActorXAlign(IActor* self, ClutterActorAlign x_align) = 0;

		/*!
		\brief               Retrieves the horizontal alignment policy set
		\param               self [in] a IActor 
		\return              ClutterActorAlign: the horizontal alignment policy.
		*/
		virtual ClutterActorAlign ActorXAlign(IActor* self) = 0;

		/*!
		\brief               Sets the vertical alignment policy of a IActor, in case the actor received extra horizontal space
		\param               self [in] a IActor 
		\param               y_align [in] the vertical alignment policy
		*/
		virtual void SetActorYAlign(IActor* self, ClutterActorAlign y_align) = 0;

		/*!
		\brief               Retrieves the vertical alignment policy set
		\param               self [in] a IActor 
		\return              ClutterActorAlign: the vertical alignment policy.
		*/
		virtual ClutterActorAlign ActorYAlign(IActor* self) = 0;
		
		/*!
		\brief               Creates a new ClutterMargin and copies the contents of margin_ into the newly created structure.
		\param               margin_ [in] a ClutterMargin
		\return              ClutterMargin*: a copy of the ClutterMargin. 
		*/
		virtual ClutterMargin* CopyMargin(const ClutterMargin *margin_) = 0;

		/*!
		\brief               Sets all the components of the margin of a IActor
		\param               self [in] a ClutterActor
		\param               margin [in] a ClutterMargin
		*/
		virtual void SetMargin(IActor* self, const ClutterMargin* margin) = 0;

		/*!
		\brief               Retrieves all the components of the margin of a IActor
		\param               self [in] a ClutterActor
		\param               margin [out] return location for a ClutterMargin.
		*/
		virtual void GetMargin(IActor* self, ClutterMargin* margin) = 0;

		/*!
		\brief               Sets the margin from the top of a IActor
		\param               self [in] a ClutterActor
		\param               margin [in] the top margin
		*/
		virtual void SetMarginTop(IActor* self, float margin) = 0;

		/*!
		\brief               Retrieves the top margin of a IActor
		\param               self [in] a ClutterActor
		\return              float: the top margin
		*/
		virtual float MarginTop(IActor* self) = 0;

		/*!
		\brief               Sets the margin from the right of a IActor
		\param               self [in] a ClutterActor
		\param               margin [in] the right margin
		*/
		virtual void SetMarginRight(IActor* self, float margin) = 0;

		/*!
		\brief               Retrieves the right margin of a IActor
		\param               self [in] a ClutterActor
		\return              float: the right margin
		*/
		virtual float MarginRight(IActor* self) = 0;

		/*!
		\brief               Sets the margin from the bottom of a IActor
		\param               self [in] a ClutterActor
		\param               margin [in] the bottom margin
		*/
		virtual void SetMarginBottom(IActor* self, float margin) = 0;

		/*!
		\brief               Retrieves the bottom margin of a IActor
		\param               self [in] a ClutterActor
		\return              float: the bottom margin
		*/
		virtual float MarginBottom(IActor* self) = 0;

		/*!
		\brief               Sets the margin from the left of a IActor
		\param               self [in] a ClutterActor
		\param               margin [in] the left margin
		*/
		virtual void SetMarginLeft(IActor* self, float margin) = 0;

		/*!
		\brief               Retrieves the left margin of a IActor
		\param               self [in] a ClutterActor
		\return              float: the left margin
		*/
		virtual float MarginLeft(IActor* self) = 0;

		/*!
		\brief               Sets whether a IActor should expand horizontally
		\remarks             This means that layout manager should allocate extra space for the actor, if possible.
		\param               self [in] a ClutterActor
		\param               expand [in] whether the actor should expand horizontally
		\note                Setting an actor to expand will also make all its parent expand, so that it's possible to build an actor tree and only set this flag on its leaves and not on every single actor.
		*/
		virtual void SetXExpandFlag(IActor* self, bool expand) = 0;

		/*!
		\brief               Retrieves whether a IActor expand horizontally
		\param               self [in] a ClutterActor
		\return              bool: TRUE if the IActor has been set to expand
		*/
		virtual bool FlagXExpand(IActor* self) = 0;

		/*!
		\brief               Sets whether a IActor should expand vertically
		\remarks             This means that layout manager should allocate extra space for the actor, if possible.
		\param               self [in] a ClutterActor
		\param               expand [in] whether the actor should expand vertically
		\note                Setting an actor to expand will also make all its parent expand, so that it's possible to build an actor tree and only set this flag on its leaves and not on every single actor.
		*/
		virtual void SetYExpandFlag(IActor* self, bool expand) = 0;

		/*!
		\brief               Retrieves whether a IActor expand vertically
		\param               self [in] a ClutterActor
		\return              bool: TRUE if the actor has been set to expand
		*/
		virtual bool FlagYExpand(IActor* self) = 0;
	};

	class HALO_API IFixedLayout : virtual public ILayout
	{
	public:
		/*!
		\brief               Create a IFixedLayout instance.
		\return              IFixedLayout*: a IFixedLayout instance
		*/
		static IFixedLayout* CreateInstance(void);
	};

	class HALO_API IBinLayout : virtual public ILayout
	{
	public:
		/*!
		\brief               Create a IBinLayout instance.
		\return              IBinLayout*: a IBinLayout instance
		*/
		static IBinLayout* CreateInstance(void);
	};

	class HALO_API IBoxLayout : virtual public ILayout
	{
	public:		
		/*!
		\brief               Create a IBoxLayout instance.
		\return              a IBoxLayout instance
		*/
		static IBoxLayout* CreateInstance(void);

		/*!
		\brief               Sets whether children of layout should be layed out by appending them or by prepending them
		\param               pack_start: TRUE if the layout should pack children at the beginning of the layout
		*/
		virtual void SetPackStartFlag(bool pack_start) = 0;

		/*!
		\brief               Retrieves whether the ClutterBoxLayout pack children at the beginning of the layout
		\return              bool: TRUE if the ClutterBoxLayout should pack children at the beginning of the layout, and FALSE otherwise
		*/
		virtual bool FlagPackStart(void) = 0;

		/*!
		\brief               Sets the spacing between children of layout 
		\param               spacing [in] the spacing between children of the layout, in pixels
		*/
		virtual void SetSpacing(float spacing) = 0;

		/*!
		\brief               Retrieves the spacing between children of layout
		\return              float: the spacing between children of the ClutterBoxLayout
		*/
		virtual float Spacing(void) = 0;

		/*!
		\brief               Sets whether the size of layout children should be homogeneous
		\param               homogeneous [in] TRUE if the layout should be homogeneous
		*/
		virtual void EnableHomogeneous(bool homogeneous) = 0;

		/*!
		\brief               Retrieves if the children sizes are allocated homogeneously.
		\return              bool: TRUE if the ClutterBoxLayout is arranging its children homogeneously, and FALSE otherwise
		*/
		virtual bool IsHomogeneousEnable(void) = 0;

		/*!
		\brief               Retrieves the direction of the layout
		\return              ClutterOrientation: the direction of the layout
		*/
		virtual ClutterOrientation Direction(void) = 0;

		/*!
		\brief               Sets the direction of the ClutterBoxLayout layout manager.
		\param               orientation [in] the direction of the ClutterBoxLayout
		*/
		virtual void SetDirection(ClutterOrientation orientation) = 0;
	};

	class HALO_API IFlowLayout : virtual public ILayout
	{
	public:		
		/*!
		\brief               Create a IFlowLayout instance.
		\return              IFlowLayout*: a IFlowLayout instance
		*/
		static IFlowLayout* CreateInstance(void);

		/*!
		\brief               Create a IFlowLayout instance.
		\param               orientation [in] the orientation of the flow layout
		\return              IFlowLayout*: a IFlowLayout instance
		*/
		static IFlowLayout* CreateInstance(ClutterFlowOrientation orientation);

		/*!
		\brief               Sets whether the layout should allocate the same space for each child
		\param               homogeneous [in] whether the layout should be homogeneous or not
		*/
		virtual void EnableHomogeneous(bool homogeneous) = 0;

		/*!
		\brief               Retrieves whether the layout is homogeneous
		\return              bool: TRUE if the ClutterFlowLayout is homogeneous
		*/
		virtual bool IsHomogeneousEnabled(void) = 0;

		/*!
		\brief               Sets the direction of the flow layout
		\remarks             The orientation controls the direction used to allocate the children: either horizontally or vertically. The orientation also controls the direction of the overflowing
		\param               orientation [in] the direction of the layout
		*/
		virtual void SetDirection(ClutterFlowOrientation orientation) = 0;

		/*!
		\brief               Retrieves the direction of the layout 
		\return              ClutterFlowOrientation: the direction of the ClutterFlowLayout
		*/
		virtual ClutterFlowOrientation Direction(void) = 0;

		/*!
		\brief               Sets the space between columns, in pixels 
		\param               spacing [in] the space between columns
		*/
		virtual void SetColumnSpacing(float spacing) = 0;

		/*!
		\brief               Retrieves the spacing between columns 
		\return              float: the spacing between columns of the ClutterFlowLayout, in pixels
		*/
		virtual float ColumnSpacing(void) = 0;

		/*!
		\brief               Sets the spacing between rows, in pixels
		\param               spacing [in] the space between rows
		*/
		virtual void SetRowSpacing(float spacing) = 0;

		/*!
		\brief               Retrieves the spacing between rows
		\return              float: the spacing between rows of the ClutterFlowLayout, in pixels
		*/
		virtual float RowSpacing(void) = 0;

		/*!
		\brief               Sets the minimum and maximum widths that a column can have
		\param               min_width [in] minimum width of a column
		\param               max_width [in] maximum width of a column
		*/
		virtual void SetColumnWidth(float min_width, float max_width) = 0;

		/*!
		\brief               Retrieves the minimum and maximum column widths
		\param               min_width [out] return location for the minimum column width, or NULL. 
		\param               max_width [out] return location for the maximum column width, or NULL.
		*/
		virtual void GetColumnWidth(float &min_width, float &max_width) = 0;

		/*!
		\brief               Sets the minimum and maximum heights that a row can have
		\param               min_height: the minimum height of a row
		\param               max_height: the maximum height of a row
		*/
		virtual void SetRowHeight(float min_height, float max_height) = 0;

		/*!
		\brief               Retrieves the minimum and maximum row heights 
		\param               min_height [out] return location for the minimum row height, or NULL. 
		\param               max_height [out] return location for the maximum row height, or NULL. 
		*/
		virtual void GetRowHeight(float &min_height, float &max_height) = 0;
	};

	class HALO_API IGridLayout : virtual public ILayout
	{
	public:
		/*!
		\brief               Create a IGridLayout instance.
		\return              IGridLayout*: a IGridLayout instance
		*/
		static IGridLayout* CreateInstance(void);

		/*!
		\brief               Adds a IActor to the grid
		\remarks             The position of child is determined by left and top . The number of 'cells' that child will occupy is determined by width and height .
		\param               child [in] the IActor to add
		\param               left [in] the column number to attach the left side of child to
		\param               top [in] the row number to attach the top side of child to 
		\param               width [in] the number of columns that child will span
		\param               height [in] the number of rows that child will span
		*/
		virtual void Attach(IActor* child, int left, int top, int width, int height) = 0;

		/*!
		\brief               Gets a child IActor of layout
		\remarks             Gets the child of layout whose area covers the grid cell whose upper left corner is at left , top 
		\param               left [in] the left edge of the cell
		\param               top [in] the top edge of the cell
		*/
		virtual IActor* ChildAt(int left, int top) = 0;

		/*!
		\brief               Inserts a column at the specified position
		\remarks             Children which are attached at or to the right of this position are moved one column to the right. Children which span across this position are grown to span the new column.
		\param               postition [in] the position to insert the column at
		*/
		virtual void InsertColumn(int postition) = 0;

		/*!
		\brief               Inserts a row at the specified position
		\remarks             Children which are attached at or below this position are moved one row down. Children which span across this position are grown to span the new row.
		\param               position [in] the position to insert the row at
		*/
		virtual void InsertRow(int position) = 0;

		/*!
		\brief               Inserts a row or column at the specified position
		\remarks             The new row or column is placed next to sibling , on the side determined by side . If side is CLUTTER_GRID_POSITION_LEFT or CLUTTER_GRID_POSITION_BOTTOM, a row is inserted. If side is CLUTTER_GRID_POSITION_LEFT of CLUTTER_GRID_POSITION_RIGHT, a column is inserted.
		\param               sibling [in] the child of layout that the new row or column will be placed next to
		\param               side [in] the side of sibling that child is positioned next to.
		*/
		virtual void InsertNextTo(IActor* sibling, ClutterGridPosition side) = 0;

		/*!
		\brief               Sets the orientation of the layout
		\param               orientation [in] the orientation of the ClutterGridLayout
		*/
		virtual void SetDirection(ClutterOrientation orientation) = 0;

		/*!
		\brief               Retrieves the orientation of the layout
		\return              ClutterOrientation: the orientation of the layout
		*/
		virtual ClutterOrientation Direction(void) = 0;
		
		/*!
		\brief               Sets whether all columns of layout will have the same width
		\param               homogeneous [in] TRUE to make columns homogeneous
		*/
		virtual void EnableColumnHomogeneous(bool homogeneous) = 0;

		/*!
		\brief               Returns whether all columns of layout have the same width
		\return              bool: whether all columns of layout have the same width.
		*/
		virtual bool IsColumnHomogeneousEnable(void) = 0;
		
		/*!
		\brief               Sets whether all rows of layout will have the same height
		\param               homogeneous [in] TRUE to make rows homogeneous
		*/
		virtual void EnableRowHomogeneous(bool homogeneous) = 0;

		/*!
		\brief               Returns whether all rows of layout have the same height.
		\return              bool: whether all rows of layout have the same height.
		*/
		virtual bool IsRowHomogeneousEnable(void) = 0;

		/*!
		\brief               Sets the spacing between columns of layout 
		\param               spacing [in]the spacing between columns of the layout, in pixels
		*/
		virtual void SetColumnSpacing(float spacing)=0;

		/*!
		\brief               Retrieves the spacing between columns of layout
		\return              float: the spacing between coluns of layout 
		*/
		virtual float ColumnSpacing(void)=0;

		/*!
		\brief               Sets the spacing between rows of layout
		\param               spacing [in] the spacing between rows of the layout, in pixels
		*/
		virtual void SetRowSpacing(float spacing) = 0;

		/*!
		\brief               Retrieves the spacing between rows of layout
		\return              float: the spacing between rows of layout 
		*/
		virtual float RowSpacing(void) = 0;
	};
}
#endif //_HALO_ILAYOUT_H_
