#ifndef _HALO_IPAGECONTROL_H_
#define _HALO_IPAGECONTROL_H_

namespace HALO
{
	class HALO_API IPageControl : virtual public IActor
	{
	public:
		/*!
		\brief               Create a new page control
		\remarks             The parent is not recommended to NULL.
		\param               parent:[in]      The parent of rectangle.
		\param               width:[in]		  The width of rectangle.
		\param               height:[in]      The height of rectangle.
		\return              HALO::IPageControl *: The newly created page control instance pointer.
		\par Example:
		\code
			IPageControl* pageControl = IPageControl::CreateInstance(m_window, width, height);		
		\endcode
		\see                 IActor::CreateInstance()
		*/
		static IPageControl* CreateInstance(IActor* parent, float width, float height);
		static IPageControl* CreateInstance(Widget* parent, float width, float height);

	public:
		/*!
		\brief               Get current page sequence number
		\return              int: current page sequence number
		*/
		virtual int CurrentPage() const = 0;

		/*!
		\brief               Set current page number
		\param               curPage:[in]      current page number. The range is [1, NumberOfPages]
		\return              None
		*/
		virtual void SetCurrentPage(int curPage) = 0;

		/*!
		\brief               Get number of pages.
		\return              int: the total number of pages.
		*/
		virtual int NumberOfPages() const = 0;

		/*!
		\brief               Set total number of pages for page control
		\param               numPages:[in]      total number pages
		\return              None
		*/
		virtual void SetNumberOfPages(int numPages) = 0;

		/*!
		\brief               Set hide flag for single page
		\param               hideFlag:[in]  single page hide flag. Default value is true.
		\return              None
		*/
		virtual void SetHideForSinglePageFlag(bool hideFlag) = 0;

		/*!
		\brief               Get hide flag for single page
		\return              bool: Hide flag for single page
		*/
		virtual bool FlagHideForSinglePage() = 0;

		// TODO:
		virtual void SetPageIndicatorImage(IImageBuffer *imageBuffer) = 0;
		virtual void SetHighlightPageIndicatorImage(IImageBuffer *imageBuffer) = 0;

		virtual void SetPageIndicatorGap(float indicatorGap) = 0;
		virtual float PageIndicatorGap(void) = 0;

		virtual void SetPageIndicatorImageSize(float width, float height) = 0;
		virtual void PageIndicatorImageSize(float &width, float &height) = 0;
	};
}

#endif	//_HALO_IPageControl_H_