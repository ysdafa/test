#ifndef _HALO_ITOOLTIP_H_
#define _HALO_ITOOLTIP_H_

namespace HALO
{
	class HALO_API IToolTip : virtual public IActor
	{
	public:
		enum EToolTipTailSide
		{
			SIDE_UP = 0,
			SIDE_DOWN,
			SIDE_LEFT,
			SIDE_RIGHT
		};
		enum EToolTipTailPosition
		{
			POSITION_START = 0,
			POSITION_CENTER,
			POSITION_END
		};

	public:
		/*!
		\brief               Create a IToolTip instance.
		\remarks             If parent is NULL, this IToolTip will be a child of the Stage. The parent is not recommended to be NULL.
		\param               parent:[in] The parent of this IToolTip.
		\param               width: [in] The width of the IToolTip.
		\param               height:[in] The height of the IToolTip.
		\return              IToolTip*: a IToolTip instance
		*/
		static IToolTip* CreateInstance(IActor* parent, float width, float height);
		static IToolTip* CreateInstance(Widget* parent, float width, float height);

	public:
		/*!
		\brief:   Get IText actor instance
		\return:  IText*:   IText instance that is a member of IToolTip class.
		*/
		virtual IText* TextActor(void) = 0;

		/*!
		\brief               Sets the size of the IToolTip
		\param               width: [in] The new requested width, in pixels.
		\param               height: [in] The new requested height, in pixels.
		\return              None
		*/
		virtual void Resize(float width, float height) = 0;

		/*!
		\brief:   Sets the popup balloon's image of IToolTip
		\param               image: [in] The image's path.
		\return              None
		*/
		virtual void SetPopupImage(const std::string& image) = 0;

		/*!
		\brief:   Retrieves the popup balloon's image of IToolTip
		\return              image: The image's path.
		*/
		virtual std::string PopupImage(void) const = 0;

		/*!
		\brief:   Sets the tail's image of IToolTip
		\param               image: [in] The image's path.
		\return              None
		*/
		virtual void SetTailImage(const std::string& image) = 0;

		/*!
		\brief:   Retrieves the tail tail's image of IToolTip
		\return              string: The image's path.
		*/
		virtual std::string TailImage(void) const = 0;

		/*!
		\brief:   Sets the tail's position based on popup balloon.
		\param               side: [in] The tail's side relative to popup ballon.
		\param               position: [in] The tail's position relative to popup ballon's start.
		\return              None
		*/
		virtual void SetTailPosition(EToolTipTailSide side, EToolTipTailPosition position) = 0;

		/*!
		\brief:   Sets the tail's position based on popup balloon.
		\param               side: [in] The tail's side relative to popup ballon.
		\param               length: [in] The tail's offset length relative to popup ballon's start.
		\return              None
		*/
		virtual void SetTailPosition(EToolTipTailSide side, float length) = 0;

		/*!
		\brief:   Sets the tail's position based on popup balloon.
		\param               side: [in] The tail's side relative to popup ballon.
		\param              position: [in] The tail's position relative to popup ballon's start.
		\param              offset: [in] The tail's offset relative to popup ballon's edge.
		\return              None
		*/
		virtual void SetTailPosition(EToolTipTailSide side, EToolTipTailPosition position, float offset) = 0;

		/*!
		\brief:   Sets the tail's position based on popup balloon.
		\param               side: [in] The tail's side relative to popup ballon.
		\param               length: [in] The tail's offset length relative to popup ballon's start.
		\param              offset: [in] The tail's offset relative to popup ballon's edge.
		\return              None
		*/
		virtual void SetTailPosition(EToolTipTailSide side, float length, float offset) = 0;

		/*!
		\brief               Sets the size of the tail.
		\param               width: [in] The new requested width, in pixels.
		\param               height: [in] The new requested height, in pixels.
		\return              None
		*/
		virtual void SetTailSize(float width, float height) = 0;

		/*!
		\brief:   Sets the tail's offset relative to popup ballon's edge.
		\param              offset: [in] The tail's offset relative to popup ballon's edge.
		\return              None
		*/
		virtual void SetTailOffset(float offset) = 0;

		/*!
		\brief:   Retrieves  the tail's offset relative to popup ballon's edge.
		\return              offset:  The tail's offset relative to popup ballon's edge.
		*/
		virtual float TailOffset(void) const = 0;

		/*!
		\brief:   Set the label text in IToolTip.
		\param               text: [in] The text of label.
		\return              None
		*/
		virtual void SetText(const std::string& text) = 0;

		/*!
		\brief:   Retrieves label text in IToolTip.
		\return              string: The text of label.
		*/
		virtual std::string Text(void) const = 0;

		/*!
		\brief                Set text font in the IToolTip
		\param              font: [in]Font name.
		\return              None
		\par Example:
		\code
		SetFont("Sans 30px");
		\endcode
		*/
		virtual void SetFont(const std::string& font) = 0;

		/*!
		\brief:   Retrieves text font in the IToolTip
		\return              string: Font name.
		*/
		virtual std::string Font(void) const = 0;

		/*!
		\brief:   Sets text font size in IToolTip.
		\param              size: [in]  text font size
		\return              None
		*/
		virtual void SetFontSize(int size) = 0;

		/*!
		\brief:   Retrieves  the text font size in IToolTip.
		\return              size:  text font size
		*/
		virtual int FontSize(void) const = 0;

		/*!
		\brief:   Sets the label's background color of IToolTip
		\param               color: [in] The background color.
		\return              None
		*/
		virtual void SetTextColor(const ClutterColor& color) = 0;

		/*!
		\brief:   Sets the label's background color of IToolTip
		\param               color: [in] The background color.
		\return              None
		*/
		virtual void SetTextBackgroundColor(const ClutterColor& color) = 0;

		/*!
		\brief:   Sets the frame's background color of IToolTip
		\param               color: [in] The background color.
		\return              None
		*/
		virtual void SetFrameColor(const ClutterColor& color) = 0;

		/*!
		\brief:   Sets the width of frame.
		\param               width: [in] The width of frame.
		\return              None
		*/
		virtual void SetFrameWidth(float width) = 0;

		/*!
		\brief:   Retrieves the width of frame.
		\return              width: [in] The width of frame.
		*/
		virtual float FrameWidth(void) const = 0;
		
		/*!
		\brief:   Sets the up tail's image of IToolTip
		\param               image: [in] The image's path.
		\return              None
		*/
		virtual void SetUpTailImage(const std::string& image) = 0;

		/*!
		\brief:   Retrieves the up tail tail's image of IToolTip
		\return              string: The image's path.
		*/
		virtual std::string UpTailImage(void) const = 0;

		/*!
		\brief:   Sets the down tail's image of IToolTip
		\param               image: [in] The image's path.
		\return              None
		*/
		virtual void SetDownTailImage(const std::string& image) = 0;

		/*!
		\brief:   Retrieves the down tail tail's image of IToolTip
		\return              string: The image's path.
		*/
		virtual std::string DownTailImage(void) const = 0;

		/*!
		\brief:   Sets the left tail's image of IToolTip
		\param               image: [in] The image's path.
		\return              None
		*/
		virtual void SetLeftTailImage(const std::string& image) = 0;

		/*!
		\brief:   Retrieves the left tail tail's image of IToolTip
		\return              string: The image's path.
		*/
		virtual std::string LeftTailImage(void) const = 0;

		/*!
		\brief:   Sets the right tail's image of IToolTip
		\param               image: [in] The image's path.
		\return              None
		*/
		virtual void SetRightTailImage(const std::string& image) = 0;

		/*!
		\brief:   Retrieves the right tail tail's image of IToolTip
		\return              string: The image's path.
		*/
		virtual std::string RightTailImage(void) const = 0;

		/*!
		\brief               Set show time(ms).
		\param               time:[in] show time(ms).
		\return              None
		*/
		virtual void SetShowTime(guint time) = 0;

		/*!
		\brief               Set show time(ms).
		\return              gunit: show time(ms)
		*/
		virtual guint ShowTime() const = 0;
	};
}

#endif //_HALO_ITOOLTIP_H_
