#ifndef _HALO_ICOMPOSITEIMAGE_H_
#define _HALO_ICOMPOSITEIMAGE_H_

namespace HALO
{
	class HALO_API ICompositeImage : virtual public IActor
	{
	public:
		/*!
		\brief               Creates a new composite image control
		\remarks             if parent is NULL, this control will be a child of the Stage. The parent is not recommended to NULL.
		\param			     parent: [in] The parent of this control.
		\param               width: [in] Width of control in pixels.
		\param               height: [in] Height of control in pixels.
		\return              HALO::ICompositeImage *: The newly created composite image control
		\par Example:
		\code
		ICompositeImage* ICompositeImage = CreateInstance(IStage::GetInstance()->RootActor(), 800, 480);
		\endcode
		\see                 IStage::GetInstance()
		*/
		static ICompositeImage* CreateInstance(IActor* parent, float width, float height);
		/*!
		\brief               Creates a new composite image control
		\remarks             if parent is NULL, this control will be a child of the Stage. The parent is not recommended to NULL.
		\param			     parent: [in] The parent of this control.
		\param               width: [in] Width of control in pixels.
		\param               height: [in] Height of control in pixels.
		\return              HALO::ICompositeImage *: The newly created composite image control
		\par Example:
		\code
		ICompositeImage* ICompositeImage = CreateInstance(IStage::GetInstance()->RootActor(), 800, 480);
		\endcode
		\see                 IStage::GetInstance()
		*/
		static ICompositeImage* CreateInstance(Widget* parent, float width, float height);

	public:
		/*!
		\brief               Sets the content of the composite image control
		\remarks             Setting the image will clears any previous image content
		Default, the image content will be stretched to fill the control
		\param               imagePath: [in] the file path that will be loaded.
		\return              None
		*/
		virtual void SetImage(const char *imagePath) = 0;
		/*!
		\brief               Sets the content of the image control
		\remarks             Setting the image will clears any previous image content
		Default, the image content will be stretched to fill the control
		\param               buffer: [in] a pointer of imageBuffer.
		\return              None
		\par Example:
		\code
		IImageBuffer *imageBuffer = IImageBuffer::CreateInstance("d:/focus.png");
		ICompositeImage* image = ICompositeImage::CreateInstance(parent, 300, 200);
		image->SetImage(imageBuffer);
		\endcode
		*/
		virtual void SetImage(IImageBuffer *buffer) = 0;

		virtual const char* ImagePath(void) = 0;
	};
}

#endif //_HALO_ICOMPOSITEIMAGE_H_
