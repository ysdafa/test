#ifndef _IPOPUPRATING_H_
#define _IPOPUPRATING_H_

namespace HALO
{
	class HALO_API IPopupRatingListener : public IListener
	{
	public:
		enum EEventType
		{
			BUTTON_FOCUS_IN     = 0,	//!< button focus in event type.
			BUTTON_FOCUS_OUT,      	    //!< button focus out event type.
			BUTTON_CLICKED           	//!< button clicked event type.
		};
		typedef uint EEventTypes;		
		/*!
		\brief               process the event when the button is processed.
		\param               popupRating:[in] The selected popupRating. 
		\param               nButtonIndex:[in] the selected button index. 
		\param               eventType:[in] The selected button event type. 
		\return              bool
		*/
		virtual bool OnButtonEvent(class IPopupRating* popupRating, const int nButtonIndex, EEventTypes eventType) { return false; }
		/*!
		\brief               process the event when the any star icon is processed.
		\param               popupRating:[in] The selected popupRating. 
		\param               eventType:[in] The selected star icon event type. 
		\return              bool
		*/
		virtual bool OnStarIconEvent(class IPopupRating* popupRating, EEventTypes eventType) { return false; }
		/*!
		\brief               process the event when time out.
		\param               popupRating:[in] The selected popupRating. 
		\return              bool
		*/
		virtual bool OnTimeOut(class IPopupRating* popupRating) { return false; }
	};

	class HALO_API IPopupRating: virtual public IActor
	{
	public:
		enum EPopupRatingStarIcon
		{
			STAR_ICON_1    = 1,      	 //!< star icon 1.
			STAR_ICON_2,        	     //!< star icon 2.
			STAR_ICON_3,        	     //!< star icon 3.
			STAR_ICON_4,        	     //!< star icon 4.
			STAR_ICON_5,        	     //!< star icon 5.
			STAR_ICON_ALL              //!< All star icons.  
		};
		typedef uint EPopupRatingStarIcons;

		enum EPopupRatingArrowButton
		{
			ARROW_BUTTON_1    = 1,       //!< arrow button 1.
			ARROW_BUTTON_2,        	     //!< arrow button 2.
			ARROW_BUTTON_ALL             //!< All arrow buttons.  
		};
		typedef uint EPopupRatingArrowButtons;

		enum EPopupRatingButton
		{
			BUTTON_1    = 1,      	 //!< button 1.
			BUTTON_2,        	     //!< button 2.
			BUTTON_ALL               //!< All buttons.  
		};
		typedef uint EPopupRatingButtons;

		enum EPopupRatingType
		{
			BASE_LABEL_ONLY         = 0,	//!< base label only type.
			BASE_LABEL_WITH_POPUP           //!< base label with popup type.
		};
		typedef uint EPopupRatingTypes;

		struct TPopupRatingAttr
		{
			float x;		    //!< popupRating x position.
			float y;		    //!< popupRating y position.
			float w;		    //!< popupRating width.
			float h;		    //!< popupRating height.
			EPopupRatingTypes nPopupRatingType;   //!< popupRating type.
			bool bHasHalfMarkedStar;              //!< if has half marked star flag.  
			bool bAutoFlag;                       //!< Auto adjust popupRating, popupRatingRect.x and popupRatingRect.y will be disable.
			TPopupRatingAttr() : x(0), y(0), w(1280), h(720), nPopupRatingType(BASE_LABEL_WITH_POPUP), bHasHalfMarkedStar(false), bAutoFlag(true) {}
		};

	public:
		/*!
		\brief               Create a new popupRating
		\param               parent:[in] The parent of the popupRating. 
		\param               attr:[in] The popupRating attribute. 
		\return              HALO::IPopupRating *: A pointer to IPopupRating
		\par Example:
		\code
			IActor *m_window;
			IPopupRating *m_popupRating;
			IPopupRating::TPopupRatingAttr attr;
			attr.popupRatingRect.x = 0;
			attr.popupRatingRect.y = 200;
			attr.popupRatingRect.w = 1920;
			attr.popupRatingRect.h = 1080;
			attr.nPopupRatingType = m_popupRating->BASE_LABEL_WITH_POPUP;
			attr.bAutoFlag = true;
			m_popupRating = IPopupRating::CreateInstance(m_window ,attr);
		*/
		static IPopupRating* CreateInstance(IActor* parent, const TPopupRatingAttr &attr);
		static IPopupRating* CreateInstance( Widget* parent, const TPopupRatingAttr &attr );
	public:
		/*!
		\brief               Set the background color.
		\param               BGColor:[in] The background color. 
		\return              None 
		*/
		virtual void SetBGColor(const ClutterColor BGColor) = 0;
		/*!
		\brief               Set title text rect.
		\param               x:[in] title x position.
		\param               y:[in] title y position.
		\param               w:[in] title width.
		\param               h:[in] title height. 
		\return              None
		*/
		virtual void SetTitleRect(float x, float y, float w, float h) = 0;
		/*!
		\brief               Set title text.
		\param               pTitleText:[in] title text. 
		\return              None
		*/
		virtual void SetTitleText(const std::string& titleText) = 0;
		/*!
		\brief               Get title text.. 
		\return              std::string
		*/
		virtual std::string TitleText() const = 0;
		/*!
		\brief               Set the title text color.
		\param               textcolor:[in] The title text color. 
		\return              None 
		*/
		virtual void SetTitleTextColor(const ClutterColor textcolor) = 0;
		/*!
		\brief               Set the title text font.
		\param               font:[in] The text font. 
		\return              None
		*/
		virtual void SetTitleTextFont(const std::string& font) = 0;
		/*!
		\brief               Get the title text font.
		\return              std::string
		*/
		virtual std::string TitleTextFont() const = 0;
		/*!
		\brief               Set title text horizontal and vertical alignment.
		\param               hAlign: [in]Horizontal alignment value. 
		\param               vAlign: [in]Vertical alignment value. 
		\return              None
		*/
		virtual void SetTitleTextAlignment(EHAlignment hAlign, EVAlignment vAlign) = 0;
		/*!
		\brief               Set title line rect.
		\param               x:[in] title line x position.
		\param               y:[in] title line y position.
		\param               w:[in] title line width.
		\param               h:[in] title line height. 
		\return              None
		*/
		virtual void SetTitleLineRect(float x, float y, float w, float h) = 0;
		/*!
		\brief               Set title line color.
		\param               color:[in] The color which will be set to title line. 
		\return              None
		*/
		virtual void SetTitleLineColor(const ClutterColor color) = 0;
		/*!
		\brief               Set context text rect.
		\param               x:[in] context x position.
		\param               y:[in] context y position.
		\param               w:[in] context width.
		\param               h:[in] context height.
		\return              None
		*/
		virtual void SetContentRect(float x, float y, float w, float h) = 0;
		/*!
		\brief               Set content text.
		\param               pContentText:[in] Explain parameter here. 
		\return              None
		*/
		virtual void SetContentText(const std::string& contentText) = 0;
		/*!
		\brief               Get content text.
		\return              std::string
		*/
		virtual std::string ContentText() const = 0;
		/*!
		\brief               Set context text color.
		\param               textcolor:[in] The title text color. 
		\return              None 
		*/
		virtual void SetContentTextColor(const ClutterColor textcolor) = 0;
		/*!
		\brief               Set context text font.
		\param               font:[in] The text font. 
		\return              None
		*/
		virtual void SetContentTextFont(const std::string& font) = 0;
		/*!
		\brief               Get context text font.
		\return              std::string
		*/
		virtual std::string ContentTextFont() const = 0;
		/*!
		\brief               Set content text horizontal and vertical alignment.
		\param               hAlign: [in]Horizontal alignment value. 
		\param               vAlign: [in]Vertical alignment value. 
		\return              None
		*/
		virtual void SetContentTextAlignment(EHAlignment hAlign, EVAlignment vAlign) = 0;
		/*!
		\brief               Set star icon rect.
		\param               nStarIcon:[in] star icon index.
		\param               x:[in] star icon x position.
		\param               y:[in] star icon y position.
		\param               w:[in] star icon width.
		\param               h:[in] star icon height.
		\return              None
		*/
		virtual void SetStarIconRect(const EPopupRatingStarIcons nStarIcon, float x, float y, float w, float h) = 0;
		/*!
		\brief               Set star icon unmarked image.
		\param               imagePath:[in] the image path. 
		\return              None 
		*/
		virtual void SetStarIconUnmarkedImage(const std::string& imagePath) = 0;
		/*!
		\brief               Get star icon unmarked image.
		\return              std::string 
		*/
		virtual std::string StarIconUnmarkedImage() const = 0;
		/*!
		\brief               Set star icon marked image.
		\param               imagePath:[in] the image path. 
		\return              None 
		*/
		virtual void SetStarIconMarkedImage(const std::string& imagePath) = 0;
		/*!
		\brief               Get star icon marked image.
		\return              std::string 
		*/
		virtual std::string StarIconMarkedImage() const = 0;
		/*!
		\brief               Set star icon half marked image.
		\param               imagePath:[in] the image path. 
		\return              None 
		*/
		virtual void SetStarIconHalfMarkedImage(const std::string& imagePath) = 0;
		/*!
		\brief               Get star icon half marked image.
		\return              std::string 
		*/
		virtual std::string StarIconHalfMarkedImage() const = 0;
		/*!
		\brief               Set star icons' background rect.
		\param               x:[in] star icons' background x position.
		\param               y:[in] star icons' background y position.
		\param               w:[in] star icons' background width.
		\param               h:[in] star icons' background height. 
		\return              None
		*/
		virtual void SetStarIconsBGRect(float x, float y, float w, float h) = 0;
		/*!
		\brief               Set star icons' background color.
		\param               color:[in] The color which will be set to star icons' background. 
		\return              None
		*/
		virtual void SetStarIconsBGColor(const ClutterColor color) = 0;
		/*!
		\brief               Set arrow button rect.
		\param               nArrowButton:[in] arrow button index.
		\param               x:[in] arrow button x position.
		\param               y:[in] arrow button y position.
		\param               w:[in] arrow button width.
		\param               h:[in] arrowbutton height.
		\return              None
		*/
		virtual void SetArrowButtonRect(const EPopupRatingArrowButtons nArrowButton, float x, float y, float w, float h) = 0;
		/*!
		\brief               Set arrow button image.
		\param               EButtonState:[in] the button state. 
		\param               imagePath:[in] the image path. 
		\return              None 
		*/
		virtual void SetArrowButtonImage(const EPopupRatingArrowButtons nArrowButton, IButton::EButtonState state, const std::string& imagePath) = 0;
		/*!
		\brief               Set button rect.
		\param               nButton:[in] button index.
		\param               x:[in] button x position.
		\param               y:[in] button y position.
		\param               w:[in] button width.
		\param               h:[in] button height.
		\return              None
		*/
		virtual void SetButtonRect(const EPopupRatingButtons nButton, float x, float y, float w, float h) = 0;
		/*!
		\brief               Set button image.
		\param               nButton:[in] the button width. 
		\param               EButtonState:[in] the button state. 
		\param               imagePath:[in] the image path. 
		\return              None 
		*/
		virtual void SetButtonImage(const EPopupRatingButtons nButton, IButton::EButtonState state, const std::string& imagePath) = 0;
		/*!
		\brief               Set button background color.
		\param               nButton:[in] the button width. 
		\param               EButtonState:[in] the button state. 
		\param               color:[in] background color. 
		\return              None 
		*/
		virtual void SetButtonBackgroundColor(const EPopupRatingButtons nButton, IButton::EButtonState state, const ClutterColor color) = 0;
		/*!
		\brief               Set button text.
		\param               nButton:[in] the button width. 
		\param               EButtonState:[in] the button state. 
		\param               text:[in] the text.  
		\return              None 
		*/
		virtual void SetButtonText(const EPopupRatingButtons nButton, IButton::EButtonState state, const std::string& text) = 0;
		/*!
		\brief               Set button text color.
		\param               nButton:[in] the button width. 
		\param               EButtonState:[in] the button state. 
		\param               color:[in] the text color.  
		\return              None 
		*/
		virtual void SetButtonTextColor(const EPopupRatingButtons nButton, IButton::EButtonState state, const ClutterColor color) = 0;
		/*!
		\brief               Set button text font size.
		\param               nButton:[in] the button width. 
		\param               EButtonState:[in] the button state. 
		\param               fontSize:[in] the text font size.  
		\return              None 
		*/
		virtual void SetButtonTextFontSize(const EPopupRatingButtons nButton, IButton::EButtonState state, int fontSize) = 0;
		/*!
		\brief               Set button text border color.
		\param               nButton:[in] the button width. 
		\param               EButtonState:[in] the button state. 
		\param               color:[in] the border color.  
		\return              None 
		*/
		virtual void SetButtonBorderColor(const EPopupRatingButtons nButton, IButton::EButtonState state, const ClutterColor& color) = 0;
		/*!
		\brief               Set button text border width.
		\param               nButton:[in] the button width. 
		\param               EButtonState:[in] the button state. 
		\param               width:[in] the border width.  
		\return              None 
		*/
		virtual void SetButtonBorderWidth(const EPopupRatingButtons nButton, IButton::EButtonState state, float width) = 0;
		/*!
		\brief               Set the default focus by button index.
		\param               nButton:[in] The button enum index. 
		\return              none. 
		*/
		virtual void SetDefaultFocus(int nButton) = 0;
		/*!
		\brief               Get the default focus button.
		\return              uint: Button index.  
		*/
		virtual int DefaultFocus() const = 0;
		/*!
		\brief               Set the marked star icon number.
		\param               nMarkedStarIconNumber:[int] The marked star icon number, range: 0~10, odd number has half marked star, such as:3 is one and half star. 
		*/
		virtual void SetMarkedStarIconNumber(int markedStarIconNumber) = 0;
		/*!
		\brief               Get the marked star icon number.
		\return              int: the marked star icon number.  
		*/
		virtual int MarkedStarIconNumber() const = 0;
		/*!
		\brief               Add IPopRatingListener.
		\param               listener:[in] IPopupRatingListener rewrite by user. 
		\return              None 
		*/
		virtual bool AddListener(IPopupRatingListener* listener) = 0;
		/*!
		\brief               Remove IPopRatingListener.
		\return              None 
		*/
		virtual bool RemoveListener(IPopupRatingListener* listener) = 0;
		/*!
		\brief               Support the TTS or not.
		\param               bSupport:[in] If the bSupport is true, will support TTS, otherwise not. 
		\return              None
		*/
		virtual void SetSupportTTS(bool bSupport) = 0;
		/*!
		\brief               Get flag about support TTS or not.
		\return              bool
		*/
		virtual bool SupportTTS() const = 0;
		/*!
		\brief               Set show time(ms).
		\param               nShowTime:[in] show time(ms). 
		\return              None
		*/
		virtual void SetShowTime(guint nShowTime) = 0;
		/*!
		\brief               Set show time(ms).
		\return              show time(ms)
		*/
		virtual guint ShowTime() const = 0;
	};
}
#endif