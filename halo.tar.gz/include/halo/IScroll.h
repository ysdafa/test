#ifndef _HALO_ISCROOL_H_
#define _HALO_ISCROOL_H_

namespace HALO
{
	enum EValueChangedType
	{
		E_TYPE_SETVALUE,
		E_TYPE_CLICK,
		E_TYPE_DRAG
	};
	class HALO_API IScrollListener : public IListener
	{
	public:
		/*!
		\brief               When scroll value changed, this function will be called
		\param               scroll:[in]      scroll subject
		\return              bool: not used
		*/
		virtual bool OnValueChanged(class IScroll* scroll, EValueChangedType type) = 0;
	};

	class HALO_API IScroll : virtual public IActor
	{
	public:
		/*!
		\brief               Create a new scroll bar
		\remarks             The parent is not recommended to NULL.
		\param               parent:[in]      The parent of rectangle.
		\param               width:[in]		  The width of rectangle.
		\param               height:[in]      The height of rectangle.
		\return              HALO::IScroll *: The newly created scroll instance pointer.
		\par Example:
		\code
			IScroll* scroll = IScroll::CreateInstance(m_window, width, height);		
		\endcode
		\see                 IActor::CreateInstance()
		*/
		static IScroll* CreateInstance(IActor* parent, float width, float height, EDirectionType direction);
		static IScroll* CreateInstance(Widget* parent, float width, float height, EDirectionType direction);

	public:
		/*!
		\brief               Add listener to current scroll
		\param               listener:[in]      scroll listener
		\return              bool: not used
		*/
		virtual bool AddListener(IScrollListener* listener) = 0;

		/*!
		\brief               Remove scroll listener
		\param               listener:[in]      scroll listener
		\return              bool: not used
		*/
		virtual bool RemoveListener(IScrollListener* listener) = 0;

	public:

		virtual EDirectionType DirectionType(void) const = 0;

		/*!
		\brief               Sets the minimum value of SCScroll window.
		\param               minValue:[in]      minimum value
		\return              None
		*/
		virtual void SetMinValue(int minValue) = 0;

		/*!
		\brief               Get the minimum value of SCScroll window.
		\return              int: minimum value
		*/
		virtual int MinValue(void) const = 0;

		/*!
		\brief               Sets the maximum value of SCScroll bar.
		\param               maxValue:[in]      maximum value 
		\return              None
		*/
		virtual void SetMaxValue(int maxValue) = 0;

		/*!
		\brief               Get maximum value
		\return              int: maximum value 
		*/
		virtual int MaxValue(void) const = 0;

		/*!
		\brief               Set current value
		\param               value:[in]      current value
		\return              None
		*/
		virtual void SetValue(int value) = 0;
		/*!
		\brief               Get current value
		\return              int: current value
		*/
		virtual int Value(void) const = 0;

		virtual void SetMinCurMaxValue(int minValue, int curValue, int maxValue) = 0;
		virtual void GetMinCurMaxValue(int &minValue, int &curValue, int &maxValue) const = 0;

		virtual void SetActive(bool flagActive) = 0;
		virtual bool FlagActive(void) const = 0;

		// background color: will be override in CScroll
		//virtual void SetBackgroundColor(const ClutterColor& topTrackColor) = 0;
		//virtual const ClutterColor& BackgroundColor(void) = 0;

		// track shadow area: normal/over state
		virtual void SetTrackShadowColor(const ClutterColor& bottomTrackColor) = 0;
		virtual const ClutterColor& TrackShadowColor(void) const = 0;

		virtual void SetTrackShadowHeight(float bottomTrackHeight) = 0;
		virtual float TrackShadowHeight(void) const = 0;
		
		// background image: pointing normal
		virtual void SetPointingNormalBackgroundImage(const std::string& pointingNormalBackgroundImage) = 0;
		virtual std::string PointingNormalBackgroundImage(void) const = 0;

		// background image: pointing over state
		virtual void SetPointingOverBackgroundImage(const std::string& pointingOverBackgroundImage) = 0;
		virtual std::string PointingOverBackgroundImage(void) const = 0;

		virtual void SetRolloverTrackHeight(float height) = 0;
		virtual float RolloverTrackHeight(void) const = 0;

		// Thumb Image: pointing normal
		virtual void SetPointingNormalThumbImage(const std::string& pointingNormalThumbImagePath) = 0;
		virtual std::string PointingNormalThumbImage(void) const = 0;

		virtual void SetPointingNormalThumbSize(float width, float height) = 0;
		virtual void GetPointingNormalThumbSize(float &width, float &height) = 0;

		// Thumb Image: pointing over
		virtual void SetPointingOverThumbImage(const std::string& pointingOverThumbImagePath) = 0;
		virtual std::string PointingOverThumbImage(void) const = 0;

		virtual void SetPointingOverThumbSize(float width, float height) = 0;
		virtual void GetPointingOverThumbSize(float &width, float &height) = 0;

		// Thumb Image: pointing focus
		virtual void SetPointingFocusThumbImage(const std::string& pointingFocusThumbImagePath) = 0;
		virtual std::string PointingFocusThumbImage(void) const = 0;

		virtual void SetPointingFocusThumbSize(float width, float height) = 0;
		virtual void GetPointingFocusThumbSize(float &width, float &height) = 0;
		
	public:
		// not using now

		/*!
		\brief               Set thumb image
		\param               state:[in]      button state
		\param               imageBuffer:[in]      image buffer
		\return              None
		*/
		//virtual void SetThumbImage(IButton::EButtonState state, IImageBuffer* imageBuffer) = 0;

		//virtual void SetThumbColor(IButton::EButtonState state, const ClutterColor& color) = 0;
		//virtual const ClutterColor& ThumbColor(IButton::EButtonState state) = 0;

		/*!
		\brief               Set thumb width and height
		\param               width:[in]			thumb width
		\param               height:[in]		thumb height
		\return              None
		*/
		//virtual void SetThumbSize(float width, float height) = 0;

		/*!
		\brief               Get thumb size
		\param               width:[out]		thumb width
		\param               height:[out]		thumb height
		\return              None
		*/
		//virtual void GetThumbSize(float &width, float &height) const = 0;

		/*!
		\brief               Set previous arrow image
		\param               state:[in]				button state
		\param               imageBuffer:[in]		image buffer
		\return              None
		*/
		virtual void SetPreviousArrowImage(IButton::EButtonState state, const std::string& imagePath) = 0;


		// Do we need these two arrow size API?
		/*!
		\brief               Set PreviousArrow size
		\param               width:[in]			arrow width
		\param               height:[in]		arrow height
		\return              None
		*/
		virtual void SetPreviousArrowSize(float width, float height) = 0;

		/*!
		\brief               Get PreviousArrow size
		\param               width:[out]		arrow width
		\param               height:[out]		arrow height
		\return              None
		*/
		virtual void GetPreviousArrowSize(float &width, float &height) = 0;

		/*!
		\brief               Set NextArrow image
		\param               state:[in]				button state
		\param               imageBuffer:[in]		image buffer
		\return              None
		*/
		virtual void SetNextArrowImage(IButton::EButtonState state, const std::string& imagePath) = 0;

		/*!
		\brief               Set NextArrow size
		\param               width:[in]			NextArrow width
		\param               height:[in]		NextArrow height
		\return              None
		*/
		virtual void SetNextArrowSize(float width, float height) = 0;

		/*!
		\brief               Get NextArrow size
		\param               width:[out]		NextArrow width
		\param               height:[out]		NextArrow height
		\return              None
		*/
		virtual void GetNextArrowSize(float &width, float &height) = 0;

		virtual void SetLongPressIntervalOnArrowButton(int timeInterval) = 0;
		virtual void SetMovingStepOnArrowButton(int moveStep) = 0;
	};
}

#endif //_HALO_ISCROOL_H_