#ifndef _IUTILITY_H_
#define _IUTILITY_H_

namespace HALO
{
	class ListenerSet;
	class HALO_API IUtility : public Instance
	{
	public:
		typedef enum _Color_Category
		{
			CC_BLACK,
			CC_WHITE,
		}ColorCategory;

		typedef enum _Interpolator_Category
		{
			IC_LINEAR,
			IC_BEZIER,
		}InterpolatorCategory;

		typedef enum _EResolution
		{
			RESOLUTION_1080,
			RESOLUTION_720,
			RESOLUTION_21_9,

			RESOLUTION_MAX,
		}EResolution;

	public:
		/*!
		\brief               Get an single instance of IUtility.
		\return              The single instance.
		*/
		static IUtility* GetInstance(void);
	public:
		/*!
		\brief               Extract color from given color
		\param               from_r [in] r channel of given color.
		\param               from_g [in] g channel of given color.
		\param               from_b [in] b channel of given color.
		\param               to_r [out] r channel of extract color.
		\param               to_g [out] g channel of extract color.
		\param               to_b [out] b channel of extract color.
		\return              true is success.
		*/
		virtual bool ExtractForegroundColor(unsigned int from_r, unsigned int from_g, unsigned int from_b, unsigned int *to_r, unsigned int * to_g, unsigned int* to_b) = 0;

		/*!
		\brief               Retrieve the color category.
		\param               from_r [in] r channel of given color.
		\param               from_g [in] g channel of given color.
		\param               from_b [in] b channel of given color.
		\return              the color category.
		*/
		virtual ColorCategory ExtractIconColor(unsigned int from_r, unsigned int from_g, unsigned int from_b) = 0;

		/*!
		\brief               Get Current Resolution
		\param               hRes [out] horizontal size of resolution.
		\param               vRes [out] vertical size of resolution.
		\return              true or false. 
		*/
		virtual bool GetCurrentResolution(int& hRes, int& vRes) = 0;

		/*!
		\brief               Get Current Resolution
		\param               None
		\return              Resolution. 
		*/
		virtual EResolution GetCurrentResolution(void) = 0;

		/*!
		\brief               Destroy asynchronous
		\remarks             if target widget delete itself using this interface. 
		\param               parent: [in] The target widget would be destroyed.
		\return              true or false
		\par Example:
		\code
		IActor::TWindowAttr attr(800, 480);
		attr.bgColor = *CLUTTER_COLOR_Blue;
		attr.alpha = 150;
		IActor* actor = CreateInstance(IStage::GetInstance()->RootActor(), attr);
		IUtility::GetIntance()->AsyncRelease(actor);
		actor = NULL;
		\endcode
		*/
		virtual bool AsyncRelease(Widget* target) = 0;
		virtual bool AsyncReleaseListenerSet(ListenerSet* target) = 0;
		virtual float GetInterpolatedValue(int type, float input) = 0;

		/*!
		\brief               Get Orientation
		\remarks             get orientation 
		\return              orientation:
		\par Example:
		\code
		IUtility::GetIntance()->GetOrientation();
		\endcode
		*/
		virtual void SetOrientation(EOrientation orientation) = 0;
		virtual EOrientation GetOrientation(void) const = 0;
		virtual void ApplyOrientation(void) = 0;

		virtual void EnableHighContrast(const bool enable) = 0;
		virtual bool IsHighContrastEnabled(void) const = 0;
		
		virtual void EnableEnlarge(const bool enable) = 0;
		virtual bool IsEnlargeEnabled(void) const = 0;


		virtual bool IsCursorVisible(void) = 0;
		virtual void Enable720P(const bool enable) = 0;
		virtual bool Is720PEnabled(void) const = 0;
	private:
		static IUtility* g_Utility;
	};
}

#endif //_IUTILITY_H_
