#ifndef _IUTILITY_H_
#define _IUTILITY_H_

namespace HALO
{
	class HALO_API IUtility : public Instance
	{
	public:
		/*!
		\brief               Get an single instance of IUtility.
		\return              The single instance.
		*/
		static IUtility* GetInstance(void);
	public:
		/*!
		\brief               Extract color from given color
		\param               from_r [in] r channel of given color.
		\param               from_g [in] g channel of given color.
		\param               from_b [in] b channel of given color.
		\param               to_r [out] r channel of extract color.
		\param               to_g [out] g channel of extract color.
		\param               to_b [out] b channel of extract color.
		\return              true is success.
		*/
		virtual bool ExtractForegroundColor(unsigned int from_r, unsigned int from_g, unsigned int from_b, unsigned int *to_r, unsigned int * to_g, unsigned int* to_b) = 0;

		/*!
		\brief               Get Current Resolution
		\param               hRes [out] horizontal size of resolution.
		\param               vRes [out] vertical size of resolution.
		\return              true or false. 
		*/
		virtual bool GetCurrentResolution(int& hRes, int& vRes) = 0;

		/*!
		\brief               Destroy asynchronous
		\remarks             if target widget delete itself using this interface. 
		\param               parent: [in] The target widget would be destroyed.
		\return              true or false
		\par Example:
		\code
		IActor::TWindowAttr attr(800, 480);
		attr.bgColor = *CLUTTER_COLOR_Blue;
		attr.alpha = 150;
		IActor* actor = CreateInstance(IStage::GetInstance()->RootActor(), attr);
		IUtility::GetIntance()->AsyncRelease(actor);
		actor = NULL;
		\endcode
		*/
		virtual bool AsyncRelease(Widget* target) = 0;

	private:
		static IUtility* g_Utility;
	};
}

#endif //_IUTILITY_H_
