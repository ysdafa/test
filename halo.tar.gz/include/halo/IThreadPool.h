#ifndef _HALO_ITHREADPOOL_H_
#define _HALO_ITHREADPOOL_H_

namespace HALO
{
	class HALO_API IThreadPool : public Instance
	{
	public:

		/*!
		\brief               Create an instance of IThreadPool.
		\return              The new created instance. 
		\note                Create Thread Pool with default maxThreadCount(30), default minReserveThreadCount(0), default maxPendingTaskCount(-1, no limit)
		*/
		static IThreadPool* CreateInstance(void);

		/*!
		\brief               Create an instance of ITreadPool with maxThreadCount.
		\param               maxThreadCount [in] The number of max thread count. 
		\return              The new created instance
		\note                Create Thread Pool with given maxThreadCount, default minReserveThreadCount(0), default maxPendingTaskCount(-1, no limit)
		*/
		static IThreadPool* CreateInstance(int maxThreadCount);

		/*!
		\brief               Create an instance of ITreadPool with maxThreadCount and minReserveThreadCount.
		\param               maxThreadCount [in] The number of max thread count. 
		\param               minReserveTheadCount [in] The number of min reserve thread count. 
		\return              The new created instance.
		\note                Create Thread Pool with given maxThreadCount, given minReserveThreadCount, default maxPendingTaskCount(-1, no limit)
		*/
		static IThreadPool* CreateInstance(int maxThreadCount, int minReserveTheadCount);

		/*!
		\brief               Create an instance of ITreadPool with maxThreadCount and minReserveThreadCount, maxPendingTaskCount.
		\param               maxThreadCount [in] The number of max thread count. 
		\param               minReserveTheadCount [in] The number of min reserve thread count.
		\param               maxPendingTaskCount [in] The number of max pending task count. 
		\return              The new created instance.
		\see                 Create Thread Pool with given maxThreadCount, given minReserveThreadCount, given maxPendingTaskCount
		*/
		static IThreadPool* CreateInstance(int maxThreadCount, int minReserveTheadCount, int maxPendingTaskCount);
	};
}

#endif