#ifndef _IPINPOPUP_H_
#define _IPINPOPUP_H_

namespace HALO
{
	class HALO_API IPinPopupListener : public IListener
	{
	public:
		enum EEventType
		{
			BUTTON_FOCUS_IN     = 0,	//!< button focus in event type.
			BUTTON_FOCUS_OUT,      	    //!< button focus out event type.
			BUTTON_CLICKED,				//!< button clicked event type.
			BUTTON_PRESSED				//!< button pressed event type.
		};
		typedef uint EEventTypes;		
	public:
		virtual bool OnValidConfirm(class IPinPopup* list ,  bool isPassWordRight) { return false;};
		virtual bool OnCompareConfirm(class IPinPopup* list ,  bool isPassWordRight , const char* pin1Pwd , const char* pin2Pwd) { return false;};
		virtual bool OnButtonEvent(class IPinPopup* pinpopup, const int nButtonIndex, EEventTypes eventType) { return false; };
	};
	class HALO_API IPinPopup : virtual public IActionPopup
	{
	public:


		enum EInputBoxState
		{
			E_STATE_NORMAL = 0,
			E_STATE_FOCUSED,
			E_STATE_ALL,
		};

		enum EInputItemsState
		{
			E_STATE_NOINPUT = 0,
			E_STATE_FINISHINPUT,
			E_STATE_INPUT_ALL
		};

		enum E_PINNUMBER_TYPE
		{
			E_PINNUMBER_ONE = 0,
			E_PINNUMBER_TWO = 1,
			E_PINNUMBER_ALL = 3
		};

		enum EPinPopupButton
		{
			BUTTON_1    = 1,      	 //!< button 1.
			BUTTON_2,        	     //!< button 2.
			BUTTON_ALL               //!< All buttons.  
		};
		typedef uint EPinPopupButtons;

		struct TPinPopupAttr : public TActionPopupAttr
		{
			bool isAutoArrange;
			bool isContent;
			int buttonNum;
			E_PINNUMBER_TYPE pinType;
			TPinPopupAttr() : pinType(E_PINNUMBER_ONE) , isContent(true), buttonNum(0) , isAutoArrange(true){}
		};
	public:
		static IPinPopup* CreateInstance(IActor *parent , const TPinPopupAttr &attr);
		static IPinPopup* CreateInstance(Widget *parent , const TPinPopupAttr &attr);
	public:
		virtual void SetContentText(const std::string& text) = 0;

		virtual  std::string ContentText(void) const = 0;

		virtual void SetContentRect(float xPos , float yPos ,float width , float height) = 0;

		virtual void SetContentTextFont(const std::string& font) = 0;

		virtual std::string ContentTextFont(void) const = 0;

		virtual void SetContentTextFontSize(int fontSize) = 0;

		virtual int ContentTextFontSize(void) const = 0;

		virtual void SetContentTextFontColor(const ClutterColor textcolor) = 0;

		virtual ClutterColor ContentTextFontColor(void) const = 0;

		virtual void SetPinBoxBackGroundImage(EInputBoxState pinstate , const std::string& iconPath) = 0;

		virtual void SetPinBoxItemImage(EInputItemsState inputboxState  , const std::string& iconPath) = 0;

		virtual void SetPinBoxDescriptionText(E_PINNUMBER_TYPE pinType , const char* pinTitle) = 0;

		virtual void SetPinBoxDescriptionRect(E_PINNUMBER_TYPE pinType , float xPos , float yPos ,float width , float height) = 0;

		virtual void SetPinBoxDescriptionTextFontSize(E_PINNUMBER_TYPE pinType , int fontSize) = 0;

		virtual void SetPinBoxDescriptionTextColor(E_PINNUMBER_TYPE pinType , const ClutterColor textcolor) = 0;

		virtual void SetPinBoxItemDigitFontSize(int digitsize) = 0;

		virtual int PinBoxItemDigitFontSize(void) const = 0;

		virtual void SetPinBoxItemDigitColor(const ClutterColor textcolor) = 0;

		virtual ClutterColor PinBoxItemDigitColor(void) const = 0;

		virtual void SetPinBoxItemDigitFont(const std::string& font) = 0;

		virtual  std::string PinBoxItemDigitFont(void) const = 0;

		virtual void ResetPassWord(E_PINNUMBER_TYPE pinType) = 0;

		virtual void SetPinBoxFocus(E_PINNUMBER_TYPE pinType) = 0;

		virtual void SetButtonRect(const EPinPopupButtons nButton, float x, float y, float w, float h) = 0;

		virtual void SetButtonPosition(const EPinPopupButtons nButton, float x, float y) = 0;

		virtual void SetButtonSize(const EPinPopupButtons nButton, float w, float h) = 0;
		
		virtual void SetButtonImage(const EPinPopupButtons nButton, IButton::EButtonState state, const std::string& imagePath) = 0;
		
		virtual void SetButtonText(const EPinPopupButtons nButton, IButton::EButtonState state, const std::string& text) = 0;
		
		virtual void SetButtonTextColor(const EPinPopupButtons nButton, IButton::EButtonState state, const ClutterColor color) = 0;
		
		virtual void SetButtonTextFontSize(const EPinPopupButtons nButton, IButton::EButtonState state, int fontSize) = 0;

		virtual void SetButtonBackgroundColor(const EPinPopupButtons nButton, IButton::EButtonState state, const ClutterColor color) = 0;

		virtual void SetPinBoxRect(E_PINNUMBER_TYPE pinType, float x , float y ,float w, float h) = 0;

		virtual void SetDigitTextSize(float parentW, float parentH) = 0;

		virtual void SetDigitGap(float gap) = 0;

		virtual void SetInputItemsGap(EInputItemsState inputboxState , float gap) = 0;

		virtual void SetInputBoxItemSize(EInputItemsState inputboxState , float w , float h) = 0; 

		virtual bool AddListener(class IPinPopupListener* listener) = 0;

		virtual bool RemoveListener(class IPinPopupListener* listener) = 0;
	};
}
#endif