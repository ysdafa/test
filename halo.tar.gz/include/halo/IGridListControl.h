#ifndef _HALO_IGRIDLAYOULISTCONTROL_H_
#define _HALO_IGRIDLAYOULISTCONTROL_H_

namespace HALO
{
	class HALO_API IGridListControlListener : public IListener
	{
	public:
		//! Item load listener 
		virtual bool OnItemLoaded(class IGridListControl* list, int groupIndex, int itemIndex)         { return false; }
		//! Item unload listener
		virtual bool OnItemUnloaded(class IGridListControl* list, int groupIndex, int itemIndex)	   { return false; }
		//! Item load asynchronously listener
		virtual bool OnAsyncItemLoad(class IGridListControl *list, int groupIndex, int itemIndex)      { return false; }
		//! Focus change listener
		virtual bool OnFocusChanged(class IGridListControl *list, int fromGroupIndex, int fromItemIndex, int toGroupIndex, int toItemIndex) { return false; }
		//! Focus change motion start listener
		virtual bool OnFocusChangeMotionStart(class IGridListControl* list, int fromGroupIndex, int fromItemIndex, int toGroupIndex, int toItemIndex){ return false; }
		//! If there's no more move for MoveFocus() function.
		virtual bool OnMoveOut(class IGridListControl* list, EDirection direction, int fromGroupIndex, int fromItemIndex){ return false; }
		//! Item index changes listener 
		virtual bool OnItemIndexChanged(class IGridListControl* list, int fromGroupIndex, int fromItemIndex, int toGroupIndex, int toItemIndex){ return false; };
		//! Item clicked listener 
		virtual bool OnItemClicked(class IGridListControl* list, int groupIndex, int itemIndex)         { return false; }
		//! Item long pressed enter key listener
		virtual bool OnEnterKeyLongPressed(class IGridListControl *list, int groupIndex, int itemIndex) { return false; }
	};

	class HALO_API IGridListControl : virtual public IDataListControl
	{	
	public:

		struct TGridListControlAttr : public TDataListControlAttr
		{
			float titleSpace;          //!< space between group's title and content
			float groupSpace;          //!< space between groups
			float cellSpace;           //!< space between cells
			float focusRangeOffset[2]; //!< focus range offset, both right and left side.

			EDirectionType directionType;

			TGridListControlAttr(float inWidth, float inHeight) : TDataListControlAttr(inWidth, inHeight), titleSpace(0), groupSpace(0), cellSpace(0), directionType(TYPE_HORIZONTAL)
			{
				focusRangeOffset[0] = focusRangeOffset[1] = 0;
			}
		};

		enum EAniType
		{
			ANITYPE_FOCUS_MOVE = 0,   //!< animation type is focus moving
			ANITYPE_STYLE_TRANS,      //!< animation type is style transformation
			
			ANITYPE_MAX				  //!< end of enum value
		};

	public:
		/*!
		\brief:  Create an instance of IGridListControl with given attribute.                                 
		\remarks:                            
		\param: IActor * parent [in] the parent actor where grid list control will be created on.
		\param: const TGridListControlAttr & attr [in] the attribute of the grid list control.
		\return: IGridListControl*:  return the pointer of an new grid list control instance.
		\par Example:
		\code       
		 IStage* stage = IStage::GetInstance();
		 TGridListControlAttr attr(1920,1080);
		 IGridListControl* gridListControl = CreateIntance(stage->RootActor(), attr);
		\endcode                               
		*/
		static IGridListControl* CreateInstance(IActor* parent, const TGridListControlAttr &attr);

		static IGridListControl* CreateInstance(Widget* parent, const TGridListControlAttr &attr);
	
	
	public:
		
		/*!
		\brief:   Get the data source of grid list control.                              
		\remarks: After created an instance of grid list control, user can get the data source by this API, then he can do data operation.                         
		\param:   void
		\return:  IGridDataSource *:   Return the pointer of the data source instance.                            
		*/
		virtual IGridDataSource * DataSource(void) = 0;

		/*!
		\brief:   Add an listener to list.                                                      
		\param:   IGridListControlListener * listener [in] the listener pointer to be added.
		\return:  bool:   If the listener is successfully added, return true, else return false.
		\see:     RemoveListListener                                                              
		*/
		virtual bool AddListListener(IGridListControlListener *listener) = 0;

		/*!
		\brief:   Remove listener from list.                               
		\remarks:                            
		\param:   IGridListControlListener * listener [in] the listener pointer to be removed.
		\return:  bool:    If the listener is successfully removed, return true, else return false.
		\see:     AddListListener                                                                
		*/
		virtual bool RemoveListListener(IGridListControlListener* listener) = 0;

		/*!
		\brief:   Add given number of group to list   
		\remarks: Inner group index start from 0. The grid list control can add multiple groups. Inside each group, multiple styles can be added.
		\param:   int numberOfGroup [in] the number of group to be added.
		\return:  void:  
		\see:     AddStyle, AddColumn, AddRowToColumn, AddRowToAllColumn   
		*/
		virtual void AddGroup(int numberOfGroup) = 0;

		/*!
		\brief:    Add given number of style to grid list control                                
		\remarks:  Inner style index start from 0. This API will add same number of styles to each group. Inside each style, column infos should be added.                        
		\param:    int numOfStyle [in] the number of style that will be added to each group.
		\return:   bool: If styles are added successfully, return true.    
		\see:      AddGroup, AddColumn, AddRowToColumn, AddRowToAllColumn   
		*/
		virtual bool AddStyleToAllGroup(int numOfStyle) = 0;

		/*!
		\brief:    Get current style index of grid list control.                                
		\remarks:  Inner grid list control, there maybe several styles, each group has the same style.\n
				   The default style index is set to 0.
		\param:    void
		\return:   int:  The style index that the control is using currently. 
		\see:      SetGroupStyle                                                               
		*/
		virtual int CurrentStyle(void) = 0;

		/*!
		\brief:   Set grid list control current style index.                              
		\remarks: Grid list control current style index is set to be 0 in default. This function can change current style index.                          
		\param:   int styleIndex [in] the style index that current style will be changed to.
		\return:  bool:  If current style equals to the style index, return false, else return true. 
		\see:     GroupStyle                                
                                  
		*/
		virtual bool SetStyle(int styleIndex) = 0;

		/*!
		\brief:   Add a column to given group in given style                              
		\remarks: Inner column index start from 0. This API will add an column to given style of give group. Inside each column, row infos should be added.                           
		\param:   int groupIndex [in] the group that the column will be added to.
		\param:   int styleIndex [in] the group's style that the column will be added to.
		\param:   float columnWidth [in] the width of the column that will be added to the given style.
		\return:  int:  Return the column index in the group.
		\par Example:
		\code       
			IStage* stage = IStage::GetInstance();
			TGridListControlAttr attr(1920,1080);
			IGridListControl* gridListControl = CreateIntance(stage->RootActor(), attr);
			gridListControl->AddGroup(1);
			gridListControl->AddStyle(2);
			gridListControl->AddColumn(0, 0, 200);//add an column with width 200 to group 0 style 0
			gridListControl->AddColumn(0, 1, 200);//add an column with width 200 to group 0 style 1
		\endcode
		\see:  AddGroup, AddStyle, AddRowToColumn, AddRowToAllColumn                                                                
		*/
		virtual int AddColumn(int groupIndex, int styleIndex, float columnWidth) = 0;

		/*!
		\brief:   Add a row to given column in given group of given style                                
		\remarks: This function can only add one row to given column once. If you want to add same row to all columns, please refer to AddRowToAllColumn                           
		\param:   int groupIndex  [in] the group that the column will be added to.
		\param:   int styleIndex  [in] the group's style that the column will be added to.
		\param:   int columnIndex [in] the style's column that the row will be added to.
		\param:   float rowHeight [in] the height of the row that will be added to the given column.
		\return:  bool:  If the row was added successfully, return true. 
		\par Example:
		\code       
			IStage* stage = IStage::GetInstance();
			TGridListControlAttr attr(1920,1080);
			IGridListControl* gridListControl = CreateIntance(stage->RootActor(), attr);
			gridListControl->AddGroup(1);
			gridListControl->AddStyle(2);
			gridListControl->AddColumn(0, 0, 200);
			gridListControl->AddRowToColumn(0, 0, 0, 100); //add an row with height 100 to group 0 style 0 column 0
		\endcode
		\see:    AddGroup, AddStyle, AddColumn, AddRowToAllColumn                                                                
		*/
		virtual bool AddRowToColumn(int groupIndex, int styleIndex, int columnIndex, float rowHeight) = 0;

		/*!
		\brief:   Add a row to all column in given group of given style                                
		\remarks: This function can the same hight of row to each column of the given style once and it can be used to add regular cells quickly.                          
		\param:   int groupIndex  [in] the group that the column will be added to.
		\param:   int styleIndex  [in] the group's style that the column will be added to.
		\param:   float rowHeight [in] the height of the row that will be added to the given column.
		\return:  bool:  If the row was added successfully, return true. 
		\par Example:
		\code       
			IStage* stage = IStage::GetInstance();
			TGridListControlAttr attr(1920,1080);
			IGridListControl* gridListControl = CreateIntance(stage->RootActor(), attr);
			gridListControl->AddGroup(1);
			gridListControl->AddStyle(2);
			for(int i=0; i<10; i++) //add 10 columns to group 0 style 0
			{
				gridListControl->AddColumn(0, 0, 200);
			}
			gridListControl->AddRowToAllColumn(0, 0, 100); //add an row with height 100 to each column of group 0 style 0
		\endcode
		\see:  AddGroup, AddStyle, AddColumn, AddRowToColumn                                                                   
		*/
		virtual bool AddRowToAllColumn(int groupIndex, int styleIndex, float rowHeight) = 0;
 
		/*!
		\brief:   Merge cells in given style of given group with given row and column range it will occupy.                                  
		\remarks: This function is to merged several small cells to a large one. User should insure the cells of given range can be merged to an rectangle.                           
		\param:   int groupIndex [in] the group in which cells will be merged. 
		\param:   int styleIndex [in] the group's style in which cells will be merged.
		\param:   int startRow   [in] the start row index that will be merged.
		\param:   int startCol   [in] the start column index that will be merged.
		\param:   int endRow     [in] the end row index that will be merged.
		\param:   int endCol     [in] the end column index that will be merged.
		\return:  bool:   If the cells are merged successfully, return true.
		\par Example:
		\code       
		       gridListControl->MergeCells(0,0,0,0,1,1);// merge cell of group 0 style 0                                                          
		\endcode                              
		*/
		virtual bool MergeCells(int groupIndex, int styleIndex, int startRow, int startCol, int endRow, int endCol) = 0;

		/*!
		\brief:   Transform current style to target style with animation
		\remarks: After transformation, the focused item will still be on screen. \n
			      All groups inside will be transformed to the same destination style.
		\param:   int toStyleIndex [in] the destination style index.
		\return:  void
		*/
		virtual void TransformStyle(int toStyleIndex) = 0;

		/*!
		\brief:   Attach an title actor to group.                                
		\remarks: Title actor will set parent to an actor inside grid list control, the inner actor size is (0,0), position is (groupStartX, 0).\n
				  User should maintain the title actor himself, for example, set title content, font, size, color, etc.
		\param:   int groupIndex     [in] the group to attach title.
		\param:   IText * titleActor [in] the title actor to be attached. 
		\return:  void                                 
		*/
		virtual void AttachGroupTitle(int groupIndex, IText* titleActor) = 0;

		/*!
		\brief:   Set focus to given item of given group                                 
		\remarks: In default, the focus item is set to group 0, item 0. This function is used to change the focus item to given one.                           
		\param:   int groupIndex [in] the group that the focus item will be set to.
		\param:   int itemIndex  [in] the item index that focus item will be set to.
		\return:  void    
		\see:     GetFocusItemIndex
		*/
		virtual TValue2f SetFocusItemIndex(int groupIndex, int itemIndex, bool flagAni = true) = 0;

		/*!
		\brief:   Get current focused item's group index and itemIndex.                                                           
		\param:   int & groupId   [out] return the group index of focused item.
		\param:   int & itemIndex [out] return the item index of focused item.
		\return:  void 
		\see:     SetFocusItemIndex                                                                
		*/
		virtual void GetFocusItemIndex(int &groupId, int &itemIndex) = 0;

		/*!
		\brief:   Enable / Disable item.                               
		\remarks: All interaction will be blocked if the item is disabled.                              
		\param:   int groupIndex  [in] the group index of the item.
		\param:   int itemIndex   [in] the item index of the item.
		\param:   bool flagEnable [in] the enable flag, true means enable the item, false means disable the item.
		\see:     IsItemEnabled                                                                 
		*/
		virtual void EnableItem(int groupIndex, int itemIndex, bool flagEnable) = 0;

		/*!
		\brief:   Get the item's status is enabled or not.                                                      
		\param:   int groupIndex [in] the group index of the item.
		\param:   int itemIndex  [in] the item index of the item.
		\return:  bool: If the item is enabled return true, else return false.  
		\see:     EnableItem                                                                
		*/
		virtual bool IsItemEnabled(int groupIndex, int itemIndex) = 0;

		/*!
		\brief:   Set animation duration to give animation type.                                                           
		\param:   EAniType anitype [in] an enum value means the animation type to set duration.
		\param:   int duration     [in] the destination value of animation duration.
		\return:  void   
		\see:     SetAnimationMode                                                                
		*/
		virtual void SetAnimationDuration(EAniType anitype, int duration) = 0;

		/*!
		\brief:   Set animation duration to give animation type.                                                             
		\param:   EAniType anitype          [in] an enum value means the animation type to set mode.
		\param:   ClutterAnimationMode mode [in] an enum value means the destination value of animation mode.
		\return:  void   
		\see:     SetAnimationDuration                                                            
		*/
		virtual void SetAnimationMode(EAniType anitype, ClutterAnimationMode mode) = 0;

		/*!
		\brief:   Set the grid list control editable or not.                                
		\remarks: 
			If the grid list control is set editable, then items inside can be dragged and dropped.\n
			Currently, the item can only be dragged and dropped inside the same group.
		\param:   bool flag [in] the editable flag, true means editable, false means not editable.
		\return:  void   
		\see:     IsEditEnabled                                                                  
		*/
		virtual void EnableEdit(const bool flagEditable) = 0;

		/*!
		\brief:   Get whether the grid list control is set editable or not                                                            
		\return:  bool:  If the grid list control is editable return true, else return false.   
		\see:     EnabeEdit                                                              
		*/
		virtual bool IsEditEnabled(void) const = 0;

		/*!
		\brief:   Get the total column count of a group
		\remarks:
		\param:   int groupIndex [in] the index of the group that to get the column count.
		\return:  void
		*/
		virtual int ColumnCount(int groupIndex, int styleIndex) = 0;

		/*!
		\brief:   Update an item. 
		\remarks: This function is used to update an item to reload data. It will make renderer to redraw the item UI elements.
		\param:   int groupIndex  [in] the group index of the item.
		\param:   int itemIndex   [in] the item index of the item.
		\return:  void
		\see:	  UpdateAllItems
		*/
		virtual void UpdateItem(int groupIndex, int itemIndex) = 0;

		/*!
		\brief:   Update all items of a group.
		\remarks: This function is used to update all items of a group to reload data. It will make renderer to redraw the item UI elements.
		\param:   int groupIndex  [in] the group index of the item.
		\return:  void
		\see:	  UpdateItem
		*/
		virtual void UpdateAllItems(int groupIndex) = 0;

		/*!
		\brief:   Set buffer column size.
		\param:   int left  [in] left buffer column size.
		\param:   int right [in] right buffer column size.
		\return:  void
		\see:     SetAnimationMode
		*/
		virtual void SetBufferColumnSize(int left, int right) = 0;

		/*!
		\brief:   Get on screen item index range.
		\param:   int startGroupIndex  [out] start group index on screen.
		\param:   int startItemIndex   [out] start item index on screen.
		\param:   int endGroupIndex  [out] end group index on screen.
		\param:   int endItemIndex   [out] end item index on screen.
		\return:  void
		*/
		virtual void GetOnScreenRange(int &startGroupIndex, int &startItemIndex, int &endGroupIndex, int &endItemIndex) = 0;

		/*!
		\brief:   Get the total item count of a group
		\remarks:
		\param:   int groupIndex [in] the index of the group that to get the item count.
		\return:  void
		*/
		virtual int ItemCount(int groupIndex) = 0;

		/*!
		\brief:   Enable or disable straight path on focus moving.
		\remarks: If enabled, when moving focus, focus will move to last focused item in priority.
				  Otherwise, when moving focus, focus will just move to the item which is the nearest one to current focused item.
		\param:   bool flagStraightPath [in] the straight path flag, true means enable, false means disable.
		\return:  void
		\see:     IsStraightPathOnFocusMovingEnabled
		*/
		virtual void EnableStraightPathOnFocusMoving(const bool flagStraightPath) = 0;

		/*!
		\brief:   Get whether the grid list control is enabled straight path when moving focus or not.
		\return:  bool:  If the grid list control is enabled straight path return true, else return false.
		\see:     EnableStraightPathOnFocusMoving
		*/
		virtual bool IsStraightPathOnFocusMovingEnabled(void) const = 0;

		/*!
		\brief:   Set the grid list control item has rollover effect or not when mouse move in the item.
		\remarks:
		\param:   bool flagRolloverEffect [in] the rollover effect flag, true means set the rollover effect, false means no rollover effect.
		\return:  void
		\see:     IsRolloverEffectEnabled
		*/
		virtual void EnableRolloverEffect(const bool flagRolloverEffect) = 0;

		/*!
		\brief:   Get whether the grid list control focused item has rollover effect when mouse move in the item.
		\return:  bool:  If the grid list control has rollover effect return true, else return false.
		\see:     EnableRolloverEffect
		*/
		virtual bool IsRolloverEffectEnabled(void) const = 0;
	};
}


#endif //_HALO_IGRIDLAYOULISTCONTROL_H_