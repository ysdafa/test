#ifndef _ISELECTBUTTON_H_
#define _ISELECTBUTTON_H_

namespace HALO
{
	class HALO_API ISelectButton : virtual public IActor
	{
	public:
		enum EItemState
		{
			E_STATE_NORMAL = 0,   //!< button normal state.
			E_STATE_FOCUSED,	  //!< button focused state.   
			E_STATE_DISABLED,	  //!< button disabled state.   
			E_STATE_SELECTED,
			E_STATE_ALL			  //!< button all state.
		};
	public:
		
		static ISelectButton* CreateInstance(IActor *parent , float width, float height);
		/*!
		\brief               Set the button text
		\remarks             The itemText is not recommended to NULL. 
		\param               state: [in] The button state . 
		\param               itemText:[in] The text which will be set for button. 
		\return              None
		*/
		virtual void SetItemText(EItemState state, const char* itemText) = 0;
		
		/*!
		\brief               Get the text by button's state
		\param               state: [in] The state of button. 
		\return              const char *: A Pointer to char.
		*/
		virtual const char* ItemText(EItemState state) = 0;
		
		/*!
		\brief               Set the font size by button's state.
		\remarks             the fontSize is const type.
		\param               state:[in] The button state. 
		\param               fontSize:[in] The font size which will be set by button state. 
		\return              None
		*/
		virtual void SetItemTextFontSize(EItemState state, const int fontSize) = 0;
		
		/*!
		\brief               Set the color by button's state.
		\remarks             The color is const type.
		\param               state:[in] The button state. 
		\param               color:[in] The color which will be set by button state. 
		\return              None
		*/
		virtual void SetItemTextColor(EItemState state, const ClutterColor color) = 0;
		
		/*!
		\brief               Set font by button's state.
		\remarks             The font is const type.
		\param               state:[in] The button state.
		\param               font:[in] The font which will be set by button state.  
		\return              None
		*/
		virtual void SetTextFont(EItemState state,const char* font) = 0;
		
		/*!
		\brief               Get font by button state.
		\param               state:[in] The button state.
		\return              char *: A Pointer to char.
		*/
		virtual char* TextFont(EItemState state) = 0;
		
		/*!
		\brief               Set image button's state.
		\remarks             The imageBuffer is not recommended to NULL. 
		\param               state:[in] The button state. 
		\param               imageBuffer:[in] The image which will be set by button state. 
		\return              None
		*/
		virtual void SetBoxBackGroudImage(EItemState state, const std::string& iconPath) = 0;
		

		virtual void SetCheckImage(EItemState state, const std::string& iconPath) = 0;

		virtual void SetBoxBackGroudImageOpacity(EItemState state, int boxbgOpacity) = 0;

		virtual void SetCheckImageOpacity(EItemState state, int checkOpacity) = 0;

		virtual void UpdateImageAttr(float x , float y , float w , float h) = 0;


		virtual void SetAttachText(float x , float y , float w , float h) = 0;
		/*!
		\brief               Set the button id.
		\param               itemId: The button id. 
		\return              None
		*/
		virtual void SetId(int itemId) = 0;
		
		/*!
		\brief               Get button id.
		\return              int: The button id.
		*/
		virtual int GetId() = 0;		
		/*!
		\brief               Set the text alignment of button
		\param               hAlign:[in] The horizontal type. 
		\param               vAlign:[in] The vertical type. 
		\return              None
		*/
		virtual void SetTextAlignment(EHAlignment hAlign, EVAlignment vAlign) = 0;

		/*!
		\brief               Show the button
		\remarks             Must call the API after create it.
		\return              None
		*/
		virtual void Show() = 0;

		/*!
		\brief				 Set the check state for the button.
		\remarks             If the isChecked is true, the button is checked, otherwise is unchecked.
		\return              None
		*/
		virtual void SetCheck(bool isChecked) = 0;

		/*!
		\brief               Get the button check state.
		\return              bool: If return true ,the button is on check state, otherwise is on uncheck state. 
		*/
		virtual bool IsChecked() = 0;

		/*!
		\brief               Enable the check or not.
		\remarks             if the isSelected is false, the button can't be selected.
		\return              None
		*/
		virtual void EnableChecked(bool isSelected) = 0;

		virtual void SetAsyncLoading(const bool isAsync) = 0;

		virtual void SetAutoFocusFlag(bool isAutoFocused) = 0;

		virtual void SetFocusState(bool isFocused) = 0;

		virtual bool AsyncLoading(void)const = 0;

		virtual void SetAutoCheckFlag(bool isAutoChecked) = 0;

		virtual void Resize(float width, float height) = 0;

		virtual void AddListener(class OnButtonCheckedChangedListener *listener) = 0;	
	};
}
#endif