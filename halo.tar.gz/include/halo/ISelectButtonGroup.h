#ifndef _IBASESELECTBUTTON_GROUP_H_
#define _IBASESELECTBUTTON_GROUP_H_

namespace HALO
{
class HALO_API OnCheckedChangedListener : public IListener
{
	public:
		/*!
		\brief               Process the event when button is selected.
		\remarks             If use the listener ,must over write the function.
		\param               list:[in] the selected group. 
		\param               index:[in] the button index. 
		\param               ischecked:[in]  the button check state. 
		\param               checkcontrol:[in] the checked button. 
		\return              None
		*/
		virtual bool OnCheckChanged(class ISelectButtonGroup* list , int index , bool ischecked ,ISelectButton* checkcontrol){return true;};

};
class HALO_API ISelectButtonGroup :  virtual public IActor
{
public:
	
	/*!
	\brief               Add button into group.
	\param               checkContorl:[in] checkContorl is the base class. 
	\return              int: The button index. 
	*/
	virtual int AddButton(ISelectButton *checkContorl) = 0;
	
	/*!
	\brief				 Get the button by button id.
	\param               itemId: The button id. 
	\return              HALO::ISelectButton *: A Pointer to ISelectButton.
	*/
	virtual ISelectButton* GetItemById(int itemId) = 0;
	/*!
	\brief               Set default focus by button id.
	\remarks             The id must be correct.
	\param               itemId: The button id. 
	\return              None
	*/
	virtual void SetDefaultFocus(int itemId) = 0;
	

	virtual void SetDefaultSelectedItem(int itemId) = 0;
	/*!
	\brief               Get the number of the buttons in the group.
	\return              int: The button number. 
	*/
	virtual int NumofItem() = 0;

	/*!
	\brief               Add OnCheckedChangedListener for button group.
	\param               listener: The pointer to OnCheckedChangedListener. 
	\return              None
	*/
	virtual bool AddListener(OnCheckedChangedListener *listener) = 0;	
	/*!
	\brief               Remove the OnCheckedChangedListener which has been added in the group.
	\remarks             When add the OnCheckedChangedListener,when destroy application ,must remove it.
	\return              None
	*/
	virtual bool RemoveListener(OnCheckedChangedListener *listener) = 0;

	};

	class HALO_API ICheckBoxGroup :  virtual public ISelectButtonGroup
	{
	public:
		static ICheckBoxGroup* CreateInstance(void);


		virtual std::vector<int> GetSelectedItemIndexes() = 0;
	};

	class HALO_API IRadioButtonGroup :  virtual public ISelectButtonGroup
	{
	public:
		static IRadioButtonGroup* CreateInstance(void);

		virtual int GetSelectedItemIndex() = 0; 
	};
}
#endif