#ifndef _IDEFAULTWINDOW_H_
#define _IDEFAULTWINDOW_H_

namespace HALO
{
	class HALO_API IDefaultWindow : virtual public IActor
	{
	public:
		enum E_ITEM_TYPE
		{
			ITEM_TYPE_NONE = 0x00000000,	//!< None item type.
			ITEM_TYPE_TITLE	= 0x00000001,	//!< Title type.
			ITEM_TYPE_HELPBAR = 0x00000002,	//!< Help bar type.
			ITEM_TYPE_BUTTON_LINE = 0x00000004,	//!< Button line type.
			ITEM_TYPE_NO_BG = 0x00000008,	//!< No back ground type.
		};
		
		enum E_TIMEOUT_ALARM
		{
			TIMEOUT_ALARM_3SEC		= 3000,		//!< Time out 3 sec.
			TIMEOUT_ALARM_5SEC		= 5000,		//!< Time out 5 sec.
			TIMEOUT_ALARM_10SEC		= 10000,	//!< Time out 10 sec.
			TIMEOUT_ALARM_30SEC		= 30000,	//!< Time out 30 sec.
			TIMEOUT_ALARM_60SEC		= 60000,	//!< Time out 60 sec.
			TIMEOUT_ALARM_180SEC	= 180000,	//!< Time out 18 sec.
			TIMEOUT_ALARM_600SEC	= 600000,	//!< Time out 600 sec.
		};

		enum E_ANIMATION_TYPE
		{
			ANIMATION_NONE           = 0,		//!< None animation.
			ANIMATION_ZOOM_OUT_TO_IN = 1,		//!< From out to in by zoom animation.
			ANIMATION_ZOOM_IN_TO_OUT = 2,		//!< From in to out by zoom animation.
			ANIMATION_RIGHT_TO_LEFT  = 3,		//!< From right to left animation.
			ANIMATION_LEFT_TO_RIGHT  = 4,		//!< From left to right animation.
			ANIMATION_DOWN_TO_UP     = 5,		//!< From down to up animation.
			ANIMATION_UP_TO_DOWN     = 6		//!< From up to down animation.
		};


		enum E_COLOR_TYPE
		{
			HELPBAR_WHITE = 0,					//!< Help bar with white color.
			HELPBAR_BLACK = 1,					//!< Help bar with black.
		};

		enum E_BG_TYPE
		{
			BG_NORMAL = 0,						//!< Normal background type.
			BG_DARK								//!< Dark background type.
		};
		typedef struct T_DEFAULTWINDOW_ATTR
		{
			float xPos;	//!< The default window x position.
			float yPos;	//!< The default window y position.
			float width;	//!< The default window width.
			float height;	//!< The default window height.
			int nItemType;	//!< The default item type.
			int screenNumber;	//!< The screen number.
			bool bUseCompositeBGImage;	//!< Use composite background image flag.
		}TDefaultWindowAttr;	//!< the none button index.
	public:
		/*!
		\brief               Create A new default window.
		\param               parent:[in] The parent of default window. 
		\param               attr:[in] Default window attribute. 
		\return              HALO::IDefaultWindow *: A pointer to IDefaultWindow
		*/
		static IDefaultWindow* CreateInstance(IActor* parent, const TDefaultWindowAttr &attr);
	public:
		/*!
		\brief               Show the default window.
		\param               nAnimationType:[in] The animation type. 
		\return              None 
		*/
		virtual void Show(E_ANIMATION_TYPE nAnimationType) = 0;
		/*!
		\brief               Hide the default window.
		\param               nAnimationType:[in] The animation type. 
		\return              None
		*/
		virtual void Hide(E_ANIMATION_TYPE nAnimationType) = 0;
		/*!
		\brief               Set the title text.
		\param               pTitle: The title text. 
		\return              None
		*/
		virtual void SetTitleText(const char* pTitle) = 0;
		/*!
		\brief               Set the title text color.
		\param               textcolor:[in] The title text color. 
		\return              None 
		*/
		virtual void SetTitleTextColor(const ClutterColor textcolor) = 0;
		/*!
		\brief               Set the title text font size.
		\param               fontSize:[in] The text font size. 
		\return              None
		*/
		virtual void SetTitleTextFontSize(int fontSize) = 0;
		/*!
		\brief               Set the time out value.
		\param               nTimeOut: The time out value. 
		\return              None
		*/
		virtual void SetAlarmTimeOut(unsigned long nTimeOut) = 0;
		/*!
		\brief               Set background image
		\param               pBGImage:[in] The background image. 
		\return              None
		*/
		virtual void SetBGImage(IImageBuffer* pBGImage) = 0;
		/*!
		\brief               Reset the time out alarm.
		\return              None
		*/
		virtual void ResetTimeOutAlarm(void) = 0;
		/*!
		\brief               Stop the time out alarm.
		\return              None
		*/
		virtual void StopTimeOutAlarm(void) = 0;
		/*!
		\brief               Set the background type
		\param               nBGType:[in] The background type. 
		\return              None
		*/
		virtual void SetBGType(int nBGType) = 0;
		/*!
		\brief               Enable the auto transparency
		\return              None
		*/
		virtual void EnableAutoTransparency() = 0;
		/*!
		\brief               Set the cursor shape
		\param               nHelpBarType:[in] The help bar type. 
		\param               nType:[in] The shape type. 
		\return              None 
		*/
		virtual void SetCursorShape(int nHelpBarType, int nType) = 0; 
		/*!
		\brief               Set the shadow background image for default window.
		\param               pShadowBGImage:[in] The shadow image. 
		\param               nRelativeX:[in] The image relative x position. 
		\param               nRelativeY:[in] The image relative y position. 
		\param               nDestWidth:[in] The image width. 
		\param               nDestHeight:[in] The image height. 
		\return              None
		*/
		virtual void SetShadowBGImage(IImageBuffer* pShadowBGImage = NULL, int nRelativeX = -1, int nRelativeY = -1, float nDestWidth = -1, float nDestHeight = -1/*, STRect* sourceRect = NULL*/) = 0; // for Tools, SourceBrowser etc..
		/*!
		\brief               Set the transparency for default window.
		\param               nValue:[in] The transparency value. 
		\return              None
		*/
		virtual void SetTransparency(int nValue) = 0;	
	};
}
#endif
