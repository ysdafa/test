#ifndef _IMESSAGEBOX_H_
#define _IMESSAGEBOX_H_

namespace HALO
{
	class HALO_API IMessageBoxListener : public IListener
	{
	public:
		enum EEventType
		{
			BUTTON_FOCUS_IN     = 0,	//!< button focus in event type.
			BUTTON_FOCUS_OUT,      	    //!< button focus out event type.
			BUTTON_CLICKED           	//!< button clicked event type.
		};
		typedef uint EEventTypes;		
		/*!
		\brief               process the event when the button is processed.
		\param               messagebox:[in] The selected message box. 
		\param               buttonIndex:[in] the selected button index. 
		\param               eventType:[in] The selected button event type. 
		\return              bool
		*/
		virtual bool OnButtonEvent(class IMessageBox* messagebox, const int nButtonIndex, EEventTypes eventType) { return false; };
	};

	class HALO_API IMessageBox: virtual public IActor
	{
	public:
		enum EMessageButton
		{
			NO_BUTTON     = 0,	     //!< none button type.
			BUTTON_1,      	         //!< button 1, one button type.
			BUTTON_2,        	     //!< button 2, two buttons type.
			BUTTON_3,     	         //!< button 3, three buttons type.
			BUTTON_ALL          	 //!< All buttons.  
		};
		typedef uint EMessageButtons;

		enum EMessageContent
		{
			SINGLE_LINE_CONTENT                          = 0,	//!< single-line context type.
			MULTI_LINE_CONTENT,                                 //!< muti-line context type.
			MULTI_LINE_CONTENT_WITH_SINGLE_LINE_CONTENT,        //!< muti-line context(>= 2 lines) with single line type.
			SINGLE_LINE_CONTENT_WITH_LOADING,	                //!< single-line context with loading animation type.
			MULTI_LINE_CONTENT_WITH_LOADING                     //!< muti-line context with loading animation type.
		};
		typedef uint EMessageContents;

		struct TMessageBoxAttr
		{
			float x;		    //!< message box x position.
			float y;		    //!< message box y position.
			float w;		    //!< message box width.
			float h;		    //!< message box height.
			EMessageButtons nButtonType;	 //!< button count in message box.
			EMessageContents nContentType;   //!< message context type.
			bool bTitle;                     //!< message title flag.
			bool bAutoFlag;                  //!< Auto adjust messagebox, messageboxRect.x and messageboxRect.y will be disable.
			TMessageBoxAttr() : x(0), y(0), w(1280), h(720), nButtonType(NO_BUTTON), nContentType(SINGLE_LINE_CONTENT), bTitle(false), bAutoFlag(true) {}
		};

	public:
		/*!
		\brief               Create a new message box
		\param               parent:[in] The parent of the message box. 
		\param               attr:[in] The message box attribute. 
		\return              HALO::IMessageBox *: A pointer to IMessageBox
		\par Example:
		\code
			IActor *m_window;
			IMessageBox *m_messageBox;
			IMessageBox::TMessageBoxAttr attr;
			attr.messageboxRect.x = 0;
			attr.messageboxRect.y = 200;
			attr.messageboxRect.w = 1920;
			attr.messageboxRect.h = 1080;
			attr.nButtonType = m_messageBox->BUTTON_2;
			attr.nContentType = m_messageBox->MULTI_LINE_CONTENT;
			attr.bTitle = true;
			attr.bAutoFlag = true;
			m_messageBox = IMessageBox::CreateInstance(m_window ,attr);
		*/
		static IMessageBox* CreateInstance(IActor* parent, const TMessageBoxAttr &attr);
		static IMessageBox* CreateInstance( Widget* parent, const TMessageBoxAttr &attr );
	public:
		/*!
		\brief               Set the background color.
		\param               BGColor:[in] The background color. 
		\return              None 
		*/
		virtual void SetBGColor(const ClutterColor BGColor) = 0;
		/*!
		\brief               Set title text rect.
		\param               x:[in] title x position.
		\param               y:[in] title y position.
		\param               w:[in] title width.
		\param               h:[in] title height. 
		\return              None
		*/
		virtual void SetTitleRect(float x, float y, float w, float h) = 0;
		/*!
		\brief               Set title text.
		\param               pTitleText:[in] title text. 
		\return              None
		*/
		virtual void SetTitleText(const std::string& titleText) = 0;
		/*!
		\brief               Get title text.
		\return              std::string
		*/
		virtual std::string TitleText() const = 0;
		/*!
		\brief               Set the title text color.
		\param               textcolor:[in] The title text color. 
		\return              None 
		*/
		virtual void SetTitleTextColor(const ClutterColor textcolor) = 0;
		/*!
		\brief               Set the title text font.
		\param               font:[in] The text font. 
		\return              None
		*/
		virtual void SetTitleTextFont(const std::string& font) = 0;
		/*!
		\brief               Get the title text font.
		\return              std::string
		*/
		virtual std::string TitleTextFont() const = 0;
		/*!
		\brief               Set title text horizontal and vertical alignment.
		\param               hAlign: [in]Horizontal alignment value. 
		\param               vAlign: [in]Vertical alignment value. 
		\return              None
		*/
		virtual void SetTitleTextAlignment(EHAlignment hAlign, EVAlignment vAlign) = 0;
		/*!
		\brief               Get title text line count. 
		\return              int
		*/
		virtual int TitleTextLineCount() = 0;
		/*!
		\brief               Set title line rect.
		\param               x:[in] title line x position.
		\param               y:[in] title line y position.
		\param               w:[in] title line width.
		\param               h:[in] title line height. 
		\return              None
		*/
		virtual void SetTitleLineRect(float x, float y, float w, float h) = 0;
		/*!
		\brief               Set title line color.
		\param               color:[in] The color which will be set to title line. 
		\return              None
		*/
		virtual void SetTitleLineColor(const ClutterColor color) = 0;
		/*!
		\brief               Set context text rect.
		\param               x:[in] context x position.
		\param               y:[in] context y position.
		\param               w:[in] context width.
		\param               h:[in] context height.
		\return              None
		*/
		virtual void SetContentRect(float x, float y, float w, float h) = 0;
		/*!
		\brief               Set content text.
		\param               pContentText:[in] Explain parameter here. 
		\return              None
		*/
		virtual void SetContentText(const std::string& contentText) = 0;
		/*!
		\brief               Get content text.
		\return              std::string
		*/
		virtual std::string ContentText() const = 0;
		/*!
		\brief               Set context text color.
		\param               textcolor:[in] The title text color. 
		\return              None 
		*/
		virtual void SetContentTextColor(const ClutterColor textcolor) = 0;
		/*!
		\brief               Set context text font.
		\param               font:[in] The text font. 
		\return              None
		*/
		virtual void SetContentTextFont(const std::string& font) = 0;
		/*!
		\brief               Get context text font.
		\return              std::string
		*/
		virtual std::string ContentTextFont() const = 0;
		/*!
		\brief               Set content text horizontal and vertical alignment.
		\param               hAlign: [in]Horizontal alignment value. 
		\param               vAlign: [in]Vertical alignment value. 
		\return              None
		*/
		virtual void SetContentTextAlignment(EHAlignment hAlign, EVAlignment vAlign) = 0;
		/*!
		\brief               Set content text row gap value.
		\param               gap:[in] The content text row gap value. 
		\return              None
		*/
 		virtual void SetContentTextRowGap(int gap) = 0;
		/*!
		\brief               Get content text row gap value. 
		\return              int
		*/
		virtual int ContentTextRowGap() const = 0;
		/*!
		\brief               Get content text line count. 
		\return              int
		*/
		virtual int ContentTextLineCount() = 0;
		/*!
		\brief               Set context2 text rect(just effect in < muti-line context(>= 2 lines) with single line type).
		\param               x:[in] context2 x position.
		\param               y:[in] context2 y position.
		\param               w:[in] context2 width.
		\param               h:[in] context2 height.
		\return              None
		*/
		virtual void SetContent2Rect(float x, float y, float w, float h) = 0;
		/*!
		\brief               Set content2 text(just effect in < muti-line context(>= 2 lines) with single line type).
		\param               pContentText:[in] Explain parameter here. 
		\return              None
		*/
		virtual void SetContentText2(const std::string& contentText) = 0;
		/*!
		\brief               Get content2 text.
		\return              std::string
		*/
		virtual std::string ContentText2() const = 0;
		/*!
		\brief               Set context2 text color(just effect in < muti-line context(>= 2 lines) with single line type).
		\param               textcolor:[in] The title text color. 
		\return              None 
		*/
		virtual void SetContentText2Color(const ClutterColor textcolor) = 0;
		/*!
		\brief               Set context2 text font(just effect in < muti-line context(>= 2 lines) with single line type).
		\param               font:[in] The text font. 
		\return              None
		*/
		virtual void SetContentText2Font(const std::string& font) = 0;
		/*!
		\brief               Get context2 text font.
		\return              std::string
		*/
		virtual std::string ContentText2Font() const = 0;
		/*!
		\brief               Set content2 text horizontal and vertical alignment.
		\param               hAlign: [in]Horizontal alignment value. 
		\param               vAlign: [in]Vertical alignment value. 
		\return              None
		*/
		virtual void SetContentText2Alignment(EHAlignment hAlign, EVAlignment vAlign) = 0;
		/*!
		\brief               Get content2 text line count. 
		\return              int
		*/
		virtual int ContentText2LineCount() = 0;
		/*!
		\brief               Set button rect.
		\param               nButton:[in] button index.
		\param               x:[in] button x position.
		\param               y:[in] button y position.
		\param               w:[in] button width.
		\param               h:[in] button height.
		\return              None
		*/
		virtual void SetButtonRect(const EMessageButtons nButton, float x, float y, float w, float h) = 0;
		/*!
		\brief               Set button background color.
		\param               nButton:[in] the button width. 
		\param               EButtonState:[in] the button state. 
		\param               color:[in] background color. 
		\return              None 
		*/
		virtual void SetButtonBackgroundColor(const EMessageButtons nButton, IButton::EButtonState state, const ClutterColor color) = 0;
		/*!
		\brief               Set button image.
		\param               nButton:[in] the button width. 
		\param               EButtonState:[in] the button state. 
		\param               imagePath:[in] the image path. 
		\return              None 
		*/
		virtual void SetButtonImage(const EMessageButtons nButton, IButton::EButtonState state, const std::string& imagePath) = 0;
		/*!
		\brief               Set button text.
		\param               nButton:[in] the button width. 
		\param               EButtonState:[in] the button state. 
		\param               text:[in] the text.  
		\return              None 
		*/
		virtual void SetButtonText(const EMessageButtons nButton, IButton::EButtonState state, const std::string& text) = 0;
		/*!
		\brief               Set button text.
		\param               nButton:[in] the button width. 
		\param               EButtonState:[in] the button state. 
		\param               color:[in] the text color.  
		\return              None 
		*/
		virtual void SetButtonTextColor(const EMessageButtons nButton, IButton::EButtonState state, const ClutterColor color) = 0;
		/*!
		\brief               Set button text.
		\param               nButton:[in] the button width. 
		\param               EButtonState:[in] the button state. 
		\param               fontSize:[in] the text font size.  
		\return              None 
		*/
		virtual void SetButtonTextFontSize(const EMessageButtons nButton, IButton::EButtonState state, int fontSize) = 0;
		/*!
		\brief               Set the default focus by button index.
		\param               nButton:[in] The button enum index. 
		\return              none.
		*/
		virtual void SetDefaultFocus(int nButton) = 0;
		/*!
		\brief               Get the default focus button.
		\return              int: Button index.  
		*/
		virtual int DefaultFocus() const = 0;
		/*!
		\brief               Add loading animation attribute.
		\param               attr:[in] loading animation attribute. 
		\return              none. 
		*/
		virtual void SetLoadingAttr(const ILoading::TLoadingAttr &attr) = 0;
		/*!
		\brief               Add MessageBoxListener.
		\param               listener:[in] IMessageBoxListener rewrite by user. 
		\return              bool 
		*/
		virtual bool AddListener(IMessageBoxListener* listener) = 0;
		/*!
		\brief               Remove MessageBoxListener.
		\param               listener:[in] IMessageBoxListener rewrite by user. 
		\return              bool 
		*/
		virtual bool RemoveListener(IMessageBoxListener* listener) = 0;
		/*!
		\brief               Support the TTS or not.
		\param               bSupport:[in] If the bSupport is true, will support TTS, otherwise not. 
		\return              None
		*/
		virtual void SetSupportTTS(bool bSupport) = 0;
		/*!
		\brief               Get flag about support TTS or not.
		\return              bool
		*/
		virtual bool SupportTTS() const = 0;
		/*!
		\brief               Set show time(ms).
		\param               nShowTime:[in] show time(ms). 
		\return              None
		*/
		virtual void SetShowTime(guint nShowTime) = 0;
		/*!
		\brief               Set show time(ms).
		\return              show time(ms)
		*/
		virtual guint ShowTime() const = 0;
	};
}
#endif
