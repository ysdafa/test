#ifndef _IACTIONPOPUP_H_
#define _IACTIONPOPUP_H_

namespace HALO
{
	class HALO_API IActionPopup : virtual public IActor
	{
	public:
		enum E_BACKGROUND_TYPE
		{
			E_TYPE_ONE = 0,
			E_TYPE_TWO,
			E_TYPE_THREE,
			E_TYPE_FOUR
		};

		enum E_ANIMATION_TYPE
		{
			ANIMATION_NONE           = 0,		//!< None animation.
			ANIMATION_ZOOM_OUT_TO_IN = 1,		//!< From out to in by zoom animation.
			ANIMATION_ZOOM_IN_TO_OUT = 2,		//!< From in to out by zoom animation.
			ANIMATION_RIGHT_TO_LEFT  = 3,		//!< From right to left animation.
			ANIMATION_LEFT_TO_RIGHT  = 4,		//!< From left to right animation.
			ANIMATION_DOWN_TO_UP     = 5,		//!< From down to up animation.
			ANIMATION_UP_TO_DOWN     = 6		//!< From up to down animation.
		};

		struct TActionPopupAttr
		{
			float x;		    
			float y;		    
			float w;		    
			float h;
			bool isTitle;
			E_BACKGROUND_TYPE nBackGroundType;	   
			E_ANIMATION_TYPE nAnimationType;   
			TActionPopupAttr() : x(0), y(0), w(1280), h(720), isTitle(true) , nBackGroundType(E_TYPE_ONE), nAnimationType(ANIMATION_NONE) {}
		};
	public:
		static IActionPopup* CreateInstance(IActor* parent, const TActionPopupAttr &attr);
	public:
		virtual void SetTitle(const char* title) = 0;

		virtual void UpdateTitlePosition(float xPos , float yPos) = 0;

		virtual void UpdateTitleSize(float width , float height) = 0;

		virtual void SetTitleAlignment(EHAlignment hAlign, EVAlignment vAlign) = 0;

		virtual void SetTitleTextColor(const ClutterColor textcolor) = 0;

		virtual void SetTitleTextFontSize(int fontSize) = 0;

		virtual void SetBackgroundType(E_BACKGROUND_TYPE  backgroundType) = 0;

		virtual void SetBlendColor(const ClutterColor textcolor) = 0;

		virtual void SetTitleLineColor(const ClutterColor color) = 0;
	};
/*
	class HALO_API IButtonPopup : virtual public IActionPopup
	{
	public:
		enum EButton
		{
			NO_BUTTON     = 0,	     //!< none button type.
			BUTTON_1,      	         //!< button 1, one button type.
			BUTTON_2,        	     //!< button 2, two buttons type.
			BUTTON_3,     	         //!< button 3, three buttons type.
			BUTTON_ALL          	 //!< All buttons.  
		};
		struct TButtonPopupAttr : public TActionPopupAttr
		{
			EButton nButtonType;
			float buttonWidth;
			float buttonHeight;
			TButtonPopupAttr() : nButtonType(BUTTON_1), buttonWidth(0) ,buttonHeight(0){}
		};
	public:
		static IActionPopup* CreateInstance(IActor* parent, const TButtonPopupAttr &attr);
	public:
		virtual void SetButtonType(EButton nButtonType) = 0;

		virtual void SetButtonPosition(EButton button , float xPos , float yPos) = 0;

		virtual void SetButtonSize(EButton button , float width , float height) = 0;

		virtual void SetButtonText(EButton button , const char* text) = 0;

		virtual void SetButtonTextColor(EButton button , const ClutterColor textcolor) = 0;

		virtual void SetButtonTextFontSize(EButton button , int fontSize) = 0;
	};*/
}

#endif