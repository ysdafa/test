#ifndef _HALO_IEFFECT_H_
#define _HALO_IEFFECT_H_

namespace HALO
{
	class HALO_API IEffect : public Instance
	{
	public:
		/*!
		\brief               Sets whether effect should be enabled or not
		\param               flagEnable: [in] Whether effect is enabled. 
		\return              None
		*/
		virtual void Enabled(bool flagEnable) = 0;
		/*!
		\brief               Retrieves whether effect is enabled
		\return              bool: true if the effect instance is enabled 
		*/
		virtual bool IsEnabled(void) = 0;
	};

	class HALO_API IDesaturationEffect :virtual public IEffect
	{
	public:
		/*!
		\brief               Creates a new desturation effect with the given @factor
		\remarks             The factor between 0.0 and 1.0, with 0.0 being "do not desaturate" and 1.0 being "fully desaturate"
		\param               factor: [in] the desaturation factor. 
		\return              HALO::IDesaturationEffect *: The newly created desturation effect instance
		*/
		static IDesaturationEffect* CreateInstance(double factor);
	public:
		/*!
		\brief               Sets the desaturation factor for effect
		\remarks             The factor between 0.0 and 1.0, with 0.0 being "do not desaturate" and 1.0 being "fully desaturate"
		\param               factor: [in] the desaturation factor. 
		\return              None
		*/
		virtual void SetFactor(double factor) = 0;
		/*!
		\brief               Retrieves the desaturation factor of effect
		\return              double: the desaturation factor 
		*/
		virtual double GetFactor(void) = 0;
	};

	class HALO_API IShadowEffect :virtual public IEffect
	{
	public:
		/*!
		\brief               Creates a new shadow effect instance
		\param               topOffset: [in] The top offset, in pixels. 
		\param               bottomOffset: [in] The bottom offset, in pixels. 
		\param               leftOffset: [in] The left offset, in pixels. 
		\param               rightOffset: [in] The right offset, in pixels. 
		\return              HALO::IShadowEffect *: The newly created shadow effect instance
		\par Example:
		\code
			IShadowEffect* effect = IShadowEffect::CreateInstance( -30, 30, -30, 30);
		\endcode
		*/
		static IShadowEffect* CreateInstance(float topOffset, float bottomOffset, float leftOffset, float rightOffset);

	public:
		/*!
		\brief               Sets the offsets of the effect
		\param               topOffset: [in] The top offset, in pixels. 
		\param               bottomOffset: [in] The bottom offset, in pixels. 
		\param               leftOffset: [in] The left offset, in pixels. 
		\param               rightOffset: [in] The right offset, in pixels. 
		\return              None
		*/
		virtual void SetShadowOffset(float top, float bottom, float left, float right) = 0;
	};
}
#endif //_HALO_IEFFECT_H_