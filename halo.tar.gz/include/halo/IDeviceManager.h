#ifndef _HALO_IDEVICE_MANAGER_H_
#define _HALO_IDEVICE_MANAGER_H_

namespace HALO
{
	class HALO_API IDeviceManager : public Instance
	{
	public:	
		/*!
		\brief               Get the sigle instance of IDeviceManager.
		\return              The instance pointer.
		*/
		static IDeviceManager* GetInstance(void);
		
		// Get the devicelist of HALO
		//virtual const DeviceInfoList* GetDeviceInfoList(void) = 0;

		/*!
		\brief               Get the device according to deviceId.
		\param               deviceId [in] The types of input devices available.. 
		\return              The device pointer.
		*/
		virtual IDevice* GetDevice(ClutterInputDeviceType deviceId) = 0;

		/*!
		\brief				Get mouse device.
		\param[in]			void
		\return				The mouse device pointer.
		*/
		virtual IMouseDevice* GetMouseDevice(void) = 0;

		/*!
		\brief               Get the grabed actor.
		\param               device [in]  A device pointer. 
		\return              The grabde actor.
		\note				 Only ClutterInputDevice of types CLUTTER_POINTER_DEVICE and CLUTTER_KEYBOARD_DEVICE can hold a grab.
		*/
		virtual IActor* GetGrabedActor(IDevice *device) = 0;

		/*!
		\brief               Set cursor property.
		\param               scene [in] The current stage. 
		\param               imagePath [in] The path of image. 
		*/
		virtual void SetCursorImage(IStage* scene, const char* imagePath) = 0;

		/*!
		\brief               Enable the device work.
		\param               device [in] The device will be enabled.
		\param               enable [in] True or False.
		\note                Only devices with a "device-mode" property set to CLUTTER_INPUT_MODE_SLAVE or CLUTTER_INPUT_MODE_FLOATING can be disabled.
		*/
		virtual void EnableDevice(IDevice *device, bool enabled) = 0;

		/*!
		\brief               Check whether the device is enabled.
		\param               device [in] The device will be checked. 
		\return              True or false.
		\see                 IDeviceManager::EnableDevice().
		*/
		virtual bool IsDeviceEnabled(IDevice *device) = 0;		

		/*!
		\brief               Check cursor is visible or hidden.
		\return              True or false.
		*/
		virtual bool IsCursorVisible(void) = 0;
	private:
		static IDeviceManager* m_deviceManager;

	};
}

#endif