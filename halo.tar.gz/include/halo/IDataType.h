#ifndef _IDATA_TYPE_H_
#define _IDATA_TYPE_H_

namespace HALO
{
	struct HALO_API TValueBase
	{
		virtual int ElementCount(void) const = 0;
		virtual float ElementValue(int index) const = 0;
		virtual void SetElementValue(int index, float val) = 0;

		static float Distance(const TValueBase &from, const TValueBase &to)
		{
			ASSERT(from.ElementCount() == to.ElementCount());
			float result = 0.0f;
			int count = from.ElementCount();

			for (int i = 0; i < count; i++)
			{
				result += (from.ElementValue(i) - to.ElementValue(i)) * (from.ElementValue(i) - to.ElementValue(i));
			}

			return sqrt(result);
		}

		static void GetRakeRatio(const TValueBase &from, const TValueBase &to, TValueBase &rakeRatio, float distance = -1.0f)
		{
			if (0.0f > distance)
			{
				distance = Distance(from, to);
			}

			int count = from.ElementCount();

			if (0.0f == distance)
			{
				for (int i = 0; i < count; i++)
				{
					rakeRatio.SetElementValue(i, 0.0f);
				}
			}
			else
			{
				for (int i = 0; i < count; i++)
				{
					rakeRatio.SetElementValue(i, (to.ElementValue(i) - from.ElementValue(i)) / distance);
				}
			}
		}
	};

	template <typename T>
	struct HALO_API TValue1 : public TValueBase
	{
		TValue1(T x = (T)0.0f)
		{
			Set(x);
		}

		T val[1];

		static TValue1 Build(T x)
		{
			TValue1 result(x);
			return result;
		}

		void Set(T x)
		{
			val[0] = x;
		}

		int ElementCount(void) const
		{
			return 1;
		}

		float ElementValue(int index) const
		{
			ASSERT(0 == index);
			return (float)val[index];
		}

		void SetElementValue(int index, float inVal)
		{
			ASSERT(0 == index);
			val[index] = (T)inVal;
		}
	};

	template <typename T>
	struct HALO_API TValue2 : public TValueBase
	{
		TValue2(T x = (T)0.0f, T y = (T)0.0f)
		{
			Set(x, y);
		}

		T val[2];

		static TValue2 Build(T x, T y)
		{
			TValue2 result(x, y);
			return result;
		}

		void Set(T x, T y)
		{
			val[0] = x;
			val[1] = y;
		}

		int ElementCount(void) const
		{
			return 2;
		}

		float ElementValue(int index) const
		{
			ASSERT(2 > index);
			return (float)val[index];
		}

		void SetElementValue(int index, float inVal)
		{
			ASSERT(2 > index);
			val[index] = (T)inVal;
		}
	};

	typedef TValue1<int> TValue1i;
	typedef TValue1<float> TValue1f;
	typedef TValue2<float> TValue2f;

	template <typename ValueType>
	struct HALO_API TVector3
	{
		ValueType x;
		ValueType y;
		ValueType z;

		TVector3(ValueType fX, ValueType fY, ValueType fZ) :x(fX), y(fY), z(fZ) {}
	};

	typedef TVector3<float> TVector3f;

	struct HALO_API TMargin
	{
		TMargin() : top(0), bottom(0), left(0), right(0) {}

		int top;
		int bottom;
		int left;
		int right;

		void Set(int inTop, int inBottom, int inLeft, int inRight)
		{
			top = inTop;
			bottom = inBottom;
			left = inLeft;
			right = inRight;
		}
	};
	
	//! Horizontal alignment types
	enum HALO_API EHAlignment
	{
		HALIGN_LEFT 	= 0,	//! Left Alignment
		HALIGN_CENTER,		//! Center Alignment
		HALIGN_RIGHT		//! Right Alignment
	};

	//! Vertical alignment types
	enum HALO_API EVAlignment
	{
		VALIGN_TOP 	= 3,	//! Top Alignment
		VALIGN_MIDDLE,		//! Middle Alignment
		VALIGN_BOTTOM		//! Bottom Alignment
	};

	enum HALO_API EDirection
	{
		DIRECTION_UP = 0,
		DIRECTION_DOWN,
		DIRECTION_LEFT,
		DIRECTION_RIGHT,

		DIRECTION_MAX
	};

	//! Orientation - Direction of text
	enum HALO_API EOrientation
	{
		ORIENTATION_LEFT_TO_RIGHT = 0,
		ORIENTATION_RIGHT_TO_LEFT,
		ORIENTATION_REFER_TO_PARENT,
	};

	enum HALO_API EDirectionType
	{
		TYPE_VERTICAL = 0,
		TYPE_HORIZONTAL
	};

	struct HALO_API TRect
	{
		TRect(void) : x(0.0f), y(0.0f), w(0.0f), h(0.0f) {}
		TRect(float inX, float inY, float inW, float inH){ x = inX; y = inY; w = inW; h = inH; }

		void Set(float inX, float inY, float inW, float inH){ x = inX; y = inY; w = inW; h = inH; }
		float x;
		float y;
		float w;
		float h;

		void operator=(TRect rect)
		{
			x = rect.x;
			y = rect.y;
			w = rect.w;
			h = rect.h;
		}
	};

	const float EPSINON = 0.00001;
	struct HALO_API TRegion
	{
		TRegion(void) : l(0), r(0), t(0), b(0) {}
		TRegion(int inL, int inR, int inT, int inB) : l(inL), r(inR), t(inT), b(inB) {}

		void Set(int inL, int inR, int inT, int inB) { l = inL; r = inR; t = inT; b = inB; }
		float l;
		float r;
		float t;
		float b;

		bool isEmpty() const
		{
			return ((l >= -EPSINON) && (l <= EPSINON)) && ((r >= -EPSINON) && (r <= EPSINON)) && ((t >= -EPSINON) && (t <= EPSINON)) && ((b >= -EPSINON) && (b <= EPSINON));
		}

		void operator=(TRegion region)
		{
			l = region.l;
			r = region.r;
			t = region.t;
			b = region.b;
		}
	};

	struct HALO_API TPoint
	{
		TPoint(void) : x(0.0f), y(0.0f){}
		TPoint(float inX, float inY){ x = inX; y = inY; }

		void Set(float inX, float inY){ x = inX; y = inY; }
		float x;
		float y;

		void operator=(TPoint point)
		{
			x = point.x;
			y = point.y;
		}
	};

}

#endif
