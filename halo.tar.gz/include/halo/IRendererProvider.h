#ifndef _HALO_IRENDERERPROVIDER_H_
#define _HALO_IRENDERERPROVIDER_H_

namespace HALO
{
	class IRenderer
	{
	public:
		//! Draw item
		enum E_DRAW_TYPE
		{
			LOAD_DATA_DRAW = 0,
			UNLOAD_DATA_DRAW,
			UPDATE_DATA_DRAW,
			ITEM_SCROLL_DRAW,
			FOCUS_CHANGE_START_FROM_DRAW,
			FOCUS_CHANGE_START_TO_DRAW,
			FOCUS_CHANGE_FINISH_FROM_DRAW,
			FOCUS_CHANGE_FINISH_TO_DRAW,

			DRAW_TYPE_MAX
		};

		virtual void Draw(IData *data, IActor* parent, E_DRAW_TYPE drawType) = 0;
		virtual void Update(IData *data, IActor* parent) = 0;
		virtual void Resize(IData *data, IActor* parent, ClutterSize destSize, bool flagAni, int animationDuration) = 0;
		virtual void OnTransformStyle(IData *data, IActor* parent, int fromStyle, int toStyle, int parentWidth, int parentHeight, bool flagAni, int animationDuration){}

		virtual ~IRenderer(void)
		{
			
		}

		//Internal use
		virtual IThumbnail* Thumbnail(void) const
		{
			return NULL;
		}
	};

	class IRendererProvider
	{
	public:
		virtual IRenderer* GetRenderer(IData *data, IActor* parent) = 0;
	};
}

#endif //_HALO_IRENDERERPROVIDER_H_