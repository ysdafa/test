#ifndef _IWIZARDWIDGET_H_
#define _IWIZARDWIDGET_H_

namespace HALO
{
	//class HALO_API IWizardWidgetListener : public IListener
	//{
	//public:
	//	//virtual bool IfPreviousButtonPressed(class IButton* button, int buttonValue) = 0;
	//	//virtual bool IfNextButtonPressed(class IButton* button, int buttonValue) = 0;
	//	//virtual bool IfSkipButtonPressed(class IButton* button, int buttonValue) = 0;
	//	//virtual bool IfCloseButtonPressed(class IButton* button, int buttonValue) = 0;
	//	//virtual bool IfPreviousButtonMouseClicked(class IButton* button, int buttonValue) = 0;
	//	//virtual bool IfNextButtonMouseClicked(class IButton* button, int buttonValue) = 0;
	//	//virtual bool IfSkipButtonMouseClicked(class IButton* button, int buttonValue) = 0;
	//	//virtual bool IfCloseButtonMouseClicked(class IButton* button, int buttonValue) = 0;
	//};
	class HALO_API IWizardWidget : virtual public IActor
	{

	public:
		enum NAVIGATION_BUTTON_TYPE
		{
			NAVIGATION_BUTTON_TYPE_NONE = 0x00000000,  //!<
			NAVIGATION_BUTTON_TYPE_PREVIOUS = 0x00000001,  //!<
			NAVIGATION_BUTTON_TYPE_NEXT = 0x00000002,  //!<
			NAVIGATION_BUTTON_TYPE_SKIP = 0x00000004,  //!<
		};

	public:
		//! Initialize Wizard Widget.
		static IWizardWidget* CreateInstance(IActor* parent, int nTotalStep, int nNavigationButtonType);
	public:
		/*!
		\brief               Show Wizard Widget
		\return              None
		\see                 virtual void Hide(void) = 0;
		*/
		virtual void Show(void) = 0;
		/*!
		\brief               Hide Wizard Widget
		\return              None
		\see                 virtual void Show(void) = 0;
		*/
		virtual void Hide(void) = 0;
		////! Destroy Wizard Widget.
		//virtual void Destroy( void ) = 0;
		////! Update Wizard Widget. 
		//virtual void Update( int nLanguageID = -1 ) = 0;
		////! Set enable or disable, dim or not of Wizatd Widget.
		//virtual void EnableWidget( bool bEnable, bool bUseDefaultAlphaConstant = true ) = 0;
		////! Set enable or disable of navigation button.
		//virtual void EnableNavigationButton( bool bEnable, int nNavigationButtonType ) = 0;
		////! Get the enable flag of navigation button.
		//virtual bool FlagEnableNavigationButton( int nNavigationButtonType ) = 0;
		////! Show step button.
		//virtual void ShowStepButton( void ) = 0;
		////! Hide step button.
		//virtual void HideStepButton( void ) = 0;
		//! Set title.
		virtual void SetTitle(const char* pTitle) = 0;
		//! Set the current step.
		virtual void SetCurrentStep(int nCurrentStep) = 0;
		//! Get the current step.
		virtual int CurrentStep(void) = 0;
		//! Set the total step.
		virtual void SetTotalStep(int nTotalStep) = 0;
		//! Get the total step.
		virtual int TotalStep(void) = 0;
		////! Set TV step.
		//virtual void SetTVStep( int nIndex ) = 0;
		////! Set smart hub step.
		//virtual void SetSmartHubStep( int nIndex ) = 0;
		////! Set the step to hide divide image.
		//virtual void SetDevideImageHideStep( int nIndex ) = 0;
		////! Set the title image show(true) or hide(false)
		//virtual void EnableShowTitleImage( bool bTitleImageFlag ) = 0;
		////! Set the divide image show(true) or hide(false)
		//virtual void EnableShowDevideImage( bool bDevideImageFlag ) = 0;
		////! Set the type of navigation button.
		//virtual void SetNavigationButtonType( int nNavigationButtonType ) = 0;
		////! Set focus to navigation button by its tpye.
		//virtual void SetFocusToNavigationButton( int nNavigationButtonType ) = 0;
		////! Get the title.
		//virtual const char* Title( void ) = 0;
		////! Set ignore contrast option or not.
		//virtual void SetDisableContrastOption(bool bBlock) = 0;
		////! Add or Remove listener.
		//virtual bool AddListener(IWizardWidgetListener* listener) = 0;
		//virtual bool RemoveListener(IWizardWidgetListener* listener) = 0;
	};
}
#endif