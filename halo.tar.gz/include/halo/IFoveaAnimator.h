#ifndef _HALO_IFOVEAANIMATOR_H_
#define _HALO_IFOVEAANIMATOR_H_

namespace HALO
{
	class HALO_API IFoveaAnimator :  public Instance
	{
	public:
		static IFoveaAnimator* GetInstance(void);
		virtual float CalculateFoveaTransX(int width, int height, int posX, int posY, int cursorX, int cursorY, int cursorRadius) = 0;
		virtual float CalculateFoveaTransText(int width, int height, int centerX, int centerY, int cursorX, int cursorY) = 0;
		virtual void SetCurve(int curve) = 0;
		virtual void SetScaleFactor(float factor) = 0;

	private:
		static IFoveaAnimator* m_foveaAnimator;
			
		
	};
}
			
#endif
