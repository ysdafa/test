#ifndef _IDATALISTCONTROL_H_
#define _IDATALISTCONTROL_H_

namespace HALO
{
	class HALO_API IDataListControl : virtual public IActor
	{
	public:
		struct TDataListControlAttr : TWindowAttr
		{
			TDataListControlAttr(float inWidth, float inHeight) : TWindowAttr(inWidth, inHeight) {};
		};

/*!
\brief               Enable or disable the dynamic unload function.
\remarks             Control has function to unload the data which not showing, this API used to turn on/off the dynamic unload function
\param               flagEnable: [in] True means open the function, false means close it. 
\return              None
\note                N/A
*/
		virtual void EnableUnload(bool flagEnable) = 0;

/*!
\brief               Let control load the data.
\remarks             After add the items and add the data, user need to call this API.
\return              None
\note                N/A
*/
		virtual void LoadData(void) = 0;

/*!
\brief               Set the render provider.
\remarks             The render provider is used to provide the render, control will get render from the provider.
\param               rendererProvider: [in] The pointer of the provider. 
\return              None
\note                N/A
*/
		virtual void SetRendererProvider(IRendererProvider *rendererProvider) = 0;

/*!
\brief               Set the image of focus bar.
\remarks             If user don't call this API, the focusBar will not show.
\param               imageBuffer: [in] The pointer of focusBar's imageBuffer. 
\return              None
\note                N/A
*/
		virtual void SetFocusImage(IImageBuffer* imageBuffer, float xOffset, float yOffset) = 0;
		virtual void SetFocusImage(const char* imageName, float xOffset, float yOffset) = 0;

/*!
\brief               Set the enlarge value of focused item.
\remarks             When one item be focused, control can enlarge it. This API is used to set the enlarge value.
\param               widthDiff: [in] The enlarge width. 
\param               heightDiff: [in] The enlarge height. 
\return              None
\note                N/A
*/
		virtual void EnlargeFocusedItem(float widthDiff, float heightDiff) = 0;

/*!
\brief               Set the focus margin.
\remarks             This API is used to set the margin of focusBar.
\param               margin: [in] The TMargin has 4 values(Top, Bottom, Left, Right), it define the reachable range of focusBar. 
\return              None
\par Example:
\code
TMargin margin;
margin.Set(0, 0, 150, 150);
m_firstScrn->SetFocusMargin(margin);
\endcode
\note                N/A
*/
		virtual void SetFocusMargin(TMargin margin) = 0;

/*!
\brief               Get the margin of focusBar.
\param               margin: [out] The margin of focusBar. 
\return              None
\note                N/A
*/
		virtual void GetFocusMargin(TMargin &margin) = 0;

/*!
\brief               Move focusBar to next item.
\param               direction: [in] The direction of focusBar's moving. 
\return              bool: True means move success, false means move fail.
\note                N/A
*/
		virtual bool MoveFocus(EDirection direction) = 0;

/*!
\brief               Show the focusBar and enlarge the focused item.
\remarks             The focusBar will not show if user hasn't called SetFocusImage()
\param               flagAnimation: [in] Show focus with animation. 
\return              bool: Explain return value here 
\note                N/A
*/
		virtual bool ShowFocus(bool flagAnimation) = 0;

/*!
\brief               Hide the focusBar and disEnlarge the focused item.
\param               flagAnimation: [in] Hide focus with animation. 
\return              bool: True means success, false means fail.
\note                N/A
*/
		virtual bool HideFocus(bool flagAnimation) = 0;

/*!
\brief               Use to judge whether the control can scroll along the designated direction.
\param               dir: [in] The designated direction. 
\return              bool: True means can scroll, false means can't. 
\note                N/A
*/
		virtual bool IsDirectionScrollable(EDirection dir) = 0;

/*!
\brief               Get the visableArea rect.
\remarks             The position(x, y) of visableArea rect relative to the most left-up item's position, width and height is the ones of control.
\return              HALO::TRect: The visableArea rect. 
\note                N/A
*/
		virtual TRect VisibleAreaRect(void) = 0;

/*!
\brief               Scroll the visible area.
\param               xOffset: [in] The scroll distance on X-axis. 
\param               yOffset: [in] The scroll distance on Y-axis. 
\param               flagAni: [in] True means the scroll will be done by animation, false means jump to the destination directly. 
\return              None
\par Example:
\code
Add code snip here
\endcode
\see                 See other functions if needed
\note                N/A
*/
		virtual void ScrollVisibleArea(float xOffset, float yOffset, bool flagAni) = 0;

		/*!
		\brief:   Set the data list control can loop or not when moving focus left.
		\remarks:
		\param:   bool flag [in] the loop flag, true means can loop, false means can not loop.
		\return:  void
		\see:     IsLoopLeftEnabled
		*/
		virtual void EnableLoopLeft(const bool flagLoop) = 0;

		/*!
		\brief:   Set the data list control can loop or not when moving focus right.
		\remarks:
		\param:   bool flag [in] the loop flag, true means can loop, false means can not loop.
		\return:  void
		\see:     IsLoopRightEnabled
		*/
		virtual void EnableLoopRight(const bool flagLoop) = 0;

		/*!
		\brief:   Get the status of data list control can loop or not when moving focus left.
		\remarks:
		\param:   void
		\return:  bool:  If the data list control can loop return true, else return false.
		\see:     EnableLoopLeft
		*/
		virtual bool IsLoopLeftEnabled(void) const = 0;

		/*!
		\brief:   Get the status of data list control can loop or not when moving focus right.
		\remarks:
		\param:   void
		\return:  bool:  If the data list control can loop return true, else return false.
		\see:     EnableLoopRight
		*/
		virtual bool IsLoopRightEnabled(void) const = 0;

		/*!
		\brief:   Attach a scroll bar to data list control.
		\remarks: Data list control will be a listener of the attached scroll control.
		\param:   scroll: [in] The scroll going to be attached.
		\return:  void
		*/
		virtual void AttachScrollBar(class IScroll* scroll) = 0;

		/*!
		\brief:   Set the grid list control focused item has shadow effect or not.
		\remarks:
		\param:   bool flagShadowEffect [in] the shadow effect flag, true means set the shadow effect, false means no shadow effect.
		\return:  void
		\see:     IsShadowEffectEnabled
		*/
		virtual void EnableShadowEffect(const bool flagShadowEffect) = 0;

		/*!
		\brief:   Get whether the grid list control focused item has shadow effect.
		\return:  bool:  If the grid list control has shadow effect return true, else return false.
		\see:     EnableShadowEffect
		*/
		virtual bool IsShadowEffectEnabled(void) const = 0;

		/*!
		\brief:   Set the grid list control item has fovea effect or not when mouse moving in the item.
		\remarks:
		\param:   bool flagFoveaAni [in] the fovea effect flag, true means set the fovea effect, false means no fovea effect.
		\return:  void
		\see:     IsFoveaEffectEnabled
		*/
		virtual void EnableFoveaEffect(const bool flagFoveaAni) = 0;

		
		/*!
		\brief:   Get whether the grid list control item has fovea effect when mouse moving in the item.
		\return:  bool:  If the grid list control has fovea effect return true, else return false.
		\see:     EnableFoveaEffect
		*/
		virtual bool IsFoveaEffectEnabled(void) const = 0;

		virtual void SetCursorScrollArea(float totalSpace, float inShowAreaSpace) = 0;

		virtual void GetCursorScrollArea(float &totalSpace, float &inShowAreaSpace) = 0;

		virtual void SetChangeMount(const float changeMount) = 0;
		virtual float ChangeMount(void) = 0;
	};
}
#endif
