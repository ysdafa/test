#ifndef _HALO_IRICHTEXT_H_
#define _HALO_IRICHTEXT_H_

#ifndef WIN32
#define HAVE_ECORE_IMF
#endif

namespace HALO
{
	class HALO_API IRichTextListener : public IListener
	{
	public:
		virtual bool OnStateChanged(class IRichText* tab, int keyval) = 0;
	};

	class HALO_API IRichText : virtual public IActor
	{
	public:
		static IRichText* CreateInstance(IActor* parent, float width, float height);
		static IRichText* CreateInstance(Widget* parent, float width, float height);

	public:
		typedef struct T_CHARFORMAT
		{
			char *font;						//!< font name
			long size;						//!< font size
			unsigned long style;			//!< font style
			ClutterColor fgColor;			//!< text color
			ClutterColor bgColor;			//!< background color
			T_CHARFORMAT() :font(NULL), size(16), style(0), fgColor(), bgColor() {}
		}ITCharFormat;						//!< Char Format

		typedef struct T_PARAGRAPHFORMAT
		{
			unsigned int lineGap;		//!< paragraph gap
			int alignment;				//!< paragraph alignment
			T_PARAGRAPHFORMAT() :lineGap(0), alignment(0) {}
		}ITParaFormat;					//!< Paragraph format

		//! Struct of fontstyle.
		enum  T_FONTSTYLE
		{
			STYLE_NONE = 0x0000, /*!< NONE */
			STYLE_ITALIC = 0x0001, /*!< ITALIC */
			STYLE_BOLD = 0x0002, /*!< BOLD with bold weight */
			STYLE_BACKSLANT = 0x0004,	/*!< BACKSLANT*/
			STYLE_BORDERED = 0x0008,	/*!< BORDERED*/
			STYLE_BOLD_FILTER = 0x0010, /*!< BOLD using bold filter */
			STYLE_UNDERLINE = 0x0020, /*!< UNDERLINE */
			STYLE_STRIKE = 0x0040, /*!< STRIKE */
		};
	public:

		/*!
		\brief               Set text enable editable state.
		\param               flagEditable: [in]true: text editable; false: text non-editable. 
		\return              None
		*/
		virtual void EnableEditable(bool flagEditable) = 0;

		//! Get text enable editable state.
 		virtual bool IsEditableEnabled(void) = 0;

		/*!
		\brief               Set text single-line or multi-line state.
		\param               flagMutliLineMode: [in]true, multi-line state; false, single-line state. 
		\return              None
		*/
		virtual void EnableMultiLine(bool flagMutliLineMode) = 0;

		//!  Get text single-line or multi-line state.
		virtual bool IsMultiLineEnabled(void) = 0;

		//! Set text content.
		virtual void SetText(const char *text) = 0;

		//! Get text content.
		virtual const char* Text(void) = 0;

		/*!
		\brief               Set text font.
		\param               font: [in]Font name. 
		\return              None
		\par Example:
		\code
							 SetFont("Sans 20px");
							 SetFont("Sans");
		\endcode
		*/
		virtual void SetFont(const char* fontName) = 0;

		//! Get text font name.
		virtual const char* Font(void) = 0;

		//! Set text font size.
		virtual void SetFontSize(int size) = 0;

		//! Get text font size.
		virtual int FontSize(void) = 0;

		/*!
		\brief               Insert a char string to the text.
		\param               text: [in]The char string buffer. 
		\return              None
		\par Example:
		\code
							 InsertText("abc123def");
		\endcode
		*/
		virtual void InsertText(char *text) = 0;

		//! Delete selection text.
		virtual void DeleteText(void) = 0;

		/*!
		\brief               Set text enable select state.
		\param               flagSelectable: [in]true: text enable be selected; false: text disable be selected. 
		\return              None
		*/
		virtual void EnableSelectable(bool flagSelectable) = 0;

		//! Get the text enable selectable state.
 		virtual bool IsSelectableEnabled(void) = 0;

		//! Set a section text as selection.
		virtual void SetSelection(int startPos, int endPos) = 0;

		//! Get selection text buffer.
 		virtual char* Selection(void) = 0;

		//! Set selection text region color.
		virtual void SetSelectionColor(const ClutterColor color) = 0;

		//! Get selection text region color.
		virtual const ClutterColor& SelectionColor(void) = 0;

		//! Set text color.
		virtual void SetTextColor(const ClutterColor color) = 0;

		//! Get text color.
		virtual const ClutterColor& TextColor(void) = 0;

		//! Set text background color.
		virtual void SetBackgroundColor(const ClutterColor color) = 0;

		//! Get text background color.
		virtual const ClutterColor& BackgroundColor(void) = 0;

		//! Set text cursor color.
		virtual void SetCursorColor(const ClutterColor color) = 0;

		//! Get cursor color.
		virtual const ClutterColor& CursorColor(void) = 0;

		//! Set cursor position.
		virtual void SetCursorPosition(int charIndex) = 0;

		//! Get cursor position.
		virtual int CursorPosition(void) = 0;

		//! Set cursor width.
		virtual void SetCursorWidth(int width) = 0;

		//! Get cursor width.
		virtual int CursorWidth(void) = 0;

		/*!
		\brief               Set text enable HighLightMove state.
		\param               flagEnable: [in]true: enable HighLightMove; false: disable HighLightMove. 
		\return              None
		*/
		virtual void EnableHighlightMove(bool flagEnable) = 0;

		//! Get text enable HighLightMove state.
		virtual bool IsHighlightMoveEnabled(void) = 0;

		//! Set text HighLight region background color.
		virtual void SetHighlightMoveBgColor(ClutterColor color) = 0;

		//! Set text HighLight region background color.
		virtual void SetHighlightMoveBgColor(int a, int r, int g, int b) = 0;

		//! Get text HighLight region background color.
		virtual const ClutterColor& HighlightMoveBgColor(void) = 0;

		//! Get text HighLight region background color.
		virtual void GetHighlightMoveBgColor(unsigned char& a, unsigned char& r, unsigned char& g, unsigned char& b) = 0;

		/*!
		\brief               Move HighLight with direction.
		\param               dir: [in]Direction to move. 
		\return              None
		\par Example:
		\code
							 left: MoveHighlight(DIRECTION_LEFT);
							 right: MoveHighlight(DIRECTION_RIGHT);
		\endcode
		*/
		virtual void MoveHighlight(EDirection dir) = 0;

		/*!
		\brief               Move cursor with direction.
		\param               dir: [in]Direction to move. 
		\return              None
		\par Example:
		\code
							 left: MoveCursor(DIRECTION_LEFT);
							 right: MoveCursor(DIRECTION_RIGHT);
		\endcode
		*/
		virtual void MoveCursor(EDirection dir) = 0;

		//! Set cursor blink interval.
		virtual void SetCursorBlinkInterval(int interval) = 0;

		//! Get cursor blink interval.
		virtual int CursorBlinkInterval(void) = 0;

		//! Set text selection region border thick.
		virtual void SetBorderThickness(int thickness) = 0;

		//! Get text selection region border thick.
		virtual int BorderThickness(void) = 0;

		//! Copy the selection text buffer.
		virtual void Copy(void) = 0;

		//! Copy and delete the selection text buffer.
		virtual void Cut(void) = 0;

		//! Paste the selection text buffer.
		virtual void Paste(void) = 0;

		//! Get a special path file content, and set the content to show.
		virtual bool OpenFile(const char *filePath) = 0;

		//! Get current text content, and write the content to a special file.
		virtual bool SaveFile(const char *filePath) = 0;

		/*!
		\brief               Set selection text with a special char format.
		\remarks             Now the char format include: italic, bold and underline.
		\param               cf: [in]ITCharFormat. 
		\return              bool: true, succeed; false, failed.
		\par Example:
		\code
							 IRichText::ITCharFormat cf;
							 cf.style |= 1;		//italic;
							 cf.style |= 2;		//bold;
							 cf.style |= 32;	//underline;
							 SetCharFormat(cf);
		\endcode
		*/
		virtual bool SetCharFormat(ITCharFormat &cf) = 0;

		/*!
		\brief               Set selection paragraph with a special paragraph format.
		\remarks             The text must be in multi-line mode.
		\param               cf: [in]ITParaFormat. 
		\return              bool: true, succeed; false, failed.
		\par Example:
		\code
							 IRichText::ITParaFormat pf;
							 pf.alignment = 0;//left justify
							 SetParaFormat(pf);
		\endcode
		*/
		virtual bool SetParagraphFormat(ITParaFormat& pf) = 0;

		/*!
		\brief               Set text alignment.
		\remarks             The text must be in single-line mode.
		\param               hAlign: [in]EHAlignment.
		\param               vAlign: [in]EVAlignment.
		\return              bool: true, succeed; false, failed.
		\par Example:
		\code
		SetSingleLineTextAlignment(HALIGN_CENTER, VALIGN_MIDDLE);
		\endcode
		*/
		virtual bool SetSingleLineTextAlignment(EHAlignment hAlign, EVAlignment vAlign) = 0;

		/*!
		\brief               Get text alignment.
		\remarks             The text must be in single-line mode.
		\param               hAlign: [in]EHAlignment.
		\param               vAlign: [in]EVAlignment.
		\return              bool: true, succeed; false, failed.
		*/
		virtual bool GetSingleLineTextAlignment(EHAlignment& hAlign, EVAlignment& vAlign) = 0;

		//! Set text max count.
		virtual void SetSingleLineTextMaxCount(int count) = 0;

		//! Internal use. Add state changed listener.
		virtual bool AddStateChangedListener(IRichTextListener* listener) = 0;

		//! Internal use. Remove state changed listener.
		virtual bool RemoveStateChangedListener(IRichTextListener* listener) = 0;

#ifdef HAVE_ECORE_IMF		
		//! Get IMData that user set to IME.
		virtual	void GetIMEData(void *data, void *len) = 0;
		//! Set IME Data.
		virtual	void SetIMEData(const char *imdata) = 0;
		//!Get IME enable param.
		virtual	bool IsIMFEnableOnFocus() = 0;
		//! Set IME shown on CRichText Foucs.
		virtual	void EnableIMFOnFocus(bool is_enable) = 0;
		//! Show IME panel.
		virtual	void ShowIMFContext() = 0;
		//! Hide IME panel.
		virtual	void HideIMFContext()= 0;
		//! Focus in IMF.
		virtual void FocusInIMFContext() = 0;
		//! Focus out IMF.
		virtual void FocusOutIMFContext() = 0;
#endif
	};
}

#endif
