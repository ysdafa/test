#ifndef _ISUBLIST_H_
#define _ISUBLIST_H_

namespace HALO
{
	class HALO_API ISubListListener : public IListener
	{
	public:
		enum EEventType
		{
			ON_ITEM_CLICKED    = 0,	    //!< item clicked type.
			ON_FOCUS_CHANGED,	        //!< focus changed type.
			ON_ENTER_KEY_LONG_PRESSED,  //!< item long pressed type.
			TIME_OUT      	            //!< time out type.
		};

		/*!
		\brief               process the event when item clicked.
		\param               subList:[in] The selected sublist. 
		\return              bool
		*/
		virtual bool OnItemClicked(class ISubList* subList, int itemIndex) { return false; }
		/*!
		\brief               process the event when item clicked.
		\param               subList:[in] The selected sublist. 
		\return              bool
		*/
		virtual bool OnFocusChanged(class ISubList *subList, int fromItemIndex, int toItemIndex) { return false; }
		/*!
		\brief               process the event when item long pressed by enter key.
		\param               subList:[in] The selected sublist. 
		\return              bool
		*/
		virtual bool OnEnterKeyLongPressed(class ISubList *subList, int itemIndex) { return false; }
		/*!
		\brief               process the event when time out.
		\param               subList:[in] The selected sublist. 
		\return              bool
		*/
		virtual bool OnTimeOut(class ISubList* subList) { return false; }
	};

	class HALO_API ISubList: virtual public IActor
	{
	public:
		enum EArrowDirection
		{
			UP_ARROW          = 0,	//!< up arrow.
			DOWN_ARROW,             //!< down arrow.
			LEFT_ARROW,             //!< left arrow.
			RIGHT_ARROW,	        //!< right arrow.
		};
		typedef uint EArrowDirections;

		struct TArrowAttr
		{
			float x;		    //!< sub list x position.
			float y;		    //!< sub list y position.
			float w;		    //!< sub list width.
			float h;		    //!< sub list height.
			std::string arrowNormalImagePath;		 //!< arrow normal image.
			std::string arrowFocusedImagePath;		 //!< arrow focus image.
			std::string arrowDimImagePath;           //!< arrow dim image.
			int normalAlpha;                         //!< arrow normal image alpha.
			int focusAlpha;                         //!< arrow focus image alpha.
			int dimAlpha;                         //!< arrow dim image alpha.
			TArrowAttr() : x(0), y(0), w(0), h(0), arrowNormalImagePath(""), arrowFocusedImagePath(""), arrowDimImagePath(""), normalAlpha(128), focusAlpha(255), dimAlpha(25) {}
		};

		struct TSubListAttr
		{
			float x;		    //!< sub list x position.
			float y;		    //!< sub list y position.
			float w;		    //!< sub list width.
			float h;		    //!< sub list height.
			int nTotalItemNumber;		                              //!< sub list total item number.
			int nItemNumberOnWindow;		                          //!< item number shown in current window.
			float singleLineListWidth;                  //!< sinle line list control width
			float singleLineListHeight;                 //!< sinle line list control height
			EDirectionType singleLineListType;          //!< Define whether the control is vertical or horizontal.
			TSubListAttr() : x(0), y(0), w(200), h(72), nTotalItemNumber(0), nItemNumberOnWindow(5), singleLineListWidth(200), singleLineListHeight(72), singleLineListType(EDirectionType::TYPE_VERTICAL) {}
		};

	public:
		/*!
		\brief               Create a new sub list
		\param               parent:[in] The parent of the sub list. 
		\param               attr:[in] The sub list attribute. 
		\return              HALO::ISubList *: A pointer to ISubList
		\par Example:
		\code
			IActor *m_window;
			ISubList *m_SubList;
			ISubList::TSubListAttr attr;
			attr.x = 0;
			attr.y = 0;
			attr.w = 200;
			attr.h = 360;
			m_SubList = ISubList::CreateInstance(m_window ,attr);
		*/
		static ISubList* CreateInstance(IActor* parent, const TSubListAttr &attr);
		static ISubList* CreateInstance( Widget* parent, const TSubListAttr &attr );
	public:
		/*!
		\brief               set first bg color.
		\param               BGColor: [in] bg color. 
		\return              None
		\note                N/A
		*/
		virtual void SetFirstLayerBGColor(const ClutterColor BGColor) = 0;
		/*!
		\brief               set second bg color.
		\param               BGColor: [in] bg color. 
		\return              None
		\note                N/A
		*/
		virtual void SetSecondLayerBGColor(const ClutterColor BGColor) = 0;
		/*!
		\brief               set third bg color.
		\param               BGBorderWidth: [in] bg color. 
		\return              None
		\note                N/A
		*/
		virtual void SetThirdLayerBGBorderWidth(float BGBorderWidth) = 0;
		/*!
		\brief               set third bg color.
		\param               BGBorderColor: [in] border color. 
		\return              None
		\note                N/A
		*/
		virtual void SetThirdLayerBGBorderColor(const ClutterColor BGBorderColor) = 0;
		/*!
		\brief               set shadow bg image.
		\param               shadowImagePath: [in] shadow image Path. 
		\return              None
		\note                N/A
		*/
		virtual void SetFourthLayerBGImage(std::string &shadowImagePath) = 0;
		/*!
		\brief               Add items.
		\remarks             Different items can have different spaces.
		\param               itemNum: [in] The number of added items. 
		\param               itemSpaceArray: [in] The space array of the items. 
		\return              None
		\note                N/A
		*/
		virtual void AddItem(int itemNum, float *itemSpaceArray, float itemGap ) = 0;
		/*!
		\brief               Add items.
		\remarks             Every items have the same space.
		\param               itemNum: [in] The number of added items. 
		\param               itemSpace: [in] The space of the items. 
		\return              None
		\note                N/A
		*/
		virtual void AddItem(int itemNum, float itemSpace, float itemGap) = 0;
		/*!
		\brief               Updata item by index.
		\param               itemIndex: [in] Item index. 
		\return              None
		\note                N/A
		*/		
		virtual void UpdateItem(int itemIndex) = 0;
		/*!
		\brief               Delete items.
		\param               fromItem: [in] The first item to delete. 
		\param               deleteItemNum: [in] The number of delete items. 
		\return              None
		\note                N/A
		*/
		virtual void DeleteItem(int fromItem, int deleteItemNum) = 0;
		/*!
		\brief               Updata all items. 
		\return              None
		\note                N/A
		*/	
		virtual void UpdateAllItems(void) = 0;
		/*!
		\brief               Set data source. 
		\return              None
		\note                N/A
		*/	
		virtual void SetDataSource() = 0;
		/*!
		\brief               Get data source. 
		\return              ISingleLineDataSource
		\note                N/A
		*/	
		virtual ISingleLineDataSource* GetDataSource() = 0;
		/*!
		\brief               Get renderer. 
		\return              IRenderer
		\note                N/A
		*/	
		virtual IRenderer* GetRenderer(IData *data, IActor *parent) = 0;
		/*!
		\brief               Set the itemIndex that need to be focused.
		\param               itemIndex: [in] The index of focused item. 
		\return              None
		\note                N/A
		*/
		virtual void SetFocusItemIndex(const int itemIndex) = 0;
		/*!
		\brief               Get the index of focused item.
		\return              int: [in] The index of focused item. 
		\note                N/A
		*/
		virtual int FocusItemIndex(void) const = 0;
		/*!
		\brief               singlelinelist show focus.
		\param               flagAnimation: [in] flag of animation.
		\note                N/A
		*/
		virtual bool ShowFocus(bool flagAnimation) = 0;
		/*!
		\brief               singlelinelist hide focus.
		\param               flagAnimation: [in] flag of animation.
		\note                N/A
		*/
		virtual bool HideFocus(bool flagAnimation) = 0;
		/*!
		\brief               singlelinelist set focus.
		\note                N/A
		*/
		virtual bool SetFocus(void) = 0;
		/*!
		\brief               singlelinelist kill focus.
		\note                N/A
		*/
		virtual void KillFocus(void) = 0;
		/*!
		\brief               set single line list position.
		\param               x: [in] x position. 
		\param               y: [in] y position. 
		\return              None
		\note                N/A
		*/
		virtual void SetSingleLineListPosition(const float x, const float y) = 0;
		/*!
		\brief               set arrow image attr.
		\param               arrowDirection: [in] arrow direction. 
		\param               arrowAttr: [in] arrow attribute. 
		\return              None
		\note                N/A
		*/
		virtual void SetArrowImageAttr(EArrowDirections arrowDirection, const TArrowAttr &arrowAttr) = 0;
		/*!
		\brief               set button attr.
		\param               buttonImageRect: [in] button rect. 
		\param               buttonNormalImagePath: [in] button normal image path.
		\param               buttonFocusedImagePath: [in] button focused image path.
		\param               buttonDimImagePath: [in] button dim image path.
		\return              None
		\note                N/A
		*/		
		virtual void SetButtonAttr(const TRect &buttonImageRect, std::string &buttonNormalImagePath, std::string &buttonFocusedImagePath, std::string &buttonDimImagePath) = 0;
		/*!
		\brief               Set the checked itemIndex that need to be focused.
		\param               checkedItemIndex: [in] The index of checked item. 
		\return              None
		\note                N/A
		*/
		virtual void SetCheckItemIndex(int checkedItemIndex) = 0;
		/*!
		\brief               Get the index of checked item.
		\return              int: [in] The index of checked item. 
		\note                N/A
		*/
		virtual int CheckItemIndex() const = 0;
		/*!
		\brief               Get the number of items.
		\return              int: [in] The number of items. 
		\note                N/A
		*/
		virtual int NumofItem(void) = 0;
		/*!
		\brief               Set dim item by item index.
		\param              itemIndex: [in] The item index. 
		\param              ifDim: [bool] Dim flag. 
		\note                N/A
		*/
		virtual void SetDimItem(int itemIndex, bool ifDim) = 0;
		/*!
		\brief               Get the dim flag of item.
		\param              itemIndex: [in] The item index. 
		\return              bool: [bool] The dim flag. 
		\note                N/A
		*/
		virtual bool IfDim(int itemIndex) = 0;
		/*!
		\brief               Set the duration of animations in control
		\param               aniType: [in] The animationType. 
		\param               duration: [in] The duration of animation. 
		\return              None
		\note                N/A
		*/
		virtual void SetAnimationDuration(ISingleLineListControl::ESingleLineAniType aniType, int duration) = 0;
		/*!
		\brief               Get text string by item index.
		\param              itemIndex: [in] The item index. 
		\return              std::string: [std::string] The dim flag. 
		\note                N/A
		*/
		virtual std::string Text(int itemIndex) = 0;
		/*!
		\brief               Get text2 string by item index.
		\param              itemIndex: [in] The item index. 
		\return              std::string: [std::string] The dim flag. 
		\note                N/A
		*/
		virtual std::string Text2(int itemIndex) = 0;
		/*!
		\brief               Add ISubListListener.
		\param               listener:[in] ISubListListener rewrite by user. 
		\return              bool 
		*/
		virtual bool AddListener(ISubListListener* listener) = 0;
		/*!
		\brief               Remove ISubListListener.
		\param               listener:[in] ISubListListener rewrite by user. 
		\return              bool 
		*/
		virtual bool RemoveListener(ISubListListener* listener) = 0;
		/*!
		\brief               Set show time(ms).
		\param               nShowTime:[in] show time(ms). 
		\return              None
		*/
		virtual void SetShowTime(guint nShowTime) = 0;
		/*!
		\brief               Set show time(ms).
		\return              show time(ms)
		*/
		virtual guint ShowTime() const = 0;
	};
}
#endif
