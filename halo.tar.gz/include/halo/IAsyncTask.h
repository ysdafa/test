#ifndef _IASYNCTASK_H_
#define _IASYNCTASK_H_
namespace HALO
{
	class IEventManager;
	class HALO_API IAsyncTask;
	class HALO_API ITaskListener : public IListener
	{
	public:
		ITaskListener();
		~ITaskListener();

		//! Process the event.
		bool Process(IEvent* event);

		//! Listen the task whether is start.
		virtual void* OnStart(void* params) = 0;

		//! Listen the task whether is working.
		virtual bool OnUpdate(void* result) = 0;

	    //! Listen the task whether is finished.
		virtual bool OnFinish(void* result) = 0;

		//! Listen the task whether is canceled when working.
		virtual bool OnCancel(void* params) = 0;

		//! Set one asynctask as the tasklistener will listen.
		void SetTask(IAsyncTask* task) {m_task = task;}

		//! Get the task which the tasklistener listening.
		IAsyncTask* GetTask(void) {return m_task;}
	private:
		IAsyncTask* m_task;
	};

	class HALO_API IAsyncTask : public Instance
	{
	public:		
		/*!
		\brief				 Create an IAsyncTask instance.
		\return              The new created instance pointer.
		*/
		static IAsyncTask* CreateInstance(void);

		/*!
		\brief               Create an IAsyncTask instance with an void* params.
		\param               params [in] An void* param. 
		\return              The new created instance pointer. 
		*/
		static IAsyncTask* CreateInstance(void* params);

		/*!
		\brief               Create an IAsyncTask instance with an void* params and an IThreadPool pointer.
		\param               params [in] An void* param. 
		\param               threadPool [in] An threadpool pointer. 
		\return              The new created instance pointer.
		*/
		static IAsyncTask* CreateInstance(void* params, IThreadPool* threadPool);

		/*!
		\brief               The asynctask begin start work.
		\return              true or false. 
		*/
		virtual bool Execute(void) = 0;

		/*!
		\brief               Update the result of asynctask when working.
		\param               result [in] The result of the asynctask work out. 
		\return              true or false.
		*/
		virtual bool Update(void* result) = 0;

		/*!
		\brief               Cancel the asynctask when working
		*/
		virtual void Cancel(void) = 0;

		/*!
		\brief               Add the taskListener to the asynctask.
		\param               taskListener [in] An tasklistener pointor. 
		\return              true or false.
		\see                 IAsyncTask::RemoveTaskListener().
		*/
		virtual bool SetTaskListener(ITaskListener* taskListener) = 0;

		/*!
		\brief               Remove the tasklistener from the asynctask.
		\param               taskListener [in] An tasklistener pointor. 
		\return              true or false.
		\see                 IAsyncTask::AddTaskListener().
		*/
		virtual bool RemoveTaskListener(ITaskListener* taskListener) = 0;
	};
}

#endif