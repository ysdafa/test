#ifndef WIN32
#ifndef _HALO_IVIDEOACTOR_H_
#define _HALO_IVIDEOACTOR_H_



namespace HALO
{
	class HALO_API IVideoActor : virtual public IActor
	{
	public:
		
		static IVideoActor* CreateInstance(IActor* parent, float width, float height, ClutterVideoController type);

		static IVideoActor* CreateInstance(Widget* parent, float width, float height, ClutterVideoController  type);
	 
	public:

		virtual ClutterVideoController  VideoType(void) const = 0;
		
	};
}

#endif
#endif