#ifndef _IEVENTMANAGER_H_
#define _IEVENTMANAGER_H_

namespace HALO
{
	class IEvent;
	class ITaskListener;
	class HALO_API IEventManager : public Instance
	{
	public:
		/*!
		\brief               Get an single instance of IEventManager.
		\return              The single instance.
		*/
		static IEventManager* GetInstance(void);

	public:
		/*!
		\brief               Send the event between the same app.
		\param               event [in] The event will be sent. 
		\return              true or false. 
		*/
		virtual bool SendEventLocal(IEvent* event) = 0;

		/*!
		\brief               Send the event between the same app using synchronized methods.
		\param               reqEvent [in]  The event will be sent. 
		\param               resEvent [out] The event will be returned. 
		\return              true or false. 
		*/
		virtual bool SendEventLocalSync(IEvent* reqEvent, IEvent* resEvent) = 0;

		/*!
		\brief               Send the event between different apps.
		\param               target [in] The target where the event will send. 
		\param               requestEvent [in] The event will be sent.
		\param               bAsync [in] True or false. 
		\param               pbHasResponse[out] Has response or not
		\param               responseEvent [out] The event will be returned from target. 
		\return              Send request event to target success or fail.
		*/
		virtual bool SendEventRemote(const char* target, IEvent* requestEvent, bool bAsync, bool* pbHasResponse, IEvent* responseEvent) = 0;

		/*!
		\brief               Add systemevent listener.
		\param               systemListener [in] The systemListener will be added. 
		\return              true or false.
		\see                 IEventManager::RemoveSystemEventListener().
		*/
		virtual bool AddSystemEventListener(ISystemEventListener* systemListener) = 0;

		/*!
		\brief               Remove systemevent listener.
		\param               systemListener [in] The systemListener will be removed. 
		\return              true or false. 
		*/
		virtual bool RemoveSystemEventListener(ISystemEventListener* systemListener) = 0;

		/*!
		\brief               Add customevent listener.
		\param               customListener [in] The customListener will be added. 
		\return              true or false.
		\see                 IEventManager::RemoveCustomEventListener().
		*/
		virtual bool AddCustomEventListener(ICustomEventListener* customListener) = 0;

		/*!
		\brief               Remove customevent listener.
		\param               customListener [in] The customListener will be removed. 
		\return              true or false.
		*/
		virtual bool RemoveCustomEventListener(ICustomEventListener* customListener) = 0;

		/*!
		\brief               Get the type of event according to eventname.
		\param               eventName [in] The name of event. 
		\return              The type of event.
		*/
		virtual int GetEventType(const char* eventName) = 0;

		/*!
		\brief               Get the eventname according to event-type.
		\param               eventType [in] The type of event. 
		\return              The name of event.
		*/
		virtual const char* GetEventName(int eventType) = 0;

		/*!
		\brief               Register interesting event
		\param               eventName [in] The name of event. 
		*/
		virtual void RegisterInterestingEvent(const char *eventName) = 0;

		/*!
		\brief               Unregister interesting event
		\param               eventName [in] The name of event. 
		\see                 IEventManager::RegisterInterestingEvent().
		*/
		virtual void UnregisterInterestingEvent(const char *eventName) = 0;

		/*!
		\brief              Set the key long press teimer interval.
		\param               Key long press timer interval. 
		*/
		virtual void SetKeyLongPressInterval(int interval) = 0;

		/*!
		\brief              Get the key long press teimer interval.
		\return               Key long press timer interval. 
		*/
		virtual int KeyLongPressInterval(void) = 0;

		/*!
		\brief              SendAsyncRelease Event
		\return              return false if duplicate release. 
		*/
		virtual bool AsyncRelease(Widget* target) = 0;
		virtual bool AsyncReleaseListenerSet(ListenerSet* target) = 0;

		/*!
		\brief              Remove target that will be async release
		\return               return false if target does not exist.
		*/
		virtual bool RemoveAsyncReleaseTarget(Widget* target) = 0;

		/*!
		\brief              Add focus target that will be receive focus event
		\return               return true
		*/
		virtual bool AddFocusTarget(IWidgetExtension* target) = 0;

		/*!
		\brief              Remove focus target that will be receive focus event
		\return               return false if target does not exist.
		*/
		virtual bool RemoveFocusTarget(IWidgetExtension* target) = 0;
	private:
		static IEventManager* g_eventManager;
	};
}
#endif
