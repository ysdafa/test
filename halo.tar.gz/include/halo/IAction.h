#ifndef _IACTION_H_
#define _IACTION_H_

namespace HALO
{
	class HALO_API IAction : public Instance
	{
	public:
		/*!
		\brief               Initalize the action by the passing actor param.
		\param               params [in] The actor which will bind the action. 
		\return              true or false.
		\see                 IAction::IsInitialized().
		*/
		virtual bool Initialize(IActor* params) = 0;

		/*!
		\brief               Check whether the action is initialized.
		\return              true or false.
		\see                 IAction::Initialize().
		*/
		virtual bool IsInitialized(void) const = 0;

		/*!
		\brief               Check whether the event is action's interesting event. 
		\param               event [in] An event which will be checked. 
		\return              true or false. 
		*/
		virtual bool IsInterestEvent(IEvent* event) = 0;

		/*!
		\brief               Process the passing event. 
		\param               inEvent [in] An event passed-in needed to handle. 
		\param               outEvent [out] An event passed-out which has been handled. 
		\return              true or false.
		*/
		virtual bool Process(IEvent* inEvent, IEvent** outEvent) = 0;

		/*!
		\brief               Return ClutterAction. 
		\return              ClutterAction.
		*/
		virtual ClutterAction* Action(void) = 0;
	};

	class HALO_API IClickAction :virtual public IAction
	{
	public:
		/*!
		\brief               Create an IClickAction instance without params.
		\return              The new created instance pointer.
		\see                 IClickAction::CreateInstance(IActor* params).
		*/
		static IClickAction* CreateInstance(void);

		/*!
		\brief               Create an IClickAction instance with an actor param.
		\param               params [in] The actor which will bind the instance. 
		\return              The new created instance pointer.
		\see                 IAction::Initialize(IActor* params).
		*/
		static IClickAction* CreateInstance(IActor* params);
	};

	class HALO_API IDragAction : virtual public IAction
	{
	public:

		/*!
		\brief               Create an IDragAction instance with an actor param.
		\param               params [in] The actor which will bind the instance.
		\return              The new created instance pointer. 
		\see                 IAction::Initialize(IActor* params).
		*/
		static IDragAction* CreateInstance(IActor* params); 

		/*!
		\brief               Set the Drag Axis with the axis param.
		\param               axis [in] The axis of the constraint that should be applied on the
									   dragging action. 
		\return              None
		\par Example:
		\code
							IActor* actor;
							IDragAction* daction = IDragAction::CreateInstance(actor);
							actor->AddAction(daction);
							daction->SetDragAxis(CLUTTER_DRAG_X_AXIS);
		\endcode
		\note               The params contains��
							CLUTTER_DRAG_AXIS_NONE : No constraint;
							CLUTTER_DRAG_X_AXIS : Set a constraint on the X axis;
							CLUTTER_DRAG_Y_AXIS : Set a constraint on the Y axis.
		*/
		virtual void SetDragAxis(ClutterDragAxis axis) = 0;

		/*!
		\brief               Set the drag area with the position params.
		\param               x [in] The Left-top x-coordinate of drag area. 
		\param               y [in] The Left-top y-coordinate of drag area. 
		\param               width [in] The width of drag area. 
		\param               height [in] The height of drag area. 
		\par Example:
		\code
							IActor* actor;
							IDragAction* daction = IDragAction::CreateInstance(actor);
							actor->AddAction(daction);
							daction->SetDragAxis(CLUTTER_DRAG_X_AXIS);
							daction->SetDragArea(0,0,100,100);
		\endcode
		\note               If drag_area is NULL, the actor is not constrained.
		*/
		virtual void SetDragArea(float x, float y, float width, float height) = 0;

		/*!
		\brief               Get the drag axis.
		\return              0 :  CLUTTER_DRAG_AXIS_NONE,
							 1 :  CLUTTER_DRAG_X_AXIS,
							 2 :  CLUTTER_DRAG_Y_AXIS
		\see                 IDragAction::SetDragAxis(ClutterDragAxis axis).
		*/
		virtual int GetDragAxis(void) = 0;

		/*!
		\brief               Get the drag area.
		\param               drag_area [out] The area which drag-action can move. 
		\see				 IDragAction::SetDragArea(float x, float y, float width, float height).
		*/
		virtual void GetDragArea(ClutterRect *drag_area) = 0;
	};

	class HALO_API IGestureAction : virtual public IAction
	{
	public:	
		/*!
		\brief               Create an IGestureAction instance with an actor param.
		\param               params [in] The actor which will bind the instance.
		\return              The new created instance pointer. 
		\see                 IAction::Initialize(IActor* params).
		*/
		static IGestureAction* CreateInstance(IActor* params);
	};

	class HALO_API IKeyLongPressAction : virtual public IAction
	{
	public:
		/*!
		\brief               Create an IKeyLongPressAction instance with an actor param.
		\param               params [in] The actor which will bind the instance.
		\return              The new created instance pointer. 
		\see                 IAction::Initialize(IActor* params).
		*/
		static IKeyLongPressAction* CreateInstance(IActor* params);

		/*!
		\brief               Add long press key defined to KeyLongPressAction in order.
		\param               key_val [in] The value of the key.
		\return              true or false. 
		*/
		virtual bool AddLongPressKey(unsigned int key_val) = 0;

		/*!
		\brief               Remove long press key defined to KeyLongPressAction in order.
		\param               key_val [in] The value of the key.
		\return              true or false. 
		*/
		virtual bool RemoveLongPressKey(unsigned int key_val) = 0;
	};

	class HALO_API IKeyCombinationAction : virtual public IAction
	{
	public:
		/*!
		\brief               Create an IKeyCombinationAction instance with an actor param.
		\param               params [in] The actor which will bind the instance.
		\return              The new created instance pointer. 
		\see                 IAction::Initialize(IActor* params).
		*/
		static IKeyCombinationAction* CreateInstance(IActor* params);

		/*!
		\brief               Add each key defined to KeyCombinationAction in order.
		\param               key_val [in] The value of the key.
		\return              true or false. 
		*/
		virtual bool AddKey(unsigned int key_val) = 0;
	};
}

#endif