#ifndef _HALO_IDATASOURCE_H_
#define _HALO_IDATASOURCE_H_

namespace HALO
{
	class HALO_API IData //App should extend IData to define their own data type.
	{
	public:
		enum EDataLoadType
		{
			E_LOAD_TYPE_SYNC = 0,
			E_LOAD_TYPE_ASYNC,
			E_LOAD_TYPE_SYNC_ASYNC,
			E_LOAD_TYPE_MAX,
		};

		IData() :isReady(false), dataLoadType(E_LOAD_TYPE_SYNC), m_numOfWindow(1){}
		virtual ~IData(){}

		bool IsReady(void) const; 
		void SetReady(const bool readyFlag);

		EDataLoadType DataLoadType(void) { return dataLoadType; }
		void SetDataLoadType(EDataLoadType loadType) { dataLoadType = loadType; }

		void SetWindowNum(const int num) {m_numOfWindow = num;}
		int NumOfWindow(void) const;

		virtual void Release(void) {};

		int curUsingSubData;

	private:
		bool isReady;
		EDataLoadType dataLoadType;
		int m_numOfWindow;
	};

	class HALO_API ISingleLineDataSource
	{
	public:
		//! Adds @data to the end of data source list
		virtual void AddData(IData *data) = 0;
		virtual void InsertData(int index, IData *data) = 0;
		//! Removes data at @index from data source list
		virtual void DeleteData(int itemIndex) = 0;
		virtual IData* GetData(int itemIndex) = 0;
		virtual int Size(void) = 0;
		virtual void DeleteAll(void) = 0;
	};

	class HALO_API IGridDataSource
	{
	public:
		//! add number of group to data source.
		virtual void AddGroup(int numberOfGroup) = 0;
		//! delete given group of data source, which will delete all data in the group.
		virtual void DeleteGroup(int groupIndex) = 0;
		//! add data to given group.
		virtual void AddData(int groupIndex, IData *data) = 0;
		//! delete data from given group with given index.
		virtual void DeleteData(int groupIndex, int itemIndex) = 0;
		//! get data of given group with given index.
		virtual IData* GetData(int groupIndex, int itemIndex) = 0;
		//! get group count in data source.
		virtual int NumOfGroup(void) = 0;
		//! get data count in given group of data source.
		virtual int NumOfData(int groupIndex) = 0;
		//! delete all data of the data source.
		virtual void DeleteAll(void) = 0;
		//! insert data to index.
		virtual void InsertData(IData* data, int groupIndex, int itemIndex) = 0;
		
	};

	class HALO_API IMatrixDataSource
	{
	public:
		virtual void AddData(IData *data, int row, int col) = 0;
		virtual void AddRow(int numCols, IData* data[]) = 0;
		virtual void AddColumn(int numRows, IData* data[]) = 0;

		virtual void DeleteData(int row, int col) = 0;
		virtual void DeleteRow(int row) = 0;
		virtual void DeleteColumn(int column) = 0;
		virtual void DeleteAll(void) = 0;

		virtual void GetSize(int &numOfRow, int &numOfColumn) = 0;
	};

	class HALO_API IFirstScreenDataSource
	{
	public:
		virtual void AddMainMenuData(IData *data) = 0;
		virtual void AddScrollDataInMainMenu(IData *data, int mainMenuIndex) = 0;
		virtual void AddSubMenuData(IData *data, int mainMenuIndex) = 0;

		virtual void DeleteSubMenuData(int mainMenuIndex, int subMenuItemIndex) = 0;

		virtual IData* MainMenuData(int menuItemIndex) = 0;
		virtual IData* ScrollData(int menuItemIndex, int scrollDataIndex) = 0;
		virtual IData* SubMenuData(int menuItemIndex, int subMenuItemIndex) = 0;

		virtual int NumOfMainMenuData(void) = 0;
		virtual int NumOfScrollData(int menuItemIndex) = 0;
		virtual int NumOfSubData(int menuItemIndex) = 0;
	};
}

#endif //_HALO_IDATASOURCE_H_