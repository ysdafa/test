#ifndef _HALO_IMATRIXLISTCONTROL_H_
#define _HALO_IMATRIXLISTCONTROL_H_

namespace HALO
{
	class HALO_API IMatrixListControl : virtual public IDataListControl
	{
	public:
		struct TMatrixListControlAttr : public TDataListControlAttr
		{
			int rowHight;
			int colWidth;
			TMatrixListControlAttr(float inWidth, float inHeight) : TDataListControlAttr(inWidth, inHeight) {}
		};
	public:
		static IMatrixListControl* CreateInstance(IActor *parent, const TMatrixListControlAttr &attr) { return NULL; }

	public:
		virtual void SetColumnTitleHeight(int height) = 0;
		virtual IText *ColumnTitle(int column) = 0;

#if 0
		virtual void SetRowHight(int row, int height) = 0;
		virtual void SetColumnWidth(int column, int width) = 0;

		virtual void SetSeparateLine(IImageBuffer *image, int width, int xOffset) = 0;

		virtual void SetSeparateLine(ClutterColor color, int width, int xOffset) = 0;

		//! Set focus to given item index
		virtual bool SetFocusItemIndex(int itemColIndex, int itemRowIndex) = 0;

		//! Set range for focus move. only available before build.
		virtual void SetFocusableLayoutRange(int startLine, int endLine, EDirectionType scrollType) = 0;

		//! Get currently focused item. if the list is not built, returns -1. 
		virtual void FocusItemIndex(int &itemColIndex, int &itemRowIndex) = 0;

		//! gets given direction is scrollable or not, if list is not built, it returns false.
		virtual bool FlagScrollableDirection(EDirection dir) = 0;

		//! Set enable or disable for scroll end to end
		virtual void EnableLoop(bool flagAllowEndToEnd) = 0;

		//! Get end to end state
		virtual bool FlagEnagleLoop(void) = 0;

		//! Enables loop on continuous key input
		virtual void EnableLoopOnContinuousKey(void) = 0;

		//! disables loop on continuous key input
		virtual void DisableLoopOnContinuousKey(void) = 0;

		//! Set end to end fade out length 
		virtual void SetEndToEndFadeLength(int itemMoveLength, int highlightMoveLength) = 0;

		//! Set cover image
		virtual void SetCoverImage(IImageBuffer *image) = 0;
#endif
	};

}

#endif //_HALO_IMATRIXLISTCONTROL_H_