#ifndef _HALO_IRECTANGLE_H_
#define _HALO_IRECTANGLE_H_

namespace HALO
{
	class HALO_API IRectangle : virtual public IActor
	{
	public:
		/*!
		\brief               Create a new rectangle
		\remarks             The parent is not recommended to NULL.
		\param               parent:[in]      The parent of rectangle.
		\param               width:[in]		  The width of rectangle.
		\param               height:[in]      The height of rectangle.
		\return              HALO::IRectangle *: The newly created rectangle instance pointer.
		\par Example:
		\code
			IRectangle* rect = IRectangle::CreateInstance(m_window, width, height);		
		\endcode
		\see                 IActor::CreateInstance()
		*/
		static IRectangle* CreateInstance(IActor* parent, float width, float height);
		static IRectangle* CreateInstance(Widget* parent, float width, float height);

	public:
		virtual void SetBorderThickness(float topThickness, float leftThickness, float bottomThichness, float rightThickness) = 0;
		
		virtual void GetBorderThickness(float &topThickness, float &leftThickness, float &bottomThichness, float &rightThickness) = 0;


		/*!
		\brief               Get border color
		\return              const ClutterColor &: border color
		*/
		virtual const ClutterColor& BorderColor(void) const = 0;

		/*!
		\brief               Set border color
		\param               color:[in] border color 
		\return              None 
		*/
		virtual void SetBorderColor(const ClutterColor& color) = 0;
	};
}


#endif	//_HALO_IRECTANGLE_H_