#ifndef _HALO_IDIM_WINDOW_H_
#define _HALO_IDIM_WINDOW_H_

namespace HALO
{
	class HALO_API IDimWindow : virtual public IActor
	{
	public:
		static IDimWindow* CreateInstance(Widget* parent, float width, float height);

	public:
		virtual void AddTransparentArea(float x, float y, float width, float height) = 0;
		virtual void ClearTransparentArea(void) = 0;

	private:
		static IDimWindow* m_dimWin;
	};
}
#endif /*_HALO_IDIM_WINDOW_H_*/
