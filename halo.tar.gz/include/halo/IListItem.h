#ifndef _ILISTITEM_H_
#define _ILISTITEM_H_

namespace HALO
{
	class  HALO_API ListItemListener
	{
	public:
		virtual void OnCheckedChanged(class CListSelectItem* selectitem , int index , bool ischecked){};
		virtual void OnExpandableChanged(class CExpandableListItem* expandableitem , int index , int itemNum , bool isExpandabled){};
	};
	class HALO_API IListItem : virtual public IActor
	{
	public:
		struct TItemBaseAttr : TRect
		{};

		struct TImageAttr : TItemBaseAttr
		{
			IImageBuffer* imagebuffer;
			ClutterContentGravity gravity;
		};

		struct TTextAttr : TItemBaseAttr
		{
			ClutterColor c;
			TTextAttr() : contentText(NULL), fontSize(0), fontName(NULL), hAlign(HALIGN_CENTER) , vAlign(VALIGN_MIDDLE) , color(c){}
			char* contentText;
			int fontSize;
			char* fontName;
			EHAlignment hAlign;
			EVAlignment vAlign;
			ClutterColor& color;
		};
		struct TProgressAttr : TItemBaseAttr
		{
			ClutterColor c;
			TProgressAttr() : direction(TYPE_HORIZONTAL), progressImage(NULL), backgroudImage(NULL), minValue(0) , maxValue(100) , flagReverse(false), bgcolor(c){}
			EDirectionType direction;
			IImageBuffer* progressImage;
			IImageBuffer* backgroudImage;
			int minValue;
			int maxValue;
			bool flagReverse;
			ClutterColor bgcolor;
		};
	public:
		enum EListItemStyle
		{
			E_ITEM_NONE = 0,
			E_ITEM_INDICATOR ,
			E_ITEM_CONTENTTEXT,
			E_ITEM_ICON,
			E_ITEM_PROGRESSBAR
		};

		enum EListStateType
		{
			E_STATE_UNSELECTED = 0,   
			E_STATE_SELECTED,
			E_STATE_FOCUSED,
			E_STATE_DISABLED,
			E_STATE_DISABLE_FOCUSED,
			E_STATE_ALL
		};
	public:
		static IListItem* CreateInstance(IActor* parent, float width, float height);
		virtual void Enable(bool flagEnable) = 0;
		virtual void LoadData() = 0;
		virtual void UnLoadData() = 0;
		virtual void SetIndex(int itemIndex) = 0;
		virtual void SetItemImage(IImageBuffer *buffer , EListStateType statetype) = 0;
		virtual void SetTitleText(const char* titleText , EListStateType statetype) = 0;
		virtual void SetTitleTextFontSize(int fontSize , EListStateType statetype) = 0;
		virtual void SetTitleTextFont(const char* titlefont , EListStateType statetype) = 0;
		virtual void SetTitleTextColor(const ClutterColor color , EListStateType statetype) = 0;
		virtual void ResizeTitleText(float width, float height) = 0;
		virtual void SetTitleTextPosition(float xpos, float ypos) = 0;
		virtual void ChangeStateTo(EListStateType toState) = 0;
		virtual void SetStyle(TItemBaseAttr* attr , EListItemStyle itemStyle) = 0;
		virtual void SetProgressValue(int value) = 0;
	};

	class HALO_API IListSelectItem : virtual public IListItem
	{
	public:
		enum ESelectType
		{
			E_TYPE_SELECTED,
			E_TYPE_UNSELECTED
		};
	public:
		static IListSelectItem* CreateInstance(IActor* parent, float width, float height);
		virtual void CreateSelectImage(TRect rect) = 0;
		virtual void SetSelectImageBuffer(IImageBuffer* imagebuffer , ESelectType imageType) = 0;
		virtual void AddListener(ListItemListener* listener) = 0;
		virtual void RemoveListener() = 0;
		virtual void SetCheck(bool isChecked) = 0;
		virtual void LoadData() = 0;
		virtual bool IsChecked() = 0;
	};

	class HALO_API IExpandableListItem : virtual public IListItem
	{
	public:
		enum EExpandableType
		{
			E_TYPE_OPEN,
			E_TYPE_CLOSED
		};
	public:
		static IExpandableListItem* CreateInstance(IActor* parent, float width, float height);
		virtual void CreateExpandableFlagImage(TRect rect) = 0;
		virtual void SetExpandableFlagImageBuffer(IImageBuffer* imagebuffer , EExpandableType imageType) = 0;
		virtual void SetSingleLineListToItem(ISingleLineListControl* singlelinelist) = 0;
		virtual void SetExpandable(bool isExpandabled) = 0; 
		virtual bool IsExpandabled() = 0;
		virtual void AddListener(ListItemListener* listener) = 0;
		virtual void RemoveListener() = 0;
	};
}
#endif //_CLISTITEM_H_