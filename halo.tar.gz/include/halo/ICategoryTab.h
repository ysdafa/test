#ifndef _HALO_ICATEGORYTAB_H_
#define _HALO_ICATEGORYTAB_H_

namespace HALO
{
	class HALO_API ICategoryTabChangedListener : public IListener
	{
	public:
		virtual bool OnTabChanged(class ICategoryTab* tab, int index) = 0;
	};

	class HALO_API ICategoryTab : virtual public IActor
	{
	public:
		enum ECategoryTabState
		{
			STATE_UNSELECTED = 0,				//!< State normal 
			STATE_SELECTED,					//!< State focused 
			STATE_HIGHLIGHTED,					//!< State highlighted(mouse roll-over) 
			STATE_ALL						//!< state for setting all state at once.
		};

	public:
		/*!
		\brief               Create a ICategoryTab instance.
		\remarks             If parent is NULL, this ICategoryTab will be a child of the Stage. The parent is not recommended to be NULL.
		\param               parent:[in] The parent of this ICategoryTab.
		\param               width: [in] The width of the ICategoryTab.
		\param               height:[in] The height of the ICategoryTab.
		\return              ICategoryTab*: a ICategoryTab instance
		*/
		static ICategoryTab* CreateInstance(IActor* parent, float width, float height);
		static ICategoryTab* CreateInstance(Widget* parent, float width, float height);

	public:
		/*!
		\brief                Sets all the components of the margin of a ICategoryTab
		\param               top: [in] The top margin, in pixels.
		\param               bottom: [in] The bottom margin, in pixels.
		\param               left: [in] The left margin, in pixels.
		\param               right: [in] The right margin, in pixels.
		\return              None
		*/
		virtual void SetMargin(float top, float bottom, float left, float right) = 0;

		/*!
		\brief                Sets the spliter size between tabs in ICategoryTab
		\param               width: [in] The new requested width, in pixels.
		\param               height: [in] The new requested height, in pixels.
		\return              None
		*/
		virtual void SetSpliterSize(float width, float height) = 0;

		/*!
		\brief:   Sets spliter color between tabs.
		\param              color: [in]   color
		\return              None
		*/
		virtual void SetSpliterColor(const ClutterColor &color) = 0;

		/*!
		\brief:   Sets the background image of spliter.
		\param               image: [in] The image's path.
		\return              None
		*/
		virtual void SetSpliterImage(const std::string& image) = 0;

		/*!
		\brief:   Retrieves the image path of spliter.
		\return              string: image path.
		*/
		virtual std::string SpliterImage(void) const = 0;

		/*!
		\brief                Sets enable looping tabs in ICategoryTab
		\param             enable: [in] Enable flag.
		\return             None
		*/
		virtual void EnableLooping(bool enable) = 0;

		/*!
		\brief                Retrieves is enable looping tabs in ICategoryTab
		\return             bool: Enable flag.
		*/
		virtual bool IsLoopingEnabled(void) const = 0;

		/*!
		\brief                Sets enable align center tabs in ICategoryTab
		\param             enable: [in] Enable flag.
		\return             None
		*/
		virtual void EnableAlignTabsCenter(bool enable) = 0;

		/*!
		\brief                Retrieves is enable align center tabs in ICategoryTab
		\return             bool: Enable flag.
		*/
		virtual bool IsAlignTabsCenterEnabled(void) const = 0;

		/*!
		\brief:   Get IButton actor instance
		\param:   index: [in] The index of tab in ICategoryTab, from 0.
		\return:  IButton*:   IButton instance that is a member of ICategoryTab class.
		*/
		virtual IButton* TabButtontActor(int index) = 0;

		/*!
		\brief:   Get IText actor instance
		\param:   index: [in] The index of tab in ICategoryTab, from 0.
		\return:  IText*:   IText instance that is a member of ICategoryTab class.
		*/
		virtual IText* TabTextActor(int index) = 0;

		/*!
		\brief:   Get ICompositeImage actor instance
		\param:   index: [in] The index of tab in ICategoryTab, from 0.
		\return:  ICompositeImage*:   ICompositeImage instance that is a member of ICategoryTab class.
		*/
		virtual ICompositeImage* TabImageActor(int index) = 0;

		/*!
		\brief                Set text font in tab.
		\param              font: [in]Font name.
		\return              None
		\par Example:
		\code
		SetTabFont("Sans 30px");
		\endcode
		*/
		virtual void SetTabFont(const std::string& font) = 0;

		/*!
		\brief:   Retrieves the text font name in tab.
		\return              char: Font.
		*/
		virtual std::string TabFont(void) const = 0;

		/*!
		\brief:   Sets text font size in tab for a specific(or all) state
		\param              state:[in] Button State
		\param              size: [in]  text font size
		\return              None
		*/
		virtual void SetTabFontSize(ECategoryTabState state, int size) = 0;

		/*!
		\brief:   Sets text color in tab for a specific(or all) state
		\param              state:[in] Button State
		\param              color: [in]   text color
		\return              None
		*/
		virtual void SetTabTextColor(ECategoryTabState state, const ClutterColor &color) = 0;

		/*!
		\brief:   Sets background image in tab for a specific(or all) state
		\param              state:[in] Button State
		\param              image: [in]   image path
		\return              None
		*/
		virtual void SetTabImage(ECategoryTabState state, const char* image) = 0;

		/*!
		\brief:   Sets background color in tab for a specific(or all) state
		\param              state:[in] Button State
		\param              color: [in]   tab color
		\return              None
		*/
		virtual void SetTabColor(ECategoryTabState state, const ClutterColor &color) = 0;
		
		/*!
		\brief:   Sets the size of left arrows
		\remarks           If height will be limited in ICategoryTab's.
		\param               width: [in] The width of left arrows, in pixels.
		\param               height: [in] The height of left arrows, in pixels.
		\return              None
		*/
		virtual void SetLeftArrowsSize(float width, float height) = 0;

		/*!
		\brief:   Sets the size of right arrows
		\remarks           If height will be limited in ICategoryTab's.
		\param               width: [in] The width of right arrows, in pixels.
		\param               height: [in] The height of right arrows, in pixels.
		\return              None
		*/
		virtual void SetRightArrowsSize(float width, float height) = 0;

		/*!
		\brief:   Sets the background image of left arrows
		\param               image: [in] The image's path.
		\return              None
		*/
		virtual void SetLeftArrowsImage(const std::string& image) = 0;

		/*!
		\brief:   Retrieves the image path of left arrows.
		\return              string: image path.
		*/
		virtual std::string LeftArrowsImage(void) const = 0;

		/*!
		\brief:   Sets the background image of right arrows
		\param               image: [in] The image's path.
		\return              None
		*/
		virtual void SetRightArrowsImage(const std::string& image) = 0;

		/*!
		\brief:   Retrieves the image path of right arrows.
		\return              string: image path.
		*/
		virtual std::string RightArrowsImage(void) const = 0;

		/*!
		\brief:   Sets the background image path of ICategoryTab
		\param               image: [in] The image's path.
		\return              None
		*/
		virtual void SetBackgroundImage(const std::string& image) = 0;

		/*!
		\brief:   Retrieves the background image path of ICategoryTab
		\return              string: image path.
		*/
		virtual  std::string BackgroundImage(void) const = 0;

		/*!
		\brief:   Sets the background color of ICategoryTab
		\param               color: [in] The background color.
		\return              None
		*/
		virtual void SetBackgroundColor(const ClutterColor &color) = 0;

		/*!
		\brief:   Sets the background color of Highlightbar.
		\param               color: [in] The background color.
		\return              None
		*/
		virtual void SetHighlightBarColor(const ClutterColor& color) = 0;

		/*!
		\brief:   Retrieves is enable show highlight bar.
		\return              bool: Enable flag.
		*/
		virtual bool IsHightlightBarEnabled(void) const = 0;

		/*!
		\brief:   Enable show highlight bar.
		\param              enable: [in] Enable flag.
		\return              None
		*/
		virtual void EnableHightlightBar(bool enable) = 0;

		/*!
		\brief:   Retrieves the hight of highlight bar.
		\return              float: The hight value.
		*/
		virtual float HighlightBarHeight(void) const = 0;

		/*!
		\brief:   Sets the hight of highlight bar.
		\param               hight: [in] The hight value.
		\return              None
		*/
		virtual void SetHighlightBarHeight(float height) = 0;

		/*!
		\brief:   Retrieves the text margin in tab.
		\return              float: The margin value.
		*/
		virtual float TabTextMargin(void) const = 0;

		/*!
		\brief:   Sets the text margin in tab.
		\param               magin: [in] The margin value.
		\return              None
		*/
		virtual void SetTabTextMargin(float margin) = 0;

		/*!
		\brief:   Retrieves the text limit width of tab.
		\return              int: The limit width value.
		*/
		virtual float TabTextLimitWidth(void) const = 0;

		/*!
		\brief:   Sets the text limit width of tab.
		\param               limit: [in] The limit width value.
		\return              None
		*/
		virtual void SetTabTextLimitWidth(float limit) = 0;

		/*!
		\brief:   Add a new tab at last into ICategoryTab with the text to display.
		\remarks           The height use ICategoryTab's, the width according to the text's size.
		\param               text: [in] The text of tab.
		\return              bool: The result of adding a new tab
		*/
		virtual bool AddTab(const char* text) = 0;		

		/*!
		\brief:   Add a new tab at specific index into ICategoryTab with the text to display.
		\remarks           The height use ICategoryTab's, the width according to the text's size.
		\param               text: [in] The text of tab.
		\param               index: [in] The index of tab, from 0.
		\return              bool: The result of adding a new tab
		*/
		virtual bool AddTab(const char* text, int index) = 0;

		/*!
		\brief:   Add a new tab at last into ICategoryTab with the text to display.
		\param               text: [in] The text of tab.
		\param               width: [in] The width of new tab, in pixels.
		\param               height: [in] The height of new tab, in pixels.
		\return              bool: The result of adding a new tab
		*/
		virtual bool AddTab(const char* text, float width, float height) = 0;

		/*!
		\brief:   Add a new tab at specific index into ICategoryTab with the text to display.
		\param               text: [in] The text of tab.
		\param               width: [in] The width of new tab, in pixels.
		\param               height: [in] The height of new tab, in pixels.
		\param               index: [in] The index of tab, from 0.
		\return              bool: The result of adding a new tab
		*/
		virtual bool AddTab(const char* text, float width, float height, int index) = 0;

		/*!
		\brief:   Remove a new tab at specific index.
		\param               index: [in] The index of tab, from 0.
		\return              bool: The result of removing a tab
		*/
		virtual bool RemoveTab(int index) = 0;

		/*!
		\brief:   Retrieves current index of tab which is on focus.
		\return              int: The index of the tab
		*/
		virtual int CurrentTabIndex(void) = 0;

		/*!
		\brief:   Retrieves current text of tab which is on focus.
		\return              char*: The text of the tab
		*/
		virtual const char* CurrentTabText(void) = 0;

		/*!
		\brief:   Retrieves the text of specific tab
		\param               index: [in] The index of tab, from 0.
		\return              char*: The text of the tab
		*/
		virtual const char* TabText(int index) = 0;

		/*!
		\brief:   Change focus to another tab.
		\param               index: [in] The index of tab, from 0.
		\return              bool: The result of changing a tab
		*/
		virtual bool ChangeTab(int index) = 0;

		/*!
		\brief:   Retrieves the number of  tabs.
		\return              int: The number of  tabs.
		*/
		virtual int NumberOfTab(void) = 0;

		/*!
		\brief:   Add a callback listener to handler message when the tab changed.
		\param               listener: [in] The ICategoryTabChangedListener.
		\return              bool: The result of adding a listener
		*/
		virtual bool AddTabChangedListener(ICategoryTabChangedListener* listener) = 0;

		/*!
		\brief:   Remove a tab changed callback listener.
		\param               listener: [in] The ICategoryTabChangedListener.
		\return              bool: The result of removing a listener
		*/
		virtual bool RemoveTabChangedListener(ICategoryTabChangedListener* listener) = 0;
	};
}

#endif //_HALO_ICATEGORYTAB_H_
