#ifndef _HALO_ICATEGORYTAB_H_
#define _HALO_ICATEGORYTAB_H_

namespace HALO
{
	class HALO_API ICategoryTabListener : public IListener
	{
	public:
		virtual bool OnTabChanged(class ICategoryTab* tab, int index) = 0;
		virtual bool OnTabClicked(class ICategoryTab* tab, int index) = 0;
		virtual bool OnTabMouseIn(class ICategoryTab* tab, int index) = 0;
		virtual bool OnTabMouseOut(class ICategoryTab* tab, int index) = 0;
		virtual bool OnLeftArrowsClicked(class ICategoryTab* tab) = 0;
		virtual bool OnRightArrowsClicked(class ICategoryTab* tab) = 0;
	};	

	class HALO_API ICategoryTab : virtual public IActor
	{
	public:
		enum ECategoryTabState
		{
			STATE_UNSELECTED = 0,				//!< State normal 
			STATE_SELECTED,					//!< State focused 
			STATE_HIGHLIGHTED,					//!< State highlighted(mouse roll-over) 
			STATE_ALL						//!< state for setting all state at once.
		};
		enum ECategoryTabSelectState
		{
			STATE_SELECT_NORMAL = 0,   //!< button normal state.
			STATE_SELECT_FOCUSED,	  //!< button focused state.   
			STATE_SELECT_DISABLED,	  //!< button disabled state.   
			STATE_SELECT_SELECTED,
			STATE_SELECT_ALL
		};
		enum ECategoryTabAnimationMode
		{
			ANIMATION_CUSTOM_MODE = 0,
			ANIMATION_LINEAR,

			/* quadratic */
			ANIMATION_EASE_IN_QUAD,
			ANIMATION_EASE_OUT_QUAD,
			ANIMATION_EASE_IN_OUT_QUAD,

			/* cubic */
			ANIMATION_EASE_IN_CUBIC,
			ANIMATION_EASE_OUT_CUBIC,
			ANIMATION_EASE_IN_OUT_CUBIC,

			/* quartic */
			ANIMATION_EASE_IN_QUART,
			ANIMATION_EASE_OUT_QUART,
			ANIMATION_EASE_IN_OUT_QUART,

			/* quintic */
			ANIMATION_EASE_IN_QUINT,
			ANIMATION_EASE_OUT_QUINT,
			ANIMATION_EASE_IN_OUT_QUINT,

			/* sinusoidal */
			ANIMATION_EASE_IN_SINE,
			ANIMATION_EASE_OUT_SINE,
			ANIMATION_EASE_IN_OUT_SINE,

			/* exponential */
			ANIMATION_EASE_IN_EXPO,
			ANIMATION_EASE_OUT_EXPO,
			ANIMATION_EASE_IN_OUT_EXPO,

			/* circular */
			ANIMATION_EASE_IN_CIRC,
			ANIMATION_EASE_OUT_CIRC,
			ANIMATION_EASE_IN_OUT_CIRC,

			/* elastic */
			ANIMATION_EASE_IN_ELASTIC,
			ANIMATION_EASE_OUT_ELASTIC,
			ANIMATION_EASE_IN_OUT_ELASTIC,

			/* overshooting cubic */
			ANIMATION_EASE_IN_BACK,
			ANIMATION_EASE_OUT_BACK,
			ANIMATION_EASE_IN_OUT_BACK,

			/* exponentially decaying parabolic */
			ANIMATION_EASE_IN_BOUNCE,
			ANIMATION_EASE_OUT_BOUNCE,
			ANIMATION_EASE_IN_OUT_BOUNCE,

			/* step functions (see css3-transitions) */
			ANIMATION_STEPS,
			ANIMATION_STEP_START, /* steps(1, start) */
			ANIMATION_STEP_END, /* steps(1, end) */

			/* cubic bezier (see css3-transitions) */
			ANIMATION_CUBIC_BEZIER,
			ANIMATION_EASE,
			ANIMATION_EASE_IN,
			ANIMATION_EASE_OUT,
			ANIMATION_EASE_IN_OUT,

			/* guard, before registered alpha functions */
			ANIMATION_LAST
		};
	public:
		/*!
		\brief               Create a ICategoryTab instance.
		\remarks             If parent is NULL, this ICategoryTab will be a child of the Stage. The parent is not recommended to be NULL.
		\param               parent:[in] The parent of this ICategoryTab.
		\param               width: [in] The width of the ICategoryTab.
		\param               height:[in] The height of the ICategoryTab.
		\return              ICategoryTab*: a ICategoryTab instance
		*/
		static ICategoryTab* CreateInstance(IActor* parent, float width, float height);
		static ICategoryTab* CreateInstance(Widget* parent, float width, float height);

	public:
		/*!
		\brief                Sets all the components of the margin of a ICategoryTab
		\param               top: [in] The top margin, in pixels.
		\param               bottom: [in] The bottom margin, in pixels.
		\param               left: [in] The left margin, in pixels.
		\param               right: [in] The right margin, in pixels.
		\return              None
		*/
		virtual void SetMargin(float top, float bottom, float left, float right) = 0;

		/*!
		\brief                Sets the spliter size between tabs in ICategoryTab
		\param               width: [in] The new requested width, in pixels.
		\param               height: [in] The new requested height, in pixels.
		\return              None
		*/
		virtual void SetSpliterSize(float width, float height, int index) = 0;

		/*!
		\brief:   Sets spliter color between tabs.
		\param              color: [in]   color
		\return              None
		*/
		virtual void SetSpliterColor(const ClutterColor &color) = 0;

		/*!
		\brief:   Sets the background image of spliter.
		\param               image: [in] The image's path.
		\return              None
		*/
		virtual void SetSpliterImage(const std::string& image) = 0;

		/*!
		\brief:   Retrieves the image path of spliter.
		\return              string: image path.
		*/
		virtual std::string SpliterImage(void) const = 0;

		/*!
		\brief                Sets enable looping tabs in ICategoryTab
		\param             enable: [in] Enable flag.
		\return             None
		*/
		virtual void EnableLooping(bool enable) = 0;

		/*!
		\brief                Retrieves is enable looping tabs in ICategoryTab
		\return             bool: Enable flag.
		*/
		virtual bool IsLoopingEnabled(void) const = 0;

		/*!
		\brief                Sets enable align center tabs in ICategoryTab
		\param             enable: [in] Enable flag.
		\return             None
		*/
		virtual void EnableAlignTabsCenter(bool enable) = 0;

		/*!
		\brief                Retrieves is enable align center tabs in ICategoryTab
		\return             bool: Enable flag.
		*/
		virtual bool IsAlignTabsCenterEnabled(void) const = 0;
				
		/*!
		\brief:   Get IText actor instance
		\param:   index: [in] The index of tab in ICategoryTab, from 0.
		\return:  IText*:   IText instance that is a member of ICategoryTab class.
		*/
		virtual IText* TabTextActor(int index) = 0;

		/*!
		\brief:   Get ICompositeImage actor instance
		\param:   index: [in] The index of tab in ICategoryTab, from 0.
		\return:  ICompositeImage*:   ICompositeImage instance that is a member of ICategoryTab class.
		*/
		virtual ICompositeImage* TabImageActor(int index) = 0;

		/*!
		\brief                Set text font in tab.
		\param              font: [in]Font name.
		\return              None
		\par Example:
		\code
		SetTabFont("Sans 30px");
		\endcode
		*/
		virtual void SetTabFont(const std::string& font) = 0;

		/*!
		\brief:   Retrieves the text font name in tab.
		\return              char: Font.
		*/
		virtual std::string TabFont(void) const = 0;

		/*!
		\brief:   Sets text font size in tab for a specific(or all) state
		\param              state:[in] Button State
		\param              size: [in]  text font size
		\return              None
		*/
		virtual void SetTabFontSize(ECategoryTabState state, int size) = 0;

		/*!
		\brief:   Sets text color in tab for a specific(or all) state
		\param              state:[in] Button State
		\param              color: [in]   text color
		\return              None
		*/
		virtual void SetTabTextColor(ECategoryTabState state, const ClutterColor &color) = 0;

		/*!
		\brief:   Sets background image in tab for a specific(or all) state
		\param              state:[in] Button State
		\param              image: [in]   image path
		\return              None
		*/
		virtual void SetTabImage(ECategoryTabState state, const char* image) = 0;

		/*!
		\brief:   Sets background color in tab for a specific(or all) state
		\param              state:[in] Button State
		\param              color: [in]   tab color
		\return              None
		*/
		virtual void SetTabColor(ECategoryTabState state, const ClutterColor &color) = 0;
		
		/*!
		\brief:   Sets the size of left arrows
		\remarks           If height will be limited in ICategoryTab's.
		\param               width: [in] The width of left arrows, in pixels.
		\param               height: [in] The height of left arrows, in pixels.
		\return              None
		*/
		virtual void SetLeftArrowsSize(float width, float height) = 0;

		/*!
		\brief:   Sets the size of right arrows
		\remarks           If height will be limited in ICategoryTab's.
		\param               width: [in] The width of right arrows, in pixels.
		\param               height: [in] The height of right arrows, in pixels.
		\return              None
		*/
		virtual void SetRightArrowsSize(float width, float height) = 0;

		/*!
		\brief:   Sets the background image of left arrows
		\param               image: [in] The image's path.
		\return              None
		*/
		virtual void SetLeftArrowsImage(const std::string& image) = 0;

		/*!
		\brief:   Retrieves the image path of left arrows.
		\return              string: image path.
		*/
		virtual std::string LeftArrowsImage(void) const = 0;

		/*!
		\brief:   Sets the background image of right arrows
		\param               image: [in] The image's path.
		\return              None
		*/
		virtual void SetRightArrowsImage(const std::string& image) = 0;

		/*!
		\brief:   Retrieves the image path of right arrows.
		\return              string: image path.
		*/
		virtual std::string RightArrowsImage(void) const = 0;

		/*!
		\brief:   Sets the background image path of ICategoryTab
		\param               image: [in] The image's path.
		\return              None
		*/
		virtual void SetBackgroundImage(const std::string& image) = 0;

		/*!
		\brief:   Retrieves the background image path of ICategoryTab
		\return              string: image path.
		*/
		virtual  std::string BackgroundImage(void) const = 0;

		/*!
		\brief:   Sets the background color of ICategoryTab
		\param               color: [in] The background color.
		\return              None
		*/
		virtual void SetBackgroundColor(const ClutterColor &color) = 0;

		/*!
		\brief:   Sets the background color of Highlightbar.
		\param               color: [in] The background color.
		\return              None
		*/
		virtual void SetHighlightBarColor(const ClutterColor& color) = 0;

		/*!
		\brief:   Sets the background color of Highlightbar when focus in.
		\param               color: [in] The background color.
		\return              None
		*/
		virtual void SetHighlightBarFocusedColor(const ClutterColor& color) = 0;

		/*!
		\brief:   Sets the background color of Highlightbar when focus out.
		\param               color: [in] The background color.
		\return              None
		*/
		virtual void SetHighlightBarUnfocusedColor(const ClutterColor& color) = 0;

		/*!
		\brief:   Retrieves is enable show highlight bar.
		\return              bool: Enable flag.
		*/
		virtual bool IsHightlightBarEnabled(void) const = 0;

		/*!
		\brief:   Enable show highlight bar.
		\param              enable: [in] Enable flag.
		\return              None
		*/
		virtual void EnableHighlightBar(bool enable) = 0;

		/*!
		\brief:   Retrieves the hight of highlight bar.
		\return              float: The hight value.
		*/
		virtual float HighlightBarHeight(void) const = 0;

		/*!
		\brief:   Sets the hight of highlight bar.
		\param               hight: [in] The hight value.
		\return              None
		*/
		virtual void SetHighlightBarHeight(float height) = 0;
		
		/*!
		\brief:   Retrieves the text left margin in tab.
		\return              float: The margin value.
		*/
		virtual float TabTextLeftMargin(void) const = 0;

		/*!
		\brief:   Sets the text left margin in tab.
		\param               magin: [in] The margin value.
		\return              None
		*/
		virtual void SetTabTextLeftMargin(float margin) = 0;

		/*!
		\brief:   Retrieves the text right margin in tab.
		\return              float: The margin value.
		*/
		virtual float TabTextRightMargin(void) const = 0;

		/*!
		\brief:   Sets the text right margin in tab.
		\param               magin: [in] The margin value.
		\return              None
		*/
		virtual void SetTabTextRightMargin(float margin) = 0;

		/*!
		\brief:   Retrieves the text limit width of tab.
		\return              int: The limit width value.
		*/
		virtual float TabTextLimitWidth(void) const = 0;

		/*!
		\brief:   Sets the text limit width of tab.
		\param               limit: [in] The limit width value.
		\return              None
		*/
		virtual void SetTabTextLimitWidth(float limit) = 0;

		/*!
		\brief:   Add a new tab at last into ICategoryTab with the text to display.
		\remarks           The height use ICategoryTab's, the width according to the text's size.
		\param               text: [in] The text of tab.
		\return              bool: The result of adding a new tab
		*/
		virtual bool AddTab(const char* text) = 0;		

		/*!
		\brief:   Add a new tab at specific index into ICategoryTab with the text to display.
		\remarks           The height use ICategoryTab's, the width according to the text's size.
		\param               text: [in] The text of tab.
		\param               index: [in] The index of tab, from 0.
		\return              bool: The result of adding a new tab
		*/
		virtual bool AddTab(const char* text, int index) = 0;

		/*!
		\brief:   Add a new tab at last into ICategoryTab with the text to display.
		\param               text: [in] The text of tab.
		\param               width: [in] The width of new tab, in pixels.
		\param               height: [in] The height of new tab, in pixels.
		\return              bool: The result of adding a new tab
		*/
		virtual bool AddTab(const char* text, float width, float height) = 0;

		/*!
		\brief:   Add a new tab at specific index into ICategoryTab with the text to display.
		\param               text: [in] The text of tab.
		\param               width: [in] The width of new tab, in pixels.
		\param               height: [in] The height of new tab, in pixels.
		\param               index: [in] The index of tab, from 0.
		\return              bool: The result of adding a new tab
		*/
		virtual bool AddTab(const char* text, float width, float height, int index) = 0;

		/*!
		\brief:   Remove a new tab at specific index.
		\param               index: [in] The index of tab, from 0.
		\return              bool: The result of removing a tab
		*/
		virtual bool RemoveTab(int index) = 0;

		/*!
		\brief:   Retrieves current index of tab which is on focus.
		\return              int: The index of the tab
		*/
		virtual int CurrentTabIndex(void) = 0;

		/*!
		\brief:   Retrieves current text of tab which is on focus.
		\return              char*: The text of the tab
		*/
		virtual const char* CurrentTabText(void) = 0;

		/*!
		\brief:   Retrieves the text of specific tab
		\param               index: [in] The index of tab, from 0.
		\return              char*: The text of the tab
		*/
		virtual const char* TabText(int index) = 0;

		/*!
		\brief:   Change focus to another tab.
		\param               index: [in] The index of tab, from 0.
		\return              bool: The result of changing a tab
		*/
		virtual bool ChangeTab(int index) = 0;

		/*!
		\brief:   Retrieves the number of  tabs.
		\return              int: The number of  tabs.
		*/
		virtual int NumberOfTab(void) = 0;

		/*!
		\brief:   Add a callback listener to handler message when the tab changed.
		\param               listener: [in] The ICategoryTabChangedListener.
		\return              bool: The result of adding a listener
		*/
		virtual bool AddCategoryTabListener(ICategoryTabListener* listener) = 0;

		/*!
		\brief:   Remove a tab changed callback listener.
		\param               listener: [in] The ICategoryTabChangedListener.
		\return              bool: The result of removing a listener
		*/
		virtual bool RemoveCategoryTabListener(ICategoryTabListener* listener) = 0;

		/*!
		\brief:   Sets the icon margin in sub-tab.
		\param               magin: [in] The margin value.
		\return              None
		*/
		virtual void SetTabIconMargin(float margin) = 0;

		/*!
		\brief:   Retrieves the icon margin in sub-tab.
		\return              float: The margin value.
		*/
		virtual float TabIconMargin(void) const = 0;

		/*!
		\brief:   Sets the icon size in sub-tab.
		\param               magin: [in] The margin value.
		\return              None
		*/
		virtual void SetTabIconSize(float width, float height, int index) = 0;

		/*!
		\brief                Show icon in sub-tab
		\param             index: [in] index of sub-tab. -1 means all.
		\return             None
		*/
		virtual void ShowTabIcon(int index) = 0;

		/*!
		\brief                Hide icon in sub-tab
		\param             index: [in] index of sub-tab. -1 means all.
		\return             None
		*/
		virtual void HideTabIcon(int index) = 0;

		/*!
		\brief                Retrieves is enable show icon in sub-tab
		\param             index: [in] index of sub-tab.
		\return             bool: Enable flag.
		*/
		virtual bool FlagTabIconShow(int index) const = 0;

		/*!
		\brief:   Sets icon image in sub-tab for a specific(or all) sub-tab. 
		\param              state:[in] Button State
		\param              image: [in]   image path
		\param              alpha: [in]   image alpha
		\param              index:[in] index of sub-tab. -1 means all.
		\return              None
		*/
		virtual void SetTabIconImage(ECategoryTabState state, const std::string& image, int alpha, int index) = 0;

		/*!
		\brief:   Set text of specific sub-tab with specific state to display.
		\param               text: [in] The text of tab.
		\param               text: [in] The text of tab.
		\param               index: [in] The index of tab, from 0.
		\return              bool: The result of set tab text
		*/
		virtual void SetTabText(ECategoryTabState state, const char* text, int index) = 0;

		/*!
		\brief                Sets enable change tabs in ICategoryTab
		\param             enable: [in] Enable flag.
		\return             None
		*/
		virtual void EnableChangeTab(bool enable) = 0;

		/*!
		\brief                Retrieves is enable change tabs in ICategoryTab
		\return             bool: Enable flag.
		*/
		virtual bool IsChangeTabEnabled(void) const = 0;

		/*!
		\brief                Sets highlightbar height animation when focus in or out of ICategoryTab
		\param               unfocusHeight: [in] The height of highlightBar when focus out.
		\param               focusHeight: [in] The height of highlightBar when focus in.
		\param               mode: [in] The mode of animation.
		\param               time:[in] The animation duration (ms).
		\return             None
		*/
		virtual void SetHighlightBarFocusAnimation(float unfocusHeight, float focusHeight, ECategoryTabAnimationMode mode, int time) = 0;

		/*!
		\brief                Sets highlightbar move animation in ICategoryTab
		\param               mode: [in] The mode of animation.
		\param               time:[in] The animation duration (ms).
		\return             None
		*/
		virtual void SetHighlightBarMoveAnimation(ECategoryTabAnimationMode mode, int time) = 0;

		/*!
		\brief                Sets enable use keyborad to swtich sub-tabs.
		\param             enable: [in] Enable flag.
		\return             None
		*/
		virtual  void EnableTabsKey(bool enable) = 0;
		
		/*!
		\brief                Retrieves is enable use keyborad to swtich sub-tabs.
		\return             bool: Enable flag.
		*/
		virtual bool IsTabsKeyEnabled(void) const = 0;

		/*!
		\brief                Swap sub tabs in ICategoryTab
		\param               fromIndex: [in] The index of from position.
		\param               toIndex:[in] The index of to position.
		\return             None
		*/
		virtual void SwapSubTab(int fromIndex, int toIndex) = 0;

		/*!
		\brief                Show the check box in sub-tabs.
		\return             None
		*/
		virtual void ShowTabCheckBox(void) = 0;

		/*!
		\brief                Hide the check box in sub-tabs.
		\return             None
		*/
		virtual void HideTabCheckBox(void) = 0;

		/*!
		\brief                Show the left image in specific sub-tab
		\param             Index: [in] The index of sub-tab.
		\return             None
		*/
		virtual void ShowTabLeftImage(int index) = 0;

		/*!
		\brief                Show the right image in specific sub-tab
		\param             Index: [in] The index of sub-tab.
		\return             None
		*/
		virtual void ShowTabRightImage(int index) = 0;

		/*!
		\brief                Hide the left image in specific sub-tab
		\param             Index: [in] The index of sub-tab.
		\return             None
		*/
		virtual void HideTabLeftImage(int index) = 0;

		/*!
		\brief                Hide the right image in specific sub-tab
		\param             Index: [in] The index of sub-tab.
		\return             None
		*/
		virtual void HideTabRightImage(int index) = 0;

		/*!
		\brief                Set the left image in sub-tabs
		\param             Width: [in] The width of left image.
		\param             Height: [in] The height of left image.
		\param             Margin: [in] The distance from left side.
		\return             None
		*/
		virtual void SetTabLeftImageSize(float width, float height, float margin) = 0;

		/*!
		\brief                Set the right image in sub-tabs
		\param             Width: [in] The width of left image.
		\param             Height: [in] The height of left image.
		\param             Margin: [in] The distance from right side.
		\return             None
		*/
		virtual void SetTabRightImageSize(float width, float height, float margin) = 0;

		/*!
		\brief                Set the left image in specific sub-tab
		\param             Path: [in] The path of  image.
		\param             Index: [in] The index of sub-tab.
		\return             None
		*/
		virtual void SetTabLeftImagePath(const std::string&  path, int index) = 0;

		/*!
		\brief                Set the right image in specific sub-tab
		\param             Path: [in] The path of  image.
		\param             Index: [in] The index of sub-tab.
		\return             None
		*/
		virtual void SetTabRightImagePath(const std::string&  path, int index) = 0;

		/*!
		\brief                Set enable keep the highlight bar at bottom
		\param             Enable: [in] Enable flag.
		\return             None
		*/
		virtual void EnableHighlightBarBottom(bool enable) = 0;

		/*!
		\brief                Retrieves is enable keep the highlight bar at bottom
		\return             bool: Enable flag.
		*/
		virtual bool IsHighlightBarBottom(void) const = 0;

		/*!
		\brief                Set the size of check box
		\param             Width: [in] The width.
		\param             Height: [in] The height.
		\return             None
		*/
		virtual void SetTabCheckBoxSize(float width, float height) = 0;

		/*!
		\brief                Set the margin of check box
		\param             Margin: [in] The distance from left side.
		\return             None
		*/
		virtual void SetTabCheckBoxMargin(float margin) = 0;

		/*!
		\brief                Set the duration time of swap sub-tabs animation
		\param             Time: [in] The duration time.
		\return             None
		*/
		virtual void SetSwapSubTabDuration(int time) = 0;

		/*!
		\brief                Set enable drag the sub-tabs
		\param             Enable: [in] Enable flag.
		\return             None
		*/
		virtual void EnableDragTab(bool enable) = 0;

		/*!
		\brief                Retrieves is enable drag the sub-tabs
		\return             bool: Enable flag.
		*/
		virtual bool IsEnableDragTab(void) const = 0;

		/*!
		\brief                Retrieves the index of checkbox selected.
		\return             vector<int>: Index.
		*/
		virtual std::vector<int> GetTabCheckBoxSelectedIndexes(void) = 0;

		/*!
		\brief                Set the taget height of CategoryTab
		\param             Min: [in] The min height.
		\param             Max: [in] The max height.
		\return             None
		*/
		virtual void SetTabTargetHeight(float targetMin, float targetMax) = 0;

		/*!
		\brief                Set check state of check box in specific sub-tab
		\param             Index: [in] The index of sub-tab.
		\param             Enable: [in] Enable flag.
		\return             None
		*/
		virtual void SetTabChecked(int index, bool enable) = 0;

		/*!
		\brief                Retrieves the check state of check box in specific sub-tab
		\param             Index: [in] The index of sub-tab.
		\return             bool: Enable flag.
		*/
		virtual bool IsTabChecked(int index) = 0;

		/*!
		\brief                Set enable auto show left and right image when mouse press sub-tabs
		\param             Enable: [in] Enable flag.
		\return             None
		*/
		virtual void EnableAutoShowImagesOnPressTab(bool enable) = 0;

		/*!
		\brief                Retrieves is enable drag the sub-tabs
		\return             bool: Enable flag.
		*/
		virtual bool IsEnableAutoShowImagesOnPressTab(void) const = 0;

		/*!
		\brief                Retrieves size of specific sub-tab
		\param             Index: [in] The index of sub-tab.
		\param             Width: [out] The width value.
		\param             Height: [out] The height value.
		\return             None
		*/
		virtual void GetTabSize(int index, float &width, float &height) = 0;

		/*!
		\brief                Retrieves position of specific sub-tab
		\param             Index: [in] The index of sub-tab.
		\param             IsAbsolute: [in] Absolute flag.
		\param             X: [out] The x value.
		\param             Y: [out] The y value.
		\return             None
		*/
		virtual void GetTabPosition(int index, bool isAbsolute, float &x, float &y) = 0;

		/*!
		\brief                Set  text scroll's attribute of sub-tab
		\param             duration: [in] The duration value.
		\param             speed: [in] The speed value.
		\param             delay: [in] The delay value.
		\param             type: [in] The type.
		\param             direction: [in] The direction.
		\param             continueGap: [in] The continueGap value.
		\return             None
		*/
		virtual void SetTabScrollAttribute(guint duration, gfloat speed, guint delay, gint repeat, ClutterTextScrollType type, ClutterTimelineDirection direction, guint continueGap) = 0;
	};
}

#endif //_HALO_ICATEGORYTAB_H_
