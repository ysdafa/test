#ifndef _ITHUMBNAIL_H_
#define _ITHUMBNAIL_H_

namespace HALO
{
#ifndef WIN32
#include "ua_video_control.h"
#endif
	class IThumbnailListener : public IListener
	{
	public:
		virtual bool OnImageReady(class IThumbnail *thumbnail, int index, bool success) { return false; }
		virtual bool OnIconClicked(class IThumbnail *thumbnail, int index) { return false; }
		virtual bool OnCheckMarkStateChanged(class IThumbnail *thumbnail, bool checked) { return false; }
		virtual bool OnProgressValueChanged(class IThumbnail *thumbnail, int value) { return false; }
	};

	class IThumbnail : virtual public IActor
	{
	public:
		enum EThumbnailStyle
		{
			THUMB_STYLE_IMAGE = 0x01,
			THUMB_STYLE_ICON = 0x02,     // Icon overlaid on Image
			THUMB_STYLE_TEXT = 0x04,     // Text overlaid on Image
			THUMB_STYLE_PROGRESSBAR = 0x08,
			THUMB_STYLE_CHECKBOX = 0x10,
			THUMB_STYLE_INFO = 0x20,     // Information
			THUMB_STYLE_SCROLLPLAYER = 0x40,
			THUMB_STYLE_VIDEO = 0x80,
		};
		typedef uint EThumbnailStyles;

		enum EInformationStyle
		{
			THUMB_INFO_STYLE_TEXT = 0x01,
			THUMB_INFO_STYLE_ICON = 0x02,
			THUMB_INFO_STYLE_RATING = 0x04
		};
		typedef uint EInformationStyles;

		enum EMouseEventType
		{
			EVENT_MOUSE_PRESSED = 0,
			EVENT_MOUSE_RELEASE,
			EVENT_MOUSE_MOVED
		};

		struct TImageInfo
		{
			TRect alloc;
			std::string src;
			std::string defaultSrc;
			ImageWidget::FillMode fillMode;
			bool  async;

			TImageInfo() : fillMode(ImageWidget::Stretch), async(true) {}
		};

		struct TTextInfo
		{
			TRect  alloc;
			std::string text;
			std::string fontName;
			EHAlignment hAlign;
			EVAlignment vAlign;
			Color textColor;
			int   opacity;
			bool  ellipsize;
			bool  singleLineMode;
			bool  bold;
			bool  italic;

			TTextInfo() : hAlign(HALIGN_LEFT), vAlign(VALIGN_MIDDLE), opacity(255), ellipsize(true), singleLineMode(true), bold(false), italic(false) {}
		};

		struct TIconInfo
		{
			TRect  alloc;
			std::string unpressName;
			std::string pressedName;
			int   opacity;
			bool  async;
			bool  clickable;

			TIconInfo() :opacity(255), async(false), clickable(false) {}
		};

		struct TRatingInfo
		{
			TRect alloc;
			std::string offName;
			std::string onName;
			std::string halfName;
			TValue2f iconSize;
			int gap;
			int opacity;
			int value;

			TRatingInfo() : gap(0), opacity(255), value(0) {}
		};

		struct TCheckBoxInfo
		{
			TRect  alloc;
			std::string uncheckName;
			std::string checkedName;

			TCheckBoxInfo() {}
		};

		struct TProgressBarInfo
		{
			TRect  alloc;
			Color backgroundColor;
			Color progressColor;
			std::string normalThumb;
			std::string focusThumb;
			TValue2f thumbSize;
			EDirectionType direction;
			bool  slidable;

			TProgressBarInfo() : direction(TYPE_HORIZONTAL), slidable(false) {}
		};

		struct TAttachText
		{
			TTextInfo textInfo;
			Color backgroundColor;
			bool  useRefereceColor;
			TRegion colorPickingRange;

			TAttachText() : useRefereceColor(true) {}
		};

		struct TInformation
		{
			TRect  alloc;
			std::vector<TTextInfo> textInfos;
			std::vector<TIconInfo> iconInfos;
			TRatingInfo ratingInfo;
			Color backgroundColor;
			bool  useRefereceColor;
			TRegion colorPickingRange;

			TInformation() : useRefereceColor(true) {}
		};

		struct TScrollPlayerInfo
		{
			bool async;
			int itemNumber;
			int aniDuration;
			TRect alloc;
			ClutterAnimationMode aniMode;
			std::vector<std::string> srcList;

			TScrollPlayerInfo() : async(true), itemNumber(2), aniDuration(500), aniMode(CLUTTER_EASE_IN_OUT_QUAD)
			{}
		};
#ifndef WIN32
		struct TVideoActorInfo
		{
			TRect alloc;
			ClutterVideoController type;
			std::string uri;

			TVideoActorInfo(): type(CLUTTER_VC_TYPE_TV_MAIN){}
		};
#endif
		struct TThumbnailAttr
		{
			TImageInfo imageInfo;
			std::vector<TIconInfo> attachIconInfos;
			TAttachText attachTextInfo;
			TProgressBarInfo progressBar;
			TCheckBoxInfo checkBox;

			EInformationStyles infoStyle;
			TInformation info; 

			TScrollPlayerInfo scrollPlayerInfo;
#ifndef WIN32
			TVideoActorInfo videoActorInfo;
#endif
			TThumbnailAttr() : infoStyle(0) {}
		};

	public:
		static IThumbnail* CreateInstance(Widget* parent, float width, float height, EThumbnailStyles styles, EThumbnailStyles visibleStyles, const TThumbnailAttr& attr);
	public:
		virtual bool AddThumbnailListener(IThumbnailListener *listener) = 0;

		virtual bool OnMouseEvent(EMouseEventType eventType, IMouseEvent* pMouseEvent) = 0;

		virtual void SetThumbnailStyle(EThumbnailStyles styles, EThumbnailStyles visibleStyles, const TThumbnailAttr& attr, bool flagAni) = 0;   
		virtual void EnableThumbnailStyle(bool enable, EThumbnailStyle style, bool flagAni) = 0; // show or hide given style
		virtual void EnableThumbnailStyles(bool enable, EThumbnailStyles styles, bool flagAni) = 0;
		virtual void EnableAttachIcon(bool enable, int iconIndex, bool flagAni) = 0;  // show or hide given attached icon
		virtual void EnableInformationIcon(bool enable, int iconIndex, bool flagAni) = 0; // show or hide given information icon
		virtual void EnableInformationText(bool enable, int textIndex, bool flagAni) = 0; // show or hide given information text

		virtual void SetImage(const char* fileName) = 0;
		virtual void SetAttachTextColorPickingRange(int fromHPer, int toHPer, int fromVPer, int toVPer) = 0;
		virtual void SetInformationColorPickingRange(int fromHPer, int toHPer, int fromVPer, int toVPer) = 0;
		virtual bool GetInformationColorPicking(Color &color) = 0;
		virtual bool GetInformationExtractColor(Color &color) = 0;
		virtual bool GetColorPicking(int fromHPer, int toHPer, int fromVPer, int toVPer, Color &color) = 0;

		virtual void AddAttachIcon(const std::vector<TIconInfo> &iconInfo) = 0;
		virtual void RemoveAttachIcon(int index) = 0;
		virtual int  AttachedIconNumber(void) = 0;
		virtual void SetAttachIconImage(int index, const char* fileName) = 0;

		virtual void AddAttachText(const TAttachText &atInfo) = 0;
		virtual void RemoveAttachText(void) = 0;
		virtual void SetAttachText(const char* text) = 0;
		virtual void SetAttachTextColor(Color color) = 0;
		virtual void SetAttachTextFont(const char* font) = 0;
		virtual void SetAttachTextScrollAttribute(guint duration, guint delay, gint repeat, ClutterTextScrollType type, ClutterTimelineDirection direction, guint continueGap)  = 0;
		virtual void EnableAttachTextAutoScroll(bool enable) = 0;
		virtual bool isAttachTextAutoScrollEnabled(void) = 0;  //deprecated
		virtual void EnableAttachTextEllipsize(bool enable) = 0;
		virtual bool isAttachTextEllipsizeEnabled(void) = 0;
		virtual void EnableAttachTextMultiLine(bool enable) = 0;
		virtual bool isAttachTextMultiLineEnabled(void) = 0;

		virtual void AddProgressBar(const TProgressBarInfo &pbInfo) = 0;
		virtual void RemoveProgressBar(void) = 0;
		virtual void SetProgressBarRange(int min, int max) = 0;
		virtual void SetProgressBarValue(int value) = 0;

		virtual void AddCheckBox(const TCheckBoxInfo &cbInfo) = 0;
		virtual void RemoveCheckBox(void) = 0;

		virtual void AddInformationText(const std::vector<TTextInfo> &textInfo) = 0;
		virtual void RemoveInformationText(int index) = 0;
		virtual int InformationTextNumber(void) = 0;
		virtual void SetInformationText(int index, const char* text) = 0;
		virtual void SetInformationTextColor(int index, Color color) = 0;
		virtual void SetInformationTextFont(int index, const char* font) = 0;
		virtual void SetInformationTextScrollAttribute(int index, guint duration, guint delay, gint repeat, ClutterTextScrollType type, ClutterTimelineDirection direction, guint continueGap) = 0;
		virtual void EnableInformationTextAutoScroll(int index, bool enable) = 0;
		virtual bool isInformationTextAutoScrollEnabled(int index) = 0; //deprecated
		virtual void EnableInformationTextEllipsize(int index, bool enable) = 0;
		virtual bool isInformationTextEllipsizeEnabled(int index) = 0;
		virtual void EnableInformationTextMultiLine(int index, bool enable) = 0;
		virtual bool isInformationTextMultiLineEnabled(int index) = 0;
		virtual void SetInformationRatingValue(int value) = 0;

		virtual void AddInformationIcon(const std::vector<TIconInfo> &iconInfo) = 0;
		virtual void RemoveInformationIcon(int index) = 0;
		virtual int InformationIconNumber(void) = 0;
		virtual void SetInformationIconImage(int index, const char* fileName) = 0;

		virtual void SetImagePosition(float x, float y) = 0;
		virtual void GetImagePosition(float &x, float &y) = 0;
		virtual void ResizeImage(float width, float height) = 0;
		virtual void GetImageSize(float &width, float &height) = 0;

		virtual void SetAttachIconPosition(int index, float x, float y) = 0;
		virtual void GetAttachIconPosition(int index, float &x, float &y) = 0;
		virtual void ResizeAttachIcon(int index, float width, float height) = 0;
		virtual void GetAttachIconSize(int index, float &width, float &height) = 0;

		virtual void SetAttachTextPosition(float x, float y) = 0;
		virtual void GetAttachTextPosition(float &x, float &y) = 0;
		virtual void ResizeAttachText(float width, float height) = 0;
		virtual void GetAttachTextSize(float &width, float &height) = 0;

		virtual void SetCheckBoxPosition(float x, float y) = 0;
		virtual void GetCheckBoxPosition(float &x, float &y) = 0;
		virtual void ResizeCheckBox(float width, float height) = 0;
		virtual void GetCheckBoxSize(float &width, float &height) = 0;

		virtual void SetProgressBarPosition(float x, float y) = 0;
		virtual void GetProgressBarPosition(float &x, float &y) = 0;
		virtual void ResizeProgressBar(float width, float height) = 0;
		virtual void GetProgressBarSize(float &width, float &height) = 0;

		virtual void SetInformationPosition(float x, float y) = 0;
		virtual void GetInformationPosition(float &x, float &y) = 0;
		virtual void ResizeInformation(float width, float height) = 0;
		virtual void GetInformationSize(float &width, float &height) = 0;

		virtual void SetInformationIconPosition(int index, float x, float y) = 0;
		virtual void GetInformationIconPosition(int index, float &x, float &y) = 0;
		virtual void ResizeInformationIcon(int index, float width, float height) = 0;
		virtual void GetInformationIconSize(int index, float &width, float &height) = 0;

		virtual void SetInformationTextPosition(int index, float x, float y) = 0;
		virtual void GetInformationTextPosition(int index, float &x, float &y) = 0;
		virtual void ResizeInformationText(int index, float width, float height) = 0;
		virtual void GetInformationTextSize(int index, float &width, float &height) = 0;

		virtual void SetAttachIconOpacity(int index, int opacity) = 0;
		virtual int  AttachIconOpacity(int index) = 0;
		virtual void SetAttachTextOpacity(int opacity) = 0;
		virtual int  AttachTextOpacity(void) = 0;
		virtual void SetInformationIconOpacity(int index, int opacity) = 0;
		virtual int  InformationIconOpacity(int index) = 0;

		virtual EThumbnailStyles VisibleThumbnailStyles(void) = 0;

		virtual EThumbnailStyles ThumbnailStyle(void) = 0;
		virtual EInformationStyles ThumbnailInformationStyle(void) = 0;

		virtual void SetScaleAnimation(int duration, ClutterAnimationMode mode) = 0;
		virtual void SetStyleTransAnimation(int duration, ClutterAnimationMode mode) = 0;
		virtual void Scale(TValue2f imageScaleFactor, bool flagAni) = 0;
		virtual void Scale(TValue2f imageScaleFactor, float titleFontScaleFactor, bool flagAni) = 0;

		virtual void SetDimBackgroundColor(const Color &color) = 0;
		virtual void SetDimImage(const char* path, int opacity) = 0;
		virtual void Dim(bool enable) = 0;
		virtual void RaiseImage(void) = 0;
		virtual void RaiseAttachIcon(int index) = 0;
		virtual void RaiseAttachText(void) = 0;
		virtual void RaiseProgressBar(void) = 0;
		virtual void RaiseCheckBox(void) = 0;
		virtual void RaiseInformation(void) = 0;

		virtual void SetChecked(bool checked) = 0;
		virtual bool IsChecked(void) = 0;

		virtual void Enable(bool enable) = 0;
		virtual bool IsEnabled(void) = 0;

		virtual void SetTTSText(const std::string text) = 0;
		virtual void PlayTTSText(void) = 0;

		virtual void ScrollImage(void) = 0;
	};
}

#endif //_ITHUMBNAIL_H_
