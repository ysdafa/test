#ifndef _ITOGGLE_BUTTON_H_
#define _ITOGGLE_BUTTON_H_

namespace HALO
{
	class HALO_API ToggleButtonListener
	{
	public:
		/*!
		\brief               Process the event when toggle button is on state.
		\remarks             If use the listener ,must over write the function.
		\param               togglebutton:[in] The toggle button which is selected. 
		\return              None
		*/
		virtual void OnToggleOn(class IToggleButton *togglebutton) {}
		/*!
		\brief               Process the event when toggle button is off state.
		\remarks             If use the listener ,must over write the function.
		\param               togglebutton:[in] The toggle button which is selected. 
		\return              None
		*/
		virtual void OnToggleOff(class IToggleButton *togglebutton) {}
	};
	class HALO_API IToggleButton : virtual public IActor
	{
	
	public:
		enum ECheckState
		{
			E_STATE_ON = 0,   //!< toggle button check state on.
			E_STATE_OFF       //!< toggle button check state off.   
		};
		typedef enum E_ITEM_STATE
		{
			E_STATE_NORMAL = 0,  //!< toggle button state normal.
			E_STATE_FOCUSED,     //!< toggle button state focused.  
			E_STATE_DISABLED,	//!<  toggle button state disabled.   
			E_STATE_HIGHLIGHTED,//!<  toggle button state high lighted.
			E_STATE_ALL			//!<  toggle button state all.
		}EItemState;
		typedef struct T_TOGGLEBUTTON_ATTR
		{
			float width;   //!< toggle button width. 
			float height;  //!< toggle button height 
			float xPos;	//!< toggle button x position
			float yPos;//!< toggle button y position
		}TToggleButtonAttr;
	public:
		/*!
		\brief				 Create a new group.          
		\param               parent: The parent of the group. 
		\param               attr: The group attribute.
		\return              HALO::IToggleButton *: A pointer to IToggleButton.
		\par Example:
		\code
			IToggleButton::T_TOGGLEBUTTON_ATTR attr;
			attr.width = 160;
			attr.height = 80;
			attr.xPos = 300;
			attr.yPos = 100;
			openButton = IToggleButton::CreateInstance(m_window ,attr);
		*/
		static IToggleButton* CreateInstance(IActor* parent, const TToggleButtonAttr &attr);
	public:	
		/*!
		\brief               Set the check image by check state.
		\param               state:[in] The state of button ,maybe on or off. 
		\param               imageBuffer:[in] A pointer to IImageBuffer. 
		\param               width:[in] The width of check image. 
		\param               height:[in] The height of check image. 
		\return              None
		\par Example:
		\code
			openButton->SetCheckImage(IToggleButton::E_STATE_ON ,onImageBuffer ,70 ,70);
		*/
		virtual void SetCheckImage(ECheckState state , IImageBuffer* imageBuffer, float width ,float height) = 0;
		/*!
		\brief               Set the button image by button state.
		\param               state:[in] The state of button. 
		\param               imageBuffer:[in] A pointer to IImageBuffer.
		\return              None
		\par Example:
		\code
			openButton->SetImage(IToggleButton::E_STATE_FOCUSED , focusedImageBuffer);
			openButton->SetImage(IToggleButton::E_STATE_NORMAL , unfocusedImageBuffer);
		
		*/
		virtual void SetImage(EItemState state , IImageBuffer* imageBuffer) = 0;
		/*!
		\brief               Set the text by check state.
		\param               state:[in] The check state. 
		\param               text:[in] A const pointer to char. 
		\return              None
		\par Example:
		\code
			openButton->SetText(IToggleButton::E_STATE_ON ,on);
			openButton->SetText(IToggleButton::E_STATE_OFF ,off);
		*/
		virtual void SetText(ECheckState state ,const char* text) = 0;
		/*!
		\brief               Get the text by check state.
		\param               state:[in] The check state. 
		\return              const char *: A const pointer to char 
		*/
		virtual const char* ItemText(ECheckState state) = 0;
		/*!
		\brief               Set font size by check state.
		\param               state:[in] The check state. 
		\param               fontSize:[in] the font size. 
		\return              None
		\par Example:
		\code
			openButton->SetTextFontSize(IToggleButton::E_STATE_ON,25);
			openButton->SetTextFontSize(IToggleButton::E_STATE_OFF,15);
		*/
		virtual void SetTextFontSize(ECheckState state, const int fontSize) = 0;
		/*!
		\brief               Add listener to toggle button.
		\param               listeners: A pointer to ToggleButtonListener ,which is will be set into toggle button. 
		\return              None
		\par Example:
		\code
			openButton->AddListener(this);
		*/
		virtual void AddListener(ToggleButtonListener *listeners) = 0;
		/*!
		\brief               Remove the listener which has been set.
		\remarks             When Add the listener to toggle button, when destroy the application ,must remove the listener.
		\return              None
		\par Example:
		*/
		virtual void RemoveListener() = 0;
		/*!
		\brief				 Set the check state for the button.
		\remarks             If the isChecked is true, the button is checked, otherwise is unchecked.
		\return              None
		*/
		virtual void SetCheck(bool isChecked) = 0;
		/*!
		\brief               Get the button check state.
		\return              bool: If return true ,the button is on check state, otherwise is on uncheck state. 
		*/
		virtual bool IsChecked() = 0;
		/*!
		\brief               Enable the check or not.
		\remarks             if the isSelected is false, the button can't be selected.
		\return              None
		*/
		virtual void EnableChecked(bool isSelected) = 0;

		/*!
		\brief               Show the toggle button.
		\return              None
		*/
		virtual void Show(bool isOpened) = 0;

		/*!
		\brief               Set the move animation property
		\param               animationMode:[in] Explain parameter here. 
		\param               aniDuration:[in] Explain parameter here. 
		\return              None
		\par Example:
		\code
		*/
		virtual void SetAnimationProperty(ClutterAnimationMode animationMode, int aniDuration) = 0;
	};

}
#endif