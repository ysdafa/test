#ifndef _HALO_IPROGRESS_H_
#define _HALO_IPROGRESS_H_

namespace HALO
{
	class HALO_API IProgressListener : public IListener
	{
	public:
		/*!
		\brief               When progress value changed, this function will be called
		\param               slider:[in]      slider subject
		\return              bool: not used
		*/
		virtual bool OnValueChanged(class IProgress* slider) = 0;
	};

	class HALO_API IProgress : virtual public IActor
	{
	public:
		/*!
		\brief               Create a new progress control
		\remarks             The parent is not recommended to NULL.
		\param               parent:[in]      The parent of rectangle.
		\param               width:[in]		  The width of rectangle.
		\param               height:[in]      The height of rectangle.
		\return              HALO::IProgress *: The newly created progress control instance pointer.
		\par Example:
		\code
			IProgress* progress = IProgress::CreateInstance(m_window, width, height);		
		\endcode
		\see                 IActor::CreateInstance()
		*/
		static IProgress* CreateInstance(IActor* parent, float width, float height, EDirectionType direction);
		static IProgress* CreateInstance(Widget* parent, float width, float height, EDirectionType direction);

	public:
		virtual bool AddListener(IProgressListener* listener) = 0;
		virtual bool RemoveListener(IProgressListener* listener) = 0;

	public:
		/*!
		\brief               Set progress image
		\param               imageBuffer:[in] progress image buffer
		\return              None
		*/
		virtual void SetProgressImage(IImageBuffer* imageBuffer) = 0;		// not using now
		virtual void SetProgressColor(const ClutterColor& color) = 0;
		//virtual const ClutterColor& ProgressColor(void) = 0;

		/*!
		\brief               Set background image
		\param               imageBuffer:[in] background image buffer
		\return              None
		*/
		virtual void SetBackgroundImage(IImageBuffer* imageBuffer) = 0;		// not using now
		virtual void SetBackgroundColor(const ClutterColor& color) = 0;
		//virtual const ClutterColor& BackgroundColor(void) = 0;

		virtual void SetMinValue(int minValue) = 0;
		virtual int MinValue(void) const = 0;

		virtual void SetMaxValue(int maxValue) = 0;
		virtual int MaxValue(void) const = 0;

		virtual void SetValue(int value) = 0;
		virtual int Value(void) const = 0;

		/*!
		\brief               Set progress control reverse flag
		\param               flagReverse:[in]	reverse flag
		\return              None
		*/
		virtual void SetReverse(bool flagReverse) = 0;

		/*!
		\brief               Get reverse flag
		\return              bool: reverse flag
		*/
		virtual bool FlagReverse(void) const = 0;

		virtual void SetNormalThumbImage(const std::string& normalThumbImagePath) = 0;
		virtual std::string NormalThumbImage(void) const = 0;

		virtual void SetFocusThumbImage(const std::string& focusThumbImagePath) = 0;
		virtual std::string FocusThumbImage(void) const = 0;

		virtual void SetThumbSize(float width, float height) = 0;
		virtual void GetThumbSize(float &width, float &height) const = 0;

		virtual void SetActive(bool flagActive) = 0;
		virtual bool FlagActive(void) const = 0;
	};
}

#endif //_HALO_IPROGRESS_H_