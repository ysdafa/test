#ifndef _IANIMATION_NEW_H_
#define _IANIMATION_NEW_H_

namespace HALO
{
	class HALO_API ITimeLineListener
	{
	public:
/*!
\brief               The callback of new frame.
\remarks             When timeLine is playing, it will send signal every frame, this function is the callback of the signal.
\param               animation: [in] The pointer of animating timeLine. 
\param               currentProgress: [in] The current progress. 
\param               data: [in] The userData which set by ITimeLine::AddListener(). 
\return              bool: If the executing of the function is correct, return true, or return false. 
\see                 ITimeLine::AddListener()
\note                N/A
*/
		virtual bool OnNewFrame(class ITimeLine *animation, double currentProgress, void *data) {return false;};

/*!
\brief               The callback of start.
\remarks             When timeLine start, it will send start signal, this function is the callback of the signal.
\param               animation: [in] The pointer of animating timeLine. 
\param               data: [in] The userData which set by ITimeLine::AddListener(). 
\return              bool: If the executing of the function is correct, return true, or return false. 
\see                 ITimeLine::AddListener()
\note                N/A
*/
		virtual bool OnStarted(class ITimeLine *animation, void *data) {return false;};

/*!
\brief               The callback of via.
\remarks             When animatable object reach one destination and the transition is still playing, it will send the via signal.
\param               animation: [in] The pointer of animating timeLine. 
\param               data: [in] The userData which set by ITimeLine::AddListener(). 
\return              bool: If the executing of the function is correct, return true, or return false. 
\see                  ITimeLine::AddListener()
\note                N/A
*/
		virtual bool OnVia(class ITimeLine *animation, void *data) {return false;};

/*!
\brief               The callback of pause.
\remarks             When timeLine pause, it will send pause signal, this function is the callback of the signal.
\param               animation: [in] The pointer of animating timeLine. 
\param               data: [in] The userData which set by ITimeLine::AddListener(). 
\return              bool: If the executing of the function is correct, return true, or return false. 
\see                 ITimeLine::AddListener()
\note                N/A
*/
		virtual bool OnPaused(class ITimeLine *animation, void *data) {return false;};

/*!
\brief               The callback of complete.
\remarks             When timeLine complete, it will send complete signal, this function is the callback of the signal.
\param               animation: [in] The pointer of animating timeLine. 
\param               data: [in] The userData which set by ITimeLine::AddListener(). 
\return              bool: If the executing of the function is correct, return true, or return false. 
\see                 ITimeLine::AddListener()
\note                N/A
*/
		virtual bool OnCompleted(class ITimeLine *animation, void *data) {return false;};

/*!
\brief               The callback of stop.
\remarks             When timeLine stop, it will send stop signal, this function is the callback of the signal.
\param               animation: [in] The pointer of animating timeLine. 
\param               flagFinished: [in] Flag of whether timeLine is finished. if true, the reason of stop is the timeLine is completed, if false, the reason is user has called the Stop() of ITimeLine. 
\param               data: [in] The userData which set by ITimeLine::AddListener(). 
\return              bool: If the executing of the function is correct, return true, or return false. 
\see                 ITimeLine::AddListener()
\note                N/A
*/
		virtual bool OnStoped(class ITimeLine *animation, bool flagFinished, void *data) {return false;};
	};

	class HALO_API ITimeLine : public Instance
	{
	public:
		enum EAnimationEventType
		{
			ANI_EVENT_COMPLETE = 0,	//!< Animation event type: completed
			ANI_EVENT_MARKER_REACHED, //!< Animation event type: marker-reached
			ANI_EVENT_NEW_FRAME, //!< Animation event type: new-frame
			ANI_EVENT_PAUSED, //!< Animation event type: paused
			ANI_EVENT_STARTED, //!< Animation event type: started
			ANI_EVENT_STOPPED, //!< Animation event type: stopped
			ANI_EVENT_MAX
		};

/*!
\brief               Create the instance.
\param               flagCustomAnimation: [in] Is the animation a custom one. 
\return              HALO::ITimeLine *: The instance of time line
\par Example:
\code
ITimeLine *timeLine = ITimeLine::CreateInstance(false);
\endcode
\note                N/A
*/
		static ITimeLine* CreateInstance(bool flagCustomAnimation);

/*!
\brief               Set the animation's duration.
\param               duration: [in] The duration of animation. 
\return              None
\note                N/A
*/
		virtual void SetDuration(int duration) = 0;

/*!
\brief               Get the duration of animation.
\return              int: The duration's value 
\note                N/A
*/
		virtual int Duration(void) = 0;

/*!
\brief               Set the animation's mode.
\remarks             Write remarks here
\param               animationMode: [in] The mode of animation. 
\return              None
\par Example:
\code
timeLine->SetMode(CLUTTER_EASE_IN_QUAD);
\endcode
\note                N/A
*/
		virtual void SetMode(ClutterAnimationMode animationMode) = 0;

/*!
\brief               Add the listener to timeLine.
\remarks             Write remarks here
\param               listener: [in] The pointer of listener. 
\param               userData: [in] The pointer of the data, it will be set back in the callback function of listener. 
\return              None
\par Example:
\code
Add code snip here
\endcode
\see                 The callback function of ITimeLineListener
\note                N/A
*/
		virtual void AddListener(ITimeLineListener *listener, void *userData) = 0;

/*!
\brief               Remove the listener.
\param               listener: [in] The pointer of listener. 
\param               userData: [out] The userData of this listener. 
\return              None
\note                N/A
*/
		virtual void RemoveListener(ITimeLineListener *listener, void* &userData) = 0;

/*!
\brief               Get the flag of playing.
\return              True means the ITimeLine is playing, false means it is not playing.
\note                N/A
*/
		virtual bool IsPlaying(void) = 0;

/*!
\brief               Play the timeLine.
\return              None.
\note                N/A
*/
		virtual void Play(void) = 0;

/*!
\brief               Stop the timeLine.
\return              None.
\note                N/A
*/
		virtual void Stop(void) = 0;

/*!
\brief               Pause the timeLine.
\return              None.
\note                N/A
*/
		virtual void Pause(void) = 0;
	};

	class HALO_API ITransition : virtual public ITimeLine
	{
	public:

/*!
\brief               Create the instance of ITransition.
\return              HALO::ITransition *: The instance. 
\par Example:
\code
ITransition *timeLine = ITransition::CreateInstance(false);
\endcode
\note                N/A
*/
		static ITransition* CreateInstance(void);

/*!
\brief               Set the destination of transition.
\remarks             This is used to set the "one int" type destination, such as alpha.
\param               destValue: The destination. 
\return              None
\note                N/A
*/
		virtual void SetDestination(int destValue) = 0;

/*!
\brief               Set the destination of transition.
\remarks             This is used to set the "one float" type destination, such as position-x.
\param               destValue: The destination. 
\return              None
\note                N/A
*/
		virtual void SetDestination(float destValue) = 0;


/*!
\brief               Write brief introduction here.
\remarks			 This is used to set the "two float" type destination, such as position.
\param               destValue1: The first value of destination. 
\param               destValue2: The second value of destination. 
\return              None
\note                N/A
*/
		virtual void SetDestination(float destValue1, float destValue2) = 0;

/*!
\brief               Let the animatable object jump to the destination.
\remarks             The same effect to play the animation with the 0 duration.
\return              None
\note                N/A
*/
		virtual void JumpToDestination(void) = 0;
	};

	class HALO_API IAnimatable
	{
	public:
/*!
\brief               Bind a transition to the animatable object.
\remarks             Use to tell a transition what is its animatableObject and what property shall the transition change.
\param               transition: [in] The pointer of transition. 
\param               animationType: [in] The type to sign what property shall the transition change, the value's meaning shall define by the derived class. 
\return              bool: True means success executing, false means not success. 
\note                N/A
*/
		virtual bool BindTransition(ITransition *transition, int animationType) = 0;
	};
}

#endif
