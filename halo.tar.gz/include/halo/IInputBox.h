#ifndef _IINPUTBOX_H_
#define _IINPUTBOX_H_

#ifndef WIN32
#define HAVE_ECORE_IMF
#endif

namespace HALO
{
	class HALO_API IInputBox : virtual public IActor
	{
	public:

		//! InputBox attr.
		struct TInputBoxAttr
		{
			float margin_h;			//!< Text x position.
			float margin_v;			//!< Text y position.
			TInputBoxAttr() : margin_h(25), margin_v(10) {}
		};

		//! InputBox state.
		enum  T_INPUTBOX_STATE
		{
			INPUTBOX_STATE_NORMAL,		//!< InputBox normal state.
			INPUTBOX_STATE_FOCUS		//!< InputBox focus state.
		};

	public:
		
		static IInputBox* CreateInstance(IActor* parent, float width, float height, const TInputBoxAttr &attr);
		static IInputBox* CreateInstance(Widget* parent, float width, float height, const TInputBoxAttr &attr);

	public:

		//! Set image.
		virtual void SetImage(const std::string& filepath) = 0;
		
		//! Set normal/focus state image.
		virtual void SetNormal_FocusImage(const std::string& file_normal, const std::string& file_focus) = 0;

		//! Set normal/focus state text color.
		virtual void SetNormal_FocusTextColor(const ClutterColor color_normal, const ClutterColor color_focus) = 0;
		
		//! Set image with state.
		virtual void SetImage(T_INPUTBOX_STATE state, const std::string& filepath) = 0;

		//! Set text color with state.
		virtual void SetTextColor(T_INPUTBOX_STATE state, const ClutterColor color) = 0;

		//! Set text.
		virtual void SetText(const std::string& text) = 0;

		//! Get text.
		virtual std::string Text() const = 0;

		//! Set background color.
		virtual void SetBGColor(const ClutterColor color) = 0;

		//! Set text background color.
		virtual void SetTextBGColor(const ClutterColor color) = 0;

		//! Set text color.
		virtual void SetTextColor(const ClutterColor color) = 0;

		//! Set text cursor color.
		virtual void SetTextCursorColor(const ClutterColor color) = 0;

		//! Set text selection color.
		virtual void SetTextSelectionColor(const ClutterColor color) = 0;

		//! Set text horizontal alignment.
		virtual void SetTextHAlignment(EHAlignment hAlign) = 0;

		//! Get text horizontal alignment.
		virtual EHAlignment TextHAlignment() = 0;

		//! Set text font.
		virtual void SetFont(const std::string& font) = 0;

		//! Get text font.
		virtual std::string Font() const = 0;

		//! Set text font size.
		virtual void SetFontSize(int size) = 0;

		//! Get text font size.
		virtual int FontSize() = 0;

		//! Set text max count.
		virtual void SetTextMaxCount(int count) = 0;

		//! Get text max count.
		virtual int TextCount() = 0;

		//! Insert text.
		virtual void InsertText(const std::string& text) = 0;

		//! Set focus to text.
		virtual bool SetFocus() = 0;

		//! Kill focus to text.
		virtual bool KillFocus() = 0;

#ifdef HAVE_ECORE_IMF		
		virtual void EnableIME(bool IsIMEEnabled) = 0;
#endif
	};
}
#endif
