#ifndef _IRADIOBUTTON_GROUP_H_
#define _IRADIOBUTTON_GROUP_H_

namespace HALO
{
	class HALO_API IRadioButtonGroup :  virtual public IBaseSelectButtonGroup
	{
	public:
		/*!
		\brief				 Create a new group.          
		\param               parent: The parent of the group. 
		\param               attr: The group attribute.
		\return              HALO::IRadioButtonGroup *: A pointer to IRadioButtonGroup.
		\par Example:
		\code
		IBaseSelectButtonGroup::T_BUTTONGROUP_ATTR attr;
		attr.estyle = IBaseSelectButtonGroup::E_LAYOUT_VERTICAL;
		attr.itemW = 300;
		attr.itemH = 80;
		attr.rowNum = 4;
		attr.columnNum = 1;
		m_group = IRadioButtonGroup::CreateInstance(m_window ,attr);
		*/
		//static IRadioButtonGroup* CreateInstance(IActor* parent, const TButtonGroupAttr &attr);
		static IRadioButtonGroup* CreateInstance(IActor* parent, float groupW, float groupH);
	};
}
#endif