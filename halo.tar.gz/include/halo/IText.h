#ifndef _HALO_ITEXT_H_
#define _HALO_ITEXT_H_

namespace HALO
{
	class HALO_API IText : virtual public IActor
	{
	public:
		static IText* CreateInstance(IActor* parent, float width, float height);
		static IText* CreateInstance(Widget* parent, float width, float height);
	public:

		//! Struct of fontstyle.
		enum  T_STYLE
		{
			STYLE_NONE = 0, /*!< NONE */
			STYLE_ITALIC, /*!< ITALIC */
			STYLE_BOLD, /*!< BOLD with bold weight */
			STYLE_UNDERLINE /*!< UNDERLINE */
		};
		
 		//! Set text content.
		virtual void SetText(const char *text) = 0;

		//! Get text content.
 		virtual const char* Text(void) = 0;

		//! Set text color.
		virtual void SetTextColor(const ClutterColor& textColor) = 0;

		//! Get text color value.
		virtual const ClutterColor& TextColor(void) = 0;

		/*!
		\brief               Set text font.
		\param               font: [in]Font name. 
		\return              None
		\par Example:
		\code
							 SetFont("Sans 20px");
							 SetFont("Sans");
		\endcode
		*/
		virtual void SetFont(const char* font) = 0;

		//! Get text font name.
		virtual const char* Font(void) = 0;

		/*!
		\brief               Set text horizontal and vertical alignment.
		\param               hAlign: [in]Horizontal alignment value. 
		\param               vAlign: [in]Vertical alignment value. 
		\return              None
		*/
		virtual void SetTextAlignment(EHAlignment hAlign, EVAlignment vAlign) = 0;

		/*!
		\brief               Get text horizontal and vertical alignment.
		\param               hAlign: [out]The horizontal alignment value. 
		\param               vAlign: [out]The vertical alignment value. 
		\return              None
		*/
		virtual void GetTextAlignment(EHAlignment& hAlign, EVAlignment& vAlign) = 0;

		/*!
		\brief               Set text single-line or multi-line state.
		\param               flagMutliLineMode: [in]true, multi-line state; false, single-line state. 
		\return              None
		*/
		virtual void EnableMultiLine(bool flagMutliLineMode) = 0;

		//! Get text single-line or multi-line state.
 		virtual bool IsMultiLineEnabled(void) = 0;

		//! Set text row gap.
 		virtual void SetRowGap(int gap) = 0;

		//! Get text row gap value.
		virtual int RowGap(void) = 0;

		//! Set text max text count.
		virtual void SetMaxTextCount(int textCount) = 0;

		//! Get text max count value.
		virtual int MaxTextCount(void) = 0;

		//! Set text font size.
		virtual void SetFontSize(int size) = 0;

		//! Get text font size value.
		virtual int FontSize(void) = 0;

		/*!
		\brief               Set text shadow show or hide.
		\param               flagEnable: [in]true, show shadow; false, hide shadow. 
		\return              None
		*/
		virtual void EnableShadow(bool flagEnable) = 0;

		//! Get the shadow show or hide state.
		virtual bool IsShadowEnabled(void) = 0;

		/*!
		\brief               Set the text shadow position.
		\param               x: [in]The offset that the shadow x_position with its text x_position. 
		\param               y: [in]The offset that the shadow y_position with its text y_position. 
		\return              None
		*/
		virtual void SetShadowPosition(int x, int y) = 0;

		//! Get the shadow position.
		virtual void GetShadowPosition(int& x, int& y) = 0;

		//! Set the shadow color.
		virtual void SetShadowColor(int a, int r, int g, int b) = 0;

		//! Set the shadow color.
		virtual void SetShadowColor(ClutterColor color) = 0;

		//! Get the shadow color.
		virtual void GetShadowColor(int& a, int& r, int& g, int& b) = 0;

		//! Get the shadow color.
		virtual const ClutterColor& ShadowColor(void) = 0;

		/*!
		\brief               Set text scale attribute.
		\param               scaled_size: [in]scaled font size.
		\param               duration: [in]scale animation duration.
		\param               delay: [in]delay rate.
		\param               ani_mode: [in]animation mode.
		\return              None
		\par Example:
		\code
							 SetScaleAttribute(20, 300, 20, CLUTTER_EASE_IN_CUBIC);
		\endcode
		*/
		virtual void SetScaleAttribute(guint scaled_size, guint duration, guint delay, ClutterAnimationMode ani_mode) = 0;

		//! Set text scale size.
		virtual void SetScaleSize(guint scale_size) = 0;

		//! Start scale text.
		virtual void StartScaleText(void) = 0;

		//! Stop scale text.
		virtual void StopScaleText(void) = 0;

		/*!
		\brief               Set text scroll attribute.
		\param               duration: [in]scroll duration.
		\param               speed: [float]scroll speed.
		\param               delay: [in]scroll delay.
		\param               repeat: [in]scroll repeat times.
		\param               type: [in]text scroll type.
		\param               direction: [in]text scroll direction.
		\param               continueGap: [in]text continue scroll gap.
		\return              None
		\par Example:
		\code
							 SetScaleAttribute(2000, 0.1, 500, 10, CLUTTER_TEXT_SCROLL_START_INSIDE_STOP_OUTSIDE, CLUTTER_TIMELINE_BACKWARD, 20);
		\endcode
		*/
		virtual void SetScrollAttribute(guint duration, gfloat speed, guint delay, gint repeat, ClutterTextScrollType type, ClutterTimelineDirection direction, guint continueGap) = 0;

		//! Get scroll attribute.
		virtual void GetScrollAttribute(guint& duration, gfloat& speed, guint& delay, gint& repeat, ClutterTextScrollType& type, ClutterTimelineDirection& direction, guint& continueGap) = 0;

		//! Start scale text.
		virtual void StartScrollText(void) = 0;

		//! Stop scale text.
		virtual void StopScrollText(void) = 0;
		
		//! Set enable ellipsize.
		virtual void EnableEllipsize(bool flagEnable) = 0;

		//! Get enable ellipsize state.
		virtual bool IsEllipsizeEnable() = 0;
		
		//! Set Text attribute.
		virtual bool SetCharFormat(T_STYLE style) = 0;

		//! Get text preferred height
		virtual float PreferredHeight(float width) = 0;

		//! Get text line number.
		virtual int LineCount(void) = 0;

		//! Get text line height.
		virtual int LineHeight(int index) = 0;
	};
}

#endif
