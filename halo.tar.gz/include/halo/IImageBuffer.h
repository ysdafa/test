#ifndef _HALO_IIMAGEBUFFER_H_
#define _HALO_IIMAGEBUFFER_H_

namespace HALO
{
	class HALO_API IImageBuffer : public Instance
	{
	public:
		/*!
		\brief               Creates a new image buffer instance
		\param               fileName: [in] The file path that to be loaded. 
		\return              HALO::IImageBuffer *: The newly created image buffer instance 
		*/
		static IImageBuffer* CreateInstance(const char *fileName);
		/*!
		\brief               Creates a new image buffer instance
		\param               data: [in] The image data that to be loaded. 
		\param               len: [in] length of data. 
		\return              HALO::IImageBuffer *: The newly created image buffer instance 
		*/
		static IImageBuffer* CreateInstance(const char *data, int len);
		/*!
		\brief               Create a new buffer instance with constructs a shallow copy of the given image buffer
		\param               image: [in] a given image buffer. 
		\return              HALO::IImageBuffer *: The newly created image buffer instance 
		*/
		static IImageBuffer* CreateInstance(IImageBuffer *image);

	public:
		/*!
		\brief               Queries the width of the image buffer in the current instance.
		\return              int: the width of the image 
		*/
		virtual int Width(void) = 0;
		/*!
		\brief               Queries the height of the image buffer in the current instance.
		\return              int: the height of the image 
		*/
		virtual int Height(void) = 0;
		/*!
		\brief               Queries the number of bytes per line of the image buffer in the current instance.
		\return              int: The number of bytes per image scanline 
		*/
		virtual int BytesPerLine(void) = 0;
		/*!
		\brief               Queries whether the image buffer in the current instance has an alpha channel.
		\return              bool: true if the image has alpha channel
		*/
		virtual bool HasAlphaChannel(void) = 0;

		//! Queries a pointer to the pixel data of the image.
		virtual guchar* GetPixels(void) = 0;

		//! Creates an image buffer and copies from the current instance.
		virtual	IImageBuffer* Clone(void) = 0;

	};
}

#endif //_HALO_IIMAGEBUFFER_H_
