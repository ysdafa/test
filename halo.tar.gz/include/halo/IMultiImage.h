#ifndef _HALO_IMULTIIMAGE_H_
#define _HALO_IMULTIIMAGE_H_

namespace HALO
{
	class HALO_API IMultiImage : virtual public IImage
	{
	public:
		/*!
		\brief               Creates a new image control
		\remarks             if parent is NULL, this control will be a child of the Stage. The parent is not recommended to NULL.
		\param			     parent: [in] The parent of this control.  
		\param               width: [in] Width of control in pixels. 
		\param               height: [in] Height of control in pixels. 
		\return              HALO::IImage *: The newly created image control
		\par Example:
		\code
			IImage* image = CreateInstance(IStage::GetInstance()->RootActor(), 800, 480);
		\endcode
		\see                 IStage::GetInstance()
		*/
		static IMultiImage* CreateInstance(IActor* parent, float width, float height);

		static IMultiImage* CreateInstance(Widget* parent, float width, float height);

	public:
		virtual void AddIcon(const char* path, TRect icon_rect, int opacity) = 0;
		virtual void AddIcon(IImageBuffer* buffer, TRect icon_rect, int opacity) = 0;
		virtual void AddIcon(ClutterContent *image, TRect icon_rect, int opacity) = 0;

		virtual bool SetIcon(int index, const char*path, int opacity) = 0;
		virtual bool SetIcon(int index, IImageBuffer* buffer, int opacity) = 0;
		virtual bool SetIcon(int index, ClutterContent *image, int opacity) = 0;

		virtual void RemoveIcon(int index) = 0;

		virtual int IconCount(void) = 0;

		virtual void GetIconRect(int index, TRect &icon_rect) = 0;

	};
}

#endif //_HALO_IMULTIIMAGE_H_
