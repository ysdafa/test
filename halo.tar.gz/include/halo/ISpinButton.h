#ifndef _IISPINBUTTON_H_
#define _IISPINBUTTON_H_
namespace HALO
{
	class HALO_API ISpinButtonListener : public IListener
	{
	public:
		/*!
		\brief               Process the event when the left arrow is clicked.
		\param               list:[in] The selected spin button. 
		\param               ptrEvent:[in] The selected event source type. 
		\param               eventType:[in] The selected event type. 
		\return              None
		*/
		virtual void OnLeftArrowEvent(class ISpinButton* list ,const IEvent* ptrEvent , const ClutterEventType eventType) = 0;
		/*!
		\brief               Process the event when the right arrow is clicked.
		\param               list:[in] The selected spin button. 
		\param               ptrEvent:[in] The selected event source type. 
		\param               eventType:[in] The selected event type. 
		\return              None
		*/
		virtual void OnRightArrowEvent(class ISpinButton* list ,const IEvent* ptrEvent , const ClutterEventType eventType) = 0;
	};
	class HALO_API ISpinButton : virtual public IDefaultWindow
	{
	public:
		typedef struct T_SPINBUTTON_ATTR
		{
			float xPos;	//!< spin button x position. 
			float yPos;	//!< spin button y position. 
			bool bcontent;	//!< If the spin button has content text. 
			const char* leftText;	//!< spin button left text. 
			const char* rightText;	//!< spin button right text. 
		}TSpinButtonAttr;
	public:
		/*!
		\brief				 Create a new spin button.          
		\param               parent:[in] The parent of the spin button. 
		\param               attr:[in] The spin button attribute.
		\return              HALO::ISpinButton *: A pointer to ISpinButton.
		\par Example:
		\code
			ISpinButton::T_SPINBUTTON_ATTR attr;
			attr.bcontent = true;
			attr.leftText = ltext;
			attr.rightText = rtext;
			attr.xPos = 100;
			attr.yPos = 100;
			spinbutton = ISpinButton::CreateInstance(m_window , attr);
		*/
		static ISpinButton* CreateInstance(IActor* parent, const TSpinButtonAttr &attr);
	public:
		/*!
		\brief               Show the spin button
		\return              None
		*/
		virtual void Show() = 0;
		/*!
		\brief               Hide the spin button.
		\return              None
		*/
		virtual void Hide() = 0;
		/*!
		\brief               Add listener to spin button.
		\param               listeners:[in] A pointer to ISpinButtonListener ,which is will be set into spin button. 
		\return              None
		*/
		virtual bool AddListener(ISpinButtonListener* listener) = 0;
		/*!
		\brief               Remove the listener which has been set.
		\remarks             When Add the listener to spin button, when destroy the application ,must remove the listener.
		\param               listeners:[in] A pointer to ISpinButtonListener ,which is will be set into spin button. 
		\return              None
		\par Example:
		*/
		virtual bool RemoveListener(ISpinButtonListener* listener) = 0;
	};
}
#endif