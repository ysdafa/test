#ifndef _HALO_ISTAGE_H_
#define _HALO_ISTAGE_H_

namespace HALO
{
	class HALO_API IStage : public Instance
	{
	public:
		static IStage* GetInstance(void);
		IStage(){};
		virtual ~IStage(){};

	public:
		virtual void Create(float width, float height) = 0;
		virtual void Destroy() = 0;

		virtual void SetSize(float width, float height) = 0;
		virtual void GetSize(float &width, float &height) = 0;

		virtual IActor* RootActor(void) = 0;

		virtual void UseExternalStage(ClutterActor* stage) = 0;
		virtual bool IsUsingExternalStage(void) = 0;
		
		//!Set cursor show/hide
		virtual void ShowCursor(void) = 0;
		virtual void HideCursor(void) = 0;	

		virtual ClutterActor* Stage(void) = 0;

		/********************************************
		//! Show or hide fps info
		virtual void EnableFPSShown(bool enable) = 0;

		//! Set FPS show update interval
		virtual void SetFPSShownInterval(double sec) = 0;

		//! Set FPS label font
		virtual void SetFPSLabelFont(const char*fontName) = 0;
		**********************************************************/

		virtual void DlogObjectDump(void) = 0;
		virtual void Show(void) = 0;

	private:
		static IStage* m_stage;
	};
}
#endif
