#ifndef _IFIRSTSCREENLIST_CONTROL_H_
#define _IFIRSTSCREENLIST_CONTROL_H_

namespace HALO
{
	class IFirstScreenListListener : public IListener
	{
	public:
/*!
\brief               The callback of loading main menu item.
\remarks             When control need to load main menu data by sync type, it will notify user by this callback function.
\param               list: [in] The pointer of the control.. 
\param               mainMenuIndex: [in] The index of main menu item. 
\return              bool: True means load success, false means fail.
\note                N/A
*/
		virtual bool OnMainMenuItemLoaded(class IFirstScreenListControl* list, int mainMenuIndex) {return false;};

/*!
\brief               The callback of loading scroll data in main menu.
\remarks             When control need to load scroll data in main menu by sync type, it will notify user by this callback function.
\param               list: [in] The pointer of the control.. 
\param               mainMenuIndex: [in] The index of main menu item. 
\param               scrollDataIndex: [in] The index of scroll data. 
\return              bool: True means load success, false means fail.
\note                N/A
*/
		virtual bool OnScrollListItemLoaded(class IFirstScreenListControl* list, int mainMenuIndex, int scrollDataIndex) { return false; }

/*!
\brief               The callback of loading subMenu data in main menu.
\remarks             When control need to load subMenu data in main menu by sync type, it will notify user by this callback function.
\param               list: [in] The pointer of the control.. 
\param               mainMenuIndex: [in] The index of main menu item. 
\param               subMenuIndex: [in] The index of subMenu data. 
\return              bool: True means load success, false means fail.
\note                N/A
*/
		virtual bool OnSubMenuItemLoaded(class IFirstScreenListControl* list, int mainMenuIndex, int subMenuIndex) {return false;};
	};

	class HALO_API IFirstScreenListControl : virtual public IDataListControl
	{
	public:
		struct TFirstScreenListControlAttr : public TDataListControlAttr
		{
		public:
			TFirstScreenListControlAttr(float width, float height, float inMainTitleWidth, float inMainTitleHeight, float inMainTitleSpace, float inSubTitleWidth, float inSubTitleHeight, float inSubTitleSpace) :
						TDataListControlAttr(width, height), 
						mainTitleWidth(inMainTitleWidth), mainTitleHeight(inMainTitleHeight), mainTitleSpace(inMainTitleSpace), 
						subTitleWidth(inSubTitleWidth), subTitleHeight(inSubTitleHeight), subTitleSpace(inSubTitleSpace){};

			float mainTitleWidth;	//!< The width of mainMenu's title.
			float mainTitleHeight;	//!< The height of mainMenu's title.
			float mainTitleSpace;	//!< The space of mainMenu's title.
			float subTitleWidth;	//!< The width of subMenu's title.
			float subTitleHeight;	//!< The height of subMenu's title.
			float subTitleSpace;	//!< The space of subMenu's title.
		};

/*!
\brief               Create the instance.
\param               parent: [in] The parent actor of the control. 
\param               attr: [in] The attribute of control. 
\return              HALO::IFirstScreenListControl *: The instance of the control.
\note                N/A
*/
		static IFirstScreenListControl* CreateInstance(IActor *parent, const TFirstScreenListControlAttr &attr);

		static IFirstScreenListControl* CreateInstance(Widget *parent, const TFirstScreenListControlAttr &attr);

/*!
\brief               Add the mainMenu items.
\remarks             Every mainMenus can have same size.
\param               itemNum: [in] The number of mainMenu. 
\param               itemSize: [in] The size of mainMenu. 
\param               spaceBetweenItem: [in] The space between two menu. 
\param               itemTitles: The array of menu's title string. 
\return              None
\note                N/A
*/
		virtual void AddMainMenuItem(int itemNum, float itemSize, float spaceBetweenItem, char** itemTitles) = 0;

/*!
\brief               Add the mainMenu items.
\remarks             Different mainMenus can have different sizes.
\param               itemNum: [in] The number of mainMenu. 
\param               itemSize: [in] The size of mainMenu. 
\param               spaceBetweenItem: [in] The space between two menu. 
\param               itemTitles: The array of menu's title string. 
\return              None
\note                N/A
*/
		virtual void AddMainMenuItem(int itemNum, float *itemSize, float spaceBetweenItem, char** itemTitles) = 0;

/*!
\brief               Add subMenu item to a mainMenu.
\param               mainMenuIndex: [in] The mainMenu that subMenu will be added to. 
\param               itemSize: [in] The size of subMenu. 
\param               spaceBetweenItem: [in] The space between sub menu. 
\param               enlargeFocusItemSize: [in] The enlarge size of the focused item. 
\param               titleContent: The string of subMenu's title. 
\return              None
\note                N/A
*/
		virtual void AddSubItem(int mainMenuIndex, float itemSize, float spaceBetweenItem, float enlargeFocusItemSize, const char* titleContent) = 0;

/*!
\brief               Set the number of scrollDatas.
\param               mainMenuIndex: [in] The mainMenu that need to set. 
\param               itemNumber: [in] The number of scrollDatas. 
\return              None
\note                N/A
*/
		virtual void SetScrollItemNumber(int mainMenuIndex, int itemNumber) = 0;

/*!
\brief               Expand one mainMenu.
\remarks             User can call this API to expand a mainMenu.
\param               mainMenuIndex: [in] The mainMenu that need to expand. 
\note                N/A
*/
		virtual void ExpandMainMenu(int mainMenuIndex) = 0;

/*!
\brief               Shrink one mainMenu.
\remarks             User can call this API to shrink a mainMenu.
\param               mainMenuIndex: [in] The mainMenu that need to expand. 
\note                N/A
*/
		virtual void ShrinkMainMenu(int mainMenuIndex) = 0;

/*!
\brief               Set the max margin.
\remarks             The margin define the 
\param               startMargin: [in] The start margin. 
\param               endMargin: [in] The end margin. 
\note                N/A
*/
		virtual void SetMaxMargin(float startMargin, float endMargin) = 0;

/*!
\brief               Add the listListener to control.
\param               listener: [in] The pointer of listener. 
\note                N/A
*/
		virtual void AddListListener(IFirstScreenListListener *listener) = 0;

/*!
\brief               Set the duration of expand animation.
\param               duration: [in] The duration of expand animation. 
\return              None
\note                N/A
*/
		virtual void SetExpandAnimationDuration(int duration) = 0;

/*!
\brief               Set the max scroll speed.
\param               pixPerMillisecond: [in] The max scroll speed. 
\return              None
\note                N/A
*/
		virtual void SetScrollSpeed(float pixPerMillisecond) = 0;

/*!
\brief               Get the dataSource of control.
\remarks             The dataSource is used to store the data pointer.
\return              HALO::IFirstScreenDataSource *: The pointer of dataSource. 
\note                N/A
*/
		virtual IFirstScreenDataSource * DataSource(void) = 0;
	};
}

#endif