#ifndef _HALO_ISLIDER_H_
#define _HALO_ISLIDER_H_

namespace HALO
{
	class HALO_API ISliderListener : public IListener
	{
	public:
		/*!
		\brief               When slider value changed, this function will be called
		\param               slider:[in]      slider subject
		\return              bool: not used
		*/
		virtual bool OnValueChanged(class ISlider* slider) = 0;
	};

	class HALO_API ISlider : virtual public IActor
	{
	public:
		/*!
		\brief               Create a new slider control
		\remarks             The parent is not recommended to NULL.
		\param               parent:[in]      The parent of rectangle.
		\param               width:[in]		  The width of rectangle.
		\param               height:[in]      The height of rectangle.
		\return              HALO::ISlider *: The newly created slider instance pointer.
		\par Example:
		\code
			ISlider* slider = ISlider::CreateInstance(m_window, width, height);		
		\endcode
		\see                 IActor::CreateInstance()
		*/
		static ISlider* CreateInstance(IActor* parent, float width, float height, EDirectionType direction);
		static ISlider* CreateInstance(Widget* parent, float width, float height, EDirectionType direction);

	public:
		/*!
		\brief               Add listener to current slider
		\param               listener:[in]      slider listener
		\return              bool: not used
		*/
		virtual bool AddListener(ISliderListener* listener) = 0;

		/*!
		\brief               Remove slider listener
		\param               listener:[in]      slider listener
		\return              bool: not used
		*/
		virtual bool RemoveListener(ISliderListener* listener) = 0;

	public:
		/*!
		\brief               Set min & max value
		\param               minValue:[in]      min value
		\param               maxValue:[in]      max value
		\return              None
		*/
		virtual void SetMinMaxValue(int minValue, int maxValue) = 0;

		/*!
		\brief               Get min & max value
		\param               minValue:[out]      min value
		\param               maxValue:[out]      max value
		\return              None
		*/
		virtual void GetMinMaxValue(int& minValue, int& maxValue) = 0;

		/*!
		\brief               Get slider value
		\return              int: slider value
		*/
		virtual int Value(void) const = 0;

		/*!
		\brief               Set slider value
		\param               value:[in]      slider value
		\return              None
		*/
		virtual void SetValue(int value) = 0;

		/*!
		\brief               Set thumb image for state
		\param               state:[in]				button state
		\param               imageBuffer:[in]		image buffer
		\return              None
		*/
		virtual void SetThumbImage(IButton::EButtonState state, const std::string& imagePath) = 0;

		// TODO:
		//virtual void SetThumbColor(IButton::EButtonState state, const ClutterColor& color) = 0;
		//virtual const ClutterColor& ThumbColor(IButton::EButtonState state) const = 0;

		/*!
		\brief               Set thumb size
		\param               width:[in]      thumb width
		\param               height:[in]     thumb height
		\return              None
		*/
		virtual void SetThumbSize(float width, float height) = 0;

		/*!
		\brief               Get thumb size
		\param               width:[out]      thumb width
		\param               height:[out]     thumb height
		\return              None
		*/
		virtual void GetThumbSize(float &width, float &height) const = 0;


		/*!
		\brief               Set fill image
		\param               imageBuffer:[in]	image buffer
		\return              None
		*/
		virtual void SetFillImage(IImageBuffer* imageBuffer) = 0;
		//virtual void SetFillColor(const ClutterColor& color) = 0;
		//virtual const ClutterColor& FillColor(void) = 0;

		/*!
		\brief               Set background image
		\param               imageBuffer:[in]      image buffer
		\return              None
		*/
		virtual void SetBackgroundImage(IImageBuffer* imageBuffer) = 0;
	};
}

#endif //_HALO_ISLIDER_H_
