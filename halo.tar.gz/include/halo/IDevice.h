#ifndef _HALO_IDEVICE_H_
#define _HALO_IDEVICE_H_

namespace HALO
{	
	class HALO_API IDevice
	{
	public:
		IDevice(){};
		virtual ~IDevice(){};
	public:
		/*!
		\brief              Get the device type.
		\return             The type number of the device.
		*/
		virtual int DeviceType(void) = 0;

		/*!
		\brief              Get the device id.
		\return             The id number of the device.
		*/
		virtual int DeviceId(void) = 0;

		/*!
		\brief              Get the device name.
		\return             The name of the device.
		*/
		virtual char* DeviceName(void)  = 0;

		/*!
		\brief				Get ClutterInputDevice
		\return				Pointer of ClutterInputDevice
		*/
		virtual ClutterInputDevice* InputDevice(void) = 0;
	};

	class HALO_API IRemoconDevice : virtual public IDevice
	{

	};

	class HALO_API IMouseDevice : virtual public IDevice
	{
	public:
		enum EMouseOption
		{
			OPTION_USER_TYPE = 0, //!< User option Type
			MOUSE_OPTION_MAX,     //!< Other mouse option
		};

		/*!
		\brief               Set the sensibility of mouse pointer.
		\param               level [in] The grade of sensibility. 
		\note                The param level is 1~5 and default is 3.
		*/
		virtual void SetPointerSensibility(int level) = 0;

		/*!
		\brief               Get the sensibility of mouse pointer.
		\return              The grade of sensibility.
		\see                 IMouseDevice::SetPointerSensibility().
		*/
		virtual int PointerSensibility(void) = 0;

		/*!
		\brief               Set the option of the mouse.
		\param               optionType [in] The type of option. 
		\param               optionValue [in] The value of option. 
		*/
		virtual void SetMouseOption(EMouseOption optionType, int optionValue) = 0;

		/*!
		\brief               Get the option of the mouse.
		\param               optionType [in] The type of option. 
		\return              The option of the mouse. 
		\see                 IMouseDevice::SetMouseOption().
		*/
		virtual int MouseOption(int optionType) = 0;

		/*!
		\brief:             Get point from mouse device                     
		\remarks:                            
		\param[out]:		ClutterPoint * point
		\return:			bool:true or false
		*/
		virtual bool GetMousePoint(ClutterPoint* point) = 0;

		/*!
		\brief:             Move mouse cursor by offset
		\remarks:                            
		\param:				long offsetX: offset of x
		\param:				long offsetY: offset of y
		\return:			void   
		*/
		virtual void MoveMousePoint(long offsetX, long offsetY) = 0;
	};

	class HALO_API IKeyboardDevice : virtual public IDevice
	{
	public:
		enum EKeyboardOption
		{
			OPTION_KEYBOARD_TOGGLE_LANG = 0,  //!< The language of keyboard toggle
			KEYBOARD_OPTION_MAX,              //!< Other keyboard option
		};

		/*!
		\brief               Set the keyboard option.
		\param               optionType [in] The type of keyboard option.
		\param               optionValue [in] The value of keyboard option. 
		*/
		virtual void SetKeyboardOption(EKeyboardOption optionType, int optionValue) = 0;

		/*!
		\brief               Get the keyboard option.
		\param               optionType [in] The type of keyboard option. 
		\return              The option of keyboard. 
		\see                 IKeyboardDevice::SetKeyboardOption().
		*/
		virtual int KeyboardOption(int optionType) = 0;
	};

	class HALO_API IMotionDevice : virtual public IDevice
	{

	};

	class HALO_API ITouchDevice : virtual public IDevice
	{
	public:
		enum ETouchMode
		{
			TOUCH_DIRECTION = 0, //!< The Direction of Touch
			TOUCH_POINTING = 1,  //!< The Pointing of Touch
		};

		/*!
		\brief               Set the touch mode.
		\param               touchMode [in] The mode of touch. 
		*/
		virtual void SetTouchMode(ETouchMode touchMode) = 0;

		/*!
		\brief               Get the touch mode.
		\return              The mode of touch.
		\see                 ITouchDevice::SetTouchMode().
		*/
		virtual ETouchMode TouchMode(void) = 0;
	};
	
	class HALO_API ISmartconDevice : virtual public IDevice
	{

	};

}

#endif