#ifndef WIN32

#ifndef _HALO_IAUDIOUI_H_
#define _HALO_IAUDIOUI_H_

namespace HALO
{
	enum CTListStauts
	{
		MOVE_NAVIGATION = 0,
		MOVE_PANEL,
		MOVE_BACK,
		MOVE_NOKEY,
		SELECT,
		CANCEL,
		KEY0,
		KEY1,
		POPUP,
		VOICE_RESPONSE,
		OSK_BACKSPACE,
		OSK_ENTER,
		OSK_KEYPAD,
		OSK_SPACE,
		TAP,
		SIP,
		SIP_BACKSPACE,
	};
	
	class HALO_API IAudioUI : public Instance
	{
	public:
		static IAudioUI* GetInstance(void);
		virtual bool Play(int pattern) = 0;
		
	private:
		static IAudioUI* m_audioUI;
	};
}
			
#endif
#endif
