#ifndef _ISERIALIZABLE_H_
#define _ISERIALIZABLE_H_
namespace HALO
{
	class HALO_API ISerializable
	{
	public:
		virtual char* Serialize(void) = 0;
		virtual bool Deserialize(const char* data) = 0;
	};
}
#endif