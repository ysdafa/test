#ifndef _ILOADING_H_
#define _ILOADING_H_

namespace HALO
{
	class HALO_API ILoading : virtual public IActor
	{
	public:
		struct TLoadingAttr
		{
			int imageNum;				//!< the loading image number.
			float x;					//!< the loading x position.
			float y;					//!< the loading y position.
			float imageWidth;			//!< the image width.
			float imageHeight;			//!< the image height.
			float textWidth;			//!< the text width.
			float textHeight;			//!< the text height.
			int fps;					//!< the frame per second.
			int fontSize;				//!< the text font size.
			int gap;					//!< the gap between image and text.
			const char* text;			//!< the loading text.
			const char* path;			//!< the image path.
			const char* fontName;		//!< the text font name.
			char** name;				//!< the image name.			
			ClutterColor color;			//!< the text color.

			TLoadingAttr() : imageNum(0), x(0), y(0), imageWidth(0.0), imageHeight(0.0), textWidth(0.0), textHeight(0.0), fps(0), fontSize(0), gap(0),
				text(NULL), path(NULL), name(NULL), fontName(NULL)
			{
				clutter_color_init(&color, 125, 125, 125, 0);
			}
		};
	public:
		/*!
		\brief               Create a new loading control.
		\param               parent:[in] The parent of loading control. 
		\param               attr:[in] The loading control attribute. 
		\return              HALO::TLoadingAttr *: A pointer to new loading control.
		*/
		static ILoading* CreateInstance(IActor* parent, const TLoadingAttr &attr);
		static ILoading* CreateInstance(Widget* parent, const TLoadingAttr &attr);
	public:
		/*!
		\brief               Play the loading.
		\return              None
		*/
		virtual void Play() = 0;
		/*!
		\brief               Pause the loading.
		\return              None
		*/
		virtual void Pause() = 0;
		/*!
		\brief               Stop the loading.
		\return              None
		*/
		virtual void Stop( void ) = 0;
		/*!
		\brief               Set the text which will show by warning widget.
		\param               pMessage:[in] The text which will be shown. 
		\return              None
		*/
		virtual void SetText(const std::string& text) = 0;
		//! Get text content.
		virtual std::string Text(void) const = 0;
		/*!
		\brief               Set the text color
		\param               textcolor:[in] The color which will be set by text. 
		\return              None
		*/
		virtual void SetTextColor(const ClutterColor textcolor) = 0;
		/*!
		\brief               Set loading text font
		\param               font:[in] font. Can not be NULL.
		\return              None
		*/
		//! Get text color value.
		virtual const ClutterColor& TextColor(void) = 0;
		virtual void SetTextFont(const std::string& font) = 0;
		/*!
		\brief               Set laoding font size
		\param               size:[in] font size. Should greater than 0.
		\return              None
		*/
		//! Get text font name.
		virtual std::string TextFont(void) const = 0;
		virtual void SetFontSize(int size) = 0;
		//! Get text font size value.
		virtual int FontSize(void) const = 0;
		/*!
		\brief               Set fps
		\param               fps value. 
		\return              None
		*/
		virtual void SetFPS(int fps) = 0;
		//! Get fps
		virtual int FPS(void) const = 0;
		/*!
		\brief               Set gap between image and text
		\param               gap value. 
		\return              None
		*/
		virtual void SetGap(int gap) = 0;
		//! Get gap value
		virtual int Gap(void) const = 0;
	};
}
#endif