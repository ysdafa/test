#ifndef _IINPUTHANDLER_H_
#define _IINPUTHANDLER_H_

namespace HALO
{
	class IFocusable;
	class IInputHandler;

	class IFocusListener: public IListener
	{
	public:
		virtual bool IfFocusIn(IFocusable* pWindow) = 0;
		virtual bool IfFocusOut(IFocusable* pWindow) = 0;
	};

	class IMouseListener: public IListener
	{
	public:
		virtual bool IfMouseButtonPressed(IInputHandler* pWindow, CMouseEvent* ptrMouseEvent) = 0;
		virtual bool IfMouseButtonReleased(IInputHandler* pWindow, CMouseEvent* ptrMouseEvent) = 0;
		virtual bool IfMouseMoved(IInputHandler* pWindow, CMouseEvent* ptrMouseEvent) = 0;
		virtual bool IfMouseWheel(IInputHandler* pWindow, CMouseEvent* ptrMouseEvent) = 0;
		virtual bool IfMouseClicked(IInputHandler* pWindow, CMouseEvent* ptrMouseEvent) = 0;	
		virtual bool IfMousePointerIn(IInputHandler* pWindow, CMouseEvent* ptrMouseEvent) = 0;
		virtual bool IfMousePointerOut(IInputHandler* pWindow, CMouseEvent* ptrMouseEvent) = 0;
	};

	class ITouchListener: public IListener
	{
	public:
		virtual bool IfTouchPressed(IInputHandler* pWindow, CTouchEvent* ptrTouchEvent) = 0;
		virtual bool IfTouchReleased(IInputHandler* pWindow, CTouchEvent* ptrTouchEvent) = 0;
		virtual bool IfTouchMoved(IInputHandler* pWindow, CTouchEvent* ptrTouchEvent) = 0;
		virtual bool IfTouchTap(IInputHandler* pWindow, CTouchEvent* ptrTouchEvent) = 0;
		virtual bool IfTouchFlicked(IInputHandler* pWindow, CTouchEvent* ptrTouchEvent) = 0;
		virtual bool IfTouchPinched(IInputHandler* pWindow, CTouchEvent* ptrTouchEvent) = 0;
		virtual bool IfTouchStretched(IInputHandler* pWindow, CTouchEvent* ptrTouchEvent) = 0;
		virtual bool IfTouchLongPressed(IInputHandler* pWindow, CTouchEvent* ptrTouchEvent) = 0;
	};

	class IKeyboardListener: public IListener
	{
	public:
		virtual bool IfKeyPressed(IInputHandler* pWindow, CKeyboardEvent* ptrKeyboardEvent) = 0;
		virtual bool IfKeyReleased(IInputHandler* pWindow, CKeyboardEvent* ptrKeyboardEvent) = 0;
	};

	class IAudioListener: public IListener
	{
	public:
	//		virtual bool IfAudioEvent(IInputHandler* pWindow, const PTEvent* ptrEvent, void* userData) = 0;
	};

	class IMotionListener: public IListener
	{
	public:
		virtual bool IfMotionTilt(IInputHandler* pWindow, CMotionEvent* pMotionEvent) = 0;
		virtual bool IfMotionRoll(IInputHandler* pWindow, CMotionEvent* pMotionEvent) = 0;
		virtual bool IfMotionPanning(IInputHandler* pWindow, CMotionEvent* pMotionEvent) = 0;
		virtual bool IfMotionSnap(IInputHandler* pWindow, CMotionEvent* pMotionEvent) = 0;
	};

	class IRemoteControlListener: public IListener
	{
	public:
		virtual bool IfKeyPressed(IInputHandler* pWindow, CRemoconEvent* pRemoteControlEvent) = 0;
		virtual bool IfKeyReleased(IInputHandler* pWindow, CRemoconEvent* pRemoteControlEvent) = 0;
		virtual bool IfKeyLongPressed(IInputHandler* pWindow, CRemoconEvent* pRemoteControlEvent) = 0;	
	};

	class IRidgeListener: public IListener
	{
	public:
		virtual bool IfRidgeOn(IInputHandler* pWindow, CRidgeEvent* pRidgeEvent) = 0;
		virtual bool IfRidgeOff(IInputHandler* pWindow, CRidgeEvent* pRidgeEvent) = 0;
		virtual bool IfRidgeMove(IInputHandler* pWindow, CRidgeEvent* pRidgeEvent) = 0;
		virtual bool IfRidgeFlick(IInputHandler* pWindow, CRidgeEvent* pRidgeEvent) = 0;
	};

	class ICursorListener: public IListener
	{
	public:
		virtual bool IfShown(IInputHandler* pApp, CCursorEvent* pCursorEvent) = 0;
		virtual bool IfHidden(IInputHandler* pApp, CCursorEvent* pCursorEvent) = 0;
		virtual bool IfDeviceTypeChanged(IInputHandler* pHandler, CCursorEvent* pCursorEvent) = 0;
	};

	class ISensorListener : public IListener
	{
	public:
		virtual bool IfSensorStart(IInputHandler* pWindow, CSensorEvent* pSensorEvent) = 0;
		virtual bool IfSensorMoved(IInputHandler* pWindow, CSensorEvent* pSensorEvent) = 0;
		virtual bool IfSensorEnd(IInputHandler* pWindow, CSensorEvent* pSensorEvent) = 0;
	};

	class IFocusable
	{
	public:
		virtual bool SetFocus(void) = 0;
		virtual bool FlagFocus(void) = 0;
		virtual bool FlagFocusable(void) = 0;

		//! Add/Remove Focus Listener
		virtual bool AddFocusListener(IFocusListener* pListener) = 0;
		virtual bool RemoveFocusListener(IFocusListener* pListener) = 0;
	};

	class IInputHandler : virtual public IFocusable
	{
	public:
		virtual bool OnEvent(const CInputEvent* pEvent) = 0;
		virtual bool FlagAcceptInput(void) = 0;

		//!Add/Remove mouse listeners
		virtual bool AddMouseListener(IMouseListener* pAddListener) = 0;
		virtual bool RemoveMouseListener(IMouseListener* pRemoveListener) = 0;

		//! Add/Remove Touch Listener
		virtual bool AddTouchListener(ITouchListener* pAddListener) = 0;
		virtual bool RemoveTouchListener(ITouchListener* pRemoveListener) = 0;

		//! Add/Remove Keyboard Listener
		virtual bool AddKeyboardListener(IKeyboardListener* pAddListener) = 0;
		virtual bool RemoveKeyboardListener(IKeyboardListener* pRemoveListener) = 0;

		//! Add/Remove Audio Listener
		virtual bool AddAudioListener(IAudioListener* pAddListener) = 0;
		virtual bool RemoveAudioListener(IAudioListener* pRemoveListener) = 0;

		//! Add/Remove RemoteControl Listener
		virtual bool AddRemoteControlListener(IRemoteControlListener* pAddListener) = 0;
		virtual bool RemoveRemoteControlListener(IRemoteControlListener* pRemoveListener) = 0;

		//! Add/Remove RemoteControl Listener
		virtual bool AddRidgeListener(IRidgeListener* pAddListener) = 0;
		virtual bool RemoveRidgeListener(IRidgeListener* pRemoveListener) = 0;

		//! Add/Remove cursor Listener
		virtual bool AddCursorStateChangeListener(ICursorListener* pAddListener) = 0;
		virtual bool RemoveCursorStateChangeListener(ICursorListener* pRemoveListener) = 0;
	};

}
#endif
