#ifndef _IEVENT_H_
#define _IEVENT_H_

namespace HALO
{
	class IActor;

	typedef enum HALO_API E_FOCUS_TYPE
	{
		EVENT_FOCUSIN = 0,  //!< FocusIn Type 
		EVENT_FOCUSOUT,     //!< FocusOut Type
	}EFocusType;

	typedef enum HALO_API E_DRAG_SIGNAL_TYPE 
	{
		DRAG_BEGIN = 0,	//!< Drag Begin Signal
 		DRAG_END,       //!< Drag End Signal				
		DRAG_MOTION,	//!< Drag Motion Signal
		DRAG_PROGRESS,	//!< Drag Progress Signal
		DRAG_HOLD,      //!< Drag Hold Signal
		DRAG_TYPE_MAX,  //!< Drag Other Signal
	}EDragSignalType;

	typedef enum HALO_API E_GESTURE_SIGNAL_TYPE 
	{
		GESTURE_BEGIN = 0, //!< Gesture Begin Signal		
		GESTURE_END,   	   //!< Gesture End Signal			
		GESTURE_CANCEL,    //!< Gesture Cancel Signal
		GESTURE_PROGRESS,  //!< Gesture Progress Signal
		GESTURE_TYPE_MAX,  //!< Gesture Other Signal
	}EGestureSignalType;

	typedef enum HALO_API E_BUTTON_PRESS_TYPE 
	{
		NONE_PRESS = 0,	   //!<  None Button Press
		LEFT_PRESS,        //!< Mouse Left Button Press		
		SCROLL_PRESS,      //!< Mouse Scroll Button Press		
		RIGHT_PRESS,       //!< Mouse Right Button Press	
		BUTTON_PRESS_MAX,  //!< Mouse Button Press Max
	}EButtonPressType;

	class HALO_API IEvent : public Instance
	{
	public:
		/*!
		\brief              Create an instance of IEvent.
		\return             The new instance pointer. 
		*/
		static IEvent* CreateInstance();

		/*!
		\brief               Clone the event.
		\return              The cloned event instance pointer. 
		\see                 IEvent::CreateInstance()
		*/
		virtual IEvent* Clone(void) = 0;

		/*!
		\brief               Set Receiver to Event.
		\param               actor [in] The Receriver actor. 
		\return              0 express Success, other express Fail.  
		*/
		virtual int SetReceiver(IActor* actor) = 0;

		/*!
		\brief               Get Receiver from Event.
		\return              The receive actor. 
		\see                 IEvent::SetReceiver().
		*/
		virtual IActor* Receiver(void) = 0;

		/*!
		\brief               Set the name of event.
		\param               eventName [in] The name of event.
		*/
		virtual void SetEventType(const char* eventName) = 0;

		/*!
		\brief               Check whether the name of event is event-type.
		\param               eventName [in] The name of event will be checked. 
		\return              true or false.
		\see                 IEvent::SetEventType().
		*/
		virtual bool IsEventType(const char* eventName) = 0;

		/*!
		\brief               Put Key and Int Value into Event.
		\param               key [in] The name of key. 
		\param               value [in] The value corresponding to the key.
		\return              Success or Fail.
		*/
		virtual bool PutInt(const char* key, int value) = 0;

		/*!
		\brief               Put Key and Long Value into Event.
		\param               key [in] The name of key. 
		\param               value [in] The value corresponding to the key.
		\return              Success or Fail.
		*/
		virtual bool PutLong(const char* key, long value) = 0;

		/*!
		\brief               Put Key and Double Value into Event.
		\param               key [in] The name of key. 
		\param               value [in] The value corresponding to the key.
		\return              Success or Fail.
		*/
		virtual bool PutDouble(const char* key, double value) = 0;

		/*!
		\brief               Put Key and Float Value into Event.
		\param               key [in] The name of key. 
		\param               value [in] The value corresponding to the key.
		\return              Success or Fail.
		*/ 
		virtual bool PutFloat(const char* key, float value) = 0;

		/*!
		\brief               Put Key and Char Value into Event.
		\param               key [in] The name of key. 
		\param               value [in] The value corresponding to the key.
		\return              Success or Fail.
		*/ 
		virtual bool PutChar(const char* key, char value) = 0;

		/*!
		\brief               Put Key and String Value into Event.
		\param               key [in] The name of key. 
		\param               value [in] The value corresponding to the key.
		\return              Success or Fail.
		*/ 
		virtual bool PutString(const char* key, const char* value) = 0;

		/*!
		\brief               Put Key and Pointor Value into Event.
		\param               key [in] The name of key. 
		\param               value [in] The pointor corresponding to the key.
		\return              Success or Fail.
		*/ 
		virtual bool PutPointor(const char* key, void* pointor) = 0;

		/*!
		\brief               Get Int Value from Event by Key.
		\param               key [in] The name of key. 
		\param               value [out] The value corresponding to the key .
		\return              Success or Fail.
		\see				 IEvent::PutInt().
		*/ 
		virtual bool GetInt(const char* key, int& value) = 0;

		/*!
		\brief               Get Long Value from Event by Key.
		\param               key [in] The name of key. 
		\param               value [out] The value corresponding to the key .
		\return              Success or Fail.
		\see				 IEvent::PutLong().
		*/ 
		virtual bool GetLong(const char* key, long& value) = 0;

		/*!
		\brief               Get Double Value from Event by Key.
		\param               key [in] The name of key. 
		\param               value [out] The value corresponding to the key .
		\return              Success or Fail.
		\see				 IEvent::PutDouble().
		*/ 
		virtual bool GetDouble(const char* key, double& value) = 0;

		/*!
		\brief               Get Float Value from Event by Key.
		\param               key [in] The name of key. 
		\param               value [out] The value corresponding to the key .
		\return              Success or Fail.
		\see				 IEvent::PutFloat().
		*/ 
		virtual bool GetFloat(const char* key, float& value) = 0;

		/*!
		\brief               Get Char Value from Event by Key.
		\param               key [in] The name of key. 
		\param               value [out] The value corresponding to the key .
		\return              Success or Fail.
		\see				 IEvent::PutChar().
		*/ 
		virtual bool GetChar(const char* key, char& value) = 0;

		/*!
		\brief               Get String Value from Event by Key.
		\param               key [in] The name of key. 
		\param               value [out] The value corresponding to the key .
		\return              Success or Fail.
		\see				 IEvent::PutString().
		*/ 
		virtual bool GetString(const char* key, char** value) = 0;

		/*!
		\brief               Get Pointor Value from Event by key.
		\param               key [in] The name of key. 
		\param               value [out] The value corresponding to the key .
		\return              Success or Fail.
		\see				 IEvent::PutPointor().
		*/ 		
		virtual bool GetPointor(const char* key, void** value) = 0;
	};
	
	class HALO_API IRemoconEvent : virtual public IEvent
	{
	public:
		/*!
		\brief               Create an instance of IRemoceonEvent.
		\return              The new created instance.
		*/
		static IRemoconEvent* CreateInstance(void);
	};
	class HALO_API IMouseEvent : virtual public IEvent
	{
	public:
		/*!
		\brief               Create an instance of IMouseEvent.
		\return              The new created instance.
		*/
		static IMouseEvent* CreateInstance(void);
	public:
		/*!
		\brief               Get the ModifierType.
		\return              The Mouse ModiferType. 
		\see				 IMouseEvent::SetModifierType().
		*/
		virtual  int GetModifierType() const = 0;

		/*!
		\brief               Get the x-coordinate of mouse pointer.
		\return              The value of x-coordinate.
		\see				 IMouseEvent::SetX().
		*/
		virtual float GetX() const = 0;

		/*!
		\brief               Get the y-coordinate of mouse pointer.
		\return              The value of y-coordinate.
		\see				 IMouseEvent::SetY().
		*/
		virtual float GetY() const = 0;

		/*!
		\brief               Set ModifierType of mouse.
		\param				 type [in] The modifier type.
		*/
		virtual void SetModifierType(int type) = 0;

		/*!
		\brief               Set x-coordinate of mouse pointer.
		\param				 x [in] The value of y-coodinate.
		*/
		virtual void SetX(float x) = 0;

		/*!
		\brief               Set y-coordinate of mouse pointer.
		\param				 y [in] The value of y-coodinate.
		*/
		virtual void SetY(float y) = 0;

		/*!
		\brief               Get mouse click count of mouse pointer.
		\return				 Mouse click count.
		*/
		virtual int ClickCount() const = 0;

		/*!
		\brief               Get mouse button press type of mouse pointer.
		\return				 Mouse button press type.
		*/
		virtual EButtonPressType ButtonPressType() const = 0;

		/*!
		\brief               Get scroll direction of mouse pointer.
		\return				 Mouse scroll dierection.
		*/
		virtual ClutterScrollDirection ScrollDirection() const = 0;
	};

	class HALO_API IKeyboardEvent : virtual public IEvent
	{
	public:
		/*!
		\brief               Create an instance of IKeyboardEvent.
		\return              The new created instance. 
		*/
		static IKeyboardEvent* CreateInstance(void);
	public:
		/*!
		\brief               Get Modifier Type from KeyboardEvent.
		\return              The value of modier-type.
		\see                 IKeyboardEvent::SetModifierType().
		*/
		virtual  int GetModifierType(void) const = 0;

		/*!
		\brief               Get Key Value from KeyboardEvent.
		\return              The key-value.
		\see                 IKeyboardEvent::SetKeyVal().
		*/
		virtual  int GetKeyVal(void) const = 0;

		/*!
		\brief               Get Hardware Key Code from KeyboardEvent.
		\return              The Hardware Key Code.
		\see                 IKeyboardEvent::SetHardwareKeyCode().
		*/
		virtual  short GetHardwareKeyCode(void) const = 0;

		/*!
		\brief               Get Unicode Value from KeyboardEvent.
		\return              The value of unicode.
		\see                 IKeyboardEvent::SetUnicodeValue().
		*/
		virtual  int GetUnicodeValue(void) const = 0;
		/*!
		\brief               Get the data of keyCombination-action from KeyboardEvent.
		\return              The value of action-data.
		\see                 IKeyboardEvent::SetKeyComActionData().
		*/
		virtual void* GetKeyComActionData(void) const = 0;

		/*!
		\brief               Set Modifier Type to KeyboardEvent.
		\param               modifierType [in] The value of modifiertype
		*/
		virtual void SetModifierType(int modifierType) = 0;

		/*!
		\brief               Set Key Value to KeyboardEvent.
		\param               keyVal [in] The key-value.
		*/
		virtual void SetKeyVal(int keyVal) = 0;

		/*!
		\brief               Set Hardware Key Code to KeyboardEvent.
		\param               hardwareKeyCode [in] The hardware key code.
		*/
		virtual void SetHardwareKeyCode(short hardwareKeyCode) = 0;

		/*!
		\brief               Set Unicode Value to KeyboardEvent.
		\param               unicodeValue [in] The value of unicode.
		*/
		virtual void SetUnicodeValue(int unicodeValue) = 0;

		/*!
		\brief               Set the data of keyCombination-action to KeyboardEvent.
		\param               data [in] The value of ket-action data.
		*/
		virtual void SetKeyComActionData(void* data) = 0;
	};

	class HALO_API IMotionEvent : virtual public IEvent
	{
	public:
		/*!
		\brief               Create an instance of IMotionEvent.
		\return              The new created instance.
		*/
		static IMotionEvent* CreateInstance(void);
	};

	class HALO_API ITouchEvent : virtual public IEvent
	{
	public:
		/*!
		\brief               Create an instance of ITouchEvent.
		\return              The new created instance.
		*/
		static ITouchEvent* CreateInstance(void);
	};

	class HALO_API IRidgeEvent : virtual public IEvent
	{
	public:
		/*!
		\brief               Create an instance of IRidgeEvent.
		\return              The new created instance.
		*/
		static IRidgeEvent* CreateInstance(void);
	};

	class HALO_API ICursorEvent : virtual public IEvent
	{
	public:
		/*!
		\brief               Create an instance of ICursorEvent.
		\return              The new created instance.
		*/
		static ICursorEvent* CreateInstance(void);
	};

	class HALO_API ISensorEvent : virtual public IEvent
	{
	public:;
		/*!
		\brief               Create an instance of ISensorEvent.
		\return              The new created instance.
		*/
		static ISensorEvent* CreateInstance(void);
	};

	class HALO_API IClickEvent : virtual public IEvent
	{
	public:
		/*!
		\brief               Create an instance of IClickEvent.
		\return              The new created instance.
		*/
		static IClickEvent* CreateInstance(void);
	};

	class HALO_API ILongPressEvent : virtual public IEvent
	{
	public:
		/*!
		\brief               Create an instance of ILongPressEvent.
		\return              The new created instance.
		*/
		static ILongPressEvent* CreateInstance(void);
	};

	//! Drag event
	class HALO_API IDragEvent : virtual public IEvent
	{
	public:
		/*!
		\brief               Create an instance of IDragEvent.
		\return              The new created instance.
		*/
		static IDragEvent* CreateInstance(void);
	public:
		/*!
		\brief               Get the drag signal type.
		\return              The signal type of drag-action.
		\see                 HALO::EDragSignalType.
		*/
		virtual EDragSignalType DragSignalType() = 0;

		/*!
		\brief               Get the press coords.
		\param               press_x [out] The press_x coordinate. 
		\param               press_y [out] The press_y coordinate. 
		*/
		virtual void PressCoords(float *press_x, float *press_y) = 0;

		/*!
		\brief               Get the motion coords.
		\param               motion_x [out] The motion_x coordinate. 
		\param               motion_y [out] The motion_y coordinate. 
		*/
		virtual void MotionCoords(float *motion_x, float *motion_y) = 0;

		/*!
		\brief               Retrieves the incremental delta since the last motion event during the dragging..
		\param               delta_x [out] The delta_x coordinate. 
		\param               delta_y [out] The delta_y coordinate. 
		*/
		virtual void MotionDelta(float *delta_x, float * delta_y) = 0;
	}; //! Drag event end

	//! Gesture event
	class HALO_API IGestureEvent : virtual public IEvent
	{
	public:
		/*!
		\brief               Create an instance of IGestureEvent.
		\return              The new created instance.
		*/
		static IGestureEvent* CreateInstance(void);
	public:
		/*!
		\brief               Get the gesture signal type.
		\return              The gesture signal type.
		\see                 HALO::EGestureSignalType.
		*/
		virtual EGestureSignalType GestureSignalType() = 0;

		/*!
		\brief               Retrieves the threshold trigger distance of the gesture action.
		\param               x [out] The x-coordinate of Distance. 
		\param               y [out] The y-coordinate of Distance. 
		*/
		virtual void ThresholdTriggerDistance(float *x, float *y) = 0;

		/*!
		\brief               Retrieves the number of requested points to trigger the gesture.
		\return              The number of requested points.
		*/
		virtual int TouchPoints() = 0;

		/*!
		\brief               Retrieves the number of points currently active.
		\return              The number of points currently active. 
		*/
		virtual int CurrentPoints() = 0;

	}; // !Gesture event end

	class HALO_API ISystemEvent : virtual public IEvent
	{
	public:
		/*!
		\brief               Create an instance of ISystemEvent.
		\return              The new created instance.
		*/
		static ISystemEvent* CreateInstance(void);
	};

	class HALO_API ICustomEvent : virtual public IEvent
	{
	public:
		/*!
		\brief               Create an instance of ICustomEvent.
		\return              The new created instance.
		*/
		static ICustomEvent* CreateInstance(void);

		/*!
		\brief               Set the event type;
		\param               eventType [in] The value of event type. 
		*/
		virtual void SetEventType(int eventType) = 0;

		/*!
		\brief               Set the event type;
		\param               eventName [in] The name of event. 
		*/		
		virtual void SetEventType(const char* eventName) = 0;
		/*virtual bool IsEventType(const char* eventName) = 0;		*/
	};

	class HALO_API IFocusEvent: virtual public IEvent
	{
	public:
		/*!
		\brief               Create an instance of IFocusEvent.
		\return              The new created instance.
		*/
		static IFocusEvent* CreateInstance(void);
	};
}
#endif
