#ifndef _HALO_ILABEL_H_
#define _HALO_ILABEL_H_

namespace HALO
{
	class HALO_API ILabel : virtual public IActor
	{
	public:
		/*!
		\brief               Create a new label
		\remarks             The parent is not recommended to NULL.
		\param               parent:[in]      The parent of rectangle.
		\param               width:[in]		  The width of rectangle.
		\param               height:[in]      The height of rectangle.
		\return              HALO::ILabel *: The newly created label instance pointer.
		\par Example:
		\code
			ILabel* label = ILabel::CreateInstance(m_window, width, height);	
		\endcode
		\see                 IActor::CreateInstance()
		*/
		static ILabel* CreateInstance(IActor* parent, float width, float height);
		static ILabel* CreateInstance(Widget* parent, float width, float height);

	public:
		/*!
		\brief               Set image buffer for label
		\param               imageBuffer:[in]      image buffer. Can not be NULL.
		\return              None
		*/
		virtual void SetImage(IImageBuffer* imageBuffer) = 0;

		/*!
		\brief               Set text for label
		\param               text:[in]     label text. Can not be NULL.
		\return              None
		*/
		virtual void SetText(const char* text) = 0;

		/*!
		\brief               Get label text
		\return              const char *: label text
		*/
		virtual const char* Text(void) const = 0;

		/*!
		\brief               Set text color for label
		\param               color:[in]      label text color
		\return              None
		*/
		virtual void SetTextColor(const ClutterColor& color) = 0;

		/*!
		\brief               Get label text color
		\return              const ClutterColor &: label text color
		*/
		virtual const ClutterColor& TextColor(void) = 0;

		/*!
		\brief               Set label text font
		\param               font:[in] label font. Can not be NULL.
		\return              None
		*/
		virtual void SetTextFont(const char* font) = 0;

		/*!
		\brief               Get label text font
		\return              const char *: label text font.
		*/
		virtual const char* TextFont(void) const = 0;

		/*!
		\brief               Set label font size
		\param               size:[in] font size. Should greater than 0.
		\return              None
		*/
		virtual void SetFontSize(int size) = 0;

		/*!
		\brief               Get label font size
		\return              int: label font size
		*/
		virtual int FontSize(void) const = 0;


		virtual void EnableMultiLine(bool flagMutliLineMode) = 0;

		//! Get text single-line or multi-line state.
		virtual bool IsMultiLineEnabled(void) = 0;

		/*!
		\brief               Get label text actor
		\return              HALO::IText *: label text actor.
		*/
		virtual IText* TextActor(void) = 0;

		/*!
		\brief               Get label image actor
		\return              HALO::IImage *: label image actor
		*/
		virtual IImage* ImageActor(void) = 0;
	};
}

#endif	//_HALO_IIMAGE_H_