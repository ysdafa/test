#ifndef _ICHECKBOX_GROUP_H_
#define _ICHECKBOX_GROUP_H_

namespace HALO
{
	class HALO_API ICheckBoxGroup :  virtual public ISelectButtonGroup
	{
	public:
		static ICheckBoxGroup* CreateInstance(IActor* parent , float groupW, float groupH);
	};
}
#endif