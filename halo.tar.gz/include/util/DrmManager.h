#pragma once

#include <stdint.h>
#include <string>

#if defined(BUILD_FOR_TV)
#if defined(GOLFP) || defined(X14) || defined(NT14U)
#include <memory>
#include "AppDrmDecryptor.h"
#endif
#endif

class DrmManager
{
  public:
    static DrmManager& Instance();
    virtual ~DrmManager ();

    bool LoadLicense(const std::string &aLicPath);

    bool LicenseLoaded() const;

    bool DecryptFile(const std::string &aPath,
                     unsigned char * &aData, int &aSize);

  private:
    DrmManager ();

  private:
    bool license_loaded_;

#if defined(BUILD_FOR_TV)
#if defined(GOLFP) || defined(X14) || defined(NT14U)
    std::unique_ptr<appdrm::AppDrmDecryptor> decryptor_;
#elif defined(TIZEN)
    /* Is int the right data type for the handle??
     * appdrm_* api's expects a void*, not sure if this is correct...
     * but o well, let's just do the same thing as the sample given by the HQ
     * folks. */
    int license_handle_;
#endif
#endif
};
