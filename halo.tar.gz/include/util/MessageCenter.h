#ifndef MESSAGE_CENTER_H
#define MESSAGE_CENTER_H

#include <memory>
#include <deque>
#include <map>
#include <thread>
#include <mutex>

#include <boost/interprocess/managed_shared_memory.hpp>
#include <boost/interprocess/mapped_region.hpp>
#include <boost/interprocess/sync/interprocess_mutex.hpp>
#include <boost/interprocess/sync/interprocess_condition.hpp>
#include <boost/interprocess/containers/deque.hpp>
#include <boost/interprocess/containers/string.hpp>
#include <boost/interprocess/containers/vector.hpp>

#include "MessageTypes.h"
#include "logger.h"

#ifdef SAMPLE_IPC
#include "time_util.h"
#endif

namespace volt
{
namespace util
{
namespace ipc
{

class MessageCenter
{
  public:
    static volt::util::Logger LOGGER;

    /**
     * Handler to be called when a message is received.
     * The first argument is the message received.
     */
    typedef std::function<void (Message *)> MessageHandler;
    /**
     * Handler to be called when a command result is received.
     * The first argument is the result of a command set by the receiver.
     */
    typedef std::function<void (void *, const size_t)> ResultHandler;

    /**
     * Handle that can be shared among multiple processes to reference an
     * address on a shared memory.
     */
    typedef boost::interprocess::managed_shared_memory::handle_t SharedHandle;

  public:
    /**
     * Prepare the singleton instance.
     * This MUST be called before calling any other methods.
     */
    static void PrepareInstance();

    static MessageCenter& Instance();
    virtual ~MessageCenter();

    /**
     * Initialize internal data structures.
     * This will clear the previously created state (specifically the shared
     * memory).
     * When the MessageCenter is deallocated, the shared memory is removed.
     *
     * The size should be chosen carefully to match the application
     * requirements.
     *
     * @param[in] aName Name of this MessageCenter object.  The same name is
     *                  used to create shared memory.
     * @param[in] aSize Size of the shared memory to be allocated.
     *
     * @return true if success, false otherwise.
     */
    bool Initialize(const std::string aName, const size_t aSize = 0);

    /**
     * Attach to an existing MessageCenter.
     * The shared memory will NOT be removed by this instance.
     *
     * @param[in] aName Name of this MessageCenter object.  The same name is
     *                  used to create shared memory.
     *
     * @return true if success, false otherwise.
     */
    bool Attach(const std::string aName);

    /**
     * Destroy and reset the internal data structures.
     *
     * @param[in] aForce Remove shared memory if true, otherwise the shared
     *                   memory is removed only if it was created by this
     *                   object.
     */
    void Destroy(const bool aForce = false);

    /**
     * Get the page size of this system.
     *
     * @return Page size.
     */
    size_t PageSize() const;

    /**
     * Templatized function to allocate/create a new data on the shared memory.
     */
    template <typename Type>
    Type* CreateObject()
    {
      //std::lock_guard<std::mutex> lock(segment_mutex_);
      try
      {
        size_t before = segment_.get_free_memory();

        Type *ret = segment_.construct<Type>(boost::interprocess::anonymous_instance)();

        size_t after = segment_.get_free_memory();
        LOG_TRACE(LOGGER, "Created object " << ret << " of " << sizeof(Type) <<
                  " bytes (actually used " << (before - after) << "); " <<
                  segment_.get_free_memory() << "/" <<
                  segment_.get_size() << " free");
        return ret;
      }
      catch (boost::interprocess::bad_alloc &e)
      {
        LOG_FATAL(LOGGER, "Failed to create object of " << sizeof(Type) <<
                  " bytes; " << segment_.get_free_memory() << "/" <<
                  segment_.get_size() << " free");

#if 0 /* can't grow unless all processes unmaps the memory region... */
        LOG_FATAL(LOGGER, "Try to grow shm size");

        if (segment_.grow(shm_name_.c_str(), PageSize()))
        {
          LOG_FATAL(LOGGER, "Grew the shm to " << segment_.get_size() <<
                    "; " << segment_.get_free_memory() << " free");
          return CreateObject<Type>();
        }
        else
        {
          LOG_FATAL(LOGGER, "Failed to grow shm size");
          return NULL;
        }

#else
        return NULL;
#endif
      }
    }

    /**
     * Destroy a objects created on the shared memory.
     *
     * @param[in] aPtr Pointer to the data to be destroyed.
     */
    template <typename Type>
    void DestroyObject(Type *aPtr)
    {
      //std::lock_guard<std::mutex> lock(segment_mutex_);
      size_t before = segment_.get_free_memory();

      segment_.destroy_ptr(aPtr);

      size_t after = segment_.get_free_memory();
      LOG_TRACE(LOGGER, "Destroyed object of " << sizeof(Type) <<
                " bytes (actually free'd " << (after - before) << "); " <<
                segment_.get_free_memory() << "/" <<
                segment_.get_size() << " free");
    }

    template <typename Type>
    void DestroyNamedObject(const std::string &aName)
    {
      //std::lock_guard<std::mutex> lock(segment_mutex_);
      size_t before = segment_.get_free_memory();

      segment_.destroy<Type>(aName.c_str());

      size_t after = segment_.get_free_memory();
      LOG_TRACE(LOGGER, "Destroyed object (" << aName << " ) of " << sizeof(Type) <<
                " bytes (actually free'd " << (after - before) << "); " <<
                segment_.get_free_memory() << "/" <<
                segment_.get_size() << " free");
    }

    /**
     * Create a new message queue on the shared memory.
     *
     * @param[in] aQueueName Name of the new queue to be created.
     *
     * @return true on success, false otherwise.
     */
    bool CreateNamedQueue(const std::string aQueueName,
                          const size_t aSize = 10000);

    /**
     * Destroy a queue queue with the given name.
     * It is important to call this method for unused queues.
     *
     * @param[in] aQueueName Name of the queue to be destroyed.
     * @return true on success, false otherwise.
     */
    bool DestroyNamedQueue(const std::string aQueueName);

    /**
     * Post a message on the specified queue.
     *
     * @param[in] aQueueName Name of the queue to post this message.
     * @param[in] aType Type of the message to be posted.
     *
     * @return true on success, false otherwise.
     */
    bool PostMessage(const std::string aQueueName,
                     MessageType aType);

    /**
     * Post a message on the specified queue with an associated data.
     * The given data will be copied onto the shared memory.
     * The data given should be "flat" (no complex data types that require
     * dynamic memory allocation).
     *
     * @param[in] aQueueName Name of the queue to post this message.
     * @param[in] aType Type of the message to be posted.
     * @param[in] aData Pointer to the local memory space holding the data to
     *                  be posted.
     * @param[in] aSize Size of the data.
     *
     * @return true on success, false otherwise.
     */
    bool PostMessage(const std::string aQueueName,
                     MessageType aType,
                     void *aData, const size_t aSize);

    /**
     * Post a message on the specified queue with timeout.
     *
     * @param[in] aQueueName Name of the queue to post this message.
     * @param[in] aMaxWaitTime Maximum time in milli-seconds allowed to post
     *                         the given message. (0 == nonblocking, -1 ==
     *                         block indefinitely)
     * @param[in] aType Type of the message to be posted.
     *
     * @return true on success, false otherwise (eg failed to post in the
     *         allowed time).
     */
    bool PostMessage(const std::string aQueueName,
                     const int aMaxWaitTime,
                     MessageType aType);

    /**
     * Post a message on the specified queue with an associated data and with
     * timeout..
     * The given data will be copied onto the shared memory.
     * The data given should be "flat" (no complex data types that require
     * dynamic memory allocation).
     *
     * @param[in] aQueueName Name of the queue to post this message.
     * @param[in] aMaxWaitTime Maximum time in milli-seconds allowed to post
     *                         the given message. (0 == nonblocking, -1 ==
     *                         block indefinitely)
     * @param[in] aType Type of the message to be posted.
     * @param[in] aData Pointer to the local memory space holding the data to
     *                  be posted.
     * @param[in] aSize Size of the data.
     *
     * @return true on success, false otherwise.
     */
    bool PostMessage(const std::string aQueueName,
                     const int aMaxWaitTime,
                     MessageType aType,
                     void *aData, const size_t aSize);

    bool PostMessage(const std::string aQueueName,
                     const int aMaxWaitTime,
                     const std::string aReplyTo,
                     MessageType aType,
                     void *aData, const size_t aSize);

    /**
     * Execute a command on the specified queue.
     * The function will block until the result is set by the receiver.
     *
     * @param[in] aQueueName Name of the queue to post this message.
     * @param[in] aType Type of the message to be posted.
     * @param[in] aHandler ResultHandler to be called when the result is set
     *                     by the reciever.
     *
     * @return true on success, false otherwise.
     */
    bool ExecuteCommand(const std::string aQueueName,
                        MessageType aType, ResultHandler aHandler);

    /**
     * Execute a command on the specified queue with an associated data.
     * The function will block until the result is set by the receiver.
     * The given data will be copied onto the shared memory.
     * The data given should be "flat" (no complex data types that require
     * dynamic memory allocation).
     *
     * @param[in] aQueueName Name of the queue to post this message.
     * @param[in] aType Type of the message to be posted.
     * @param[in] aHandler ResultHandler to be called when the result is set
     *                     by the reciever.
     * @param[in] aData Pointer to the local memory space holding the data to
     *                  be posted.
     * @param[in] aSize Size of the data.
     *
     * @return true on success, false otherwise.
     */
    bool ExecuteCommand(const std::string aQueueName,
                        MessageType aType, ResultHandler aHandler,
                        void *aData, const size_t aSize);

    /**
     * Execute a command on the specified queue with timeout..
     * The function will block until the result is set by the receiver or the
     * aMaxWaitTime is reached.
     *
     * @param[in] aQueueName Name of the queue to post this message.
     * @param[in] aMaxWaitTime Maximum time in milli-seconds allowed to
     *                         execute the given message. (0 == nonblocking,
     *                         -1 == block indefinitely)
     * @param[in] aType Type of the message to be posted.
     * @param[in] aHandler ResultHandler to be called when the result is set
     *                     by the reciever.
     *
     * @return true on success, false otherwise.
     */
    bool ExecuteCommand(const std::string aQueueName, const int aMaxWaitTime,
                        MessageType aType, ResultHandler aHandler);

    /**
     * Execute a command on the specified queue with an associated data and with
     * timeout..
     * The function will block until the result is set by the receiver or the
     * aMaxWaitTime is reached.
     * The given data will be copied onto the shared memory.
     * The data given should be "flat" (no complex data types that require
     * dynamic memory allocation).
     *
     * @param[in] aQueueName Name of the queue to post this message.
     * @param[in] aMaxWaitTime Maximum time in milli-seconds allowed to
     *                         execute the given message. (0 == nonblocking,
     *                         -1 == block indefinitely)
     * @param[in] aType Type of the message to be posted.
     * @param[in] aHandler ResultHandler to be called when the result is set
     *                     by the reciever.
     * @param[in] aData Pointer to the local memory space holding the data to
     *                  be posted.
     * @param[in] aSize Size of the data.
     *
     * @return true on success, false otherwise.
     */
    bool ExecuteCommand(const std::string aQueueName, const int aMaxWaitTime,
                        MessageType aType, ResultHandler aHandler,
                        void *aData, const size_t aSize);

    bool ExecuteCommand(const std::string aQueueName, const int aMaxWaitTime,
                        const std::string aReplyTo,
                        MessageType aType, ResultHandler aHandler,
                        void *aData, const size_t aSize);

    /**
     * Get the next message from the specified queue.
     *
     * @param[in] aQueueName Name of the queue to receive message from.
     *
     * @return The received Message object, NULL on error.
     */
    Message* GetMessage(const std::string aQueueName);

    /**
     * Get the next message from the specified queue.
     *
     * @param[in] aQueueName Name of the queue to receive message from.
     * @param[in] aMaxWaitTime Maximum time in milli-seconds allowed to
     *                         wait for the next message. (0 == nonblocking,
     *                         -1 == block indefinitely)
     *
     * @return The received Message object, NULL on error.
     */
    Message* GetMessage(const std::string aQueueName, const int aMaxWaitTime);

    bool GetMessages(std::vector<Message *> &aMessages,
                     const std::string aQueueName);
    bool GetMessages(std::vector<Message *> &aMessages,
                     const std::string aQueueName, const int aMaxWaitTime);

    /**
     * Block until all pending messages have been received.
     * @param[in] aQueueName Name of the queue to flush.
     * @param[in] aMaxWaitTime Maximum time in milli-seconds allowed to
     *                         flush messages. (0 == nonblocking,
     *                         -1 == block indefinitely)
     */
    bool FlushMessages(const std::string aQueueName,
                       const int aMaxWaitTime = -1);

    /**
     * Register the default handler for incoming messages on the specified
     * queue.
     *
     * Message handlers are searched in the following order.
     *   1. Handler matching the received MessageType.
     *   2. Handler matching the received MessageGroup.
     *   3. Default handler.
     *
     * @param[in] aQueueName Name of the queue to register handler on.
     * @param[in] aHandler MessageHandler to be called.
     */
    void RegisterHandler(const std::string aQueueName,
                         MessageHandler aHandler);

    /**
     * Register a handler for incoming messages in the speicified message
     * group on the specified queue.
     *
     * Message handlers are searched in the following order.
     *   1. Handler matching the received MessageType.
     *   2. Handler matching the received MessageGroup.
     *   3. Default handler.
     *
     * @param[in] aQueueName Name of the queue to register handler on.
     * @param[in] aGroup MessageGroup of interest.
     * @param[in] aHandler MessageHandler to be called.
     */
    void RegisterHandler(const std::string aQueueName,
                         const MessageGroup aGroup,
                         MessageHandler aHandler);

    /**
     * Register a handler for incoming messages of the specified message type
     * on the specified queue.
     *
     * Message handlers are searched in the following order.
     *   1. Handler matching the received MessageType.
     *   2. Handler matching the received MessageGroup.
     *   3. Default handler.
     *
     * @param[in] aQueueName Name of the queue to register handler on.
     * @param[in] aType MessageType of interest.
     * @param[in] aHandler MessageHandler to be called.
     */
    void RegisterHandler(const std::string aQueueName,
                         const MessageType aType,
                         MessageHandler aHandler);

    /**
     * Helper function to start the main loop to start receiving incoming
     * messages and commands on the specified queue.
     * This function will not return until StopMainLoop is called on the
     * queue.
     *
     * @param[in] aQueueName Name of the queue to start checking for incoming
     *                       messages.
     */
    void StartMainLoop(const std::string aQueueName);

    /**
     * Stop the main loop running on the specified queue.
     *
     * @param[in] aQueueName Name of the queue to stop the main loop on.
     */
    void StopMainLoop(const std::string aQueueName);

    /**
     * Stop main loops running on all queues.
     */
    void StopMainLoops();

    /**
     * Create and run a thread to start the main loop on the specified queue.
     *
     * @param[in] aQueueName Name of the queue to start the main loop on.
     */
    void StartMainLoopThread(const std::string aQueueName);

    /**
     * Join the thread running the main loop on the specified queue.
     * This function will block until the join completes/fails.
     */
    void JoinMainLoopThread(const std::string aQueueName);

    /**
     * Join all the main loop threads.
     */
    void JoinMainLoopThreads();

  protected:
    typedef boost::interprocess::managed_shared_memory ManagedSharedMemory;
    typedef ManagedSharedMemory::segment_manager SegmentManager;

    typedef boost::interprocess::allocator<void, SegmentManager> VoidAlloc;

    typedef ManagedSharedMemory::handle_t MessageHandle;
    typedef boost::interprocess::allocator<MessageHandle, SegmentManager> MessageHandleAlloc;

    const MessageHandleAlloc& GetMessageHandleAlloc() const;
    ManagedSharedMemory& GetManagedSharedMemory();

    /**
     * Message queue to be constructed on a shared memory.
     */
    class SharedQueue
    {
      public:
        SharedQueue(const std::string aName,
                    MessageCenter &aMC, const size_t aSize);
        ~SharedQueue();

        bool Push(Message *aMsg, const int aMaxWaitTime = -1);

        bool Pop(Message *&aMsg, const int aMaxWaitTime = -1);
        bool Pop(std::vector<Message *> &aMsgs, const int aMaxWaitTime = -1);

        bool Flush(const int aMaxWaitTime = -1);

        void Clear();

        void Destroy();

        static SharedQueue* FindQueue(const std::string &aName, MessageCenter &aMC);

      private:
        size_t Size() const;

        size_t MaxSize() const;

        bool Empty() const;

        bool Full() const;

        bool DoPush(MessageHandle aHandle);
        bool DoPop(MessageHandle &aHandle);
        bool DoPop(std::vector<Message *> &aMsgs);

      private:
        struct SharedQueuePrivate
        {
          SharedQueuePrivate(MessageCenter &aMC, const size_t aSize):
            mutex_(), cond_consumed_(), cond_produced_(),
            queue_(aSize, 0, aMC.GetMessageHandleAlloc()),
            max_num_msg_(aSize), head_(0), num_msg_(0)
          {
          }

          ~SharedQueuePrivate()
          {
          }

          boost::interprocess::interprocess_mutex mutex_;
          boost::interprocess::interprocess_condition cond_consumed_;
          boost::interprocess::interprocess_condition cond_produced_;

          typedef boost::interprocess::vector<MessageHandle, MessageHandleAlloc> MessageQueue;
          MessageQueue queue_;

          size_t max_num_msg_;
          size_t head_;
          size_t num_msg_;
        };

        SharedQueue(const std::string aName,
                    MessageCenter &aMC, SharedQueuePrivate *aPrivateQueue);

      private:
        std::string name_;

        MessageCenter &mc_;

        SharedQueuePrivate *shared_;
    };

    static void SharedQueueDeleter(SharedQueue *aObj)
    {
      /* Should probably be using destroy or destroy_ptr but it'd crash if the
       * queue is used by another process.
       * Not destroying the pointer as its lifetime is the same as that of the
       * shared memory. */
    };

    typedef boost::interprocess::allocator<SharedQueue, SegmentManager> SharedQueueAlloc;
    typedef std::shared_ptr<SharedQueue> SharedQueuePtr;

    /**
     * Struct to group different types of queues (shared, prefetch).
     */
    class QueueSet
    {
      public:
        QueueSet():
          name(), shared(), prefetch(),
          default_handler(), message_handlers(), group_handlers()
        {}
        QueueSet(SharedQueuePtr aShared):
          name(), shared(aShared), prefetch(),
          default_handler(), message_handlers(), group_handlers()
        {}
        QueueSet(const QueueSet &aSrc):
          name(), shared(), prefetch(),
          default_handler(), message_handlers(), group_handlers()
        {
          *this = aSrc;
        }

        QueueSet& operator=(const QueueSet &aRhs)
        {
          if (this == &aRhs)
          {
            return *this;
          }

          name = aRhs.name;
          shared = aRhs.shared;
          prefetch = aRhs.prefetch;
          default_handler = aRhs.default_handler;
          message_handlers = aRhs.message_handlers;
          group_handlers = aRhs.group_handlers;
          return *this;
        }

        std::string name;

        /** Shared queue on a shared memory. */
        SharedQueuePtr shared;
        /** Queue to hold prefetched messages. */
        std::deque<Message *> prefetch;

        typedef std::map<MessageType, MessageHandler> HandlerMap;
        typedef std::pair<MessageType, MessageHandler> HandlerMapValue;
        typedef std::map<MessageGroup, MessageHandler> GroupHandlerMap;
        typedef std::pair<MessageGroup, MessageHandler> GroupHandlerMapValue;

        /** Default handler for this queue. */
        MessageHandler default_handler;
        /** Handlers for various MessageType's. */
        HandlerMap message_handlers;
        /** Handlers for various MessageGroup's. */
        GroupHandlerMap group_handlers;
    };
    typedef std::shared_ptr<QueueSet> QueueSetPtr;

    struct DeallocSignal
    {
      DeallocSignal():
        mutex(), cond_deallocd()
      {
      }

      ~DeallocSignal()
      {
      }

      boost::interprocess::interprocess_mutex mutex;
      boost::interprocess::interprocess_condition cond_deallocd;
    };

  protected:
    friend class Message;
    friend class Command;

    MessageCenter();

    Message* CreateMessage(const int aMaxWaitTime = -1);
    Command* CreateCommand(const int aMaxWaitTime = -1);

    void DestroyMessage(Message *aMsg);

    SharedQueuePtr CreateQueue(const std::string aQueueName,
                               const size_t aSize);

    QueueSetPtr GetQueue(const std::string &aQueueName);

    /**
     * Create a copy of the given data on the shared memory.
     *
     * @param[in] aData Data to make a copy of.
     * @param[in] aSize Size of the data.
     *
     * @return Pointer to the shared memory region containing the copied data,
     *         NULL on failure.
     */
    void* CreateSharedData(const void *aData, const size_t aSize,
                           const int aMaxWaitTime = -1);

    /**
     * Destroy the data created using CreateSharedData.
     *
     * @param[in] aPtr Pointer to the data to be destroyed.
     */
    void DestroyPtr(void *aPtr);

    /**
     * Get a handle for the memory address on the shared memory.
     * The returned handle can be used by any process to get the address valid
     * on each process to refer to the same memory address.
     *
     * @param[in] aLocalAddr Address valid on the current process.
     *
     * @return SharedHandle that can be used by any process attached to the
     *         same shared memory.
     */
    SharedHandle GetSharedHandle(void *aLocalAddr);

    /**
     * Get the address valid on the current process from the given handle.
     * The returned address would point to the same memory region that created
     * the given handle.
     *
     * @param[in] aHandle SharedHandle returned by GetSharedHandle.
     *
     * @return Pointer to the shared memory.
     */
    void* GetLocalAddr(const SharedHandle aHandle);


    bool PostMessageWithTimeout(QueueSetPtr aQueueSet, Message *aMsg,
                                const int aMaxWaitTime);

    virtual void CallMessageHandler(MessageHandler aHandler, Message *aMsg);

    bool WaitForFreeMemory(const size_t aSize, const int aMaxWaitTime = -1);

  protected:
    static MessageCenter *singleton_;
    std::string shm_name_;
    std::mutex segment_mutex_;
    ManagedSharedMemory segment_;
    std::unique_ptr<MessageHandleAlloc> msg_handle_alloc_;
    bool remove_shm_;

    std::map<std::string, QueueSetPtr> queues_;

    typedef std::map<std::string, std::thread> MainLoopThreadMap;
    MainLoopThreadMap main_loop_threads_;

    DeallocSignal *dealloc_signal_;

#ifdef SAMPLE_IPC
    unsigned int post_samples_;
    volt::util::Stopwatch post_samples_timer_;
    unsigned int exec_samples_;
    volt::util::Stopwatch exec_samples_timer_;

    volt::util::Stopwatch result_handler_timer_;
#endif
};

}; /* namespace ipc */
}; /* namespace util */
}; /* namespace volt */

#endif
