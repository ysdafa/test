#ifndef VOLT_UTIL_MACROS_H
#define VOLT_UTIL_MACROS_H

/**
 * This is a utility macro to define a class property.
 * The property will be of the specified data type and the accessor/mutator
 * methods will be named name()/set_name(const type) respectively.
 */
#define PROPERTY(type, name) \
  PROPERTY_GETTER(type, name) \
  PROPERTY_SETTER(type, name) \
  PROPERTY_VARIABLE(type, name)

#define PROPERTY_CONST(type, name) \
  PROPERTY_GETTER_CONST(type, name) \
  PROPERTY_SETTER(type, name) \
  PROPERTY_VARIABLE(type, name)

/**
 * This is a utility macro to define a class property pointer.
 * The property will be a pointer to the specified data type and the accessor/mutator
 * methods will be named name()/set_name(const type) respectively.
 *
 * This is identical to the PROPERTY macro except that this will define
 * pointers to the type specified.  If PROPERTY is used for pointers you may
 * have const related compiler errors.
 */

#define PROPERTY_PTR(type, name) \
  PROPERTY_PTR_GETTER(type, name) \
  PROPERTY_PTR_SETTER(type, name) \
  PROPERTY_PTR_VARIABLE(type, name)

#define PROPERTY_PTR_CONST(type, name) \
  PROPERTY_PTR_GETTER_CONST(type, name) \
  PROPERTY_PTR_SETTER(type, name) \
  PROPERTY_PTR_VARIABLE(type, name)

/**
 * This is a utility macro to define a class property.
 * The property will be of the specified data type and the accessor/mutator
 * methods will be named name()/set_name(const type) respectively.
 *
 * This is identical to the PROPERTY macro except that this will use
 * references for accessor/mutator methods.  This would be the prefered way of
 * defining properties of complex type (where copying may be expensive).
 */
#define PROPERTY_REF(type, name) \
  PROPERTY_GETTER_REF(type, name) \
  PROPERTY_SETTER_REF(type, name) \
  PROPERTY_VARIABLE(type, name)

#define PROPERTY_CONST_REF(type, name) \
  PROPERTY_GETTER_CONST_REF(type, name) \
  PROPERTY_SETTER_REF(type, name) \
  PROPERTY_VARIABLE(type, name)

/**
 * This is a utility macro to define a read-only property.
 */
#define PROPERTY_RO(type, name) \
  PROPERTY_GETTER(type, name) \
  PROPERTY_VARIABLE(type, name)

#define PROPERTY_CONST_RO(type, name) \
  PROPERTY_GETTER_CONST(type, name) \
  PROPERTY_VARIABLE(type, name)

/**
 * This is a utility macro to define a read-only property.
 *
 * This is identical to the PROPERTY_RO macro except that this will use
 * references for accessor/mutator methods.  This would be the prefered way of
 * defining properties of complex type (where copying may be expensive).
 */
#define PROPERTY_REF_RO(type, name) \
  PROPERTY_GETTER_REF(type, name) \
  PROPERTY_VARIABLE(type, name)

#define PROPERTY_CONST_REF_RO(type, name) \
  PROPERTY_GETTER_CONST_REF(type, name) \
  PROPERTY_VARIABLE(type, name)


#define PROPERTY_PTR_RO(type, name) \
  PROPERTY_PTR_GETTER(type, name) \
  PROPERTY_PTR_VARIABLE(type, name)

#define PROPERTY_PTR_CONST_RO(type, name) \
  PROPERTY_PTR_GETTER_CONST(type, name) \
  PROPERTY_PTR_VARIABLE(type, name)

/* Generator macros */

#define PROPERTY_GETTER(type, name) \
  public: inline type name() const { return name##_; }

#define PROPERTY_GETTER_CONST(type, name) \
  public: inline const type name() const { return name##_; }

#define PROPERTY_SETTER(type, name) \
  public: inline void set_##name(const type aVal) { name##_ = aVal; }

#define PROPERTY_GETTER_REF(type, name) \
  public: inline type& name() { return name##_; }

#define PROPERTY_GETTER_CONST_REF(type, name) \
  public: inline const type& name() const { return name##_; }

#define PROPERTY_SETTER_REF(type, name) \
  public: inline void set_##name(const type &aVal) { name##_ = aVal; }

#define PROPERTY_VARIABLE(type, name) \
  private: type name##_

#define PROPERTY_PTR_GETTER(type, name) \
  public: inline type* name() const { return name##_; }

#define PROPERTY_PTR_GETTER_CONST(type, name) \
  public: inline const type* name() const { return name##_; }

#define PROPERTY_PTR_SETTER(type, name) \
  public: inline void set_##name(type *aVal) { name##_ = aVal; }

#define PROPERTY_PTR_VARIABLE(type, name) \
  private: type *name##_

#endif /* VOLT_UTIL_MACROS_H */
