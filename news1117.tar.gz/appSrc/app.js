(function() {
    Volt.pakages = { instances: {}, modules: {} };
    Volt.BASE_PATH = 'file://';
    Volt.require = function(path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            return require(Volt.browser ? path : Volt.BASE_PATH + path);
        }
    };

    var resolutionHeight = 1080;
    Volt.requireTemplate = function(templateName){
        return Volt.require('templates/' + resolutionHeight+'/' + templateName + '-template.js');
    };
    Volt.requireAppTemplate = function(fileName){
        return Volt.require('app/templates/' + resolutionHeight+'/' + fileName);
    };
})();

var Backbone, PanelCommon, CommonDefines, GlobalMediator = null,Global,DeviceModel,CPAPI = null,ModelController,LoadingDialog ;
//for search city weather
var IsDeepLink = false;
var DeepLinkCityID = "";
var splashList = [];

var initialize = function() {
    //showSplashImage();
    Volt.setTimeout(function(){
        loadModules();
        setupEnv();
        startApp();
		//destroySplashImage();
    }, 100);
};

function loadModules() {
	Volt.require('distribution.min.js');	
	Volt.require('lib/volt-common.js'); // Common Functions
	Volt.require('lib/volt-debug.js'); // For Debug
	Volt.require('lib/volt-nav.js'); // Focus and Key Input Management

	Backbone = Volt.require('lib/volt-backbone.js');
	PanelCommon = Volt.require('lib/panel-common.js');
	//Require common defines
	CommonDefines = Volt.require('app/common/commonDefines.js');
	Global = Volt.require('app/common/Global.js');
	GlobalMediator = Volt.require('app/common/GlobalMediator.js');
	DeviceModel = Volt.require('app/common/deviceModel.js');
	CPAPI = Volt.require('app/common/CPAPI.js');
	ModelController = Volt.require('app/controller/model-controller.js');
	Volt.require('app/router.js');
	//KPI start
	Volt.KPIMapper = Volt.require('app/common/kpi-mapper.js');	//KPI end

	//multilingual
	Volt.i18n = Volt.require('lib/volt-multilingual.js');
	
	//Update Template Parser custom widget into
	PanelCommon.mapWidgets(['OptionMenu', 'Button_Generic', 'MessagePopup']);
};

function setupEnv() {
    Volt.KPIMapper.init();
    
    Volt.i18n.init({
        lng : DeviceModel.getLanguageCode(),
        resGetPath: 'lang/<<lng>>.json',
        getAsync: false,
        interpolationPrefix: '<<',
        interpolationSuffix: '>>'
    }, function(t){
    });
};

function startApp() {
    LoadingDialog = Volt.require('app/views/loading-view.js');

    if (-1 == DeviceModel.getNetWorkState()){
        scene.color = Volt.hexToRgb('#000000');
        var ErrorHandler = Volt.require('app/common/errorHandler.js');
        ErrorHandler.show(CommonDefines.PopupType.NETWORK_ERROR_ENTRY,null,function(){Volt.quit();});
        return;
    }
    
    scene.color = Volt.hexToRgb('#0f1826');
    Global.APP_STATUS = Global.APP_ACTIVE;
    Backbone.history.start({minCount: 0});
    if (!IsDeepLink){
        Backbone.history.navigate('home', {
            trigger : true
        });
        ModelController.offline().then(function(){
            if (DeviceModel.isDeviceInfoReady()){
                Volt.log('begin cp init');
                CPAPI.initialize().then(function(){
                    ModelController.ready();
                });
            } else {
                GlobalMediator.on(CommonDefines.Event.ON_DEVICEINFO_READY, function(){
                    Volt.log('begin cp init on trigger');
                    CPAPI.initialize().then(function(){
                        ModelController.ready();
                    });
                });
            }
        }).fail(function(){
            if (DeviceModel.isDeviceInfoReady()){
                Volt.log('begin cp init');
                CPAPI.initialize().then(function(){
                    ModelController.ready();
                });
            } else {
                GlobalMediator.on(CommonDefines.Event.ON_DEVICEINFO_READY, function(){
                    Volt.log('begin cp init on trigger');
                    CPAPI.initialize().then(function(){
                        ModelController.ready();
                    });
                });
            }
        });
    } else {
        Volt.log('go to weather detailview from search');
        LoadingDialog.show(1);
        //dummy China
        DeviceModel.set('countryCode', 'CN');

        CPAPI.initialize().then(function(){
            Backbone.history.navigate('weather/0', {
                trigger : true,
    			weatherTile : [],
    			isDeepLink : true,
    			cid : DeepLinkCityID
            });
        });
    }
};

function showSplashImage() {
    splashList.push(new Widget({
            x: 0, y: 0, width: 1920, height: 144, color: { r: 16, g: 24, b: 42 }, parent: scene
    }));
    splashList.push(new Widget({
            x: 0, y: 145, width: 1920, height: 72, color: { r: 242, g: 242, b: 242 }, parent: scene
    }));
    splashList.push(new Widget({
            x: 0, y: 216, width: 1920, height: 864, color: { r: 239, g: 239, b: 239 }, parent: scene
    }));
    splashList.push(new Widget({
            x: 0, y: 0, width: 1920, height: 1080, color: { r: 0, g: 0, b: 0, a: 122 }, parent: scene
    }));
};


function destroySplashImage(){
    var count = splashList.length;
    for(var i = 0; i < count; i++){
        var temp = splashList[i];
        print('destroy splash image');
        scene.removeChild(temp);
        temp.destroy();
        temp = null;
    }
};

/**
 * Key event listener from volt engine
 * @param keycode
 * @param type
 */
var onKeyEvent = function(keyCode, keyType) {

	if(GlobalMediator === null) {
		return;
	}
	
    Volt.log('keyCode : ' + keyCode);
    /*if (keyCode == Volt.KEY_3 && keyType == Volt.EVENT_KEY_PRESS){		
		    Global.MEMORY_TEST_STATUS = Global.MEMORY_TEST_ON;
			return;
    }
    if (keyCode == Volt.KEY_4 && keyType == Volt.EVENT_KEY_PRESS){		
		    Global.MEMORY_TEST_STATUS = Global.MEMORY_TEST_OFF;
			return;
    }
    
    if (keyCode == Volt.KEY_5 && keyType == Volt.EVENT_KEY_PRESS) {
        gc();
        VDUtil.heapSnapshot();
    }*/
    
    if(LoadingDialog.isLoading)
    {
        if (keyCode == Volt.KEY_RETURN && keyType == Volt.EVENT_KEY_RELEASE) {
			if (Backbone.history.location.history.length > 1) {
                print("Return loading");
                Backbone.history.back();
            } else {
				Volt.log('newson exit loading');
                //DeviceModel.destroyVoltApi();
                Volt.exit(); 
            }
        }
        return;
    }
    
    if (Volt.Nav.onKeyEvent(keyCode, keyType) === false) {
        // use key_1 and key_0 to simulate network status
    	if (keyCode == Volt.KEY_1 && keyType == Volt.EVENT_KEY_RELEASE){		
    	    DeviceModel.set('networkState', -1);
    		return;
    	}
    	else if(keyCode == Volt.KEY_0 && keyType == Volt.EVENT_KEY_RELEASE) {
    	    DeviceModel.set('networkState', 0);
    		return;		
    	}
    	else if(keyCode == Volt.KEY_8 && keyType == Volt.EVENT_KEY_RELEASE){
            var RouterController = Volt.require('app/controller/router-controller.js');
            if (RouterController.getCurrentView().name && 'main-view' == RouterController.getCurrentView().name){
                if(DeviceModel.get('countryCode') == 'BR'){
                    DeviceModel.set('countryCode', 'CN');
                } else {
                    DeviceModel.set('countryCode', 'BR');
                }
            }
    	    return;
    	}
    	else if(keyCode == Volt.KEY_9 && keyType == Volt.EVENT_KEY_RELEASE) {
    	        var ErrorHandler = Volt.require('app/common/errorHandler.js');
                ErrorHandler.show(CommonDefines.PopupType.VERSION,null,null);
                return;     
            }
        if (keyCode == Volt.KEY_RETURN && keyType == Volt.EVENT_KEY_RELEASE) {
			if (Backbone.history.location.history.length > 1) {
                print("Return");
                Backbone.history.back();
            } else {
				Volt.log('newson exit');
                //DeviceModel.destroyVoltApi();
                Volt.exit(); 
            }
        }
    }
};

Volt.addEventListener(Volt.ON_SHOW, function(data){
    //Volt.log("receive event ON_SHOW:"+JSON.stringify(data));
    if(data == undefined || data == null){
        Volt.log('received data is null or undefined');
        return;
    }
    
	if(data["Sub_Menu"] == "detail"){
        if (data.hasOwnProperty('cid')){
            Volt.log('received city id, prepare to show city weather');
    		IsDeepLink = true;
    		DeepLinkCityID = data["cid"];
        }
        //dummy
        //IsDeepLink = true;
        //DeepLinkCityID = '01010101';
	}
});

Volt.addEventListener(Volt.ON_PAUSE, function(){
	if(GlobalMediator !== null) {
		Volt.log('Event Volt.ON_PAUSE is received');
		//GlobalMediator.trigger(CommonDefines.Event.APP_ON_PAUSE);
	}
});

Volt.addEventListener(Volt.ON_RESUME, function(){
	if(GlobalMediator !== null) {
		Volt.log('Event Volt.ON_RESUME is received');
		//GlobalMediator.trigger(CommonDefines.Event.APP_ON_RESUME);
	}
});

Volt.addEventListener(Volt.ON_DEACTIVATE, function(){
	if(GlobalMediator !== null) {
		Volt.log('Event Volt.ON_DEACTIVATE is received');
		GlobalMediator.trigger(CommonDefines.Event.APP_ON_DEACTIVATE);
	}
});

Volt.addEventListener(Volt.ON_ACTIVATE, function(){
	if(GlobalMediator !== null) {
		Volt.log('Event Volt.ON_ACTIVATE is received');
		GlobalMediator.trigger(CommonDefines.Event.APP_ON_ACTIVATE);
	}
});

Volt.addEventListener(Volt.ON_UNLOAD, function(){
	if(GlobalMediator !== null) {
		Volt.log('Event Volt.ON_UNLOAD is received');
		//GlobalMediator.trigger(CommonDefines.Event.APP_ON_UNLOAD);
	}
});

Volt.addEventListener(Volt.ON_HIDE, function(){
	if(GlobalMediator !== null) {
        Volt.log('Event Volt.ON_HIDE is received');
        GlobalMediator.trigger(CommonDefines.Event.APP_ON_HIDE);
    }
});


