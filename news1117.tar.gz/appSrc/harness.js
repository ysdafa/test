(function(){
    //Volt.BASE_PATH = 'http://10.240.135.67:8080/'; // In case server environment
    Volt.BASE_PATH = 'file://'; // In case TV environment
    Volt.require = function(path) {
        return require(Volt.browser ? path : Volt.BASE_PATH + path);
    };
})();
Volt.require('lib/volt-debug.js'); // For Debug

var testScripts = ['file://app/unit_test/testModel-Yahoo.js',
		   'file://app/unit_test/testModel-SinaHuafeng.js'];

var resultWidget,
    jasmine = require("jasmine.js");

var widgetReporter = new WidgetReporter();

function initialize() {
  var jasmineEnv = jasmine.jasmine.getEnv();

  jasmineEnv.addReporter(widgetReporter);

  /********************************************************
    Load and run CursorComponent modules tests
  *********************************************************/
  var req = new ResourceRequest({
    uri: "",
    async: false,
    success: function(data, status, response) { eval(data); }
  });

  testScripts.forEach(function(path)
  {
    req.uri = path;
    req.process();
  });

  jasmineEnv.execute();
}

function onKeyEvent(keycode, type)
{
  if (type != Volt.EVENT_KEY_PRESS) return;

  var y_delta = 100;
  var duration = 200;
  var easing = "QUADRATIC";
  switch(keycode)
  {
    case Volt.KEY_JOYSTICK_DOWN:
      if (widgetReporter.textHeight > scene.height)
      {
        var new_y = widgetReporter.textWidget.y - y_delta;
        var min = scene.height - widgetReporter.textHeight;
        if (new_y < min)
        {
          widgetReporter.textWidget.animate("y", min, duration, easing);
          //widgetReporter.textWidget.y = min;
        }
        else
        {
          widgetReporter.textWidget.animate("y", new_y, duration, easing);
          //widgetReporter.textWidget.y = new_y;
        }
      }
      break;
    case Volt.KEY_JOYSTICK_UP:
      if (widgetReporter.textHeight > scene.height)
      {
        var new_y = widgetReporter.textWidget.y + y_delta;
        if (new_y > 0)
        {
          widgetReporter.textWidget.animate("y", 0, duration, easing);
          //widgetReporter.textWidget.y = 0;
        }
        else
        {
          widgetReporter.textWidget.animate("y", new_y, duration, easing);
          //widgetReporter.textWidget.y = new_y;
        }
      }
      break;
  }
}

function WidgetReporter()
{
  this.textWidget = new TextWidget({
    width: scene.width,
    height: scene.height,
    x: 0,
    y: 0,
    text: "",
    font: "14px",
    parent: scene
  });

  this.pass = "<span color='green'>PASS</span>";
  this.fail = "<span color='red'><b>FAIL</b></span>";

  this.markupText = "";
  this.textHeight = 0;
  this.prevSuite = null;
}

WidgetReporter.prototype.reportRunnerStarting = function(runner)
{
  this.appendText("Test starting: " + (new Date()) + "\r\n");
}

WidgetReporter.prototype.reportRunnerResults = function(runner)
{
  // When all the spec are finished //
  var result = runner.results();

  this.appendText("********************************************************************************\r\n" +
                  "Test results (" + result.passedCount + "/" + result.totalCount + "): " +
                  (result.passed() ? this.pass : this.fail) + "\r\n" +
                  "********************************************************************************\r\n" +
                  "Test finished: " + (new Date()) + "\r\n");

  (new ResourceRequest({
    uri: "file://result.txt",
    method: "PUT",
    async: false,
    data: this.textWidget.text
  })).process();
};

WidgetReporter.prototype.reportSuiteResults = function(suite)
{
  // When a group of spec has finished running //
  var result = suite.results();
  var description = suite.description;
  this.appendText("[END] " + suite.getFullName() +
                  " (" + result.passedCount + "/" + result.totalCount + "): " +
                  (result.passed() ? this.pass : this.fail) + "\r\n");
}

WidgetReporter.prototype.reportSpecStarting = function(spec)
{
  if (spec.suite !== this.prevSuite)
  {
    this.appendText("********************************************************************************\r\n" +
                    "[BEGIN] " + spec.suite.getFullName() + "\r\n");
    this.prevSuite = spec.suite;
  }
  this.appendText("|-- " + spec.description + "... ");
}

WidgetReporter.prototype.reportSpecResults = function(spec)
{
  // When a single spec has finished running //
  var results = spec.results().getItems();
  for (var index = 0; index < results.length; ++index)
  {
    this.appendText((results[index].passed() ? this.pass : this.fail) + " ");
  }
  this.appendText("\r\n");
}

WidgetReporter.prototype.appendText = function(text)
{
  this.markupText += text;
  this.textWidget.text = this.markupText;

  this.adjustHeight();
}

WidgetReporter.prototype.adjustHeight = function()
{
  /* Bad impl... */
  var tmp_widget = new TextWidget({
    width: scene.width,
    x: 0,
    y: this.textWidget.y,
    text: this.markupText,
    font: "14px"
  });
  this.textHeight = tmp_widget.height;
  this.textWidget.height = tmp_widget.height;

  if (tmp_widget.height > scene.height)
  {
    this.textWidget.animate("y", scene.height - this.textHeight, 200, "QUADRATIC");
    //this.textWidget.y = scene.height - this.textHeight;
  }
}
