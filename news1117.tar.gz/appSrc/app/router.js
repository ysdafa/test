var Backbone = Volt.require('lib/volt-backbone.js');
var RouterController = Volt.require('app/controller/router-controller.js');
var GlobalMediator = Volt.require('app/common/GlobalMediator.js');
var Global = Volt.require('app/common/Global.js');
//Require common defines
var CommonDefines = Volt.require('app/common/commonDefines.js');
var Router = Backbone.Router.extend({

    initialize: function() {
        this.on('route', function() {
            Volt.log('URL : ' + Backbone.history.location.hash);
        });
        GlobalMediator.on(CommonDefines.Event.APP_ON_DEACTIVATE, function(){
            //KPI start
            Volt.log('Begin KPILogLeavePage');
            KPILogLeavePage();
       	    //KPI end

            Global.APP_STATUS = Global.APP_DEACTIVATE;
            RouterController.pauseView(RouterController.getCurrentView());
        });
        GlobalMediator.on(CommonDefines.Event.APP_ON_ACTIVATE, function(){
            //KPI start
            Volt.log('Begin KPILogEnterPage');
            KPILogEnterPage();
       	    //KPI end

            Global.APP_STATUS = Global.APP_ACTIVE;
            RouterController.resumeView(RouterController.getCurrentView());
        });
        GlobalMediator.on(CommonDefines.Event.APP_ON_HIDE, function(){
            //KPI start
            Volt.log('Begin KPILogLeavePage');
            KPILogLeavePage();
       	    //KPI end
        });
    },

    routes: {
        'home': 'home',
        'detail/:id/:focus': 'detail',
		'weather/:id': 'weather',
		'tutorialColdStart' : 'tutorialColdStart',
		'weatherSetting' : 'weatherSetting'
    },

    home: function() {
        RouterController.root('main-view');
        Volt.KPIMapper.enterPage('H01_HOME');
    },
    detail : function(id, focus){
        RouterController.detail('newson-detail-view', {'id':id,'focus':focus});
        Volt.KPIMapper.enterPage('H02_DETAIL');
    },
	weather: function(id, options) { 
    	options.id = id;
    	Volt.log(typeof options.weatherTile);
    	RouterController.detail('weather-detial-view', options); 
        Volt.KPIMapper.enterPage('H04_WEATHER');
	},
	tutorialColdStart : function() {
		RouterController.secondDepth('newson-tutorial-cold-start-view');
	},
	weatherSetting : function() {
        RouterController.secondDepth('newson-weather-setting-view-china');
        Volt.KPIMapper.enterPage('H05_WEATHER');
	},
});

//KPI start
var KPILogEnterPage = function(){
    var pageEvent = '', pageName = '';
    if (RouterController.getCurrentView().name){
        pageName = RouterController.getCurrentView().name;
        Volt.log('Enter NewsOn on '+pageName);
        switch(pageName){
            case 'main-view':
                pageEvent = 'H01_HOME';
                break;
            case 'newson-detail-view':
                pageEvent = 'H02_DETAIL';
                break;
            case 'weather-detial-view':
                pageEvent = 'H04_WEATHER';
                break;
            case 'newson-weather-setting-view-china':
                pageEvent = 'H05_WEATHER';
                break;
            default:
                break;
        }
    }
    if (pageEvent != ''){
        Volt.KPIMapper.enterPage(pageEvent);
    }
};

var KPILogLeavePage = function(){
    var pageEvent = '', pageName = '';
    if (RouterController.getCurrentView().name){
        pageName = RouterController.getCurrentView().name;
        Volt.log('Exit NewsOn on '+pageName);
        switch(pageName){
            case 'main-view':
                pageEvent = 'H01_HOME';
                break;
            case 'newson-detail-view':
                pageEvent = 'H02_DETAIL';
                break;
            case 'weather-detial-view':
                pageEvent = 'H04_WEATHER';
                break;
            case 'newson-weather-setting-view-china':
                pageEvent = 'H05_WEATHER';
                break;
            default:
                break;
        }
    }
    if (pageEvent != ''){
        Volt.KPIMapper.leavePage(pageEvent);
    }
};
//KPI end

exports = new Router();