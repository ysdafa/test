/**
 * @author  Yipeng Zhu (yipeng.zhu@samsung.com)
 * @fileoverview Description of a file
 * @date    2014/07/04 (last modified date)
 *
 * Copyright 2012 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

// Include libraries
var _ = Volt.require('modules/underscore.js')._;
var Backbone = Volt.require('lib/volt-backbone.js');
var VoltJSON = Volt.require('modules/VoltJSON.js');
var CPAPI = Volt.require('app/common/CPAPI.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var BaseView = PanelCommon.BaseView;
var Q = PanelCommon.Q;
var voltapi = Volt.require('modules/voltapi.js');

// Include models
var NewsDetailModel = Volt.require('app/models/newsDetailModel.js');
var MainNewsModel = Volt.require('app/models/mainNewsModel.js');
var MoreNewsModel = Volt.require('app/models/moreNewsModel.js');
var newsCollection = null;//MainNewsModel.get('pageModel').get('tileCollection');

var ScrollableTextWidget = Volt.require('app/common/scrollableTextWidget.js');
PanelCommon.mapWidget('ScrollableTextWidget', ScrollableTextWidget);
var CResizeableGridListControl = Volt.require('modules/UIElement/CResizeableGridListControl.js');
PanelCommon.mapWidget('CResizeableGridListControl', CResizeableGridListControl);

// Include example templates(should implement by apps panel member)
var NewsonMainDetailTemplate = Volt.requireAppTemplate('newson-main-detail-template.js');
var DetailThumbTemplate = Volt.requireAppTemplate('newson-detail-thumb-template.js');
var DetailTextTemplate = Volt.requireAppTemplate('newson-detail-text-template.js');
//var DetailVideoTemplate = Volt.requireAppTemplate('newson-detail-video-template.js');
var NewsonDetailTemplate = Volt.requireAppTemplate('newson-detail-template.js');
//Include newson common templates
var NewsOnDetailCommonTemplate = Volt.requireTemplate('newson-detail');

var DeviceModel = Volt.require('app/common/deviceModel.js');


var LoadingDialog = Volt.require('app/views/loading-view.js');
//Require dim view
var dimView = PanelCommon.requireView('dim');
//Require customization
var customizationIcon = Volt.require('app/common/customization-icon.js');
//KPI start
var KPI = Volt.require('app/common/kpi-options.js');
var KPIOptions = KPI.NewsDetail;
//KPI end

//define list item attribute
var detailViewSelf = null;

var Global = Volt.require('app/common/Global.js');
//Require GlobalMediator
var GlobalMediator = Volt.require('app/common/GlobalMediator.js');
//Require common defines
var CommonDefines = Volt.require('app/common/commonDefines.js');
var ScrollBar = Volt.require('app/common/ScrollBar.js');
PanelCommon.mapWidget('ScrollBar', ScrollBar);
var relatedItemViewSelf = null;

/** News Detail View -BackboneView
* @class 
* @name DetailView
* @augments Backbone.View
*/
var DetailView = BaseView.extend({
        /**
         * This property represents the default template in DetailView.
         * @name template
         * @type JSON
         * @default NewsOnDetailCommonTemplate.container
         * @fieldOf DetailView.prototype
         */
		template : NewsOnDetailCommonTemplate.container,
        
        /**
         * This property represents the parameter passed from other view.
         * @name options
         * @type JSON
         * @default null
         * @fieldOf DetailView.prototype
         */
		options : null,
        
         /**
         * This property represents the news' map on the news collection.
         * @name map
         * @type Array
         * @default []
         * @fieldOf DetailView.prototype
         */
		map : [],
        
        /**
         * This property represents the detail news' model.
         * @name newsDetailModel
         * @type JSON
         * @default null
         * @fieldOf DetailView.prototype
         */
		newsDetailModel : null,
        
        /**
         * This property represents the child view's reference in DetailView.
         * @name titleView
         * @type Class
         * @default null
         * @fieldOf DetailView.prototype
         */
		titleView : null,
        
        /**
         * This property represents the child view's reference in DetailView.
         * @name contentView
         * @type Class
         * @default null
         * @fieldOf DetailView.prototype
         */
		contentView : null,
        
        /**
         * This property represents the child view's reference in DetailView.
         * @name relatedView
         * @type Class
         * @default null
         * @fieldOf DetailView.prototype
         */
		relatedView : null,
        
        /**
         * This property represents detail news model request status.
         * @name status
         * @type string
         * @default success
         * @fieldOf DetailView.prototype
         */
		status : 'success',
        sceneColorMgr : [],
        urlCacheMgr : [],
        tileCollection : null,
        lastFocus : null,
        /** Initialize DetailView. 
        * @function initialize
        * @memberof DetailView
        */
		initialize : function () {
			this.newsDetailModel = NewsDetailModel;
			this.loadingDialog = LoadingDialog;
            this.tileCollection = new Backbone.Collection();
            detailViewSelf = this;
            if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
            {
                print('detail view initialize');
                print(VDUtil.getProcMemory());
            }
		},
        
        /** render DetailView. 
        * @function render
        * @memberof DetailView
        */
		render : function () {
        
           
			this.setWidget(PanelCommon.loadTemplate(this.template)); //load newson detail view(include titile-area,content-area and related area)
            this.widget.hide();
			this.renderTitle();
			this.renderContent();
			this.renderRelated();
			this.renderReturnButton();
		},
		
        /** callback of detail view's model if the detail view model fetch error. 
        * @function show
        * @param {Object}  object                  	- the http request object
        * @param {string}  status          		- show the http request's status
        * @param {string}  exception                  	- pass the exception
        * @memberof DetailView
        */
		errorHappened : function (object, status, exception) {
		    Volt.log('errorHandle');
			this.loadingDialog.hide();
			var ErrorHandler = Volt.require('app/common/errorHandler.js');
			ErrorHandler.show(CommonDefines.PopupType.SERVER_ERROR2,404,this.returnFun);	
		},		

		returnFun : function() {
			detailViewSelf.widget.hide();
			Backbone.history.location.history.length = 0;
			//Backbone.history.back();
            detailViewSelf.sceneColorMgr.length = 0;
            detailViewSelf.sceneColorMgr = [];
            detailViewSelf.urlCacheMgr.length = 0;
            detailViewSelf.urlCacheMgr = [];
			Backbone.history.navigate('home', {
						trigger : true
					});
		},
		
        /** show the detail view 
        * @function show
        * @param {JSON}  options                  	- the parameter
        * @param {string}  animationType          		-animation type
        * @memberof DetailView
        */
		show : function (options, animationType) {
			var deferred = Q.defer();
			if( !voltapi.vconf.getValue(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE)){
	            this.returnButton.hide();
	        } else {
	            this.returnButton.show();
	        }

	        this.listenTo(GlobalMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, this.onChangeCursor);
	        
			this.loadingDialog.show(1);
			this.options = options;
            //scene color mgr
            //first time should save scene color
            if(this.sceneColorMgr.length === 0) {// from main view into detail
                this.sceneColorMgr.push({r:scene.color.r, g:scene.color.g, b:scene.color.b});
            }
            if(this.options.focus != '<-1>') {
                if(this.sceneColorMgr.length > 1) {
                    this.sceneColorMgr.pop();
                    scene.color = this.sceneColorMgr[this.sceneColorMgr.length - 1];
                }
                if(this.urlCacheMgr.length > 1)
                    this.urlCacheMgr.pop();
            }
            //end scene color mgr
            
            this.tileCollection.reset();
            for(var i = 0; i < MainNewsModel.get('pageModel').get('tileCollection').length; i++)
            {
                this.tileCollection.add(MainNewsModel.get('pageModel').get('tileCollection').at(i));
            }
            
            for(var i = 0; i < MoreNewsModel.get('pageCollection').length; i++)
            {
                var pageModel = MoreNewsModel.get('pageCollection').at(i);
                for(var j = 0; j < pageModel.get('tileCollection').length;j++)
                {
                    this.tileCollection.add(pageModel.get('tileCollection').at(j));
                }
            }
            var iCount = 0;
			for (var i = 0; i < this.tileCollection.length; i++) {
				if (this.tileCollection.at(i).get('tile_type') == 'news') {
					this.map[iCount] = i;
					iCount++;
				}
			}
            this.model = null;
            if(this.urlCacheMgr.length === 0) {
                for(var i = 0; i < this.tileCollection.length;i++){
                    if(this.tileCollection.at(i).id === options.id){
                        this.model = this.tileCollection.at(i);
                        print('found the tile model-------------------');
                        break;
                    }
                }
                this.urlCacheMgr.push(this.model.get('detail_url'));
            }
			this.listenTo(this.newsDetailModel, 'error', this.errorHappened);
			this.listenTo(this.newsDetailModel, 'complete', this.showDetail);
			var url = null;
            
            url = this.urlCacheMgr[this.urlCacheMgr.length - 1];
            print('this.urlCacheMgr.length-------------------------'+this.urlCacheMgr.length);
            this.newsDetailModel.setInitData({
                'url' : url
            });
            detailViewSelf.newsDetailModel.fetch({}).then(function () {});
			deferred.resolve();
            if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
            {
                print('detail view show');
                print(VDUtil.getProcMemory());
            }
			return deferred.promise;
		},
		
		/** hide the detail view 
        * @function hide
        * @param {JSON}  options                  	- the parameter
        * @param {string}  animationType          		-animation type
        * @memberof DetailView
        */
		hide : function (options, animationType) {
			var deferred = Q.defer();
			this.stopListening();
			this.stopListening(GlobalMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR);
			this.newsDetailModel.clear();
            this.contentView.hide();
            this.relatedView.hide();
			this.widget.hide();
            //scene color mgr
            if(Backbone.history.location.history.length === 1)
            {
                this.sceneColorMgr.length = 0;//clear scene color mgr stack
                this.sceneColorMgr = [];
                this.urlCacheMgr.length = 0;
                this.urlCacheMgr = [];
            }
            //end of scene color mgr
            
			this.loadingDialog.hide();
            if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
            {
                print('detail view hide');
                gc();
                print(VDUtil.getProcMemory());
            }
			deferred.resolve();
			return deferred.promise;
		},
		
		update : function(options, animationType){
			this.hide(options, animationType);
			this.show(options, animationType);
		},
        
        /** show the detail content callback
        * @function showDetail
        * @memberof DetailView
        */
		showDetail : function (object, status) {
			if (status != 'success')
            {
				this.loadingDialog.hide();
                return; // for error handler extension
            }
            if(this.newsDetailModel.get('id') === null)
            {
                this.loadingDialog.hide();
                this.errorHappened();
            }
            //clear the last focus
            Volt.Nav.setRoot(this.widget,{focus:null});
			this.titleView.show();
			this.contentView.show();
			//this.renderRelated();
            if(this.newsDetailModel.relatedTileCollection.length > 0) {
                this.relatedView.show(this.options, this.newsDetailModel.relatedTileCollection);
            }
            else {
                this.relatedView.show(this.options);
            }
            //Volt.Nav.setRoot(this.widget, {focus:this.relatedView.widget});
            this.widget.show();
            Volt.setTimeout(function(){
                detailViewSelf.loadingDialog.hide();
            },30);
            
		},
		
        /** render title view 
        * @function renderTitle
        * @memberof DetailView
        */
		renderTitle : function () {
			var container = this.widget.getDescendant('detail-title-area');
			if (container && container.addChild) {
				this.titleView = new TitleView(this.newsDetailModel);
				container.addChild(this.titleView.render().widget);
			}
		},
		
        /** render content view 
        * @function renderContent
        * @memberof DetailView
        */
		renderContent : function () {
			var container = this.widget.getDescendant('detail-content-area');
			if (container && container.addChild) {
				this.contentView = new ContentView(this.newsDetailModel);
				container.addChild(this.contentView.render().widget);
			}
		},
		
        /** render related view 
        * @function renderRelated
        * @memberof DetailView
        */
		renderRelated : function () {
			var container = this.widget.getDescendant('detail-relate-area');
			if (container && container.addChild) {
				this.relatedView = new RelatedItemView(this.map);
				container.addChild(this.relatedView.render(container).widget, 0);
			}
		},
		
		/**
	     * @description Render the return button.
	     * @function renderReturnButton
	     * @memberof DetailView
	     * @return None
	     */
	    renderReturnButton : function() {
	        this.returnButton = this.widget.getDescendant('newson-news-detail-return-button');
	        customizationIcon(this.returnButton, {
	            imageStyle : 'pageReturn'
	        });
	        this.returnButton.onMouseClick = function(){
	            Backbone.history.back();
	        };
	    },
	    /** pause the main view Invoked when some popup view popup over this View
        * @function onChangeCursor
        * @memberof DetailView
        */
	    onChangeCursor : function(visible){
	        if( this.returnButton){
	            if(visible){
	                this.returnButton.show();
	            }else{
	                this.returnButton.hide();
	            }
	        }
	    },
        /**
         * pause the main view Invoked when some popup view popup over this View
         * @function
         * @memberof MainView
         */
        pause : function() {
            Volt.log();
            dimView.show({
                parent: scene
            });
        },

        /**
         * Invoked when come back from popup
         * @function
         * @memberof MainView
         */
        resume : function() {
            Volt.log();
            dimView.hide();
            if(this.lastFocus)
            {
                Volt.Nav.focus(this.lastFocus);
            }
        }
	});

var titleViewSelf = null;
//template of title area

/** TitleView -BackboneView
* @class 
* @name TitleView
* @augments Backbone.View
*/
var TitleView = BaseView.extend({

        /**
        * This property represents the template type.text,thumb,or video.
        * @name template_type
        * @type string
        * @default null
        * @fieldOf TitleView.prototype
        */
		template_type : null,
        
        /**
        * This property represents the text template container
        * @name text_container
        * @type Widget
        * @default null
        * @fieldOf TitleView.prototype
        */
        text_container : null,
        
        /**
        * This property represents the thumb template container
        * @name thumb_contaner
        * @type Widget
        * @default null
        * @fieldOf TitleView.prototype
        */
		thumb_contaner : null,
        
        /** Initialize TitleView. 
        * @function initialize
        * @memberof TitleView
        */
		initialize : function (model) {
			this.model = model;
            titleViewSelf = this;
		},
		
        /** render TitleView. 
        * @function render
        * @memberof TitleView
        */
		render : function () {

            var container = new Widget();
			
			this.text_container = PanelCommon.loadTemplate(DetailTextTemplate.container);
			this.thumb_contaner = PanelCommon.loadTemplate(DetailThumbTemplate.container);
            
			container.addChild(this.text_container);
			container.addChild(this.thumb_contaner);
			this.setWidget(container);
            this.thumbTitleInfoWithoutThumbWidth = this.thumb_contaner.width;
            this.thumbTitleInfoWithThumbWidth = this.widget.getDescendant('thumb_title_info').width;
            this.thumbTitleInfoWithThumbX = this.widget.getDescendant('thumb_title_info').x;
            this.thumbTitleInfoChildWithThumbX = this.widget.getDescendant('thumb_headline').x;
            this.thumbTitleInfoChildWithoutThumbX = this.widget.getDescendant('text_headline').x;
			this.text_container.hide();
			this.thumb_contaner.hide();
			this.widget.hide();
			return this;
		},
		
        /** show the title view 
        * @function show
        * @memberof TitleView
        */
		show : function () {
            if (this.model.get('img_url') == null || this.model.get('img_url').length == 0) {
				this.template_type = 'text';
				this.thumb_contaner.hide();
				this.text_container.show();
				
			} else {
				this.template_type = 'thumb';
				this.text_container.hide();
				this.thumb_contaner.show();
			}
            
            var thumbnail = this.widget.getDescendant(this.template_type + '_thumbnail');
			if (thumbnail) {
                if(thumbnail.parent)
                    thumbnail.parent.show();
                //thumbnail.hide();
                thumbnail.onReady = function(bLoading)
                {
                    var thumbTitleInfo = titleViewSelf.widget.getDescendant('thumb_title_info');
                    var thumbnail = titleViewSelf.widget.getDescendant('thumb_thumbnail');
                    var headline = thumbTitleInfo.getChild('thumb_headline');
                    var thumbSourceIcon = titleViewSelf.widget.getDescendant('thumb_source_icon');
                    var thumbSourceContainer = titleViewSelf.widget.getDescendant('thumb_source_container');
                    if(!bLoading)
                    {
                        thumbTitleInfo.x = 0;
                        thumbTitleInfo.width = titleViewSelf.thumbTitleInfoWithoutThumbWidth;
                        headline.x = titleViewSelf.thumbTitleInfoChildWithoutThumbX;
                        headline.width = titleViewSelf.thumbTitleInfoWithoutThumbWidth - 2 * titleViewSelf.thumbTitleInfoChildWithoutThumbX;
                        thumbSourceIcon.x = titleViewSelf.thumbTitleInfoChildWithoutThumbX;
                        thumbSourceContainer.x = titleViewSelf.thumbTitleInfoChildWithoutThumbX;
                        if(thumbnail.parent)
                            thumbnail.parent.hide();
                    }
                    else
                    {
                        thumbTitleInfo.x = titleViewSelf.thumbTitleInfoWithThumbX;
                        thumbTitleInfo.width = titleViewSelf.thumbTitleInfoWithThumbWidth;
                        headline.x = titleViewSelf.thumbTitleInfoChildWithThumbX;
                        headline.width = titleViewSelf.thumbTitleInfoWithThumbWidth - 2 * headline.x;
                        thumbSourceIcon.x = titleViewSelf.thumbTitleInfoChildWithThumbX;
                        thumbSourceContainer.x = titleViewSelf.thumbTitleInfoChildWithThumbX;
                        thumbnail.show();
                    }
                };
				
				//thumbnail.setSrc(this.model.get('img_url')); //load src maybe failed
				thumbnail.setContentImage(this.model.get('img_url')); //load src maybe failed
				
			}
            
            var utility = new Utility;
            var extractColor = utility.extractForegroundColor(scene.color.r, scene.color.g, scene.color.b);
            var color = {r:extractColor.color.r, g:extractColor.color.g, b:extractColor.color.b};
            var headline = this.widget.getDescendant(this.template_type + '_headline');
			if (headline && headline.text !== undefined) {
				headline.text = this.model.get('title')+'';
			}
            headline.textColor = color;
            var source_icon = this.widget.getDescendant(this.template_type + '_source_icon');
			if (source_icon) {
				source_icon.src = this.model.get('source_icon');
			}
            
            var source = this.widget.getDescendant(this.template_type + '_source');
			if (source && source.text !== undefined && this.model.get('source') !== undefined) {
				source.text = this.model.get('source');//this.model.get('source');
                source.textColor = color;
//                var testWidget = new TextWidget({
//                    x:0,y:0,
//                    height:32,
//                    font : 'SVD Light 26px',
//                    verticalAlignment:'center',
//                    horizontalAlignment : 'left',
//                    singleLineMode: true,
//                    text : this.model.get('source'),
//                });
//                source.width = testWidget.width;
//                testWidget.destroy();
			}
            
            
            var colorDrawing01 = this.widget.getDescendant(this.template_type + '_color_drawing01');
            if(colorDrawing01 && source)
            {
                colorDrawing01.x = source.x + source.width + NewsonDetailTemplate.constNum.infoSpace;
            }
            var pressTime = this.widget.getDescendant(this.template_type + '_press_time');
			if (pressTime && pressTime.text !== undefined && colorDrawing01) {
				pressTime.text = this.model.get('stringstamp');//this.model.get('source');
//                var testWidget = new TextWidget({
//                    x:0,y:0,
//                    height:32,
//                    font : 'SVD Light 26px',
//                    verticalAlignment:'center',
//                    horizontalAlignment : 'left',
//                    singleLineMode: true,
//                    text : this.model.get('stringstamp'),
//                });
                pressTime.x = colorDrawing01.x + colorDrawing01.width + NewsonDetailTemplate.constNum.infoSpace;
                pressTime.textColor = color;
//                pressTime.width = testWidget.width;
//                testWidget.destroy();
			}
            var colorDrawing02 = this.widget.getDescendant(this.template_type + '_color_drawing02');
            if(colorDrawing02 && pressTime)
            {
                colorDrawing02.x = pressTime.x + pressTime.width + NewsonDetailTemplate.constNum.infoSpace;
            }
            var timestamp = this.widget.getDescendant(this.template_type + '_timestamp');
			if (timestamp && timestamp.text !== undefined && colorDrawing02) {
				timestamp.text = this.model.get('timestatus');//this.model.get('source');
                timestamp.x = colorDrawing02.x + colorDrawing02.width + NewsonDetailTemplate.constNum.infoSpace;
//                var testWidget = new TextWidget({
//                    x:0,y:0,
//                    height:32,
//                    font : 'SVD Light 26px',
//                    verticalAlignment:'center',
//                    horizontalAlignment : 'left',
//                    singleLineMode: true,
//                    text : this.model.get('timestatus'),
//                });
                timestamp.textColor = color;
//                timestamp.width = testWidget.width;
//                testWidget.destroy();
			}
            
            /*
            var source = this.widget.getDescendant(this.template_type + '_source');
			if (source && source.text) {
				source.text = this.model.get('source') + ' | ' + this.model.get('stringstamp');//this.model.get('source');
			}
            */
			this.widget.show();
		},
		
        /** hide the title view 
        * @function hide
        * @memberof TitleView
        */
		hide : function () {
			var deferred = Q.defer();
			this.widget.hide();
			deferred.resolve();
			return deferred.promise;
		},
	});

var contentViewSelf = null;
//template of content area

/** ContentView -BackboneView
* @class 
* @name ContentView
* @augments Backbone.View
*/
var ContentView = BaseView.extend({
        
        /**
        * This property represents the default template in ContentView.
        * @name template
        * @type JSON
        * @default NewsOnDetailCommonTemplate.DetailContentArea
        * @fieldOf ContentView.prototype
        */
        template : NewsOnDetailCommonTemplate.DetailContentArea,
        
        /** Initialize content view. 
        * @function initialize
        * @memberof ContentView
        */
		initialize : function (model) {
			this.model = model;
            contentViewSelf = this;
		},
		
        /** render content view. 
        * @function render
        * @memberof ContentView
        */
        render : function () {
            this.setWidget(PanelCommon.loadTemplate(this.template));
            var articalUp = null,articalDown = null;
            articalUp = this.widget.getDescendant('artical_up');
            articalDown = this.widget.getDescendant('artical_down');
            articalUp.onKeyEvent  = this.onKeyEvent.bind(this);
            articalDown.onKeyEvent  = this.onKeyEvent.bind(this);
            articalUp.getChild(0).setBackgroundImage({
                state: "focused",
                src: Volt.getRemoteUrl('images/1080/arrow/detail_arrow_up_f.png'),
            });
            articalUp.getChild(0).setBackgroundImage({
                state: "normal",
                src: Volt.getRemoteUrl('images/1080/arrow/detail_arrow_up_n.png'),
            });
            articalUp.getChild(0).setBackgroundImage({
                state: "roll-over",
                src: Volt.getRemoteUrl('images/1080/arrow/detail_arrow_up_f.png'),
            });
            articalUp.getChild(0).setBackgroundImage({
                state: "focused-roll-over",
                src: Volt.getRemoteUrl('images/1080/arrow/detail_arrow_up_f.png'),
            });
            articalUp.getChild(0).setBackgroundImage({
                state: "disabled",
                src: Volt.getRemoteUrl('images/1080/arrow/detail_arrow_up_n.png'),
            });
            articalUp.getChild(0).setBackgroundImage({
                state: "disabled-focused",
                src: Volt.getRemoteUrl('images/1080/arrow/detail_arrow_up_n.png'),
            });
            
            articalUp.getChild(0).setBackgroundColor({
                state: "normal",
                color: {r: 255, g: 0, b: 0, a: 0},
            });
            articalUp.getChild(0).setBackgroundColor({
                state: "focused",
                color: {r: 255, g: 0, b: 0, a: 0},
            });
            
            articalUp.getChild(0).setBackgroundColor({
                state: "roll-over",
                color: {r: 255, g: 0, b: 0, a: 0},
            });
            
            
            articalUp.getChild(0).setBackgroundColor({
                state: "focused-roll-over",
                color: {r: 255, g: 0, b: 0, a: 0},
            });
            articalUp.getChild(0).setBackgroundColor({
                state: "disabled",
                color: {r: 255, g: 0, b: 0, a: 0},
            });
            articalUp.getChild(0).setBackgroundColor({
                state: "disabled-focused",
                color: {r: 255, g: 0, b: 0, a: 0},
            });
            
            articalDown.getChild(0).setBackgroundImage({
                state: "focused",
                src: Volt.getRemoteUrl('images/1080/arrow/detail_arrow_down_f.png'),
            });
            articalDown.getChild(0).setBackgroundImage({
                state: "normal",
                src: Volt.getRemoteUrl('images/1080/arrow/detail_arrow_down_n.png'),
            });
            articalDown.getChild(0).setBackgroundImage({
                state: "disabled",
                src: Volt.getRemoteUrl('images/1080/arrow/detail_arrow_down_n.png'),
            });
            articalDown.getChild(0).setBackgroundImage({
                state: "disabled-focused",
                src: Volt.getRemoteUrl('images/1080/arrow/detail_arrow_down_n.png'),
            });
            articalDown.getChild(0).setBackgroundImage({
                state: "roll-over",
                src: Volt.getRemoteUrl('images/1080/arrow/detail_arrow_down_f.png'),
            });
            articalDown.getChild(0).setBackgroundImage({
                state: "focused-roll-over",
                src: Volt.getRemoteUrl('images/1080/arrow/detail_arrow_down_f.png'),
            });
            articalDown.getChild(0).setBackgroundColor({
                state: "focused",
                color: {r: 255, g: 0, b: 0, a: 0},
            });
            articalDown.getChild(0).setBackgroundColor({
                state: "roll-over",
                color: {r: 255, g: 0, b: 0, a: 0},
            });
            
            articalDown.getChild(0).setBackgroundColor({
                state: "focused-roll-over",
                color: {r: 255, g: 0, b: 0, a: 0},
            });
            articalDown.getChild(0).setBackgroundColor({
                state: "normal",
                color: {r: 255, g: 0, b: 0, a: 0},
            });
            articalDown.getChild(0).setBackgroundColor({
                state: "disabled",
                color: {r: 255, g: 0, b: 0, a: 0},
            });
            articalDown.getChild(0).setBackgroundColor({
                state: "disabled-focused",
                color: {r: 255, g: 0, b: 0, a: 0},
            });
            var buttonListener = new ButtonListener();
            buttonListener.onButtonClicked = function(Button, type) {
                print('detail button clicked'+Button.parent.id);
                if(contentViewSelf !== null && (Button.parent.id === 'artical_down' || Button.parent.id === 'artical_up'))
                {
                    print('detail button clicked');
                    contentViewSelf.onSelect(Button.parent);
                }
            };//.bind(this);
            this.widget.getDescendant('artical_down').getChild(0).addListener(buttonListener);
            this.widget.getDescendant('artical_up').getChild(0).addListener(buttonListener);
            this.widget.hide();
            //KPI start
            this.KPIUpScroll = new KPIOptions.UpScroll(this);
            this.KPIDownScroll = new KPIOptions.DownScroll(this);
            //KPI end

            return this;
        },
		
        /** show the content view 
        * @function show
        * @memberof ContentView
        */
		show : function () {
            var stripText = this.model.get('full_story_txt');
            if(stripText && stripText.length > 0)
            {
                stripText = stripText.replace(/<p>/g, '').replace(/<\/p>/g, '');
                stripText = stripText.replace(/<b>/g, '').replace(/<\/b>/g, '');
                stripText = stripText.replace(/\n/g, '\\n');
                stripText = stripText.replace(/\t/g, '\\t');
            }
            var summary = this.model.get('summary');
            if(summary && summary.length > 0)
            {
                summary = summary.replace(/<(?:.|\n)*?>/gm, '').replace(/(?:\r\n|\r|\n|\t)/g, '');
            }
            var brandImgUrl = null;
            if(CPAPI.getServiceType() == 'sina_huafeng') {
                brandImgUrl = Volt.getRemoteUrl('images/1080/news_cp_icon_sina_w.png');
                summary = '';
                //clear first '\\n' when in sina_huafeng
                while(String(stripText).indexOf('\\n') === 0)
                {
                    stripText = stripText.replace('\\n','');
                }
            } else {
                brandImgUrl = this.model.get('brand_img_url');
            }
            var mastash = {
                brand_img_url: brandImgUrl,
                contents: summary,
                fullarticle:stripText,
            };
            var contentArea = this.widget.getDescendant('contentArea');
            //clear contentArea's child if hide operation didn't function well
            if(contentArea && contentArea.getChildCount() > 0)
            {
                for(var i = 0; i < contentArea.getChildCount(); i++)
                {
                    var child = contentArea.getChild(i);
                    this.destroy(child);
                }
            }
            
            var content = PanelCommon.loadTemplate(NewsOnDetailCommonTemplate.contentAppend, mastash);
            contentArea.addChild(content);
            var colorDrowingHorizontal = this.widget.getDescendant('color_drowing_horizontal');
            if(CPAPI.getServiceType() == 'sina_huafeng') {
                this.widget.getDescendant('brand_img_url').width = this.widget.getDescendant('brand_img_url').height * 1.3; //adjust the image width manually
            }
            var textFullarticle = this.widget.getDescendant('text_fullarticle');
            var fullarticle = this.widget.getDescendant('fullarticle');
            if(summary === null || summary === '')
            {
                this.widget.getDescendant('contents').height = 0;
                colorDrowingHorizontal.hide();
                textFullarticle.hide();
            }
            else
            {
                this.widget.getDescendant('contents').lineSpacing = NewsonDetailTemplate.constNum.bodyLineHeight - this.widget.getDescendant('contents').getLineHeight();
                colorDrowingHorizontal.y = this.widget.getDescendant('contents').y +this.widget.getDescendant('contents').height + NewsonDetailTemplate.constNum.lineSpace;
                textFullarticle.y = colorDrowingHorizontal.y + colorDrowingHorizontal.height + NewsonDetailTemplate.constNum.lineSpace;
                fullarticle.y = textFullarticle.y + textFullarticle.height + NewsonDetailTemplate.constNum.infoSpace;
            }
            fullarticle.lineSpacing = NewsonDetailTemplate.constNum.bodyLineHeight - fullarticle.getLineHeight();
            var utility = new Utility;
            var extractColor = utility.extractForegroundColor(scene.color.r, scene.color.g, scene.color.b);
            var color = {r:extractColor.color.r, g:extractColor.color.g, b:extractColor.color.b};
            //update contentArea font color
            
            textFullarticle.textColor = color;
            this.widget.getDescendant('contents').textColor = color;
            fullarticle.textColor = color;
            
            var articalContainer = this.widget.getDescendant('contentArea');
            var fullarticleContainer = this.widget.getDescendant('fullarticle');
            var contentRealAreaContaner = this.widget.getDescendant('contentRealArea');
            var height = fullarticleContainer.height + fullarticleContainer.y;
            this.scrollIndex = 0;
            this.scrollTotal = Math.floor( height / NewsonDetailTemplate.constNum.contentHeight )  + (height % NewsonDetailTemplate.constNum.contentHeight == 0 ? 0:1 );
            var scrollBar = this.widget.getDescendant('detail_scroll_bar');
            scrollBar.setCount(this.scrollTotal);
            this.onBlur(this.widget.getDescendant('artical_down')); //clear focus first
            this.onBlur(this.widget.getDescendant('artical_up'));
            Volt.Nav.focus(null);
            if(contentRealAreaContaner.y + height <= articalContainer.height)
            {
                contentViewSelf.disableButton(contentViewSelf.widget.getDescendant('artical_up'));
                contentViewSelf.disableButton(contentViewSelf.widget.getDescendant('artical_down'));
                Volt.Nav.reload();
            }
            else
            {
                contentViewSelf.disableButton(contentViewSelf.widget.getDescendant('artical_up'));
                contentViewSelf.enableButton(contentViewSelf.widget.getDescendant('artical_down'));
                Volt.Nav.reload();
                if(detailViewSelf)
                {
                    detailViewSelf.lastFocus = null;
                }
                if(Global.APP_STATUS === Global.APP_ACTIVE)
                {
                    Volt.Nav.focus(this.widget.getDescendant('artical_down'));
                } 
                else if(Global.APP_STATUS === Global.APP_DEACTIVATE)
                {
                    detailViewSelf.lastFocus = this.widget.getDescendant('artical_down');
                } 
                else
                {
                    Volt.Nav.focus(this.widget.getDescendant('artical_down'));
                }
                //Volt.Nav.focus(this.widget.getDescendant('artical_down')); //if pagecount > 1, should focus page down
            }
            this.keySelectEnable = true;
			this.widget.show();
		},
		scrollIndex : 0,
        scrollTotal : 0,
		events : {
			'NAV_FOCUS' : 'onFocus',
			'NAV_BLUR' : 'onBlur',
            //'NAV_SELECT': 'onSelect',
		},
        focusWidget:null, // mgr which focus now is focused in detail view
		keySelectEnable : false,
        onKeyEvent : function (keycode, keytype){
            if (keytype == Volt.EVENT_KEY_PRESS) {
				return ;
			}
            //Volt.KEY_JOYSTICK_DOWN,Volt.KEY_JOYSTICK_UP
            if (this.focusWidget !== null && 
                    this.focusWidget.id === 'artical_down' && keycode == Volt.KEY_JOYSTICK_DOWN){
                this.onSelect(this.focusWidget);
                return true;
            } else if (this.focusWidget !== null && 
                      this.focusWidget.id === 'artical_up' && keycode == Volt.KEY_JOYSTICK_UP){
                this.onSelect(this.focusWidget);
                return true;
            } else {
                return false;
            }
        },
        /** contentView's selected callback. 
        * @function onSelect
        * @param {Widget}  widget                  	- the widget is selected
        * @memberof ContentView
        */
		onSelect : function (widget) {
            if(this.keySelectEnable)
            {
                var contentRealAreaContaner = this.widget.getDescendant('contentRealArea');
                var scrollBar = this.widget.getDescendant('detail_scroll_bar');
                if(contentRealAreaContaner === undefined)
                    return;
                this.keySelectEnable = false;
                var needMoveWidget = contentRealAreaContaner;
                if(widget.id == 'artical_down' && contentViewSelf.scrollIndex < contentViewSelf.scrollTotal - 1)
                {
                    needMoveWidget.animate('y',needMoveWidget.y - NewsonDetailTemplate.constNum.contentHeight, 300, function(){
                        contentViewSelf.scrollIndex++;
                        //if page have more than 3 page
                        if(contentViewSelf.scrollIndex == 1 && contentViewSelf.scrollTotal >= 3)
                        {
                            contentViewSelf.enableButton(contentViewSelf.widget.getDescendant('artical_up'));
                            contentViewSelf.enableButton(contentViewSelf.widget.getDescendant('artical_down'));
                            Volt.Nav.reload();
                        }
                        if(contentViewSelf.scrollIndex == contentViewSelf.scrollTotal - 1) // arrive bottom
                        {
                            contentViewSelf.enableButton(contentViewSelf.widget.getDescendant('artical_up'));
                            contentViewSelf.disableButton(contentViewSelf.widget.getDescendant('artical_down'));
                            Volt.Nav.blur();
                            Volt.Nav.reload();
                            if(detailViewSelf)
                            {
                                detailViewSelf.lastFocus = null;
                            }
                            if(Global.APP_STATUS === Global.APP_ACTIVE)
                            {
                                Volt.Nav.focus(contentViewSelf.widget.getDescendant('artical_up'));
                            } 
                            else if(Global.APP_STATUS === Global.APP_DEACTIVATE)
                            {
                                detailViewSelf.lastFocus = contentViewSelf.widget.getDescendant('artical_up');
                            } 
                            else
                            {
                                Volt.Nav.focus(contentViewSelf.widget.getDescendant('artical_up'));
                            }
                        }
                        scrollBar.downPage(); 
                        contentViewSelf.keySelectEnable = true;
                    });
                    //KPI start
                    this.KPIDownScroll.send();
                    //KPI end
                }else if(widget.id == 'artical_up' && contentViewSelf.scrollIndex > 0) {
                    needMoveWidget.animate('y',needMoveWidget.y + NewsonDetailTemplate.constNum.contentHeight, 300,function(){
                        contentViewSelf.scrollIndex--;
                        if(contentViewSelf.scrollIndex == 0)
                        {
                            contentViewSelf.disableButton(contentViewSelf.widget.getDescendant('artical_up'));
                            contentViewSelf.enableButton(contentViewSelf.widget.getDescendant('artical_down'));
                            Volt.Nav.blur();
                            Volt.Nav.reload();
                            if(detailViewSelf)
                            {
                                detailViewSelf.lastFocus = null;
                            }
                            if(Global.APP_STATUS === Global.APP_ACTIVE)
                            {
                                Volt.Nav.focus(contentViewSelf.widget.getDescendant('artical_down'));
                            } 
                            else if(Global.APP_STATUS === Global.APP_DEACTIVATE)
                            {
                                detailViewSelf.lastFocus = contentViewSelf.widget.getDescendant('artical_down');
                            } 
                            else
                            {
                                Volt.Nav.focus(contentViewSelf.widget.getDescendant('artical_down'));
                            }
                        }
                        if(contentViewSelf.scrollTotal >= 3 && contentViewSelf.scrollIndex == contentViewSelf.scrollTotal - 2)
                        {
                            contentViewSelf.enableButton(contentViewSelf.widget.getDescendant('artical_up'));
                            contentViewSelf.enableButton(contentViewSelf.widget.getDescendant('artical_down'));
                            Volt.Nav.reload();
                        }
                        scrollBar.upPage();
                        contentViewSelf.keySelectEnable = true;
                    });
                    //KPI start
                    this.KPIUpScroll.send();
                    //KPI end
                }else {
                    this.keySelectEnable = true;                
                }
            }
        },
		
        enableButton : function(wzButton){
            wzButton.opacity = Volt.getPercentage(100);
            wzButton.custom.focusable = true;
            wzButton.getChild(0).enable(true);
        },
        
        disableButton : function(wzButton){
            wzButton.opacity = Volt.getPercentage(10);
            wzButton.custom.focusable = false;
            wzButton.getChild(0).enable(false);
        },
        /** contentView's focus callback. 
        * @function onFocus
        * @param {Widget}  widget                  	- the widget is focused
        * @memberof ContentView
        */
		onFocus : function (widget) {
			if (widget === undefined)
				return;
            try{
                if (widget) {
                    /*
                    widget.getChild(0).hide();
                    widget.getChild(1).show();*/
                    widget.getChild(0).setFocus();
                    this.focusWidget = widget; // save the focus widget
                }
            }catch(e){
                Volt.err(e);
            }
		},
		destroy : function(widget){
            if (!widget) {
                return;
            }
            Volt.log('widget.id' + widget.id);
            var nChildLength = widget.getChildCount();
            if (nChildLength > 0) {
                var i = 0;
                for(i = 0; i < nChildLength; i++){
                    this.destroy(widget.getChild(i));
                }
            }
            widget.id = '';
            //delete widget;
            widget.destroy();
            widget = null;
        },
        /** contentView's blur callback. 
        * @function onBlur
        * @param {Widget}  widget                  	- the widget is blurred
        * @memberof ContentView
        */
		onBlur : function (widget) {
			if (widget === undefined)
				return;
            try{
                if (widget) {
                    /*
                    widget.getChild(0).show();
                    widget.getChild(1).hide();*/
                    widget.getChild(0).killFocus();
                }
            }catch(e){
                Volt.err(e);
            }
		},
		
        /** contentView's focus callback. 
        * @function onFocusVideo
        * @param {Widget}  widget                  	- the widget is focused
        * @memberof ContentView
        */
		onFocusVideo : function (widget) {
			if (widget === undefined)
				return;
			if (widget.setFocus) {
				widget.setFocus();
			} else {
				if (widget && widget.border)
					widget.border = {
						width : NewsonDetailTemplate.constNum.videoFocusBW,
						color : {
							r : 255,
							g : 0,
							b : 255,
							a : 255
						}
					};
			}
			
		},
		
        /** contentView's blur callback. 
        * @function onBlurVideo
        * @param {Widget}  widget                  	- the widget is blurred
        * @memberof ContentView
        */
		onBlurVideo : function (widget) {
			if (widget === undefined)
				return;
			if (widget.killFocus) {
				widget.killFocus();
			} else
				widget.border = {
					width : NewsonDetailTemplate.constNum.videoBlurBW,
					color : {
						r : 255,
						g : 0,
						b : 255,
						a : 0
					}
				};
		},
		
        /** hide the content view 
        * @function hide
        * @memberof ContentView
        */
		hide : function () {
			var deferred = Q.defer();
            var articalUp = this.widget.getDescendant('artical_up');
            var articalDown = this.widget.getDescendant('artical_down');
            if(articalUp !== undefined && articalUp.getChildCount() == 2)
            {
                this.onBlur(articalUp);
            }
            
            if(articalDown !== undefined && articalDown.getChildCount() == 2)
            {
                this.onBlur(articalDown);
            }
            //open the key 
            this.keySelectEnable = true;//because of widget destory may cancel the animation
            
			this.widget.hide();
            var contentRealArea = this.widget.getDescendant('contentRealArea');
            if(contentRealArea)
                this.destroy(contentRealArea);
            this.focusWidget = null; // clear focus widget
			deferred.resolve();
			return deferred.promise;
		},
		
	});

//template of related area

/** RelatedItemView -BackboneView
* @class 
* @name RelatedItemView
* @augments Backbone.View
*/
var RelatedItemView = BaseView.extend({
        
        /**
        * This property represents the default template in RelatedItemView.
        * @name template
        * @type JSON
        * @default NewsonDetailTemplate.verticallist
        * @fieldOf RelatedItemView.prototype
        */
		template : NewsonDetailTemplate.verticallist,
        
        /**
         * This property represents the news' map on the news collection.
         * @name cacheMap
         * @type Array
         * @default []
         * @fieldOf RelatedItemView.prototype
         */
		cacheMap : [],
        
        /**
         * This property represents the news' map without current news.
         * @name map
         * @type Array
         * @default []
         * @fieldOf RelatedItemView.prototype
         */
		map : [],
        
        /** Initialize RelatedItemView. 
        * @function initialize
        * @param {Array}  map                  	- the detail news' map
        * @memberof RelatedItemView
        */
        initialize : function (map) {
			relatedItemViewSelf = this;
        	this.cacheMap = map;

            //KPI start
            this.KPISelectRelatedNews = new KPIOptions.SelectRelatedNews(this);
            //this.itemPositionVisible = 1;
            //KPI end
            this.initList = _.bind(__initList, this);
        },
		
        /** render RelatedItemView. 
        * @function render
        * @memberof RelatedItemView
        */
		render : function (parent) {
			//relatedItemViewSelf = this;
			//use resizeablelist to render related list
			var grid = null; //__initGrid();
			grid = PanelCommon.loadTemplate(this.template, null, parent);
            this.initList(grid);
            this.setWidget(grid);
            Volt.Nav.setNextItemRule(this.widget,"down",this.widget);
            grid.onFocusChange = function(oldIndex, newIndex){
                if (1 == DeviceModel.getMenuTTS() && newIndex != -1){
                    var position = -1, tile = null, count = 0;
                    if(relatedItemViewSelf.relatedCollection !== null && relatedItemViewSelf.relatedCollection.length > 0) {
                        position = newIndex;
                        tile = relatedItemViewSelf.relatedCollection.at(position);
                        count = relatedItemViewSelf.relatedCollection.length;
                    } else {
                        position = relatedItemViewSelf.map[newIndex % relatedItemViewSelf.map.length];
                        tile = detailViewSelf.tileCollection.at(position);
                        count = relatedItemViewSelf.map.length - 1;
                    }
                    var voiceText = tile.get('title');
                    if (-1 == oldIndex){
                        var item = (1 == count) ? 'item' : 'items';
                        voiceText = 'News List, ' + count + ', ' + item + ', ' + voiceText;
                    }
                    Global.voiceGuide(voiceText);
                }
                //KPI start
                if ((oldIndex < newIndex) && (relatedItemViewSelf.itemPositionVisible<4)){
                        	relatedItemViewSelf.itemPositionVisible++;
                }else if ((oldIndex > newIndex) && (relatedItemViewSelf.itemPositionVisible>1)){
                    relatedItemViewSelf.itemPositionVisible--;
                }
                //KPI end
            };
            grid.onDrawLoadData = function(thumbnail,data, parentWidth, parentHeight)
            {
                data.root = thumbnail;
                createRelatedItem(thumbnail,data.index, data.model);
            };
            
            grid.onDrawUpdateData = function(widget,data,parentWidth,parentHeight)
            {
                //createRelatedItem(data.index, widget, data.model);
            };
            
            grid.onItemMouseClick = function(index)
            {
                grid.onItemPress(index);
            };
            
            grid.onItemPress = function(index)
            {
                var widget = relatedItemViewSelf.dataCollection[index].root;
                if(-1 == DeviceModel.getNetWorkState()){	
					ErrorHandler.show(CommonDefines.PopupType.NETWORK_ERROR1,505);
					return;
				}
			
				if (index >= 0) {
					//switch view when press item of the related list
					//this.model = newsCollection.at;
                    //only happened want exclude news (index==5)
					var length = Backbone.history.location.history.length;
                    var postion = -1;
                    if(relatedItemViewSelf.relatedCollection !== null && relatedItemViewSelf.relatedCollection.length > 0) {
                        postion = index;
                    } else {
                        postion = relatedItemViewSelf.map[index % relatedItemViewSelf.map.length];
                    }
                    if (length > 1) {
                        //KPI start
                        var tile = null;
                        if(relatedItemViewSelf.relatedCollection !== null && relatedItemViewSelf.relatedCollection.length > 0) {
                            tile = relatedItemViewSelf.relatedCollection.at(postion);
                        } else {
                            tile = detailViewSelf.tileCollection.at(postion);
                        }
                        relatedItemViewSelf.KPISelectRelatedNews.send({sp : 'S-P-' + relatedItemViewSelf.itemPositionVisible.toString(),
                        								cl : 'C-L-' + (index+1).toString(),
                        								ct : tile.get('tile_type'),
                        								ai : tile.get('id'),
                        								at : tile.get('title')});
                        //KPI end
                    	var url = Backbone.history.location.history[length - 1];
                        //save scene color
						var thumbnail = relatedItemViewSelf.dataCollection[index].root;
						
						if (thumbnail && thumbnail.getInformationColorPicking) {						
							
							var color = thumbnail.getInformationColorPicking();							
							Volt.log("backcolor:color.r " + color.r);
							Volt.log("backcolor:color.g " + color.g);
							Volt.log("backcolor:color.b " + color.b);
							Volt.log("backcolor:color.a " + color.a);
							color.a = 255;
							scene.color = color;
							
						}
                        //scene.color = thumbnail.getChild(1).color;
                        detailViewSelf.sceneColorMgr.push({r:scene.color.r, g:scene.color.g, b:scene.color.b});
                        //end save scene color
                    	// need improvement,maybe more options could be passed
                    	Backbone.history.location.history[length - 1] = url.replace(/<(?:.|\n)*?>/gm, '<' + postion + '>');
                        //cache url for have related news
                        detailViewSelf.urlCacheMgr.push(tile.get('detail_url'));
                        
                    	Backbone.history.navigate('detail/' + tile.get('id') + '/' + '<-1>', {
                    		trigger : true
                    	});
                        
                    }
                } else {
                    Volt.log('index is invalid' + index);
                }
            };
            
            grid.onDrawFromFocusChangeStart = function(widget, data, parentWidth, parentHeight)
            {
                //widget.getChild(1).getChild(0).killFocus();
            };
            
            grid.onDrawToFocusChangeEnd = function(widget, data, parentWidth, parentHeight)
            {
               // widget.getChild(1).getChild(0).setFocus();
            };
            var _initScrollBar = function (width,height)
            {
                var scroll = new Scroll({
                    parent: scene,
                    width: 1920*0.00463, //initial scroll bar width
                    height: 1080,   //initial scroll bar height
                    direction: "vertical" 
                });

                print(' ***********loadTemplate********gridlist.setScrollBar********  ');
                scroll.setPosition(324-23, 0);
                scroll.setBackgroundColor(220, 220, 220, 51);
                scroll.setTrackShadowColor(0, 0, 0, 51);
                scroll.setTrackShadowHeight(2);

                scroll.setPointingNormalThumbImage(Volt.getRemoteUrl("images/1080/scroll/keyscreen_scroll_pn.png"));
                scroll.setPointingNormalThumbSize(4, 36);

                scroll.setPointingOverThumbImage(Volt.getRemoteUrl("images/1080/scroll/keyscreen_scroll_po.png"));
                scroll.setPointingOverThumbSize(40, 20);

                scroll.setPointingFocusThumbImage(Volt.getRemoteUrl("images/1080/scroll/keyscreen_scroll_pf.png"));
                scroll.setPointingFocusThumbSize(40, 20);

                scroll.setMinValue(0);
                scroll.setMaxValue(100);
                scroll.setValue(0);

                scroll.setRolloverTrackHeight(37);
                scroll.show();
                
                return scroll;
            }
            print('');
            var scroll = _initScrollBar(grid.width,grid.height);
            
            grid.attachScrollBar(scroll);
            grid.focusImageSetted = false;
			grid.hide();
			return this;
		},
		dataCollection : [],
        relatedCollection : null,
        /** show RelatedItemView. 
        * @function show
        * @param {JSON}  options                  	- the options passed from other view
        * @memberof RelatedItemView
        */
		show : function (options,relatedCollection) {
			this.map = [];
			this.map = this.cacheMap.slice(0);
            this.relatedCollection = null;
            if(relatedCollection !== undefined)
            {
                this.relatedCollection = relatedCollection;
            }
			
            if(this.relatedCollection === null) {
                //remove the show news in map
                var index = -1;
                var indexInTileCollection = -1;
                for(var i = 0; i < detailViewSelf.tileCollection.length;i++)
                {
                    print('detailViewSelf.tileCollection.at'+i+'id'+detailViewSelf.tileCollection.at(i).id);
                    print('options.id'+options.id);
                    if(detailViewSelf.tileCollection.at(i).id === options.id){
                        indexInTileCollection = i;
                        break;
                    }
                }
                for (var i = 0; i < this.map.length; i++) {
                    
                    if (this.map[i] == indexInTileCollection) {
                        index = i;
                    }
                }
                if (index != -1)
                    this.map.splice(index, 1);
            }
			
            var length = this.map.length <= 15 ? this.map.length : 15;
            length--;//setItem length need exclude news index == 5;
            
            if(this.relatedCollection !== null)
            {
                length = this.relatedCollection.length
            }
            
            if(this.widget.numOfItem() > 0)
            {
                this.widget.deleteItem({fromItem:0,  itemNum:this.widget.numOfItem()});
            }
            this.dataCollection = [];
            this.widget.addItem({itemNum:length, itemSpace:292});
            for(var i = 0; i < length;i++)
            {
                var data = new Data();
                data.index = i;
                data.parent = this.widget;
                if(this.relatedCollection !== null) {
                    data.model = this.relatedCollection.at(i);
                } else {
                    data.model = detailViewSelf.tileCollection.at(this.map[i]);
                }
                data.root = null;
                data.isReady = false;
                this.dataCollection.push(data);
                this.widget.addData(data);
            }
            this.widget.loadData();
            if(length > 0) {
                if (options.focus != '<-1>') {
                    var index = -1;
                    var focusIndex = parseInt(options.focus.replace("<", '').replace(">", ''));
                    for (var i = 0; i < this.map.length; i++) {
                        if (detailViewSelf.tileCollection.at(this.map[i]) == detailViewSelf.tileCollection.at(focusIndex)) {
                            index = i;
                            break;
                        }
                    }
                    //if have related news ,modify focus index
                    if(this.relatedCollection && this.relatedCollection.length > 0)
                    {
                        index = focusIndex;
                    }
                    
                    if (index >= 0) {
                        if(detailViewSelf) {
                            detailViewSelf.lastFocus = null;
                        }
                        this.widget.focusItemIndex = index;
                        if(Global.APP_STATUS === Global.APP_ACTIVE) {
                            Volt.Nav.focus(this.widget);
                        } else if (Global.APP_STATUS === Global.APP_DEACTIVATE) {
                            detailViewSelf.lastFocus = this.widget;
                        } else {
                            Volt.Nav.focus(this.widget);
                        }
                        
                    }
                } else {
                    if(contentViewSelf && contentViewSelf.scrollTotal <= 1) {// when page count <=1 set Focust
                        this.widget.focusItemIndex = 0;
                        if(detailViewSelf) {
                            detailViewSelf.lastFocus = null;
                        }
                        if(Global.APP_STATUS === Global.APP_ACTIVE) {
                            Volt.Nav.focus(this.widget);
                        } else if (Global.APP_STATUS === Global.APP_DEACTIVATE) {
                            if(detailViewSelf)
                                detailViewSelf.lastFocus = this.widget;
                        } else {
                            Volt.Nav.focus(this.widget);
                        }
                    }
                }
            } else {
                this.widget.focusable = false;
            }
            this.widget.show();
            //KPI start
            print('[kpi]reset itemPositionVisible to 1');
            this.itemPositionVisible = 1;
            //KPI end
        },
		
        hide : function()
        {
            this.widget.focusItemIndex = 0;
            this.widget.hideFocus("false");
            this.widget.hide();
        },
        
		events : {
			'NAV_FOCUS' : 'onFocus',
			'NAV_BLUR' : 'onBlur'
		},
		
        /** relatedItemView's selected callback. 
        * @function onSelect
        * @param {Widget}  widget                  	- the widget is selected
        * @memberof RelatedItemView
        */
		onSelect : function (widget) {},
		
        /** relatedItemView's focus callback. 
        * @function onFocus
        * @param {Widget}  widget                  	- the widget is focused
        * @memberof relatedItemView
        */
		onFocus : function (widget) {
			if (widget === undefined)
				return;
            if(!widget.focusImageSetted){
                widget.setFocusImage(Volt.getRemoteUrl("images/1080/icon/focus_grid.png"), 0, 0);
                widget.focusImageSetted = true;
            }
			widget.enableFocus();
            widget.setFocus();
            widget.showFocus("false");
		},
		
        /** relatedItemView's blur callback. 
        * @function onBlur
        * @param {Widget}  widget                  	- the widget is blurred
        * @memberof relatedItemView
        */
		onBlur : function (widget) {
			if (widget === undefined)
				return;
            Volt.log();
            widget.hideFocus("false");
		},
	});
var getRenderer = function(singleList,parentWidth, parentHeight, data) {

	print("~~~~~~~~~~~~~~render root parent w  h " + parentWidth + "  :" + parentHeight);
    
	var renderer = new Renderer(parentWidth, parentHeight);
	
	renderer.root = new Widget({
		x : 0,
		y : 0,
		width : parentWidth,
		height : parentHeight,
		parent : scene,

	});
	renderer.root.show();
	
	PanelCommon.loadTemplate(NewsOnDetailCommonTemplate.RelatedItem, null, renderer.root);
	renderer.thumbnail = renderer.root.getChild(0).getChild(2);
    var thumbListener = new ThumbnailListener;
    thumbListener.onImageReady = function (thumbnail, id, success) {
        if(success) {
            var backColor = thumbnail.getInformationExtractColor();		
            Volt.log("backcolor:color.r " + backColor.r);
            Volt.log("backcolor:color.g " + backColor.g);
            Volt.log("backcolor:color.b " + backColor.b);	
            backColor.a = 153;
            thumbnail.setInformationTextColor('text1',backColor);
            thumbnail.setInformationTextColor('text2',backColor);
        }
    }
    renderer.thumbnail.addThumbnailListener(thumbListener);	
	renderer.onDraw = function(rendererInstance,drawTypeString, data, parentWidth, parentHeight) {
		if (!data) {
			return;
		}

		if ("LoadData" == drawTypeString) {
			
			//response the callback onDrawLoadData to draw on listitem
			singleList.onDrawLoadData(rendererInstance.thumbnail,data, parentWidth, parentHeight);
			print("~~~~~~~~~~~~~~renderer.onDraw     LoadData       " );

		}
		else if("UpdateData" == drawTypeString)
        {
			//response the callback onDrawUpdateData to update on listitem
			singleList.onDrawUpdateData(rendererInstance.root,data,parentWidth,parentHeight);
			print("~~~~~~~~~~~~~~renderer.onDraw     UpdateData       " );
        }
		else if("FromItemFocusChangeAniStart" == drawTypeString)
        {
            //The from item of focus change motion start
			singleList.onDrawFromFocusChangeStart(rendererInstance.root,data,parentWidth,parentHeight);
			//print("~~~~~~~~~~~~~~renderer.onDraw     FromItemFocusChangeAniStart       " );
        }
        else if("ToItemFocusChangeAniEnd" == drawTypeString)
        {
            //The to item of focus change motion end
			singleList.onDrawToFocusChangeEnd(rendererInstance.root,data,parentWidth,parentHeight);
			//print("~~~~~~~~~~~~~~renderer.onDraw     ToItemFocusChangeAniEnd       " );
        }
	};

	renderer.onResize = function(rendererInstance,data, destWidth, destHeight, flagWithAni, duration) {
		if ("withAni" == flagWithAni) {
		} else if ("noAni" == flagWithAni) {
		}
	};

	renderer.onUpdate = function(width, height) {

	};

	renderer.onRelease = function() {
		print("~~~~~~~~~~~~~~render onRelease " + renderer.root.getChildCount());
		renderer.root.destroy();
		delete renderer;
	};

	return renderer;
};

function itemClicked(singleLineList, itemIndex) {

		var index = itemIndex;	

        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']   index    ' + index);
		
		//response the callback onItemMouseClick to mouse click on listitem
	    singleLineList.onItemMouseClick(index);
};

function __initList(singleList)
{
    var rendererProvider = new RendererProvider;
    
	rendererProvider.funcGetRenderer = function(parentWidth, parentHeight, data) {
		return getRenderer(singleList,parentWidth, parentHeight, data);
	};

	singleList.setRendererProvider(rendererProvider);

	var singleLineListener = new SingleLineListControlListener;
	singleLineListener.onItemClicked = itemClicked;

	

	


	/*******************set call back api from common-module begin******************/
	//callback to draw list item
	singleList.onDrawLoadData = function(thumbnail,data, parentWidth, parentHeight){};
	//callback to response "enter" key press
	singleList.onItemPress = function(index){};
	//callback to response update list item
	singleList.onDrawUpdateData = function(widget,data, parentWidth, parentHeight){};
	//callback to response focus change start( from item)
	singleList.onDrawFromFocusChangeStart = function(widget,data, parentWidth, parentHeight){};
	//callback to response focus change start( to item)
	singleList.onDrawToFocusChangeEnd = function(widget,data, parentWidth, parentHeight){};
	//callback to response mouse click
	singleList.onItemMouseClick = function(groupIndex,index){};
    
    singleList.onFocusChange = function(fromItemIndex, toItemIndex){};
    
    singleLineListener.onFocusChanged = function(singleLineList, fromItemIndex, toItemIndex)
    {
        singleLineList.onFocusChange(fromItemIndex,toItemIndex);
    };
    
    singleList.addListListener(singleLineListener);

	
	/*******************set onkeyevent process begin******************/
	this.onKeyEvent = function (keycode, keytype) {
		var ret = false;
		
		if (keytype == Volt.EVENT_KEY_RELEASE) {
            
			return ret;
		}		
		
    	switch(keycode) {
			case Volt.KEY_JOYSTICK_UP:
				ret =  singleList.moveFocus("Up");
				break;
			case Volt.KEY_JOYSTICK_DOWN:
				ret =  singleList.moveFocus("Down");
				break;	
			case Volt.KEY_JOYSTICK_LEFT:
				//ret =  singleList.moveFocus("Left");
                ret = false;
				break;	
			case Volt.KEY_JOYSTICK_RIGHT:
				ret =  singleList.moveFocus("Right");
				break;	
			case Volt.KEY_JOYSTICK_OK:{
				var index = singleList.focusItemIndex;
	        	print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']   singleList.focusItemIndex    ' + singleList.focusItemIndex);
				if ( index == undefined){
					index = 0;
				}
			    singleList.onItemPress(index);
			    ret = true;
			}
			break;

			default:
			// to do
			break;
		}
        print('single list onkeyevent return '+ret);
		return ret;
	}
    singleList.enlargeFocusedItem(20, 20);
    singleList.shadowEffectFlag = false;
    //singleList.setAnimationDuration("focusMove" , 300)
	singleList.onKeyEvent =  this.onKeyEvent.bind(this);
}

/**
 * append related news into grid list.
 * @function
 * @param {Number} index   - the index of related news
 * @param {Widget} widget   - the widget of related news
 * @param {Backbone.Model} model   - the model of related news
 */

function createRelatedItem(thumbnail,index, model) {
    
	print('createRelatedItem---------');
    var occurStamp = model.get('stringstamp');
    if(occurStamp === undefined || occurStamp === null)
    {
        var last_utc_timestamp = Math.round(new Date(model.get('timestamp')).getTime()/1000);
        var now_utc_timestamp = detailViewSelf.newsDetailModel.get('now_utc_timestamp');
        occurStamp = Global.getOccurStamp(now_utc_timestamp, last_utc_timestamp);
    }
    var imgUrl = model.get('img_url');
    if(CPAPI.getServiceType() == 'sina_huafeng')
    {
        if(imgUrl === null || imgUrl.length ===0)
        {
            imgUrl = NewsonMainDetailTemplate.main_detail_default[index%8];
        }
    }
   /*var mustache = {
		imgUrl : model.get('img_url'),
		title : model.get('title').replace(/(?:\r\n|\r|\n)/g, ''),
		timestamp : model.get('source')+' - ' + occurStamp,
	};	*/
	thumbnail.setContentImage(imgUrl);
	thumbnail.setInformationText('text1',(model.get('title').replace(/(?:\r\n|\r|\n)/g, '')));
	thumbnail.setInformationText('text2',(model.get('source')+' - ' + occurStamp));


}
exports = DetailView;
