﻿// Include libraries
var _ = Volt.require('modules/underscore.js')._;
var Backbone = Volt.require('lib/volt-backbone.js');
var VoltJSON = Volt.require('modules/VoltJSON.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var Q = PanelCommon.Q;
var voltapi = Volt.require('modules/voltapi.js');

var BaseView = PanelCommon.BaseView;
// Include templates
var WeatherTemplate = Volt.requireAppTemplate('newson-weather-template.js');
var WeatherDetailModel = Volt.require('app/models/weatherDetailModel.js');
var WeatherSettingViewModel = Volt.require('app/models/newson-weather-setting-model.js');
//var LoadingWidget = Volt.require('app/common/LoadingWidget.js');
var LoadingDialog = Volt.require('app/views/loading-view.js');
var DeviceModel = Volt.require('app/common/deviceModel.js');
var WeatherImageTemplate = Volt.requireAppTemplate('newson-weather-detail-image-template.js');
//Require dim view
var dimView = PanelCommon.requireView('dim');
//Require customization function 
var customizationIcon = Volt.require('app/common/customization-icon.js');
//Require Utility
var utility = new Utility;
var Global = Volt.require('app/common/Global.js');

//Require GlobalMediator
var GlobalMediator = Volt.require('app/common/GlobalMediator.js');
//Require common defines
var CommonDefines = Volt.require('app/common/commonDefines.js');
//KPI log
var KPI = Volt.require('app/common/kpi-options.js');
var KPIOptions = KPI.WeatherDetail;

var weatherBaseView = BaseView.extend({	
	destroy : function(widget){
	
		if(!widget) {
			return;
		}
		var nChildLength = widget.getChildCount();
		if(nChildLength > 0)
		{
			for(var i = 0; i < nChildLength; i++)
			{
				this.destroy(widget.getChild(i));
			}
		}
		widget.id = '';
		widget.destroy();
		delete widget;
		widget = null;
		
		},
});

var HomeMediator = _.clone(Backbone.Events);

var selfDetail = null;
var weatherTileModel = null;
var isEnterFromMainView = true;
var WeatherDetailView = weatherBaseView.extend({
    template: WeatherTemplate.container,
    model:null,
    contentView:null,
    container:null,
    IsDeepLink : false,
    initialize:function() {	
        Volt.log();
        this.model = WeatherDetailModel;		
        this.loadingDialog = LoadingDialog;
        selfDetail = this;	
        //KPI
        this.KPIMovePrevious = new KPIOptions.MovePrevious(this);
        this.KPIMoveNext = new KPIOptions.MoveNext(this);
    },
    render: function() {
        Volt.log('weather.render');	
		this.setWidget(VoltJSON.load(this.template));
		//this.renderContent();			

    },

	onComplete:function(object, staus){
		Volt.log();
		if(staus == 'success'){		
			this.loadingDialog.hide();
			this.widget.show();
			selfDetail.updateContent();
			Volt.Nav.setRoot(selfDetail.widget);
			Volt.Nav.focus(Volt.Nav.getItem(0));
		}
	},
	
	renderContent: function() {	
		Volt.log();		
		selfDetail.container = selfDetail.widget.getChild('weather-content-container');
		selfDetail.contentView =  new ContentView();
		selfDetail.container.addChild(selfDetail.contentView.render().widget);
    },	
    
    /**
     * @description Render the return button.
     * @function renderReturnButton
     * @memberof WeatherDetailView
     * @return None
     */
    renderReturnButton : function() {
        this.returnButton = this.widget.getDescendant('newson-weather-detail-return-button');
        customizationIcon(this.returnButton, {
            imageStyle : 'pageReturn'
        });
        this.returnButton.onMouseClick = this.returnFun;
    },
    
    /** pause the main view Invoked when some popup view popup over this View
     * @function onChangeCursor
     * @memberof DetailView
     */
     onChangeCursor : function(visible){
         if( this.returnButton ){
             if(visible){
                 this.returnButton.show();
             }else{
                 this.returnButton.hide();
             }
         }
     },
	
	updateContent: function() {	
		Volt.log();
		
		if(-1 == DeviceModel.getNetWorkState()) {			
			Volt.Nav.focus(null);
			var ErrorHandler = Volt.require('app/common/errorHandler.js');
			ErrorHandler.show(CommonDefines.PopupType.NETWORK_ERROR1,505,selfDetail.returnFun);
			return;
		}		

		selfDetail.contentView.update(selfDetail.model);		
    },	
	
    show: function(options, animationType) {
		if (false == this.loadingDialog.isLoading){
		    this.loadingDialog.show(1);
        }
        var deferred = Q.defer();
		
        if (options.hasOwnProperty('isDeepLink') && options.isDeepLink){
            this.IsDeepLink = options.isDeepLink;
            this.model.setInitData(options.cid);
        } else {
		    this.model.setInitData();
        }
        
		this.model.set('cityIdx', parseInt(options.id));	
		this.listenTo(this.model, 'complete', this.onComplete);
		this.listenTo(this.model, 'change:cityIdx', this.updateContent);
		this.listenTo(this.model, 'error', this.errorHandle);		

        /*if (false == this.loadingDialog.isLoading){
		    this.loadingDialog.show(1);
        }*/
		this.model.fetch({});
		Volt.log('options.id:'+ options.id);
		print(typeof options.weatherTile);
		weatherTileModel  = options.weatherTile;
		
		isEnterFromMainView = true;
		
		//this.setWidget(VoltJSON.load(this.template));
		this.renderContent();		
		this.renderReturnButton();
		
		if( !voltapi.vconf.getValue(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE)){
            this.returnButton.hide();
        } else {
            this.returnButton.show();
        }

        this.listenTo(GlobalMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, this.onChangeCursor);

        //this.setWidget(VoltJSON.load(this.template));
		
        //Volt.Nav.setRoot(this.widget);
        //Volt.Nav.focus(Volt.Nav.getItem(0));
		
		//this.widget.show();
        deferred.resolve();
        if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
        {
            print('wether detail view show');
            print(VDUtil.getProcMemory());
        }
        return deferred.promise;
    },
	
    hide : function(options, animationType){
        var deferred = Q.defer();	
        this.stopListening(GlobalMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR);
        selfDetail.widget.hide();	

		selfDetail.stopListening();
		selfDetail.loadingDialog.hide();
		if(selfDetail.contentView) {
			selfDetail.contentView.destroy(selfDetail.container);
		}
		//selfDetail.destroy(selfDetail.widget);
		/*if(self && self.dayView && self.dayView.widget) {
			self.dayView.destroy(self.dayContainer); 		
		}*/
        deferred.resolve();
        if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
        {
            print('wether detail view hide');
            gc();
            print(VDUtil.getProcMemory());
        }
        return deferred.promise;
    },
	
	/** callback of WeatherDetail view's model if the WeatherDetail view model fetch error. 
	* @function show
    * @param {Object}  object                  	- the http request object
	* @param {string}  status          		- show the http request's status
    * @param {string}  exception                  	- pass the exception
	* @memberof WeatherDetail
	*/
    errorHandle : function(object, status, exception) {
		Volt.log('errorHandle');
        selfDetail.loadingDialog.hide();
        var ErrorHandler = Volt.require('app/common/errorHandler.js');
        if (this.IsDeepLink){
            ErrorHandler.show(CommonDefines.PopupType.SERVER_ERROR2, 404, function(){
                Volt.exit();
            });
        }else {
		    ErrorHandler.show(CommonDefines.PopupType.SERVER_ERROR2, 404, selfDetail.returnFun);
        }
    },
	

	returnFun : function() {
		Backbone.history.back();
    },
	
        /**
         * pause the main view Invoked when some popup view popup over this View
         * @function
         * @memberof MainView
         */
        pause : function() {
            Volt.log();
            dimView.show({
                parent: scene
            });
        },

        /**
         * Invoked when come back from popup
         * @function
         * @memberof MainView
         */
        resume : function() {
            Volt.log();
            dimView.hide();
        }
});

var self = null;

var ContentView = weatherBaseView.extend({
    template: WeatherTemplate.weathercontent,
	backgoundImageList:[],
	imageBgWgtList:[],
	//imageDefaultBgWgtList:[],
	imageCurrentConditionList:[],	
	imageSourceIconList:[],
	bgColorPickList:[],
	dayView:null,
	dayContainer:null,
	iCurWeatherDetailCityModel:null,
	isWidgetReady:false,
	isDestroying:false,
	    
    render: function(model) {
        Volt.log('renderContent');
		self  = this;
	
		self.setWidget(PanelCommon.loadTemplate(self.template));
		Volt.Nav.reload();
				
		self.arrowLeft = self.widget.getChild('image_arrow_left_unfocus');
		//self.arrowLeftFocus = self.widget.getChild('image_arrow_left_focus');
	
		self.arrowRight = self.widget.getChild('image_arrow_right_unfocus');
		//self.arrowRightFocus = self.widget.getChild('image_arrow_right_focus');

		
		var textCityTitle = self.widget.getChild('text-city-title');
		var textPageIndex = self.widget.getChild('text-page-index');
		textCityTitle.x = (DeviceModel.get('resolutionX') - textCityTitle.width)/2;
		textPageIndex.x = textCityTitle.x + textCityTitle.width + WeatherTemplate.constNum.indexSpace;
		
		self.dayContainer = self.widget.getChild('weather-day-container');
		self.dayView = new DayView();
		self.dayContainer.addChild(self.dayView.render().widget);
		
		self.widget.hide();

		//self.judgeFocus();	
        self.widget.custom = {};
		self.widget.custom.focusable = true;
		self.widget.onKeyEvent = function(keycode, type)
		{
			Volt.log(keycode + ' ' + type);

			if(type == Volt.EVENT_KEY_RELEASE){					
				return false;
			}	

			if(isEnterFromMainView) {		
				Volt.log('isEnterFromMainView is not ready');	
				return false;
			}	

			if(!self.isWidgetReady) {		
				Volt.log('widget is not ready');	
				return false;
			}				
			/* //For loading, if needless, please delete
			 if(self.timer) {
			    Volt.log('clearTimeout - ' + self.timer);
                Volt.clearTimeout(self.timer);
                self.timer = null;
            }*/
			switch(keycode) {
			    case Volt.KEY_RETURN:
				{
			        return false;
				}
				case Volt.KEY_JOYSTICK_LEFT:
				{
				    if(self.total === 1) {

				        return true;
				    }		
											
					if(self.index == 1)
					{
						self.index = self.total;						
					}		
					else {
						self.index--;
					}
                    //KPI start
                    selfDetail.KPIMovePrevious.send();
                    //KPI end
					self.switchToNext(self.index);						

					break;
				}
				case Volt.KEY_JOYSTICK_RIGHT:
				{		
				    if(self.total === 1) {
                        return true;
                    }							
									
					if(self.index == self.total) {
						self.index = 1;
					}
					else {
					
						self.index++;						
					}

                    //KPI start
                    selfDetail.KPIMoveNext.send();
                    //KPI end
					self.switchToNext(self.index);				
					break;
					
				}
				case Volt.KEY_JOYSTICK_OK:
				{				
					break;
				}
				
			    default:
			        break;
			}			

			return true;
		};	


		self.arrowLeft.addEventListener('OnMouseOver', function()
		{
			Volt.log('arrowRight OnMouseOver');
			if(1 === self.total) {
				return;
			}	
			self.arrowLeft.opacity = 255;
			//self.setArrowLeftFocus();
			//self.setarrowRight();
		});
		
		self.arrowRight.addEventListener('OnMouseOver', function()
		{
			Volt.log('arrowRight OnMouseOver');
			if(1 === self.total) {
				return;
			}	
			self.arrowRight.opacity = 255;
			//self.setArrowRightFocus();
			//self.setarrowLeft();
		});
		
		self.arrowLeft.addEventListener('OnMouseClick', function()
		{
			Volt.log('arrowLeftFocus OnMouseClick');
			if(1 === self.total) {
				return;
			}	
			
			if(self.index == 1)
			{
				self.index = self.total;						
			}		
			else {
				self.index--;
			}
            //KPI start
            selfDetail.KPIMovePrevious.send();
            //KPI end
			self.switchToNext(self.index);	
		});
		
		
		self.arrowRight.addEventListener('OnMouseClick', function()
		{
			Volt.log('arrowRightFocus OnMouseClick');
			if(1 === self.total) {
				return;
			}	
			if(self.index == self.total) {
				self.index = 1;
			}
			else
			{
				self.index++;						
			}
            //KPI start
            selfDetail.KPIMoveNext.send();
            //KPI end
			self.switchToNext(self.index);	
		});	
		
		
		self.arrowLeft.addEventListener("OnMouseOut", function()
		{
			Volt.log('arrowLeftFocus OnMouseOut');
			if(1 === self.total) {
				return;
			}	
			self.arrowLeft.opacity = 150;
			//self.setarrowLeft();
		});
		
		self.arrowRight.addEventListener("OnMouseOut", function()
		{
			Volt.log('arrowRightFocus OnMouseOut');
			if(1 === self.total) {
				return;
			}	
			self.arrowRight.opacity = 150;
			//self.setarrowRight();
		});
		
        return self;
    },	
	
	update: function(model) {
        Volt.log('update weather');
		self.isWidgetReady = false;
		self.widget.show();
		self.model = model;	
		var iWeatherDetailCityCollection = model.get('weatherDetailCityCollection');
		self.index = model.get('cityIdx')+1;	
		
		self.total = iWeatherDetailCityCollection.length;		
		Volt.log('this.index:'+self.index +'this.total:'+self.total);
		
		if(0 == self.total) {
			Volt.log('title collection length is 0!');
			return;
		} else if(1 == self.total) {
			if(self.arrowLeft) {
				self.arrowLeft.opacity = 0;
			}
			if(self.arrowRight) {
				self.arrowRight.opacity = 0;
			}
		}
		
		
		if(self.index > self.total){
			Volt.log('error:this.index: is larger than this.total');
			return;
		}		
		 
		if(isEnterFromMainView) {
			//isEnterFromMainView = false;
			var imageBgContainer = self.widget.getChild('image-bg-container');
			self.imageConditionContainer = self.widget.getChild('image-condition-container');
			self.imageSourceIconContainer = self.widget.getChild('image-source-container');
			
			var thumbListener = new ThumbnailListener;
			thumbListener.onImageReady = function (thumbnail, id, success) {
				print("thumb" + thumbnail + " load " + success);
				
				if(self.isDestroying) {
					Volt.log("isDestroying widget");
					return;		
				}
				
				if(thumbnail.index != (self.index-1)) {
					Volt.log("index is not the same");
					return;				
				}
								
				if(success) {
					//var backColor = thumbnail.getInformationColorPicking();
					//Volt.log("backcolor:color.r " + backColor.r);
					//Volt.log("backcolor:color.g " + backColor.g);
					//Volt.log("backcolor:color.b " + backColor.b);
					
					var fontColor = thumbnail.getInformationExtractColor();	
					Volt.log("fontColor:color.r " + fontColor.r);
					Volt.log("fontColor:color.g " + fontColor.g);
					Volt.log("fontColor:color.b " + fontColor.b);					
					__colorPickingWeather(fontColor);
				
				} else {
					if('CN' != DeviceModel.get('countryCode')) {
						Volt.log("not CN and thumbnail load failed!");					
					} else {
						
						var iconName = 'weather-defaultbg-' + self.iCurWeatherDetailCityModel.get('current_condition_icon');
						var defaultImage = WeatherImageTemplate.WeatherDetailBgIconImageTemplate[iconName];						
						//thumbnail.setContentImage(defaultImage);
						Volt.log("CN defaultImage = "+defaultImage);	

						Volt.setTimeout(function(){
							thumbnail.setContentImage(defaultImage);
							},100);					
					
					}				
				}
				
			}
			
			for(var i = 0; i < self.total; i++) {		
				
				self.imageBgWgtList[i] = new Thumbnail({
					x:0,
					y:0,
					visibleStyles: (0x01 | 0x20),
					image:{src: '',
						width: scene.width,
						height: scene.height},								
						
					information:{
						x: 0,
						y: scene.height*(1 - 0.212963),
						width: scene.width,
						height: scene.height * 0.212963,
					},

				});
				
				self.imageBgWgtList[i].index = i;							
				self.imageBgWgtList[i].addThumbnailListener(thumbListener);				
				imageBgContainer.addChild(self.imageBgWgtList[i]);
				
				self.imageCurrentConditionList[i] = new ImageWidget();
				self.imageConditionContainer.addChild(self.imageCurrentConditionList[i]);
				
				self.imageSourceIconList[i] = new ImageWidget();
				self.imageSourceIconContainer.addChild(self.imageSourceIconList[i]);				
			}
		}
		
		for(var i = 0; i < self.total; i++) {
			if(self.index == (i+1)) {			
				self.imageBgWgtList[i].show();
				//self.imageBgWgtList[i].getChild(0).opacity = 0;
				
				self.imageCurrentConditionList[i].opacity = 255;
				self.imageSourceIconList[i].opacity = 255;
			} else {
				self.imageBgWgtList[i].hide();
				self.imageCurrentConditionList[i].opacity = 0;
				self.imageSourceIconList[i].opacity = 0;
			}
				//self.imageBgWgtList[i].opacity = 0;
				/*self.imageBgWgtList[i].hide();
				self.imageCurrentConditionList[i].opacity = 0;
				self.imageSourceIconList[i].opacity = 0;*/
		}		
		
		Volt.log('this.index:'+ self.index);		
		self.iCurWeatherDetailCityModel = iWeatherDetailCityCollection.at(self.index-1);	
        var iweatherTileModel = null;
        if (true == selfDetail.IsDeepLink){
            iweatherTileModel = iWeatherDetailCityCollection.at(self.index-1);
        } else if(weatherTileModel !== undefined){
			var weatherTileCollection = weatherTileModel.get('weatherTileCityCollection');
		    iweatherTileModel = weatherTileCollection.at(self.index-1);			
		} else		
		{				
			iweatherTileModel = iWeatherDetailCityCollection.at(self.index-1);
        }
		
		//self.widget.src = iCurWeatherDetailCityModel.get('background_image');
		var imageBrand = self.widget.getChild('brand-image');
		imageBrand.src = model.get('brand_img_url');
		var textPageIndex = self.widget.getChild('text-page-index');
		textPageIndex.text = self.index+'/'+self.total;
		var textCityTitle = self.widget.getChild('text-city-title');
		textCityTitle.text = self.iCurWeatherDetailCityModel.get('location');		
		var textLocalTime = self.widget.getChild('text-local-time');
		
		if('CN' !== DeviceModel.get('countryCode')) {
		    self.widget.getChild('text-temp-up').hide();
		    self.widget.getChild('text-temp-up-colon').hide();
		    self.widget.getChild('text-temp-down').hide();
            self.widget.getChild('text-temp-down-colon').hide();
		    self.widget.getChild('image-temp-up').show();
            self.widget.getChild('image-temp-down').show();
		} else {
		    self.widget.getChild('image-temp-up').hide();
            self.widget.getChild('image-temp-down').hide();
		    self.widget.getChild('text-temp-up').show();
		    self.widget.getChild('text-temp-up-colon').show();
            self.widget.getChild('text-temp-down').show();
            self.widget.getChild('text-temp-down-colon').show();
		}
		    
        //handle format time
        
        if('CN' !== DeviceModel.get('countryCode'))
        {
            var text = self.iCurWeatherDetailCityModel.get('local_time');
            text = text.replace('AM','am');
            text = text.replace('PM','pm');
            if(text.split(':').length >= 2)
            {
                var hour = parseInt(text.split(':')[0]);
                text = hour + ':' + (text.split(':')[1]);
            }
            textLocalTime.text = text;
        }
        else
        {
            var format = function(d)
            {    
                var fmt = '';
                function pad(value) {
                    return (value.toString().length < 2) ? '0' + value : value;
                }
                fmt += (d.getHours() % 12 || 12)+':';
                fmt += pad(d.getMinutes()) + ' ';
                fmt += d.getHours() < 12 ? 'am' : 'pm';
                fmt += ' CST';
                return fmt;
            };
            textLocalTime.text = format(new Date(self.iCurWeatherDetailCityModel.get('local_time')));
        }
        //end of format time
		//textLocalTime.text = iCurWeatherDetailCityModel.get('local_time');		
		var textPhotoAttribution = self.widget.getChild('text-photo-attribution');
		textPhotoAttribution.text = self.iCurWeatherDetailCityModel.get('photo_attribution');
		
		var imageCurrentCondition = self.imageCurrentConditionList[self.index-1];
		imageCurrentCondition.opacity = 255;
		//self.imageCurrentConditionChild.opacity = 0;
		
		if('CN' != DeviceModel.get('countryCode')) {	
			imageCurrentCondition.src = self.iCurWeatherDetailCityModel.get('current_condition_icon');
		}
		else {		
			if(self.iCurWeatherDetailCityModel.get('current_condition_icon') == '00' || self.iCurWeatherDetailCityModel.get('current_condition_icon') == '03') {
				if(new Date(self.iCurWeatherDetailCityModel.get('local_time')).getHours() >= 8 && new Date(self.iCurWeatherDetailCityModel.get('local_time')).getHours() < 20) {				
					var iconName = 'weathericon-small-type'+ self.iCurWeatherDetailCityModel.get('current_condition_icon') + '-1';
					imageCurrentCondition.src = WeatherImageTemplate.WeatherIconImageTemplate[iconName];	
					Volt.log('current condition1-1:icon:'+ iconName);
				} else {
					var iconName = 'weathericon-small-type'+ self.iCurWeatherDetailCityModel.get('current_condition_icon') + '-2';
					imageCurrentCondition.src = WeatherImageTemplate.WeatherIconImageTemplate[iconName];		
					Volt.log('current condition1-2:icon:'+ iconName);					
				}			
			}
			else {
				var iconName = 'weathericon-small-type'+ self.iCurWeatherDetailCityModel.get('current_condition_icon');
				imageCurrentCondition.src = WeatherImageTemplate.WeatherIconImageTemplate[iconName];
	
				Volt.log('current condition2-1:icon:'+ iconName);					
			}		
		}	
				
		var textCurrentCondition = self.widget.getChild('text-current-condition');
		textCurrentCondition.text = self.iCurWeatherDetailCityModel.get('current_conditions');	
		var textTodayHigh = self.widget.getChild('text-today-high');
		//textTodayHigh.text = iCurWeatherDetailCityModel.get('today_high_temp')+'°';
		textTodayHigh.text = Math.floor(iweatherTileModel.get('today_high_temp'))+'°';
		var textTodayLow = self.widget.getChild('text-today-low');
		//textTodayLow.text = iCurWeatherDetailCityModel.get('today_low_temp')+'°';		
		textTodayLow.text = Math.floor(iweatherTileModel.get('today_low_temp'))+'°';	
		var textCurrentTemp = self.widget.getChild('text-current-temp');
		//textCurrentTemp.text = iCurWeatherDetailCityModel.get('current_temp')+'°';
		textCurrentTemp.text = Math.floor(iweatherTileModel.get('current_temp'))+'°';
		
		
		var imageSourceIcon = self.imageSourceIconList[self.index-1];
		imageSourceIcon.opacity = 255;
		
		if('CN' != DeviceModel.get('countryCode')) {			
			imageSourceIcon.src = model.get('source_icon');		
		}
		else {
			if('' == model.get('source_icon')) {
				imageSourceIcon.src = WeatherImageTemplate.WeatherIconImageTemplate['icon_china_weather_tv_l'];	
				Volt.log('imageSourceIcon2-1:icon:'+ imageSourceIcon.src);	
			} else {			
				imageSourceIcon.src = model.get('source_icon');
				Volt.log('imageSourceIcon2-2:icon:'+ imageSourceIcon.src);	
			}
		}
		
		
		var weatherFeatures = self.iCurWeatherDetailCityModel.get('weather_features');
		
		//empty text first
		for(var i = 0; i < 3; i++) {
			var textFeatureDesc = 'text-feature-desc'+(i+1);
			var textFeatureLabelWgt = self.widget.getChild(textFeatureDesc);
			textFeatureLabelWgt.text = '';

			var textFeatureValue = 'text-feature-value'+(i+1);
			var textFeatureValueWgt = self.widget.getChild(textFeatureValue);
			textFeatureValueWgt.text = '';		
		}
		
		for(var j = 2, i = 2; i >= 0 ; i--) {
		
			if(weatherFeatures.length <= i)
			{
				continue;
			}

			if('' != weatherFeatures[i].value) {
			
				var textFeatureDesc = 'text-feature-desc'+(j+1);
				var textFeatureLabelWgt = self.widget.getChild(textFeatureDesc);
				textFeatureLabelWgt.text = weatherFeatures[i].label+' :';

				var textFeatureValue = 'text-feature-value'+(j+1);
				var textFeatureValueWgt = self.widget.getChild(textFeatureValue);
				textFeatureValueWgt.text = weatherFeatures[i].value;
				j--;
			}		
		}
		
		textCityTitle.x = (DeviceModel.get('resolutionX') - textCityTitle.width)/2;
		textPageIndex.x = textCityTitle.x + textCityTitle.width + WeatherTemplate.constNum.indexSpace;

		if(self.dayView) {
			self.dayView.update(self.iCurWeatherDetailCityModel);
		}

		var imageBg = self.imageBgWgtList[self.index-1];
		imageBg.setContentImage(self.iCurWeatherDetailCityModel.get('background_image'));			

		if(isEnterFromMainView){
			isEnterFromMainView = false;
			var fontColor = utility.extractForegroundColor(scene.color.r, scene.color.g, scene.color.b);
			__colorPickingWeather(fontColor.color);			
		}

        if (1 == DeviceModel.getMenuTTS()){
            var city = textCityTitle.text;
            var condition = textCurrentCondition.text;
            var current_temp = textCurrentTemp.text;
            var degree = ' degrees';
            if ((-1 == current_temp)||(0 == current_temp)||(1 == current_temp)){
                degree = ' degree';
            }
            var voiceText = city + ', ' + condition + ', ' + current_temp + degree;
            for (var k = 0; k < weatherFeatures.length; k++){
                voiceText = voiceText + ', ' + weatherFeatures[k].label + ', ' + weatherFeatures[k].value;
            }
            Global.voiceGuide(voiceText);
        }
		
		self.isWidgetReady = true;
		Volt.log('widget is ready');
    },	

	
	switchToNext:function(index)
	{		
		Volt.log('switchToNext');	
		if(isEnterFromMainView || !self.isWidgetReady) {		
			Volt.log('widget is not ready');	
			return;
		}
		
//		self.dayView.destroy(self.dayContainer); 
	    //__colorPickingWeather(scene);
		self.widget.hide();
		self.model.set('cityIdx',index-1);
		if(weatherTileModel !== undefined) {
			weatherTileModel.set('cityIdx',index-1);
		}
		

		return;		
	},
	
	destroy:function(contentContainer)
	{		
		self.isDestroying = true;
		for(var i = 0; i < self.total; i++) {
			self.imageBgWgtList[i].destroy();
			self.imageBgWgtList[i] = null;
			
			self.destroyChild(self.imageConditionContainer, self.imageCurrentConditionList[i]);
			self.destroyChild(self.imageSourceIconContainer, self.imageSourceIconList[i]);
		
		}
		//self.destroy(self.widget);
		if(self.dayView) {
			self.dayView.destroy(self.dayContainer); 
		}
		if(contentContainer) {	
			self.destroyChild(contentContainer, self.widget);
		}		

		//self.widget.hide();
		
		return;		
	},
	
	destroyChild:function(parentWgt,childWgt)
	{
		if(parentWgt) {
			parentWgt.removeChild(childWgt);	
			childWgt.id = '';			
			childWgt.destroy();
			childWgt = null;	
		}		
		return;		
	},
	
		

});

var selfDayView = null;
var DayView = weatherBaseView.extend({
    template: WeatherTemplate.weatherday,
	dayListTypeOne:[],
	dayListTypeTwo:[],
	containerList:[],
	dayNum:5,	
	
	render: function(dayContainer) {
        Volt.log('DayView render');
		
		selfDayView = this;						
		this.setWidget(PanelCommon.loadTemplate(this.template));
		for(var i = 0; i < this.dayNum; i++) {
		    var containerInfo = 'weather-day-container'+(i+1);
            Volt.log(containerInfo);
            this.containerList[i] = this.widget.getChild(containerInfo);
            this.dayListTypeOne[i] = new DayViewTypeOne(); 
            this.dayListTypeOne[i].render(this.containerList[i]);
            this.dayListTypeTwo[i] = new DayViewTypeTwo(); 
            this.dayListTypeTwo[i].render(this.containerList[i]);
		}
		return this;
    },
    
    update: function(curWeatherDetailCityModel) {
        Volt.log('DayView update');
		//selfDayView = this;						
		//this.setWidget(PanelCommon.loadTemplate(this.template));

		var forecasts = curWeatherDetailCityModel.get('forecasts');	
		this.dayNum =  forecasts.length;
		for(var i = 0; i < forecasts.length; i++)
		{	
			if(i > 4)
			{
				break;
			}
			
			Volt.log('weather-day-container'+(i+1));
			
			if('CN' != DeviceModel.get('countryCode')) {	
			    this.containerList[i].type = 'weatherdaytype1';
			    this.dayListTypeTwo[i].widget.hide();
				this.dayListTypeOne[i].update(forecasts[i]);
			}
			else {
			
				if (forecasts[i].forecast_conditions_icon1 != forecasts[i].forecast_conditions_icon2) {
				
					var icon1Src  = null;
					var icon2Src  = null;
				    if (forecasts[i].forecast_conditions_icon1 == '00' || forecasts[i].forecast_conditions_icon1 == '03') { 
							var icon1Name = 'weathericon-normal-type'+ forecasts[i].forecast_conditions_icon1 + '-1';
							icon1Src = WeatherImageTemplate.WeatherIconImageTemplate[icon1Name];							
					}
					else {						
						var icon1Name = 'weathericon-normal-type'+ forecasts[i].forecast_conditions_icon1;
						icon1Src = WeatherImageTemplate.WeatherIconImageTemplate[icon1Name];
					}			
					

					if (forecasts[i].forecast_conditions_icon2 == '00' || forecasts[i].forecast_conditions_icon2 == '03') { 
							var icon2Name = 'weathericon-normal-type'+ forecasts[i].forecast_conditions_icon2 + '-1';	
							icon2Src = WeatherImageTemplate.WeatherIconImageTemplate[icon2Name];									
					}
					else {						
						var icon2Name = 'weathericon-normal-type'+ forecasts[i].forecast_conditions_icon2;
						icon2Src = WeatherImageTemplate.WeatherIconImageTemplate[icon2Name];	
					}
					
					Volt.log('icontype2-1:icon1:'+ icon1Src +' icon2'+ icon2Src );

					this.containerList[i].type = 'weatherdaytype2';
					this.dayListTypeOne[i].widget.hide();
					this.dayListTypeTwo[i].update(forecasts[i], icon1Src, icon2Src);	
				}
				else {				
					var icon1Src  = null;
					var icon2Src  = null;					
				    if (forecasts[i].forecast_conditions_icon1 == '00' || forecasts[i].forecast_conditions_icon1 == '03') { 
						var icon1Name = 'weathericon-normal-type'+ forecasts[i].forecast_conditions_icon1 + '-1';
						icon1Src = WeatherImageTemplate.WeatherIconImageTemplate[icon1Name];
						var icon2Name = 'weathericon-normal-type'+ forecasts[i].forecast_conditions_icon1 + '-2';
						icon2Src = WeatherImageTemplate.WeatherIconImageTemplate[icon2Name];
						
						Volt.log('icontype2-2:icon1:'+ icon1Src +' icon2'+ icon2Src );	
					
						this.containerList[i].type = 'weatherdaytype2';
						this.dayListTypeOne[i].widget.hide();
						this.dayListTypeTwo[i].update(forecasts[i], icon1Src, icon2Src);	
					}
					else {						
						var icon1Name = 'weathericon-normal-type'+ forecasts[i].forecast_conditions_icon1;
						icon1Src = WeatherImageTemplate.WeatherIconImageTemplate[icon1Name];
						
						this.containerList[i].type = 'weatherdaytype1';
						Volt.log('icontype1-1:icon1:'+ icon1Src);
						this.dayListTypeTwo[i].widget.hide();
						this.dayListTypeOne[i].update(forecasts[i], icon1Src);	
					}				
				}			
			}
		}
				   
        return this;
    },
	
	destroy: function(dayContainer) {
        Volt.log('DayView destroy');
		
		if(dayContainer) {		
			for(var i = 0; i < selfDayView.dayNum; i++)
			{
				if(selfDayView.dayListTypeOne[i]) {
					selfDayView.dayListTypeOne[i].destroy(selfDayView.dayListTypeOne[i],selfDayView.containerList[i]);
					delete selfDayView.dayListTypeOne[i];
					selfDayView.dayListTypeOne[i] = null;
				}
				
				if(selfDayView.dayListTypeTwo[i]) {
                    selfDayView.dayListTypeTwo[i].destroy(selfDayView.dayListTypeTwo[i],selfDayView.containerList[i]);
                    delete selfDayView.dayListTypeTwo[i];
                    selfDayView.dayListTypeTwo[i] = null;
                }
			
			}
			//dayContainer.removeChild(selfDayView.widget);	
			//selfDayView.widget.id = '';			
			//selfDayView.widget.destroy();
			//selfDayView.widget = null;
		}		
		//this.setWidget(PanelCommon.loadTemplate(this.template));				   

    },
	
});


var DayViewTypeOne = weatherBaseView.extend({
    template: WeatherTemplate.weatherdaytype1,
    
    render: function(container) {
        Volt.log('DayViewTypeOne render');
				
        var day_info = {
                text_day_labe:'',
                image_forecast_conditions:'',
                text_forecast_high_temp:'°',
                text_forecast_low_temp:'°', 
            };
//		var day_info = {
//	            text_day_labe:forecastsItem.day_label,
//	            image_forecast_conditions:iconsrc,
//	            text_forecast_high_temp:forecastsItem.forecast_high_temp+'°',
//	            text_forecast_low_temp:forecastsItem.forecast_low_temp+'°', 
//	        };  

		
		this.setWidget(PanelCommon.loadTemplate(this.template, day_info, container));
		this.widget.hide();
        return this;
    },
    
    update : function(forecastsItem, icon1src){
        Volt.log('DayViewTypeOne update');
        var iconsrc = null;
        if(icon1src) {
            iconsrc = icon1src;     
        }
        else {
            iconsrc = forecastsItem.forecast_conditions_icon;
        }
        
        var text_day_label = this.widget.getChild(1);
        var image_forecast_conditions = this.widget.getChild(2);
        var text_forecast_temp = this.widget.getChild(3);
        
        text_day_label.text = forecastsItem.day_label;
        image_forecast_conditions.src = iconsrc;
        text_forecast_temp.text = Math.floor(forecastsItem.forecast_high_temp)+'°' + '/' + Math.floor(forecastsItem.forecast_low_temp)+'°';
        this.widget.show();
    },
	
	destroy: function(dataPtr,dayContainer) {
        Volt.log('DayViewTypeOne destroy');
		
		if(dayContainer) {		

			dayContainer.removeChild(dataPtr.widget);
			dataPtr.widget.id = '';			
			dataPtr.widget.destroy();
			dataPtr.widget = null;
		}		
		//this.setWidget(PanelCommon.loadTemplate(this.template));				   

    },
});


var DayViewTypeTwo = weatherBaseView.extend({
    template: WeatherTemplate.weatherdaytype2,
    
    render: function(container) {
        Volt.log('DayViewTypeTwo render');
		
		var day_info = {
			text_day_labe:'',
			image_forecast_conditions1:'',
			image_forecast_conditions2:'',
			text_forecast_high_temp:'°',
			text_forecast_low_temp:'°',	
		};	
		
//        var day_info = {
//                text_day_label:forecastsItem.day_label,
//                image_forecast_conditions1:icon1src,
//                image_forecast_conditions2:icon2src,
//                text_forecast_high_temp:forecastsItem.forecast_high_temp+'°',
//                text_forecast_low_temp:forecastsItem.forecast_low_temp+'°', 
//            };		
		
		this.setWidget(PanelCommon.loadTemplate(this.template, day_info, container));
		this.widget.hide();
        return this;
    },
    
    update : function(forecastsItem, icon1src, icon2src){
        Volt.log('DayViewTypeTwo update');

        
        var text_day_label = this.widget.getChild(1);
        var image_forecast_conditions1 = this.widget.getChild(2);
        var image_forecast_conditions2 = this.widget.getChild(3);
        var text_forecast_temp = this.widget.getChild(4);
        
        text_day_label.text = forecastsItem.day_label;
        image_forecast_conditions1.src = icon1src;
        image_forecast_conditions2.src = icon2src;
        text_forecast_temp.text = Math.floor(forecastsItem.forecast_high_temp)+'°' + '/' + Math.floor(forecastsItem.forecast_low_temp)+'°';
        this.widget.show();
    },
	
	destroy: function(dataPtr,dayContainer) {
        Volt.log('DayViewTypeTwo destroy');
		
		if(dayContainer) {		

			dayContainer.removeChild(dataPtr.widget);	
			dataPtr.widget.id = '';		
			dataPtr.widget.destroy();
			dataPtr.widget = null;
		}		
		//this.setWidget(PanelCommon.loadTemplate(this.template));				   

    },
});

function __colorPickingWeather(fontColor){
    
    //var fontColor = utility.extractForegroundColor(colorPicking.color.r, colorPicking.color.g, colorPicking.color.b);
    
    
//  __colorWidget(self.widget.getChild('brand-image'), colorPicking);
//    __textColorWidget(self.widget.getChild('text-city-title'), fontColor);
//    __textColorWidget(self.widget.getChild('text-page-index'), fontColor);
//    __textColorWidget(self.widget.getChild('text-local-time'), fontColor, 153);
//    __textColorWidget(self.widget.getChild('text-photo-attribution'),fontColor);
    //__colorWidget(self.widget.getChild('info-weather-bg'), colorPicking);
    __textColorWidget(self.widget.getChild('text-current-condition'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-current-temp'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-temp-up'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-temp-down'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-temp-up-colon'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-temp-down-colon'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-today-high'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-today-low'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-feature-desc1'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-feature-value1'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-feature-desc2'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-feature-value2'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-feature-desc3'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-feature-value3'), fontColor, 153);
    
    if(self.dayView) {
        for(var i = 0; i < selfDayView.dayNum; i++)
        {   
            if(i > 4)
            {
                break;
            }
			
			__textColorWidget( selfDayView.dayListTypeOne[i].widget.getChild(1), fontColor, 153);
            __textColorWidget( selfDayView.dayListTypeOne[i].widget.getChild(3), fontColor, 153);
			__textColorWidget( selfDayView.dayListTypeTwo[i].widget.getChild(1), fontColor, 153);
            __textColorWidget( selfDayView.dayListTypeTwo[i].widget.getChild(4), fontColor, 153);
				
            /*var type = selfDayView.containerList[i].type;
            if(type == 'weatherdaytype1') {
                __textColorWidget( selfDayView.dayListTypeOne[i].widget.getChild(1), fontColor, 153);
                __textColorWidget( selfDayView.dayListTypeOne[i].widget.getChild(3), fontColor, 153);
            } else if(type == 'weatherdaytype2'){
                __textColorWidget( selfDayView.dayListTypeTwo[i].widget.getChild(1), fontColor, 153);
                __textColorWidget( selfDayView.dayListTypeTwo[i].widget.getChild(4), fontColor, 153);
            } else {
                Volt.log('not weatherdaytype1 and not weatherdaytype2 - getChildCount : ' + widget.getChildCount());
            }*/
        }
    } else {
        Volt.log('error to colorPicking day');
    }
}

function __colorWidget(widget, color, a) {
    if(a == undefined) {
        a = 255;
    }
    if(widget) {
        widget.color = { r: color.r, g: color.g, b: color.b, a: a };
    }
}

function __textColorWidget(widget, textColor, a) {
    if(a == undefined) {
        a = 255;
    }
    if(widget) {
        widget.textColor = { r: textColor.r, g: textColor.g, b: textColor.b, a: a};
    }
}

exports = WeatherDetailView;
