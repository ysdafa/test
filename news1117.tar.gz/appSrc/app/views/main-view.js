/**
 * @author Weihua Qiu (weihua.qiu@samsung.com) / Hongjie Zhu (hongjie.zhu@samsung.com) / Yipeng Zhu (yipeng.zhu@samsung.com) / 
 * @fileoverview Description of a file
 * @date 2014/07/09 (last modified date)
 * 
 * Copyright 2012 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung.
 */

// Include libraries
var Backbone = Volt.require('lib/volt-backbone.js');

// Require Common Modules
var PanelCommon = Volt.require('lib/panel-common.js');
var BaseView = PanelCommon.BaseView;
var Q = PanelCommon.Q;
var CPAPI = Volt.require('app/common/CPAPI.js');
//var CpList = Volt.require('app/common/cpList.js');

// Include models
var ModelController = Volt.require('app/controller/model-controller.js');
var MainNewsModel = Volt.require('app/models/mainNewsModel.js');
var MoreNewsModel = Volt.require('app/models/moreNewsModel.js');
// Require Common templates of Main View
var MainTemplate = Volt.requireTemplate('main');

var ImageWidgetEx = Volt.require('app/common/Crop.js');
PanelCommon.mapWidget('ImageWidgetEx', ImageWidgetEx);

// Require Specific template for Games Main View
var NewsonMainTemplate = Volt.requireAppTemplate('newson-main-template.js');
var NewsonMainDetailTemplate = Volt.requireAppTemplate('newson-main-detail-template.js');
var NewsonWeatherDetailImageTemplate = Volt.requireAppTemplate('newson-weather-detail-image-template.js');
var containerMap = NewsonMainTemplate.containerMap;
// Require Libs
_ = Volt.require('modules/underscore.js')._;
// Create an Mediator to commumicate between Views
var MainMediator = new PanelCommon.Mediator;
var LoadingDialog = Volt.require('app/views/loading-view.js');

var DeviceModel = Volt.require('app/common/deviceModel.js');
//Require common defines
var CommonDefines = Volt.require('app/common/commonDefines.js');
//Require sub view
var dimView = PanelCommon.requireView('dim');

//Require global Variation
var Global = Volt.require('app/common/Global.js');
var GlobalMediator = Volt.require('app/common/GlobalMediator.js');
//KPI start
var KPI = Volt.require('app/common/kpi-options.js');
var KPIOptions = KPI.Home;
//KPI end

var voltapi = Volt.require('modules/voltapi.js');

////////////////////////////////////////////////////////////////////////////////
var mainViewSelf = null;
var thumbnailViewSelf = null; // can replaced by middleware MainMediator
var headViewSelf = null;
var weatherIndex = null; // for interval
var cycleSeconds = null;
var vg_byTTS = true;	//voice guide, using TTS or not

function setInterval(cb, interval, param){
	return Volt.setInterval(cb, interval, param);
}

function clearInterval(id){
	if (id !== undefined) {
		Volt.clearInterval(id);
	}
}

////////////////////////////////////////////////////////////////////////////////
/** MainView -BackboneView
* @class 
* @name MainView
* @augments Backbone.View
*/
var MainView = BaseView.extend({
    
    /**
     * This property represents the default template in MainView.
     * @name template
     * @type JSON
     * @default MainTemplate.container
     * @fieldOf MainView.prototype
     */
    template : MainTemplate.container, // Template of Main View is a container framework
    
    /**
     * This property represents the main news model reference in MainView.
     * @name model
     * @type JSON
     * @default null
     * @fieldOf MainView.prototype
     */
    model : null,
    
    /**
     * This property represents the more news model reference in MainView.
     * @name model
     * @type JSON
     * @default null
     * @fieldOf MainView.prototype
     */
    moreNewsModel : null,
    
    /**
     * This property represents the child view's reference in MainView.
     * @name contentView
     * @type Class
     * @default null
     * @fieldOf MainView.prototype
     */
    contentView : null,
    
    /**
     * This property represents main news model request status.
     * @name mainNewsStatus
     * @type string
     * @default success
     * @fieldOf MainView.prototype
     */
    mainNewsStatus : 'success',
    
    /**
     * This property represents more news model request status.
     * @name mainNewsStatus
     * @type string
     * @default success
     * @fieldOf MainView.prototype
     */
    moreNewsStatus : 'success',
    
    /**
     * This property represents whether the view show in the first time.
     * @name firstTime
     * @type bool
     * @default true
     * @fieldOf MainView.prototype
     */
    firstTime : true,
    isFresh : true,
    
    /** Initialize MainView. 
	* @function initialize
	* @memberof MainView
	*/
    
    /**
     * For record last focus in MainView
     */
    lastFocus : null,
    
    /**
     * For record the status for app status is or not active
     */
    isNeedSetFocus : false,
    
    initialize : function() {
        this.model = MainNewsModel;
        this.moreNewsModel = MoreNewsModel;
        this.loadingDialog = LoadingDialog;
        mainViewSelf = this;
        MainMediator.on(CommonDefines.Event.SHOW_OPTION_MENU, this.pause, this);
        MainMediator.on(CommonDefines.Event.HIDE_OPTION_MENU, this.resume, this);
        GlobalMediator.on(CommonDefines.Event.MAINVIEW_DATA_READY, this.renderForFirstTime, this);
        if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
        {
            print('main-view initialize mem-size'+VDUtil.getProcMemory());
        }
    },

    /** render MainView. 
	* @function render
	* @memberof MainView
	*/
    render : function() {
        Volt.log();
        // Parse the template
        this.setWidget(PanelCommon.loadTemplate(this.template, null, null, false));
        // Render everything
        this.renderHeader();
        this.renderPopup();
        //
        Volt.Nav.setRoot(this.widget,{focus:null});
        //Volt.Nav.focus(Volt.Nav.getItem(0));
        //this.listenToOnce(this.moreNewsModel, 'complete', this.contentFresh);
        //this.listenTo(this.model, 'change:update', this.updateGridList);
        this.listenTo(this.model, 'error', this.mainNewsErrorHappend);
        this.listenTo(this.moreNewsModel, 'error', this.moreNewsErrorHappend);
        if('CN' == DeviceModel.get('countryCode')){
            var WeatherSettingModel = Volt.require('app/models/newson-weather-setting-model.js');
            this.listenTo(WeatherSettingModel, 'change:weatherSettingCodeCityList', function(){
                mainViewSelf.weatherSettingCodeCityListChange = true;
            });
        }
        //Volt.Nav.pause();
        //append loading widget
        this.block();
        //end append
    },
    
    /** callback of main view's model if the main view model fetch error. 
	* @function show
    * @param {Object}  object                  	- the http request object
	* @param {string}  status          		- show the http request's status
    * @param {string}  exception                  	- pass the exception
	* @memberof MainView
	*/
    mainNewsErrorHappend : function(object, status, exception) {
        if(mainViewSelf.firstTime === true)
        {
            mainViewSelf.firstTime = false;
            mainViewSelf.lastFocus = Volt.Nav.getItem(0);
        }
        this.mainNewsStatus = status;
        this.loadingDialog.hide();
        //Volt.Nav.resume();
		this.unblock();
		Volt.Nav.focus(null);
        print('main view error');
		var ErrorHandler = Volt.require('app/common/errorHandler.js');
		ErrorHandler.show(CommonDefines.PopupType.SERVER_ERROR2,404,this.setFocusForAppStatusChange);
    },

    /** callback of more view model if the more view model fetch error. 
	* @function show
    * @param {Object}  object                  	- the http request object
	* @param {string}  status          		- show the http request's status
    * @param {string}  exception                  	- pass the exception
	* @memberof MainView
	*/
    moreNewsErrorHappend : function(object, status, exception) {
        if(mainViewSelf.firstTime === true)
        {
            mainViewSelf.firstTime = false;
            mainViewSelf.lastFocus = Volt.Nav.getItem(0);
        }
        this.moreNewsStatus = status;
        this.loadingDialog.hide();
        //Volt.Nav.resume();
		this.unblock();
		Volt.Nav.focus(null);
		var ErrorHandler = Volt.require('app/common/errorHandler.js');
		ErrorHandler.show(CommonDefines.PopupType.SERVER_ERROR2,404,this.setFocusForAppStatusChange);
    },
	
	/**
     */
    setFocusForAppStatusChange : function() {
        Volt.log('lastFocus - ' + mainViewSelf.lastFocus);
        Volt.log('Global.APP_STATUS - ' + Global.APP_STATUS);
        mainViewSelf.isNeedSetFocus = false;
        if (Global.APP_STATUS === Global.APP_DEACTIVATE) {
            mainViewSelf.isNeedSetFocus = true;
        } else {
            mainViewSelf.isNeedSetFocus = false;
            Volt.Nav.focus(mainViewSelf.lastFocus);
        }
     },
    
    /** block this view's event. 
	* @function block
	* @memberof MainView
	*/
    block : function()
    {
        Volt.Nav.block('key');
        Volt.Nav.block('mouse');
    },
    
    /** unblock this view's event. 
	* @function unblock
	* @memberof MainView
	*/
    unblock : function()
    {
        Volt.Nav.unblock('key');
        Volt.Nav.unblock('mouse');
    },
    
    /** refresh main view's content. 
	* @function contentFresh
    * @param {Object}  object                  	- the http request object
	* @param {string}  status          		- show the http request's status
	* @memberof MainView
	*/
    renderForFirstTime : function(offline) {
        Volt.log();
        mainViewSelf.optionMenuX = NewsonMainTemplate.constNum.hideCloseOptionMenuX;
        if (this.mainNewsStatus != 'success' || this.moreNewsStatus != 'success')
            return;
        /*
        if(!offline)
        {
            this.loadingDialog.hide();
        }*/
        this.loadingDialog.hide();
        this.renderCategory();
        this.renderContent();
        Volt.Nav.reload();
        if(mainViewSelf.firstTime === true)
        {
            mainViewSelf.firstTime = false;
            mainViewSelf.lastFocus = thumbnailViewSelf.widget;
        }
        mainViewSelf.setFocusForAppStatusChange();
        this.unblock();
        
        GlobalMediator.off(CommonDefines.Event.MAINVIEW_DATA_READY);
        GlobalMediator.on(CommonDefines.Event.MAINVIEW_DATA_READY, this.mainViewUpdate, this);
    },
    mainViewUpdate : function(offline)
    {
        categorySelf.trigger('refresh');
        mainViewSelf.contentView.trigger('refresh');
        if(!offline)
        {
            this.loadingDialog.hide();
        }
    },
    /** render header view 
	* @function renderHeader
	* @memberof MainView
	*/
    renderHeader : function() {
        Volt.log();
        var container = this.widget.getDescendant('main-header-container');
        container.addChild(new HeaderView().render().widget);
    },

    /** render category view 
	* @function renderCategory
	* @memberof MainView
	*/
    renderCategory : function() {
        Volt.log();
        var container = this.widget.getChild('main-category-container');
        container.addChild(new CategoryView().render(this.model).widget);
        //Volt.Nav.reload();
    },

    /** render content view 
	* @function renderContent
	* @memberof MainView
	*/
    renderContent : function() {
        Volt.log();
        var container = this.widget.getChild('main-content-container');
        this.contentView = new ContentView();
        container.addChild(this.contentView.render(this.model, this.moreNewsModel, container).widget);

    },
    
    /** render Popup view 
	* @function renderPopup
	* @memberof MainView
	*/
    renderPopup : function() {
        Volt.log();
        this.popupView || (this.popupView = new PopupView({
            'widget': this.widget.getChild('main-popup-container')
        }));
    },
    
    /** show the main view 
	* @function show
    * @param {Object}  options                  	- the parameter
	* @param {string}  animationType          		-animation type
	* @memberof MainView
	*/
    show : function(options, animationType) {
        Volt.log();
        var deferred = Q.defer();
        scene.color = Volt.hexToRgb('#0f1826');
        Volt.Nav.setRoot(this.widget,{focus:null});
        headViewSelf.listenTo(GlobalMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, headViewSelf.onChangeCursor);
        if (this.mainNewsStatus != 'success' || this.moreNewsStatus != 'success') {
            Volt.log();
            mainViewSelf.setFocusForAppStatusChange();
            if(thumbnailViewSelf !== null)
            {
                if(!mainViewSelf.loadingDialog.isLoading) // if is not refresh,we should re open the timer
                {
                    if (thumbnailViewSelf.weatherSwitchTimer === null) {
                        var weatherModel = thumbnailViewSelf.tileCollection.at(weatherIndex);
                        var iWeatherTileCityCollection = weatherModel.get('weatherTileCityCollection');
                        if (iWeatherTileCityCollection !== null && iWeatherTileCityCollection !== undefined) {
                            var model = thumbnailViewSelf.tileCollection.at(weatherIndex);
                            var iWeatherTileCityCollection = model.get('weatherTileCityCollection');
                            var cityIdx = model.get('cityIdx');
                            thumbnailViewSelf.weatherCityIdx = cityIdx;	
                            var cityModel = iWeatherTileCityCollection.at(cityIdx);
                            var data = thumbnailViewSelf.widget.getData(0, 5);
                            data.model = cityModel;
                            thumbnailViewSelf.widget.updateItem(0, 5);//update if view return from weather detail view
                            thumbnailViewSelf.weatherSwitchTimer = Volt.setInterval(thumbnailViewSelf.onWeatherCitySwitch,
                                cycleSeconds * 1000, thumbnailViewSelf.tileCollection.at(weatherIndex));
                        }
                    }
                }
                thumbnailViewSelf.show();
                this.widget.show();
            }
            deferred.resolve();
            return deferred.promise;
        }
        Volt.log();
        //till now every thing is fine
        if(this.firstTime !== true) 
        {
            Volt.log();
            if(this.weatherSettingCodeCityListChange === true){
                Volt.log();
                this.weatherSettingCodeCityListChange = false;
                thumbnailViewSelf.weatherDataRefresh();
            }
            mainViewSelf.setFocusForAppStatusChange(); // set last focus
        }
        
        if(!mainViewSelf.loadingDialog.isLoading) // if is not refresh,we should re open the timer
        {
            if (thumbnailViewSelf !== null && thumbnailViewSelf.weatherSwitchTimer === null) {
                // TODO: the below code was test code
                var weatherModel = thumbnailViewSelf.tileCollection.at(weatherIndex);
                var iWeatherTileCityCollection = weatherModel.get('weatherTileCityCollection');
                if (iWeatherTileCityCollection !== null && iWeatherTileCityCollection !== undefined) {
					var model = thumbnailViewSelf.tileCollection.at(weatherIndex);
					var iWeatherTileCityCollection = model.get('weatherTileCityCollection');
					var cityIdx = model.get('cityIdx');
					thumbnailViewSelf.weatherCityIdx = cityIdx;		
					var cityModel = iWeatherTileCityCollection.at(cityIdx);
					var data = thumbnailViewSelf.widget.getData(0, 5);
					data.model = cityModel;
					thumbnailViewSelf.widget.updateItem(0, 5);  //update if view return from weather detail view
                    thumbnailViewSelf.weatherSwitchTimer = Volt.setInterval(thumbnailViewSelf.onWeatherCitySwitch,
                        cycleSeconds * 1000, thumbnailViewSelf.tileCollection.at(weatherIndex));
                }
            }
        }
        this.widget.show();
        if(thumbnailViewSelf !== null)
        {
            thumbnailViewSelf.show();
        }
        if (mainViewSelf.mainNewsStatus != 'success' || mainViewSelf.moreNewsStatus != 'success')
            return;
        if(mainViewSelf.firstTime === true)
        {
            mainViewSelf.loadingDialog.show(1);
        }
        if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
        {
            print('main view show');
            print(VDUtil.getProcMemory());
        }
        deferred.resolve();
        /*
        PanelCommon.doViewSwitchAni(this.widget, animationType).then(function(){
            
        });
        */
        return deferred.promise;
    },
    
    /** hide the main view 
	* @function hide
	* @param {string}  animationType          		-animation type
	* @memberof MainView
	*/
    hide : function(options, animationType) {
        var deferred = Q.defer();
        Volt.Nav.blur();
        headViewSelf.stopListening(GlobalMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR);
		if (thumbnailViewSelf && thumbnailViewSelf.weatherSwitchTimer){		
			Volt.clearInterval(thumbnailViewSelf.weatherSwitchTimer);
			thumbnailViewSelf.weatherSwitchTimer = null;
		}
        //this.stopListening();
        /*
        PanelCommon.doViewSwitchAni(this.widget, animationType).then(function() {
            
            
        });*/
        deferred.resolve();
        if(thumbnailViewSelf)
        {
            thumbnailViewSelf.hide();
        }
        if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
        {
            print('main view hide');
            gc();
            print(VDUtil.getProcMemory());
        }
        mainViewSelf.widget.hide();
        
        return deferred.promise;
    },
    /**
     * pause the main view Invoked when some popup view popup over this View
     * @function
     * @memberof MainView
     */
    pause : function() {
        Volt.log();
        dimView.show({
            parent: this.widget.getChild('main-dim-container')
        });
    },

    /**
     * Invoked when come back from popup
     * @function
     * @memberof MainView
     */
    resume : function(options) {
        Volt.log();
        dimView.hide();
        if( voltapi.vconf.getValue(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE) && mainViewSelf.lastFocusForClose != null){
            if(mainViewSelf.lastFocusForClose != null){
                Volt.Nav.focus(mainViewSelf.lastFocusForClose);
                mainViewSelf.lastFocusForClose = null;
            }
        } else {
            if(mainViewSelf.isNeedSetFocus){
                Volt.Nav.focus(mainViewSelf.lastFocus);
            }
        }
    },
    hideCustomPopups : function() {
        if (this.popupView.optionMenu != null){
            MainMediator.trigger(CommonDefines.Event.HIDE_OPTION_MENU, {
                type : 'OPTION_MENU'
            });
        }
    },
    
    onKeyEvent : function(keyCode, keyType) {
        if (keyCode == Volt.KEY_RETURN && keyType == Volt.EVENT_KEY_PRESS) {
            mainViewSelf.isNeedSetFocus = true;
        }
    }
});
/**
 * HeaderView -BackboneView
 * @class
 * @name HeaderView
 * @augments Backbone.View
 */
var HeaderView = BaseView.extend({
    
    /**
     * This property represents the default template in HeaderView.
     * @name template
     * @type JSON
     * @default NewsonMainTemplate.header
     * @fieldOf HeaderView.prototype
     */
    template : NewsonMainTemplate.header,
    
    /** Initialize HeaderView. 
	* @function initialize
	* @memberof HeaderView
	*/
    initialize : function () {
        //
        //MainMediator.on('EVENT_MAIN_CATEGORY_FOCUS', this.shrink);
        //MainMediator.on('EVENT_MAIN_CATEGORY_BLUR', this.expand);
        //KPI start
        this.KPISelectUtil1 = new KPIOptions.SelectUtil1(this);
        this.KPISelectUtil2 = new KPIOptions.SelectUtil2(this);
        headViewSelf = this;
	//KPI end
        MainMediator.on(CommonDefines.Event.SHOW_OR_HIDE_SETTING_BUTTON, function(){
            if('CN' == DeviceModel.get('countryCode')){
                Volt.log(DeviceModel.get('countryCode'));
                this.settingButton.show();
                if(!this.settingButton.custom) {
                    this.settingButton.custom = {};
                }
                this.settingButton.custom.focusable = true;
                Volt.Nav.reload();
            } else {
                Volt.log(DeviceModel.get('countryCode'));
                this.settingButton.hide();
                if(!this.settingButton.custom) {
                    this.settingButton.custom = {};
                }
                this.settingButton.custom.focusable = false;
                Volt.Nav.reload();
                if(thumbnailViewSelf) {
                    mainViewSelf.setFocusForAppStatusChange();
                }
            }
        }.bind(this));
    },
    /** render HeaderView. 
	* @function render
	* @memberof HeaderView
	*/
    render : function() {
        Volt.log();
        this.setWidget(PanelCommon.loadTemplate(this.template));
        
        this.tools = this.widget.getDescendant('main-header-tools');
        this.renderSettingButton();
        this.renderCloseButton();
        var buttonListener = new ButtonListener();
        buttonListener.onButtonClicked = function(Button, type) {
            if(headViewSelf !== null && Button.parent.id === 'main-header-icon-setting'){
                headViewSelf.onSelectSetting(Button.parent);
            }else if(headViewSelf !== null && Button.parent.id === 'main-header-icon-close' && type === 'mouse'){
                headViewSelf.onSelectClose(Button.parent);
            }
        };//.bind(this);
        this.settingButton.getChild(1).addListener(buttonListener);
        this.closeButton.getChild(1).addListener(buttonListener);
        MainMediator.trigger(CommonDefines.Event.SHOW_OR_HIDE_SETTING_BUTTON);
        return this;
    },
    
    renderSettingButton : function(){
        this.settingButton = this.widget.getDescendant('main-header-icon-setting');
        
        this.settingButton.getChild(1).setBackgroundImage({
            state: "focused",
            src: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_sel.png'),
        });
        this.settingButton.getChild(1).setBackgroundImage({
            state: "normal",
            src: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_nor.png'),
        });
        this.settingButton.getChild(1).setBackgroundImage({
            state: "roll-over",
            src: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_sel.png'),
        });
        this.settingButton.getChild(1).setBackgroundImage({
            state: "focused-roll-over",
            src: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_sel.png'),
        });
        this.settingButton.getChild(1).setBackgroundImage({
            state: "disabled",
            src: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_nor.png'),
        });
        this.settingButton.getChild(1).setBackgroundImage({
            state: "disabled-focused",
            src: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_sel.png'),
        });
        this.settingButton.getChild(1).setBackgroundImage({
            state: "selected",
            src: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_sel.png'),
        });
        
        this.settingButton.getChild(1).setBackgroundColor({
            state: "normal",
            color: {r: 255, g: 0, b: 0, a: 0},
        });
        this.settingButton.getChild(1).setBackgroundColor({
            state: "focused",
            color: {r: 255, g: 255, b: 255, a: 255},
        });
        
        this.settingButton.getChild(1).setBackgroundColor({
            state: "roll-over",
            color: {r: 255, g: 255, b: 255, a: 255},
        });
        this.settingButton.getChild(1).setBackgroundColor({
            state: "focused-roll-over",
            color: {r: 255, g: 255, b: 255, a: 255},
        });
        this.settingButton.getChild(1).setBackgroundColor({
            state: "disabled",
            color: {r: 255, g: 0, b: 0, a: 0},
        });
        this.settingButton.getChild(1).setBackgroundColor({
            state: "disabled-focused",
            color: {r: 255, g: 0, b: 0, a: 0},
        });
        this.settingButton.getChild(1).setBackgroundColor({
            state: "selected",
            color: {r: 255, g: 0, b: 0, a: 0},
        });
        
        
        Volt.Nav.setNextItemRule(this.settingButton,"left",this.settingButton);
        Volt.Nav.setNextItemRule(this.settingButton,"right",this.settingButton);
    },
    
    renderCloseButton : function(){
        this.closeButton = this.widget.getDescendant('main-header-icon-close');
        this.closeButton.getChild(1).setBackgroundImage({
            state: "focused",
            src: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_close_sel.png'),
        });
        this.closeButton.getChild(1).setBackgroundImage({
            state: "normal",
            src: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_close_nor.png'),
        });
        this.closeButton.getChild(1).setBackgroundImage({
            state: "roll-over",
            src: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_close_sel.png'),
        });
        this.closeButton.getChild(1).setBackgroundImage({
            state: "focused-roll-over",
            src: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_close_sel.png'),
        });
        this.closeButton.getChild(1).setBackgroundImage({
            state: "disabled",
            src: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_close_nor.png'),
        });
        this.closeButton.getChild(1).setBackgroundImage({
            state: "disabled-focused",
            src: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_close_sel.png'),
        });
        this.closeButton.getChild(1).setBackgroundImage({
            state: "selected",
            src: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_close_sel.png'),
        });
        
        this.closeButton.getChild(1).setBackgroundColor({
            state: "normal",
            color: {r: 255, g: 0, b: 0, a: 0},
        });
        this.closeButton.getChild(1).setBackgroundColor({
            state: "focused",
            color: {r: 255, g: 255, b: 255, a: 255},
        });
        
        this.closeButton.getChild(1).setBackgroundColor({
            state: "roll-over",
            color: {r: 255, g: 255, b: 255, a: 255},
        });
        this.closeButton.getChild(1).setBackgroundColor({
            state: "focused-roll-over",
            color: {r: 255, g: 255, b: 255, a: 255},
        });
        this.closeButton.getChild(1).setBackgroundColor({
            state: "disabled",
            color: {r: 255, g: 0, b: 0, a: 0},
        });
        this.closeButton.getChild(1).setBackgroundColor({
            state: "disabled-focused",
            color: {r: 255, g: 0, b: 0, a: 0},
        });
        this.closeButton.getChild(1).setBackgroundColor({
            state: "selected",
            color: {r: 255, g: 0, b: 0, a: 0},
        });
        Volt.Nav.setNextItemRule(this.closeButton,"left",this.closeButton);
        Volt.Nav.setNextItemRule(this.closeButton,"right",this.closeButton);
        Volt.Nav.setNextItemRule(this.closeButton,"up",this.closeButton);
        Volt.Nav.setNextItemRule(this.closeButton,"down",this.closeButton);
        
        if( !voltapi.vconf.getValue(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE)){
            Volt.log();
            mainViewSelf.optionMenuX = NewsonMainTemplate.constNum.hideCloseOptionMenuX;
            if(this.closeButton){
                this.tools.x = NewsonMainTemplate.constNum.hideCloseToolX;
                this.closeButton.hide();
                this.closeButton.custom.focusable = false;
                Volt.Nav.reload();
            }
        } else {
            mainViewSelf.optionMenuX = NewsonMainTemplate.constNum.showCloseOptionMenuX;
            if(this.closeButton){
                this.tools.x = NewsonMainTemplate.constNum.showCloseToolX;
                this.closeButton.show();
                this.closeButton.custom.focusable = true;
                Volt.Nav.reload();
            }
        }
    },

    onChangeCursor : function(visible) {
        Volt.log('visible - ' + visible);
        if (visible) {
            mainViewSelf.optionMenuX = NewsonMainTemplate.constNum.showCloseOptionMenuX;
            if (this.closeButton) {
                this.tools.x = NewsonMainTemplate.constNum.showCloseToolX;
                this.closeButton.show();
                this.closeButton.custom.focusable = true;
                Volt.Nav.reload();
            }
        } else {
            mainViewSelf.optionMenuX = NewsonMainTemplate.constNum.hideCloseOptionMenuX;
            if (this.closeButton) {
                this.tools.x = NewsonMainTemplate.constNum.hideCloseToolX;
                this.closeButton.hide();
                this.closeButton.custom.focusable = false;
                Volt.Nav.reload();
                Volt.Nav.focus(mainViewSelf.lastFocus);
            }
        }
    },
    
    events : {
        //'NAV_SELECT #main-header-icon-setting' : 'onSelectSetting',
        //'NAV_SELECT #main-header-icon-close' : 'onSelectClose',

        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },
    
    /** headerView's focus callback. 
	* @function onFocus
    * @param {Widget}  widget                  	- the widget is focused
	* @memberof HeaderView
	*/
    onFocus : function(widget) {
        Volt.log('HeaderView.focus - ' + widget.id);
        if (1 == DeviceModel.getMenuTTS()){
            if (true == vg_byTTS) {
                var voiceText = 'Options, button';
                Global.voiceGuide(voiceText);
            }
        }
        if(widget != this.closeButton) {
            mainViewSelf.lastFocus = widget;
        }
        if(widget && widget.getChildCount() > 0)
        {
            widget.getChild(0).opacity = CommonDefines.Opacity.MAINNEWS_OPACITY_FOCUS;
            widget.getChild(0).width = NewsonMainTemplate.constNum.iconBgFocusWidth;
            widget.getChild(1).setFocus();
            /*
            widget.getChild(1).opacity = 255;
            widget.getChild(2).opacity = 0;*/
        }
    },

    /** headerView's blur callback. 
	* @function onBlur
    * @param {Widget}  widget                  	- the widget is blurred
	* @memberof HeaderView
	*/
    onBlur : function(widget) {
        Volt.log('HeaderView.onBlur - ' + widget.id);
        if(widget && widget.getChildCount() > 0)
        {
            widget.getChild(0).opacity = CommonDefines.Opacity.MAINNEWS_OPACITY_BLUR;
            widget.getChild(0).width = NewsonMainTemplate.constNum.iconBgBlurWidth;
            widget.getChild(1).killFocus();
            /*
            widget.getChild(1).opacity = 0;
            widget.getChild(2).opacity = 255;*/
        }
    },
    
    /** headerView's selected callback. 
	* @function onSelectSetting
    * @param {Widget}  widget                  	- the widget is selected
	* @memberof HeaderView
	*/
    onSelectSetting : function(widget) {
        Volt.log();
        
        //KPI start
        this.KPISelectUtil1.send();
        //KPI end
        MainMediator.trigger(CommonDefines.Event.SHOW_OPTION_MENU, {
            type : CommonDefines.PopupType.OPTION_MENU
        });
    },
    
    /** headerView's selected callback. 
     * @function onSelectClose
     * @param {Widget}  widget                   - the widget is selected
     * @memberof HeaderView
     */
    onSelectClose : function(widget) {
         Volt.log();
         
         //KPI start
         this.KPISelectUtil2.send();
         //KPI end
         mainViewSelf.lastFocusForClose = widget;
         Volt.log('newson exit');
         //DeviceModel.destroyVoltApi();
         Volt.exit(); 
     },

    /*expand : function() {
        Volt.log('HeaderView.expand');
        this.headerView.widget.animate('y', 0, MENU_ANIM_DURATION);
    },

    shrink : function() {
        Volt.log('HeaderView.shrink');
        this.headerView.widget.animate('y', -18, MENU_ANIM_DURATION);
    }*/
});
var categorySelf = null;
/** CategoryView -BackboneView
* @class 
* @name CategoryView
* @augments Backbone.View
*/ 
var CategoryView = BaseView
        .extend({
            
            /**
             * This property represents the default template in CategoryView.
             * @name template
             * @type JSON
             * @default NewsonMainTemplate.category
             * @fieldOf CategoryView.prototype
             */
            template : NewsonMainTemplate.category,
            
            /**
             * This property represents the related model reference in CategoryView.
             * @name model
             * @type Object
            * @default NewsonMainTemplate.category
             * @fieldOf CategoryView.prototype
             */
			model : null,
            
            /** Item press call back. 
            * @function itemPressedCallBack
            * @param {Number}  index          		- This parameter represents the item index
            * @param {Widget}  widget          		- This parameter represents the index related widget
            * @memberof CategoryView
            */
//            itemPressedCallBack : function(index, widget) {
//                /*
//                if (categorySelf.model.get('update') == 0) {
//                    categorySelf.model.set('update', 1);
//                } else {
//                    categorySelf.model.set('update', 0);
//                }*/
//                mainViewSelf.block();
//                mainViewSelf.loadingDialog.show(1);
//                MainNewsModel.fetch().then(function(result){
//                    if(result){
//                        var url = MainNewsModel.get('more_news_url');
//                        var pageIdx = 1;
//                        var options = {'pageIdx':pageIdx,'more_news_url':url};
//                        MoreNewsModel.setInitData(options);
//                        MoreNewsModel.get('pageCollection').reset();
//                        MoreNewsModel.fetch().then(function(){
//                            //deferred.resolve();
//                            mainViewSelf.contentView.trigger('refresh');
//                            mainViewSelf.loadingDialog.hide();
//                            mainViewSelf.unblock();
//                        });
//                    }
//                });
//                if(index == 0)
//                {
//                    categorySelf.widget.getChild('cpLogo').src = Volt.getRemoteUrl('images/1080/news_cpicon_yahoo_brasil.png');
//                    categorySelf.widget.getChild('properity').text = categorySelf.model.get('tos_text');
//                }
//                else
//                {
//                    categorySelf.widget.getChild('cpLogo').src = Volt.getRemoteUrl('images/1080/news_cp_icon_sina_b.png');
//                    categorySelf.widget.getChild('properity').text = 'CP' + (index + 1);
//                }
//            },
            /** Initialize CategoryView. 
            * @function initialize
            * @memberof CategoryView
            */
            initialize : function() {
                categorySelf = this;
                //MainMediator.on('EVENT_MAIN_CATEGORY_FOCUS', this.expand);
                //MainMediator.on('EVENT_MAIN_CATEGORY_BLUR', this.shrink);
                this.listenTo(this, 'refresh', this.refresh);
            },
            
           /** render CategoryView. 
            * @function render
            * @param {Object}  model          		- main news' model based on 2014 yahoo API
            * @memberof CategoryView
            */
            render : function(model,moreNewsModel) {

                this.model = model;
                this.moreNewsModel = moreNewsModel;
                //var array = ['yahoo!']; //['CP1','CP2','CP3','CP4','CP5','CP6','CP7'];
                var mustash = null;
                if(CPAPI.getServiceType() == 'sina_huafeng'){
                    mustash = {
                        cpLogo : null,//Volt.getRemoteUrl('images/1080/news_cp_icon_sina_b.png'),
                       properity : this.model.get('tos_text'),
                    };
                }else{
                    mustash = {
                        cpLogo : Volt.getRemoteUrl('images/1080/news_cpicon_yahoo_brasil.png'),
                            properity : this.model.get('tos_text'),
                    };
                }
                var tmpWidget = PanelCommon.loadTemplate(this.template, mustash);
                //var cpList = tmpWidget.getChild('cplist');
               // cpList.ifItemPressed = this.itemPressedCallBack;
                //before setwidget,all child must be added. If not,new added child event will be disfunction.
                this.setWidget(tmpWidget);
                //cpList.setItems(array);
               //Volt.Nav.reload();
                return this;
            },
            
            refresh : function()
            {
                if(categorySelf.widget.getChildCount() > 0)
                {
                    if(CPAPI.getServiceType() == 'sina_huafeng')
                    {
                       categorySelf.widget.getChild('cpLogo').src = Volt.getRemoteUrl('images/1080/news_cp_icon_sina_b.png');
                        categorySelf.widget.getChild('cpLogo').opacity = 0;
                    }
                    else
                    {
                       categorySelf.widget.getChild('cpLogo').src = Volt.getRemoteUrl('images/1080/news_cpicon_yahoo_brasil.png');
                       categorySelf.widget.getChild('cpLogo').opacity = 255;
                   }
                    if(categorySelf.model.get('tos_text') !== undefined)
                    {
                        categorySelf.widget.getChild('properity').text = categorySelf.model.get('tos_text')+'';
                   }
                    else
                    {
                       categorySelf.widget.getChild('properity').text = '';
                    }
                    
               }
            },
            
            events : {
                'NAV_SELECT' : 'onSelect',
                'NAV_FOCUS' : 'onFocus',
                'NAV_BLUR' : 'onBlur'
            },
            
            /** CategoryView's focus callback. 
            * @function onFocus
            * @param {Widget}  widget                  	- the widget is focused
            * @memberof CategoryView
            */
            onFocus : function(widget) {
                mainViewSelf.lastFocus = widget;
                widget.setFocus();
            },
            
            /** CategoryView's blur callback. 
            * @function onBlur
           * @param {Widget}  widget                  	- the widget is blurred
            * @memberof CategoryView
            */
            onBlur : function(widget) {
                widget.killFocus();
            },
            
            /** CategoryView's select callback. 
            * @function onSelect
            * @param {Widget}  widget                  	- the widget is selected
            * @memberof CategoryView
            */
           onSelect : function(widget) {
            },
            /*expand : function() {
                this.categoryView.widget.animate('y', -36, MENU_ANIM_DURATION);
                this.categoryView.widget.animate('height', 108, MENU_ANIM_DURATION);
               this.categoryView.widget.getChild(0).animate('y', 18, MENU_ANIM_DURATION);
            },

           shrink : function() {
                this.categoryView.widget.animate('y', 0, MENU_ANIM_DURATION);
                this.categoryView.widget.animate('height', 72, MENU_ANIM_DURATION);
                this.categoryView.widget.getChild(0).animate('y', 0, MENU_ANIM_DURATION);
            }*/

       });



var mustashWeather = {
    src : null,
    defaultSrc : null,
    currentConditionIcon : null,
    location : null,
    currentConditions : null,
    todayHighTemp : null,
    todayLowTemp : null,
    currentTemp : null,
    photoAttribute : null,
};

//var weatherTileCollection = null;
var weatherTileModel = null;

var mustash = {
    src : null,
    title : null,
    time : null,
};
/** ContentView -BackboneView
* @class 
* @name ContentView
* @augments Backbone.View
*/ 
var ContentView = BaseView.extend({

    /**
     * This property represents the default template in ContentView.
     * @name template
     * @type JSON
     * @default NewsonMainTemplate.content
     * @fieldOf ContentView.prototype
     */
    template : NewsonMainTemplate.content,
    layoutCache : [],
    //maxItemSize : 1024,
    map : [],
    weatherSwitchTimer : null,
    firstTime : true,
    freshTimer : null,
	weatherCityIdx : 0,
    moreNewsCount : 0,
    moreNewsMaxSize : 1,
    tileCollection : null,
    //_stuffviewContainer :[],
    //_stuffViewHead:0,
    //_stuffViewTail:0,
    newsCount : 0,
    /** Initialize ContentView. 
    * @function initialize
    * @memberof ContentView
    */
    initialize : function () {
        //this.__initLayout();
        thumbnailViewSelf = this;
        //this.listenTo(this, 'update', this.updateChildView);
        this.listenTo(this, 'refresh', this.refresh);
        //KPI start
        this.KPISelectNews = new KPIOptions.SelectNews(this);
        this.KPISelectWeather = new KPIOptions.SelectWeather(this);
        //KPI end
    },
    events : {
        'NAV_SELECT':'onSelect',
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },
    
    __loadTemplate : function(parent, parentHeight, index){
        Volt.log('parentHeight - ' + parentHeight + ' index - ' + index);
        var thumbnail = undefined;
        if (parentHeight == containerMap.news_thumbnail1.height) {
            if (index != 5) {
                thumbnail = PanelCommon.loadTemplate(NewsonMainDetailTemplate.container_news_thumbnail1, null, parent).getChild(2);
            } else{
			
                thumbnail = PanelCommon.loadTemplate(NewsonMainDetailTemplate.container_weather_thumbnail, null, parent).getChild(2);
				var thumbListener = new ThumbnailListener;
				thumbListener.onImageReady = function (thumbnail, id, success) {
					print("thumb" + thumbnail + " load " + success);
					if(!success) {

						if('CN' == DeviceModel.get('countryCode')) {
							var defaultSrc = NewsonWeatherDetailImageTemplate.WeatherDefaultBgIconImageTemplate['weather-defaultbg-'+thumbnail.model.get(
										'current_condition_icon')];
										
							print("defaultSrc:" + defaultSrc );
							Volt.setTimeout(function(){
								thumbnail.setContentImage(defaultSrc);
								},100);							
						}

					
					}
				}
				
				thumbnail.addThumbnailListener(thumbListener);
            }
        } else if (parentHeight == containerMap.news_thumbnail2.height) {
            thumbnail = PanelCommon.loadTemplate(NewsonMainDetailTemplate.container_news_thumbnail2, null, parent).getChild(2);
        } else if (parentHeight == containerMap.news_thumbnail3.height) {
            thumbnail = PanelCommon.loadTemplate(NewsonMainDetailTemplate.container_news_thumbnail3, null, parent).getChild(2);
        }
        return thumbnail;
    },
    
    __updateView : function(thumbnail, parentHeight, index, model)
    {
        if(thumbnail === undefined)
            return;
        if(index < 0)
            return;
        if(model == null)
            return;
			
		thumbnail.model = model;
        var isSinaHuafeng = (CPAPI.getServiceType() == 'sina_huafeng');
        var bgUrl = null;
        if (5 == index) {
            bgUrl = model.get('background_image');
            if(isSinaHuafeng)
            {
                if(model.get('current_condition_icon') === '00' || model.get('current_condition_icon') === '03')
                {
                    if(new Date(model.get('local_time')).getHours() >= 8 && new Date(model.get('local_time')).getHours() < 20) {
                        mustashWeather.currentConditionIcon = NewsonWeatherDetailImageTemplate.WeatherIconImageTemplate['weathericon-normal-type'+model.get(
                        'current_condition_icon')+'-1'];
                    }
                    else
                    {
                       mustashWeather.currentConditionIcon = NewsonWeatherDetailImageTemplate.WeatherIconImageTemplate['weathericon-normal-type'+model.get(
                        'current_condition_icon')+'-2'];
                    }
                }else
                    mustashWeather.currentConditionIcon = NewsonWeatherDetailImageTemplate.WeatherIconImageTemplate['weathericon-normal-type'+model.get(
                    'current_condition_icon')];
                if(bgUrl === null ||bgUrl.length === 0)
                {
                    bgUrl = NewsonWeatherDetailImageTemplate.WeatherDefaultBgIconImageTemplate['weather-defaultbg-'+model.get(
                        'current_condition_icon')];
                }
            }
            else
            {
                mustashWeather.currentConditionIcon = model.get('current_condition_icon');
            }
            mustashWeather.src = bgUrl;
            mustashWeather.location = model.get('location');
            mustashWeather.currentConditions = model.get('current_conditions');
            mustashWeather.todayHighTemp = Math.floor(model.get('today_high_temp')) + '°';
            mustashWeather.todayLowTemp = Math.floor(model.get('today_low_temp')) + '°';
            mustashWeather.currentTemp = Math.floor(model.get('current_temp')) + '°';
            mustashWeather.photoAttribute = model.get('photo_attribution');
            
            Volt.log('mustashWeather - ' + JSON.stringify(mustashWeather));
            
            if('string' == typeof mustashWeather.src){
                thumbnail.setContentImage(mustashWeather.src);
            }
            
            if('string' == typeof mustashWeather.currentConditionIcon){
                thumbnail.setInformationIcon("icon1", mustashWeather.currentConditionIcon);
            }
            
            if('string' == typeof mustashWeather.location){
                thumbnail.setInformationText("text1", mustashWeather.location);
            }
            
            if('string' == typeof mustashWeather.currentConditions){
                thumbnail.setInformationText("text2", mustashWeather.currentConditions);
            }
            
            if('string' == typeof mustashWeather.todayHighTemp){
                thumbnail.setInformationText("text3", mustashWeather.todayHighTemp);
            }
            
            if('string' == typeof mustashWeather.todayLowTemp){
                thumbnail.setInformationText("text4", mustashWeather.todayLowTemp);
            }
            
            if('string' == typeof mustashWeather.currentTemp){
                thumbnail.setInformationText("text5", mustashWeather.currentTemp);
            }
            
            if (isSinaHuafeng) // china cp
            {
                thumbnail.visualizeAttachIcon(true, "icon1");
                thumbnail.visualizeInformationText(false, "text6");
            } else {
                thumbnail.visualizeAttachIcon(false, "icon1");
                thumbnail.visualizeInformationText(true, "text6");
                
                if('string' == typeof mustashWeather.photoAttribute){
                    thumbnail.setInformationText("text6", mustashWeather.photoAttribute);
                }
            }

            //voice guide
            if (1 == DeviceModel.getMenuTTS()){
                if (false == vg_byTTS) {            
                    var city = mustashWeather.location;
                    var condition = mustashWeather.currentConditions;
                    var current_temp = mustashWeather.currentTemp;
                    var degree = ' degrees';
                    if ((-1 == current_temp)||(0 == current_temp)||(1 == current_temp)){
                        degree = ' degree';
                    }
                    var voiceText = city + ', ' + condition + ', ' + current_temp + degree;
                    Volt.log('set voice guide, text is '+voiceText);
                    thumbnail.setTTSText({text : voiceText});
                }
            }
        }
		else
		{
            var imgUrl = model.get('img_url');
            if(imgUrl === null || imgUrl.length == 0) //imgUrl == null
            {
                if(isSinaHuafeng) // china cp
                {
                    switch(parentHeight)
                    {
                        case containerMap.news_thumbnail1.height :
                        {
                            imgUrl = NewsonMainDetailTemplate.main_detail_default[index%2];
                            break;
                        }
                        case containerMap.news_thumbnail2.height :
                        {
                            imgUrl = NewsonMainDetailTemplate.main_detail_default[2 + index % 4];
                            break;
                        }
                        case containerMap.news_thumbnail3.height :
                        {
                            imgUrl = NewsonMainDetailTemplate.main_detail_default[6 + index % 2];
                            break;
                        }
                        default :
                        {
                            imgUrl = NewsonMainDetailTemplate.main_detail_default[index%2];
                            break;
                        }
                    }
                }
            }
            mustash = {
                src : imgUrl,
                title : model.get('title') + '',
                time : model.get('source') + ' - ' + model.get('stringstamp'),
            };
            Volt.log('mustash - ' + JSON.stringify(mustash));
            if('string' == typeof mustash.src){
                thumbnail.setContentImage(mustash.src);
            }
            if('string' == typeof mustash.title){
                thumbnail.setInformationText("text1", mustash.title);
            }
            if('string' == typeof mustash.time){
                thumbnail.setInformationText("text2", mustash.time);
            }
            if (isSinaHuafeng) // china cp
            {
//                thumbnail.visualizeInformationIcon(true, "icon1");
//                var extractColor = thumbnail.getInformationExtractColor();
//                Volt.log('getInformationExtractColor - ' + JSON.stringify(extractColor));
//                if(extractColor.r < 128 && extractColor.g < 128 && extractColor.b < 128){
//                    thumbnail.setInformationIcon("icon1", Volt.getRemoteUrl('images/1080/news_cp_icon_sina_b.png'));
//                } else {
                    thumbnail.setInformationIcon("icon1", Volt.getRemoteUrl('images/1080/news_cp_icon_sina_w.png'));
//                }
            } else {
//                thumbnail.visualizeInformationIcon(false, "icon1");
                thumbnail.setInformationIcon("icon1", '');
            }
		}
    },
    
    /** weather city switch callback. 
	* @function onWeatherCitySwitch
	* @param {Object}  model                  	- main news' model
	* @memberof ContentView
	*/ 
    
    onWeatherCitySwitch : function(model) {
        
        var iWeatherTileCityCollection = model.get('weatherTileCityCollection');
        var cityIdx = model.get('cityIdx');
        cityIdx++;
        if (cityIdx >= iWeatherTileCityCollection.length) {
            cityIdx = 0;
        }
		
        thumbnailViewSelf.weatherCityIdx = cityIdx;
        model.set('cityIdx', cityIdx);
        if(iWeatherTileCityCollection.length <= 1)
            return;
        
        var cityModel = iWeatherTileCityCollection.at(cityIdx);//.get('background_image');
        var data = thumbnailViewSelf.widget.getData(0, 5);
        data.model = cityModel;
        thumbnailViewSelf.widget.updateItem(0, 5);
    },
    
    
    __initGridWidget : function (grid)
    {
        grid.addGroup(1);
        grid.addStyle(1);
        grid.addDataGroup(1);
        var rendererProvider = new RendererProvider;
        rendererProvider.funcGetRenderer = function(parentWidth, parentHeight, data)
        {
            var renderer = new Renderer(parentWidth, parentHeight);
            renderer.root = new Widget(
            {
               x:0,
               y:0,
               width:parentWidth,
               height:parentHeight,
               parent:data.parent,
            });
            
            renderer.thumbnail = thumbnailViewSelf.__loadTemplate(renderer.root, parentHeight, data.index);
            renderer.thumbnail.index = data.index;
            var thumbListener = new ThumbnailListener;
			thumbListener.onImageReady = function (thumbnail, id, success) {
                if(success) {
					var backColor = thumbnail.getInformationExtractColor();		
					Volt.log("backcolor:color.r " + backColor.r);
					Volt.log("backcolor:color.g " + backColor.g);
					Volt.log("backcolor:color.b " + backColor.b);	
					backColor.a = 153;
					//__colorPickingWeather(backcolor,fontcolor);
                    if(thumbnail.index >= 0 && thumbnail.index !== 5) {
                        thumbnail.setInformationTextColor('text1',backColor);
                        thumbnail.setInformationTextColor('text2',backColor);
                    } else if(thumbnail.index >= 0 && thumbnail.index === 5){
                        thumbnail.setInformationTextColor('text1',backColor);
                        thumbnail.setInformationTextColor('text2',backColor);
                        thumbnail.setInformationTextColor('text3',backColor);
                        thumbnail.setInformationTextColor('text4',backColor);
                        thumbnail.setInformationTextColor('text5',backColor);
                    }else {
                        
                    }
				}
            }
            renderer.thumbnail.addThumbnailListener(thumbListener);
            //set voice guide
            if (1 == DeviceModel.getMenuTTS()){
                if (false == vg_byTTS){
                    if (data.index != 5){
                        var voiceText = data.model.get('title');
                        if (0 == data.index && true == mainViewSelf.isFresh){
                            voiceText = "NewsON, " + thumbnailViewSelf.newsCount + ", items, " + voiceText;
                        }
                        Volt.log('set voice guide, text is '+voiceText);
                        renderer.thumbnail.setTTSText({text : voiceText});
                    }
                }
            }
            
            renderer.onRelease = function() 
            {
                renderer.root.destroy();
                delete renderer;
            };
            
            renderer.onDraw = function(rendererInstance, drawTypeString, data, parentWidth, parentHeight)
            {
                
                /*
                */
                if ("LoadData" == drawTypeString)
                {
                    print('LoadData---------------------'+data.index);
                    thumbnailViewSelf.__updateView(rendererInstance.thumbnail, parentHeight, data.index, data.model);
                }
                else if("UpdateData" == drawTypeString)
                {
                    print('UpdateData---------------------'+data.index);
//                    var destroyList = [];
//                    for(var i = 0; i < rendererInstance.root.getChildCount();i++)
//                    {
//                        destroyList.push(rendererInstance.root.getChild(i));
//                    }
//                    for(var i = 0; i < destroyList.length;i++)
//                    {
//                        rendererInstance.root.removeChild(destroyList[i]);
//                        destroyList[i].destroy();
//                        destroyList[i] = null;
//                    }
                    thumbnailViewSelf.__updateView(rendererInstance.thumbnail, parentHeight, data.index, data.model);
                }
            };
            
            return renderer;
        };
        grid.setRendererProvider(rendererProvider);
        
        var gridListener = new GridListControlListener;
        
        for (var i = 0; i < 10; i++){
            grid.addColumn({groupIndex: 0, styleIndex: 0, columnWidth: containerMap.news_thumbnail2.height});
        }

        for (var i = 0; i < 5; i++){
            if(i != 2)
            {
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail1.height});
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail2.height});
                
                if(i == 1 || i == 4)
                {
                    grid.mergeCells({groupIndex: 0, styleIndex: 0, startRow: 0, startCol: i - 1, endRow: 0, endCol: i});
                }
            }
            else
            {
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail3.height});
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail3.height});
            }
        }
        
        for(var i = 5; i < 10; i++)
        {
            if(i % 5 == 0)
            {
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail3.height});
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail3.height});
            }else if( (i % 5 == 1) || (i % 5) == 2)
            {
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail2.height});
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail1.height});
                if((i % 5) == 2)
                {
                    grid.mergeCells({groupIndex: 0, styleIndex: 0, startRow: 1, startCol: i - 1, endRow: 1, endCol: i});
                }
            }
            else if( (i % 5 == 3) || (i % 5) == 4)
            {
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail1.height});
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail2.height});
                if((i % 5) == 4)
                {
                    grid.mergeCells({groupIndex: 0, styleIndex: 0, startRow: 0, startCol: i - 1, endRow: 0, endCol: i});
                }
            }
        }
        gridListener.onItemClicked  = function(gridList, groupIndex, itemIndex)
        {
            thumbnailViewSelf.onItemClickedCallBack(gridList, groupIndex, itemIndex);
        };
        gridListener.onFocusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex){
            grid.onFocusChanged(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex);
        };
        grid.addListListener(gridListener);
        grid.enlargeFocusItem(20, 20);
        grid.setAnimationDuration(200);
        grid.shadowEffectFlag = false;
        grid.straightPath = false;
        grid.focusImageSetted = false;
        var _initScrollBar = function (width,height)
        {
            var scroll = new Scroll({
                parent: scene,
                width: 1920, //initial scroll bar width
                height: 4,   //initial scroll bar height
                direction: "horizontal" //must be horizontal since grid list control only support horizontal scroll
            });

            print(' ***********loadTemplate********gridlist.setScrollBar********  ');
            scroll.setPosition(0, 864 - 23);
            scroll.setBackgroundColor(220, 220, 220, 51);
            scroll.setTrackShadowColor(0, 0, 0, 51);
            scroll.setTrackShadowHeight(2);

            scroll.setPointingNormalThumbImage(Volt.getRemoteUrl("images/1080/scroll/keyscreen_scroll_pn.png"));
            scroll.setPointingNormalThumbSize(36, 4);

            scroll.setPointingOverThumbImage(Volt.getRemoteUrl("images/1080/scroll/keyscreen_scroll_po.png"));
            scroll.setPointingOverThumbSize(40, 20);

            scroll.setPointingFocusThumbImage(Volt.getRemoteUrl("images/1080/scroll/keyscreen_scroll_pf.png"));
            scroll.setPointingFocusThumbSize(40, 20);

            scroll.setMinValue(0);
            scroll.setMaxValue(100);
            scroll.setValue(0);

            scroll.setRolloverTrackHeight(37);
            scroll.show();
            
            return scroll;
        };
        print('');
        var scroll = _initScrollBar(grid.width,grid.height);
        
        grid.attachScrollBar(scroll);
    },
    DataCollection : [],
    onItemClickedCallBack : function (gridList, groupIndex, itemIndex)
    {
        var focusItem = this.widget.getFocusItemIndex();
        var index = focusItem .itemIndex;				
        Volt.log('index: ' + index);
        if (index != 5) {
            var thumbnail = this.widget.renderer(0, index).thumbnail;
            if (thumbnail && thumbnail.getInformationColorPicking) {
                scene.color = thumbnail.getInformationColorPicking();
            }
        }
        if (index >= 0) {
           if(-1 == DeviceModel.getNetWorkState()) {
               var ErrorHandler = Volt.require('app/common/errorHandler.js');
                ErrorHandler.show(CommonDefines.PopupType.NETWORK_ERROR1,505);
                return;
            }
            if (5 != index) {
                //skip weather index
                if(index > 5)
                {
                    index--;
                }
                var postion = this.map[index];
                var tile = thumbnailViewSelf.tileCollection.at(postion);
                //KPI start
                var pagePosition = (index<7) ? (index+1) : (((index-7)%8)+1);
                thumbnailViewSelf.KPISelectNews.send({cl : 'C-L-' + (index+1).toString(),
                    sp : 'S-P-' + pagePosition.toString(),
                    ct : tile.get('tile_type'),
                	ai : tile.get('id'),
                	at : tile.get('title')});
                //kpi end
                voltapi.rest.cancel();
                
                Backbone.history.navigate('detail/' + tile.get('id') + '/' + '<-1>', {
                    trigger : true
                });
            } else {
                //KPI start
                thumbnailViewSelf.KPISelectWeather.send();
                //KPI end
                voltapi.rest.cancel();
                Backbone.history.navigate('weather/' + this.weatherCityIdx, {
                    trigger : true,
                    weatherTile: weatherTileModel,
                });
            }
        } else {
            //print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'index is invalid');
            Volt.log('Erro: Invalid Index!');
        }
    },
    render : function (mainNewsModel, moreNewsModel,parent) {
		Volt.log('render entry');
		this.widget = PanelCommon.loadTemplate(this.template, null, parent);
        this.__initGridWidget(this.widget);
        Volt.Nav.setNextItemRule(this.widget,"right",this.widget);
        Volt.Nav.setNextItemRule(this.widget,"left",this.widget);
        if(headViewSelf && 'CN' == DeviceModel.get('countryCode')) {
            Volt.Nav.setNextItemRule(thumbnailViewSelf.widget,"up",headViewSelf.settingButton);
        }else {
            Volt.Nav.setNextItemRule(thumbnailViewSelf.widget,"up",thumbnailViewSelf.widget);
        }
		
        this.mainNewsModel = mainNewsModel;
        this.moreNewsModel = moreNewsModel;
        //this._stuffViewHead = 0;
        this.tileCollection = _.clone(mainNewsModel.get('pageModel').get('tileCollection'));
        this.moreNewsCount = 0;
        for(var i = 0; i < moreNewsModel.get('pageCollection').length; i++)
        {
            var pageModel = moreNewsModel.get('pageCollection').at(i);
            for(var j = 0; j < pageModel.get('tileCollection').length;j++)
            {
                this.tileCollection.add(pageModel.get('tileCollection').at(j));
            }
            this.moreNewsCount++;
        }
        
        var iCount = 0;
        for ( var i = 0; i < this.tileCollection.length; i++) {
            if (this.tileCollection.at(i).get('tile_type') == 'news') {
                this.map[iCount] = i;
                iCount++;
            }
        }
        this.newsCount = iCount <= 16 ? iCount: 16;
        /*************could be export as a function*************/
        //this.widget.clearDataSource();
        this.DataCollection.length = 0;
        for(var i = 0 ; i < this.newsCount;i++)
        {
            var data = new Data();
            data.parent = this.widget;
            data.index = i;
            if(i != 5)
            {
                if(i > 5)
                    data.model = this.tileCollection.at(this.map[i - 1]);
                else
                    data.model = this.tileCollection.at(this.map[i]);
            }
            else if(i == 5)
            {
                for ( var j = 0; j < this.tileCollection.length; j++) {
                    if (this.tileCollection.at(j).get('tile_type') == 'weather') {
                        var iWeatherTileCityCollection = this.tileCollection.at(j).get(
                                'weatherTileCityCollection');
                        weatherTileModel = this.tileCollection.at(j);
                        data.model = iWeatherTileCityCollection.at(0);
                        if('CN' == DeviceModel.get('countryCode')){
                            var cityList = '';
                            for(var k = 0; k < iWeatherTileCityCollection.length;k++)
                            {
                                cityList += iWeatherTileCityCollection.at(k).get('id');
                                if(k != iWeatherTileCityCollection.length - 1)
                                    cityList += ',';
                            }
                            Volt.log('cityList - ' + cityList);
                            var WeatherSettingModel = Volt.require('app/models/newson-weather-setting-model.js');
                            WeatherSettingModel.set('weatherSettingCodeCityList', cityList);
                        }
						
                        cycleSeconds = this.tileCollection.at(j).get('cycle_seconds');
						Volt.log('cycleSeconds:'+ cycleSeconds);
                        weatherIndex = j;
                        if (this.weatherSwitchTimer) {
                            Volt.clearInterval(this.weatherSwitchTimer);
                            this.weatherSwitchTimer = null;
                        }
                        
                        if(iWeatherTileCityCollection && iWeatherTileCityCollection.length > 1){
                            thumbnailViewSelf.weatherSwitchTimer = Volt.setInterval(thumbnailViewSelf.onWeatherCitySwitch, cycleSeconds * 1000,
                                    thumbnailViewSelf.tileCollection.at(weatherIndex));
                        }
                        break;
                    }
                }
            }
            //print('add data--------------------------'+ i);
            
            //data.tileCollection = this.tileCollection;
            //open switch timer
            this.DataCollection.push(data);
            this.widget.addData({groupIndex:0, data:data});
        }
        

        Volt.log('loadData');
        this.widget.loadData();
        this.widget.setFocusItemIndex(0, 0);
        /*************could be export as a function*************/
        this.setWidget(this.widget);

        this.widget.onFocusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex){
            if (toItemIndex <  0) {
                return;
            }
            if (1 == DeviceModel.getMenuTTS()){
                if (true == vg_byTTS) {
                    if (5 != toItemIndex) {
                        var voiceText = thumbnailViewSelf.DataCollection[toItemIndex].model.get('title');
                        if ( mainViewSelf.isFresh == true ){
                            mainViewSelf.isFresh = false;
                            voiceText = "NewsON, " + thumbnailViewSelf.newsCount + ", items, " + voiceText;
                        }
                        Global.voiceGuide(voiceText);
                    } else {
                        var tile = thumbnailViewSelf.DataCollection[toItemIndex].model;
                        var city = tile.get('location');
                        var condition = tile.get('current_conditions');
                        var current_temp = tile.get('current_temp');
                        var degree = ' degrees';
                        if ((-1 == current_temp)||(0 == current_temp)||(1 == current_temp)){
                            degree = ' degree';
                        }
                        var voiceText = city + ', ' + condition + ', ' + current_temp + degree;
                        Global.voiceGuide(voiceText);
                    }
                } else {
                    if ( true == mainViewSelf.isFresh){
                        mainViewSelf.isFresh = false;
                        var voiceText = thumbnailViewSelf.DataCollection[toItemIndex].model.get('title');
                        var thumbnail = thumbnailViewSelf.widget.renderer(0, toItemIndex).thumbnail;
                        Volt.log('set voice guide, text is '+voiceText);
                        thumbnail.setTTSText({text: voiceText});
                    }
                }
            }
        };
        
        this.onKeyEvent = function (keycode, keytype) {
			var ret = false;
			//print('-----------------gridwidget.onKeyEvent ---------this.grid is-------------------',this.grid);
			if (keytype == Volt.EVENT_KEY_PRESS) {
				return ;
			}		
			
	    	switch(keycode) {
				case Volt.KEY_JOYSTICK_UP:
					ret =  this.widget.moveFocus("Up");
					break;
				case Volt.KEY_JOYSTICK_DOWN:
					ret =  this.widget.moveFocus("Down");
					break;	
				case Volt.KEY_JOYSTICK_LEFT:
					ret =  this.widget.moveFocus("Left");
					break;	
				case Volt.KEY_JOYSTICK_RIGHT:
					ret =  this.widget.moveFocus("Right");
					break;	
				case Volt.KEY_JOYSTICK_OK:{
					var focusItem = this.widget.getFocusItemIndex();
					var index = focusItem .itemIndex;				
				    Volt.log('index: ' + index);
                    //modify scene color 
				    if (index != 5) {
                        var thumbnail = this.widget.renderer(0, index).thumbnail;
                        if (thumbnail && thumbnail.getInformationColorPicking) {
                            Volt.log('getInformationColorPicking - ' + JSON.stringify(thumbnail.getInformationColorPicking()));
                            Volt.log('getInformationExtractColor - ' + JSON.stringify(thumbnail.getInformationExtractColor()));
                            scene.color = thumbnail.getInformationColorPicking();
                        }
                    }
                    
				    if (index >= 0) {
				       if(-1 == DeviceModel.getNetWorkState()) {
				           var ErrorHandler = Volt.require('app/common/errorHandler.js');
                            ErrorHandler.show(CommonDefines.PopupType.NETWORK_ERROR1,505);
                            return;
                        }
                        if (5 != index) {
		            //skip weather index
                            if(index > 5)
                            {
                                index--;
                            }
                            var postion = thumbnailViewSelf.map[index];
                            var tile = thumbnailViewSelf.tileCollection.at(postion);
                            //KPI start
                            var pagePosition = (index<7) ? (index+1) : (((index-7)%8)+1);
                            thumbnailViewSelf.KPISelectNews.send({cl : 'C-L-' + (index+1).toString(),
                                sp : 'S-P-' + pagePosition.toString(),
                                ct : tile.get('tile_type'),
                            	ai : tile.get('id'),
                            	at : tile.get('title')});
                            //kpi end
                            voltapi.rest.cancel();
                            Backbone.history.navigate('detail/' + tile.get('id') + '/' + '<-1>', {
                                trigger : true
                            });
                        } else {
                            //KPI start
                            thumbnailViewSelf.KPISelectWeather.send();
                            //KPI end
                            voltapi.rest.cancel();
                            Backbone.history.navigate('weather/' + thumbnailViewSelf.weatherCityIdx, {
                                trigger : true,
                                weatherTile: weatherTileModel,
                            });
                        }
				    } else {
				        //print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'index is invalid');
				        Volt.log('Erro: Invalid Index!');
				    }
				}
				break;	

				default:
				// to do
				break;
			}
			return ret;
		};

		this.widget.onKeyEvent =  this.onKeyEvent.bind(this);
        this.freshTimer = setInterval(this.intervalRefresh, CommonDefines.RefreshTime.REFRESH_NEWS_TIMEOUT,null);
        
        //hijeck stuff
        this.listenTo(DeviceModel, 'change:countryCode', this.switchBRorCN);
        //end of hijeck stuff
        
        return this;
    },

    switchBRorCN : function(object, attr, options)
    {
        if(!LoadingDialog.isLoading)
        {
            mainViewSelf.isFresh = true;
            LoadingDialog.show(1);
            if (thumbnailViewSelf && thumbnailViewSelf.weatherSwitchTimer){		
                Volt.clearInterval(thumbnailViewSelf.weatherSwitchTimer);
                thumbnailViewSelf.weatherSwitchTimer = null;
            }
            CPAPI.initialize().then(function(){
                ModelController.ready().then(function(result){
                    if(result)
                    {
                        MainMediator.trigger(CommonDefines.Event.SHOW_OR_HIDE_SETTING_BUTTON);
                        var WeatherSettingModel = Volt.require('app/models/newson-weather-setting-model.js');
                        if(attr === 'BR') {
                            mainViewSelf.stopListening(WeatherSettingModel, 'change:weatherSettingCodeCityList');
                            Volt.Nav.setNextItemRule(thumbnailViewSelf.widget,"up",thumbnailViewSelf.widget);
                        } else {
                            mainViewSelf.listenTo(WeatherSettingModel, 'change:weatherSettingCodeCityList', function(){
                                mainViewSelf.weatherSettingCodeCityListChange = true;
                            });
                            if(headViewSelf) {
                                Volt.Nav.setNextItemRule(thumbnailViewSelf.widget,"up",headViewSelf.settingButton);
                            }
                        }
                    } else {
                        //if update failed
                        thumbnailViewSelf.stopListening(DeviceModel);
                        var localStorage = Volt.require("lib/volt-local-storage.js");
                        if(attr === 'BR') {
                            DeviceModel.set('countryCode', 'CN');
                            localStorage.setItem('countryCode','CN');
                        }else {
                            DeviceModel.set('countryCode', 'BR');
                            localStorage.setItem('countryCode','BR');
                        }
                        thumbnailViewSelf.listenTo(DeviceModel, 'change:countryCode', thumbnailViewSelf.switchBRorCN);
                        if (thumbnailViewSelf.weatherSwitchTimer === null) {
                            var weatherModel = thumbnailViewSelf.tileCollection.at(weatherIndex);
                            var iWeatherTileCityCollection = weatherModel.get('weatherTileCityCollection');
                            if (iWeatherTileCityCollection !== null && iWeatherTileCityCollection !== undefined) {
                                var model = thumbnailViewSelf.tileCollection.at(weatherIndex);
                                var iWeatherTileCityCollection = model.get('weatherTileCityCollection');
                                var cityIdx = model.get('cityIdx');
                                thumbnailViewSelf.weatherCityIdx = cityIdx;	
                                var cityModel = iWeatherTileCityCollection.at(cityIdx);
                                var data = thumbnailViewSelf.widget.getData(0, 5);
                                data.model = cityModel;
                                thumbnailViewSelf.widget.updateItem(0, 5);//update if view return from weather detail view
                                thumbnailViewSelf.weatherSwitchTimer = Volt.setInterval(thumbnailViewSelf.onWeatherCitySwitch,
                                    cycleSeconds * 1000, thumbnailViewSelf.tileCollection.at(weatherIndex));
                            }
                        }
                    }
                    mainViewSelf.loadingDialog.hide();
                });
            });
        }
    },
    
    weatherDataRefresh : function(){
        if(!LoadingDialog.isLoading){
            LoadingDialog.show(1);
            ModelController.weatherReady(true).then(function(result){
                if(result) {
                    var weatherModel = null;
                    for ( var i = 0; i < thumbnailViewSelf.mainNewsModel.get('pageModel').get('tileCollection').length; i++) {
                        if(thumbnailViewSelf.mainNewsModel.get('pageModel').get('tileCollection').at(i).get('tile_type') === 'weather'){
                            weatherModel = thumbnailViewSelf.mainNewsModel.get('pageModel').get('tileCollection').at(i);
                            break;
                        }
                    }
                    if(weatherModel !== null) {
                        for ( var i = 0; i < thumbnailViewSelf.tileCollection.length; i++) {
                            if (thumbnailViewSelf.tileCollection.at(i).get('tile_type') == 'weather') {
                                var model = thumbnailViewSelf.tileCollection.at(i);
                                model.set(weatherModel); // update weather model
                                break;
                            }
                        }
                    }
                    
                }
                if (thumbnailViewSelf.weatherSwitchTimer === null) {
                    var weatherModel = thumbnailViewSelf.tileCollection.at(weatherIndex);
                    var iWeatherTileCityCollection = weatherModel.get('weatherTileCityCollection');
                    if (iWeatherTileCityCollection !== null && iWeatherTileCityCollection !== undefined) {
                        var model = thumbnailViewSelf.tileCollection.at(weatherIndex);
                        var iWeatherTileCityCollection = model.get('weatherTileCityCollection');
                        var cityIdx = model.get('cityIdx');
                        thumbnailViewSelf.weatherCityIdx = cityIdx;	
                        var cityModel = iWeatherTileCityCollection.at(cityIdx);
                        var data = thumbnailViewSelf.widget.getData(0, 5);
                        data.model = cityModel;
                        thumbnailViewSelf.widget.updateItem(0, 5);//update if view return from weather detail view
                        thumbnailViewSelf.weatherSwitchTimer = Volt.setInterval(thumbnailViewSelf.onWeatherCitySwitch,
                            cycleSeconds * 1000, thumbnailViewSelf.tileCollection.at(weatherIndex));
                    }
                }
                LoadingDialog.hide();
            })
            
        }
    },
    
    intervalRefresh : function()
    {
        if(!LoadingDialog.isLoading) {
            mainViewSelf.isFresh = true;
            LoadingDialog.show(1);
            if (thumbnailViewSelf && thumbnailViewSelf.weatherSwitchTimer){		
                Volt.clearInterval(thumbnailViewSelf.weatherSwitchTimer);
                thumbnailViewSelf.weatherSwitchTimer = null;
            }
            ModelController.ready().then(function(result){
                if(result)
                {
                    MainMediator.trigger(CommonDefines.Event.SHOW_OR_HIDE_SETTING_BUTTON);
                }
                else
                {
                    //if failed re open timer 
                    if (thumbnailViewSelf.weatherSwitchTimer === null) {
                        var weatherModel = thumbnailViewSelf.tileCollection.at(weatherIndex);
                        var iWeatherTileCityCollection = weatherModel.get('weatherTileCityCollection');
                        if (iWeatherTileCityCollection !== null && iWeatherTileCityCollection !== undefined) {
                            var model = thumbnailViewSelf.tileCollection.at(weatherIndex);
                            var iWeatherTileCityCollection = model.get('weatherTileCityCollection');
                            var cityIdx = model.get('cityIdx');
                            thumbnailViewSelf.weatherCityIdx = cityIdx;	
                            var cityModel = iWeatherTileCityCollection.at(cityIdx);
                            var data = thumbnailViewSelf.widget.getData(0, 5);
                            data.model = cityModel;
                            thumbnailViewSelf.widget.updateItem(0, 5);//update if view return from weather detail view
                            thumbnailViewSelf.weatherSwitchTimer = Volt.setInterval(thumbnailViewSelf.onWeatherCitySwitch,
                                cycleSeconds * 1000, thumbnailViewSelf.tileCollection.at(weatherIndex));
                        }
                    }
                }
                mainViewSelf.loadingDialog.hide();
            });
        }
    },
    
    refresh : function () {
        
        if(this.tileCollection !== null)
            this.tileCollection.reset();
        for ( var i = 0; i < this.mainNewsModel.get('pageModel').get('tileCollection').length; i++) {
            this.tileCollection.add(this.mainNewsModel.get('pageModel').get('tileCollection').at(i));
        }
        this.moreNewsCount = 0;
        for(var i = 0; i < this.moreNewsModel.get('pageCollection').length; i++)
        {
            var pageModel = this.moreNewsModel.get('pageCollection').at(i);
            for(var j = 0; j < pageModel.get('tileCollection').length;j++)
            {
                this.tileCollection.add(pageModel.get('tileCollection').at(j));
            }
            this.moreNewsCount++;
        }
        this.map = [];
        this.map.length = 0;
        var iCount = 0;
        for ( var i = 0; i < this.tileCollection.length; i++) {
            if (this.tileCollection.at(i).get('tile_type') == 'news') {
                this.map[iCount] = i;
                iCount++;
            }
        }
        this.newsCount = iCount <= 16 ? iCount: 16;
        this.widget.clearDataSource(0);
        this.widget.addDataGroup(1);
        this.DataCollection = [];
        this.DataCollection.length = 0;
        for(var i = 0 ; i < this.newsCount;i++)
        {
            var data = new Data();
            data.parent = this.widget;
            data.index = i;
            if(i != 5) {
                if(i > 5)
                    data.model = this.tileCollection.at(this.map[i - 1]);
                else
                    data.model = this.tileCollection.at(this.map[i]);
            } else if(i == 5) {
                for ( var j = 0; j < this.tileCollection.length; j++) {
                    if (this.tileCollection.at(j).get('tile_type') == 'weather') {
                        var iWeatherTileCityCollection = this.tileCollection.at(j).get(
                                'weatherTileCityCollection');
                        //weatherTileCollection = _.clone(iWeatherTileCityCollection);
						weatherTileModel = this.tileCollection.at(j);
                        data.model = iWeatherTileCityCollection.at(0);
                        if('CN' == DeviceModel.get('countryCode')){
                            var cityList = '';
                            for(var k = 0; k < iWeatherTileCityCollection.length;k++)
                            {
                                cityList += iWeatherTileCityCollection.at(k).get('id');
                                if(k != iWeatherTileCityCollection.length - 1)
                                    cityList += ',';
                            }
                            Volt.log('cityList - ' + cityList);
                            var WeatherSettingModel = Volt.require('app/models/newson-weather-setting-model.js');
                            WeatherSettingModel.set('weatherSettingCodeCityList', cityList);
                        }
                        cycleSeconds = this.tileCollection.at(j).get('cycle_seconds');
                        weatherIndex = j;
                        if (this.weatherSwitchTimer) {
                            Volt.clearInterval(this.weatherSwitchTimer);
                            this.weatherSwitchTimer = null;
                        }
                        
                        if(iWeatherTileCityCollection && iWeatherTileCityCollection.length > 1){
                            thumbnailViewSelf.weatherSwitchTimer = Volt.setInterval(thumbnailViewSelf.onWeatherCitySwitch, cycleSeconds * 1000,
                                    thumbnailViewSelf.tileCollection.at(weatherIndex));
                        }
                        break;
                    }
                }
            }
            //data.tileCollection = this.tileCollection;
            //open switch timer
            this.DataCollection.push(data);
            this.widget.addData({groupIndex:0, data:data});
        }
        this.widget.loadData();
        this.widget.updateAllItems(0);
        this.widget.setFocusItemIndex(0, 0);
        thumbnailViewSelf.weatherCityIdx = 0;
        if('CN' !== DeviceModel.get('countryCode')){
            mainViewSelf.lastFocus = thumbnailViewSelf.widget;
        }
        mainViewSelf.setFocusForAppStatusChange();
    },
    
    show : function () 
    {
        if(this.freshTimer) {
            clearInterval(this.freshTimer);
            this.freshTimer = null;
        }
        this.freshTimer = setInterval(this.intervalRefresh, CommonDefines.RefreshTime.REFRESH_NEWS_TIMEOUT,null);
        this.stopListening(DeviceModel);
        this.listenTo(DeviceModel, 'change:countryCode', this.switchBRorCN);
        this.widget.show();
    },
    
    hide : function () {
        this.stopListening(DeviceModel);
        this.widget.hide();
        if(this.freshTimer) {
            clearInterval(this.freshTimer);
            this.freshTimer = null;
        }
    },
    
     /** ContentView's focus callback. 
    * @function onFocus
    * @param {Widget}  widget                  	- the widget is focused
    * @memberof ContentView
    */
    onFocus : function (widget)
    {
        mainViewSelf.lastFocus = widget;
        if(!widget.focusImageSetted){
            widget.setFocusImage(Volt.getRemoteUrl("images/1080/icon/focus_grid.png"), 0, 0);
            widget.focusImageSetted = true;
        }
        widget.enableFocus();
        widget.setFocus();
        widget.showFocus("false");
       
    },
    /** ContentView's blur callback. 
    * @function onBlur
    * @param {Widget}  widget                  	- the widget is blurred
    * @memberof ContentView
    */
    onBlur : function(widget)
    {
        Volt.log();
		widget.hideFocus("true");
    },
    
    
    onSelect : function(widget)
    {
        
    }
});

var PopupView = BaseView.extend({

    /**
     * This property represents the add to favorites Popup in MainView.
     * @name addToFavoritesPopup
     * @type OptionMenu
     * @default null
     * @fieldOf PopupView.prototype
     */
    addToFavoritesPopup : null,

    /**
     * This property represents the remove from favorites Popup in MainView.
     * @name removeFromFavaritesPopup
     * @type OptionMenu
     * @default null
     * @fieldOf PopupView.prototype
     */
    removeFromFavaritesPopup : null,

    /**
     * This property represents the option menu in MainView.
     * @name optionMenu
     * @type OptionMenu
     * @default null
     * @fieldOf PopupView.prototype
     */
    optionMenu : null,

    initialize : function(options) {
        MainMediator.on(CommonDefines.Event.SHOW_OPTION_MENU, this.render.bind(this));
        MainMediator.on(CommonDefines.Event.HIDE_OPTION_MENU, this.remove.bind(this));
        //KPI start
        this.KPIWeatherSetting = new KPI.WeatherSetting.WeatherSetting(this);
        //KPI end
    },

    render : function(options) {
        if (options) {
            Volt.log('type is' + options.type);
            this.options = {
                type : options.type
            };

            switch (options.type) {
                case CommonDefines.PopupType.OPTION_MENU : {
                    this.optionMenu = PanelCommon.loadTemplate(NewsonMainTemplate.optionMenuForChina, null, this.widget, false);
                    this.optionMenu.setCallback(this.onOptionMenuClick.bind(this));
                    this.optionMenu.setShowListArrow(false);
                    this.optionMenu.setShowCheckArrow(false);
                    this.optionMenu.setTimeout(function(){
                        MainMediator.trigger(CommonDefines.Event.HIDE_OPTION_MENU, this.options);
                    }.bind(this), CommonDefines.PopupTime.OPTION_TIMEOUT);
                    this.optionMenu.x = mainViewSelf.optionMenuX;
                    this.optionMenu.show();
                    Volt.Nav.beginModal(this.optionMenu);
                    break;
                }
                default :
                    break;
            }
        }
        return this;
    },
    
    remove : function(options) {
        Volt.log();
        Volt.Nav.endModal();
        switch (options.type) {
            case CommonDefines.PopupType.OPTION_MENU : {
                if(this.optionMenu) {
                    this.optionMenu.hide();
                    this.optionMenu.destroy();
                    this.optionMenu = null;
                }
                break;
            }
        }
        return this;
    },

    onOptionMenuClick : function(index, subIndex) {
        Volt.log('index - ' + index + ', subIndex - ' + subIndex);
        
        if (-1 == DeviceModel.getNetWorkState() && index == 0) {
            Volt.Nav.endModal();
            var ErrorHandler = Volt.require('app/common/errorHandler.js');
            ErrorHandler.show(CommonDefines.PopupType.NETWORK_ERROR1, 505, function() {
                Volt.Nav.beginModal(this.optionMenu);
            }.bind(this));
            return;
        }
        
        MainMediator.trigger(CommonDefines.Event.HIDE_OPTION_MENU, this.options);
//        if (index == 0) {
//            Backbone.history.navigate('tutorialColdStart', {
//                trigger : true
//            });
//        } else 
            if (index == 0) {
            //KPI start
            this.KPIWeatherSetting.send();
            //KPI end
            voltapi.rest.cancel();
            Backbone.history.navigate('weatherSetting', {
                trigger : true
            });
        }
    },

});

exports = MainView;
