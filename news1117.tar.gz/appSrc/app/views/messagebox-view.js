/** 
 * @author Zha Lihao(lihao.zha@samsung.com)
 * @fileoverview support common popup for panel
 * @date 2014/07/19
 * 
 * @version 1.4
 * 
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

// Include libraries
var _ = Volt.require('modules/underscore.js')._,
// Customize
    Button = Volt.require('modules/UIElement/Button_Generic.js');
    
    Require = Volt.require,
    
    Backbone = Require('lib/volt-backbone.js'),

// Require Common Modules
    PanelCommon = Require('lib/panel-common.js');

// Include example templates(should implement by apps panel member)
var MsgBoxTemplate = PanelCommon.requireTemplate('messagebox');

// Create an Mediator to commumicate between Views
var MsgBoxMediator = new PanelCommon.Mediator;
//Require common defines
var CommonDefines = Volt.require('app/common/commonDefines.js');
/**
 * get button view template
 * 
 * @function
 * @param {String}  type    			- common popup type
 * @return {Object} 					- Return the template according to popup type
 * @since 1.0
 *
 */
function getTemplate(type)
{
	var template;
	switch(type)
	{
		case PanelCommon.COMMON_POPUP_TYPE_SERVER_ERROR2:
		case 'VERSION_POPUP_CONFIRM':
			template = MsgBoxTemplate.msgbox_template_no_title_one_button;
			break;
		case PanelCommon.COMMON_POPUP_TYPE_NETWORK_ERROR1:
			template = MsgBoxTemplate.msgbox_template_no_title_two_button;
			break;
		default:
			print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'getTemplate, invalid type');
			break;
	}
	return template;
}

/**
 * get button mustache used for loading template
 * 
 * @function
 * @param {String}  type    			- common popup type
 * @return {Object} 					- Return the mustache according to popup type
 * @since 1.0
 *
 */
function getMustache(type)
{
	var mustache = {};
	switch(type)
	{
		case PanelCommon.COMMON_POPUP_TYPE_NETWORK_ERROR1:
		    mustache.message = MessageboxViewSelf.messageInfo;
			//mustache.message = Volt.LANG.TV_SID_NETWORK_ERROR1;
			mustache.btntext1 = Volt.LANG.TV_SID_NETWORK_STATUS;
			mustache.btntext2 = Volt.LANG.OK;
			break;
		case PanelCommon.COMMON_POPUP_TYPE_SERVER_ERROR2:
		case 'VERSION_POPUP_CONFIRM':
			mustache.message = MessageboxViewSelf.messageInfo;
			//mustache.message = Volt.LANG.TV_SID_SERVER_ERROR2;
			mustache.btntext1 = Volt.LANG.OK;
			break;
		default:
			print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'getMustache, invalid type');
			break;
	}
	return mustache;
}

/**
 * get timeout for messagebox
 * 
 * @function
 * @param {String}  type                - common popup type
 * @return {Object}                     - Return the timeout
 * @since 1.0
 *
 */
function getTimeout(type){
    var timeout;
    switch (type) {
        case PanelCommon.COMMON_POPUP_TYPE_NETWORK_ERROR1:
            timeout = CommonDefines.SPECIFIC_POPUOP_TIMEOUT;
            break;
        default :
            timeout = CommonDefines.SIMPLE_POPUOP_TIMEOUT;
    }
    return timeout;
}

/**
 * check if the type is common defined popup type
 * 
 * @function
 * @param {String}  type    			- common popup type
 * @return {Boolen} 					- Return true if type is common defined popup type, if not, return false
 * @since 1.0
 *
 */
function checkType(type)
{
	if(		type == PanelCommon.COMMON_POPUP_TYPE_NETWORK_ERROR1
		||	type == PanelCommon.COMMON_POPUP_TYPE_SERVER_ERROR2
		||  type == 'VERSION_POPUP_CONFIRM')
	{
		return true;
	}
	
	return false;
}

 /**
 * MessageboxView is used to create messagebox
 * @class MessageboxView
 * @since 1.0
 */
 ////////////////////////////////////////////////////////////////////////////////
/**
 * MessageboxView is view of List of Error Cases & Exceptions in "TV_2015_SmartHub_KeyScreen_Common_IA_v0.91_20140530.pdf".
 * <p>MessageboxView should extend from BaseView. It will be created and used as a popup widget
 *
 * @class MessageboxView
 * @memberof Views
 *
 * @property {Widget}   widget          - Basic Widget of this View. All content of this View should be drawn on this widget.
 * @property {template} template       - template of basic widgets
 * @property {Widget}   wParent        - parent widget of this message view
 * @property {String}     eType          - type of this message view
 * @property {Function} returnCB       - callback function when leave message view
 * @property {Function} initialize       - Constructor function. Do initialization inside.
 * @property {Function} render          - Core function to render element in the View.
 * @property {Function} show            - Show this message view
 * @property {Function} getWidget     - get basic widget of this view.
 * @property {Function} hide             - Hide this message view.
 * @property {Function} destroy         - Destroythis message view.
 * @property {Function} setReturnCB  - Set callback function when leave message view
 *
 */
 var MessageboxViewSelf = null;
var MessageboxView = PanelCommon.BaseView.extend({
	template: MsgBoxTemplate.container,
	wParent: null,				//parent of popup widget
	eType: null,				//msgbox type
	returnCB: null,				//callback function when select return
		messageInfo:null,
	btn1CB:null,
	btn2CB:null,	

/**
 * Constructor function. Do initialization inside
 * @function
 * @memberof MessageboxView
 * @return None
 */
	initialize : function(_parent,type,_messageInfo){
		//if parent is not valid, can not create popup successful
        if(!_parent)
		{
			print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + ' invalid parent that may cause unknown error');
			return;
		}
		//if type is not valid, can not create popup successful
		if(!type || !checkType(type))
		{
			print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + ' invalid type that may cause unknown error');
			return;
		}

		this.eType = type;
		this.wParent = _parent;
		this.messageInfo = _messageInfo;
		this.timeout = getTimeout(type);
		
		MessageboxViewSelf = this;
		
		MsgBoxMediator.on("EVENT_MESSAGE_BOX_POPUP_HIDE",this.hide,this);
    },

/**
 * Get the popup widget, used for parent view set it to parent widget
 * @function
 * @memberof MessageboxView
 * @return {Widget} basic widget of messagebox view
 */
	getWidget: function(){return this.widget;},

/**
 * show messagebox view, make sure it's create successful before call show function
 * @function
 * @memberof MessageboxView
 * @return None
 */
    show : function(){
		this.setWidget(PanelCommon.loadTemplate(MsgBoxTemplate.container));   
		this.widget.parent = this.wParent;
		this.widget.show();
		this.render();
		 
		this.widget.onKeyEvent = __onKeyEvent;				//set keyevent handle function for popup
		this.widget.startTimeOut = __startTimeOut;
        this.widget.resetTimeOut = __resetTimeOut;
        this.widget.clearTimeOut = __clearTimeOut;
        MsgBoxMediator.trigger("EVENT_MESSAGE_BOX_POPUP_SET_DEFAULT_FOCUS");
    },

/**
 * Render the static display elements.
 * @function
 * @memberof MessageboxView
 * @return None
 */
    render : function(){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' );
        this.widget.addChild(new ButtonView().render(this.eType).widget);
    },

/**
 * Hide messagebox view
 * @function
 * @memberof MessageboxView
 * @return None
 */
    hide : function(){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' );
        MsgBoxMediator.off("EVENT_MESSAGE_BOX_POPUP_HIDE",this.hide,this);
		if(!this.widget){
			return;
		}
		if(this.widget.clearTimeOut) {
		    this.widget.clearTimeOut();
		}
    	this.wParent.removeChild(this.widget);
        this.widget.hide();
        Volt.setTimeout(function(){
            this.destroy();
        }.bind(this),10);
    },

/**
 * destroy all the widget of this view, and stop listening EVENT_MESSAGE_BOX_POPUP_HIDE
 * @function
 * @memberof MessageboxView
 * @return None
 */
	destroy : function(){
    	if(!this.widget){
    	    return;
    	}
    	MsgBoxMediator.trigger("EVENT_MESSAGE_BOX_POPUP_DESTROY");
    	this.widget.destroy();
    	this.widget = null;

        this.returnCB(this.eType);
 	this.btn1CB = null;
	this.btn2CB = null;
    	this.wParent = null;			
    	this.eType = null;
    },

/**
 * set callback function, when leave messagebox view, callback function will trigger
 * @function
 * @memberof MessageboxView
 * @return None
 */
	setReturnCB : function(callback)
    {
		this.returnCB = callback;
    },
	
	setBtn1CB : function(callback)
    {
		this.btn1CB = callback;
    },
	
	setBtn2CB : function(callback)
    {
		this.btn2CB = callback;
    },
    
    startTimeOut : function(obj){
        this.widget.startTimeOut(obj);
    }

});


/**
 * ButtonView is used to create button and set functions
 * @class ButtonView
 * @since 1.0
 * @property {Widget}   widget               - Basic Widget of this View. All content of this View should be drawn on this widget.
 * @property {template} template            - template of basic widgets
 * @property {object}    btn1                  - UIElement of widget btn1
 * @property {object}    btn2                  - UIElement of widget btn2
 * @property {object}    btn3                  - UIElement of widget btn3
 * @property {object}    wFocused           - Save current focused btn
 * @property {Function} initialize            - Constructor function. Do initialization inside.
 * @property {Function} render               - Core function to render element in the View.
 * @property {Function} setDefaultFocus  - Set default focus of messagebox view
 * @property {Function} clickOK              - Handle OK key event
 * @property {Function} clickLeft             - Handle Left key event
 * @property {Function} clickRight           - Handle Right key event
 * @property {Function} destroy              - Destroy this message view.
 *
 * @example
 *
 * // Create a new ButtonView
 * var buttonView = new ButtonView();
 * buttonView.render(type);
 */
var ButtonView = PanelCommon.BaseView.extend({
	btn1 : null,
	btn2 : null,
	btn3 : null,
	wFocused : null,

/**
 * Constructor function. Do initialization inside
 * @function
 * @memberof ButtonView
 * @return None
 */
	initialize : function()
    {
		MsgBoxMediator.on("EVENT_MESSAGE_BOX_POPUP_SET_DEFAULT_FOCUS",this.setDefaultFocus,this);
		MsgBoxMediator.on("EVENT_MESSAGE_BOX_POPUP_DESTROY",this.destroy,this);
		MsgBoxMediator.on("EVENT_MESSAGE_BOX_POPUP_CLICK_OK",this.clickOK,this);
		MsgBoxMediator.on("EVENT_MESSAGE_BOX_POPUP_CLICK_LEFT",this.clickLeft,this);
		MsgBoxMediator.on("EVENT_MESSAGE_BOX_POPUP_CLICK_RIGHT",this.clickRight,this);
    },

/**
 * Render the static display elements. Create buttons according to type
 * @function
 * @memberof ButtonView
 * @return {View} this pointer to ButtonView
 */	
    render : function(type){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' );
        this.setWidget(PanelCommon.loadTemplate(getTemplate(type),getMustache(type)));	//loadtemplate according to type

		// if btn1 exist, create btn1 and set properties
		if(this.widget.getChild('btn1'))
		{
            		__initButton(this.widget.getChild('btn1'), this.widget);
           		 this.btn1 = this.widget.getChild('btn1').getUIElement();
			this.btn1.setMouseClickCallback(_.bind(
				function(){
					MsgBoxMediator.trigger("EVENT_MESSAGE_BOX_POPUP_HIDE");
		  		},this)
			);
		}
		
		// if btn2 exist, create btn2 and set properties
		if(this.widget.getChild('btn2'))
		{
			__initButton(this.widget.getChild('btn2'), this.widget);
           		 this.btn2 = this.widget.getChild('btn2').getUIElement();
			this.btn2.setMouseClickCallback(_.bind(
				function(){
					MsgBoxMediator.trigger("EVENT_MESSAGE_BOX_POPUP_HIDE");
		  		},this)
			);
		};

		// if btn3 exist, create btn3 and set properties
		if(this.widget.getChild('btn3'))
		{
			__initButton(this.widget.getChild('btn3'), this.widget);
            		this.btn3 = this.widget.getChild('btn3').getUIElement();
			this.btn3.setMouseClickCallback(_.bind(
				function(){
					MsgBoxMediator.trigger("EVENT_MESSAGE_BOX_POPUP_HIDE");
		  		},this)
			);
		};
        return this;
    },

/**
 * Set default focus of messagebox view
 * @function
 * @memberof ButtonView
 * @return None
 */
	setDefaultFocus : function()
	{
		if(this.btn1)
		{
			this.btn1.getFocus();
			this.wFocused = this.btn1;
		}
    },

/**
 * Handle OK key event
 * @function
 * @memberof ButtonView
 * @return None
 */
	clickOK : function(keyCode,keyType)
    {
		if(this.wFocused)
		{
			if((this.wFocused == this.btn1) && MessageboxViewSelf.btn1CB)
			{
				MessageboxViewSelf.btn1CB();
			}
			else if((this.wFocused == this.btn2) && MessageboxViewSelf.btn1CB)
			{
				MessageboxViewSelf.btn2CB();
			}			
			this.wFocused.keyHandler(keyCode,keyType);
		}
    },

/**
 * Handle left key event
 * @function
 * @memberof ButtonView
 * @return None
 */
	clickLeft : function()
    {
		if(this.wFocused == this.btn2)
		{
			this.btn1.getFocus();
			this.btn2.loseFocus();
			this.wFocused = this.btn1;
		}
		else if(this.wFocused == this.btn3)
		{
			this.btn2.getFocus();
			this.btn3.loseFocus();
			this.wFocused = this.btn2;
		}
	},

/**
 * Handle right key event
 * @function
 * @memberof ButtonView
 * @return None
 */
	clickRight : function()
    {
		if(this.btn2 &&
			this.wFocused == this.btn1)
		{
			this.btn2.getFocus();
			this.btn1.loseFocus();
			this.wFocused = this.btn2;
		}
		else if(this.btn3 &&
			this.wFocused == this.btn2)
		{
			this.btn3.getFocus();
			this.btn2.loseFocus();
			this.wFocused = this.btn3;
		}
    },
    
/**
 * destroy all the widget of this view, and stop listening events
 * @function
 * @memberof ButtonView
 * @return None
 */
	destroy : function(){
		//remove all the event listener
		MsgBoxMediator.off("EVENT_MESSAGE_BOX_POPUP_SET_DEFAULT_FOCUS",this.setDefaultFocus,this);
		MsgBoxMediator.off("EVENT_MESSAGE_BOX_POPUP_DESTROY",this.destroy,this);
		MsgBoxMediator.off("EVENT_MESSAGE_BOX_POPUP_CLICK_OK",this.clickOK,this);
		MsgBoxMediator.off("EVENT_MESSAGE_BOX_POPUP_CLICK_LEFT",this.clickLeft,this);
		MsgBoxMediator.off("EVENT_MESSAGE_BOX_POPUP_CLICK_RIGHT",this.clickRight,this);
		
		//destroy all the button object first
		if(this.widget)
		{
			//destroy message text
			if(this.widget.getChild('message'))
			{
				var widget = this.widget.getChild('message');
				widget.id = '';
				widget.destroy();
			}

			//destroy button widget(PS: button widget is used for saving button object template info)
			if(this.widget.getChild('btn1'))
			{
				var widget = this.widget.getChild('btn1');
				widget.id = '';
				widget.destroy();
			}
			if(this.widget.getChild('btn2'))
			{
				var widget = this.widget.getChild('btn2');
				widget.id = '';
				widget.destroy();
			}
			if(this.widget.getChild('btn3'))
			{
				var widget = this.widget.getChild('btn3');
				widget.id = '';
				widget.destroy();
			}
			this.widget.destroy();
		}
    }
});

/**
 * create button
 * 
 * @function
 * @param {widget}  widget    			- button widget
 * @param {string}  text    			- text of button
 * @param {widget}  parent    			- parent widget of button object
 * @return None 					
 * @since 1.0
 *
 */
function __initButton(widget, parent) {
    var btn = widget.getUIElement();
             
    btn.setText(btn.buttonState.STATE_UNFOCUSED, widget.text);
    btn.setText(btn.buttonState.STATE_FOCUSED, widget.text);
    btn.setText(btn.buttonState.STATE_PRESSED, widget.text);
         
    btn.parent = parent;
    btn.show();
    btn.enableMouseClick(true);
}

/**
 * handle key event
 * 
 * @function
 * @param {number}  KeyCode    			- key code
 * @return {number}  type 				- key type
 * @return {Boolean}  						- if key is handled, return ture, if not, return false
 * @since 1.0
 *
 */
function __onKeyEvent(KeyCode,type){
	if (type == Volt.EVENT_KEY_RELEASE)
	{
		return false;
	}
	var ret = false;
	switch(KeyCode) {
		case Volt.KEY_RETURN:
			MsgBoxMediator.trigger("EVENT_MESSAGE_BOX_POPUP_HIDE");
			ret = true;
			break;
		case Volt.KEY_JOYSTICK_OK:
			MsgBoxMediator.trigger("EVENT_MESSAGE_BOX_POPUP_CLICK_OK",KeyCode,type);
			ret = true;
			break;
		case Volt.KEY_JOYSTICK_LEFT:
			MsgBoxMediator.trigger("EVENT_MESSAGE_BOX_POPUP_CLICK_LEFT");
			ret = true;
			break;
		case Volt.KEY_JOYSTICK_RIGHT:
			MsgBoxMediator.trigger("EVENT_MESSAGE_BOX_POPUP_CLICK_RIGHT");
			ret = true;
			break;
		default:
			break;
	}
	if(ret === true){
        this.resetTimeOut();
    }
	return ret;
}


function __startTimeOut(obj) {
    if (obj.hasOwnProperty("time")) {
        this.timeOutTime = obj.time;
    }
    this.timer = Volt.setTimeout(function() {
        MsgBoxMediator.trigger("EVENT_MESSAGE_BOX_POPUP_HIDE");
    }.bind(this), this.timeOutTime);
};

function __resetTimeOut() {
    if (this.timer != null) {
        Volt.clearTimeout(this.timer);
        this.timer = Volt.setTimeout(function() {
            MsgBoxMediator.trigger("EVENT_MESSAGE_BOX_POPUP_HIDE");
        }.bind(this), this.timeOutTime);
    }
};

function __clearTimeOut() {
    if (this.timer != null) {
        Volt.clearTimeout(this.timer);
        this.timer = null;
    }
};
exports = MessageboxView;
