/**
 * @author Zhu Hongjie (hj00.zhu@samsung.com)
 * @fileoverview Weather Setting View.
 * @date 2014/09/11(last modified date)
 * 
 * Copyright 2014 by Samsung Electronics, Inc.
 * 
 * This software is the confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung.
 */
/* Include libraries*/
var PanelCommon = Volt.require('lib/panel-common.js');
var Q = PanelCommon.Q;
var BaseView = PanelCommon.BaseView;
var Backbone = Volt.require('lib/volt-backbone.js');
var _ = Volt.require('modules/underscore.js')._;
var voltapi = Volt.require('modules/voltapi.js');

/*Require LoadingDialog*/
var LoadingDialog = Volt.require('app/views/loading-view.js');

var DeviceModel = Volt.require('app/common/deviceModel.js');

/*Require customization function*/ 
var customizationButton = Volt.require('app/common/customization-button.js');
var customizationIcon = Volt.require('app/common/customization-icon.js');

var Gridlist = Volt.require('app/views/grid-list-view.js');

/* Include models*/
var WeatherSettingModel = Volt.require('app/models/newson-weather-setting-model.js');
var WeatherCityListModel = Volt.require('app/models/newson-weather-city-list-model.js');

/* Require Specific template for WeatherSettingView*/
var WeatherSettingTemplate = Volt.requireAppTemplate('newson-weather-setting-template-china.js');
/*Require Common templates of Newson*/
var CommonTemplate = Volt.requireAppTemplate('newson-common-template.js');
/*Require dim view*/
var dimView = PanelCommon.requireView('dim');
/*Create an Mediator to commumicate between WeatherSettingView and its sub Views*/
var Mediator = new PanelCommon.Mediator();
/*Require global Variation*/
var Global = Volt.require('app/common/Global.js');
/*Require GlobalMediator*/
var GlobalMediator = Volt.require('app/common/GlobalMediator.js');
/*Require common defines*/
var CommonDefines = Volt.require('app/common/commonDefines.js');

//KPI start
var KPI = Volt.require('app/common/kpi-options.js');
var KPIOptions = KPI.WeatherSetting;
var selfSetting = null;
//KPI end

/**
 * @description WeatherSettingView is view of "4.1. Settigs Screen_Weather Settings" in "TV_2015_SmartHub_NewsON_IA
 * Guideline_v1.0a_20140718.pdf", and "News Setting / China" in "2015_News_GUI_Guideline_v1.0a_20140718.pdf".
 * @class WeatherSettingView
 * 
 * @property {Widget} widget - Basic Widget of this view. All content of this view should be drawn on this widget.
 * @property {Function} render - Core function to render element in this View.
 * @property {Function} show - Show this view. Invoked when come back from other View
 * @property {Function} hide - Hide this view. Invoked when leave from this view
 * @property {Function} onKeyEvent - Let the View have the chance to handle key events in this view.
 * @property {Function} renderTitle - Render title.
 * @property {Function} renderContainer - Render container.
 * @property {Function} renderPopup - Render popup.
 * @property {Function} backToMainView - Back to panel main view.
 * @property {Function} onError - Callback of WeatherSettingModel if WeatherSettingModel fetch error.
 * @property {Function} setFocus - Set focus by index
 * @property {Function} updateToServer - Update selected cities to server
 * @property {Function} pause - Pause this view. Invoked when some popup view popup over this View
 * @property {Function} resume - Invoked when come back from popup
 * @requires {@link Backbone}
 * @requires {@link PanelCommon}
 * @requires {@link Volt}
 * @requires {@link Volt.Nav}
 * @requires {@link WeatherSettingModel}
 * @requires {@link WeatherCityListModel}
 * @requires {@link WeatherSettingTemplate}
 * @requires {@link LoadingDialog}
 */
var WeatherSettingView = BaseView.extend({
    template : WeatherSettingTemplate.main,
    isFresh : true,

    /**
     * @description Render the static display elements.
     * @function render
     * @memberof WeatherSettingView
     * @return {View} return this WeatherSettingView
     */
    render : function() {
        Volt.log();

        /* Parse and load the template*/
        this.setWidget(PanelCommon.loadTemplate(this.template, null, null, false));
        /*Render every sub view*/
        this.renderTitle();
        this.renderContainer();
//        this.renderPopup();
        return this;
    },

    /**
     * @description Show this view. Invoked when come back from other View
     * @function show
     * @memberof WeatherSettingView
     * @param {Object} options - All options from router path or navigate/back parameters.
     * @param {String} animationType - Type of Animation
     * @return None
     */
    show : function(options, animationType) {
        Volt.log();
        Volt.Nav.block();

        /* Listen to this event to set focus to city when focusIndex is 2, and hide the loadingDialog, and unblock*/
        this.listenTo(Mediator, CommonDefines.Event.SET_FOCUS_BY_INDEX, this.setFocus);

        /* Listen to this event to update the server data by WeatherSettingModel*/
        this.listenTo(Mediator, CommonDefines.Event.UPDATE_SETTING_CITIES_TO_SERVER, this.updateToServer);

        this.listenTo(WeatherSettingModel, 'complete', function(cityListLength) {
            if (cityListLength > 0) {
                /* Listen to completed parse in WeatherCityListModel to update provincecontent and citycontent*/
                this.listenTo(WeatherCityListModel, 'complete', function() {
                    WeatherSettingModel.beginListeningChange();
                    selfSetting.isShow = true;
                    Mediator.trigger(CommonDefines.Event.REFRESH_PROVINCE);
                    Mediator.trigger(CommonDefines.Event.UPDATE_SELECTED_CITIES_2);
                });

                /* Listen to the status of error in WeatherCityListModel to handle error*/
                this.listenTo(WeatherCityListModel, 'error', this.onError.bind(this));

                /* Listen to the status of saveSuccess in WeatherSettingModel to show save popup*/ 
                this.listenTo(WeatherSettingModel, 'success', function() {
                    var ErrorHandler = Volt.require('app/common/errorHandler.js');
                    ErrorHandler.show(CommonDefines.PopupType.SAVE, null, this.backToMainView);
                });

                WeatherCityListModel.setInitData();
                WeatherCityListModel.fetch({});
            } else {
                Volt.log('Should not be here!');
                this.onError('0 city is currently saved on server.');
            }
        }.bind(this));

        this.containerView.show();
        this.titleView.show();
//        this.popupView.show();

        this.loadingDialog = LoadingDialog;
        this.loadingDialog.show(1);
        
      //KPI start
        selfSetting = this;
        this.model = WeatherSettingModel;
        this.KPISave = new KPIOptions.Save(this);
        this.KPICancel = new KPIOptions.Cancel(this);
        //KPI end
        
        PanelCommon.doViewSwitchAni(this.widget, animationType).then(function() {
            WeatherSettingModel.fetch();
            if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
            {
                print('wether setting view show');
                print(VDUtil.getProcMemory());
            }
        });
    },

    /**
     * @description Opposite operation of show, hide what you have shown.
     * @function hide
     * @memberof WeatherSettingView
     * @param {Object} options - All options from router path or navigate/back parameters.
     * @param {String} animationType - Type of Animation
     * @return {Object} return deferred.promise
     */
    hide : function(options, animationType) {
        selfSetting.isShow = false;
        Volt.log();
        var deferred = Q.defer();
        Volt.Nav.focus(null);
        this.stopListening();
        if(this.loadingDialog) {
            this.loadingDialog.hide();
            Volt.Nav.unblock();
            this.loadingDialog = null;
        }
        Mediator.off();
        this.stopListening(GlobalMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR);
        PanelCommon.doViewSwitchAni(this.widget, animationType).then(function() {
            this.containerView.release();
            if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
            {
                print('wether setting view hide');
                gc();
                print(VDUtil.getProcMemory());
            }
            deferred.resolve();
        }.bind(this));

        return deferred.promise;
    },

    /**
     * @description View handle key event, if return false, let nav to handle this key event.
     * @function onKeyEvent
     * @memberof WeatherSettingView
     * @param {enum} keyCode - key code
     * @param {enum} keyType - key type
     * @return {boolean} return the status of handle key event
     */
    onKeyEvent : function(keyCode, keyType) {
        if (keyCode == Volt.KEY_RETURN && keyType == Volt.EVENT_KEY_PRESS) {
            var ErrorHandler = Volt.require('app/common/errorHandler.js');
            ErrorHandler.show(CommonDefines.PopupType.CANCEL);
            return true;
        } else if(keyCode == Volt.KEY_8){
            return true;
        }
        return false;
    },
    
    /**
     * @description Render title.
     * @function renderTitle
     * @memberof WeatherSettingView
     * @return None
     */
    renderTitle : function(){
        (this.titleView || (this.titleView = new TitleView({
            widget : this.widget.getChild('newson-weather-setting-title-area')
        }))).render();
    },

    /**
     * @description Render container.
     * @function renderContainer
     * @memberof WeatherSettingView
     * @return None
     */
    renderContainer : function() {
        (this.containerView || (this.containerView = new ContainerView({
            widget : this.widget.getChild('newson-weather-setting-container-area')
        }))).render();
    },

    /**
     * @description Back to panel main view.
     * @function backToMainView
     * @memberof WeatherSettingView
     * @return None
     */
    backToMainView : function() {
        Backbone.history.back();
    },

    /**
     * @description Callback of WeatherSettingModel if WeatherSettingModel fetch error.
     * @function onError
     * @memberof WeatherSettingView
     * @param {Object} object - the http request object
     * @param {String} status - show the http request's status
     * @param {String} exception - pass the exception
     * @return None
     */
    onError : function(object, status, exception) {
        Volt.log();
        Volt.Nav.unblock();
        this.loadingDialog.hide();
        var ErrorHandler = Volt.require('app/common/errorHandler.js');
        
        if(arguments.length === 0){
            ErrorHandler.show(CommonDefines.PopupType.EM_FROM_CITYLIST_SERVER, null, this.backToMainView);
        } else {
            ErrorHandler.show(CommonDefines.PopupType.SERVER_ERROR2, 404, this.backToMainView);
        }
    },
    
    /**
     * This function will be called when coding like [Mediator.trigger(CommonDefines.Event.SET_FOCUS_BY_INDEX);].
     * @description Set focus by index
     * @function setFocus
     * @memberof WeatherSettingView
     * @param {Number} index - the focus index
     * @return None
     */
    setFocus : function(focusIndex) {
        Volt.log('focusIndex - ' + focusIndex);
        if(Global.APP_STATUS === Global.APP_DEACTIVATE)
        {
            this.lastFocusIndex = focusIndex;
            Volt.log('Global.APP_DEACTIVATE');
        } 
        else
        {
            this.lastFocusIndex = null;
            if (focusIndex == 2) {
                Mediator.trigger(CommonDefines.Event.SET_FOCUS_TO_CITY, this.widget);
            } else {
                Mediator.trigger(CommonDefines.Event.SET_FOCUS_TO_PROVINCE, this.widget);
            }
            Volt.log('Global.APP_ACTIVATE');
        }
        if(this.loadingDialog) {
            this.loadingDialog.hide();
            Volt.Nav.unblock();
            this.loadingDialog = null;
        }
    },
    
    /**
     * This function will be called when coding like [Mediator.trigger(CommonDefines.Event.UPDATE_SETTING_CITIES_TO_SERVER);].
     * @description Update selected cities to server
     * @function updateToServer
     * @memberof WeatherSettingView
     * @return None
     */
    updateToServer : function() {
        if (-1 == DeviceModel.getNetWorkState()) {
            Volt.Nav.focus(null);
            var ErrorHandler = Volt.require('app/common/errorHandler.js');
            ErrorHandler.show(CommonDefines.PopupType.NETWORK_ERROR1, 505, this.backToMainView);
            return;
        }
        WeatherSettingModel.updateToServer();
    },
    
    /**
         * Pause this view. Invoked when some popup view popup over this View
         * @function
         * @memberof MainView
         */
    pause : function() {
        Volt.log();
        dimView.show({
            parent : scene
        });
    },

    /**
     * Invoked when come back from popup
     * @function
     * @memberof MainView
     */
    resume : function() {
        Volt.log();
        dimView.hide();
        Volt.log('lastFocusIndex - ' + this.lastFocusIndex);
        if (this.lastFocusIndex != null) {
            if (this.lastFocusIndex == 2) {
                Mediator.trigger(CommonDefines.Event.SET_FOCUS_TO_CITY, this.widget);
            } else {
                Mediator.trigger(CommonDefines.Event.SET_FOCUS_TO_PROVINCE, this.widget);
            }
            this.lastFocusIndex = null;
        }
    }


});

/**
 * @description TitleView is sub view of WeatherSettingView.
 * @class TitleView
 * 
 * @property {Widget} widget - Basic Widget of this view.
 * @property {Function} render - Core function to render element in the View.
 * @property {Function} show - Show this view. Invoked when come back from other View
 * @property {Function} hide - Hide this view. Invoked when back to other View
 * @property {Function} renderText - Render the text of title.
 * @property {Function} renderReturnButton - Render the return button.
 * @property {Function} onChangeCursor - Show or Hide Return button
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 */
var TitleView = BaseView.extend({
    template : WeatherSettingTemplate.titleArea,

    /**
     * @description Render the static display elements.
     * @function render
     * @memberof TitleView
     * @return {View} return this TitleView
     */
    render : function() {
        Volt.log();
        this.setWidget(PanelCommon.loadTemplate(this.template, null, this.widget));
        this.renderText();
        this.renderReturnButton();
        return this;
    },
    
    /**
     * @description Show this view. Invoked when come back from other View
     * @function show
     * @memberof TitleView
     * @return None
     */
    show : function(){
        if( !voltapi.vconf.getValue(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE)){
            Volt.log();
            this.returnButton.hide();
        } else {
            this.returnButton.show();
        }

        this.listenTo(GlobalMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, this.onChangeCursor);
    },
    
    /**
     * @description Render the text of title.
     * @function renderText
     * @memberof TitleView
     * @return None
     */
    renderText : function() {
        this.text = this.widget.getDescendant('newson-weather-setting-title-text');
    },

    /**
     * @description Render the return button.
     * @function renderReturnButton
     * @memberof TitleView
     * @return None
     */
    renderReturnButton : function() {
        this.returnButton = this.widget.getDescendant('newson-weather-setting-return-button');
        customizationIcon(this.returnButton, {
            imageStyle : 'pageReturn'
        });
        this.returnButton.onMouseClick = function() {
            var ErrorHandler = Volt.require('app/common/errorHandler.js');
            ErrorHandler.show(CommonDefines.PopupType.CANCEL);
        };
    },
    
    /** 
     * This function will be called when coding like [GlobalMediator.trigger(CommonDefines.Event.CHANGE_VISIBLE_CURSOR);].
     * Show or Hide Return button
     * @function onChangeCursor
     * @memberof TitleView
     */
     onChangeCursor : function(visible){
         Volt.log();
         if( this.returnButton ){
             if(visible){
                 this.returnButton.show();
             }else{
                 this.returnButton.hide();
             }
         }
     },
});

/**
 * @description ContainerView is sub view of WeatherSettingView.
 * @class ContainerView
 * 
 * @property {Widget} widget - Basic Widget of this view.
 * @property {Function} render - Core function to render element in the View.
 * @property {Function} show - Show this view. Invoked when come back from other View
 * @property {Function} renderTipView - Render the tips.
 * @property {Function} renderButtons - Render the buttons.
 * @property {Function} renderProvinceContentView - Render province content.
 * @property {Function} renderCityContentView - Render city content.
 * @property {Function} release - Release resource used in sub view of this view or re-initialize sub view of this view.
 * 
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 */
var ContainerView = BaseView.extend({
    template : WeatherSettingTemplate.containerArea,

    /**
     * @description Render the static display elements.
     * @function render
     * @memberof ContainerView
     * @return {View} return this ContainerView
     */
    render : function() {
        Volt.log();
        PanelCommon.loadTemplate(this.template, null, this.widget);
        this.renderTipView();
        this.renderButtons();
        this.renderProvinceContentView();
        this.renderCityContentView();

        return this;
    },

    /**
     * @description Show this view. Invoked when come back from other View
     * @function show
     * @memberof ContainerView
     * @return None
     */
    show : function() {
        this.tipView.show();
        this.provinceView.show();
        this.cityView.show();
        this.buttonView.show();
    },

    /**
     * @description Render the tips.
     * @function renderTipView
     * @memberof ContainerView
     * @return None
     */
    renderTipView : function() {
        (this.tipView || (this.tipView = new TipView({
            widget : this.widget.getDescendant('newson-weather-setting-tip-area')
        }))).render();
    },

    /**
     * @description Render the buttons.
     * @function renderButtons
     * @memberof ContainerView
     * @return None
     */
    renderButtons : function() {
        (this.buttonView || (this.buttonView = new ButtonView({
            widget : this.widget.getDescendant('newson-weather-setting-button-area')
        }))).render();
    },

    /**
     * @description Render province content, include province list
     * @function renderProvinceContentView
     * @memberof ContainerView
     * @return None
     */
    renderProvinceContentView : function() {
        (this.provinceView || (this.provinceView = new ProvinceContentView({
            widget : this.widget.getDescendant('newson-weather-setting-province-content-area')
        }))).render();
    },

    /**
     * @description Render city content, include city list
     * @function renderCityContentView
     * @memberof ContainerView
     * @return None
     */
    renderCityContentView : function() {
        (this.cityView || (this.cityView = new CityContentView({
            widget : this.widget.getDescendant('newson-weather-setting-city-content-area')
        }))).render();
    },

    /**
     * @description Release resource used in sub view of this view or re-initialize sub view of this view.
     * @function release
     * @memberof ContainerView
     * @return None
     */
    release : function() {
        this.provinceView.release();
        this.cityView.release();
        this.tipView.release();
        this.buttonView.release();
    }
});

/**
 * @description TipView is sub view of ContainerView.
 * @class TipView
 * 
 * @property {Widget} widget - Basic Widget of this view.
 * @property {TextWidget} selectedCountItem - This widget displays the selected count of WeatherSettingModel.
 * @property {Function} render - Render tip area in this view.
 * @property {Function} show - Show this view. Invoked when come back from other View
 * @property {Function} updateSelectedCount - Update the text of selectedCountItem in this view.
 * @property {Function} release - Release resource used in this view or re-initialize this view.
 * 
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 */
var TipView = BaseView.extend({
    template : WeatherSettingTemplate.tipArea,
    selectedCountItem : null,

    /**
     * @description Render tip area in this view.
     * @function render
     * @memberof TipView
     * @return {View} return this TipView
     */
    render : function() {
        Volt.log();
        PanelCommon.loadTemplate(this.template, null, this.widget);
        this.selectedCountItem = this.widget.getDescendant('newson-weather-setting-selected-count');
        this.updateSelectedCount(0);
        return this;
    },

    /**
     * @description Show this view. Invoked when come back from other View
     * @function show
     * @memberof TipView
     * @return None
     */
    show : function() {
        /* Listen to this event to update the text of selectedCountItem in this view.*/
        this.listenTo(Mediator, CommonDefines.Event.UPDATE_SELECTED_CITIES_2, this.updateSelectedCount.bind(this));
    },

    /**
     * This function will be called when coding like [Mediator.trigger(CommonDefines.Event.UPDATE_SELECTED_CITIES_2);].
     * @description Update the text of selectedCountItem in this view.
     * @function updateSelectedCount
     * @memberof TipView
     * @param {Number} count - The selected count
     * @return None
     */
    updateSelectedCount : function(count) {
        if('number' != typeof count) {
            count = WeatherSettingModel.getSelectedCount();
        }
        var content;
        if (count > 1) {
            content = Volt.i18n.t('COM_SID_MIX_CITIES_CURRENTLY_SELECTED', {A : count});
        } else {
            content = Volt.i18n.t('COM_SID_1_CITY_CURRENTLY_SELECTED');
            if(count == 0) {
                content = content.replace('1', '0');
            }
        }
        this.selectedCountItem.text = content;
    },

    /**
     * @description Release resource used in this view or re-initialize this view.
     * @function release
     * @memberof TipView
     * @return None
     */
    release : function() {
        this.updateSelectedCount(0);
    }

});

/**
 * @description ButtonView is sub view of ContainerView.
 * @class ButtonView
 * 
 * @property {Widget} widget - Basic Widget of this view.
 * @property {Button_Generic} cancelButton - The cancel button.
 * @property {Button_Generic} saveButton - The save button.
 * @property {Function} render -Render buttons in this view.
 * @property {Function} renderCancelButton - Render the cancel button.
 * @property {Function} renderSaveButton - Render the save button.
 * @property {Function} onSelectCancelButton - ButtonView's selected callback.
 * @property {Function} onSelectSaveButton - ButtonView's selected callback.
 * @property {Function} onFocus - ButtonView's focus callback.
 * @property {Function} onBlur - ButtonView's blur callback.
 * 
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 * @requires {@link customizationButton}
 */
var ButtonView = BaseView.extend({
    template : WeatherSettingTemplate.buttonArea,
    cancelButton : null,
    saveButton : null,

    /**
     * @description Render buttons in this view.
     * @function render
     * @memberof ButtonView
     * @return {View} return this ButtonView
     */
    render : function() {
        Volt.log();
        this.setWidget(PanelCommon.loadTemplate(this.template, null, this.widget));
        return this;
    },
    
    show : function() {
        this.renderSaveButton();
        this.renderCancelButton();
    },
    
    release : function() {
        Volt.setTimeout(function(){
            this.saveButton.release();
            this.cancelButton.release();
            this.saveButton = null;
            this.cancelButton = null;
        }.bind(this), 1);
    },

    /**
     * @description Render the cancel button.
     * @function renderCancelButton
     * @memberof ButtonView
     * @return None
     */
    renderCancelButton : function() {
        Volt.log();
        var cancelButtonWidget = this.widget.getDescendant('newson-weather-setting-cancel-button');
        this.cancelButton = new Button({
            x : 0,
            y : 0,
            width : cancelButtonWidget.width,
            height : cancelButtonWidget.height,
            color : Volt.hexToRgb('#ffffff', 0),
            parent : cancelButtonWidget
        });
        customizationButton(this.cancelButton, {
            text : Volt.i18n.t('SID_CANCEL'),
            style : CommonTemplate.buttonTextStyleC,
            callback : this.onSelectCancelButton
        });
    },

    /**
     * @description Render the save button.
     * @function renderSaveButton
     * @memberof ButtonView
     * @return None
     */
    renderSaveButton : function() {
        Volt.log();
        var saveButtonWidget = this.widget.getDescendant('newson-weather-setting-save-button');
        this.saveButton = new Button({
            x : 0,
            y : 0,
            width : saveButtonWidget.width,
            height : saveButtonWidget.height,
            color : Volt.hexToRgb('#ffffff', 0),
            parent : saveButtonWidget
        });
        customizationButton(this.saveButton, {
            text : Volt.i18n.t('COM_BUTTON_SAVE'),
            style : CommonTemplate.buttonTextStyleC,
            callback : this.onSelectSaveButton
        });
    },

    events : {
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },

    /**
     * @description ButtonView's selected callback.
     * @function onSelectCancelButton
     * @memberof ButtonView
     * @return None
     */
    onSelectCancelButton : function() {
        //KPI start
        selfSetting.KPICancel.send();
        //KPI end
        Volt.log();
        var ErrorHandler = Volt.require('app/common/errorHandler.js');
        ErrorHandler.show(CommonDefines.PopupType.CANCEL);
    },

    /**
     * @description ButtonView's selected callback.
     * @function onSelectSaveButton
     * @memberof ButtonView
     * @return None
     */
    onSelectSaveButton : function() {
        //KPI start
        selfSetting.KPISave.send();
        //KPI end
        Volt.log();
        Mediator.trigger(CommonDefines.Event.UPDATE_SETTING_CITIES_TO_SERVER);
    },

    /**
     * @description ButtonView's focus callback.
     * @function onFocus
     * @memberof ButtonView
     * @param {Widget} widget - the widget is focused
     * @return None
     */
    onFocus : function(widget) {
        Volt.log('Button');
        if(widget.getChild(0)){
            widget.getChild(0).setFocus();
        }
        //voice guide
        if (1 == DeviceModel.getMenuTTS()){
            var voiceText = 'Save, button';
            if ('newson-weather-setting-button2' == widget.id){
                voiceText = 'Cancel, button';
            }
            Global.voiceGuide(voiceText);
        }
    },

    /**
     * @description ButtonView's blur callback.
     * @function onBlur
     * @memberof ButtonView
     * @param {Widget} widget - the widget is blurred
     * @return None
     */
    onBlur : function(widget) {
        Volt.log('Button');
        if(widget.getChild(0)){
            widget.getChild(0).killFocus();
        }
    }

});

/**
 * @description ProvinceContentView is sub view of ContainerView.
 * @class ProvinceContentView
 * 
 * @property {Widget} widget - Basic Widget of this view.
 * @property {GridListControl} list - The list of this view.
 * @property {Function} render - Render list, list background in this view.
 * @property {Function} show - Show this view. Invoked when come back from other View
 * @property {Function} provinceRefresh - Update the data of list in this view.
 * @property {Function} release - Release resource used in this view or re-initialize this view.
 * @property {Function} renderList - Render list in this view.
 * 
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 * @requires {@link WeatherCityListModel}
 * @requires {@link customizationIcon}
 */
var ProvinceContentView = BaseView.extend({
    template : WeatherSettingTemplate.provinceContentArea,
    list : null,

    /**
     * @description Render list, list background in this view.
     * @function render
     * @memberof ProvinceContentView
     * @return {View} return this ProvinceContentView
     */
    render : function() {
        PanelCommon.loadTemplate(this.template, null, this.widget);
        return this;
    },

    /**
     * @description Show this view. Invoked when come back from other View
     * @function show
     * @memberof ProvinceContentView
     * @return None
     */
    show : function() {
        /* Listen to this event to update the data of list in this view*/
        this.listenTo(Mediator, CommonDefines.Event.REFRESH_PROVINCE, this.provinceRefresh);

        /* Listen to this event to set focus to the list of this view*/
        this.listenTo(Mediator, CommonDefines.Event.SET_FOCUS_TO_PROVINCE, function(root) {
            Volt.Nav.setRoot(root, {
                focus : this.list.widget
            });
        }.bind(this));
    },

    /**
     * This function will be called when coding like [Mediator.trigger(CommonDefines.Event.REFRESH_PROVINCE)].
     * @description Update the data of list in this view.
     * @function provinceRefresh
     * @memberof ProvinceContentView
     * @return None
     */
    provinceRefresh : function() {
        Volt.log(JSON.stringify(WeatherCityListModel.get('provinceCollection').pluck('index')));
        this.renderList(WeatherCityListModel.get('provinceCollection').pluck('province'));
    },

    /**
     * @description Release resource used in this view or re-initialize this view.
     * @function release
     * @memberof ProvinceContentView
     * @return None
     */
    release : function() {
        this.list.destroy();
        this.list = null;
    },

    /**
     * @description Render list in this view.
     * @function renderList
     * @memberof ProvinceContentView
     * @return None
     */
    renderList : function(provinces) {
        (this.list || (this.list = new ProvinceList(this.widget.getDescendant('newson-weather-setting-province-list'), provinces.length))).render(provinces);
    }
    
});

/**
 * @description CityContentView is sub view of ContainerView.
 * @class CityContentView
 * 
 * @property {Widget} widget - Basic Widget of this view.
 * @property {GridListControl} list - The list of this view.
 * @property {Object} cityCollection - The collection of city of WeatherCityListModel.
 * @property {Number} provinceIndex - The index of the selected province.
 * @property {Function} render - Render list, list background in this view.
 * @property {Function} show - Show this view. Invoked when come back from other View
 * @property {Function} updateSelectedCity - Update the codeArray of WeatherSettingModel.
 * @property {Function} cityRefresh - Update the data of list in this view.
 * @property {Function} release - Release resource used in this view or re-initialize this view.
 * @property {Function} renderList - Render list in this view.
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 * @requires {@link WeatherCityListModel}
 * @requires {@link WeatherSettingModel}
 * @requires {@link customizationIcon}
 */
var CityContentView = BaseView.extend({
    template : WeatherSettingTemplate.cityContentArea,
    list : null,
    cityCollection : null,
    provinceIndex : null,

    /**
     * @description Render list, list background in this view.
     * @function render
     * @memberof CityContentView
     * @return {View} return this CityContentView
     */
    render : function() {
        PanelCommon.loadTemplate(this.template, null, this.widget);
        return this;
    },

    /**
     * @description Show this view. Invoked when come back from other View
     * @function show
     * @memberof CityContentView
     * @return None
     */
    show : function() {
        /* Listen to this event to update the codeArray of WeatherSettingModel.*/
        this.listenTo(Mediator, CommonDefines.Event.UPDATE_SELECTED_CITIES_1, this.updateSelectedCity.bind(this));

        /* Listen to this event to set focus to the list of this view*/
        this.listenTo(Mediator, CommonDefines.Event.SET_FOCUS_TO_CITY, function(root) {
            Volt.Nav.setRoot(root, {
                focus : this.list.widget
            });
        }.bind(this));

        /* Listen to this event to update the data of list in this view*/
        this.listenTo(Mediator, CommonDefines.Event.REFRESH_CITY, this.cityRefresh.bind(this));
    },

    /**
     * This function will be called when coding like [Mediator.trigger(CommonDefines.Event.UPDATE_SELECTED_CITIES_1)].
     * @description update the codeArray of WeatherSettingModel.
     * @function updateSelectedCity
     * @memberof CityContentView
     * @param {Number} index - The index of selected city
     * @return None
     */
    updateSelectedCity : function(index) {
        WeatherSettingModel.updateCityStatus(this.cityCollection.at(index).get('code'));
        Mediator.trigger(CommonDefines.Event.UPDATE_SELECTED_CITIES_2);
    },

    /**
     * This function will be called when coding like [Mediator.trigger(CommonDefines.Event.REFRESH_CITY)].
     * @description Update the data of list in this view.
     * @function cityRefresh
     * @memberof CityContentView
     * @param {Number} index - the selected province index
     * @param {Boolean} focusIndex - if city should get focus focusIndex is 2.
     * @return None
     */
    cityRefresh : function(index, focusIndex) {
        Volt.log('index - ' + index + ' oldIndex - ' + this.provinceIndex + ' focusIndex - ' + focusIndex);
        if(this.provinceIndex !== index){
            this.provinceIndex = index;
            this.cityCollection = WeatherCityListModel.get('provinceCollection').at(index).get('cityCollection');
            Volt.log(JSON.stringify(this.cityCollection.pluck('index')));
            if(this.list!=null){
                this.list.destroy();
                this.list = null;
            }
            this.renderList(this.cityCollection);
            this.list.widget.provinceName = WeatherCityListModel.get('provinceCollection').at(index).get('province');
            Mediator.trigger(CommonDefines.Event.SET_FOCUS_BY_INDEX, focusIndex);
        }
    },

    /**
     * @description Release resource used in this view or re-initialize this view.
     * @function release
     * @memberof CityContentView
     * @return None
     */
    release : function() {
        this.provinceIndex = null;
        this.cityCollection = null;
        this.list.destroy();
        this.list = null;
    },


    /**
     * @description Render list in this view.
     * @function renderList
     * @memberof CityContentView
     * @return None
     */
    renderList : function(cityCollection) {
//        (this.list || (this.list = new CityList(this.widget.getDescendant('newson-weather-setting-city-list')))).render(cityCollection);
        this.list = new CityList(this.widget.getDescendant('newson-weather-setting-city-list'), cityCollection.length).render(cityCollection);
    }

});

/**
 * @description ProvinceList is the list of ProvinceContentView.
 * @class ProvinceList
 * 
 * @property {GridListControl} widget - Basic Widget of this view.
 * @property {Function} render - Render list.
 * @property {Function} onFocus - ProvinceList's focus callback.
 * @property {Function} onBlur - ProvinceList's blur callback.
 * 
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 */
var ProvinceList = BaseView.extend({
    template : WeatherSettingTemplate.provinceList,
    
    /**
     * @description initialize list.
     * @function initialize
     * @memberof ProvinceList
     */
    initialize : function(container, length){
        var provinceList = new Gridlist(this.template, container).render().widget;
        this.setWidget(provinceList);
        __initProvinceList(this.widget, length);
    },

    /**
     * @description Render list.
     * @function render
     * @memberof ProvinceList
     * @return {View} return this ProvinceList
     */
    render : function(provinces) {
        Volt.log();
        __updateProvinceList(this.widget, provinces);
        return this;
    },
    
    events : {
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },

    /**
     * @description ProvinceList's focus callback.
     * @function onFocus
     * @memberof ProvinceList
     * @param {Widget} widget - the widget is focused
     * @return None
     */
    onFocus : function(widget) {
        Volt.log('ProvinceList');
        if(selfSetting && selfSetting.isShow) {
            if(widget) {
                widget.enableFocus();
                widget.setFocus();
                widget.showFocus("true");
            }
        }
    },

    /**
     * @description ProvinceList's blur callback.
     * @function onBlur
     * @memberof ProvinceList
     * @param {Widget} widget - the widget is blurred
     * @return None
     */
    onBlur : function(widget) {
        Volt.log('ProvinceList');
        if(selfSetting && selfSetting.isShow) {
            if (widget){
                widget.hideFocus("true");
                var focusItem = widget.getFocusItemIndex();
                var item = widget.renderer(focusItem.groupIndex, focusItem.itemIndex);
                if(item) {
                    item.root.getChild(0).onBlur();
                }
            }
        }
    },
    
    destroy : function() {
        Volt.log('ProvinceList');
        this.widget.destroy();
        delete this.widget;
        this.widget = null;
    }
});

/**
 * @description CityList is the list of CityContentView.
 * @class CityList
 * 
 * @property {GridListControl} widget - Basic Widget of this view.
 * @property {Function} render - Render list.
 * @property {Function} show - Show this view. Invoked when come back from other View
 * @property {Function} onFocus - CityList's focus callback.
 * @property {Function} onBlur - CityList's blur callback.
 * 
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 * @requires {@link WeatherSettingModel}
 */
var CityList = BaseView.extend({
    template : WeatherSettingTemplate.cityList,

    /**
     * @description initialize list.
     * @function initialize
     * @memberof CityList
     */
    initialize : function(container, size){
        var cityList = new Gridlist(this.template, container).render().widget;
        this.setWidget(cityList);
        __initCityList(this.widget, size);
//        __initCityList(this.widget, WeatherCityListModel.get('max_cities_num'));
    },
    /**
     * @description Render list.
     * @function render
     * @memberof CityList
     * @return {View} return this CityList
     */
    render : function(cityCollection) {
        Volt.log();
        __updateCityList(this.widget, cityCollection);
        return this;
    },

    events : {
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },

    /**
     * @description CityList's focus callback.
     * @function onFocus
     * @memberof CityList
     * @param {Widget} widget - the widget is focused
     * @return None
     */
    onFocus : function(widget) {
        Volt.log('CityList');
        if(selfSetting && selfSetting.isShow) {
            if(widget) {
                widget.enableFocus();
                widget.setFocus();
                widget.showFocus("true");
            }
        }
    },

    /**
     * @description CityList's blur callback.
     * @function onBlur
     * @memberof CityList
     * @param {Widget} widget - the widget is blurred
     * @return None
     */
    onBlur : function(widget) {
        Volt.log('CityList');
        if(selfSetting && selfSetting.isShow) {
            if (widget){
                widget.hideFocus("true");
                var focusItem = widget.getFocusItemIndex();
                var item = widget.renderer(focusItem.groupIndex, focusItem.itemIndex);
                if(item) {
                    item.root.getChild(0).onBlur();
                }
            }
        }
    },
    
    destroy : function() {
        Volt.log('CityList');
        this.widget.destroy();
        delete this.widget;
        this.widget = null;
    }

});

/**
 * @description ProvinceItem is the widget item used in ProvinceList.
 * @class ProvinceItem
 * 
 * @property {Widget} widget - Basic Widget of this view.
 * @property {Function} render - Render widget item.
 * @property {Function} setFocus - Show highlight text when the item onFocus.
 * @property {Function} killFocus - Show normal text when the item onBlur.
 * 
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 */
var ProvinceItem = BaseView.extend({
    template : WeatherSettingTemplate.provinceItem,

    /**
     * @description Render list.
     * @function render
     * @memberof ProvinceItem
     * @return {View} return this ProvinceItem
     */
    render : function(parent, provinceName, isSelected, isShownDivision) {
        this.widget = PanelCommon.loadTemplate(this.template, {
            provinceName : provinceName
        }, parent);
        this.widget.onSelected = this.onSelected;
        this.widget.onUnSelected = this.onUnSelected;
        this.widget.onFocus = this.onFocus;
        this.widget.onBlur = this.onBlur;
        this.widget.updateProvinceItem = this.updateProvinceItem;
        this.widget.setIsShownDivision = this.setIsShownDivision;
        
        this.widget.updateProvinceItem(undefined, isSelected, isShownDivision);
        this.widget.onBlur();
        return this;
    },
    
    /**
     * @description Update the province name and status
     * @function updateProvinceItem
     * @memberof ProvinceItem
     * @return None
     */
    updateProvinceItem : function(provinceName, isSelected, isShownDivision){
        if(provinceName !== undefined) {
            this.getChild(0).text = provinceName;
            this.getChild(1).text = provinceName;
            this.getChild(2).text = provinceName;
        }
       
        if(isSelected !== undefined) {
            if(isSelected) {
                this.onSelected();
            } else {
                this.onUnSelected();
            }
        }
        
        if(isShownDivision !== undefined) {
            this.setIsShownDivision(isShownDivision);
        }
    },
    
    /**
     * @description Set whether show the division
     * @function setIsShownSivision
     * @memberof ProvinceItem
     * @return None
     */
    setIsShownDivision : function(isShownDivision){
        if(isShownDivision){
            this.getChild(3).show();
        } else {
            this.getChild(3).hide();
        }
    },
    
    /**
     * @description Show selected text when the item onSelected.
     * @function onSelected
     * @memberof ProvinceItem
     * @return None
     */
    onSelected : function() {
        this.isSelected = true;
        this.getChild(2).show();
    },
    
    /**
     * @description Show normal text when the item onUnSelected.
     * @function onUnSelected
     * @memberof ProvinceItem
     * @return None
     */
    onUnSelected : function() {
        this.isSelected = false;
        this.getChild(2).hide();
    },

    /**
     * @description Show highlight text when the item onFocus.
     * @function onFocus
     * @memberof ProvinceItem
     * @return None
     */
    onFocus : function() {
        this.getChild(1).show();
    },

    /**
     * @description Show normal text when the item onBlur.
     * @function onBlur
     * @memberof ProvinceItem
     * @return None
     */
    onBlur : function() {
        this.getChild(1).hide();
    }

});

/**
 * @description CityItem is the widget item used in CityList.
 * @class CityItem
 * 
 * @property {Widget} widget - Basic Widget of this view.
 * @property {Function} render - Render widget item.
 * @property {Function} setFocus - Show highlight text when the item onFocus.
 * @property {Function} killFocus - Show normal text when the item onBlur.
 * @property {Function} setCheckStatus - Update the status of this widget.
 * @property {Function} getCheckStatus - Get the status of this widget.
 * 
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 */
var CityItem = BaseView.extend({
    template : WeatherSettingTemplate.cityItem,
    
    /**
     * @description Render list.
     * @function render
     * @memberof CityItem
     * @return {View} return this CityItem
     */
    render : function(parent, cityName, isChecked, isShownDivision) {
        this.widget = PanelCommon.loadTemplate(this.template, {
            cityName : cityName
        }, parent);
        
        this.widget.onFocus = this.onFocus;
        this.widget.onBlur = this.onBlur;
        this.widget.setCheckStatus = this.setCheckStatus;
        this.widget.getCheckStatus = this.getCheckStatus;
        this.widget.updateCityItem = this.updateCityItem;
        this.widget.setIsShownDivision = this.setIsShownDivision;
        
        this.widget.updateCityItem(undefined, isChecked, isShownDivision);
        this.widget.onBlur();
        return this;
    },
    
    /**
     * @description Update the city name and status
     * @function updateCityItem
     * @memberof CityItem
     * @return None
     */
    updateCityItem : function(cityName, isChecked, isShownDivision){
        if(cityName !== undefined) {
            this.getChild(1).text = cityName;
            this.getChild(2).text = cityName;
        }
       
        if(isChecked !== undefined) {
            this.setCheckStatus(isChecked);
        }
        
        if(isShownDivision !== undefined) {
            this.setIsShownDivision(isShownDivision);
        }
    },
    
    /**
     * @description Set whether show the division
     * @function setIsShownSivision
     * @memberof CityItem
     * @return None
     */
    setIsShownDivision : function(isShownDivision){
        if(isShownDivision){
            this.getChild(7).show();
        } else {
            this.getChild(7).hide();
        }
    },

    /**
     * @description Show highlight text when the item onFocus.
     * @function setFocus
     * @memberof CityItem
     * @return None
     */
    onFocus : function() {
        this.getChild(0).show();
        this.getChild(2).show();
        this.getChild(4).show();
        this.getChild(5).hide();
        
        if(this.isChecked) {
            this.getChild(6).show();
        } else {
            this.getChild(6).hide();
        }
    },

    /**
     * @description Show normal text when the item onFocus.
     * @function killFocus
     * @memberof CityItem
     * @return None
     */
    onBlur : function() {
        this.getChild(0).hide();
        this.getChild(2).hide();
        this.getChild(4).hide();
        this.getChild(6).hide();
        
        if(this.isChecked) {
            this.getChild(5).show();
        } else {
            this.getChild(5).hide();
        }
    },

    /**
     * @description Update the status of this widget.
     * @function setCheckStatus
     * @memberof CityItem
     * @param {Boolean} isChecked - the status
     * @return None
     */
    setCheckStatus : function(isChecked) {
        this.isChecked = isChecked;
        if (this.isChecked === true) {
            this.getChild(6).show();
        } else {
            this.getChild(6).hide();
        }
    },

    /**
     * @description Get the status of this widget.
     * @function getCheckStatus
     * @memberof CityItem
     * @return {Boolean} the status
     */
    getCheckStatus : function() {
        return this.isChecked;
    }

});

/*
 * This function will render a province list.
 * <p>
 * @param {GridListControl} provinceList The list which need render.
 * @param {Number} size The size of provinces
 */
function __initProvinceList(provinceList, size) {
    Volt.log('provinces.length - ' + size);
    
    if(size > 1) {
        provinceList.addGroup(1);
        provinceList.addStyle(1);
        provinceList.addDataGroup(1);
        provinceList.setAnimationDuration(CommonDefines.AniTime.WEATHER_SETTING_MOVE_TIME);
        provinceList.addRegularGrid({
            groupIndex : 0,
            styleIndex : 0,
            columnNumber : size,
            rowNumber : 1,
            columnWidth : WeatherSettingTemplate.provinceItem.width,
            rowHeight : WeatherSettingTemplate.provinceItem.height
        });
        
        provinceList.setBackgroundColor(0,0,0,0);
        provinceList.shadowEffectFlag = false;
        provinceList.show();
        
        provinceList.initRenderer = function(renderer, data, parentWidth, parentHeight){
            Volt.log('data - ' + JSON.stringify(data));
            renderer.root.color = Volt.hexToRgb('#000000', 0);
            new ProvinceItem().render(renderer.root, data.provinceName, data.isSelected, data.isShownDivision);
        };

        provinceList.onDrawLoadData = function(renderer, data, parentWidth, parentHeight) {
            Volt.log('data - ' + JSON.stringify(data));
        };

        provinceList.onDrawUpdateData = function(widget, data, parentWidth, parentHeight) {
            Volt.log('data - ' + JSON.stringify(data));
        };
        
        provinceList.onDrawFromFocusChangeStart = function(widget, data, parentWidth, parentHeight){
            var radioWgt = widget.getChild(0);
//            Volt.log('killFocus- ' + radioWgt + ' data - ' + JSON.stringify(data));
            radioWgt.onBlur();
        };
        
        provinceList.onDrawToFocusChangeEnd = function(widget, data, parentWidth, parentHeight){
            var radioWgt = widget.getChild(0);
//            Volt.log('setFocus- ' + radioWgt + ' data - ' + JSON.stringify(data));
            radioWgt.onFocus();
            //voice guide
            if (1 == DeviceModel.getMenuTTS()){
                var voiceText = data.provinceName;
                if (true == selfSetting.isFresh){
                    selfSetting.isFresh = false;
                    voiceText = 'Weather Settings, Select the cities you would like to follow. You can select up to 5 cities. '
                                + WeatherSettingModel.getSelectedCount()
                                + ' cities are currently selected. ' + 
                                voiceText;
                }
                Global.voiceGuide(voiceText);
            }
        };
        
        provinceList.onItemMouseClick = provinceList.onItemPress = function(groupIndex, itemIndex){
            Volt.log('index: ' + itemIndex);
            if(provinceList.lastGroupIndex !== undefined && provinceList.lastItemIndex !== undefined){
                var oldItem = provinceList.renderer(provinceList.lastGroupIndex, provinceList.lastItemIndex);
                if(oldItem) {
                    oldItem.root.getChild(0).onUnSelected();
                }
                provinceList.getData(provinceList.lastGroupIndex, provinceList.lastItemIndex).isSelected = false;
            }
            var newItem = provinceList.renderer(groupIndex, itemIndex);
            if(newItem){
                newItem.root.getChild(0).onSelected();
            }
            provinceList.getData(groupIndex, itemIndex).isSelected = true;
            provinceList.lastGroupIndex = groupIndex;
            provinceList.lastItemIndex = itemIndex;
            Mediator.trigger(CommonDefines.Event.REFRESH_CITY, itemIndex, 1);
        };
        Volt.Nav.setNextItemRule(provinceList,"left",provinceList);
        Volt.Nav.setNextItemRule(provinceList,"right",provinceList);
    } else {
        provinceList.custom.focusable = false;
        Mediator.trigger(CommonDefines.Event.REFRESH_CITY, 0, 2);
    }
}

function __updateProvinceList(provinceList, provinces){
    Volt.log();
    var size = provinces.length;
    _.each(provinces , function(provinceName, i){
        var data = new Data();
        data.index = i;
        data.provinceName =  provinceName;
        if(i == 0) {
            data.isSelected = true;
        } else {
            data.isSelected = false;
        }
        if(i == size - 1){
            data.isShownDivision = false;
        } else {
            data.isShownDivision = true;
        }
        provinceList.addData({groupIndex:0, data:data});
    });
    
    provinceList.loadData();
    provinceList.setFocusItemIndex(0, 0);
    provinceList.onItemPress(0, 0);
};

/*
 * This function will render a province list.
 * <p>
 * @param {GridListControl} cityList The list which need render.
 * @param {Number} size The size of cities
 */
function __initCityList(cityList, size) {
    Volt.log('cities.length - ' + size);
    
    if(size > 0) {
        cityList.addGroup(1);
        cityList.addStyle(1);
        cityList.addDataGroup(1);
        cityList.setAnimationDuration(CommonDefines.AniTime.WEATHER_SETTING_MOVE_TIME);
        var row = 4;
        var col = Math.ceil(size/row);

        cityList.addRegularGrid({
            groupIndex : 0,
            styleIndex : 0,
            columnNumber : col,
            rowNumber : row,
            columnWidth : WeatherSettingTemplate.cityItem.width,
            rowHeight : WeatherSettingTemplate.cityItem.height
        });
        
        cityList.setBackgroundColor(0,0,0,0);
        cityList.shadowEffectFlag = false;
        cityList.show();
        
        cityList.initRenderer = function(renderer,data, parentWidth, parentHeight){
            Volt.log('data - ' + JSON.stringify(data));
            renderer.root.color = Volt.hexToRgb('#000000', 0);
            new CityItem().render(renderer.root, data.cityName, data.isChecked, data.isShownDivision);
        };

        cityList.onDrawLoadData = function(renderer, data, parentWidth, parentHeight) {
            Volt.log('data - ' + JSON.stringify(data));
        };
        
        cityList.onDrawUpdateData = function(widget, data, parentWidth, parentHeight) {
            Volt.log('data - ' + JSON.stringify(data));
//            var checkboxWgt = widget.getChild(0);
//            checkboxWgt.updateCityItem(data.cityName, data.isChecked, data.isShownDivision);
        };
        
        cityList.onDrawFromFocusChangeStart = function(widget, data, parentWidth, parentHeight){
          Volt.log('killFocus- ' + checkboxWgt + ' data - ' + JSON.stringify(data));
            var checkboxWgt = widget.getChild(0);
            checkboxWgt.onBlur();
        };
        
        cityList.onDrawToFocusChangeEnd = function(widget, data, parentWidth, parentHeight){
          Volt.log('setFocus- ' + checkboxWgt + ' data - ' + JSON.stringify(data));
            var checkboxWgt = widget.getChild(0);
            checkboxWgt.onFocus();
            //voice guide
            /*if (1 == DeviceModel.getMenuTTS()){
                var checked = data.isChecked ? 'checked' : 'unchecked';
                var voiceText = 'checkbox, ' + checked + ', ' +data.cityName;
                Global.voiceGuide(voiceText);
            }*/
        };
        
//        cityList.onFocusChangeStart = function(fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex){
//            Volt.log();
//            var oldItem = cityList.renderer(fromGroupIndex, fromItemIndex);
//            if(oldItem) {
//                oldItem.root.getChild(0).onBlur();
//            }
//            var newItem = cityList.renderer(toGroupIndex, toItemIndex);
//            if(newItem) {
//                newItem.root.getChild(0).onFocus();
//            }
//        };

        cityList.onItemMouseClick = cityList.onItemPress = function(groupIndex, itemIndex) {
            Volt.log('index: ' + itemIndex);
            var checkboxWgt = cityList.renderer(groupIndex, itemIndex).root.getChild(0);
            var checkStatus = checkboxWgt.getCheckStatus();
            if (checkStatus) {
                if (WeatherSettingModel.getSelectedCount() <= 1) {
                    var ErrorHandler = Volt.require('app/common/errorHandler.js');
                    ErrorHandler.show(CommonDefines.PopupType.MINIMUM);
                    return;
                }
            } else {
                if (WeatherSettingModel.getSelectedCount() >= 5) {
                    var ErrorHandler = Volt.require('app/common/errorHandler.js');
                    ErrorHandler.show(CommonDefines.PopupType.MAXIMUM);
                    return;
                }
            }
            Mediator.trigger(CommonDefines.Event.UPDATE_SELECTED_CITIES_1, itemIndex);
            checkboxWgt.setCheckStatus(!checkStatus);
            //voice guide
            if (1 == DeviceModel.getMenuTTS()){
                var voiceText = (true == checkStatus) ? 'unchecked' : 'checked';
                Global.voiceGuide(voiceText);
            }
            cityList.getData(groupIndex, itemIndex).isChecked = !checkStatus;
        };
        
        Volt.Nav.setNextItemRule(cityList,"left",cityList);
        Volt.Nav.setNextItemRule(cityList,"right",cityList);
    } else {
        cityList.custom.focusable = false;
    }

    var gridListener = new GridListControlListener;
    gridListener.onFocusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex){
        if (toItemIndex <  0) {
            return;
        }
        if (1 == DeviceModel.getMenuTTS()){
            var data = gridList.getData(toGroupIndex, toItemIndex);
            var checked = data.isChecked ? 'checked' : 'unchecked';
            var voiceText = 'checkbox, ' + checked + ', ' +data.cityName;
            if (-1 == fromItemIndex){
                var cityCount = cityList.itemCount(0);
                var item = (1 == cityCount) ? 'item' : 'items';
                voiceText = gridList.provinceName + ', ' + cityCount + ', ' + item + ', ' + voiceText;
            }
            Global.voiceGuide(voiceText);
        }
    };
    cityList.addListListener(gridListener);
}

function __updateCityList(cityList, cityCollection){
    Volt.log();
//    cityList.clearDataSource(0);
//    cityList.addDataGroup(1);
    var length = cityCollection.length;
    var row = 4;
    var pageCol = 4;
    var needDivisionCol = {};
    var col = 0;
    needDivisionCol[0] = true;
    while(length > row * pageCol){
        length = length - row * pageCol;
        needDivisionCol[Math.ceil(length/row)] = true;
    }
    cityCollection.each(function(city, i){
        var data = new Data();
        data.index = i;
        data.cityName = city.get('name');
        data.isChecked = WeatherSettingModel.getSelectedCityIndex(city.get('code')) !== undefined;
        col = Math.floor(i/row);
        if((length != 1) && needDivisionCol[col] && ((i+1)%row !== 0)){
            data.isShownDivision = true;
        } else {
            data.isShownDivision = false;
        }
        cityList.addData({groupIndex:0, data:data});
    });
    cityList.loadData();
//    cityList.updateAllItems(0);
    cityList.setFocusItemIndex(0, 0);
};

exports = WeatherSettingView;
