var DeviceModel = Volt.require('app/common/deviceModel.js');

function rgcHandleKey(keyCode, type)
{
	if(this.openKey == false)
		return;
	if (type == Volt.EVENT_KEY_PRESS)
	{
		if (keyCode == Volt.KEY_JOYSTICK_LEFT)
		{
			return this._onKeyLeft();
		}
		else if (keyCode == Volt.KEY_JOYSTICK_RIGHT)
		{
			return this._onKeyRight();
		} 
		else if (keyCode == Volt.KEY_JOYSTICK_UP)
		{
			return this._onKeyUp();
		} 
		else if (keyCode == Volt.KEY_JOYSTICK_DOWN)
		{
			return this._onKeyDown();
		} 
		else if (keyCode == Volt.KEY_JOYSTICK_OK)
		{
			return this._onPressItem();
		}
		else
		{
			return false;
		}
	}
	return true;
};

function rgcOnKeyLeft()
{
	var self = this;
	if(this.index == 0)
		return;
	this.openKey = false;
	
	if(this.childItem[this.index - 1] !== undefined)
	{
		var pos = this.childItem[this.index - 1].getAbsolutePosition();
		
		var root = this.getAbsolutePosition();
		if(pos.x < root.x)
		{
			this.openKey = false;
			var anim = new Animation(300, 0);
			Volt.Nav.pause();
			anim.addProperty("x", this.background.x + this.itemWidth + this.span);
			this.background.animate(anim,function()
			{
				self.index--;
				self.killFocus();
                self.lastHighlightItem = self.highlightItem;
                self.lastHighlightItem.getChild(0).opacity = 105;
				self.highlightItem = self.childItem[self.index];
				self.setFocus();
                self.highlightItem.getChild(0).opacity = 255;
                self.lastHighlightItem = self.highlightItem;
				self._updateIndicator();
				Volt.Nav.resume();
				self.openKey = true;
			});
		}
		else
		{
			this.index--;
			this.killFocus();
            self.lastHighlightItem = self.highlightItem;
            self.lastHighlightItem.getChild(0).opacity = 105;
			this.highlightItem = this.childItem[this.index];
			this.setFocus();
            self.highlightItem.getChild(0).opacity = 255;
             self.lastHighlightItem = self.highlightItem;
			this.openKey = true;
		}
        this.ifItemPressed(this.index, this.highlightItem);
		return true;
	}else if(this.childItem[this.index - 1] === undefined)
		return false;
};

function rgcOnKeyRight()
{
	var self = this;
	if(this.index == this.total - 1)
		return;
	this.openKey = false;
	if(this.childItem[this.index + 1] !== undefined)
	{
		
		var pos = this.childItem[this.index + 1].getAbsolutePosition();
		
		var root = this.getAbsolutePosition();
		if(pos.x >= root.x + this.width)
		{
			
			var anim = new Animation(300, 0);
			anim.addProperty("x", this.background.x - this.itemWidth-this.span);
			Volt.Nav.pause();
			this.background.animate(anim,function(){
				self.index++;
				self.killFocus();
                self.lastHighlightItem = self.highlightItem;
                self.lastHighlightItem.getChild(0).opacity = 105;
				self.highlightItem = self.childItem[self.index];
				self.setFocus();
                self.highlightItem.getChild(0).opacity = 255;
                self.lastHighlightItem = self.highlightItem;
				self._updateIndicator();
				Volt.Nav.resume();
				self.openKey = true;
			});
		}
		else
		{
			this.index++;
			this.killFocus();
            self.lastHighlightItem = self.highlightItem;
            self.lastHighlightItem.getChild(0).opacity = 105;
			this.highlightItem = this.childItem[this.index];
			this.setFocus();
            self.highlightItem.getChild(0).opacity = 255;
            self.lastHighlightItem = self.highlightItem;
			self.openKey = true;
		}
        this.ifItemPressed(this.index, this.highlightItem);
		return true;
	}else if(this.childItem[this.index + 1] === undefined)
		return false;
};

function rgcOnKeyUp()
{
	this.killFocus();
	return false;
};

function rgcOnKeyDown()
{
	this.killFocus();
	return false;
};

function rgcOnPressItem()
{
	this.ifItemPressed(this.index, this.highlightItem);
};

function rgcSetFocus()
{
	if(this.highlightItem != null )
	{
		//this.highlightItem.opacity = 255;
        this.highlightItem.animate("scale", {x:1.05,y:1.05}, 300);
		return true;
	}else
		return false;
};


function rgcKillFocus()
{
	if(this.highlightItem != null )
	{
		//this.highlightItem.opacity = 105;
        this.highlightItem.animate("scale", {x:1,y:1}, 300);
		return true;
	}else
		return false;
	
};

function rgcSetItems(arrItems)
{
	if(arrItems.length <= 0)
		return;
	this.item = arrItems;
	if(this.childItem && this.childItem.length > 0)
    {
        for(var i = 0; i < this.childItem.length; i++)
        {
            this.background.removeChild(this.childItem[i]);
            this.childItem[i].destroy();
        }
        for(var i = 0; i < this.spanWidget.length; i++)
        {
            this.background.removeChild(this.spanWidget[i]);
            this.spanWidget[i].destroy();
        }
        this.childItem.length = 0;
        this.spanWidget.length = 0;
    }
    this.width = 4 * (this.itemWidth + this.span);
	this.canvas.width = 4 * (this.itemWidth + this.span);
	this.x = (DeviceModel.get('resolutionX') - this.canvas.width) / 2;
	this.background.height = 40;
	this.background.y = 10;
	var X = 0;
	//var width = this.itemWidth;
	var frontSize = this.background.height - 2;
	if(this.item.length == 1)
	{
		this.hide();
		this.focusable = false;
	}else
    {
        this.show();
		this.focusable = true;
    }
	if(this.item.length > 4)
	{
		
		this.nextIndicator = this.nextIndicator || new Widget({
			x:this.canvas.width+this.canvas.x,
			y:10,
			width:this.itemWidth,
			height:this.background.height,
			color:{r:0,g:0,b:0,a:0},
		});
		this.leftText =  this.leftText || new TextWidget({
			x:0,y:0,height:this.background.height,width:this.itemWidth,
			horizontalAlignment : "left",
			font : "SVD Light "+frontSize+"px",
			fillMode:"stretch",
			//color:{r:111,g:111,b:111,a:255},
			textColor:{r:0, g:0, b:0, a:255},
			text:"...",
		});
        this.removeChild(this.nextIndicator);
		this.addChild(this.nextIndicator);
        this.nextIndicator.removeChild(this.leftText);
		this.nextIndicator.addChild(this.leftText);
		this.nextIndicator.hide();
		this.rightText =  this.rightText || new TextWidget({
			x:0,y:0,height:this.background.height,width:this.itemWidth,
			horizontalAlignment : "right",
			font : "SVD Light "+frontSize+"px",
			fillMode:"stretch",
			
			//color:{r:111,g:111,b:111,a:255},
			textColor:{r:0, g:0, b:0, a:255},
			text:"...",
		});
		this.prevIndicator = this.prevIndicator || new Widget({
			x:this.canvas.x - this.span - this.itemWidth,
			y:10,
			width:this.itemWidth,
			height:this.background.height,
			color:{r:0,g:0,b:0,a:0},
		});
        this.removeChild(this.prevIndicator);
		this.addChild(this.prevIndicator);
        this.prevIndicator.removeChild(this.rightText);
		this.prevIndicator.addChild(this.rightText);
		this.prevIndicator.hide();
	}
	if(this.item.length <= 4)
    {
        X = (this.width - this.item.length * (this.itemWidth + this.span))/2;
    }
	for(var i = 0; i < this.item.length;i++)
	{
		this.childItem[i] = new Widget({
			x:X,
			y:0,
			height:this.background.height,
			width:this.itemWidth,
			color:{r:0,g:0,g:0,a:0},
		});
		X += this.itemWidth;
		if(i != this.item.length - 1)
		{
			this.spanWidget[i] = new Widget({
				x:X,
				y:0,
				height:this.background.height,
				width:this.span,
				color:{r:0,g:0,b:0,a:255},
			});
			this.background.addChild(this.spanWidget[i]);
		}
		X += this.span;
		this.background.addChild(this.childItem[i]);
		
		var cpText = new TextWidget({
			x:0,y:0,height:this.background.height + 4,width:this.itemWidth,
			horizontalAlignment : "center",
			font : "SVD Light "+frontSize+"px",
			fillMode:"stretch",
			//ellipsize : true,
            opacity:105,
			textColor:{r:0, g:0, b:0, a:255},
			text:this.item[i],
		});
		this.childItem[i].addChild(cpText);
		this._configMouseEvent(this.childItem[i]);
	}
	
	this.highlightItem = this.childItem[0];
    this.lastHighlightItem = this.highlightItem;
    this.highlightItem.getChild(0).opacity = 255;
	this.index = 0;
	this.total = arrItems.length;
	this._updateIndicator();
};


function defaultValue(value, defaultValue)
{
	if (value === undefined)
	{
		return defaultValue;
	}
	else
	{
		return value;
	}
}

function rgcConfigMouseEvent(widget)
{
	widget.addEventListener("OnMouseClick", function(targetWidget, eventData)
	{
		
		var parent = targetWidget.parent.parent.parent;
		if(parent.ifItemPressed)
        {
			parent.lastHighlightItem.getChild(0).opacity = 105;
            parent.ifItemPressed(parent.index, targetWidget);
            parent.highlightItem.getChild(0).opacity = 255;
            parent.lastHighlightItem = parent.highlightItem;
        }
	});
	widget.addEventListener("OnMouseOver", function(targetWidget, eventData)
	{
		var parent = targetWidget.parent.parent.parent;
		if(parent.highlightItem)
		{
            parent.killFocus();
		}
		parent.highlightItem = targetWidget;
		var text = targetWidget.getChild(0).text;
		for(var i = 0; i < parent.item.length;i++)
		{
			if(parent.item[i] == text)
			{
				parent.index = i;
				break;
			}
		}
		parent.setFocus();
	});

	widget.addEventListener("OnMouseOut", function(targetWidget, eventData)
	{
		var parent = targetWidget.parent.parent.parent;
		parent.killFocus();
	});

	widget.addEventListener("OnMouseMove", function(targetWidget, eventData)
	{
		
	});
}

function rgcUpdateIndicator()
{
	if(this.item.length > 4 && this.index != this.total - 1)
	{
		this.nextIndicator.show();
	}
	else if(this.index == this.total - 1 && this.item.length > 4)
	{
		this.nextIndicator.hide();
	}
	if(this.item.length > 4 && this.index == 0)
	{
		this.prevIndicator.hide();
	}else if(this.item.length > 4 && this.index != 0)
	{
		this.prevIndicator.show();
	}

}


function cplist(param)
{
	var cplist = new Widget();
	cplist.openKey = true;
	cplist.onKeyEvent = rgcHandleKey;
	cplist._onKeyLeft = rgcOnKeyLeft;
	cplist._onKeyRight = rgcOnKeyRight;
	cplist._onKeyUp = rgcOnKeyUp;
	cplist._onKeyDown = rgcOnKeyDown;
	cplist._onPressItem = rgcOnPressItem;
	cplist._configMouseEvent = rgcConfigMouseEvent;
	cplist._updateIndicator = rgcUpdateIndicator;
	cplist.setItems = rgcSetItems;
	cplist.cropOverflow = false;
	if(param['id'])
		cplist.id = param['id'];
	cplist.item = [];
	cplist.span = defaultValue(param['span'], 0);
	cplist.highlightItem = null;
    cplist.lastHighlightItem = null;
	cplist.index = null;
	cplist.total = null;
	cplist.childItem = [];
    cplist.spanWidget = [];
	cplist.height = param['height'];
	cplist.itemWidth = defaultValue(param['itemWidth'],144);
	cplist.color = {r:0,g:0,b:0,a:0};
	if(param.hasOwnProperty('parent')){
	    cplist.parent = param['parent'];
	}
	//cplist.parent = scene;//param['parent'];
	cplist.ifItemPressed = function(){};
	cplist.background = new Widget({x:0,y:0,color:{r:0,g:0,b:0,a:0}});
	cplist.canvas = new Widget({
		height:cplist.height,
		//width:900,
		x:0,y:0,
		cropOverflow:true,
		color:{r:0,g:0,b:0,a:0},
	});
	cplist.canvas.addChild(cplist.background);
	cplist.addChild(cplist.canvas);
	cplist.nextIndicator = null;
	cplist.prevIndicator = null;
	//kill the gridlist's focus
	cplist.killFocus = rgcKillFocus;
	cplist.setFocus = rgcSetFocus;
	return cplist;
}

exports = cplist