/*
AnimateIamgeDrawingClass Module

usage:

		//create an AnimatedImageDrawing instance , set animating image resource and set it to animate.
		var loadingIns = new AnimatedImageDrawing(10, 105, 80, 80, popupBG); 
	  	for (var i=0; i<18; i++){
				loadingIns.SetFrames(ImageUrl[i], i);
			}
		loadingIns.Play(0, 200);
*/

var KeyCode = {
	up:Volt.KEY_JOYSTICK_UP,
	down:Volt.KEY_JOYSTICK_DOWN,
	left:Volt.KEY_JOYSTICK_LEFT,
	right:Volt.KEY_JOYSTICK_RIGHT,
	enter:Volt.KEY_JOYSTICK_OK,
	exit:Volt.KEY_EXIT,
	returnKey:Volt.KEY_RETURN,
	red:Volt.KEY_RED,
	green:Volt.KEY_GREEN,
	yellow:Volt.KEY_YELLOW,
	blue:Volt.KEY_BLUE,
	one:Volt.KEY_1, 
	two:Volt.KEY_2, 
	four:Volt.KEY_4,
	five:Volt.KEY_5,
	six:Volt.KEY_6,
	seven:Volt.KEY_7, 
	eight:Volt.KEY_8,
	nine:Volt.KEY_9 
}

function setTimeout(cb, interval, param) {
	return Volt.setTimeout(cb, interval, param);
}

function clearTimeout(id){
	if (id !== undefined)  {
		Volt.clearTimeout(id);
	}
}

function setInterval(cb, interval, param){
	return Volt.setInterval(cb, interval, param);
}

function clearInterval(id){
	if (id !== undefined) {
		Volt.clearInterval(id);
	}
}

(function (){ 
		var h=/\b_super\b/,// Regular Expression
		
			i={};
		function c(l,j){
			return function (){
				var n=this._super,
					m;
				this._super=j;
				m=l.apply(this,arguments);
				if(n){
					this._super=n
				}else {
					delete this._super
				}
				return m
			}
		}
			
		function f(){
			var j=Array.prototype.slice.call(arguments,1);
			return this.extend({
				init:function (){
					var l=Array.prototype.slice.call(arguments,0);
					this._super.apply(this,j.concat(l))
				}
			})
		}
			
		function d(n){
			var m=new this(i),
				l,j,p,o;
			for(l in n){
				j=n.__lookupGetter__(l);
				p=n.__lookupSetter__(l);
				if(j||p){
					j&&m.__defineGetter__(l,j);
					p&&m.__defineSetter__(l,p)
				}else {
					o=n[l];
					if(typeof o ==='function'&&h.test(o)){
						o = c(o,this.prototype[l]||NOOP)
					}
					m[l]=o
				}
			}
			return e(m)
		}
			
		function e(l){  // create the function 
			var j=function (){
				var m=this.init;
				if(m&&arguments[0]!==i){
					m.apply(this,arguments)
				}
			};
			if(l){
				j.prototype=l
			}
			j.constructor =j;
			j.extend=d;
			j.bind=f;
			return j
		}
		
		Class = {// often used interface
			create:e
		}
	})();

/////////////////////AnimatedImageDrawing//////////////////////////////////////////	
var AnimatedImageDrawing = function(xPos, yPos, Width, Height, Parent){
	var AnimatedWidget = new Widget();
	
	AnimatedWidget.AnimateState = {
						STATE_PLAY:0,
						STATE_STOP:1,
						STATE_PAUSE:2,
						STATE_IDLE:3			
					 };
	
	//variable
	AnimatedWidget.currentFrameIdx = 0;
	AnimatedWidget.animateDuration = 0;
	AnimatedWidget.currentState = AnimatedWidget.AnimateState.STATE_IDLE;
	AnimatedWidget.isCreate = true;
	AnimatedWidget.isLoopFlag = true;
	AnimatedWidget.animateTimer = null;

	//function
	AnimatedWidget.init = init;
	AnimatedWidget.Destroy = Destroy;
	AnimatedWidget.Hide = Hide;
	AnimatedWidget.Show = Show;
	AnimatedWidget.SetFrames = SetFrames;
	AnimatedWidget.DeleteAllFrames = DeleteAllFrames;
	AnimatedWidget.SetPosition = SetPosition;
	AnimatedWidget.SetSize = SetSize;
	AnimatedWidget.Play = Play;
	AnimatedWidget.Pause = Pause;
	AnimatedWidget.Resume = Resume;
	AnimatedWidget.Stop = Stop;
	AnimatedWidget.SetLoop = SetLoop;
	AnimatedWidget.GetLoop = GetLoop;
	AnimatedWidget.GetState = GetState;
	
	AnimatedWidget.init(xPos, yPos, Width, Height, Parent);
						 
	return AnimatedWidget;
};

var init = function(xPos, yPos, Width, Height, Parent){
	var AnimatedBGWidget = new Widget({
		x : xPos,
		y : yPos,
		width : Width,
		height : Height,
		color : {
			r : 0,
			g : 0,
			b : 0,
			a : 0
		},
		cropOverflow : true,
		parent : Parent
	});

	this.ImgSrc = [];

	this.ImgInstance = new ImageWidget({
		x : 0,
		y : 0,
		width : Width,
		height : Height,
		parent : AnimatedBGWidget
	});

	// AnimatedBGWidget.hide();
};
		
var Destroy = function() {
	var self = this;

	if(this.isCreate == true) {

		if(this.currentState == this.AnimateState.STATE_PLAY) {
			this.Pause();
		}

		this.destroy();
		this.isCreate = false;
		this.ImgSrc.splice(0, this.ImgSrc.length);
		this.currentFrameIdx = -1;
		this.animateDuration = -1;
		this.currentState = null;

		if(self.animateTimer != null) {
			clearInterval(self.animateTimer)
		}
	}

}; 
var Hide = function() {
	if(this.isCreate == true) {
		this.hide();
	}
}; 
var Show = function() {
	if(this.isCreate == true) {
		this.show();
	}
}; 
var SetFrames = function(frames, index) {

	if(this.isCreate == true) {
		if(index < 0) {
			return;
		}

		if(this.currentState == this.AnimateState.STATE_PLAY) {
			this.Pause();
		}

		this.ImgSrc.push(frames);
		if(index == 0) {
			this.ImgInstance.src = this.ImgSrc[0];
			this.show();
		}
	}

}; 
var DeleteAllFrames = function() {
	if(this.isCreate == true) {
		if(this.currentState == this.AnimateState.STATE_PLAY) {
			this.Pause();
			this.ImgInstance.src = '';
			this.ImgInstance.destroy();
			this.ImgSrc.splice(0, this.ImgSrc.length);

		} else {
			this.ImgInstance.src = '';
			this.ImgInstance.destroy();
			this.ImgSrc.splice(0, this.ImgSrc.length);
		}

	}
}; 
var SetPosition = function(xPos, yPos) {
	if(this.isCreate == true) {
		this.hide();
		this.x = xPos;
		this.y = yPos;
		this.show();
	}
}; 
var SetSize = function(Width, Height) {

	if(this.isCreate == true) {
		if(Width < 0 || Height < 0) {
			return;
		}

		this.hide();
		this.width = Width;
		this.height = Height;
		this.ImgInstance.width = Width;
		this.ImgInstance.height = Height;
		this.show();
	}
}; 
var Play = function(frameIdx, interval) {
	var self = this;

	if((this.ImgSrc.length < 1) || (frameIdx < 0) || (interval <= 0)) {
		return;
	}

	if(this.currentState != this.AnimateState.STATE_PLAY) {
		this.animateDuration = interval;
		this.currentState = this.AnimateState.STATE_PLAY;

		this.animateTimer = setInterval(function() {
			if(frameIdx < (self.ImgSrc.length - 1)) {
				frameIdx++;
				self.ImgInstance.src = self.ImgSrc[frameIdx];
				self.currentFrameIdx = frameIdx;
			} else {
				if(self.isLoopFlag == true) {
					frameIdx = 0;
					self.ImgInstance.src = self.ImgSrc[frameIdx];
					self.currentFrameIdx = frameIdx;
				} else {
					result = clearInterval(self.animateTimer);
					self.currentFrameIdx = 0;
					self.currentState = self.AnimateState.STATE_STOP;
				}
			}

		}, interval);
	}

}; 
var Pause = function() {
	var self = this;
	var result;

	if(this.currentState == this.AnimateState.STATE_PLAY) {
		result = clearInterval(self.animateTimer);
		this.currentState = this.AnimateState.STATE_PAUSE;

	}

}; 
var Resume = function() {
	var self = this;
	var result;

	if(this.ImgSrc.length < 1) {
		return;
	}

	if(this.currentState == this.AnimateState.STATE_PAUSE) {
		this.currentState = this.AnimateState.STATE_PLAY;

		this.animateTimer = setInterval(function() {
			if(self.currentFrameIdx < (self.ImgSrc.length - 1)) {
				self.currentFrameIdx++;
				self.ImgInstance.src = self.ImgSrc[self.currentFrameIdx];
			} else {
				if(self.isLoopFlag == true) {
					self.currentFrameIdx = 0;
					self.ImgInstance.src = self.ImgSrc[self.currentFrameIdx];
				} else {
					result = clearInterval(self.animateTimer);
					self.currentFrameIdx = 0;
					self.currentState = self.AnimateState.STATE_STOP;
				}
			}

		}, self.animateDuration);
	}
}; 
var Stop = function() {
	var self = this;
	var stopTimer;
	var result;

	if(this.currentState == this.AnimateState.STATE_PLAY) {
		if(this.currentFrameIdx == (this.ImgSrc.length - 1)) {
			result = clearInterval(self.animateTimer);
			this.currentFrameIdx = 0;
		} else {
			stopTimer = setInterval(function() {
				if(self.currentFrameIdx == (self.ImgSrc.length - 1)) {
					result = clearInterval(self.animateTimer);
					reuslt = clearInterval(stopTimer);
					self.currentFrameIdx = 0;

				}
			}, self.animateDuration);
		}
		this.currentState = this.AnimateState.STATE_STOP;
	}
}; 
var SetLoop = function(bLoopFlag) {
	this.isLoopFlag = bLoopFlag;
}; 
var GetLoop = function() {
	return this.isLoopFlag;
};
var GetState = function() {
	return this.currentState;
};

exports = AnimatedImageDrawing;

