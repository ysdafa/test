
var Backbone = Volt.require('lib/volt-backbone.js');
//var BaseView = require("file://app/views/baseView.js");
var PanelCommon = Volt.require('lib/panel-common.js');
var CommonTemplate = Volt.requireAppTemplate('newson-common-template.js');
//Require common defines
var CommonDefines = Volt.require('app/common/commonDefines.js');
//var MessageboxView = Volt.require('app/views/messagebox-view.js');
var BaseView = PanelCommon.BaseView;

var dimView = PanelCommon.requireView('dim');
var customizationMessageBox = Volt.require('app/common/customization-messagebox.js');

var ErrorHandlerSelf = null;
var ErrorHandler = BaseView.extend({
	template : CommonTemplate.container,
	returnCallback : null,
	parent : null,
	showFlag : false,

	initialize : function() {
		ErrorHandlerSelf = this;

		this.setWidget(PanelCommon.loadTemplate(this.template));
		scene.addChild(this.widget);
	},	
			
	show : function(type, errorCode, returnCallback) 
	{
	    Volt.log();
	    ErrorHandlerSelf.hide();
	    ErrorHandlerSelf.showFlag = true;

		if(returnCallback === undefined){
		
			ErrorHandlerSelf.returnCallback = null;
		}
		else {
		
			ErrorHandlerSelf.returnCallback = returnCallback;
		}
		scene.removeChild(ErrorHandlerSelf.widget);
		scene.addChild(ErrorHandlerSelf.widget);
		
		dimView.show({
	        parent: this.widget
	    });
		switch (type) {
            case CommonDefines.PopupType.SAVE :
            case CommonDefines.PopupType.MAXIMUM :
            case CommonDefines.PopupType.MINIMUM :
            case CommonDefines.PopupType.EM_FROM_CITYLIST_SERVER :
            case CommonDefines.PopupType.VERSION :
                ErrorHandlerSelf.messageBox = customizationMessageBox(this.widget, {type : type});
                ErrorHandlerSelf.showMessageBox();
                break;
            case CommonDefines.PopupType.SERVER_ERROR2 : 
                print('--------------');
                ErrorHandlerSelf.messageBox = customizationMessageBox(this.widget, {type : type , errorCode : errorCode});
                ErrorHandlerSelf.showMessageBox();
                break;
				
			case CommonDefines.PopupType.NETWORK_ERROR1 :
                ErrorHandlerSelf.messageBox = customizationMessageBox(this.widget, {type : type , errorCode : errorCode, callbacks:[ErrorHandlerSelf.networkCallback]});
                ErrorHandlerSelf.showMessageBox();
                break;

            case CommonDefines.PopupType.CANCEL :
                ErrorHandlerSelf.messageBox = customizationMessageBox(this.widget, {type : type , callbacks : [function(){ErrorHandlerSelf.hide();Backbone.history.back();}]});
                ErrorHandlerSelf.showMessageBox();
                break;
            case CommonDefines.PopupType.NETWORK_ERROR_ENTRY:
                ErrorHandlerSelf.messageBox = customizationMessageBox(this.widget, {type : type, callbacks:[returnCallback]});
                ErrorHandlerSelf.showMessageBox();
                break;
			default :
				Volt.log('error type');
				break;			
		}
	},
					
						
	networkCallback : function() {
        Volt.log();		
		var aulApp = new Aul();
		var ret = aulApp.launchApp("org.tizen.NetworkSetting-Tizen");
		
		//ErrorHandlerSelf.networkErrorFlag = true;
    },
	
    showMessageBox : function() {
        Volt.log();
		ErrorHandlerSelf.messageBox.show();
		ErrorHandlerSelf.messageBox.startTimeOut({
		    time : ErrorHandlerSelf.messageBox.timeout,
		    callback : ErrorHandlerSelf.hide
		});
		Volt.Nav.beginModal(ErrorHandlerSelf.messageBox);
    },
	
    hide : function() {
	    if(ErrorHandlerSelf.showFlag === true){
	        ErrorHandlerSelf.showFlag = false;
	        Volt.log();
	        dimView.hide();
	        Volt.Nav.endModal();
	        if(ErrorHandlerSelf.messageBox) {
	            ErrorHandlerSelf.messageBox.hide();
                Volt.setTimeout(function() {
                    ErrorHandlerSelf.messageBox.release();
                    ErrorHandlerSelf.messageBox = null;
                }, 1);
            }
	        if(null != ErrorHandlerSelf.returnCallback)
	        {
	            ErrorHandlerSelf.returnCallback();
	        }
        }
    }
});
exports = new ErrorHandler();