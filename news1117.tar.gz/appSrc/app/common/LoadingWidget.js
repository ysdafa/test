//AnimatedImageDrawing的路径自己定义了
var AnimatedImageDrawing = Volt.require("app/common/AnimatedImageDrawing.js");
var self = null;

var LoadingWidget = {
	m_animatedImageDrawing:null,
	m_x:null,
	m_y:null,
	m_width:null,
	m_height:null,
	m_parent:null,
	m_imgPath:null,
	initialize:function(parent, x, y, width, height,imgPath)
	{
		self = this;
		self.m_x = x;
		self.m_y = y;
		self.m_width = width;
		self.m_height = height;
		self.m_parent = parent;
		self.m_imgPath = imgPath;
		return self;
	},
	
	show:function()
	{
		var imgList = [];
		imgList[0] = self.m_imgPath + '/loading_48_01.png';
		imgList[1] = self.m_imgPath + '/loading_48_02.png';
		imgList[2] = self.m_imgPath + '/loading_48_03.png';
		imgList[3] = self.m_imgPath + '/loading_48_04.png';
		imgList[4] = self.m_imgPath + '/loading_48_05.png';
		imgList[5] = self.m_imgPath + '/loading_48_06.png';
		imgList[6] = self.m_imgPath + '/loading_48_07.png';
		imgList[7] = self.m_imgPath + '/loading_48_08.png';
		imgList[8] = self.m_imgPath + '/loading_48_09.png';
		imgList[9] = self.m_imgPath + '/loading_48_10.png';
		imgList[10] = self.m_imgPath + '/loading_48_11.png';
		imgList[11] = self.m_imgPath + '/loading_48_12.png';
		imgList[12] = self.m_imgPath + '/loading_48_13.png';
		imgList[13] = self.m_imgPath + '/loading_48_14.png';
		imgList[14] = self.m_imgPath + '/loading_48_15.png';
		imgList[15] = self.m_imgPath + '/loading_48_16.png';
		imgList[16] = self.m_imgPath + '/loading_48_17.png';
		imgList[17] = self.m_imgPath + '/loading_48_18.png';
		
		if(self.m_animatedImageDrawing)
		{
			
			self.m_animatedImageDrawing.Stop();
			self.m_animatedImageDrawing.Hide();
			self.m_animatedImageDrawing.DeleteAllFrames();
			self.m_animatedImageDrawing.Destroy();
			self.m_animatedImageDrawing = null;
		}
		self.m_animatedImageDrawing = new AnimatedImageDrawing(self.m_x, self.m_y, self.m_width, self.m_height, self.m_parent);
		for(var i = 0; i < imgList.length; i++)
		{
			self.m_animatedImageDrawing.SetFrames(imgList[i], i);
		}
		self.m_animatedImageDrawing.Play(0, 100);
	},
	
	destroy:function()
	{
		if(self.m_animatedImageDrawing)
		{
			
			self.m_animatedImageDrawing.Stop();
			self.m_animatedImageDrawing.Hide();
			self.m_animatedImageDrawing.DeleteAllFrames();
			self.m_animatedImageDrawing.Destroy();
			self.m_animatedImageDrawing = null;
		}
	}
}
exports = LoadingWidget;