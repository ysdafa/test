var APP_ACTIVE = 'ON_ACTIVATE';
var APP_DEACTIVATE = 'ON_DEACTIVATE';
var APP_UNKNOWN = 'ON_UNKNOWN';
var MEMORY_TEST_ON = 1;
var MEMORY_TEST_OFF = 0;
var getOccurStamp = function(now_utc_timestamp, last_utc_timestamp)
{
    if(now_utc_timestamp === undefined || last_utc_timestamp === undefined 
         || typeof now_utc_timestamp !== 'number' 
         || typeof last_utc_timestamp !== 'number' ) {
        return '';
    }
    var temp = ((parseInt(now_utc_timestamp) - parseInt(last_utc_timestamp)));
	var status = null;
	if(temp >= 0 && temp <= 59)
	{
		status = 'Just Now';
	}else if(temp >= 60 && temp <= 119)
	{
		status = '1 min ago';
	}else if(temp >= 120 && temp <= 3600 - 1)
	{
		status = (Math.floor(temp/60))+ ' mins ago'
	}else if(temp >= 3600 && temp <= 7200 - 1)
	{
		status = '1 hr ago';
	}else if(temp >= 3600 && temp <= 3600*24 - 1)
	{
		status = (Math.floor(temp/3600))+ ' hrs ago'
	}else if(temp >= 3600*24 && temp <= 3600*48 - 1)
	{
		status = '1d ago'
	}
    else
	{
		status = (Math.floor(temp/(3600*24)))+ 'd ago'
	}
    return status;
};
var voiceGuide = function(voiceText){
    Volt.log('voice guide text : '+voiceText);
    TTS.setText(voiceText);
    TTS.play();
    //TTS.play(voiceText);
};
var string2Json = function(s) {     
    var newstr = "";  
    for (var i=0; i<s.length; i++) {  
        c = s.charAt(i);       
        switch (c) {       
            case '\"':       
                newstr+="\\\"";       
                break;       
            case '\\':       
                newstr+="\\\\";       
                break;       
            case '/':       
                newstr+="\\/";       
                break;       
            case '\b':       
                newstr+="\\b";       
                break;       
            case '\f':       
                newstr+="\\f";       
                break;       
            case '\n':       
                newstr+="\\n";       
                break;       
            case '\r':       
                newstr+="\\r";       
                break;       
            case '\t':       
                newstr+="\\t";       
                break;       
            default:       
                newstr+=c;       
        }  
   }  
   return newstr;       
}
exports = {
    APP_STATUS : APP_UNKNOWN,
    APP_ACTIVE : APP_ACTIVE,
    APP_DEACTIVATE : APP_DEACTIVATE,
    APP_UNKNOWN : APP_UNKNOWN,
    MEMORY_TEST_ON : MEMORY_TEST_ON,
    MEMORY_TEST_OFF : MEMORY_TEST_OFF,
    MEMORY_TEST_STATUS : MEMORY_TEST_OFF,
    string2Json : string2Json,
    getOccurStamp : getOccurStamp,
    voiceGuide : voiceGuide,
};
