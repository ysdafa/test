/**
 * @author He Mingcan (mingcan.he@samsung.com)
 * @fileoverview CAPI.js cpapi init.
 * @date 2014/07/17(last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.
 *
 * This software is the confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung.
 */
var SICServerAPI = Volt.require('app/common/SICServerAPI.js');
var YahooServerAPI = Volt.require('app/common/YahooServerAPI.js');
var SinaHuafengAPI = Volt.require('app/common/SinaHuafengAPI.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var Q = PanelCommon.Q;
var DeviceModel = Volt.require('app/common/deviceModel.js');

var CPAPI = {
	oCPModule : null,
	tryCount : 0,
	RETRY_LIMIT : 3,
	serviceType : 'yahoo',

	initialize : function () {
	    var deferred =  Q.defer();
		//SICServerAPI.initialize();
		onSICAuthSuccess();
		return deferred.promise;

		/*SICServerAPI.authenticate({
		success: function() {
		Volt.log('[initialize]auth succeed.');
		onSICAuthSuccess();
		},
		error: function(error) {
		//CPAPI.state = CPAPI.INIT_STATE_FAIL;
		Volt.log('[initialize]auth fail.');
		//onError(error);
		}
		});*/

		function onSICAuthSuccess() {
			//CPAPI.oCPModule = null;
			SICServerAPI.domainlist({
				success : function (result) {
					Volt.log('domainTotalCount: ' + result.domainTotalCount);
					if (result.domainTotalCount > 0) {
						CPAPI.serviceType = result.servicetype;
						switch (result.servicetype) {
		                    case 'yahoo':
			                    YahooServerAPI.initialize({
			                        domain: result.domainlist[0].apidomain,
			                        languageCode: result.domainlist[0].lang
			                    });
								CPAPI.oCPModule = YahooServerAPI;
								break;

		                    case 'sina_huafeng':
			                    SinaHuafengAPI.initialize({
			                        domainlist: result.domainlist
			                    });
								CPAPI.oCPModule = SinaHuafengAPI;
		                        break;

		                    default:
			                    YahooServerAPI.initialize({
			                        domain: result.domainlist[0].apidomain,
			                        languageCode: result.domainlist[0].lang
			                    });
								CPAPI.oCPModule = YahooServerAPI;
		                        break;
	                	}

						deferred.resolve(true);
					} else {
						Volt.log('get domainlist fail.');

						if (CPAPI.tryCount < CPAPI.RETRY_LIMIT) {
							Volt.log('Retry getting domainlist after 3 sec...');
							CPAPI.tryCount++;
							Volt.setTimeout(function () {
								//SICServerAPI.initialize();
								onSICAuthSuccess();
							}, 3000);

						} else {
							Volt.log('get domainlist timeout');
							deferred.resolve(false);
						}
					}
				},
				error : function (error) {
					CPAPI.tryCount = 0;
					Volt.log('get domainlist fail');
					deferred.resolve(false);
				}
			});
		}

		function onSuccess(result) {
			Volt.log('onSuccess in CPAPI');
		}

		function OnError(error) {
			Volt.log('OnError in CPAPI');
		}
	},

	getMainNewsAPI : function () {
		return CPAPI.oCPModule?CPAPI.oCPModule.getMainNewsAPI():'';
	},
	
	getMainWeatherAPI : function(options) {
		return CPAPI.oCPModule?CPAPI.oCPModule.getMainWeatherAPI(options):'';
    },
    
    getMoreNewsAPI : function(options) {
		return CPAPI.oCPModule?CPAPI.oCPModule.getMoreNewsAPI(options):'';
    },
    
    getNewsDetailAPI : function(options) {
		return CPAPI.oCPModule?CPAPI.oCPModule.getNewsDetailAPI(options):'';
    },

    getWeatherDetailAPI : function(options) {
		return CPAPI.oCPModule?CPAPI.oCPModule.getWeatherDetailAPI(options):'';
    },
    
    getWeatherCityListAPI : function() {
		return CPAPI.oCPModule?CPAPI.oCPModule.getWeatherCityListAPI():'';
    },
	
	getServiceType : function() {
		return CPAPI.serviceType;
	}


};

exports = CPAPI;
