 /** 
 * @fileoverview This module defines common values.
 * @date    2014/09/12 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var CommonDefines = {

    Event: {
        //used when app status changed
        APP_ON_DEACTIVATE:                  'APP_ON_DEACTIVATE',
        APP_ON_ACTIVATE:                    'APP_ON_ACTIVATE',
        APP_ON_PAUSE:                       'APP_ON_PAUSE',
        APP_ON_RESUME:                      'APP_ON_RESUME',
        APP_ON_UNLOAD:                      'APP_ON_UNLOAD',
        APP_ON_HIDE:                        'APP_ON_HIDE',
        MAINVIEW_DATA_READY:                'MAINVIEW_DATA_READY',
        MAINVIEW_DATA_FAILED:               'MAINVIEW_DATA_FAILED',
        //used for somewhere then change the visible of cursor
        CHANGE_VISIBLE_CURSOR:              'CHANGE_VISIBLE_CURSOR',
        
        //used only in main view
        SHOW_OPTION_MENU:                   'EVENT_SHOW_MAIN_POPUP',
        HIDE_OPTION_MENU:                   'EVENT_HIDE_MAIN_POPUP',
        SHOW_OR_HIDE_SETTING_BUTTON:        'EVENT_SHOW_OR_HIDE_SETTING_BUTTON',
        
        //used only in weather setting view
        UPDATE_SETTING_CITIES_TO_SERVER:    'EVENT_UPDATE_SETTING_CITIES_TO_SERVER',
        UPDATE_SELECTED_CITIES_1:           'EVENT_UPDATE_SELECTED_CITIES_COUNT_PRE',
        UPDATE_SELECTED_CITIES_2:           'EVENT_UPDATE_SELECTED_CITIES_COUNT_IN_VIEW',
        
        SET_FOCUS_BY_INDEX:                 'EVENT_SET_FOCUS_BY_INDEX',
        
        REFRESH_PROVINCE:                   'EVENT_REFRESH_PROVINCE',
        SET_FOCUS_TO_PROVINCE:              'EVENT_FOCUS_TO_PROVINCE',
        UPDATE_PROVINCE_BG:                 'EVENT_UPDATE_PROVINCE_BG',
        SHOW_PROVINCE_ARROW:                'EVENT_SHOW_ARROW_IN_PROVINCE',
        
        SET_FOCUS_TO_CITY :                 'EVENT_FOCUS_TO_CITY',
        REFRESH_CITY :                      'EVENT_REFRESH_CITY',
        UPDATE_CITY_BG :                    'EVENT_UPDATE_CITY_BG',
        SHOW_CITY_ARROW :                   'EVENT_SHOW_ARROW_IN_CITY',
        HIDE_CITY_ARROW :                   'EVENT_HIDE_ARROW_IN_CITY',
        ON_DEVICEINFO_READY :               'ON_DEVICEINFO_READY',
    },

    Vconf: {
        RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE:          'memory/window_system/input/cursor_visible',
        DEVICE_ATOKEN : 'db/comss/atoken',
        DEVICE_DUID : 'db/comss/duid',
        DEVICE_MODEL_ID : 'db/comss/modelid',
        COUNTRY_CODE : 'db/comss/countrycode',
        LANGUAGE : 'db/menu_widget/language',
        DB_MENU_ACCESSIBILITY_TTS : 'db/menu/accessibility/tts'
    },
    
    PopupType : {
        //common popup type
        NETWORK_ERROR_ENTRY:                'COMMON_POPUP_TYPE_NETWORK_ERROR_ENTRY',
        NETWORK_ERROR1:                     'COMMON_POPUP_TYPE_NETWORK_ERROR1',
        SERVER_ERROR2:                      'COMMON_POPUP_TYPE_SERVER_ERROR2',
        VERSION:                            'VERSION_POPUP_CONFIRM',
        
        //used only in main view
        OPTION_MENU:                        'OPTION_MENU',
        
        //used only in weather setting view
        EM_FROM_CITYLIST_SERVER:            'ERROR_MESSAGE_FROM_WEATHERCITYLIST_SERVER',
        SAVE:                               'SAVE',
        CANCEL:                             'CANCEL',
        MAXIMUM:                            'MAXIMUM',
        MINIMUM:                            'MINIMUM',
    },
    
    PopupTime : {
        SIMPLE_TIMEOUT :                    5000,
        SPECIFIC_TIMEOUT :                  10000, 
        OPTION_TIMEOUT :                    30000
    },
    
    NetWorkTime : {
        REQUEST_TIMEOUT : 10000,
        RETRY_TIME : 3
    },
    
    RefreshTime : {
        REFRESH_NEWS_TIMEOUT : 600000  // 10 * 60 * 1000
    },
    
    Opacity : {
        MAINNEWS_OPACITY_FOCUS : 242, // 255 * 0.95
        MAINNEWS_OPACITY_BLUR : 25, //255 * 0.1
    },
    
    AniTime : {
        WEATHER_SETTING_MOVE_TIME : 200
    },
   
    VERSION : '1.11.11.1'
    
};

exports = CommonDefines;
