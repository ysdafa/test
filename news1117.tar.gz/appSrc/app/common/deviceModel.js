/**
 * @author He Mingcan (mingcan.he@samsung.com)
 * @fileoverview deviceModel.js get device info.
 * @date 2014/07/17(last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.
 *
 * This software is the confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung.
 */
var Backbone = Volt.require('lib/volt-backbone.js');
var voltapi = Volt.require('modules/voltapi.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');
var GlobalMediator = Volt.require('app/common/GlobalMediator.js');
var self = null;

var DeviceInfoModel = Backbone.Model.extend({
    deviceInfoReady : false,
    defaults : {
    	duid : "",
    	modelId : "",
    	countryCode : "",
    	languageCode : "",
    	serverType : "",
    	vdToken : "",
    	versionInfo : "",
    	firmware : "",
    	resolutionX : "",
    	resolutionY : "",
    	deviceType : "",
    	deviceYear : "",
    	networkState : 0,
    	tts : ''
    },

    initialize : function () {
        self = this;
        this.destroyVoltApi();
        this.updateInfoFromWAS();
        this.updateInfoFromVCONF();
        //this.set("networkState", getNetworkStatus());
        this.listenNetworkStatus();
        this.setResolution();
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE, this.onChangeVisibleCursor);
    },

    setResolution : function () {
    	this.set("resolutionX", 1920);
    	this.set("resolutionY", 1080);
    },

    getNetWorkState : function () {
        //this.set("networkState", this.getNetworkStatus());
        return this.get("networkState");
    },
    
    getLanguageCode : function() {
        return this.get("languageCode");
    },

    //1: true, 0: false
    getMenuTTS : function() {
        return this.get('tts');
    },

    isDeviceInfoReady : function() {
        Volt.log('deviceInfoReady is '+this.get('deviceInfoReady'));
        return this.get('deviceInfoReady');
    },
    
    updateInfoFromWAS : function () {
        if (true == voltapi.WAS.isOpened()){
            Volt.log('voltapi.WAS already opened');
            this.updateInfoFromWASCallback();
        } else {
            voltapi.WAS.initAsync(this.updateInfoFromWASCallback, null);
        }
        
        /*if (true == ready) {
    		var oDebugInfo = voltapi.WAS.getDebugInfo();
            if(oDebugInfo === 0)
            oDebugInfo = {};
			
            //this.set('duid', oDebugInfo.duid || '');
            //this.set('modelId', oDebugInfo.model_id || '15_TIZEN');
            Volt.log('firmware_version get by WAS is '+oDebugInfo.firmware_version);
            this.set('firmware', oDebugInfo.firmware_version || getFirmware());
            Volt.log('server_type get by WAS is '+oDebugInfo.server_type);
            this.set("serverType", oDebugInfo.server_type || getServerType());
        }*/
    },

    updateInfoFromWASCallback : function () {
        Volt.log('updateInfoFromWASCallback is called');
		var oDebugInfo = voltapi.WAS.getDebugInfo();
        if(oDebugInfo === 0)
        oDebugInfo = {};
		
        Volt.log('firmware_version get by WAS is '+oDebugInfo.firmware_version);
        self.set('firmware', oDebugInfo.firmware_version || getFirmware());
        Volt.log('server_type get by WAS is '+oDebugInfo.server_type);
        self.set("serverType", oDebugInfo.server_type || getServerType());
        
        Volt.log('Network status get by WAS is ' + oDebugInfo.networks_status);
		if ('OK' == oDebugInfo.networks_status){
			self.set("networkState", 0);
		} else if ('NG' == oDebugInfo.networks_status){
			self.set("networkState", -1);
		}
        
        self.deviceInfoReady = true;
        GlobalMediator.trigger(CommonDefines.Event.ON_DEVICEINFO_READY);
    },

    updateInfoFromVCONF : function () {
        var atoken = voltapi.vconf.getValue(CommonDefines.Vconf.DEVICE_ATOKEN);
        Volt.log('atoken get by vconf is '+atoken);
        this.set("vdToken", atoken || getAToken());

        var model_id = voltapi.vconf.getValue(CommonDefines.Vconf.DEVICE_MODEL_ID);
        Volt.log('model_id get by vconf is '+model_id);
        this.set("modelId", model_id || getModelId());

        var duid = voltapi.vconf.getValue(CommonDefines.Vconf.DEVICE_DUID);
        Volt.log('duid get by vconf is '+duid);
        this.set("duid", duid || getDUID());
		
        var country_code = voltapi.vconf.getValue(CommonDefines.Vconf.COUNTRY_CODE);
        Volt.log('country code get by vconf is '+country_code);
        if (country_code != 'CN'){
            country_code = 'BR';//dummy Brazil
        }
        this.set("countryCode", country_code || getCountryCode());
        
        var lang = voltapi.vconf.getValue(CommonDefines.Vconf.LANGUAGE);
        Volt.log('menu language get by vconf is '+ lang);
        this.set("languageCode", analyzeLanguageCode(lang || "es_US"));

        var tts = voltapi.vconf.getValue(CommonDefines.Vconf.DB_MENU_ACCESSIBILITY_TTS);
        Volt.log('menu tts get by vconf is '+ tts);
        this.set('tts', tts || '');
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.DB_MENU_ACCESSIBILITY_TTS, this.onChangeTTS);
    },

   /**
     * onChangeTTS Callback.
     * @method
     */
    onChangeTTS : function(key, value) {
        Volt.log("[deviceModel.js] onChangeTTS() : " + value);
        this.set('tts', value || '');
    },

    getNetworkStatus : function () {
        return 0;
        if (true == voltapi.WAS.isOpened()) {
    		var oDebugInfo = voltapi.WAS.getDebugInfo();	
    		Volt.log('Network status get by WAS is ' + oDebugInfo.networks_status);
    		if ('OK' == oDebugInfo.networks_status){
    			return 0;
    		} else if ('NG' == oDebugInfo.networks_status){
    			return -1;
    		} else {
                return this.get('networkState');
            }
    	}else{
            Volt.log('voltapi network is not opened');
            return this.get('networkState');
    	}
    },

    listenNetworkStatus : function() {
    	var self = this;
        Volt.log("set listener to network by volt js Network");

        var ready = voltapi.network.isOpened();
        if (true == ready){
            Volt.log('voltapi.network already opened');
        } else {
            ready = voltapi.network.init();
            Volt.log('network init ret is '+ready);
        }

    	if (true == ready) {
    	    voltapi.network.getAvailableNetworks(function(networkList) {
    	        networkList[0].setWatchListener({
    	            onconnect : function(type) {
    	                Volt.log("wireless network onconnect");
    					self.set("networkState", 0);
    	            },
    	            ondisconnect : function(type) {
    	                Volt.log("wireless network ondisconnect");
    					self.set("networkState", -1);
    	            }
    	        }, function() {
    	            Volt.log("wireless network error");
    	        });

    	        networkList[1].setWatchListener({
    	            onconnect : function(type) {
    	                Volt.log("wired network onconnect");
    					self.set("networkState", 0);
    	            },
    	            ondisconnect : function(type) {
    	                Volt.log("wired network ondisconnect");
    					self.set("networkState", -1);
    	            }
    	        }, function() {
    	            Volt.log("wired network error");
    	        });
    	    }, function(errorMessage) {
    	        Volt.log("network error errorMessage : " + errorMessage);
    	    });
    	}
    },
    destroyVoltApi : function() {
        if (voltapi.network.isOpened()){
            Volt.log('voltapi.network.destroy');
            voltapi.network.destroy();
        }
        if (voltapi.WAS.isOpened()){
            Volt.log('voltapi.WAS.destroy');
            voltapi.WAS.destroy();
        }

    },
    
    onChangeVisibleCursor : function(key, value) {
    	Volt.log("onChangeVisibleCursor() : " + value);
    	//self.set('visibleCursor', value || '');
    	GlobalMediator.trigger(CommonDefines.Event.CHANGE_VISIBLE_CURSOR, value);
    }
})

var getAToken = function () {
    return "VdFXu65a83meaVhanWLtQFe86V82ARh1+zDhS9hwZfDu5y1Zv3QoAp+Pk1ULtr0CfUJ0LNaeEneXeWHTZJNgSAojRR6mK0wKIx79kMxhryGKB3MNSqSx5x7+RaiD9wsryO26CTBV74wD7KsnkqeV5Aei=SASAT=";
};

var getDUID = function () {
    return "15PreHawk";
};

var getModelId = function () {
	return "14_GOLFP_TIZEN";
};

var getCountryCode = function () {
	return "BR";
};

var getFirmware = function () {
	return "T-GFP9AKUC-1106.4";
};

var getServerType = function () {
	return "SERVERTYPE_DEVELOPMENT";
};

var analyzeLanguageCode = function(vconfMenuLang) {
    Volt.log("Lang: " + vconfMenuLang);
    var languageCode = '';

    var preDefine = {
        'fr_US' : 'fr-US',
        'es_US' : 'es-US',
        'pt_US' : 'pt-US',
        'en_GB' : 'en-GB',
        'zh_CN' : 'zh-CN',
        'zh_HK' : 'zh-HK',
        'zh_TW' : 'zh-TW'
    };

    var lang = vconfMenuLang.split('.')[0];

    if (preDefine[lang]) {
        languageCode = preDefine[lang];
    } else {
        languageCode = lang.split('_')[0];
    }

    Volt.log("languageCode: " + languageCode);
    return languageCode;
};

exports = new DeviceInfoModel();
