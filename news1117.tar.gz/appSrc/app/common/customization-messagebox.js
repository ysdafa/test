/**
 * @author Zhu Hongjie (hj00.zhu@samsung.com)
 * @fileoverview Draw a MessageBox
 * @date 2014/10/30(last modified date)
 * 
 * Copyright 2014 by Samsung Electronics, Inc.
 * 
 * This software is the confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung.
 */

//Require common template for customization-messagebox
var CommonTemplate = Volt.requireAppTemplate('newson-common-template.js');

var PanelCommon = Volt.require('lib/panel-common.js');
//Require common defines
var CommonDefines = Volt.require('app/common/commonDefines.js');
var isShowLog = true;
/**
 * Custom a MessageBox by assigned template base on GUI.
 * @function customizationMessageBox
 * @param {Widget} widget - the parent of MessageBox
 * @param {JSON} options - the json defined type of MessageBox, callbacks of MessageBox's buttons
 * @example 1. customizationMessageBox(widget, { type : type); 
 *          2. customizationMessageBox(widget, { type : type, errorCode : erroeCode, callbacks : callbacks});
 */
var customizationMessageBox = function(widget, options) {
    if (!options || !__checkType(options.type)) {
        Volt.log('[--------------------type error-------------------]');
        return undefined;
    }
    var content = __getContent(options);
    var buttons = __getButtons(options.type);
    var defaultFocusIndex = __getDefaultFocusIndex(options.type);
    var callbacks = options.callbacks;
    var timeout = __getTimeout(options.type);
    var buttonType = __getButtonType(buttons.length);
    var contentType = __getContentType(options.type);

    Volt.log('[content - ' + content + '] [buttons - ' + buttons.toString() + ']');

    if (content) {
        var messageBox = __customizationMessageBoxNoTitle(PanelCommon.loadTemplate(CommonTemplate.MessageBoxNoTitle, {
            buttonType : buttonType,
            contentType : contentType
        }, widget), content, buttons, callbacks, defaultFocusIndex);
        messageBox.timeout = timeout;
        return messageBox;
    }
    return undefined;
};

/*
 * Custom a MessageBox with content and buttons.
 * @function __customizationMessageBoxNoTitleButton
 * @param {MessagePopup} messageBox - a MessageBox
 * @param {String} iContent - the content text of MessageBox
 * @param {Array} iButtons - the array of button text for MessageBox
 * @param {Array} iCallbacks - the array of button callback for MessageBox
 * @param {Number} defaultFocusIndex - the default focus index for MessageBox
 */
function __customizationMessageBoxNoTitle(messageBox, iContent, iButtons, iCallbacks, defaultFocusIndex) {
    if(messageBox == null || messageBox == undefined) {
        throw new Error('Error to custom Button: non button');
    }
    messageBox.contentText = iContent;
    
    var messageBoxTemplate = CommonTemplate.MessageBoxCommon;
    if(messageBox.setButtonText){
        for ( var i = 0; i < iButtons.length; i++) {
            if (isShowLog) {
                print('[customization-messagebox.js] setButtonText(button_' + (i + 1) + ',"all", ' + iButtons[i] + ');');
            }
            messageBox.setButtonText('button_' + (i + 1), 'all', iButtons[i]);
        }
    }
    
    if (messageBoxTemplate.hasOwnProperty('buttonStyle')) {
        __setButtonTextFontSize(messageBox, messageBoxTemplate.buttonStyle);
        __setButtonTextColor(messageBox, messageBoxTemplate.buttonStyle);
        __setButtonImage(messageBox, messageBoxTemplate.buttonStyle);
        __setButtonBackgroundColor(messageBox, messageBoxTemplate.buttonStyle);
    }

    var messageBoxListener = new MessageBoxListener;
    messageBoxListener.OnButtonEvent = function(messagebox, nButtonIndex, eventType) {
        Volt.log('nButtonIndex - ' + nButtonIndex + ' eventType - ' + eventType);
        if (messageBox.timer != null) {
            Volt.clearTimeout(messageBox.timer);
            if(messageBox.timeOutTime) {
                messageBox.timer = Volt.setTimeout(messageBox.timeoutCB, messageBox.timeOutTime);
            }
        }
        if ('button_clicked' == eventType) {
            if ('button_1' == nButtonIndex) {
                print('[customization-messagebox.js][' + iButtons[0] + '] click');
                if (iCallbacks && iCallbacks[0]) {
                    iCallbacks[0]();
                } else {
                    if (messageBox.timeoutCB) {
                        messageBox.timeoutCB();
                    }
                }
            } else if ('button_2' == nButtonIndex) {
                print('[customization-messagebox.js][' + iButtons[1] + '] click');
                if (iCallbacks && iCallbacks[1]) {
                    iCallbacks[1]();
                } else {
                    if (messageBox.timeoutCB) {
                        messageBox.timeoutCB();
                    }
                }
            }
        } else if ('button_focus_in' == eventType) {
            if ('button_1' == nButtonIndex) {
                print('[customization-messagebox.js][' + iButtons[0] + '] focus in');
            } else if ('button_2' == nButtonIndex) {
                print('[customization-messagebox.js][' + iButtons[1] + '] focus in ');
            }
        } else if ('button_focus_out' == eventType) {
            if ('button_1' == nButtonIndex) {
                print('[customization-messagebox.js][' + iButtons[0] + '] focus out');
            } else if ('button_2' == nButtonIndex) {
                print('[customization-messagebox.js][' + iButtons[1] + '] focus out ');
            }
        }
    };
    messageBox.enablePointerFocus();
    messageBox.addListener(messageBoxListener);
    messageBox.defaultFocusIndex = (defaultFocusIndex + 1);

//    messageBox.onKeyEvent = function(keyCode, keyType) {
//        Volt.log('keyCode : ' + keyCode + ' keyType : ' + keyType);
//        switch (keyCode) {
//            case Volt.KEY_RETURN :
//                if (messageBox.timeoutCB && keyType != Volt.EVENT_KEY_RELEASE) {
//                    messageBox.timeoutCB();
//                    return true;
//                }
//                break;
//            case Volt.KEY_JOYSTICK_OK :
//                return true;
//        }
//        return false;
//    };

    messageBox.startTimeOut = function(obj) {
        if (obj == null || typeof (obj) == "undefined") {
            return false;
        }
        if (obj.hasOwnProperty("time") && 'number' == typeof obj.time && obj.time > 0) {
            messageBox.timeOutTime = obj.time;
        }
        if (obj.hasOwnProperty("callback")) {
            messageBox.timeoutCB = obj.callback;
        }
        if (messageBox.timeoutCB != null) {
            if(messageBox.timeOutTime) {
                messageBox.timer = Volt.setTimeout(messageBox.timeoutCB, messageBox.timeOutTime);
            }
        }
    };

    messageBox.release = function() {
        if (messageBox.timer != null) {
            Volt.clearTimeout(messageBox.timer);
            messageBox.timer = null;
        }
        messageBox.removeListener(messageBoxListener);
//        messageBox.hide();
        messageBox.destroy();
        delete messageBox;
    };

    return messageBox;
};

/*
 * Check effective type
 * @param {String} type - the type of MessageBox
 */
function __checkType(type) {
    switch (type) {
        case CommonDefines.PopupType.SAVE :
        case CommonDefines.PopupType.CANCEL :
        case CommonDefines.PopupType.MAXIMUM :
        case CommonDefines.PopupType.MINIMUM :
        case CommonDefines.PopupType.EM_FROM_CITYLIST_SERVER :
        case CommonDefines.PopupType.VERSION :
        case CommonDefines.PopupType.SERVER_ERROR2 :
        case CommonDefines.PopupType.NETWORK_ERROR_ENTRY:
        case CommonDefines.PopupType.NETWORK_ERROR1 :
            return true;
    }
    return false;
}

/*
 * Define a content for MessageBox
 * @param {JSON} options - the define info for MessageBox
 */
function __getContent(options) {
    var iContent;
    switch (options.type) {
        case CommonDefines.PopupType.SAVE :
            iContent = Volt.LANG.POPUP_SAVE_TIP;
            break;
        case CommonDefines.PopupType.CANCEL :
            iContent = Volt.i18n.t('TV_SID_WANT_TO_DISCARD_ALL_CHANOES');
            break;
        case CommonDefines.PopupType.MAXIMUM :
            iContent = Volt.LANG.POPUP_MAXIMUM_TIP;
            break;
        case CommonDefines.PopupType.MINIMUM :
            iContent = Volt.i18n.t('COM_SID_MUST_SELECT_AT_LEAST_ONE_CITY');
            break;
        case CommonDefines.PopupType.EM_FROM_CITYLIST_SERVER :
            var WeatherSettingModel = Volt.require('app/models/newson-weather-setting-model.js');
            iContent = WeatherSettingModel.get('attributes').error_msg;
            break;
        case CommonDefines.PopupType.VERSION :
            iContent = Volt.i18n.t('SID_VERSION') + " : " + CommonDefines.VERSION;
            break;
        case CommonDefines.PopupType.NETWORK_ERROR_ENTRY:
            iContent = Volt.i18n.t('TV_SID_NOT_CONNECTED_INTERNET_REQUIRES_NETWORK');
            break;
        case CommonDefines.PopupType.SERVER_ERROR2 :
            iContent = Volt.i18n.t('TV_SID_SAMSUNG_SERVER_NOT_RESPONDING_TRY') + '(<<' + options.errorCode + '>>)';
            break;
        case CommonDefines.PopupType.NETWORK_ERROR1 :
            iContent = Volt.i18n.t('TV_SID_NOT_CONNECTED_INTERNET_REQUIRES_NETWORK') + '(<<' + options.errorCode + '>>)';
            break;
        default :
            iContent = null;
    }
    return iContent;
}

/*
 * Define buttons for MessageBox
 * @param {String} type - the type of MessageBox
 */
function __getButtons(type) {
    var iButtons;
    switch (type) {
        case CommonDefines.PopupType.CANCEL :
            iButtons = [Volt.i18n.t('SID_YES'), Volt.i18n.t('SID_NO')];
            break;
        case CommonDefines.PopupType.NETWORK_ERROR1 :
            iButtons = [Volt.i18n.t('UID_ONTV_TROUBLESHOT'), Volt.i18n.t('SID_CANCEL')];
            break;
        default :
            iButtons = [Volt.i18n.t('SID_OK')];
    }
    return iButtons;
}

/*
 * Define buttonType for MessageBox
 * @param {Number} buttonLength - the number of buttons
 */
function __getButtonType(buttonLength) {
    var buttonType;
    switch (buttonLength) {
        case 1 :
            buttonType = 'button_1';
            break;
        case 2 :
            buttonType = 'button_2';
            break;
        default :
            buttonType = 'no_button';
            break;
    }
    return buttonType;
}

/*
 * Define default focus index for MessageBox
 * @param {String} type - the type of MessageBox
 */
function __getDefaultFocusIndex(type) {
    var defaultFocusIndex;
    switch (type) {
        case CommonDefines.PopupType.CANCEL :
            defaultFocusIndex = 1;
            break;
        default :
            defaultFocusIndex = 0;
    }
    return defaultFocusIndex;
}

/*
 * Define default timeout for MessageBox
 * @param {String} type - the type of MessageBox
 */
function __getTimeout(type) {
    var timeout;
    switch (type) {
        case CommonDefines.PopupType.CANCEL :
            timeout = CommonDefines.PopupTime.SPECIFIC_TIMEOUT;
            break;
        case CommonDefines.PopupType.NETWORK_ERROR_ENTRY:
            timeout = 0;
            break;
        default :
            timeout = CommonDefines.PopupTime.SIMPLE_TIMEOUT;
    }
    return timeout;
}

/*
 * Define default contentType for MessageBox
 * @param {String} type - the type of MessageBox
 */
function __getContentType(type) {
    var contentType;
    switch (type) {
        case CommonDefines.PopupType.SAVE :
        case CommonDefines.PopupType.CANCEL :
        case CommonDefines.PopupType.MAXIMUM :
        case CommonDefines.PopupType.MINIMUM :
        case CommonDefines.PopupType.VERSION :
            contentType = 'single_line_content_type';
            break;
        default :
            contentType = 'multi_line_content_type';
    }
    return contentType;
}

function __setButtonTextFontSize(messageBox, style) {
    if (style.hasOwnProperty('fontSize') && messageBox.setButtonTextFontSize) {
        if ('number' == typeof style.fontSize.all) {
            if (isShowLog) {
                print('[customization-messagebox.js] setButtonTextFontSize("button_all",' + ' "all",' + style.fontSize.all + ');');
            }
            messageBox.setButtonTextFontSize('button_all', 'all', style.fontSize.all);
        }
        for ( var name in style.fontSize) {
            if (__isButtonStatus(name) && 'number' == typeof style.fontSize[name]) {
                if (isShowLog) {
                    print('[customization-messagebox.js] setButtonTextFontSize("button_all", "' + name + '", ' + style.fontSize[name] + ");");
                }
                messageBox.setButtonTextFontSize('button_all', name, style.fontSize[name]);
            }
        }
    }
}

function __setButtonTextColor(messageBox, style) {
    if (style.hasOwnProperty('textColor') && messageBox.setButtonTextColor) {
        var textColor = undefined;
        if ('object' == typeof style.textColor.all) {
            textColor = style.textColor.all;
            if (isShowLog) {
                print('[customization-messagebox.js] setButtonTextColor("button_all", ' + '"all", ' + JSON.stringify(textColor) +');');
            }
            messageBox.setButtonTextColor('button_all', 'all', textColor.r, textColor.g, textColor.b, textColor.a);
        }

        for ( var name in style.textColor) {
            if (__isButtonStatus(name) && 'object' == typeof style.textColor[name]) {
                textColor = style.textColor[name];
                if (isShowLog) {
                    print('[customization-messagebox.js] setButtonTextColor("button_all", "' + name + '", ' + JSON.stringify(textColor) +');');
                }
                messageBox.setButtonTextColor('button_all', name, textColor.r, textColor.g, textColor.b, textColor.a);
            }
        }
    }
}

function __setButtonImage(messageBox, style) {
    if (style.hasOwnProperty('image') && messageBox.setButtonImage) {
        if ('string' == typeof style.image.all) {
            if (isShowLog) {
                print('[customization-messagebox.js] setButtonImage("button_all", ' + '"all", ' + style.image.all +');');
            }
            messageBox.setButtonImage('button_all', 'all', style.image.all);
        }

        for ( var name in style.image) {
            if (__isButtonStatus(name) && style.image[name]) {
                if (isShowLog) {
                    print('[customization-messagebox.js] setButtonImage("button_all", "' + name + '",' + style.image[name] +');');
                }
                messageBox.setButtonImage('button_all', name, style.image[name]);
            }
        }
    }
}

function __setButtonBackgroundColor(messageBox, style) {
    if (style.hasOwnProperty('color') && messageBox.setButtonBackgroundColor) {
        var color = undefined;
        if ('object' == typeof style.color.all) {
            color = style.color.all;
            if (isShowLog) {
                print('[customization-messagebox.js] setButtonBackgroundColor("button_all", ' + '"all", ' + JSON.stringify(color) +');');
            }
            messageBox.setButtonBackgroundColor('button_all', 'all', color.r, color.g, color.b, color.a);
        }

        for ( var name in style.color) {
            if (__isButtonStatus(name) && 'object' == typeof style.color[name]) {
                color = style.color[name];
                if (isShowLog){
                    print('[customization-messagebox.js] setButtonBackgroundColor("button_all", "' + name + '", ' + JSON.stringify(color)+');');
                }
                messageBox.setButtonBackgroundColor('button_all', name, color.r, color.g, color.b, color.a);
            }
        }
    }
}

function __isButtonStatus(status) {
    switch (status) {
        case 'normal' :
        case 'focused' :
        case 'selected' :
        case 'roll-over' :
        case 'focused-roll-over' :
        case 'disabled' :
        case 'disabled-focused' :
//        case 'all':
            return true;
    }
    return false;
}

exports = customizationMessageBox;