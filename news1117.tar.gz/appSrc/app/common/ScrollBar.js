function rgcDownPage()
{
    if(typeof this.index !== 'number' || this.index < 0 || this.index >= this.total)
        return;
    if(this.index >= 0 && this.index <= this.total - 1)
    {
        this.index++;
    }
    if(this.index == this.total)
    {
        if(this.loop)
        {
            this.index = 0;
        }else
        {
            this.index = this.total - 1;
        }
    }
    this.__updateScrollBar('up');
}
function rgcUpPage()
{
    if(typeof this.index !== 'number' || this.index < 0 || this.index >= this.total)
        return;
    if(this.index >= 0)
    {
        this.index--;
    }
    if(this.index < 0)
    {
        if(this.loop)
        {
            this.index = this.total - 1;
        }else
        {
            this.index = 0;
        }
    }
    this.__updateScrollBar('down');
    
}
function rgcUpdateScrollBar(direction)
{
    var widget = this;
    this.thumb.y = this.index * Math.floor(this.height / this.total);
    if(this.index == this.total - 1)
    {
        this.thumb.height = Math.floor(this.height / this.total) + this.extraPart; //adjust the thumb height when it goes to end
    }else
    {
        this.thumb.height = Math.floor(this.height / this.total);
    }
    
    if(!this.bThumbShow)
    {
        if(this.animationShowHandle !== null)
        {
            this.animationShowHandle.cancel();
            this.animationShowHandle = null;
        }
        this.bThumbShow = true;
        this.animationShowHandle = this.animate(this.animationShow,function(){});
    }
    if(this.timeout !== null)
    {
        Volt.clearTimeout(this.timeout);
        this.timeout = null;
    }
    this.timeout = Volt.setTimeout(function(){
        if(widget.animationHideHandle !== null)
        {
            widget.animationHideHandle.cancel();
            widget.animationHideHandle = null;
        }
        widget.animationHideHandle = widget.animate(widget.animationHide,function(){
            widget.bThumbShow = false;
        });
    },1000);
}
function defaultValue(value, defaultValue)
{
	if (value === undefined)
	{
		return defaultValue;
	}
	else
	{
		return value;
	}
}
function rgcSetCount(count)
{
    if(typeof count !== 'number' || count <= 0)
        return;
    this.total = count;
    this.index = 0;
    this.thumb.height = Math.floor(this.height/this.total);
    this.extraPart = this.height % this.total;
}
function ScrollBar(param)
{
    var height = parseInt(defaultValue(param['height'],1080));
    var width = parseInt(defaultValue(param['width'],5));
    var x = parseInt(defaultValue(param['x'],0));
    var y = parseInt(defaultValue(param['y'],0));
    var total = 0;
    var index = 0;
    var loop = defaultValue(param['loop'],false);
    var scrollBar = new Widget({
        height:height,
        width:width,
        color : {r:220,g:220,b:220,a:255*0.2},
        x:x,
        y:y,
    });
    scrollBar.parent = param['parent'];
    scrollBar.id = param['id'];
    scrollBar.total = total;
    scrollBar.index = index;
    scrollBar.loop = loop;
    scrollBar.timeout = null;
    scrollBar.thumb = new Widget({
      x:0,
      y:0,
      height:0,
      width:width,
      color:{r:255,g:255,b:255,a:255},
      parent:scrollBar,
    })
    scrollBar.animationShow = new Animation(200, 0);
    scrollBar.animationShowHandle = null;
    scrollBar.animationShow.addProperty("opacity", 255);
    scrollBar.animationHide = new Animation(200, 0);
    scrollBar.animationHide.addProperty("opacity", 0);
    scrollBar.animationHideHandle = null;
    scrollBar.setCount = rgcSetCount;
    scrollBar.bThumbShow = false;
    scrollBar.upPage = rgcUpPage;
    scrollBar.downPage = rgcDownPage;
    scrollBar.__updateScrollBar = rgcUpdateScrollBar;
    scrollBar.opacity = 0;
    scrollBar.show();
    return scrollBar;
}

exports = ScrollBar;
    
