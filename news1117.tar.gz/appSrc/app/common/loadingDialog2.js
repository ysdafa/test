//var AnimatedImageDrawing = require("UIElement/AnimatedImageDrawing");
function setTimeout(cb, interval, param) {
	return Volt.setTimeout(cb, interval, param);
}

function clearTimeout(id){
	if (id !== undefined)  {
		Volt.clearTimeout(id);
	}
}

function setInterval(cb, interval, param){
	return Volt.setInterval(cb, interval, param);
}

function clearInterval(id){
	if (id !== undefined) {
		Volt.clearInterval(id);
	}
}
function rgcShow()
{
	scene.removeChild(this);
	scene.addChild(this);
    this.index = 0;
    if(this.timer !== null)
    {
        clearInterval(this.timer);
        this.timer = null;
    }
	this.timer = setInterval(this.playCallBack, this.interval, this);
    this.addEventListener("OnMouseOver", function(targetWidget, eventData){
    });
	this.show();
}

function rgcHide()
{   
    if(this.timer !== null)
    {
        clearInterval(this.timer);
        this.timer = null;
    }
    this.removeEventListener("OnMouseOver", function(targetWidget, eventData){
    });
    this.instance.src = this.map[0];
	this.hide();
}

function rgcPlayCallback(userData)
{
    if(userData.map.length <= 0)
        return;
    userData.instance.src = userData.map[userData.index];
    if(userData.index < userData.count - 1)
        userData.index++;
    else
        userData.index = 0;
}
var FRAME_COUNT = 63;
function loadingDialog(param)
{
	var dimX = param['dimX'];
    var dimY = param['dimY'];
    var dimWidth = param['dimWidth'];
    var dimHeight = param['dimHeight'];
    var interval = param['interval'];
    var dimSecondX = param['dimSecondX'];
    var dimSecondY = param['dimSecondY'];
    var dimSecondWidth = param['dimSecondWidth'];
    var dimSecondHeight = param['dimSecondHeight'];
    var dimSecondColor = param['dimSecondColor'];
    var loadingBg1X = param['loadingBg1X'];
    var loadingBg1Y = param['loadingBg1Y'];
    
    var loadingBg1Width = param['loadingBg1Width'];
    var loadingBg1Height = param['loadingBg1Height'];
    var loadingBg2X = param['loadingBg2X'];
    var loadingBg2Y = param['loadingBg2Y'];
    var loadingBg2Width = param['loadingBg2Width'];
    var loadingBg2Height = param['loadingBg2Height'];
    
    var whitePointHeight = param['whitePointHeight'];
    var whitePointWidth = param['whitePointWidth'];
    var loadingFont = param['loadingFont'];
    var imagePath = param['imagePath'];
    //
    var loadingDialog = new Widget({
		x:dimX,
		y:dimX,
		width : dimWidth,
		height : dimHeight,
		color : {
			r : 0,
			g : 0,
			b : 0,
			a : 255 * 0.5,
		},
		parent:scene,
	});
    loadingDialog.interval = interval;
 
    loadingDialog.hide();
    var dimSecond = new Widget({
        x:dimSecondX,
        y:dimSecondY,
        width : dimSecondWidth,
        height: dimSecondHeight,
        color: dimSecondColor,
        parent: loadingDialog,
    })
    
	var bg1 = new ImageWidget({
        x:loadingBg1X,
        y:loadingBg1Y,
        width : loadingBg1Width,
        height: loadingBg1Height,
        color : {r:111,g:111,b:111,a:0},
        parent:dimSecond,
    });
    var bg2 = new TextWidget({
        x:loadingBg2X,
        y:loadingBg2Y,
        width : loadingBg2Width,
        height: loadingBg2Height,
        color : {r:111,g:111,b:111,a:0},
        font : loadingFont,//'SVD Light 40px',
        text : Volt.i18n.t('COM_SID_LOADING_DOT'),
        horizontalAlignment : 'center',
        parent:dimSecond,
    });
    loadingDialog.instance = bg1;
    loadingDialog.map = [];
    for(var i = 0; i < FRAME_COUNT;i++)
    {
        var index = i+1;
        if(i < 9)
        {
            loadingDialog.map[i] =  imagePath + whitePointWidth +'x' + whitePointWidth+'/' + 'loading_bright_'+whitePointWidth+'_0'+ index + '.png';
        }else
        {
            loadingDialog.map[i] =  imagePath + whitePointWidth +'x' + whitePointWidth+'/' + 'loading_bright_'+whitePointWidth+'_'+ index + '.png';
        }
    }
    loadingDialog.playCallBack = rgcPlayCallback;
    loadingDialog.count = FRAME_COUNT;
    loadingDialog.index = 0;
	loadingDialog.play = rgcShow;
	loadingDialog.stop = rgcHide;
	return loadingDialog;
}

exports = loadingDialog;