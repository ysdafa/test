/**
 * @author He Mingcan (mingcan.he@samsung.com)
 * @fileoverview SICServerAPI.js.
 * @date 2014/07/17(last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.
 *
 * This software is the confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung.
 */
var HttpRequest = Volt.require('app/common/HttpRequest.js');
var DeviceInfoModel = Volt.require('app/common/deviceModel.js');
/* A Module for accessing to Samsung Information panel Configuration Server. */

var SICServerAPI = {
	/*SERVER_URL : 'https://osbstg.samsungcloudsolution.com',
	APP_KEY : '',
	SEC_KEY : '',
	MODEL_ID : '',
	DUID : '',
	COUNTRY_CODE : '',
	TOKEN : '',
	CONTENT_TYPE : 'application/xml; charset=utf-8',
	CONTENT_LENGTH : '0',
	ACCEPT : 'application/json',
	HOST : 'newson',
	CACHE_CONTROL : 'no-cache',
	ACCEPT_ENCODING : 'gzip, deflate',
	SMART_TV_CLIENT : 'OTN-FW/T-GFP9AKUC-1106.4',

	initialize : function () {
		if (DeviceInfoModel.get('serverType') == 'SERVERTYPE_DEVELOPMENT') {
			this.SERVER_URL = 'https://osbstg.samsungcloudsolution.com';
			this.APP_KEY = '940511b2-edcc-11e2-a288-782bcb9aa972-4f444a12-0430-49b4-a2fd-80da3fafce14';
			this.SEC_KEY = '3606a7a8-6ba1-4de9-a84a-c79307ab406b-26f4264f-334c-4920-850e-830c6355dd38';
		}
		this.MODEL_ID = DeviceInfoModel.get('modelId');
		this.DUID = DeviceInfoModel.get('duid');
		this.COUNTRY_CODE = DeviceInfoModel.get('countryCode');
		this.TOKEN = DeviceInfoModel.get('vdToken');
		Volt.log('model id is ' + this.MODEL_ID);
		Volt.log('duid is ' + this.DUID);
		Volt.log('countrycode is ' + this.COUNTRY_CODE);
		Volt.log('token is ' + this.TOKEN);
	},

	authenticate : function (options) {
		var self = this;

		this.validtoken({
			success : function (result) {
				Volt.log('Authentication Success!');
				options.success();
			},
			error : function (serverError) {
				self.TOKEN = '';

				Volt.log('Authentication Failed! ' + serverError);

				options.error(serverError);
			}
		});
	},

	validtoken : function (options) {
		Volt.log('validtoken start ');
		var self = this;
		HttpRequest.handleRequest({
			operation : 'validtoken',
			url : self.SERVER_URL + '/openapi/device/auth/valid_atoken',
			type : 'GET',
			property : {
				token : self.TOKEN,
				model_id : self.MODEL_ID,
				duid : self.DUID,
				country_code : self.COUNTRY_CODE
			},
			success : options.success,
			error : options.error
		});
	},*/

	domainlist : function (options) {
		Volt.log('domainlist start');

		var self = this;
		HttpRequest.handleRequest({
			operation : 'domainlist',
			//url : self.SERVER_URL + '/newson/service/v2/domainlist?CountryCode='+DeviceInfoModel.get('countryCode'),
			url : 'newson/service/v2/domainlist?CountryCode='+DeviceInfoModel.get('countryCode'),

			type : 'GET',
			/*property : {
				content_type : self.CONTENT_TYPE,
				content_length : self.CONTENT_LENGTH,
				accept : self.ACCEPT,
				host : self.HOST,
				cache_control : self.CACHE_CONTROL,
				accept_encoding : self.ACCEPT_ENCODING,
				token : self.TOKEN,
				smart_tv_client : self.SMART_TV_CLIENT,
				duid : self.DUID,
				country_code : self.COUNTRY_CODE
			},*/
			success : options.success,
			error : options.error
		});
	}
};

exports = SICServerAPI;
