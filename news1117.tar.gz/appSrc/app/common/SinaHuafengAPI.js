/*
* China Server API (News: Sina, Weather: Haufeng)
*/
var _ = Volt.require('modules/underscore.js')._;


var SinaHuafengAPI = {
	sAppKey : '?app_key=1204660113',
    sDomainSina : '',
    sDomainHuafeng : '',


    initialize: function(options) {
		var self = this;
        _.each(options.domainlist, function(domainList) {
            if (domainList.categoryid && domainList.categoryid == '100') { // 100: News
                self.sDomainSina = domainList.apidomain;
            } else if (domainList.categoryid && domainList.categoryid == '200') { // 200: Weather
                self.sDomainHuafeng = domainList.apidomain;
            }
        })
    },

    getMainNewsAPI : function() {
    	return this.sDomainSina + 'main_news' + this.sAppKey;
    },
    
    getMainWeatherAPI : function(options) {
    	var queryString = options.cid ? '?cid='+options.cid : '';
    	return this.sDomainHuafeng + 'getsamsungmainweather' + queryString;
    },
    
    getMoreNewsAPI : function(options) {
    	return options.url + '&page=' + options.page;
    },
    
    getNewsDetailAPI : function(options) {
    	return this.sDomainSina + 'news_details' + this.sAppKey + '&url=' + options.url;
    },

    getWeatherDetailAPI : function(options) {
		var queryString = options.cid ? '?cid=' + options.cid : '';
		print("in sina getWeatherDetailAPI, query is "+queryString);
    	return this.sDomainHuafeng + 'getsamsungdetail' + queryString;
    },
    
    getWeatherCityListAPI : function() {
    	return this.sDomainHuafeng + 'getsamsungcitylist';
    }

}

exports = SinaHuafengAPI;


