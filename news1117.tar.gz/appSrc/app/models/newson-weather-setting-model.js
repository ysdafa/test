/**
 * @author Zhu Hongjie (hj00.zhu@samsung.com)
 * @date 2014/08/25(last modified date)
 * 
 * @copyright Copyright 2014 by Samsung Electronics, Inc.
 * 
 * This software is the confidential and proprietary information of Samsung Electronics, Inc. ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Samsung.
 */

// Include libraries
var Backbone = Volt.require('lib/volt-backbone.js');
var BaseModel = Volt.require('app/models/baseModel.js');

//Include models
var DeviceModel = Volt.require('app/common/deviceModel.js');
var LocalStorage = Volt.require('lib/volt-local-storage.js');

var WeatherSettingModel = Backbone.Model.extend({
    defaults : {
        weatherSettingCodeCityList : ''
    },

    codeArray : [],
    initialize : function() {
        var weatherSettingCodeCityList = '';
        weatherSettingCodeCityList = LocalStorage.getItem('weather-setting-code-city-list');
        Volt.log('[-----------------[' + weatherSettingCodeCityList + ']-------------------]');
        this.set('weatherSettingCodeCityList', weatherSettingCodeCityList);
        this.bind('change:weatherSettingCodeCityList', this.__saveWeatherSettingCodeCityList, this);
        if (weatherSettingCodeCityList === undefined || weatherSettingCodeCityList === '') {
            weatherSettingCodeCityList = '01010101,01011410,01010704,01012601,01010401';
        } else {
            var array = weatherSettingCodeCityList.split(',');
            for(var i = 0; i < array.length; i++){
                var id = parseInt(new Number(array[i]));
                if(isNaN(id)){
                    weatherSettingCodeCityList = '01010101,01011410,01010704,01012601,01010401';
                    break;
                }
            }
        }
        this.set('weatherSettingCodeCityList', weatherSettingCodeCityList);
        Volt.log('[-----------------[' + weatherSettingCodeCityList + ']-------------------]');
    },

    fetch : function() {
        this.parse();
        this.trigger('complete', this.codeArray.length);
    },

    parse : function() {
        var weatherSettingCodeCityList = this.get('weatherSettingCodeCityList');
        Volt.log('[-----------------[' + weatherSettingCodeCityList + ']-------------------]');
        this.codeArray = [];
        if (weatherSettingCodeCityList && weatherSettingCodeCityList.length > 0) {
            this.codeArray = weatherSettingCodeCityList.split(',');
        }
    },
    
    updateCityStatus : function (code){
        var changeStatus = true;
        var length = this.codeArray.length;
        for ( var i = 0; i < length; i++) {
            if (this.codeArray[i] === code) {
                this.codeArray.splice(i, 1);
                changeStatus = false;
                break;
            }
        }
        if (changeStatus) {
            this.codeArray.push(code);
        }
        Volt.log('code - ' + code + ' ' + changeStatus);
    },
    
    getSelectedCityIndex : function(code){
        var length = this.codeArray.length;
        for ( var i = 0; i < length; i++) {
            if (this.codeArray[i] === code) {
                return i;
            }
        }
        return undefined;
    },

    beginListeningChange : function(){
        this.codeArray.reverse();
    },
    
    // to update data to server, update the collection of selected
    updateToServer : function() {
        Volt.log();
        this.codeArray.reverse();
        var weatherSettingCodeCityList = this.codeArray.toString();
        this.set('weatherSettingCodeCityList', weatherSettingCodeCityList);
        // TODO: the above code was test code
        this.trigger('success');
    },

    getSelectedCount : function() {
        return this.codeArray.length;
    },
    
    __saveWeatherSettingCodeCityList : function() {
        if ('CN' == DeviceModel.get('countryCode')) {
            var weatherSettingCodeCityList = this.get('weatherSettingCodeCityList');
            LocalStorage.setItem('weather-setting-code-city-list', weatherSettingCodeCityList);
            Volt.log('[-----------------[' + weatherSettingCodeCityList + ']-------------------]');
        }
    }

});

exports = new WeatherSettingModel();