
var Backbone = Volt.require('lib/volt-backbone.js');
var TileCollection = Volt.require("app/models/tileCollection.js");

var PageModel = Backbone.Model.extend({

        defaults: {
            tile_template_id: '',
            now_utc_timestamp: '',
            tileCollection: null
        },

        initialize: function() {
            this.set('tileCollection', new TileCollection());
        },

        parse: function(response, flag) {
		
			var oResp = response;
			iTileCollection = this.get('tileCollection');
            if(flag) {// need reset the whole tilecollection
                iTileCollection.reset();
            }
			iTileModel = null;
			oPageData = null;

            oResp.tile_template_id = oResp.tile_template_id || 'samsung.template.main.v1';
			if(oResp.tiles && oResp.tiles.length) {
				for(var i = 0; i < oResp.tiles.length; i++) {	
					var tileData = oResp.tiles[i];
					iTileModel = iTileCollection.findWhere({position: tileData.position}) || null;
					
					if (iTileModel) {
						iTileModel.set(iTileModel.parse(tileData, {'now_utc_timestamp':oResp.now_utc_timestamp}));
					} else {
						iTileCollection.addTile(tileData,{'now_utc_timestamp':oResp.now_utc_timestamp});
					}

				}            
			}

            oPageData = {
                tile_template_id: oResp.tile_template_id,
                now_utc_timestamp: oResp.now_utc_timestamp,
                tileCollection: iTileCollection
            };

            return oPageData;
        }

    })

exports = PageModel;