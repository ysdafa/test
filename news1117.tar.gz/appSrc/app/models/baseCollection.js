

var Backbone = Volt.require('lib/volt-backbone.js');
//var CommonInfo = Volt.require("app/common/commonInfo.js");

var BaseCollection = Backbone.Collection.extend({
	currentUrlIndex:-1,
	urlTotal:-1,
	urlList:[],
	path:"",

	initialize : function(options) {

	},

	parse : function(data,staus,response) {

	},
	
	addUrl: function(url) {
		if(null == url)
			return;
		this.urlList[urlTotal] = url;
		this.urlTotal++;
	},
	
	getCurrentUrl : function() {
		
		return this.urlList[this.currentUrlIndex] + this.path;
	},
	
	getCurrentIndex : function() {
		
		return this.currentUrlIndex;
	},
	
	fetchPrev: function(options) {
		if(this.currentUrlIndex <= 0 ){
			this.currentUrlIndex = this.urlTotal -1;		
		}
		else {
			this.currentUrlIndex--;
		}		
			
		this.fetch(options);
	},
	
	fetchNext: function(options) {
		if(this.currentUrlIndex >= (this.urlTotal-1)){
			this.currentUrlIndex = 0;
		}		
		else {
			this.currentUrlIndex++;
		}		
			
		this.fetch(options);
	},
	
	fetchByIndex: function(options) {
		if((options.index >= (this.urlTotal-1)) || (options.index < 0)){
			return;
		}	
		
		this.currentUrlIndex = options.index;			
		this.fetch(options);
	},


	fetch : function(options) {	
		var self = this;		
	
		var url = this.getCurrentUrl(this.currentUrlIndex);
		var network_request = new ResourceRequest({
			async:true,
			uri: url,
			success: function(data,staus,response){	
				if(response.uri != url)
					return;
				self.parse(data,staus,response);
			},
			
			error: function(object, staus, exception) {                
				 self.trigger('error', object, staus, exception);
			},
			
			complete: function(object, staus) {                
				self.trigger('complete',object, staus);
			},
		});
		network_request.process();
	},	
});
exports = BaseCollection;