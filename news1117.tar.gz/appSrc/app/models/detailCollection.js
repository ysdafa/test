
var BaseCollection = Volt.require('app/models/baseCollection.js');
var NewsDetailModel = Volt.require('app/models/newsDetailModel.js');
//var VideoDetailModel = require('file://app/models/VideoDetailModel.js');

var DetailCollection = BaseCollection.extend({	
	tile_type:[],
	initialize : function(options) {
		this.tile_type = options.tile_type;
		this.urlList = options.detail_url;			
		this.urlTotal = this.urlList.length;
		this.currentUrlIndex = options.index;
		this.path = '&appid=com.samsung.panels.tv.ytoday&contextid=samsung.main.2014&man=SEC&model=14_X14_BT&deviceid=SHCJYGR247DHC&swversion=T-MST14DEUC-0721.0&region=AE&language=ar&res=1920x1080&ts=1398135176&format=json';		
	},
	
	getCurrentTileType : function() {
		
		return this.tile_type[this.currentUrlIndex];
	},
	
	parse: function(data,staus,response) {
	
		Volt.log('DetailCollection response.uri' + response.uri);
		Volt.log(data);
		if(String(response.uri).indexOf(this.getCurrentUrl()) == -1)
			return;
		data = JSON.parse(data);

		var  detailModel = createDetailModel(this.tile_type[this.currentUrlIndex]);
		if(detailModel)
		{
			detailModel.set(detailModel.parse(data));			
		}
		else
		{
			Volt.log('detailModel is null!');
			return;
		}
			
		this.reset();			
		this.add(detailModel);
	}	

});

 function createDetailModel(tileType) {

	var iDetailModel = null;

	switch(tileType) {
		case 'news':
			iDetailModel = new NewsDetailModel();
			break;
		case 'video':
			//iDetailModel = new VideoDetailModel();
			break;
		case 'branding':
			//iDetailModel = new BrandingTileModel();
			break;    
		default:
			iDetailModel = new NewsDetailModel();
			break;
	}

	return iDetailModel;
};

exports = DetailCollection;