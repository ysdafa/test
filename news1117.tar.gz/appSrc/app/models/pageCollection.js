var Backbone = Volt.require('lib/volt-backbone.js');
var PageModel = Volt.require("app/models/pageModel.js");
var PageCollection = Backbone.Collection.extend({

	model: PageModel

});

exports = PageCollection;
