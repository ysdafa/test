

var Backbone = Volt.require('lib/volt-backbone.js');
    var VideoTileModel = Backbone.Model.extend({

        defaults: {
            tile_type: 'video',
            position: '1',
            id: '',
            source: '',
            title: '',
            timestamp: 0,
            img_url: '',
            brand_img_url: '',
            formats: [
                // {
                //     "url": "http://stage.api.digitalhomeservices.yahoo.com/V0_3/video_redirect_uuid?bitrate=221&uuid=26a4dd5b-cdbe-3610-b92b-5edf03859fb2",
                //     "tech": "mp4",
                //     "bitrate": "221",
                //     "duration": "162"
                // }
            ]
        },

        parse: function(videoTileData) {
           
            var oVideoTileData = {
                tile_type: videoTileData.tile.tile_type,
                position: videoTileData.tile.position,
                id: videoTileData.tile.id,
                source: videoTileData.tile.source,
                title: videoTileData.tile.title,
                timestamp: videoTileData.tile.timestamp,
                img_url: videoTileData.tile.img_url,
                brand_img_url: videoTileData.tile.brand_img_url,
                stringstamp: '',
                detailstringstamp: '',
                now_utc_timestamp: videoTileData.now_utc_timestamp,
                formats: videoTileData.tile.formats || []
            };


            if (oVideoTileData.timestamp != 0) {
                
                var temp = ((oVideoTileData.now_utc_timestamp - oVideoTileData.timestamp)/3600),
                    day = Math.floor(temp/24),
                    hour = Math.floor(temp),
                    minute = Math.floor((temp-hour)*60),
                    sec = Math.floor((temp-hour-(minute/60))*3600);

                if(hour == 0 & minute < 1){
                    oVideoTileData.stringstamp = COM_SID_JUST_NOW;
                    oVideoTileData.detailstringstamp = COM_SID_JUST_NOW;
                } else if(hour == 0 & minute == 1){
                    oVideoTileData.stringstamp = COM_MIS_MESSAGE_BEFORE_MIN_P.replace('<<A>>', minute);
                    oVideoTileData.detailstringstamp = TV_SID_MIX_MINUTE_AGO.replace('<<A>>', minute);
                } else if(hour == 0 & minute > 1){
                    oVideoTileData.stringstamp = COM_SID_MIX_MINS_AGO.replace('<<A>>', minute);
                    oVideoTileData.detailstringstamp = SID_MIX_MINUTES_AGO.replace('<<A>>', minute);
                } else if(hour == 1){
                    oVideoTileData.stringstamp = COM_SID_1_HR_AGO;
                    oVideoTileData.detailstringstamp = TV_SID_MIX_HOUR_AGO.replace('<<A>>', hour);
                } else if(hour > 1 && day < 1){
                    oVideoTileData.stringstamp = COM_SID_MIX_HRS_AGO.replace('<<A>>', hour);
                    oVideoTileData.detailstringstamp = SID_MIX_HOURS_AGO.replace('<<A>>', hour);
                } else if(day == 1 || day > 1){
                    oVideoTileData.stringstamp = COM_SID_MIX_D_AGO.replace('<<A>>', day);
                    oVideoTileData.detailstringstamp = TV_SID_MIX_DAY_AGO.replace('<<A>>', day);
                }
            
            }


            return oVideoTileData;
        }
    });

})