
var BaseModel = Volt.require('app/models/baseModel.js');
var PageModel = Volt.require('app/models/pageModel.js');
var PageCollection = Volt.require('app/models/pageCollection.js');
var CPAPI = Volt.require('app/common/CPAPI.js');
var localStorage = Volt.require("lib/volt-local-storage.js");
var PanelCommon = Volt.require('lib/panel-common.js');
var Q = PanelCommon.Q;
var MoreNewsModel = BaseModel.extend({

	defaults: {
		attributes: {
			status: 0,
			error_msg: ''
		},
		brand_img_url: '',
		now_utc_timestamp:'',
		pageCollection: null,
		tos_text: '',
		//more_news_url:'',
		tilePos: 0,
		pageIdx: 0,
        number_of_page : 0,
		positionLeft: 0
	},

	initialize: function(options) {
		//this.set('more_news_url',options.more_news_url);
		//if(options == null)
			//return;
		//this.set('pageIdx', options.pageIdx);
		//this.set('pageCollection', new PageCollection());
		
		//var page = '&page='+(options.pageIdx + 1);		
        //getQueryString();
        //this.url = options.more_news_url + page +'&' + serverInfo.getQueryString();
		//this.url = options.more_news_url + page + '&appid=com.samsung.panels.tv.ytoday&contextid=samsung.main.2014&man=SEC&model=14_X14_BT&deviceid=SHCJYGR247DHC&swversion=T-MST14DEUC-0721.0&region=AE&language=ar&res=1920x1080&ts=1398135176&format=json';
	},	
	offline : function()
    {
        var deferred = Q.defer();
        if(!this.get('pageCollection'))
			this.set('pageCollection', new PageCollection());
        var caching02 = localStorage.getItem('morenews'+'1');
        if(CPAPI.getServiceType() === 'sina_huafeng')
        {
            var caching01 = localStorage.getItem('morenews'+'0');
            if (caching01 && caching02&& caching01.length > 0 && caching02.length > 0) {
                print('cache more view');
                this.parse(caching01,'offline');
                this.parse(caching02,'offline');
                deferred.resolve();
            }
            else
            {
                deferred.reject();
            }
        }else
        {
            if(caching02 && caching02.length > 0)
            {
                this.parse(caching02,'offline');
                print('cache more view');
                deferred.resolve();
            }else
            {
               deferred.reject(); 
            }
        }
        return deferred.promise; 
    },
	setInitData: function(options){
		if(options == null)
			return;
		this.set('pageIdx', options.pageIdx);
		if(!this.get('pageCollection'))
			this.set('pageCollection', new PageCollection());
		//var page = '&page='+(options.pageIdx + 1);	
        this.url = CPAPI.getMoreNewsAPI({
            url : options.more_news_url,
            page : options.pageIdx + 1
        });
	},
	
	
	parse: function(data,staus,response)
	{
		if(response !== undefined)
            Volt.log('response.uri' + response.uri);
		if(response !== undefined && String(response.uri).indexOf(this.url) == -1)
			return;
        if(staus !== 'offline')
            localStorage.setItem('morenews'+this.get('pageIdx'), data);
		data = JSON.parse(data);
		data.tile_template_id = data.tile_template_id || 'samsung.template.more.v1';
		
		var iPageCollection = this.get('pageCollection'),
			iPageModel = new PageModel();
        if(this.get('pageIdx') === 0 && CPAPI.getServiceType() === 'sina_huafeng')
            iPageCollection.reset();
        else if(CPAPI.getServiceType() !== 'sina_huafeng')
            iPageCollection.reset();
		this.set('attributes', data.attributes);
		this.set('brand_img_url', data.brand_img_url);

		iPageModel.set(iPageModel.parse(data));
		
		iPageCollection.add(iPageModel);
	},

});

exports = new MoreNewsModel();
