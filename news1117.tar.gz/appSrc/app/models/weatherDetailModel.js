/**
* @author xyz
*/

var Backbone = Volt.require('lib/volt-backbone.js');
var BaseModel = Volt.require('app/models/baseModel.js');
var WeatherDetailCityModel = Volt.require('app/models/weatherDetailCityModel.js');
var CPAPI = Volt.require('app/common/CPAPI.js');
var WeatherSettingModel = Volt.require('app/models/newson-weather-setting-model.js');

var WeatherDetailModel = BaseModel.extend({
	
	defaults: {	
		cityIdx: 0,
		//detail_url:'',
		
		attributes: {
			status: 1,
			error_msg: ''
		},
		source: '',
		source_icon: '',
		brand_img_url: '',
		high_temp_icon: '',
		low_temp_icon: '',
		now_utc_timestamp: '',

		weatherDetailCityCollection: null
	},

	initialize: function(options) {
		//this.set('cityIdx',0);
		//this.set('detail_url',options.detail_url);
		this.set('weatherDetailCityCollection', new Backbone.Collection([], {
			model: WeatherDetailCityModel
		}));
		//var tempurl = 'https:\/\/api.digitalhomeservices.yahoo.com\/V0_3\/GetWeatherDetails';
		
		//this.url  = tempurl+'?appid=com.samsung.panels.tv.ytoday&contextid=samsung.main.2014&man=SEC&model=14_X14_BT&deviceid=SHCJYGR247DHC&swversion=T-MST14DEUC-0721.0&region=BR&language=pt&res=1920x1080&ts=1398135176&format=json';
		Volt.log('[weather-model.js] initialize.render');
	},
	
	setInitData : function(cidFromSearch) {
	    if (undefined == cidFromSearch || '' == cidFromSearch) {
            Volt.log('set weather detail url normally');
            var citylist = WeatherSettingModel.get('weatherSettingCodeCityList');
            this.url = CPAPI.getWeatherDetailAPI({cid:citylist});
        } else {
            Volt.log('set weather detail url from search');
            this.url = CPAPI.getWeatherDetailAPI({cid:cidFromSearch});
            if (CPAPI.getServiceType() != 'sina_huafeng'){
                this.url = '';
            }
        }
	},
	

	parse: function(data,staus,response) {	
		//Volt.log(data);
		Volt.log('WeatherDetailModel response.uri' + response.uri);
		if(String(response.uri).indexOf(this.url) == -1)
			return;
		data = JSON.parse(data);	
					
		var iWeatherDetailCityCollection = this.get('weatherDetailCityCollection');
		iWeatherDetailCityCollection.reset();
		this.set('attributes', data.attributes);
		this.set('source', data.source);
		this.set('source_icon', data.source_icon);
		this.set('brand_img_url', data.brand_img_url);
		this.set('high_temp_icon', data.high_temp_icon);
		this.set('low_temp_icon', data.low_temp_icon);
		this.set('now_utc_timestamp', data.now_utc_timestamp);
									  
		iWeatherDetailCityCollection.add(data.detail_weather_cities);
		
		//return oWeatherDetailData;
	}

})


exports = new WeatherDetailModel();
