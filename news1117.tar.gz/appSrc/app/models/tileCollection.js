
var Backbone = Volt.require('lib/volt-backbone.js');
var WeatherTileModel = Volt.require('app/models/weatherTileModel.js');
var NewsTileModel = Volt.require('app/models/newsTileModel.js');

    var TileCollection = Backbone.Collection.extend({

        addTile: function(tileData,options) {

            tileData.position = String(tileData.position);

            var  iTileModel = createTileModel(tileData.tile_type);
			if(iTileModel)
			{
				iTileModel.set(iTileModel.parse(tileData,options));			
			}
			else
			{
				Volt.log('iTileModel is null!');
				return;
			}

            this.add(iTileModel);
        }
		


    });

	function createTileModel(tileType) {

			var iTileModel = null;

			switch(tileType) {
			    case 'news':
                iTileModel = new NewsTileModel();
					break;
				case 'weather':
					iTileModel = new WeatherTileModel();
					break;  
				default:
				   iTileModel = null;//new NewsTileModel();
					break;
			}

			return iTileModel;
		}


	
	exports = TileCollection;