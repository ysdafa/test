
var Backbone = Volt.require('lib/volt-backbone.js');

var WeatherDetailCityModel = Backbone.Model.extend({

	defaults: {
		id: '',
		location: '',
		background_image: '',
		temp_scale: 'C',
		local_time: '',
		current_conditions: '',
		current_condition_icon: '',
		current_temp: '',
		today_high_temp: '',
		today_low_temp: '',
		weather_features: [],
		forecasts: [],
		photo_attribution: '',
		brand_img_url: '',
		count: 0
	}

});

exports = WeatherDetailCityModel;