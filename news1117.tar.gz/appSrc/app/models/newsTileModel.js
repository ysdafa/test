
var Backbone = Volt.require('lib/volt-backbone.js');
    var NewsTileModel = Backbone.Model.extend({

        defaults: {
            tile_type: "news",
            position: 0,
            id: '',
            source: '',
            title: '',
            timestamp: 0,
            img_url: '',
            detail_url: '',
            image_aspect_ratio: '',
            now_utc_timestamp: '',
            stringstamp: '',
            blank: false
        },

        parse: function(newsTileData, options) {
            var oNewsTileData = {
                tile_type: newsTileData.tile_type,
                position: newsTileData.position,
                id: newsTileData.id,
                source: newsTileData.source,
                title: newsTileData.title,
                timestamp: newsTileData.timestamp,
                img_url: newsTileData.img_url,
                detail_url: newsTileData.detail_url,
                image_aspect_ratio: newsTileData.image_aspect_ratio,
                now_utc_timestamp: newsTileData.now_utc_timestamp,
                stringstamp:'',
                blank: (newsTileData.blank !== undefined) ? newsTileData.blank : false
            };
			
			var temp = Math.floor((parseInt(options.now_utc_timestamp) - parseInt(oNewsTileData.timestamp)));
			var status = '';
			if(temp >= 0 && temp <= 59)
			{
				status = 'Just Now';
			}else if(temp >= 60 && temp <= 119)
			{
				status = '1 min ago';
			}else if(temp >= 120 && temp <= 3600 - 1)
			{
				status = (Math.floor(temp/60))+ ' mins ago'
			}else if(temp >= 3600 && temp <= 7200 - 1)
			{
				status = '1 hr ago';
			}else if(temp >= 3600 && temp <= 3600*24 - 1)
			{
				status = (Math.floor(temp/3600))+ ' hrs ago'
			}else if(temp >= 3600*24 && temp <= 3600*48 - 1)
			{
				status = '1d ago'
			}
            else
			{
				status = (Math.floor(temp/(3600*24)))+ 'd ago'
			}
			oNewsTileData.stringstamp = status;
            return oNewsTileData;
        }
    })
	
	exports = NewsTileModel;
	