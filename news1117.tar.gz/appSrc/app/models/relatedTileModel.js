var Backbone = Volt.require('lib/volt-backbone.js');
var RelatedTileModel = Backbone.Model.extend({
    defaults: {
            tile_type: "news",
            id: '',
            source: '',
            title: '',
            timestamp: '',
            img_url: '',
            detail_url: '',
            image_aspect_ratio: '',
    },
});

exports = RelatedTileModel;