/**
 * @author Zhu Hongjie (hj00.zhu@samsung.com)
 * @date 2014/8/25(last modified date)
 * 
 * @copyright Copyright 2014 by Samsung Electronics, Inc.
 * 
 * This software is the confidential and proprietary information of Samsung Electronics, Inc. ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Samsung.
 */

// Include libraries
var Backbone = Volt.require('lib/volt-backbone.js');
var BaseModel = Volt.require('app/models/baseModel.js');
var _ = Volt.require('modules/underscore.js')._;
var DeviceModel = Volt.require('app/common/deviceModel.js');

var CPAPI = Volt.require('app/common/CPAPI.js');
var WeatherSettingModel = Volt.require('app/models/newson-weather-setting-model.js');
var WeatherCityListModel = BaseModel.extend({
    defaults : {
        attributes : {
            status : 1,
            error_msg : ''
        },
        country_code : '',
        provinceCollection : undefined
    },

    initialize : function() {
        var provinceCollection = new Backbone.Collection([], {
            model : ProvinceModel
        });
        provinceCollection.comparator = 'index';
        this.set('provinceCollection', provinceCollection);
    },

    setInitData : function() {
        this.url = CPAPI.getWeatherCityListAPI();
    },

    parse : function(data, status, response) {
        Volt.log();
        if (String(response.uri).indexOf(this.url) == -1)
            return;
        var iResp = JSON.parse(data);
        var provinceCollection = this.get('provinceCollection');
        if (-1 == DeviceModel.getNetWorkState()) {
            iResp.attributes = {
                status : 0,
                error_msg : 'Server error.'
            };
        }

        if (iResp.attributes.status == 1) {
            provinceCollection.reset();
            _.each(iResp.cities, function(city) {
                if(city.eng_name == 'taibei' || city.eng_name == 'gaoxiong') {
                    // do nothing
                } else {
                    var index = WeatherSettingModel.getSelectedCityIndex(city.code);
                    var provinceModel = provinceCollection.findWhere({
                        province : city.province
                    });
                    if (!provinceModel) {
                        provinceModel = new ProvinceModel();
                        provinceCollection.add(provinceModel);
                    }

                    provinceModel.parse(city, index);
                }
            });
            provinceCollection.sort();
            Volt.log();
        } else {
            Volt.log();
            this.trigger('error', iResp.attributes.error_msg);
        }
    }

});

var ProvinceModel = Backbone.Model.extend({

    defaults : {
        province : '',
        cityCollection : undefined,
        index : undefined
    },

    initialize : function() {
        var cityCollection = new Backbone.Collection([], {
            model : CityModel
        });
        cityCollection.comparator = 'index';
        this.set('cityCollection', cityCollection);
    },

    parse : function(city, index) {
        var cityCollection = this.get('cityCollection');
        var iIndex = this.get('index');
        if (iIndex === undefined && index !== undefined) {
            this.set('index', index);
        }
        this.set('province', city.province);
        var cityModel = new CityModel();
        cityModel.parse(city, index);
        cityCollection.add(cityModel);
    }

});

var CityModel = Backbone.Model.extend({
    defaults : {
        code : '',
        name : '',
        eng_name : '',
        index : undefined
    },

    parse : function(city, index) {
        var oData = {
            code : city.code,
            name : city.name,
            eng_name : city.eng_name,
            index : index
        };
        this.set(oData);
    }

});

exports = new WeatherCityListModel();