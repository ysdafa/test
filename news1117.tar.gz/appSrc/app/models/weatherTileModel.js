

var Backbone = Volt.require('lib/volt-backbone.js');
var WeatherTileCityModel = Volt.require('app/models/weatherTileCityModel.js');

    var WeatherTileModel = Backbone.Model.extend({

        defaults: {
            tile_type: 'weather',
            position: '3',
            source: '',
            high_temp_icon: '',
            low_temp_icon: '',
            cycle_seconds: 10,
            detail_url : '',
            weatherTileCityCollection: null,

            cityIdx: 0,
            blank: false
        },

        initialize: function() {
            this.set('weatherTileCityCollection', new Backbone.Collection([], {
                model: WeatherTileCityModel
            }));
        },

        parse: function(weatherTileData) {
            Volt.log('WeatherTileCityModel parse');
            var iWeatherTileCityCollection = this.get('weatherTileCityCollection'),
                oWeatherTileData = {
                    tile_type: weatherTileData.tile_type,
                    position: weatherTileData.position,
                    source: weatherTileData.source,
                    high_temp_icon: weatherTileData.high_temp_icon,
                    low_temp_icon: weatherTileData.low_temp_icon,
                    cycle_seconds: weatherTileData.cycle_seconds,
                    detail_url: weatherTileData.detail_url,
                    weatherTileCityCollection: iWeatherTileCityCollection,

                    cityIdx: 0,
                    blank: (weatherTileData.blank !== undefined) ? weatherTileData.blank : false
                };

            iWeatherTileCityCollection.set(weatherTileData.weather_cities);

            return oWeatherTileData;
        }

    })
	
	exports = WeatherTileModel;


