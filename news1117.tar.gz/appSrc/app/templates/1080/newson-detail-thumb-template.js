var DetailTemplate = {
    container : {
        type : 'widget',
        x : 0,
        y : 0,
        width : 1596, // 1920 * 0.83125
        height : 371, // 1080 * 0.343519
        color : Volt.hexToRgb('#000000', 0),
        children : [{
            type : 'image',
            x : 0,
            y : 0,
            width : 659,//1920 * 0.343229
            height : 371,// 1080 * 0.343519
            src : Volt.getRemoteUrl('images/1080/icon/icon_blank_thumbnail.png'),
            fillMode : 'center',
            color : Volt.hexToRgb('#d4d4d4', 100),
            children : [{
                type : 'widget',
                x : 658, //1920 * 0.343229 -1
                y : 0,
                width : 1,
                height : 371,// 1080 * 0.343519
                color : Volt.hexToRgb('#c9c9c9', 100)
            }, {
                type : 'widget',
                x : 0,
                y : 370, // 1080 * 0.343519 - 1
                width : 659, //1920 * 0.343229
                height : 1,
                color : Volt.hexToRgb('#c9c9c9', 100)
            },{
				id : 'thumb_thumbnail',
			    type: 'Thumbnail',
				visibleStyles: (0x01 | 0x20),
				x : 0,
				y : 0,
				image:{src: '{{ source_icon }}',
				width: 659,
				height: 371}
			}
			
			/*{
                id : 'thumb_thumbnail',
                type : 'ImageWidgetEx',
                cropMode : "cropCenter",
                async : true,
                x : 0,
                y : 0,
                width : 659,//1920 * 0.343229
                height : 371,// 1080 * 0.343519
                src : '{{source_icon}}'
            }*/]
        },

        {
            type : 'widget',
            x : 659,//1920 * 0.343229
            y : 0,
            width : 937, //1920 * (0.83125 - 0.343229)
            height : 371, // 1080 * 0.343519
            color : Volt.hexToRgb('#111111', 0),
            id : 'thumb_title_info',
            children : [{
                type : 'text',
                x : 30, // 1920 * 0.015625
                y : 40, // 1080 * 0.037037
                width : 877, //1920 * (0.83125 - 0.343229 - 0.015625 - 0.015625)
                height : 204,// 1080 * 0.062963 * 3
                color : Volt.hexToRgb('#000000', 0),
                id : 'thumb_headline',
                ellipsize : true,
                text : '{{ headline }}',
                font : 'SVD Light 56px'
            }, {
                id : 'thumb_source_icon',
                type : 'image',
                async : true,
                x : 30, // 1920 * 0.015625
                y : 282, // 1080 * (0.343519 - 0.026852 - 0.009259 - 0.027778 - 0.018519)
//                        width : 29 * 3,
//                        height : 29, // 1080 * 0.026852
                src : '{{source_icon}}'
            }, {
                id : 'thumb_source_container',
                type : 'widget',
                x : 30, // 1920 * 0.015625
                y : 321,// 1080 * (0.343519 - 0.027778 - 0.018519)
                width : 877, //1920 * (0.83125 - 0.343229 - 0.015625 - 0.015625)
                height : 30, // 1080 * 0.027778
                color : Volt.hexToRgb('#000000', 0),
                children : [{
                    id : 'thumb_source',
                    type : 'text',
                    x : 0,
                    y : 0,
                    height : 30,
                    font : 'SVD Light 26px',
                    verticalAlignment : 'center',
                    horizontalAlignment : 'left',
                    singleLineMode : true,
                    text : '{{source}}'
                },

                {
                    id : 'thumb_press_time',
                    type : 'text',
                    font : 'SVD Light 26px',
                    verticalAlignment : 'center',
                    horizontalAlignment : 'left',
                    x : 0,
                    y : 0,
                    height : 30,
                    singleLineMode : true,
                    src : '{{press_time}}'
                },

                {
                    id : 'thumb_timestamp',
                    type : 'text',
                    font : 'SVD Light 26px',
                    verticalAlignment : 'center',
                    horizontalAlignment : 'left',
                    x : 0,
                    y : 0,
                    height : 30,
                    singleLineMode : true,
                    src : '{{timestamp}}'
                },

                {
                    id : 'thumb_color_drawing01',
                    type : 'widget',
                    x : 0,
                    y : 3,//1080 * 0.002778
                    height : 24,//1080 * 0.022222
                    width : 3,//1920 * 0.001563
                    color : Volt.hexToRgb('#FFFFFF', 60)
                },

                {
                    id : 'thumb_color_drawing02',
                    type : 'widget',
                    x : 0,
                    y : 3,//1080 * 0.002778
                    height : 24,//1080 * 0.022222
                    width : 3,//1920 * 0.001563
                    color : Volt.hexToRgb('#FFFFFF', 60)
                }]
            }]
        }]
    }
};

exports = DetailTemplate;