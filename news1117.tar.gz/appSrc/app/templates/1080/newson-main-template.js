var NewsonMainTemplate = {
    header : {
        type : 'widget',
        x : 0,
        y : 0,
        width : 1920,
        height : 144, //1080 * 0.133333
        color : Volt.hexToRgb('#0f1826'),
        children : [{
            type : 'text',
            x : 36, // 1920 * 0.018750
            y : 0,
            height : 144, //1080 * 0.133333
            verticalAlignment : 'center',
            textColor : Volt.hexToRgb('#ffffff'),
            opacity : 102,
            text : Volt.LANG.NEWSON_MAIN_TITLE,
            font : '50px'
        }, {
            id : 'main-header-tools',
            type : 'widget',
            x : 1820, //1920 * (1 - 1 * 0.052083)
            y : 0,
            width : 200,// 1920 * 0.052083 * 2
            height : 144,//1080 * 0.133333
            color : Volt.hexToRgb('#0f1826'),
            children : [{
                id : 'main-header-icon-setting',
                type : 'widget',
                x : 0,
                y : 0,
                width : 101, // 1920 * 0.052604
                height : 144, //1080 * 0.133333
                color : Volt.hexToRgb('#0f1826'),
                custom : {
                    'focusable' : true
                },
                children : [{
                    type : 'widget',
                    width : 1,
                    height : 144,//1080 * 0.133333
                    color : Volt.hexToRgb('#ffffff'),
                    opacity : 25 //255 * 0.1
                },/* {
                    type : 'image',
                    x : 32, // (1920 * 0.052604 - 36)/2
                    y : 54, // (1080 * 0.133333 - 36)/2
                    width : 36,
                    height : 36,
                    opacity : 0,
                    src : Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_sel.png')
                }, {
                    type : 'image',
                    x : 32, // (1920 * 0.052604 - 36)/2
                    y : 54, // (1080 * 0.133333 - 36)/2
                    width : 36,
                    height : 36,
                    opacity : 255,
                    src : Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_nor.png')
                }*/
                {
                    type : 'Button',
                    x : 0, 
                    y : 0, 
                    width : 101, // 1920 * 0.052604
                    height : 144,//1080 * 0.133333
                    backgroundImage: {
                        x: 32,// (1920 * 0.052604 - 36)/2
                        y: 54,// (1080 * 0.133333 - 36)/2
                        width: 36,
                        height: 36,
                        src: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_nor.png'),
                    }
                }    
                ]
            }, {
                id : 'main-header-icon-close',
                type : 'widget',
                x : 100, // 1920 * 0.052083
                y : 0,
                width : 101, // 1920 * 0.052604
                height : 144, //1080 * 0.133333
                color : Volt.hexToRgb('#0f1826'),
                custom : {
                    'focusable' : false
                },
                children : [{
                    type : 'widget',
                    width : 1,
                    height : 144,//1080 * 0.133333
                    color : Volt.hexToRgb('#ffffff'),
                    opacity : 25 //255 * 0.1
                },/* {
                    type : 'image',
                    x : 32, // (1920 * 0.052604 - 36)/2
                    y : 54, // (1080 * 0.133333 - 36)/2
                    width : 36,
                    height : 36,
                    opacity : 0,
                    src : Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_close_sel.png')
                }, {
                    type : 'image',
                    x : 32, // (1920 * 0.052604 - 36)/2
                    y : 54, // (1080 * 0.133333 - 36)/2
                    width : 36,
                    height : 36,
                    opacity : 255,
                    src : Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_close_nor.png')
                }*/
                {
                    type : 'Button',
                    x : 0, 
                    y : 0, 
                    width : 101, // 1920 * 0.052604
                    height : 144,//1080 * 0.133333
                    backgroundImage: {
                        x: 32,// (1920 * 0.052604 - 36)/2
                        y: 54,// (1080 * 0.133333 - 36)/2
                        width: 36,
                        height: 36,
                        src: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_close_nor.png'),
                    }
                }
                ]
            }]
        }]
    },

    category : {
        type : 'widget',
        x : 0,
        y : 0,
        width : 1920,
        height : 72, // 1080 * 0.066667
        color : Volt.hexToRgb('#f2f2f2'),
        children : [{
            type : 'text',
            x : 0,
            y : 52, //1080 * (0.066667 - 0.018519) 
            width : 1885,//1920 - 1920 * 0.018229
            height : 20,//1080 * 0.018519
            font : "SVD Medium 13px",
            id : 'properity',
            text : '{{properity}}',
            horizontalAlignment : 'right',
            textColor : Volt.hexToRgb('#000000', 30)
        }, {
            type : 'image',
            x : 1774, //1920 - 1920 * 0.018229 - 111
            y : 15, // 1080 * 0.013889
            width : 111,
            height : 34,
            //color:{a:255,r:255,g:255,b:255},
            id : 'cpLogo',
            src : '{{cpLogo}}'
        }/*, {
            id : 'cplist',
            type : 'CpList',
            height : 72,// 1080 * 0.066667
            itemWidth : 300,
            span : 5,
            custom : {
                'focusable' : false
            }
        }*/]
    },

    content : {
        type : 'GridListControl',
        x : 0,
        y : 0,
        width : 1920,
        height : 864, //1080 * 0.8
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : 0,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0,
        custom : {
            'focusable' : true
        },
        color : {
            r : 0,
            g : 111,
            b : 0,
            a : 0
        }
    },

    optionMenuForChina : {
        type : 'OptionMenu',
        x : 1485,// 1920 - 435
        y : 144, // 1080 * 0.133333
        width : 435,
        renderNum : 1,
        loop : false,
        text : [Volt.i18n.t('TV_SID_WEATHER_SETTINGS')],
        custom : {
            'focusable' : true
        }
    },

    containerMap : {
        news_thumbnail1 : {
            width : 648, // 1920 * 0.337500 
            height : 540, // 1080 * 0.500000
            imageHeight : 412,
            infoHeight : 128,
            title : {
                x : 20, // 1920 * 0.010417
                y : 16, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 - 1080 * 0.001852)/2
                width : 608,// 1920 * (0.337500 - 2 * 0.010417)
                height : 64, // 1920 * 0.016667 * 2
                font : 'SVD Light 26px'
            },
            time : {
                x : 20,// 1920 * 0.010417
                y : 82, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 + 1080 * 0.001852)/2 + 64
                width : 608,// 1920 * (0.337500 - 2 * 0.010417)
                height : 30, // 1920 * 0.015625
                font : 'SVD Medium 20px'
            },
            cp_icon : {
                x : 589, // 1920 * (0.337500 - 0.010417) - 39
                y : 82, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 + 1080 * 0.001852)/2 + 64
                width : 39,
                height : 30,
                opacity : 102
            // 255 * 0.4
            }
        },
        news_thumbnail2 : {
            width : 324, //1920 * 0.168750
            height : 324, // 1080 * 0.300000
            imageHeight : 196,
            infoHeight : 128,
            title : {
                x : 20, // 1920 * 0.010417
                y : 16, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 - 1080 * 0.001852)/2
                width : 284,// 1920 * (0.168750 - 2 * 0.010417)
                height : 64, // 1920 * 0.016667 * 2
                font : 'SVD Light 26px'
            },
            time : {
                x : 20,// 1920 * 0.010417
                y : 82, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 + 1080 * 0.001852)/2 + 64
                width : 284,// 1920 * (0.168750 - 2 * 0.010417)
                height : 30, // 1920 * 0.015625
                font : 'SVD Medium 20px'
            },
            cp_icon : {
                x : 265, // 1920 * (0.168750 - 0.010417) - 39
                y : 82, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 + 1080 * 0.001852)/2 + 64
                width : 39,
                height : 30,
                opacity : 102
            // 255 * 0.4
            }
        },
        news_thumbnail3 : {
            width : 324, // 1920 * 0.168750
            height : 432, // 1080 * 0.400000
            imageHeight : 304,
            infoHeight : 128,
            title : {
                x : 20, // 1920 * 0.010417
                y : 16, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 - 1080 * 0.001852)/2
                width : 284,// 1920 * (0.168750 - 2 * 0.010417)
                height : 64, // 1920 * 0.016667 * 2
                font : 'SVD Light 26px'
            },
            time : {
                x : 20,// 1920 * 0.010417
                y : 82, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 + 1080 * 0.001852)/2 + 64
                width : 284,// 1920 * (0.168750 - 2 * 0.010417)
                height : 30, // 1920 * 0.015625
                font : 'SVD Medium 20px'
            },
            cp_icon : {
                x : 265, // 1920 * (0.168750 - 0.010417) - 39
                y : 82, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 + 1080 * 0.001852)/2 + 64
                width : 39,
                height : 30,
                opacity : 102
            // 255 * 0.4
            }
        },
        weather_thumbnail : {
            width : 648, // 1920 * 0.337500 
            height : 540, // 1080 * 0.500000
            imageHeight : 412,
            infoHeight : 128,
            weather_icon : {
                x : 20, //1920 * 0.010417
                y : 23, //1080 * 0.021296
                width : 83,
                height : 83
            },
            icon_h : {
                x : 423,// 1920 * 0.337500 - 1920 * 0.010417 - 110 - 1920 * 0.010417 - 50 - 1920 * 0.003125 - 19
                y : 22, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2
                width : 19,
                height : 41
            },
            icon_l : {
                x : 423,// 1920 * 0.337500 - 1920 * 0.010417 - 110 - 1920 * 0.010417 - 50 - 1920 * 0.003125 - 19
                y : 65, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2 + 1080 * 0.037963 + 1080 * 0.001852  
                width : 19,
                height : 41
            },
            location : {
                x : 115,//1920 * 0.010417 + 83 + 1920 * 0.00625
                y : 22, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2
                width : 300, //1920 * 0.156250
                height : 41,//1080 * 0.037963
                opacity : 153, // 255 * 0.6
                font : "SVD Light 26px"
            },
            conditions : {
                x : 115,//1920 * 0.010417 + 83 + 1920 * 0.00625
                y : 65, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2 + 1080 * 0.037963 + 1080 * 0.001852  
                width : 300, //1920 * 0.156250
                height : 41,//1080 * 0.037963
                opacity : 153, // 255 * 0.6
                font : "SVD Light 40px"
            },
            highTemperature : {
                x : 448,// 1920 * 0.337500 - 1920 * 0.010417 - 110 - 1920 * 0.010417 - 50
                y : 22, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2
                width : 50, //special value
                height : 41,//1080*0.037963
                opacity : 153, // 255 * 0.6
                font : "SVD Light 30px"
            },
            lowTemperature : {
                x : 448,// 1920 * 0.337500 - 1920 * 0.010417 - 110 - 1920 * 0.010417 - 50
                y : 65, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2 + 1080 * 0.037963 + 1080 * 0.001852  
                width : 50, //special value
                height : 41,//1080*0.037963
                opacity : 153, // 255 * 0.6
                font : "SVD Light 30px"
            },
            temperature : {
                x : 518, // 1920 * 0.337500 - 1920 * 0.010417 - 110
                y : 22, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2
                width : 110, //special value
                height : 84,// 1080 * 0.077778
                opacity : 153, // 255 * 0.6
                font : "SVD Light 70px"
            },
            photoAttribute : {
                x : 338,// 1920 * 0.337500 - 1920 * 0.005208 - 300
                y : 108, //128 - 1080 * 0.018519
                width : 300,//special value
                height : 20,//1080 * 0.018519
                font : "SVD Light 13px"
            },
            cp_icon : {
                x : 606, // 1920 * 0.337500 - 42
                y : 370, // 412 - 42
                width : 42,
                height : 42
            }
        }
    },

    constNum : {
        iconBgBlurWidth : 1,
        iconBgFocusWidth : 101,
        showCloseToolX: 1720, // 1920 * (1 - 2 * 0.052083)
        hideCloseToolX : 1820, //1920 * (1 - 1 * 0.052083)
        showCloseOptionMenuX : 1384, // 1920 - 1920 * 0.052604 - 435
        hideCloseOptionMenuX : 1485// 1920 - 435
    //1920 * 0.052604
    }

};

exports = NewsonMainTemplate;
