var CommonTemplate = Volt.require('app/templates/1080/newson-common-template.js');
var ScreenTemplate = Volt.require('app/templates/1080/newson-screen-template.js');

var CurTemplate = {
    title : {
        height : 144,// 1080 * 0.1333
        text : {
            x : 40, // 1920 * 0.02083
            y : 46, // 1080 * 0.042593
            width : 1814, // 1920 * 0.944792
            height : 65
        //1080 * 0.050000
        },
        button : {
            x : 40, // (1920 * 0.075000 - 64)/2
            y : 40, // (1080 * 0.133333 - 64)/2
            width : 64,
            height : 64
        }
    },

    container : {
        height : 936,// 1080 * (1-0.1333)
        tip : {
            x : 66, // 1920 * 0.034375
            y : 40, // 1080 * (0.042593 + 0.050000 + 0.077778) - 1080 * 0.1333
            width : 1788,// 1920 * 0.931250
            height : 230, //1080 * (0.035185 * 2 + 0.109259 + 0.031481)
            tip1And2 : {
                height : 38, //1080 * 0.035185
            },
            tip3 : {
                y : 194, //1080 * (0.035185 * 2 + 0.109259)
                height : 34, // 1080 * 0.031481
            }
        },
        province : {
            y : 286, // 1080 * (0.398148 - 0.1333) 
            width : 1760, //1920 * 0.183333 * 5
            height : 74, // 1080 * 0.068519
            list : {
                x : 80, // 1920 * 0.041667
                item : {
                    width : 352, //1920 * 0.183333
                }
            },
            division : {
                x : 351, // 1920 * 0.183333 - 1920 * 0.000521
                y : 23, //1080 * (0.419444 - 0.398148) 
                width : 1,// 1920 * 0.000521
                height : 27// 1080 * 0.025000
            },
        },
        hr : {
            y : 360, //1080 * (0.466667 - 0.1333)
            height : 2, // 1080 * 0.001852
        },
        city : {
            y : 362, // 1080 * (0.468519 - 0.1333)
            width : 1768, //1920 * 0.230208 * 4
            height : 408, // 1080 * 0.094444 * 4
            list : {
                x : 100, // 1920 * 0.052083
                item : {
                    width : 442, //1920 * 0.230208
                    height : 102, //1080 * 0.094444
                    box : {
                        y : 31, // 1080 * (0.497222 - 0.468519)
                        width : 40,
                        height : 40,
                    },
                    text : {
                        x : 54, // 1920 * (0.080208 - 0.052083)
                        width : 340, //1920 * 0.177083
                    },
                    bg : {
                        width : 410, //1920 * 0.213542
                    }
                }
            },
            division : {
                x : 0,
                y : 101,//1080 * 0.094444 - 1080 * 0.000926
                width : 1740, // 1920 * 0.906250
                height : 1 // 1080 * 0.000926
            }
        },
        button : {
            y : 820, //1080 * ( 1 - 0.047222 - 0.060185) - 1080 * 0.1333
            width : 270, // 1920 * 0.140625
            height : 65, // 1080 * 0.060185
            b1 : {
                x : 678, // 1920  / 2 -  1920 * 0.012500 / 2 - 1920 * 0.140625
            },
            b2 : {
                x : 972, // 1920  / 2 +  1920 * 0.012500 / 2
            }
        }
    }
};

var WeatherSettingTemplate = {
    main : {
        parent : scene,
        type : 'widget',
        width : ScreenTemplate.width,
        height : ScreenTemplate.height,
        color : ScreenTemplate.transparentColor,
        children : [{
            id : 'newson-weather-setting-title-area',
            type : 'widget',
            width : ScreenTemplate.width,
            height : CurTemplate.title.height,
            color : Volt.hexToRgb('#1F2B3D')
        }, {
            id : 'newson-weather-setting-container-area',
            type : 'widget',
            y : CurTemplate.title.height,
            width : ScreenTemplate.width,
            height : CurTemplate.container.height,
            color : Volt.hexToRgb('#233146')
        }, {
            id : 'newson-weather-setting-popup-container',
            type : 'widget',
            width : ScreenTemplate.width,
            height : ScreenTemplate.height,
            color : Volt.hexToRgb('#000000', 0)
        }]
    },

    titleArea : {
        type : 'widget',
        width : ScreenTemplate.width,
        height : CurTemplate.title.height,
        color : ScreenTemplate.transparentColor,
        children : [{
            id : 'newson-weather-setting-title-text',
            type : 'text',
            x : CurTemplate.title.text.x,
            y : CurTemplate.title.text.y,
            width : CurTemplate.title.text.width,
            height : CurTemplate.title.text.height,
            horizontalAlignment : 'left',
            verticalAlignment : 'top',
            textColor : Volt.hexToRgb('#ffffff', 40),
            text : Volt.LANG.SETTING,
            font : 'SVD Light 50px'
        }, {
            id : 'newson-weather-setting-return-button',
            type : 'image',
            x : CurTemplate.title.button.x,
            y : CurTemplate.title.button.y,
            width : CurTemplate.title.button.width,
            height : CurTemplate.title.button.height,
            color : ScreenTemplate.transparentColor,
        }]
    },

    containerArea : {
        type : 'widget',
        width : ScreenTemplate.width,
        height : CurTemplate.container.height,
        color : ScreenTemplate.transparentColor,
        children : [{
            id : 'newson-weather-setting-tip-area',
            type : 'widget',
            x : CurTemplate.container.tip.x,
            y : CurTemplate.container.tip.y,
            width : CurTemplate.container.tip.width,
            height : CurTemplate.container.tip.height,
            color : ScreenTemplate.transparentColor
        }, {
            id : 'newson-weather-setting-province-content-area',
            type : 'widget',
            y : CurTemplate.container.province.y,
            width : ScreenTemplate.width,
            height : CurTemplate.container.province.height,
            color : ScreenTemplate.transparentColor
        }, {
            id : 'newson-weather-setting-division-hr',
            type : 'widget',
            y : CurTemplate.container.hr.y,
            width : ScreenTemplate.width,
            height : CurTemplate.container.hr.height,
            color : Volt.hexToRgb('#ffffff', 10)
        }, {
            id : 'newson-weather-setting-city-content-area',
            type : 'widget',
            y : CurTemplate.container.city.y,
            width : ScreenTemplate.width,
            height : CurTemplate.container.city.height,
            color : ScreenTemplate.transparentColor
        }, {
            id : 'newson-weather-setting-button-area',
            type : 'widget',
            y : CurTemplate.container.button.y,
            width : ScreenTemplate.width,
            height : CurTemplate.container.button.height,
            color : ScreenTemplate.transparentColor
        }]
    },

    tipArea : {
        type : 'widget',
        width : CurTemplate.container.tip.width,
        height : CurTemplate.container.tip.height,
        color : ScreenTemplate.transparentColor,
        children : [{
            type : 'text',
            width : CurTemplate.container.tip.width,
            height : CurTemplate.container.tip.tip1And2.height,
            horizontalAlignment : 'left',
            verticalAlignment : 'top',
            textColor : Volt.hexToRgb('#ffffff', 60),
            text : Volt.LANG.WEATHER_SETTING_TIP_1,
            font : 'SVD Light 30px'
        }, {
            type : 'text',
            y : CurTemplate.container.tip.tip1And2.height,
            width : CurTemplate.container.tip.width,
            height : CurTemplate.container.tip.tip1And2.height,
            horizontalAlignment : 'left',
            verticalAlignment : 'top',
            textColor : Volt.hexToRgb('#ffffff', 60),
            text : Volt.LANG.WEATHER_SETTING_TIP_2,
            font : 'SVD Light 30px'
        }, {
            id : 'newson-weather-setting-selected-count',
            type : 'text',
            y : CurTemplate.container.tip.tip3.y,
            width : CurTemplate.container.tip.width,
            height : CurTemplate.container.tip.tip3.height,
            horizontalAlignment : 'left',
            verticalAlignment : 'top',
            textColor : Volt.hexToRgb('#ffffff', 60),
            text : '',
            font : 'SVD Light 30px'
        }]
    },

    provinceContentArea : {
        type : 'widget',
        width : ScreenTemplate.width,
        height : CurTemplate.container.province.height,
        color : ScreenTemplate.transparentColor,
        children : [{
            id : 'newson-weather-setting-province-list',
            type : 'widget',
            x : CurTemplate.container.province.list.x,
            width : CurTemplate.container.province.width,
            height : CurTemplate.container.province.height,
            color : ScreenTemplate.transparentColor
        }]
    },

    cityContentArea : {
        type : 'widget',
        width : ScreenTemplate.width,
        height : CurTemplate.container.city.height,
        color : ScreenTemplate.transparentColor,
        children : [{
            id : 'newson-weather-setting-city-list',
            type : 'widget',
            x : CurTemplate.container.city.list.x,
            width : CurTemplate.container.city.width,
            height : CurTemplate.container.city.height,
            color : ScreenTemplate.transparentColor
        }]
    },

    buttonArea : {
        type : 'widget',
        width : ScreenTemplate.width,
        height : CurTemplate.container.button.height,
        color : ScreenTemplate.transparentColor,
        children : [{
            id : 'newson-weather-setting-save-button',
            type : 'widget',
            x : CurTemplate.container.button.b1.x,
            width : CurTemplate.container.button.width,
            height : CurTemplate.container.button.height,
            color : ScreenTemplate.transparentColor,
            custom : {
                focusable : true
            }
        }, {
            id : 'newson-weather-setting-cancel-button',
            type : 'widget',
            x : CurTemplate.container.button.b2.x,
            width : CurTemplate.container.button.width,
            height : CurTemplate.container.button.height,
            color : ScreenTemplate.transparentColor,
            custom : {
                focusable : true
            }
        }]
    },
    
    provinceList : {
        type : 'GridListControl',
        parent : null,
        width : CurTemplate.container.province.width,
        height : CurTemplate.container.province.height,
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : 0,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0,
        custom : {
            focusable : true
        }
    },

    cityList : {
        type : 'GridListControl',
        parent : null,
        width : CurTemplate.container.city.width,
        height : CurTemplate.container.city.height,
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : 0,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0,
        custom : {
            focusable : true
        }
    },
    
    provinceItem : {
        type : 'widget',
        width : CurTemplate.container.province.list.item.width,
        height : CurTemplate.container.province.height,
        color : ScreenTemplate.transparentColor,
        children : [{
            ID : 'TextNormal',
            type : 'text',
            width : CurTemplate.container.province.list.item.width,
            height : CurTemplate.container.province.height,
            text : '{{ provinceName }}',
            textColor : Volt.hexToRgb('#ffffff', 80),
            horizontalAlignment : 'center',
            verticalAlignment : 'center',
            font : 'SVD Light 35px'
        }, {
            ID : 'TextFocus',
            type : 'text',
            width : CurTemplate.container.province.list.item.width,
            height : CurTemplate.container.province.height,
            color : Volt.hexToRgb('#ffffff', 95),
            text : '{{ provinceName }}',
            textColor : Volt.hexToRgb('#464646'),
            horizontalAlignment : 'center',
            verticalAlignment : 'center',
            font : 'SVD Light 35px'
        }, {
            ID : 'TextSelected',
            type : 'text',
            width : CurTemplate.container.province.list.item.width,
            height : CurTemplate.container.province.height,
            text : '{{ provinceName }}',
            textColor : Volt.hexToRgb('#fbba2d'),
            horizontalAlignment : 'center',
            verticalAlignment : 'center',
            font : 'SVD Light 35px'
        }, {
            ID : 'division',
            type : 'widget',
            x : CurTemplate.container.province.division.x,
            y : CurTemplate.container.province.division.y,
            width : CurTemplate.container.province.division.width,
            height : CurTemplate.container.province.division.height,
            color : Volt.hexToRgb('#ffffff', 10)
        }]
    },

    cityItem : {
        type : 'widget',
        width : CurTemplate.container.city.list.item.width,
        height : CurTemplate.container.city.list.item.height,
        color : ScreenTemplate.transparentColor,
        children : [{
            ID : 'BGFocus',
            type : 'widget',
            width : CurTemplate.container.city.list.item.bg.width,
            height : CurTemplate.container.city.list.item.height,
            color : Volt.hexToRgb('#ffffff', 95)
        }, {
            ID : 'TextNormal',
            type : 'text',
            x : CurTemplate.container.city.list.item.text.x,
            width : CurTemplate.container.city.list.item.text.width,
            height : CurTemplate.container.city.list.item.height,
            text : '{{ cityName }}',
            textColor : Volt.hexToRgb('#ffffff', 80),
            verticalAlignment : 'center',
            font : 'SVD Light 35px'
        }, {
            ID : 'TextFocus',
            type : 'text',
            x : CurTemplate.container.city.list.item.text.x,
            width : CurTemplate.container.city.list.item.text.width,
            height : CurTemplate.container.city.list.item.height,
            text : '{{ cityName }}',
            textColor : Volt.hexToRgb('#464646'),
            verticalAlignment : 'center',
            font : 'SVD Light 36px'
        }, {
            ID : 'BoxNormal',
            type : 'image',
            y : CurTemplate.container.city.list.item.box.y,
            width : CurTemplate.container.city.list.item.box.width,
            height : CurTemplate.container.city.list.item.box.height,
            src : Volt.getRemoteUrl('images/1080/checkbox/popup_check_box.png'),
            fillMode : 'stretch'
        }, {
            ID : 'BoxFocus',
            type : 'image',
            y : CurTemplate.container.city.list.item.box.y,
            width : CurTemplate.container.city.list.item.box.width,
            height : CurTemplate.container.city.list.item.box.height,
            src : Volt.getRemoteUrl('images/1080/checkbox/popup_check_box_f.png'),
            fillMode : 'stretch'
        }, {
            ID : 'CheckNormal',
            type : 'image',
            y : CurTemplate.container.city.list.item.box.y,
            width : CurTemplate.container.city.list.item.box.width,
            height : CurTemplate.container.city.list.item.box.height,
            src : Volt.getRemoteUrl('images/1080/checkbox/popup_check_icon_n.png'),
            fillMode : 'stretch'
        }, {
            ID : 'CheckFocus',
            type : 'image',
            y : CurTemplate.container.city.list.item.box.y,
            width : CurTemplate.container.city.list.item.box.width,
            height : CurTemplate.container.city.list.item.box.height,
            src : Volt.getRemoteUrl('images/1080/checkbox/popup_check_icon_f.png'),
            fillMode : 'stretch'
        }, {
            ID : 'division',
            type : 'widget',
            x : CurTemplate.container.city.division.x,
            y : CurTemplate.container.city.division.y,
            width : CurTemplate.container.city.division.width,
            height : CurTemplate.container.city.division.height,
            color : Volt.hexToRgb('#ffffff', 10)
        }]
    }

};

exports = WeatherSettingTemplate;
