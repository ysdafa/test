var ScreenTemplate = Volt.require('app/templates/1080/newson-screen-template.js');
var WeatherDetailTemplate = {
    container : {
        parent : scene,
        type : 'widget',
        x : 0,
        y : 0,
        width : 1920,
        height : 1080,
        color : {
            r : 0,
            g : 0,
            b : 0,
            a : 0
        },
        children : [{
            id : 'weather-content-container',
            type : 'widget',
            x : 0,
            y : 0,
            width : 1920,
            height : 1080,
            //color: Volt.hexToRgb('#00285A'),
            color : {
                r : 0,
                g : 0,
                b : 0,
                a : 0
            }
        }]
    },

    weathercontent : {
        parent : scene,
        type : 'widget',
        x : 0,
        y : 0,
        width : 1920,
        height : 1080,
        color : {
            r : 0,
            g : 0,
            b : 0,
            a : 0
        },
        children : [{
            type : 'image',
            id : 'image-bg-container',
            x : 0,
            y : 0,
            width : 1920,
            height : 1080,
            src : '{{image_bg}}'
        },

        {
            id : 'newson-weather-detail-return-button',
            type : 'image',
            x : 40, // (1920 * 0.075000 - 64)/2
            y : 40, // (1080 * 0.133333 - 64)/2
            width : 64,
            height : 64,
            color : ScreenTemplate.transparentColor
        },

        {
            type : 'image',
            id : 'brand-image',
            x : 850, // (1920 - 220) / 2
            y : 24, // 1080 * 0.022222
            width : 220,
            height : 24,
            src : '{{brand_image}}',
            horizontalAlignment : "center"
        },

        /*{			
        	type : 'text',
        	id : 'text-page-loggin',
        	x : 1240, y : 40, width : 640, height:32,
        	font : "SamsungSVD_Light_EU 25px",
        	textColor : Volt.hexToRgb('#FFFFFF', 60),
        	text:'Log in and get your own forcasts.',
        	justify: false,
        	horizontalAlignment : "right"              
        },
        
        {			
        	type: 'image',
        	id : 'login-image',
        	x: 1836, y: 58, width: 50, height:50,
        	src : Volt.getRemoteUrl('images/1080/icon_setting_n.png'), 
        	horizontalAlignment : "center"   				
        },*/

        {
            type : 'text',
            id : 'text-city-title',
            y : 48, // 1080 * 0.022222 + 24
            height : 68, // 1080 * 0.059259
            font : "SamsungSVD_Light_EU 60px",
            textColor : Volt.hexToRgb('#FFFFFF', 100),
            text : '',
            justify : true,
            horizontalAlignment : "center",
            verticalAlignment : "top",
            textShadow : {
                xOffset : 0,
                yOffset : 1,
                color : {
                    r : 0,
                    g : 0,
                    b : 0,
                    a : 255
                }
            }
        },

        {
            type : 'text',
            id : 'text-page-index',
            y : 78, // 1080 * 0.022222 + 24 + 1080 * 0.027778
            height : 30, // 1080 * 0.027778
            font : "SamsungSVD_Light_EU 25px",
            textColor : Volt.hexToRgb('#FFFFFF', 100),
            text : '',
            justify : false,
            horizontalAlignment : "left",
            verticalAlignment : "top",
            textShadow : {
                xOffset : 0,
                yOffset : 1,
                color : {
                    r : 0,
                    g : 0,
                    b : 0,
                    a : 255
                }
            }
        },

        {
            type : 'text',
            id : 'text-local-time',
            x : 360,
            y : 121, // 1080 * 0.022222 + 24 + 1080 * 0.059259 + 1080 * 0.008333
            width : 1200,
            height : 30, // 1080 * 0.027778
            font : "SamsungSVD_Light_EU 25px",
            textColor : Volt.hexToRgb('#FFFFFF', 60),
            text : '',
            justify : false,
            horizontalAlignment : "center",
            textShadow : {
                xOffset : 0,
                yOffset : 1,
                color : {
                    r : 0,
                    g : 0,
                    b : 0,
                    a : 255
                }
            }
        },

        {
            type : 'text',
            id : 'text-photo-attribution',
            x : 1104, //1920 - 1920 * 0.009375 - 1920 * 0.138542 * 3
            y : 832, // 1080 * (1 - 0.212963 - 0.016667)
            width : 798, //1920 * 0.138542 * 3
            height : 18, //1080 * 0.016667
            font : "SamsungSVD_Light_EU 13px",
            textColor : Volt.hexToRgb('#FFFFFF', 100),
            textShadow : {
                xOffset : 0,
                yOffset : 1,
                color : {
                    r : 0,
                    g : 0,
                    b : 0,
                    a : 255
                }
            },
            text : '',
            justify : false,
            horizontalAlignment : "right"
        },

        /*{
            type : 'image',
            id : 'info-weather-bg',
            y : 850, //1080 * (1 - 0.212963)
            width : 1920,
            height : 230, //1080 * 0.212963
            fillMode : "stretch",
            //opacity:255,
            color : Volt.hexToRgb('#ffffff', 80),
            horizontalAlignment : "center"
        },*/

        {
            type : 'image',
            id : 'image-condition-container',
            x : 32, // 1920 * 0.016667
            y : 868, // 1080 *(1 - 0.212963 + 0.016667)
            width : 83,
            height : 83,
            src : '{{image_current_condition}}',
        },

        {
            type : 'text',
            id : 'text-current-condition',
            x : 127, //1920 * 0.016667 + 83 + 1920 * 0.00625
            y : 868, // 1080 *(1 - 0.212963 + 0.016667)
            width : 300, // 1920 * 0.156250
            height : 83,
            font : "SamsungSVD_Light_EU 40px",
            textColor : Volt.hexToRgb('#000000', 60),
            text : '',
            justify : false,
            ellipsize : true,
            horizontalAlignment : "left",
            verticalAlignment : "center"
        },

        {
            type : 'text',
            id : 'text-current-temp',
            x : 32, // 1920 * 0.016667
            y : 970, // 1080 * (1 - 0.018519) - 90
            width : 153, //1920 * (0.096354 - 0.016667)
            height : 90, // 1080 * 0.083333
            font : "SamsungSVD_Light_EU 85px",
            textColor : Volt.hexToRgb('#000000', 60),
            text : '',
            justify : false,
            horizontalAlignment : "left"
        },

        {
            type : 'image',
            id : 'image-temp-up',
            x : 185, // 1920 * 0.096354
            y : 974, // 1080 * (1 - 0.018519)- 4 - 41 * 2
            width : 18,
            height : 41,
            src : Volt.getRemoteUrl('images/1080/news_temperature_icon_h.png'),
            //color : Volt.hexToRgb('#FFFFFF', 100),
            horizontalAlignment : "center"
        },

        {
            type : 'image',
            id : 'image-temp-down',
            x : 185, // 1920 * 0.096354
            y : 1019, // 1080 * (1 - 0.018519)- 41
            width : 18,
            height : 41,
            src : Volt.getRemoteUrl('images/1080/news_temperature_icon_l.png'),
            //color : Volt.hexToRgb('#FFFFFF', 100),
            horizontalAlignment : "center"
        }, {
            type : 'text',
            id : 'text-temp-up',
            x : 185, // 1920 * 0.096354
            y : 978, // 1080 * (1 - 0.018519) - 41 * 2
            width : 22, // 1920 * 0.011458
            height : 41, // 1080 * 0.037963
            font : "SamsungSVD_Light_EU 30px",
            textColor : Volt.hexToRgb('#000000', 60),
            text : 'H',
            justify : false,
            horizontalAlignment : "left"
        }, {
            type : 'text',
            id : 'text-temp-up-colon',
            x : 207, // 1920 * (0.096354 + 0.011458)
            y : 978, // 1080 * (1 - 0.018519) - 41 * 2
            width : 8, // 1920 * 0.004166
            height : 41, // 1080 * 0.037963
            font : "SamsungSVD_Light_EU 30px",
            textColor : Volt.hexToRgb('#000000', 60),
            text : ':',
            justify : false,
            horizontalAlignment : "left"
        },

        {
            type : 'text',
            id : 'text-today-high',
            x : 215, // 1920 * (0.096354 + 0.015625)
            y : 978, // 1080 * (1 - 0.018519) - 41 * 2
            width : 80, //1920 * 0.04166
            height : 41, // 1080 * 0.037963
            font : "SamsungSVD_Light_EU 30px",
            textColor : Volt.hexToRgb('#000000', 60),
            text : '',
            justify : false,
            horizontalAlignment : "left"
        },

        {
            type : 'text',
            id : 'text-temp-down',
            x : 185, // 1920 * 0.096354
            y : 1023, // 1080 * (1 - 0.018519)- 41 + 4
            width : 22, // 1920 * 0.011458
            height : 41, // 1080 * 0.037963
            font : "SamsungSVD_Light_EU 28px",
            textColor : Volt.hexToRgb('#000000', 60),
            text : 'L',
            justify : false,
            horizontalAlignment : "left"
        },

        {
            type : 'text',
            id : 'text-temp-down-colon',
            x : 207, // 1920 * (0.096354 + 0.011458)
            y : 1023, // 1080 * (1 - 0.018519)- 41 + 4
            width : 8, // 1920 * 0.004166
            height : 41, // 1080 * 0.037963
            font : "SamsungSVD_Light_EU 28px",
            textColor : Volt.hexToRgb('#000000', 60),
            text : ':',
            justify : false,
            horizontalAlignment : "left"
        },

        {
            type : 'text',
            id : 'text-today-low',
            x : 215, // 1920 * (0.096354 + 0.015625)
            y : 1023, // 1080 * (1 - 0.018519)- 41 + 4
            width : 80,//1920 * 0.04166
            height : 41, // 1080 * 0.037963
            font : "SamsungSVD_Light_EU 28px",
            textColor : Volt.hexToRgb('#000000', 60),
            text : '',
            justify : false,
            horizontalAlignment : "left"
        },

        {
            type : 'image',
            id : 'image-source-container',
            x : 265, // 1920 * 0.138021
            y : 1001, // 1080 * (1 - 0.022222) - 55
            width : 89,
            height : 55,
            src : '{{source_icon}}',
            horizontalAlignment : "center"
        },

        {
            type : 'text',
            id : 'text-feature-desc1',
            x : 423, //1920 * 0.220313
            y : 940, // 1080 * (1 - 0.018519 - 0.037037 * 3)
            width : 160, //1920 * 0.083333
            height : 40, // 1080 * 0.037037
            font : "SamsungSVD_Light_EU 28px",
            textColor : Volt.hexToRgb('#000000', 60),
            text : '',
            justify : false,
            ellipsize : true,
            horizontalAlignment : "left"
        },

        {
            type : 'text',
            id : 'text-feature-value1',
            x : 593, //1920 * (0.220313 + 0.083333 + 0.005208)
            y : 940, // 1080 * (1 - 0.018519 - 0.037037 * 3)
            width : 160, //1920 * 0.083333
            height : 40, // 1080 * 0.037037
            font : "SamsungSVD_Light_EU 28px",
            textColor : Volt.hexToRgb('#000000', 60),
            text : '',
            justify : false,
            horizontalAlignment : "right"
        },

        {
            type : 'text',
            id : 'text-feature-desc2',
            x : 423, //1920 * 0.220313
            y : 980, // 1080 * (1 - 0.018519 - 0.037037 * 2)
            width : 160, //1920 * 0.083333
            height : 40, // 1080 * 0.037037
            font : "SamsungSVD_Light_EU 28px",
            textColor : Volt.hexToRgb('#000000', 60),
            text : '',
            justify : false,
            ellipsize : true,
            horizontalAlignment : "left"
        },

        {
            type : 'text',
            id : 'text-feature-value2',
            x : 593, //1920 * (0.220313 + 0.083333 + 0.005208)
            y : 980, // 1080 * (1 - 0.018519 - 0.037037 * 2)
            width : 160, //1920 * 0.083333
            height : 40, // 1080 * 0.037037
            font : "SamsungSVD_Light_EU 28px",
            textColor : Volt.hexToRgb('#000000', 60),
            text : '',
            justify : false,
            horizontalAlignment : "right"
        },

        {
            type : 'text',
            id : 'text-feature-desc3',
            x : 423, //1920 * 0.220313
            y : 1020, // 1080 * (1 - 0.018519 - 0.037037)
            width : 160, //1920 * 0.083333
            height : 40, // 1080 * 0.037037
            font : "SamsungSVD_Light_EU 28px",
            textColor : Volt.hexToRgb('#000000', 60),
            text : '',
            justify : false,
            ellipsize : true,
            horizontalAlignment : "left"
        },

        {
            type : 'text',
            id : 'text-feature-value3',
            x : 593, //1920 * (0.220313 + 0.083333 + 0.005208)
            y : 1020, // 1080 * (1 - 0.018519 - 0.037037)
            width : 160, //1920 * 0.083333
            height : 40, // 1080 * 0.037037
            font : "SamsungSVD_Light_EU 28px",
            textColor : Volt.hexToRgb('#000000', 60),
            text : '',
            justify : false,
            horizontalAlignment : "right"
        },

        {
            custom : {
                'focusable' : true
            },
            type : 'image',
            id : 'image_arrow_left_unfocus',
            x : 12, // 1920 * 0.006250
            y : 446, // 1080 * (0.022222 + 0.390741)
            width : 26,
            height : 50,
            //color: Volt.hexToRgb('#ffffff',60),
            opacity : 150,
            src : Volt.getRemoteUrl('images/1080/arrow/weather_arrow_left.png')
        },

        /*{
        	custom: { 'focusable': true },	
        	type : 'image',
        	id: 'image_arrow_left_focus',
        	x : 12, y : 422, width : 26, height:50,
        	//color: Volt.hexToRgb('#ffffff',100),
        	opacity: 255,
        	src : Volt.getRemoteUrl('images/1080/arrow/weather_arrow_left.png')
        },*/

        {
            custom : {
                'focusable' : true
            },
            type : 'image',
            id : 'image_arrow_right_unfocus',
            x : 1882, // 1920 - 1920 * 0.006250 - 26
            y : 446, // 1080 * (0.022222 + 0.390741)
            width : 26,
            height : 50,
            //color: Volt.hexToRgb('#ffffff',60),
            opacity : 150,
            src : Volt.getRemoteUrl('images/1080/arrow/weather_arrow_right.png')
        },

        /*{
        	custom: { 'focusable': true },	
        	type : 'image',
        	id: 'image_arrow_right_focus',
        	x : 1882, y : 422, width : 26, height:50,
        	//color: Volt.hexToRgb('#ffffff',100),
        	opacity: 255,	
        	src : Volt.getRemoteUrl('images/1080/arrow/weather_arrow_right.png')
        },	*/

        {
            id : 'weather-day-container',
            type : 'widget',
            x : 782, //1920 * 0.407292
            y : 850, // 1080 * (1 - 0.212963)
            width : 1138, //1920 * (1-0.407292)
            height : 230, // 1080 * 0.212963
            color : Volt.hexToRgb('#000000', 0)
        },

        ]
    },

    weatherday : {
        type : 'widget',
        width : 1138, //1920 * (1-0.407292)
        height : 230, // 1080 * 0.212963
        color : Volt.hexToRgb('#000000', 0),
        children : [{
            id : 'weather-day-container1',
            type : 'widget',
            width : 226, // 1920 * 0.117708
            height : 230, // 1080 * 0.212963
            color : Volt.hexToRgb('#000000', 0)
        },

        {
            id : 'weather-day-container2',
            type : 'widget',
            x : 226, // 1920 * 0.117708
            width : 226, // 1920 * 0.117708
            height : 230, // 1080 * 0.212963
            color : Volt.hexToRgb('#000000', 0)
        },

        {
            id : 'weather-day-container3',
            type : 'widget',
            x : 452, // 1920 * 0.117708 * 2
            width : 226, // 1920 * 0.117708
            height : 230, // 1080 * 0.212963
            color : Volt.hexToRgb('#000000', 0)
        },

        {
            id : 'weather-day-container4',
            type : 'widget',
            x : 678, // 1920 * 0.117708 * 3
            width : 226, // 1920 * 0.117708
            height : 230, // 1080 * 0.212963
            color : Volt.hexToRgb('#000000', 0)
        },

        {
            id : 'weather-day-container5',
            type : 'widget',
            x : 904, // 1920 * 0.117708 * 4
            width : 226, // 1920 * 0.117708
            height : 230, // 1080 * 0.212963
            color : Volt.hexToRgb('#000000', 0)
        }, ]
    },

    weatherdaytype1 : {
        type : 'widget',
        width : 226, // 1920 * 0.117708
        height : 230, // 1080 * 0.212963
        color : Volt.hexToRgb('#000000', 0),
        children : [

        {
            type : 'widget',
            width : 3, // 1920 * 0.001563
            height : 230, // 1080 * 0.212963
            color : Volt.hexToRgb('#FFFFFF', 20),
        },

        {
            type : 'text',
            y : 20, // 1080 * 0.018519
            width : 226, // 1920 * 0.117708
            height : 40, // 1080 * 0.033333
            font : "SamsungSVD_Light_EU 32px",
            textColor : Volt.hexToRgb('#000000', 60),
            text : '{{text_day_label}}',
            justify : true,
            horizontalAlignment : "center",
            verticalAlignment : "center"
        },

        {
            type : 'image',
            x : 61, // (1920 * 0.117708 - 104)/2
            y : 66, // 1080 * 0.061111
            width : 104,
            height : 104,
            src : '{{image_forecast_conditions}}',
        },

        {
            type : 'text',
            y : 182, // 1080 * (0.212963 - 0.011111 - 0.033333)
            width : 226, // 1920 * 0.117708
            height : 36, // 1080 * 0.033333
            font : "SamsungSVD_Light_EU 32px",
            textColor : Volt.hexToRgb('#000000', 60),
            text : '{{text_forecast_high_temp}}/{{text_forecast_low_temp}}',
            justify : true,
            horizontalAlignment : "center",
            verticalAlignment : "center"
        }

        ]
    },

    weatherdaytype2 : {
        type : 'widget',
        width : 226, // 1920 * 0.117708
        height : 230, // 1080 * 0.212963
        color : Volt.hexToRgb('#000000', 0),
        children : [

        {
            type : 'widget',
            width : 3, // 1920 * 0.001563
            height : 230, // 1080 * 0.212963
            color : Volt.hexToRgb('#FFFFFF', 20),
        },

        {
            type : 'text',
            y : 20, // 1080 * 0.018519
            width : 226, // 1920 * 0.117708
            height : 40, // 1080 * 0.033333
            font : "SamsungSVD_Light_EU 32px",
            textColor : Volt.hexToRgb('#000000', 60),
            text : '{{text_day_label}}',
            justify : true,
            horizontalAlignment : "center",
            verticalAlignment : "center"
        },

        {
            type : 'image',
            x : 8, //1920 * 0.004167
            y : 66, // 1080 * 0.061111
            width : 104,
            height : 104,
            src : '{{image_forecast_conditions1}}',
        },

        {
            type : 'image',
            x : 116, //1920 * 0.004167 + 104 + 1920 * 0.002083
            y : 66, // 1080 * 0.061111
            width : 104,
            height : 104,
            src : '{{image_forecast_conditions2}}',
        },

        {
            type : 'text',
            y : 182, // 1080 * (0.212963 - 0.011111 - 0.033333)
            width : 226, // 1920 * 0.117708
            height : 36, // 1080 * 0.033333
            font : "SamsungSVD_Light_EU 32px",
            textColor : Volt.hexToRgb('#000000', 60),
            text : '{{text_forecast_high_temp}}/{{text_forecast_low_temp}}',
            justify : true,
            horizontalAlignment : "center",
            verticalAlignment : "center"
        }

        ]
    },

    constNum : {
        indexSpace : 10, //1920 * 0.005208 space between city title and page index 
    }

};
exports = WeatherDetailTemplate;