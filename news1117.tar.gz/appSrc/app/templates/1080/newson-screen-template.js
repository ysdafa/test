var ScreenTemplate = {
    width : 1920,
    height : 1080,
    defaultColor : Volt.hexToRgb('#0f1826'),
    transparentColor : Volt.hexToRgb('#ffffff', 0)
};

exports = ScreenTemplate;