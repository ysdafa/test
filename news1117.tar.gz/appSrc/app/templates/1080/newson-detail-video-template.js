var DetailTemplate = {
    container : {
        type: 'widget',
        x: 0, y: 0, width: 1920-454, height : 866,
        color : Volt.hexToRgb('#ffffff',0),
        children : [
            {
                type : 'image',
                x : 150, y : 100, width : 1920-454 - 2*150, height : 866 - 2*100 - 50,
                id : 'detail-info-area-vedio',
                color : Volt.hexToRgb('#111111', 255),
				custom: { 'focusable': true },
				children:[
					{
						type : 'image',
						x : (1920-454 - 2*150 - 70)/2, y : (866 - 2*100 - 70)/2 , width :70 , height : 70,
						id : 'detail-fullarticle-area',
						//color : Volt.hexToRgb('#000000', 255),
						src:Volt.getRemoteUrl('images/1080/info_icon_video.png'),
					}
				]
            },
        ]
    },
}

exports = DetailTemplate;