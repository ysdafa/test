var DetailTextTemplate = {
    container : {
        type : 'widget',
        x : 0,
        y : 0,
        width : 1596, // 1920 * 0.83125
        height : 371, // 1080 * 0.343519
        color : Volt.hexToRgb('#000000', 0),
        children : [{
            type : 'text',
            x : 86, // 1920 * 0.044792
            y : 40, // 1080 * 0.037037
            width : 1424, // 1920 * 0.83125 - 2 * 1920 * 0.044792
            height : 204, // 1080 * 0.062963 * 3
            color : Volt.hexToRgb('#000000', 0),
            id : 'text_headline',
            ellipsize : true,
            text : '{{ headline }}',
            font : 'SVD Light 56px'
        }, {
            id : 'text_source_icon',
            type : 'image',
            async : true,
            x : 86,// 1920 * 0.044792
            y : 282, // 1080 * (0.343519 - 0.026852 - 0.009259 - 0.027778 - 0.018519)
//                width : 29 * 3,
//                height : 29, // 1080 * 0.026852
            src : '{{source_icon}}'
        }, {
            id : 'text_source_container',
            type : 'widget',
            x : 86,// 1920 * 0.044792
            y : 321, // 1080 * (0.343519 - 0.027778 - 0.018519)
            width : 1424, // 1920 * 0.83125 - 2 * 1920 * 0.044792
            height : 30,//1080 * 0.027778
            color : Volt.hexToRgb('#000000', 0),
            children : [{
                id : 'text_source',
                type : 'text',
                x : 0,
                y : 0,
                height : 30,
                font : 'SVD Light 26px',
                singleLineMode : true,
                verticalAlignment : 'center',
                horizontalAlignment : 'left',
                text : '{{source}}'
            }, {
                id : 'text_press_time',
                type : 'text',
                font : 'SVD Light 26px',
                singleLineMode : true,
                verticalAlignment : 'center',
                horizontalAlignment : 'left',
                x : 0,
                y : 0,
                height : 30,
                src : '{{press_time}}'
            },

            {
                id : 'text_timestamp',
                type : 'text',
                singleLineMode : true,
                font : 'SVD Light 26px',
                verticalAlignment : 'center',
                horizontalAlignment : 'left',
                x : 0,
                y : 0,
                height : 30,
                src : '{{timestamp}}'
            },

            {
                id : 'text_color_drawing01',
                type : 'widget',
                x : 0,
                y : 3,//1080 * 0.002778
                height : 24,//1080 * 0.022222
                width : 3,//1920 * 0.001563
                color : Volt.hexToRgb('#FFFFFF', 60)
            },

            {
                id : 'text_color_drawing02',
                type : 'widget',
                x : 0,
                y : 3,//1080 * 0.002778
                height : 24,//1080 * 0.022222
                width : 3,//1920 * 0.001563
                color : Volt.hexToRgb('#FFFFFF', 60)
            }]
        }]
    }
};

exports = DetailTextTemplate;
