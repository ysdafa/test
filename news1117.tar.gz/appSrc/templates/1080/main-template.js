var MainTemplate = {
    container : {
        parent : scene,
        type : 'widget',
        x : 0,
        y : 0,
        width : 1920,
        height : 1080,
        color : Volt.hexToRgb('#f2f2f2'),
        children : [
        /*            {
                        id: 'main-title-area',
                        type: 'widget',
                        x: 0, y: 0, width: 1920, height: 144,
                        color: Volt.hexToRgb('#0f1826')
                    },
        */
        {
            id : 'main-header-container',
            type : 'widget',
            x : 0,
            y : 0,
            width : 1920,
            height : 144, //1080 * 0.133333
            color : Volt.hexToRgb('#0f1826')
        }, {
            id : 'main-category-container',
            type : 'widget',
            x : 0,
            y : 144, //1080 * 0.133333
            width : 1920,
            height : 72, // 1080 * 0.066667
            color : Volt.hexToRgb('#f2f2f2')
        }, {
            id : 'main-content-container',
            type : 'widget',
            x : 0,
            y : 216, //1080 * 0.133333 + 1080 * 0.066667
            width : 1920,
            height : 864, //1080 * 0.8
            color : Volt.hexToRgb('#0f1826')
        }, {
            id : 'main-dim-container',
            type : 'widget',
            x : 0,
            y : 0,
            width : 1920,
            height : 1080,
            color : Volt.hexToRgb('#000000', 0)
        }, {
            id : 'main-popup-container',
            type : 'widget',
            x : 0,
            y : 0,
            width : 1920,
            height : 1080,
            color : Volt.hexToRgb('#000000', 0)
        }, {
            id : 'main-popup2-container',
            type : 'widget',
            x : 0,
            y : 0,
            width : 1920,
            height : 1080,
            color : Volt.hexToRgb('#000000', 0)
        }]
    },
};

exports = MainTemplate;
