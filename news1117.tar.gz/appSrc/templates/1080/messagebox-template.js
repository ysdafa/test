var CommonTemplate = Volt.require('app/templates/1080/newson-common-template.js');
var MessageboxTemplate = {
//	container : {
//	    type: 'widget',
//		custom : {
//			'focusable' : true,
//			'onKeyEvent' : null
//		},
//	    x: 0, y: 0, width: 1920, height : 1080,
//	    color : Volt.hexToRgb('#ffffff',0),
//	},

//	msgbox_template_no_title_one_button:
//	{
//		type: 'widget',
//	    x: 0, y: (1080 - 550) / 2, width: 1920, height : 550,
//	    color : Volt.hexToRgb('#ffffff',0),
//		children: [
//			{
//				type: 'widget',
//				id: 'bg',
//		    	x: 0, y: 0, width: 1920, height : 550,
//		    	color : Volt.hexToRgb('#0a5d88'),
//		    	opacity: 255 * 0.85,
//			},
//	    	{
//		        type : 'text',
//				id : 'message',
//		        x : 399, y: 48, width : 1122, height : 48*8,
//		        horizontalAlignment : 'center',
//		        verticalAlignment : 'center',
//		        textColor : Volt.hexToRgb('#ffffff'),
//		        text : '{{ message }}',
//		        font : '30px',
//	    	},
//            {
//                type : 'Button_Generic',
//                id : 'btn1',
//                custom : {'focusable' : true, 'text': '{{ btntext1 }}'},
//                x : 825, y : 48*8+70, width : 270, height : 66
//            },
//		],
//    },
//			
//	msgbox_template_no_title_two_button:
//	{
//		type: 'widget',
//	    x: 0, y: (1080 - 550) / 2, width: 1920, height : 550,
//	    color : Volt.hexToRgb('#0a5d88',85),
//	    
//		children: [
//	    	{
//		        type : 'text',
//				id : 'message',
//		        x : 399, y: 48, width : 1122, height : 48*8,
//		        horizontalAlignment : 'center',
//		        verticalAlignment : 'center',
//		        textColor : Volt.hexToRgb('#ffffff'),
//		        text : '{{ message }}',
//		        font : '30px',
//	    	},
//            {
//                type : 'Button_Generic',
//                id : 'btn1',
//                custom : {'focusable' : true, 'text': '{{ btntext1 }}'},
//                x : 690, y : 48*8+70, width : 270, height : 66
//            },
//            {
//                type : 'Button_Generic',
//                id : 'btn2',
//                custom : {'focusable' : true, 'text': '{{ btntext2 }}'},
//                x : 980, y : 48*8+70, width : 270, height : 66
//            }
//		],
//    },
//
//	msgbox_template_no_title_three_button:
//	{
//		type: 'widget',
//	    x: 0, y: (1080 - 550) / 2, width: 1920, height : 550,
//	    color : Volt.hexToRgb('#ffffff',0),
//	    
//		children: [
//			{
//				type: 'widget',
//				id: 'bg',
//		    	x: 0, y: 0, width: 1920, height : 550,
//		    	color : Volt.hexToRgb('#0a5d88'),
//		    	opacity: 255*0.85,
//			},
//	    	{
//		        type : 'text',
//				id : 'message',
//		        x : 399, y: 48, width : 1122, height : 48*8,
//		        horizontalAlignment : 'center',
//		        verticalAlignment : 'center',
//		        textColor : Volt.hexToRgb('#ffffff'),
//		        text : '{{ message }}',
//		        font : '30px',
//	    	},
//            {
//                type : 'Button_Generic',
//                id : 'btn1',
//                custom : {'focusable' : true, 'text': '{{ btntext1 }}'},
//                x : 535, y : 48*8+70, width : 270, height : 66
//            },
//            {
//                type : 'Button_Generic',
//                id : 'btn1',
//                custom : {'focusable' : true, 'text': '{{ btntext2 }}'},
//                x : 825, y : 48*8+70, width : 270, height : 66
//            },
//            {
//                type : 'Button_Generic',
//                id : 'btn1',
//                custom : {'focusable' : true, 'text': '{{ btntext3 }}'},
//                x : 1115, y : 48*8+70, width : 270, height : 66
//            }
//		],
//    },

    messagePopup : {
        type : 'MessagePopup',
        width : 0,
        height : 0,
        color : CommonTemplate.popupBG.color,
        opacity : 216,//255 * 0.85
        parent : scene,
    }
};

exports = MessageboxTemplate;
