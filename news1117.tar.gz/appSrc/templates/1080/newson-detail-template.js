var ScreenTemplate = Volt.require('app/templates/1080/newson-screen-template.js');
var NewsOnDetailTemplate = {
    container : {
        parent : scene,
        type : 'widget',
        width : 1920,
        height : 1080,
        color : Volt.hexToRgb('#000000', 8),
        children : [{
            type : 'widget',
            //id : 'detail-title-area',
            width : 1920,
            height : 371,// 1080 * 0.343519
            color : Volt.hexToRgb('#000000', 8),
            children : [{
                type : 'widget',
                id : 'detail-title-area',
                width : 1596, // 1920 * 0.831250
                height : 371,// 1080 * 0.343519
                color : Volt.hexToRgb('#000000', 0)
            }]
        }, {
            type : 'widget',
            y : 371,// 1080 * 0.343519
            width : 1596, // 1920 * 0.831250
            height : 709, // 1080 * (1 - 0.343519)
            id : 'detail-content-area',
            color : Volt.hexToRgb('#ffffff', 0)
        }, {
            type : 'widget',
            x : 1596, // 1920 * 0.831250
            width : 324, // 1920 * 0.168750
            height : 1080,
            id : 'detail-relate-area',
            color : Volt.hexToRgb('#ffffff', 0)
        }, {
            id : 'newson-news-detail-return-button',
            type : 'image',
            x : 40, // (1920 * 0.075000 - 64)/2
            y : 40, // (1080 * 0.133333 - 64)/2
            width : 64,
            height : 64,
            color : ScreenTemplate.transparentColor
        }]
    },
    /*
    TitleArea:{
        type : 'widget',
        x : 0, y : 0, width : 1920 - 277, height : 144,
        color : Volt.hexToRgb('#0F2540',0),
    	children: [
            {
                type : 'text',
                x : 60, y: 0, width : 1920 - 277 - (2 * 60), height : 144,
                horizontalAlignment : 'left',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#ffffff', 90),
    			id:'headline',
                ellipsize : true,
                text : '{{ headline }}',
                font : 'SVD Light 58px',
                singleLineMode: false,
            },
        ]
    },
    */
    DetailContentArea : {
        type : 'widget',
        width : 1596, // 1920 * 0.831250
        height : 709, // 1080 * (1 - 0.343519)
        color : Volt.hexToRgb('#ffffff', 0),
        children : [{
            type : 'widget',
            width : 1596, // 1920 * 0.831250
            height : 600, // 1080 * 0.572222 - (1080 * 0.572222 % (1080 * 0.046296))
            id : 'contentArea',
            cropOverflow : true,
            color : Volt.hexToRgb('#ffffff', 0)
        }, {
            type : 'widget',
            x : 692, // 1920 * 0.360417
            y : 617, // 1080 * (1 - 0.343519 - 0.037037) - 52
            width : 96,
            height : 52,
            custom : {
                'focusable' : false
            },
            color : Volt.hexToRgb('#ffffff', 0),
            opacity : Volt.getPercentage(10),
            id : 'artical_up',
            children : [
            /*{
                type : 'image',
                x : 0, // (96 - 32) / 2
                y : 0, //(52 - 32) / 2
                width : 96,
                height : 52,
                src : Volt.getRemoteUrl('images/1080/arrow/detail_arrow_up_n.png'),
            },
            {
                type : 'image',
                x : 0, // (96 - 32) / 2
                y : 0, //(52 - 32) / 2
                width : 96,
                height : 52,
                src : Volt.getRemoteUrl('images/1080/arrow/detail_arrow_up_f.png'),
            }*/
            {
                type : 'Button',
                x : 0, // (96 - 32) / 2
                y : 0, //(52 - 32) / 2
                width : 96,
                height : 52,
                backgroundImage: {
                  x: 0,
                  y: 0,
                  width: 96,
                  height: 52,
                  //src: Volt.getRemoteUrl('images/1080/arrow/detail_arrow_up_n.png')
              },
            }
            ]
        }, {
            type : 'widget',
            x : 808, // 1920 * 0.360417 + 96 + 1920 * 0.010417
            y : 617, // 1080 * (1 - 0.343519 - 0.037037) - 52
            width : 96,
            height : 52,
            custom : {
                'focusable' : false
            },
            id : 'artical_down',
            color : Volt.hexToRgb('#ffffff', 0),
            children : [
            /*{
                type : 'image',
                x : 0, // (96 - 32) / 2
                y : 0, //(52 - 32) / 2
                width : 96,
                height : 52,
                src : Volt.getRemoteUrl('images/1080/arrow/detail_arrow_down_n.png'),
            },{
                type : 'image',
                x : 0, // (96 - 32) / 2
                y : 0, //(52 - 32) / 2
                width : 92,
                height : 52,
                src : Volt.getRemoteUrl('images/1080/arrow/detail_arrow_down_f.png'),
            }*/
            {
                type : 'Button',
                x : 0, // (96 - 32) / 2
                y : 0, //(52 - 32) / 2
                width : 96,
                height : 52,
                backgroundImage: {
                  x: 0,
                  y: 0,
                  width: 96,
                  height: 52,
                  //src: Volt.getRemoteUrl('images/1080/arrow/detail_arrow_down_n.png')
              }
            }
            ]
        },
        {
            type : 'ScrollBar',
            x:1596-23-4,
            y:0,
            height:600,
            width:4,
            id:'detail_scroll_bar',
            loop:true,
        }
        ]
    },
    contentAppend : {
        type : 'widget',
        width : 1596, // 1920 * 0.831250
        height : 600, // 1080 * 0.572222 - (1080 * 0.572222 % (1080 * 0.046296))
        color : Volt.hexToRgb('#ffffff', 0),
        id : 'contentRealArea',
        children : [{
            type : 'image',
            //cropMode: 'cropLeftTop',
            x : 86, // 1920 * 0.044792
            y : 30, // 1080 * 0.044444 - (1080 * 0.572222 % (1080 * 0.046296))
//            width : 145, 
            width : 145,
            height : 34,
            id : 'brand_img_url',
            src : '{{ brand_img_url }}',
            opacity : 255 * 0.6,
            color : Volt.hexToRgb('#FFFFFF', 0)
        }, {
            type : 'text',
            id : 'contents',
            x : 86, // 1920 * 0.044792
            y : 63, // 1080 * (0.044444 + 0.026852 + 0.003704) - (1080 * 0.572222 % (1080 * 0.046296))
            width : 1424, // 1920 * (0.831250 - 2 * 0.044792)
            //height:50*6,
            text : '{{contents}}',
            textColor : Volt.hexToRgb('#FFFFFF', 60),
            font : '35px'
        //ellipsize : true,
        }, {
            type : 'widget', // color drowing
            id : 'color_drowing_horizontal',
            x : 86, // 1920 * 0.044792
            width : 1424, // 1920 * 0.741667
            height : 2, // 1080 * 0.001852
            color : Volt.hexToRgb('#FFFFFF', 20)
        }, {
            type : 'text',
            x : 86, // 1920 * 0.044792
            width : 1424, // 1920 * (0.831250 - 2 * 0.044792)
            height : 30, // 1080 * 0.027778
            text : 'Full Article',
            id : 'text_fullarticle',
            textColor : Volt.hexToRgb('#FFFFFF', 80),
            font : 'SVD Light 26px'
        // ellipsize : true,
        }, {
            type : 'text',
            id : 'fullarticle',
            x : 86, // 1920 * 0.044792
            y : 63, // 1080 * (0.044444 + 0.026852 + 0.003704) - (1080 * 0.572222 % (1080 * 0.046296))
            width : 1424, // 1920 * (0.831250 - 2 * 0.044792)
            //height:709 - 40 - 52 - (48 + 29 + 4 + 50 * 6 + 28 + 2 + 28 + 20 + 15),
            text : '{{fullarticle}}',
            textColor : Volt.hexToRgb('#FFFFFF', 60),
            font : 'SVD Light 35px'
        //ellipsize : true,
        }]
    },
    detailArrowDown : {
        'unfocus' : Volt.getRemoteUrl('images/1080/arrow/detail_arrow_down_n.png'),
        'focus' : Volt.getRemoteUrl('images/1080/arrow/detail_arrow_down_f.png')
    },

    detailArrowUp : {
        'unfocus' : Volt.getRemoteUrl('images/1080/arrow/detail_arrow_up_n.png'),
        'focus' : Volt.getRemoteUrl('images/1080/arrow/detail_arrow_up_f.png')
    },

    RelatedItem : [{
        type : 'image',
        width : 324, // 1920 * 0.168750
        height : 292, // 1080 * (0.18148 + 0.088889)
        src : Volt.getRemoteUrl('images/1080/icon/icon_blank_thumbnail.png'),
        fillMode : 'center',
        color : Volt.hexToRgb('#d4d4d4', 100),
        children : [{
            type : 'widget',
            x : 323, // 1920 * 0.168750 - 1
            y : 0,
            width : 1, 
            height : 292, // 1080 * (0.18148 + 0.088889)
            color : Volt.hexToRgb('#c9c9c9', 100)
        }, {
            type : 'widget',
            x : 0,
            y : 291, // 1080 * (0.18148 + 0.088889) -1
            width : 324,  // 1920 * 0.168750
            height : 1,
            color : Volt.hexToRgb('#c9c9c9', 100)
        },
		{
		type: 'Thumbnail',
		visibleStyles: (0x01 | 0x20),
		image:{src: '{{ imgUrl }}',
			width: 324,
			height: 196},
		information:{
			x: 0,
			y: 196,
			width: 324,
			height: 96,
			text1:{
				x:20,
				y:16,
				width:284,
				height: 32,
				font: 'SVD Light 26px',
				text: '{{ title }}',
				singleLineMode: true
			},
			
			text2:{
				x:20,
				y:50,
				width:324- 20*2,
				height: 32,
				font: 'SVD Medium 20px',
				text: '{{ timestamp }}',
				singleLineMode: true
			},
		},
	}]	
}]	

};

exports = NewsOnDetailTemplate;
