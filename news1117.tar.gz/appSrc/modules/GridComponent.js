var GridComponent = function(widgetOptions, options) {
	var gridWidget = new Widget(widgetOptions);

	options = options || {};

	gridWidget.gridOptions = {
		maxColumns: options.maxColumns || 4,
		padding: options.padding || 10
	};

	var widgets = options.widgets ? options.widgets.length ? options.widgets : [options.widgets] : [];

	gridWidget.selectedIndex = {
		x: 0,
		y: 0
	};

	gridWidget.widgetRows = new ListWidget({
		x: 0,
		y: 0,
		height: gridWidget.height,
		width: gridWidget.width,
		parent: gridWidget,
		orientation: "vertical",
		spacing: gridWidget.gridOptions.padding,
		color: gridWidget.color
	});

	gridWidget.widgetRows.addChild(new ListWidget({
		x: 0,
		y: 0,
		width: gridWidget.widgetRows.width,
		height: 0,
		spacing: gridWidget.gridOptions.padding,
		color: gridWidget.color
	}));

	for (var i = 0; i < widgets.length; i++) {
		addWidget.call(gridWidget, widgets[i]);
	}

	gridWidget.isComponent = true;
	gridWidget.hasFocus = false;
	gridWidget.getSelectedWidget = getSelectedWidget;
	gridWidget.addWidget = addWidget;
	gridWidget.removeWidget = removeWidget;
	gridWidget.handleKey = handleKey;

	return gridWidget;

};

var getSelectedWidget = function() {
	return this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x);
};

var addWidget = function(widget) {
	var currentRow = this.widgetRows.getChild(this.widgetRows.getChildCount() - 1);
	if (currentRow.getChildCount() < this.gridOptions.maxColumns) {
		if (currentRow.height < widget.height) {
			currentRow.height = widget.height;
		}
		/* This MUST come after the above check because adding the widget to the
		 * currentRow (ListWidget) will transform its size. */
		currentRow.addChild(widget);
	} else {
		this.widgetRows.addChild(new ListWidget({
			x: 0,
			y: 0,
			width: this.widgetRows.width,
			height: widget.height,
			spacing: this.gridOptions.padding,
			color: this.color
		}));

		currentRow = this.widgetRows.getChild(this.widgetRows.getChildCount() - 1);
		if (currentRow.height < widget.height) {
			currentRow.height = widget.height;
		}
		/* This MUST come after the above check because adding the widget to the
		 * currentRow (ListWidget) will transform its size. */
		currentRow.addChild(widget);
	}

	//instanceof doesn't work in different contexts so we are checking for a src property to see if it is an image widget
	if (widget.src){
		var callback;
		if (widget.onReady){
			callback = widget.onReady;
		}
		widget.onReady = resizeRowCallback(widget, currentRow, callback);
	}

};

var resizeRowCallback = function(widget, currentRow, originalCallback){
	return function(){
		if (originalCallback){
			originalCallback();
		}
		if (currentRow.height < widget.height) {
			currentRow.height = widget.height;
		}
	};
};

var removeWidget = function(x, y) {
	return this.widgetRows.getChild(y).removeChild(x);
};

var handleKey = function(key) {
	if (this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x).isComponent) {
		var result = this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x).handleKey(key);
		if (result.handled) {
			return result;
		}
	}
	return keyHandler[key].call(this, key);
};

var keyHandler = {
	left: function() {
		if (this.selectedIndex.x > 0) {
			this.selectedIndex.x--;
			if (this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x).isComponent) {
				return this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x).handleKey("focus");
			}
			return {
				selectedWidget: this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x),
				previousWidget: this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x + 1),
				handled: true
			};
		}
		return {
			handled: false
		};
	},
	right: function() {
		if (this.selectedIndex.x < this.widgetRows.getChild(this.selectedIndex.y).getChildCount() - 1) {
			this.selectedIndex.x++;
			if (this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x).isComponent) {
				return this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x).handleKey("focus");
			}
			return {
				selectedWidget: this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x),
				previousWidget: this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x - 1),
				handled: true
			};
		}
		return {
			handled: false
		};
	},
	up: function() {
		if (this.selectedIndex.y > 0) {
			this.selectedIndex.y--;
			if (this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x).isComponent) {
				return this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x).handleKey("focus");
			}
			return {
				selectedWidget: this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x),
				previousWidget: this.widgetRows.getChild(this.selectedIndex.y + 1).getChild(this.selectedIndex.x),
				handled: true
			};
		}
		return {
			handled: false
		};
	},
	down: function() {
		if (this.selectedIndex.y < this.widgetRows.getChildCount() - 1) {
			this.selectedIndex.y++;
			if (this.selectedIndex.x >= this.widgetRows.getChild(this.selectedIndex.y).getChildCount()) {
				this.selectedIndex.x = this.widgetRows.getChild(this.selectedIndex.y).getChildCount() - 1;
			}
			if (this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x).isComponent) {
				return this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x).handleKey("focus");
			}
			return {
				selectedWidget: this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x),
				previousWidget: this.widgetRows.getChild(this.selectedIndex.y - 1).getChild(this.selectedIndex.x),
				handled: true
			};
		}
		return {
			handled: false
		};
	},
	select: function() {
		return {
			selectedWidget: this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x),
			selectedIndex: this.selectedIndex
		};
	},
	focus: function() {
		return {
			selectedWidget: this.widgetRows.getChild(this.selectedIndex.y).getChild(this.selectedIndex.x),
			selectedIndex: this.selectedIndex,
			handled: true
		};
	}
};

exports = GridComponent;
