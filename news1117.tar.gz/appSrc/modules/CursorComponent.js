/*
Cursor Module

Usage:

//Require in the cursor component
var CursorComponent = Volt.require("modules/CursorComponent.js");

//Instantiate a new CursorComponent
//You can pass in an options argument with a color and border width property or 
//a ninePatch property with images for all 9 sides
var cursor = new CursorComponent();

//or

var cursor = new CursorComponent({
	color: {r:0, g:120, b:160, a:255},
	width: 15
});

//or 

var cursor = new CursorComponent({
	ninePatch: {
		left: "9patch_img/list_high_mid_left.png",
		right: "9patch_img/list_high_mid_right.png",
		top: "9patch_img/list_high_upper_center.png",
		bottom: "9patch_img/list_high_lower_center.png",
		topLeft: "9patch_img/list_high_upper_left.png",
		topRight: "9patch_img/list_high_upper_right.png",
		bottomRight: "9patch_img/list_high_lower_right.png",
		bottomLeft: "9patch_img/list_high_lower_left.png"
	}
});


//Call move to move the cursor to the desired position and dimentions
// .move(x, y, width, height, duration) duration defaults to 100
cursor.move(100, 200, 500, 500, 100);

//Show and hide the cursor
cursor.show() || cursor.hide()

*/

var defaults = {
			color: {
				r: 0,
				g: 120,
				b: 160,
				a: 255
			},
			width: 15
		},
		adjustment = -16; //Needed after screwing with original images 

var CursorComponent = function(options){
	var cursorWidget = new Widget(-200, -200);

	options = options || {};

	cursorWidget.color = {r:0, g:0, b:0, a:0};
	cursorWidget.parent = scene;
	cursorWidget.ninePatch = {};
	cursorWidget.isHidden = false;
	cursorWidget.prevWidth = 0;
	cursorWidget.prevHeight = 0;

	if (options.ninePatch) {
		cursorWidget.type = "ninePatch";

		cursorWidget.ninePatch.left = new ImageWidget({
			src: options.ninePatch.left,
			parent: cursorWidget
		});
		cursorWidget.ninePatch.right = new ImageWidget({
			src: options.ninePatch.right,
			parent: cursorWidget
		});
		cursorWidget.ninePatch.top = new ImageWidget({
			src: options.ninePatch.top,
			parent: cursorWidget
		});
		cursorWidget.ninePatch.bottom = new ImageWidget({
			src: options.ninePatch.bottom,
			parent: cursorWidget
		});

		cursorWidget.ninePatch.topLeft = new ImageWidget({
			src: options.ninePatch.topLeft,
			parent: cursorWidget
		});
		cursorWidget.ninePatch.topRight = new ImageWidget({
			src: options.ninePatch.topRight,
			parent: cursorWidget
		});
		cursorWidget.ninePatch.bottomRight = new ImageWidget({
			src: options.ninePatch.bottomRight,
			parent: cursorWidget
		});
		cursorWidget.ninePatch.bottomLeft = new ImageWidget({
			src: options.ninePatch.bottomLeft,
			parent: cursorWidget
		});

	} else {
		cursorWidget.type = "default";
		cursorWidget.border = {
			width: options.width || defaults.width,
			color: options.color || defaults.color
		};
	}

	//Set up methods on cursor widget
	cursorWidget.move = move;
	return cursorWidget;

};

var move = function(x, y, width, height, duration, callback) {
	duration = duration || 100;
	if (this.type === "ninePatch") {
		animateDimensions.call(this, width, height, duration);

		this.animate("x", x, duration);
		this.animate("y", y, duration, callback);
	} else {
		this.animate("height", height, duration);
		this.animate("width", width, duration);
		this.animate("x", x, duration);
		this.animate("y", y, duration, callback);
	}
};


//Setup image positions and scales

function animateDimensions(width, height, d) {
	//Setup image positions
	if (width == this.prevWidth && height == this.prevHeight) {
		return;
	}

	var cornerWidth = this.ninePatch.topLeft.width + adjustment;
	var cornerHeight = this.ninePatch.topLeft.height + adjustment;

    this.ninePatch.topLeft.animate("x", -cornerWidth, d);
	this.ninePatch.topLeft.animate("y", -cornerHeight, d);
	
	this.ninePatch.topRight.animate("x", width + adjustment, d);
	this.ninePatch.topRight.animate("y", -cornerHeight, d);
	
	this.ninePatch.bottomRight.animate("x", width + adjustment, d);
	this.ninePatch.bottomRight.animate("y", height + adjustment, d);

	this.ninePatch.bottomLeft.animate("x", -cornerWidth, d);
	this.ninePatch.bottomLeft.animate("y", height + adjustment, d);

	this.ninePatch.left.animate("x", -this.ninePatch.left.width - adjustment, d);
	this.ninePatch.left.animate("y", -adjustment, d);

	this.ninePatch.right.animate("x", width + adjustment, d);
	this.ninePatch.right.animate("y", -adjustment, d);

    this.ninePatch.top.animate("x", -adjustment, d);
	this.ninePatch.top.animate("y", -this.ninePatch.top.height - adjustment, d);

	this.ninePatch.bottom.animate("x", -adjustment, d);
	this.ninePatch.bottom.animate("y", height + adjustment, d);

	this.ninePatch.left.animate("height", height + adjustment * 2, d);
	this.ninePatch.right.animate("height", height + adjustment * 2, d);
	this.ninePatch.top.animate("width", width + adjustment * 2, d);
	this.ninePatch.bottom.animate("width", width + adjustment * 2, d);

	this.prevWidth = width;
	this.prevHeight = height;
}


exports = CursorComponent;
