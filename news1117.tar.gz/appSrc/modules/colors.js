var RED = {r: 255, g: 0, b:0, a:255};
var GREEN = {r: 0, g: 255, b:0, a:255};
var BLUE = {r: 0, g: 0, b:255, a:255};
var BLACK = {r: 0, g: 0, b:0, a:255};
var WHITE = {r: 255, g: 255, b:255, a:255};
var GREY = {r:90, g:90, b:90, a:255};
var LIGHT_GREY = {r:140, g:140, b:140, a:255};
var BRIGHT_ORANGE = {r:224, g:86, b:0, a:150};

exports.RED = RED;
exports.GREEN = GREEN;
exports.BLUE = BLUE;
exports.BLACK = BLACK;
exports.WHITE = WHITE;
exports.LIGHT_GREY = LIGHT_GREY;
exports.BRIGHT_ORANGE = BRIGHT_ORANGE;

