winsetMessageBox = function(obj){		
	// local var
	var style = MessageBoxStyle.MessageBox_Title_Button_1Line,
		resoultion = ResoultionStyle.Resoultion_1080,
		path = "$VOLT_ROOT/modules/WinsetUIElement/winsetImg/",
		messagebox,
		x = 0,
		y = 0,
		screenWidth = 1920,
		screenHeight = 1080,
		width,
		height,
		bTitle,
		bButton,
		bgcolor,
		// background
		bgStyle,
		// title
		titleText,
        titleTextFont,
        titleTextColor,
        titleHeightRate,
        titleRect = {},
        // content text
        contentNumber,
        contentLine,
        contentText,
        contentTextFont,
        contentTextColor,
        contentRect = {},
        contentText2,
        contentText2Font,
        contentText2Color,
        content2Rect = {},
        // button attr
        buttonStyle,
        buttonType,
        button1Rect = {},
        button2Rect = {},
        button_1_Text,
        button_2_Text,
        buttonBgNormal,
		buttonBgFoucs,
		buttonBgSelect,
		buttonBgDim,
		buttonBgNormalColor,
		buttonBgFoucsColor,
		buttonBgSelectColor,
		buttonBgDimColor,
		normalFont,
		focusFont,
		selectFont,
		dimFont,
		normalTextColor,
		focusTextColor,
		selectTextColor,
		dimTextColor;	
        
				
	var m_analysisParameter = function(objParameter){
		if("undefined" != objParameter){
			if (objParameter.hasOwnProperty("style") 
				&& (typeof objParameter.style == "number")
				&& (MessageBoxStyle.MessageBox_Title_Button_1Line <= objParameter.style)
				&& (MessageBoxStyle.MessageBox_3Line_Loading >= objParameter.style)){
				
				style = objParameter.style;		
			}
		
			if (objParameter.hasOwnProperty("nResoultionStyle") 
				&& (typeof objParameter.nResoultionStyle == "number")
				&& (ResoultionStyle.Resoultion_720 <= objParameter.nResoultionStyle)
				&& (ResoultionStyle.Resoultion_Style_MAX > objParameter.nResoultionStyle)){
					resoultion = objParameter.nResoultionStyle;
			}			
			
			if(objParameter.hasOwnProperty("x")
				&& (typeof objParameter.x == "number")){
				x = objParameter.x;	
			}
			
			if(objParameter.hasOwnProperty("y")
				&& (typeof objParameter.y == "number")){
				y = objParameter.y;	
			}	
			
			if(objParameter.hasOwnProperty("width")
				&& (typeof objParameter.width == "number")){
				width = objParameter.width;	
			}	
			
			if(objParameter.hasOwnProperty("height")
				&& (typeof objParameter.height == "number")){
				height = objParameter.height;	
			}
			
			if(objParameter.hasOwnProperty("backgroundStyle")
				&& (typeof objParameter.backgroundStyle == "number")){
				bgStyle = objParameter.backgroundStyle;	
			}
			
			if(objParameter.hasOwnProperty("buttonStyle")
				&& (typeof objParameter.buttonStyle == "number")){
				buttonStyle = objParameter.buttonStyle;	
			}
		}
	}
			
	var m_setDefaultValueByProgressStyle = function(){
		// set resource path
		if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
			path = path + "1080p/btn/";
			width = 1920;
			height = 1080 * 0.351852;
			screenWidth = 1920;
			screenHeight = 1080;
		} else if (resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
			path = path + "720p/btn/";
			width = 1280;
			height = 720 * 0.351852;
			screenWidth = 1280;
			screenHeight = 720;
		}
		//set default value
		switch(style)
		{
			case MessageBoxStyle.MessageBox_Title_Button_1Line:
				{
					bTitle = true;
					bgcolor = {r: 39, g: 124, b: 175, a: 200};
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						titleTextFont = "Sans 44px";
						contentTextFont = "Sans 34px";
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
						titleTextFont = "Sans 30px";
						contentTextFont = "Sans 22px";
					}
					titleText = "Message Popup";
			       	titleTextColor = { r: 255, g: 255, b: 255, a: 255 };
			       	titleRect.x = (1 - 0.584375)/2 * screenWidth;
			       	titleRect.y = 0;
			       	titleRect.width = 0.584375 * screenWidth;
			       	titleRect.height = 0.089815 * screenHeight;
			       
			        // content text
			        contentNumber = 1;
			        contentLine = "single_line_content_type";
			        contentText = "Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup";
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = (0.089815 + 0.063889) * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight;
			    
			        // button
			        bButton = true;
					buttonType = "button_2";
				}
				break;
			
			case MessageBoxStyle.MessageBox_Title_Button_2_8Line:
				{
					bTitle = true;
					bgcolor = {r: 39, g: 124, b: 175, a: 200};
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						titleTextFont = "Sans 44px";
						contentTextFont = "Sans 34px";
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
						titleTextFont = "Sans 30px";
						contentTextFont = "Sans 22px";
					}
					titleText = "Message Popup";
			       	titleTextColor = { r: 255, g: 255, b: 255, a: 255 };
			       	titleRect.x = (1 - 0.584375)/2 * screenWidth;
			       	titleRect.y = 0;
			       	titleRect.width = 0.584375 * screenWidth;
			       	titleRect.height = 0.089815 * screenHeight;
			       
			        // content text
			        contentNumber = 1;
			        contentLine = "multi_line_content_type";
			        contentText = "Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Popup Message";
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = (0.089815 + 0.063889) * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight;
			    
			        // button
			        bButton = true;
					buttonType = "button_2";
				}
				break;
				
			case MessageBoxStyle.MessageBox_NoTitle_Button_1Line:
				{
					bTitle = false;
					bgcolor = {r: 39, g: 124, b: 175, a: 200};
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						titleTextFont = "Sans 44px";
						contentTextFont = "Sans 34px";
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
						titleTextFont = "Sans 30px";
						contentTextFont = "Sans 22px";
					}
					
			        // content text
			        contentNumber = 1;
			        contentLine = "single_line_content_type";
			        contentText = "Message Popup Message Popup Message Popup Message Popup Message Popup Message";
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = (0.089815 + 0.063889) * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight;
			    
			        // button
			        bButton = true;
					buttonType = "button_2";
				}
				break;	
			
			case MessageBoxStyle.MessageBox_NoTitle_Button_2_8Line:
				{
					bTitle = false;
					bgcolor = {r: 39, g: 124, b: 175, a: 200};
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						contentTextFont = "Sans 34px";
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
						contentTextFont = "Sans 22px";
					}
					
			        // content text
			        contentNumber = 1;
			        contentLine = "multi_line_content_type";
			        contentText = "Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Popup Message";
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = (0.089815 + 0.063889) * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight;
			    
			        // button
			        bButton = true;
					buttonType = "button_2";
				}
				break;
				
			case MessageBoxStyle.MessageBox_NoTitle_Button_Message_Text_Align:
				{
					bTitle = false;
					bgcolor = {r: 39, g: 124, b: 175, a: 200};
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						contentTextFont = "Sans 34px";
						contentText2Font = "Sans 34px"
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
						contentTextFont = "Sans 22px";
						contentText2Font = "Sans 22px";
					}
					
			        // content text
			        contentNumber = 2;
			        contentLine = "multi_line_with_single_line_content_type";
			        contentText = "Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Popup Message";
			        contentText2 = "Message Popup Message Popup Message Popup";
			        
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			        contentText2Color ={ r: 69, g: 187, b: 163, a: 230 };
			        
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = (0.089815 + 0.063889) * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight;
			    
			        // button
			        bButton = true;
					buttonType = "button_2";
				}
				break;
				
			case MessageBoxStyle.MessageBox_NoTitle_NoButton:
				{
					bTitle = false;
					bgcolor = {r: 39, g: 124, b: 175, a: 200};
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						contentTextFont = "Sans 34px";
						contentText2Font = "Sans 34px"
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
						contentTextFont = "Sans 22px";
						contentText2Font = "Sans 22px";
					}
					
			        // content text
			        contentNumber = 1;
			        contentLine = "multi_line_content_type";
			        contentText = "Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Popup Message";
			        
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			     
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = (0.089815 + 0.063889) * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight;
			    
			        // button
			        bButton = false;
					buttonType = "no_button";
				}
				break;
			
			case MessageBoxStyle.MessageBox_1Line:
			case MessageBox_1Line_Loading:
			case MessageBox_2Line_Loading:
			case MessageBox_3Line_Loading:
				{
					bTitle = false;
					bgcolor = {r: 39, g: 124, b: 175, a: 200};
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						contentTextFont = "Sans 34px";
						contentText2Font = "Sans 34px"
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
						contentTextFont = "Sans 22px";
						contentText2Font = "Sans 22px";
					}
					
			        // content text
			        contentNumber = 1;
			        contentLine = "single_line_content_type";
			        contentText = "Message Popup Message Popup Message Popup Message Popup Message Popup Message";
			        
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			     
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = (0.089815 + 0.063889) * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight;
			    
			        // button
			        bButton = false;
					buttonType = "no_button";
				}
				break;	
			default:
				break;
		}
		
		if(true == bButton){
			if(buttonStyle = ButtonStyle.Button_Style_A){
				button_1_Text = "OK";
				button_2_Text = "Cancel";
				
				// rect
				// button1Rect.x = 
				// button1Rect.y =
				// button1Rect.width = 
				// button1Rect.height =
			  
			    // background
			    buttonBgNormal = path + "btn_style_a_n.png";
				buttonBgFoucs = path + "btn_style_a_f.png";
				buttonBgSelect = path + "btn_style_a_s.png";
				buttonBgDim = path + "btn_style_a_d.png";
				
				buttonBgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
				buttonBgFoucsColor = { r: 33, g: 158, b: 230, a: 255 };
				buttonBgSelectColor = { r: 0, g: 0, b: 0, a: 13 };
				buttonBgDimColor = { r: 255, g: 255, b: 255, a: 0 };
				
				if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
					// text fontsize
					normalFont = "Sans 32px";
					focusFont = "Sans 36px";
					selectFont = "Sans 36px";
					dimFont = "Sans 32px";
				} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
					// text fontsize
					normalFont = "Sans 21px";
					focusFont = "Sans 24px";
					selectFont = "Sans 24px";
					dimFont = "Sans 24px";
				}
				
				// text color
				normalTextColor = { r: 64, g: 64, b: 64, a: 0 };
				focusTextColor = { r: 244, g: 244, b: 244, a: 255 };
				selectTextColor = { r: 241, g: 171, b: 21, a: 255 };
				dimTextColor = { r: 64, g: 64, b: 64, a: 0 };	   
			}
	        
			 if(buttonStyle = ButtonStyle.Button_Style_B_Focus1){
				button_1_Text = "OK";
				button_2_Text = "Cancel";
				
				// rect
				// button1Rect.x = 
				// button1Rect.y =
				// button1Rect.width = 
				// button1Rect.height =
			  
			    // background
			    buttonBgNormal = path + "btn_style_a_n.png";
				buttonBgFoucs = path + "btn_style_a_f.png";
				buttonBgSelect = path + "btn_style_a_s.png";
				buttonBgDim = path + "btn_style_a_d.png";
				
				buttonBgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
				buttonBgFoucsColor = { r: 33, g: 158, b: 230, a: 255 };
				buttonBgSelectColor = { r: 0, g: 0, b: 0, a: 13 };
				buttonBgDimColor = { r: 255, g: 255, b: 255, a: 0 };
				
				if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
					// text fontsize
					normalFont = "Sans 32px";
					focusFont = "Sans 36px";
					selectFont = "Sans 36px";
					dimFont = "Sans 32px";
				} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
					// text fontsize
					normalFont = "Sans 21px";
					focusFont = "Sans 24px";
					selectFont = "Sans 24px";
					dimFont = "Sans 24px";
				}
				
				// text color
				normalTextColor = { r: 64, g: 64, b: 64, a: 0 };
				focusTextColor = { r: 244, g: 244, b: 244, a: 255 };
				selectTextColor = { r: 241, g: 171, b: 21, a: 255 };
				dimTextColor = { r: 64, g: 64, b: 64, a: 0 };	   
			}
			
			 if(buttonStyle = ButtonStyle.Button_Style_B_Focus2){
				button_1_Text = "OK";
				button_2_Text = "Cancel";
				
				// rect
				// button1Rect.x = 
				// button1Rect.y =
				// button1Rect.width = 
				// button1Rect.height =
			  
			    // background
			    buttonBgNormal = path + "btn_style_b_n.png";
				buttonBgFoucs = path + "btn_style_b_f.png";
				buttonBgSelect = path + "btn_style_b_s.png";
				buttonBgDim = path + "btn_style_b_d.png";
				
				buttonBgNormalColor = { r: 255, g: 255, b: 255, a: 0 };
				buttonBgFoucsColor = { r: 255, g: 255, b: 255, a: 242 };
				buttonBgSelectColor = { r: 0, g: 0, b: 0, a: 13 };
				buttonBgDimColor = { r: 255, g: 255, b: 255, a: 0 };
				
				if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
					// text fontsize
					normalFont = "Sans 32px";
					focusFont = "Sans 36px";
					selectFont = "Sans 36px";
					dimFont = "Sans 32px";
				} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
					// text fontsize
					normalFont = "Sans 21px";
					focusFont = "Sans 24px";
					selectFont = "Sans 24px";
					dimFont = "Sans 24px";
				}
				
				// text color	
				normalTextColor = { r: 255, g: 255, b: 255, a: 204 };
				focusTextColor = { r: 70, g: 70, b: 70, a: 255 };
				selectTextColor = { r: 233, g: 179, b: 33, a: 255 };
				dimTextColor = { r: 255, g: 255, b: 255, a: 76 };	   
			} 
		}
	}
	
	var getResoultion = function(){
		return ResoultionStyle.Resoultion_1080;
	}
	
	// resoultion = getResoultion();		
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	print("path is ------------ " + buttonBgNormal);
	//create Messagebox instance 
	messagebox = new MessageBox({
	//	 x: 0,
	//	 y: (screenHeight - height)/2,
		 bTitle: bTitle,
		// bAutoFlag: false,
		 width: 1920,
         height: 1080,
         color: {r: 39, g: 124, b: 175, a: 200},
         contentType: contentLine,
         buttonType: buttonType
	});
	
	messagebox.color = bgcolor;
	
	// title
	if(true == bTitle){
		messagebox.setTitleText(titleText);
		//messagebox.setTitleRect(titleRect.x, titleRect.y, titleRect.width, titleRect.height);
		messagebox.setTitleTextColor(titleTextColor.r, titleTextColor.g, titleTextColor.b, titleTextColor.a);
		messagebox.setTitleTextFont(titleTextFont);
		//messagebox.setTitleLineColor(255, 255, 255, 255);
	}
	
	
	// content text
	if(1 == contentNumber){
		messagebox.setContentTextFont(contentTextFont);
		messagebox.setContentText(contentText);
		//messagebox.setContentRect(contentRect.x, contentRect.y, contentRect.width, contentRect.height);
		messagebox.setContentTextColor(contentTextColor.r, contentTextColor.g, contentTextColor.b, contentTextColor.a);
		
	}
	if(2 == contentNumber){
		messagebox.setContentTextFont(contentTextFont);
		messagebox.setContentText(contentText);
		//messagebox.setContentRect(contentRect.x, contentRect.y, contentRect.width, contentRect.height);
		messagebox.setContentTextColor(contentTextColor.r, contentTextColor.g, contentTextColor.b, contentTextColor.a);
		
		messagebox.setContentText2Font(contentText2Font);
		messagebox.setContentText2(contentText2);
		//messagebox.setContentRect(contentRect.x, contentRect.y, contentRect.width, contentRect.height);
		messagebox.setContentText2Color(contentText2Color.r, contentText2Color.g, contentText2Color.b, contentText2Color.a);
		
	}
	
	
	if(true == bButton){
		// button1
		//messagebox.setButtonRect();
		
		messagebox.setButtonImage("button_all", "normal", buttonBgNormal);
		messagebox.setButtonImage("button_all", "focused", buttonBgFoucs);
		messagebox.setButtonImage("button_all", "selected", buttonBgSelect);
		messagebox.setButtonImage("button_all", "disabled", buttonBgDim);
		
		messagebox.setButtonTextColor("button_all", "normal", normalTextColor.r, normalTextColor.g, normalTextColor.b, normalTextColor.a);
		messagebox.setButtonTextColor("button_all", "focused", focusTextColor.r, focusTextColor.g, focusTextColor.b, focusTextColor.a);
		messagebox.setButtonTextColor("button_all", "selected", selectTextColor.r, selectTextColor.g, selectTextColor.b, selectTextColor.a);
		messagebox.setButtonTextColor("button_all", "disabled", dimTextColor.r, dimTextColor.g, dimTextColor.b, dimTextColor.a);
		
		messagebox.setButtonTextFontSize("button_all", "normal", normalFont);
		messagebox.setButtonTextFontSize("button_all", "focused", focusFont);
		messagebox.setButtonTextFontSize("button_all", "selected", selectFont);
		messagebox.setButtonTextFontSize("button_all", "disabled", dimFont);
		
		messagebox.setButtonText("button_1", "all", button_1_Text);
		messagebox.setButtonText("button_2", "all", button_2_Text);
		
		// button2
		
		
	}    
	
	return messagebox;	
}

var MessageBoxStyle = {
		MessageBox_Title_Button_1Line:1,
		MessageBox_Title_Button_2_8Line:2,
		MessageBox_NoTitle_Button_1Line:3,
		MessageBox_NoTitle_Button_2_8Line:4,
		MessageBox_NoTitle_Button_Message_Text_Align:5,
		MessageBox_NoTitle_NoButton:6,
		MessageBox_1Line:7,
		MessageBox_1Line_Loading:8,
		MessageBox_2Line_Loading:9,
		MessageBox_3Line_Loading:10
	};
	
var BackgroundStyle = {
		Background_Style_B_1:1,
		Background_Style_B_2:2,
		Background_Style_B_3:3
	};
	
var ButtonStyle = {
		Button_Style_A: 1,
		Button_Style_B_Focus1: 2,
		Button_Style_B_Focus2: 3
	};
	
var ResoultionStyle = {
	Resoultion_720:0,	
	Resoultion_1080:1,
	Resoultion_720_21_9:2,
	Resoultion_1080_21_9:3,	
	Resoultion_Style_MAX:4
};	

winsetMessageBox.MessageBoxStyle = MessageBoxStyle;
winsetMessageBox.BackgroundStyle = BackgroundStyle;
winsetMessageBox.ButtonStyle = ButtonStyle;
winsetMessageBox.ResoultionStyle = ResoultionStyle;

exports = winsetMessageBox;
