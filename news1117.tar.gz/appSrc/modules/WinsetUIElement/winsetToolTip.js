winsetToolTip = function(obj) {
	// local var
	var balloon,
		height = 300,
		width = 300,
		x = 1500,
		y = 0,
		style = TooltipStyle.Balloon_Tail_Down,
		resoultion = ResoultionStyle.Resoultion_1080,
		path = "$VOLT_ROOT/modules/WinsetUIElement/winsetImg/",
		popup_image,
		tail_image,
		tail_width,
		tail_height,
		tail_side,
	    tail_distance,
	    tail_offset,
	    font_size,
	    tailPostion = "start",
	    text_background_color;
		
	   	
	var m_analysisParameter = function(objParameter){
		if("undefined" != objParameter){
			if (objParameter.hasOwnProperty("style") 
				&& (typeof objParameter.style == "number")
				&& (TooltipStyle.Tooltip_Tail_Down <= objParameter.style)
				&& (TooltipStyle.Tooltip_Tail_Right >= objParameter.style)){
				
				style = objParameter.style;		
			}
			
			if (objParameter.hasOwnProperty("nResoultionStyle") 
				&& (typeof objParameter.nResoultionStyle == "number")
				&& (ResoultionStyle.Resoultion_720 <= objParameter.nResoultionStyle)
				&& (ResoultionStyle.Resoultion_Style_MAX > objParameter.nResoultionStyle)){
					resoultion = objParameter.nResoultionStyle;
			}				
		
			if(objParameter.hasOwnProperty("x")
				&& (typeof objParameter.x == "number")){
				x = objParameter.x;	
			}
			
			if(objParameter.hasOwnProperty("y")
				&& (typeof objParameter.y == "number")){
				y = objParameter.y;	
			}
			
			if(objParameter.hasOwnProperty("height")
				&& (typeof objParameter.height == "number")){
				height = objParameter.height;	
			}
			
			if(objParameter.hasOwnProperty("width")
				&& (typeof objParameter.width == "number")){
				width = objParameter.width;	
			}
			
			if(objParameter.hasOwnProperty("tailPostion")
				&& (typeof objParameter.tailPostion == "string")){
				tailPostion = objParameter.tailPostion;	
			}	
		}	
	}

	var m_setDefaultValueByProgressStyle = function(){
		// set resource path
		if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
			path = path + "1080p/balloon/";
		} else if (resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
			path = path + "720p/balloon/";
		}
		
		text_background_color = { r: 255, g: 255, b: 255, a: 255 }
		//set default value
		switch(style)
		{
			case TooltipStyle.Tooltip_Tail_Down:
				{
					// image path
					popup_image = path + "popup_balloon.png";
					tail_image = path + "popup_balloon_tail_d.png";
					
					tail_side = "down";
					
				   
					if(resoultion == ResoultionStyle.Resoultion_1080|| resoultion == ResoultionStyle.Resoultion_1080_21_9){
						tail_width = 18;
						tail_height = 12;
						tail_offset = -3;
						font_name = "Sans 30px";
						font_size = 30;
						if("start" == tailPostion){
							tail_distance = 12;
						}
						if("center" == tailPostion){
							tail_distance = (width - tail_width)/2;
						}
						if("end" == tailPostion){
							tail_distance = width - tail_width - 12;
						}
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						tail_width = 12;
						tail_height = 8;
						tail_offset = -2;
						font_name = "Sans 20px";
						font_size = 20;
						if("start" == tailPostion){
							tail_distance = 8;
						}
						if("center" == tailPostion){
							tail_distance = (width - tail_width)/2;
						}
						if("end" == tailPostion){
							tail_distance = width - tail_width - 8;
						}			
					}
				}
				break;
			
			case TooltipStyle.Tooltip_Tail_Up:
				{
					// image path
					popup_image = path + "popup_balloon.png";
					tail_image = path + "popup_balloon_tail_u.png";
					
					tail_side = "up";
					
					if(resoultion == ResoultionStyle.Resoultion_1080|| resoultion == ResoultionStyle.Resoultion_1080_21_9){
						tail_width = 18;
						tail_height = 12;
						tail_offset = -3;
						font_name = "Sans 30px";
						font_size = 30;
						if("start" == tailPostion){
							tail_distance = 12;
						}
						if("center" == tailPostion){
							tail_distance = (width - tail_width)/2;
						}
						if("end" == tailPostion){
							tail_distance = width - tail_width - 12;
						}
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						tail_width = 12;
						tail_height = 8;
						tail_offset = -2;
						font_name = "Sans 20px";
						font_size = 20;
						if("start" == tailPostion){
							tail_distance = 8;
						}
						if("center" == tailPostion){
							tail_distance = (width - tail_width)/2;
						}
						if("end" == tailPostion){
							tail_distance = width - tail_width - 8;
						}			
					}
				}
				break;
				
			case TooltipStyle.Tooltip_Tail_Left:
				{
					// image path
					popup_image = path + "popup_balloon.png";
					tail_image = path + "popup_balloon_tail_l.png";
					
					tail_side = "left";
					
					if(resoultion == ResoultionStyle.Resoultion_1080|| resoultion == ResoultionStyle.Resoultion_1080_21_9){
						tail_width = 12;
						tail_height = 18;
						tail_offset = -3;
						font_name = "Sans 30px";
						font_size = 30;
						if("start" == tailPostion){
							tail_distance = 6;
						}
						if("center" == tailPostion){
							tail_distance = (height - tail_height)/2;
						}
						if("end" == tailPostion){
							tail_distance = height - tail_height - 6;
						}
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						tail_width = 8;
						tail_height = 12;
						tail_offset = -2;
						font_name = "Sans 20px";
						font_size = 20;
						if("start" == tailPostion){
							tail_distance = 4;
						}
						if("center" == tailPostion){
							tail_distance = (height - tail_height)/2;
						}
						if("end" == tailPostion){
							tail_distance = height - tail_height - 4;
						}			
					}
				}
				break;
				
			case TooltipStyle.Tooltip_Tail_Right:
				{
					// image path
					popup_image = path + "popup_balloon.png";
					tail_image = path + "popup_balloon_tail_r.png";
					
					tail_side = "right";
					
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						tail_width = 12;
						tail_height = 18;
						tail_offset = -3;
						font_name = "Sans 30px";
						font_size = 30;
						if("start" == tailPostion){
							tail_distance = 6;
						}
						if("center" == tailPostion){
							tail_distance = (height - tail_height)/2;
						}
						if("end" == tailPostion){
							tail_distance = height - tail_height - 6;
						}
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						tail_width = 8;
						tail_height = 12;
						tail_offset = -2;
						font_name = "Sans 20px";
						font_size = 20;
						if("start" == tailPostion){
							tail_distance = 4;
						}
						if("center" == tailPostion){
							tail_distance = (height - tail_height)/2;
						}
						if("end" == tailPostion){
							tail_distance = height - tail_height - 4;
						}			
					}
				}
				break;
				
			default:
				break;
		}
	}

	var getResoultion = function(){
		return ResoultionStyle.Resoultion_1080;
	}
	
	// resoultion = getResoultion();		
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	print("path is ------------ " + tail_image);
	balloon = new ToolTip({
		x: x,
	    y: y,
	    width: width,
	    height: height,
	    popup_image: popup_image,
	    tail_image: tail_image,
	    tail_width: tail_width,
	    tail_height: tail_height,
	    tail_side: tail_side,
	    tail_distance: tail_distance,
	    tail_offset: -4,
	    text: "ToolTipMoreWordMoreWords",
	    font_name: font_name,
	    font_size: font_size,
	    text_background_color: text_background_color,
	    frame_color: { r: 64, g: 64, b: 64, a: 204 },
    	frame_width: 3
	});
	balloon.color = { r: 64, g: 64, b: 64, a: 204 };
	
	return balloon;
};

var TooltipStyle = {
	Tooltip_Tail_Down:1,
	Tooltip_Tail_Up:2,
	Tooltip_Tail_Left:3,
	Tooltip_Tail_Right:4
};

var ResoultionStyle = {
	Resoultion_720:0,	
	Resoultion_1080:1,
	Resoultion_720_21_9:2,
	Resoultion_1080_21_9:3,	
	Resoultion_Style_MAX:4
};

winsetToolTip.TooltipStyle = TooltipStyle;
winsetToolTip.ResoultionStyle = ResoultionStyle;
exports = winsetToolTip;

