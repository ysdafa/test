winsetPinNumberPopup = function (objParameter){
	var m_pInstance = null;
	//default value
	var m_defaultParent = scene;
	var m_imagePath	= "$VOLT_ROOT/modules/WinsetUIElement/winsetImg/";
	var m_pinNumberPopupStyle = 0;
	var m_resoultionStyle = 0;	
	
	var m_defaultBgColor = { r: 39, g: 124, b: 175, a: 200 };
	var m_defaultX = 0;
	var m_defaultY = 0;
	var m_defaultWidth = 1920;
	var m_defaultHeight = 1080;

	var m_defaultPinType = "pinbox_two";
	var m_defaultHasTitle = true;
	var m_defaultContentText = "this is the pin number popup";
	var m_defaultTitle = "PIN TITLE";
	
	var m_defaultPinBoxBGFocusImage = "";
	var m_defaultPinBoxBGNormalImage = "";
	var m_defaultPinBoxItemFcousImage = "";
	var m_defaultPinBoxItemNormalImage = "";
	var m_defaultPinBoxTextOne = " First Input";
	var m_defaultPinBoxTextTwo = " Second Input";
	
	var m_create = function(objParameter){
		//analysis parameter
		m_analysisParameter(objParameter);
		
		//set default value
		m_setDefaultValueByPinNumberPopupStyle();
	
		print("000" + m_defaultPinBoxBGFocusImage);		
		//create PinPopup instance 
		m_pInstance = new PinPopup({
			parent: m_defaultParent,
			width: m_defaultWidth,
			height: m_defaultHeight ,
			pinType: m_defaultPinType,
			isTitle: m_defaultHasTitle,
			color: m_defaultBgColor,
			contenttext : m_defaultContentText,
			title : m_defaultTitle
		});		
		
		m_pInstance.setPinBoxBackGroundImage({ state: "focus_state", src: m_defaultPinBoxBGFocusImage});
		m_pInstance.setPinBoxBackGroundImage({ state: "normal_state", src: m_defaultPinBoxBGNormalImage});
		m_pInstance.setPinBoxItemImage({ state: "no_input_type", src: m_defaultPinBoxItemFcousImage});
		m_pInstance.setPinBoxItemImage({ state: "finish_input_type", src: m_defaultPinBoxItemNormalImage});
		m_pInstance.setPinBoxDescriptionText({ pintype: "pinbox_one", text: m_defaultPinBoxTextOne });
		m_pInstance.setPinBoxDescriptionText({ pintype: "pinbox_two", text: m_defaultPinBoxTextTwo });
		//m_pInstance.setPinBoxFocus({pintype:"pinbox_one"});
		
		return m_pInstance;
	}
	
	var m_analysisParameter = function(objParameter){
		if("undefined" == objParameter){
			return;
		}

		if (objParameter.hasOwnProperty("nPinNumberPopupStyle") 
			&& (typeof objParameter.nPinNumberPopupStyle == "number")
			&& (PopUpRatingStyle.PinNumberPopupStyle_MAX > objParameter.nPinNumberPopupStyle)){		
				m_pinNumberPopupStyle = objParameter.nPinNumberPopupStyle;
		}
		
		if (objParameter.hasOwnProperty("nResoultionStyle") 
			&& (typeof objParameter.nResoultionStyle == "number")
			&& (ResoultionStyle.Resoultion_720 <= objParameter.nResoultionStyle)
			&& (ResoultionStyle.Resoultion_Style_MAX > objParameter.nResoultionStyle)){
				m_resoultionStyle = objParameter.nResoultionStyle;
		}
			
		if(objParameter.hasOwnProperty("parent")
			&& (typeof objParameter.parent == "number")){
			m_defaultParent = objParameter.parent;
		}	
		
		if(objParameter.hasOwnProperty("x")
			&& (typeof objParameter.x == "number")){
			m_defaultX = objParameter.x;	
		}
		
		if(objParameter.hasOwnProperty("y")
			&& (typeof objParameter.y == "number")){
			m_defaultY = objParameter.y;	
		}	
		
		if(objParameter.hasOwnProperty("width")
			&& (typeof objParameter.width == "number")){
			m_defaultWidth = objParameter.width;	
		}	
		
		if(objParameter.hasOwnProperty("height")
			&& (typeof objParameter.height == "number")){
			m_defaultHeight = objParameter.height;
		}	
	
	}
	
	var m_setDefaultValueByPinNumberPopupStyle = function(){
		// set resource path
		if(m_resoultionStyle == ResoultionStyle.Resoultion_1080 || m_resoultionStyle == ResoultionStyle.Resoultion_1080_21_9){
			m_imagePath = m_imagePath + "1080p/pinNumberPopup/";
		} else if (m_resoultionStyle == ResoultionStyle.Resoultion_720 || m_resoultionStyle == ResoultionStyle.Resoultion_720_21_9){
			m_imagePath = m_imagePath + "720p/pinNumberPopup/";
		}
		
		m_defaultPinBoxBGFocusImage = m_imagePath + "input_box_style_a_f.png";
		m_defaultPinBoxBGNormalImage = m_imagePath + "input_box_n.png";
		m_defaultPinBoxItemFcousImage = m_imagePath + "obe_pin_f.png";
		m_defaultPinBoxItemNormalImage = m_imagePath + "obe_pin_n.png";
		
		
		switch(m_resoultionStyle){
			case ResoultionStyle.Resoultion_1080:{
				m_defaultWidth = 1920;
				m_defaultHeight = 1080;
			}
			break;
			
			case ResoultionStyle.Resoultion_1080_21_9:{
				m_defaultWidth = 2520;
				m_defaultHeight = 1080;
			}
			break;
			
			case ResoultionStyle.Resoultion_720:{
				m_defaultWidth = 1280;
				m_defaultHeight = 720;			
			}
			break;
			
			case ResoultionStyle.Resoultion_720_21_9:{
				m_defaultWidth = 1680;
				m_defaultHeight = 720;	
			}
			break;
		}
	}

	//return the instance of native PinNumberPopup	
	return m_create(objParameter);		
}

//style type
var PinNumberPopupStyle = {
	PinNumberPopupStyle_MAX:0,
};
		
var ResoultionStyle = {
	Resoultion_720:0,	
	Resoultion_1080:1,
	Resoultion_720_21_9:2,
	Resoultion_1080_21_9:3,	
	Resoultion_Style_MAX:4,
};

winsetPinNumberPopup.PinNumberPopupStyle = PinNumberPopupStyle;
winsetPinNumberPopup.ResoultionStyle = ResoultionStyle;

exports = winsetPinNumberPopup;

