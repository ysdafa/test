winsetPopUpRating = function (objParameter){	
	var m_pInstance = null;
	//default value
	var m_defaultParent = scene;
	var m_imagePath	= "$VOLT_ROOT/modules/WinsetUIElement/winsetImg/";
	var m_popUpRatingStyle = 0;
	var m_resoultionStyle = 0;	
	
	var m_defaultBgColor = {r: 39, g: 124, b: 175, a: 200};
	var m_defaultX = 0;
	var m_defaultY = 0;
	var m_defaultWidth = 1920;
	var m_defaultHeight = 418;

	var m_defaultTitleColor = {r: 255, g: 255, b: 255, a: 255};
	var m_defaultTitleSize = "Sans 44px";
	var m_defaultTitleX = 569;
	var m_defaultTitleY = 0;
	var m_defaultTitleWidth = 782;
	var m_defaultTitleHeight = 97;

	var m_defaultContentColor = {r: 255, g: 255, b: 255, a: 255};
	var m_defaultContenSize =  "Sans 34px";	
	var m_defaultContentX = 569;
	var m_defaultContentY = 108;
	var m_defaultContentWidth = 782;
	var m_defaultContentHeight = 96;

	var m_defaultLeftArrowX = 717;
	var m_defaultLeftArrowY = 108 + 96 + 21;
	var m_defaultLeftArrowWidth = 62;
	var m_defaultLeftArrowHeight = 62;
	
	var m_defaultRightArrowX = 817 + 57* 5+ 100;
	var m_defaultRightArrowY = 108 + 96 + 21;
	var m_defaultRightArrowWidth = 62;
	var m_defaultRightArrowHeight = 62;
	
	var m_defaultStarIconWidthWithGap = 57;
	var m_defaultFirstStarIconX = 817
	var m_defaultFirstStarIconY = 108 + 96 + 26;
	var m_defaultFirstStarIconWidth = 46;
	var m_defaultFirstStarIconHeight = 46;
	
	var m_defaultOkX = 817 - 135;
	var m_defaultOkY = 250 + 46 + 35;
	var m_defaultOkWidth = 270;
	var m_defaultOkHeight = 66;
	var m_defaultOkText = "OK";
	var m_defaultOkSize = 32;
	
	var m_defaultCancelX = 817 + 57* 5 - 135;
	var m_defaultCancelY = 250 + 46 + 35;
	var m_defaultCancelWidth=270;
	var m_defaultCancelHeight=66;
	var m_defaultCancelText = "Cancel";
	var m_defaultCancelSize = 36;
	
	var m_defaultTitle ="Test PopupRating";
	var m_defaultContent ="This is the popupRating!";
	var m_defaultMarkedImage = "";
	var m_defaultunMarkedImage = "";
	var m_defaultHalfMarkedImage = "";
	var m_defaultNormalLeftArrowImage = "";
	var m_defaultFocusLeftArrowImage = "";
	var m_defaultDisabledLeftArrowImage = "";
	var m_defaultNormalRightArrowImage = "";
	var m_defaultFocusRightArrowImage = "";
	var m_defaultDisabledRightArrowImage = "";
	var m_defaultNormalButtonImagePath = "";
	var m_defaultFocusButtonImagePath = "";
	
var m_create = function(objParameter){
	//analysis parameter
	m_analysisParameter(objParameter);
	
	//set default value
	m_setDefaultValueByPopUpRatingStyle();
	
	print("000" + m_defaultNormalLeftArrowImage);			
	//create PopUpRating instance 
	m_pInstance = new PopupRating({
			parent: m_defaultParent,
			x:m_defaultX,
			y:m_defaultY,
			width: m_defaultWidth,
			height: m_defaultHeight,
			color: m_defaultBgColor,
			nPopupRatingType: "base_label_with_popup_type",
			starIconUnmarkedImagePath: m_defaultMarkedImage,
			starIconMarkedImagePath: m_defaultunMarkedImage,
			starIconHalfMarkedImagePath: m_defaultHalfMarkedImage,
			normalLeftArrowButtonImagePath: m_defaultNormalLeftArrowImage,
			focusLeftArrowButtonImagePath: m_defaultFocusLeftArrowImage, 
			disabledLeftArrowButtonImagePath: m_defaultDisabledLeftArrowImage,
			normalRightArrowButtonImagePath: m_defaultNormalRightArrowImage,
			focusRightArrowButtonImagePath: m_defaultFocusRightArrowImage, 
			disabledRightArrowButtonImagePath: m_defaultDisabledRightArrowImage,
			titleText: m_defaultTitle,
			titleTextFont: m_defaultTitleSize,
			contentText: m_defaultContent,
			contentTextFont: m_defaultContenSize,
			button_1_Text: m_defaultOkText,
			button_2_Text: m_defaultCancelText,
			buttonTextNormalSize: m_defaultOkSize,
			buttonTextFocusSize: m_defaultCancelSize,
			normalButtonImagePath: m_defaultNormalButtonImagePath,
			focusButtonImagePath: m_defaultFocusButtonImagePath,
			bAutoFlag:false,
		});	
	
	
	m_pInstance.setTitleRect(m_defaultTitleX,m_defaultTitleY,m_defaultTitleWidth,m_defaultTitleHeight);
	m_pInstance.setTitleTextColor(m_defaultTitleColor.r, m_defaultTitleColor.g, m_defaultTitleColor.b, m_defaultTitleColor.a);
	m_pInstance.setTitleTextAlignment("horizontal_align_center","vertical_align_top");
	
	m_pInstance.setContentRect(m_defaultContentX,m_defaultContentY,m_defaultContentWidth,m_defaultContentHeight);
	m_pInstance.setContentTextColor(m_defaultContentColor.r, m_defaultContentColor.g, m_defaultContentColor.b, m_defaultContentColor.a);
	m_pInstance.setContentTextAlignment("horizontal_align_center","vertical_align_top");
	
	m_pInstance.setArrowButtonRect("arrow_button_1", m_defaultLeftArrowX, m_defaultLeftArrowY, m_defaultLeftArrowWidth, m_defaultLeftArrowHeight);
	m_pInstance.setArrowButtonRect("arrow_button_2", m_defaultRightArrowX, m_defaultRightArrowY, m_defaultRightArrowWidth, m_defaultRightArrowHeight);
	
	for(var index = 1; index <=5; index++){
		var strIconName =  "star_icon_" + index.toString();
		var nStarInconX = m_defaultFirstStarIconX + (index -1)* m_defaultStarIconWidthWithGap;	
		m_pInstance.setStarIconRect(strIconName,nStarInconX, m_defaultFirstStarIconY, m_defaultFirstStarIconWidth, m_defaultFirstStarIconHeight);	
	}
	
	m_pInstance.setButtonRect("button_1", m_defaultOkX, m_defaultOkY, m_defaultOkWidth, m_defaultOkHeight);
	m_pInstance.setButtonRect("button_2", m_defaultCancelX, m_defaultCancelY, m_defaultCancelWidth, m_defaultCancelHeight);
	
    m_pInstance.defaultFocusIndex = 1;
    m_pInstance.markedStarIconNumber = 1;
	
	return 	m_pInstance;
}		
	
var m_analysisParameter = function(objParameter){
	if("undefined" == objParameter){
		return;
	}

	if (objParameter.hasOwnProperty("nPopUpRatingStyle") 
		&& (typeof objParameter.nPopUpRatingStyle == "number")
		&& (PopUpRatingStyle.PopUpRating_Style_MAX > objParameter.nPopUpRatingStyle)){		
			m_PopUpRatingStyle = objParameter.nPopUpRatingStyle;
	}
	
	if (objParameter.hasOwnProperty("nResoultionStyle") 
		&& (typeof objParameter.nResoultionStyle == "number")
		&& (ResoultionStyle.Resoultion_720 <= objParameter.nResoultionStyle)
		&& (ResoultionStyle.Resoultion_Style_MAX > objParameter.nResoultionStyle)){
			m_resoultionStyle = objParameter.nResoultionStyle;
	}
		
	if(objParameter.hasOwnProperty("parent")
		&& (typeof objParameter.parent == "number")){
		m_defaultParent = objParameter.parent;
	}	
	
	if(objParameter.hasOwnProperty("x")
		&& (typeof objParameter.x == "number")){
		m_defaultX = objParameter.x;	
	}
	
	if(objParameter.hasOwnProperty("y")
		&& (typeof objParameter.y == "number")){
		m_defaultY = objParameter.y;	
	}	
	
	if(objParameter.hasOwnProperty("width")
		&& (typeof objParameter.width == "number")){
		m_defaultWidth = objParameter.width;	
	}	
	
	if(objParameter.hasOwnProperty("height")
		&& (typeof objParameter.height == "number")){
		m_defaultHeight = objParameter.height;
	}	
}
		
var m_setDefaultValueByPopUpRatingStyle = function(){
	// set resource path
	if(m_resoultionStyle == ResoultionStyle.Resoultion_1080 || m_resoultionStyle == ResoultionStyle.Resoultion_1080_21_9){
		m_imagePath = m_imagePath + "1080p/popUpRating/";
	} else if (m_resoultionStyle == ResoultionStyle.Resoultion_720 || m_resoultionStyle == ResoultionStyle.Resoultion_720_21_9){
		m_imagePath = m_imagePath + "720p/popUpRating/";
	}
	
	//set default value
	m_defaultMarkedImage = m_imagePath+"popup_rating_off.png";
	m_defaultunMarkedImage = m_imagePath+"popup_rating_on.png";
	m_defaultHalfMarkedImage = m_imagePath+"popup_rating_half.png";
	m_defaultNormalLeftArrowImage = m_imagePath+"popup_rating_arrow_l_n.png";
	m_defaultFocusLeftArrowImage = m_imagePath+"popup_rating_arrow_l_f.png";
	m_defaultDisabledLeftArrowImage = m_imagePath+"popup_rating_arrow_l_d.png";
	m_defaultNormalRightArrowImage = m_imagePath+"popup_rating_arrow_r_d.png";
	m_defaultFocusRightArrowImage = m_imagePath+"popup_rating_arrow_r_f.png";
	m_defaultDisabledRightArrowImage = m_imagePath+"popup_rating_arrow_r_f.png";
	
	switch(m_resoultionStyle){
		case ResoultionStyle.Resoultion_1080:{
			m_defaultBgColor = {r: 39, g: 124, b: 175, a: 200};
			m_defaultX = 0;
			m_defaultY = 0;
			m_defaultWidth = 1920;
			m_defaultHeight = 418;

			m_defaultTitleColor = {r: 255, g: 255, b: 255, a: 255};
			m_defaultTitleSize = "Sans 44px";
			m_defaultTitleX = 569;
			m_defaultTitleY = 0;
			m_defaultTitleWidth = 782;
			m_defaultTitleHeight = 97;

			m_defaultContentColor = {r: 255, g: 255, b: 255, a: 255};
			m_defaultContenSize =  "Sans 34px";	
			m_defaultContentX = 569;
			m_defaultContentY = 108;
			m_defaultContentWidth = 782;
			m_defaultContentHeight = 96;

			m_defaultLeftArrowX = 717;
			m_defaultLeftArrowY = 108 + 96 + 21;
			m_defaultLeftArrowWidth = 62;
			m_defaultLeftArrowHeight = 62;
			
			m_defaultRightArrowX = 817 + 57* 5 + 27;
			m_defaultRightArrowY = 108 + 96 + 21;
			m_defaultRightArrowWidth = 62;
			m_defaultRightArrowHeight = 62;
			
			m_defaultStarIconWidthWithGap = 57;
			m_defaultFirstStarIconX = 817;
			m_defaultFirstStarIconY = 108 + 96 + 26;
			m_defaultFirstStarIconWidth = 46;
			m_defaultFirstStarIconHeight = 46;
			
			m_defaultOkX = 817 - 135;
			m_defaultOkY = 250 + 46 + 35;
			m_defaultOkWidth = 270;
			m_defaultOkHeight = 66;
			m_defaultOkSize = 32;
			
			m_defaultCancelX = 817 + 57* 5 - 135;
			m_defaultCancelY = 250 + 46 + 35;
			m_defaultCancelWidth=270;
			m_defaultCancelHeight=66;
			m_defaultCancelSize = 36;		
		}
		break;
		
		case ResoultionStyle.Resoultion_720:{
			m_defaultBgColor = {r: 39, g: 124, b: 175, a: 200};
			m_defaultX = 0;
			m_defaultY = 0;
			m_defaultWidth = 1280;
			m_defaultHeight = 277;

			m_defaultTitleColor = {r: 255, g: 255, b: 255, a: 255};
			m_defaultTitleSize = "Sans 29px";
			m_defaultTitleX = 380;
			m_defaultTitleY = 0;
			m_defaultTitleWidth = 521;
			m_defaultTitleHeight = 65;

			m_defaultContentColor = {r: 255, g: 255, b: 255, a: 255};
			m_defaultContenSize =  "Sans 23px";	
			m_defaultContentX = 380;
			m_defaultContentY = 65 + 7;
			m_defaultContentWidth = 521;
			m_defaultContentHeight = 64;

			m_defaultLeftArrowX = 484;
			m_defaultLeftArrowY = 72 + 64 + 14;
			m_defaultLeftArrowWidth = 41;
			m_defaultLeftArrowHeight = 41;
			
			m_defaultRightArrowX = 484 + 38* 5+ 74;
			m_defaultRightArrowY = 72 + 64 + 14;
			m_defaultRightArrowWidth = 41;
			m_defaultRightArrowHeight = 41;
			
			m_defaultStarIconWidthWithGap = 38;
			m_defaultFirstStarIconX = 484 + 61;
			m_defaultFirstStarIconY = 72 + 64 + 17;
			m_defaultFirstStarIconWidth = 31;
			m_defaultFirstStarIconHeight = 31;
			
			m_defaultOkX = 545 - 90;
			m_defaultOkY = 150 + 41 + 23;
			m_defaultOkWidth = 180;
			m_defaultOkHeight = 44;
			m_defaultOkSize = 21;
			
			m_defaultCancelX = 545 + 38* 5 - 90;
			m_defaultCancelY = 150 + 41 + 23;
			m_defaultCancelWidth=180;
			m_defaultCancelHeight=44;
			m_defaultCancelSize = 24;
		}
		break;
		
		case ResoultionStyle.Resoultion_1080_21_9:{
			m_defaultBgColor = {r: 39, g: 124, b: 175, a: 200};
			m_defaultX = 0;
			m_defaultY = 0;
			m_defaultWidth = 2520;
			m_defaultHeight = 418;

			m_defaultTitleColor = {r: 255, g: 255, b: 255, a: 255};
			m_defaultTitleSize = "Sans 44px";
			m_defaultTitleX = 569+300;
			m_defaultTitleY = 0;
			m_defaultTitleWidth = 782;
			m_defaultTitleHeight = 97;

			m_defaultContentColor = {r: 255, g: 255, b: 255, a: 255};
			m_defaultContenSize =  "Sans 34px";	
			m_defaultContentX = 569+300;
			m_defaultContentY = 108;
			m_defaultContentWidth = 782;
			m_defaultContentHeight = 96;

			m_defaultLeftArrowX = 717+300;
			m_defaultLeftArrowY = 108 + 96 + 21;
			m_defaultLeftArrowWidth = 62;
			m_defaultLeftArrowHeight = 62;
			
			m_defaultRightArrowX = 817 + 57* 5 + 27 +300;
			m_defaultRightArrowY = 108 + 96 + 21;
			m_defaultRightArrowWidth = 62;
			m_defaultRightArrowHeight = 62;
			
			m_defaultStarIconWidthWithGap = 57;
			m_defaultFirstStarIconX = 817+300;
			m_defaultFirstStarIconY = 108 + 96 + 26;
			m_defaultFirstStarIconWidth = 46;
			m_defaultFirstStarIconHeight = 46;
			
			m_defaultOkX = 817 - 135 + 300;
			m_defaultOkY = 250 + 46 + 35;
			m_defaultOkWidth = 270;
			m_defaultOkHeight = 66;
			m_defaultOkSize = 32;
			
			m_defaultCancelX = 817 + 57* 5 - 135 + 300;
			m_defaultCancelY = 250 + 46 + 35;
			m_defaultCancelWidth=270;
			m_defaultCancelHeight=66;
			m_defaultCancelSize = 36;		
		}
		break;
		
		case ResoultionStyle.Resoultion_720_21_9:{
			m_defaultBgColor = {r: 39, g: 124, b: 175, a: 200};
			m_defaultX = 0;
			m_defaultY = 0;
			m_defaultWidth = 1680;
			m_defaultHeight = 277;

			m_defaultTitleColor = {r: 255, g: 255, b: 255, a: 255};
			m_defaultTitleSize = "Sans 29px";
			m_defaultTitleX = 380 + 200;
			m_defaultTitleY = 0;
			m_defaultTitleWidth = 521;
			m_defaultTitleHeight = 65;

			m_defaultContentColor = {r: 255, g: 255, b: 255, a: 255};
			m_defaultContenSize =  "Sans 23px";	
			m_defaultContentX = 380 + 200;
			m_defaultContentY = 65 + 7;
			m_defaultContentWidth = 521;
			m_defaultContentHeight = 64;

			m_defaultLeftArrowX = 484 + 200;
			m_defaultLeftArrowY = 72 + 64 + 14;
			m_defaultLeftArrowWidth = 41;
			m_defaultLeftArrowHeight = 41;
			
			m_defaultRightArrowX = 484 + 38* 5+ 74 + 200;
			m_defaultRightArrowY = 72 + 64 + 14;
			m_defaultRightArrowWidth = 41;
			m_defaultRightArrowHeight = 41;
			
			m_defaultStarIconWidthWithGap = 38;
			m_defaultFirstStarIconX = 484 + 61 + 200;
			m_defaultFirstStarIconY = 72 + 64 + 17;
			m_defaultFirstStarIconWidth = 31;
			m_defaultFirstStarIconHeight = 31;
			
			m_defaultOkX = 545 - 90 + 200;
			m_defaultOkY = 150 + 41 + 23;
			m_defaultOkWidth = 180;
			m_defaultOkHeight = 44;
			m_defaultOkSize = 21;
			
			m_defaultCancelX = 545 + 38* 5 - 90 + 200;
			m_defaultCancelY = 150 + 41 + 23;
			m_defaultCancelWidth=180;
			m_defaultCancelHeight=44;
			m_defaultCancelSize = 24;
		}
		break;
		
		default:
		break;
	}

	switch(m_popUpRatingStyle){
		case PopUpRatingStyle.PopUpRatingStyle_A:{
			m_defaultNormalButtonImagePath = m_imagePath+"btn_style_a_n.png";
			m_defaultFocusButtonImagePath = m_imagePath+"btn_style_a_f.png";	
		}
		break;
		
		case PopUpRatingStyle.PopUpRatingStyle_B:{
			m_defaultNormalButtonImagePath = m_imagePath+"btn_style_b_n.png";
			m_defaultFocusButtonImagePath = m_imagePath+"btn_style_b_f.png";		
		}
		break;

		default:{
			m_defaultNormalButtonImagePath = m_imagePath+"btn_style_a_n.png";
			m_defaultFocusButtonImagePath = m_imagePath+"btn_style_a_f.png";		
		}
		break;
	}

}	

//return the instance of native PopUpRating	
return m_create(objParameter);	
}

//style type
var PopUpRatingStyle = {
	PopUpRatingStyle_A:0,
	PopUpRatingStyle_B:1,
	PopUpRating_Style_MAX:2,
};
		
var ResoultionStyle = {
	Resoultion_720:0,	
	Resoultion_1080:1,
	Resoultion_720_21_9:2,
	Resoultion_1080_21_9:3,	
	Resoultion_Style_MAX:4,
};

winsetPopUpRating.PopUpRatingStyle = PopUpRatingStyle;
winsetPopUpRating.ResoultionStyle = ResoultionStyle;

exports = winsetPopUpRating;
