winsetButton = function(obj){				
	// local var
	var style = ButtonStyle.BUTTON_STYLE_A,
		resoultion = ResoultionStyle.Resoultion_1080,
		button,
		x = 0,
		y = 0,
		width = 150,
		height = 150,
		path = "$VOLT_ROOT/modules/WinsetUIElement/winsetImg/",
		text = "Button Text",
		// spacing
		textLeftSpacing = 0.010417,
		icontextSpacing = 0.006250,
		// icon attr
		iconWidth = 0,
		iconHeight = 0,
		iconImgSrc,
		iconNormalOpactiy,
		iconFoucsOpactiy,
		iconSelectOpactiy,
		iconDimOpactiy,
		// image path
		bgNormal,
		bgFoucs,
		bgSelect,
		bgDim,
		// background color
		bgNormalColor,
		bgFoucsColor,
		bgSelectColor,
		bgDimColor,
		// buttonType 1: text, 2: icon, 3: text + icon
		buttonType = ButtonType.BUTTON_TEXT,
		// text fontsize
		textWidth = 0,
		normalFont,
		focusFont,
		selectFont,
		dimFont,
		// text color
		normalTextColor,
		focusTextColor,
		selectTextColor,
		dimTextColor,
		rolloverColor = { r:0, g:0, b:0, a:0 };
	
	var m_analysisParameter = function(objParameter){
		if("undefined" != objParameter){
			if (objParameter.hasOwnProperty("style") 
				&& (typeof objParameter.style == "number")
				&& (ButtonStyle.BUTTON_STYLE_A <= objParameter.style)
				&& (ButtonStyle.BUTTON_STYLE_C_FOCUS2 >= objParameter.style)){
				
				style = objParameter.style;		
			}
			
			if (objParameter.hasOwnProperty("nResoultionStyle") 
				&& (typeof objParameter.nResoultionStyle == "number")
				&& (ResoultionStyle.Resoultion_720 <= objParameter.nResoultionStyle)
				&& (ResoultionStyle.Resoultion_Style_MAX > objParameter.nResoultionStyle)){
					resoultion = objParameter.nResoultionStyle;
			}
			
			if(objParameter.hasOwnProperty("buttonType")
				&& (typeof objParameter.buttonType == "number")){
				buttonType = objParameter.buttonType;	
			}

			if(objParameter.hasOwnProperty("x")
				&& (typeof objParameter.x == "number")){
				x = objParameter.x;	
			}
			
			if(objParameter.hasOwnProperty("y")
				&& (typeof objParameter.y == "number")){
				y = objParameter.y;	
			}	
			
			if(objParameter.hasOwnProperty("width")
				&& (typeof objParameter.width == "number")){
				width = objParameter.width;	
			}	
			
			if(objParameter.hasOwnProperty("height")
				&& (typeof objParameter.height == "number")){
				height = objParameter.height;	
			}
			
			if(objParameter.hasOwnProperty("iconWidth")
				&& (typeof objParameter.iconWidth == "number")){
				iconWidth = objParameter.iconWidth;	
			}	
			
			if(objParameter.hasOwnProperty("iconHeight")
				&& (typeof objParameter.iconHeight == "number")){
				iconHeight = objParameter.iconHeight;	
			}	
			
			if(objParameter.hasOwnProperty("iconImgSrc")
				&& (typeof objParameter.iconImgSrc == "string")){
				iconImgSrc = objParameter.iconImgSrc;	
			}
			
			if(objParameter.hasOwnProperty("text")
				&& (typeof objParameter.text == "string")){
				text = objParameter.text;	
			}
			
			if(objParameter.hasOwnProperty("textWidth")
				&& (typeof objParameter.textWidth == "number")){
				textWidth = objParameter.textWidth;	
			}
		}	
	}
			
	var m_setDefaultValueByProgressStyle = function(){
		// set resource path
		if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
			path = path + "1080p/btn/";
		} else if (resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
			path = path + "720p/btn/";
		}

		//set default value
		switch(style)
		{
			case ButtonStyle.BUTTON_STYLE_A:
				{
					// spacing
					textLeftSpacing = 0.010417,
					icontextSpacing = 0.006250,
		
					// image path
					bgNormal = path + "btn_style_a_n.png";
					bgFoucs = path + "btn_style_a_f.png";
					bgSelect = path + "btn_style_a_s.png";
					bgDim = path + "btn_style_a_d.png";
					
					// background color
					bgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
					bgFoucsColor = { r: 33, g: 158, b: 230, a: 255 };
					bgSelectColor = { r: 0, g: 0, b: 0, a: 13 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					if(1 == buttonType || 3 == buttonType){
						// set text attr value
						if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
							// text fontsize
							normalFont = 32;
							focusFont = 36;
							selectFont = 36;
							dimFont = 32;
						} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
							// text fontsize
							normalFont = 21;
							focusFont = 24;
							selectFont = 24;
							dimFont = 21;
						}
						
						// text color
						normalTextColor = { r: 64, g: 64, b: 64, a: 204 };
						focusTextColor = { r: 244, g: 244, b: 244, a: 255 };
						selectTextColor = { r: 241, g: 171, b: 21, a: 255 };
						dimTextColor = { r: 64, g: 64, b: 64, a: 76 };	
					}
					
					if(2 == buttonType || 3 == buttonType){
						iconNormalOpactiy = 153;
						iconFoucsOpactiy = 255;
						iconSelectOpactiy = 255;
						iconDimOpactiy = 76;
					}
				}
				break;
				
			case ButtonStyle.BUTTON_STYLE_B_FOCUS1:
				{
					// spacing
					textLeftSpacing = 0.010417,
					icontextSpacing = 0.006250,
					
					// image path
					bgNormal = path + "btn_style_b_n.png";
					bgFoucs = path + "btn_style_b_f.png";
					bgSelect = path + "btn_style_b_s.png";
					bgDim = path + "btn_style_b_d.png";
				
					// background color
					bgNormalColor = { r: 255, g: 255, b: 255, a: 0 };
					bgFoucsColor = { r: 255, g: 255, b: 255, a: 242 };
					bgSelectColor = { r: 0, g: 0, b: 0, a: 13 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					if(1 == buttonType || 3 == buttonType){
						// set text attr value
						if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
							// text fontsize
							normalFont = 32;
							focusFont = 36;
							selectFont = 36;
							dimFont = 32;
						} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
							// text fontsize
							normalFont = 21;
							focusFont = 24;
							selectFont = 24;
							dimFont = 21;
						}
						
						// text color
						normalTextColor = { r: 255, g: 255, b: 255, a: 204 };
						focusTextColor = { r: 70, g: 70, b: 70, a: 255 };
						selectTextColor = { r: 233, g: 179, b: 33, a: 255 };
						dimTextColor = { r: 255, g: 255, b: 255, a: 76 };	
					}
					
					if(2 == buttonType || 3 == buttonType){
						iconNormalOpactiy = 153;
						iconFoucsOpactiy = 255;
						iconSelectOpactiy = 255;
						iconDimOpactiy = 76;
					}
				}
				break;
				
			case ButtonStyle.BUTTON_STYLE_B_FOCUS2:
				{
					// spacing
					textLeftSpacing = 0.010417,
					icontextSpacing = 0.006250,
					
					// image path
					bgNormal = path + "btn_style_b_n.png";
					bgFoucs = path + "btn_style_b_f.png";
					bgSelect = path + "btn_style_b_s.png";
					bgDim = path + "btn_style_b_d.png";
				
					// background color
					bgNormalColor = { r: 255, g: 255, b: 255, a: 0 };
					bgFoucsColor = { r: 33, g: 158, b: 230, a: 255 };
					bgSelectColor = { r: 0, g: 0, b: 0, a: 13 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					if(1 == buttonType || 3 == buttonType){
						// set text attr value
						if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
							// text fontsize
							normalFont = 32;
							focusFont = 36;
							selectFont = 36;
							dimFont = 32;
						} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
							// text fontsize
							normalFont = 21;
							focusFont = 24;
							selectFont = 24;
							dimFont = 21;
						}
						
						// text color
						normalTextColor = { r: 255, g: 255, b: 255, a: 204 };
						focusTextColor = { r: 244, g: 244, b: 244, a: 255 };
						selectTextColor = { r: 233, g: 179, b: 33, a: 255 };
						dimTextColor = { r: 255, g: 255, b: 255, a: 76 };	
					}
					
					if(2 == buttonType || 3 == buttonType){
						iconNormalOpactiy = 153;
						iconFoucsOpactiy = 255;
						iconSelectOpactiy = 255;
						iconDimOpactiy = 76;
					}
				}
				break;
				
			case ButtonStyle.BUTTON_STYLE_C_FOCUS1:
				{
					// spacing
					textLeftSpacing = 0.005208,
					icontextSpacing = 0.006250,
					
					// image path
					bgNormal = path + "btn_style_c_n.png";
					bgFoucs = path + "btn_style_c_f.png";
					bgSelect = path + "btn_style_c_s.png";
					bgDim = path + "btn_style_c_d.png";
				
					// background color
					bgNormalColor = { r: 255, g: 255, b: 255, a: 0 };
					bgFoucsColor = { r: 255, g: 255, b: 255, a: 242 };
					bgSelectColor = { r: 0, g: 0, b: 0, a: 13 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					if(1 == buttonType || 3 == buttonType){
						// set text attr value
						if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
							// text fontsize
							normalFont = 26;
							focusFont = 30;
							selectFont = 30;
							dimFont = 26;
						} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
							// text fontsize
							normalFont = 17;
							focusFont = 20;
							selectFont = 20;
							dimFont = 17;
						}
						
						// text color
						normalTextColor = { r: 255, g: 255, b: 255, a: 204 };
						focusTextColor = { r: 70, g: 70, b: 70, a: 255 };
						selectTextColor = { r: 233, g: 179, b: 33, a: 255 };
						dimTextColor = { r: 255, g: 255, b: 255, a: 76 };	
					}
					
					if(2 == buttonType || 3 == buttonType){
						iconNormalOpactiy = 153;
						iconFoucsOpactiy = 255;
						iconSelectOpactiy = 255;
						iconDimOpactiy = 76;
					}
				}
				break;
				
			case ButtonStyle.BUTTON_STYLE_C_FOCUS2:
				{
					// spacing
					textLeftSpacing = 0.005208,
					icontextSpacing = 0.006250,
					
					// image path
					bgNormal = path + "btn_style_c_n.png";
					bgFoucs = path + "btn_style_c_f.png";
					bgSelect = path + "btn_style_c_s.png";
					bgDim = path + "btn_style_c_d.png";
				
					// background color
					bgNormalColor = { r: 255, g: 255, b: 255, a: 0 };
					bgFoucsColor = { r: 33, g: 158, b: 230, a: 255 };
					bgSelectColor = { r: 0, g: 0, b: 0, a: 13 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					if(1 == buttonType || 3 == buttonType){
						// set text attr value
						if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
							// text fontsize
							normalFont = 26;
							focusFont = 30;
							selectFont = 30;
							dimFont = 26;
						} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
							// text fontsize
							normalFont = 17;
							focusFont = 20;
							selectFont = 20;
							dimFont = 17;
						}
						
						// text color
						normalTextColor = { r: 255, g: 255, b: 255, a: 204 };
						focusTextColor = { r: 244, g: 244, b: 244, a: 255 };
						selectTextColor = { r: 233, g: 179, b: 33, a: 255 };
						dimTextColor = { r: 255, g: 255, b: 255, a: 76 };	
					}
					
					if(2 == buttonType || 3 == buttonType){
						iconNormalOpactiy = 153;
						iconFoucsOpactiy = 255;
						iconSelectOpactiy = 255;
						iconDimOpactiy = 76;
					}
				}
				break;
				
			default:
				break;
		}
	}
		
	var getResoultion = function(){
		return ResoultionStyle.Resoultion_1080;
	}
	
	// resoultion = getResoultion();		
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	print("path is --------- " + bgNormal);
	//create button instance 
	button = new Button({
		x: x,
		y: y,
		width: width,
		height: height 
	});
	// button.x = x;
	// button.y = y;
	// button.width = width;
	// button.height = height;

	// set each state of image
	button.setBackgroundImage({
		state: "normal",
		src: bgNormal,
	});
	
	button.setBackgroundImage({
		state: "focused",
		src: bgFoucs,
	});
	
	button.setBackgroundImage({
		state: "selected",
		src: bgSelect,
	});
	
	button.setBackgroundImage({
		state: "disabled",
		src: bgDim,
	});
	
	// set background color
	button.setBackgroundColor({
		state: "normal",
		color: bgNormalColor,
	});
	
	button.setBackgroundColor({
		state: "focused",
		color: bgFoucsColor,
	});
	
	button.setBackgroundColor({
		state: "selected",
		color: bgSelectColor,
	});
	
	button.setBackgroundColor({
		state: "disabled",
		color: bgDimColor,
	});
	
	button.setBackgroundColor({
		state: "roll-over",
		color: rolloverColor,
	});
	
	// set text attr
	if(1 == buttonType || 3 == buttonType){
		// set default text
		button.setText({
			state: "all",
			text: text,
		});
		// set each state of text font
		button.setFontSize({
			state: "normal",
			size: normalFont,
		});
		
		button.setFontSize({
			state: "focused",
			size: focusFont,
		});
		
		button.setFontSize({
			state: "selected",
			size: selectFont,
		});
		
		button.setFontSize({
			state: "disabled",
			size: dimFont,
		});
		
		// set each state of text color
		button.setTextColor({
			state: "normal",
			color: normalTextColor,
		});
		
		button.setTextColor({
			state: "focused",
			color: focusTextColor,
		});
		
		button.setTextColor({
			state: "selected",
			color: selectTextColor,
		});
		
		button.setTextColor({
			state: "disabled",
			color: dimTextColor,
		});
	}
	
	// set icon attr
	if(2 == buttonType || 3 == buttonType){
		button.setIconImage({
			state: "all",
			src: iconImgSrc
		});
		
		button.setIconAlpha({
			state: "normal",
			alpha: iconNormalOpactiy
		});
		
		button.setIconAlpha({
			state: "focused",
			alpha: iconFoucsOpactiy
		});
		
		button.setIconAlpha({
			state: "selected",
			alpha: iconSelectOpactiy
		});
		
		button.setIconAlpha({
			state: "disabled",
			alpha: iconDimOpactiy
		});
	}
	
	if(1 == buttonType){
		// set text rect
		button.setTextAttr({x: textLeftSpacing * width, y: 0, width: (1 - 2 * textLeftSpacing) * width, height: height});
	}
	
	if(2 == buttonType){
		// set icon rect
		button.setIconAttr({x: (width - iconWidth)/2, y: (height - iconHeight)/2, width: iconWidth, height: iconHeight});
	}
	
	if(3 == buttonType){
		// set text rect
		button.setTextAttr({
			x: (width - iconWidth - textWidth - width * icontextSpacing)/2 + iconWidth + width * icontextSpacing, 
			y: 0, 
			width: textWidth, 
			height: height,
			hAlign: "left"
		});
		
		// set icon rect
		button.setIconAttr({
			x: (width - iconWidth - textWidth - width * icontextSpacing)/2, 
			y: (height - iconHeight)/2, 
			width: iconWidth, 
			height: iconHeight
		});	
	}
	
	return button;	
}

var ButtonStyle = {
	BUTTON_STYLE_A: 1,
	BUTTON_STYLE_B_FOCUS1: 2,
	BUTTON_STYLE_B_FOCUS2: 3,
	BUTTON_STYLE_C_FOCUS1: 4,
	BUTTON_STYLE_C_FOCUS2: 5
};

var ButtonType = {
	BUTTON_TEXT: 1,
	BUTTON_ICON: 2,
	BUTTON_TEXT_ICON: 3
};

var ResoultionStyle = {
	Resoultion_720:0,	
	Resoultion_1080:1,
	Resoultion_720_21_9:2,
	Resoultion_1080_21_9:3,	
	Resoultion_Style_MAX:4
};

winsetButton.ButtonStyle = ButtonStyle;
winsetButton.ButtonType = ButtonType;
winsetButton.ResoultionStyle = ResoultionStyle;

exports = winsetButton;
