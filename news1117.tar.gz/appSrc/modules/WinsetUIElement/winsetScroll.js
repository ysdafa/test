winsetScroll = function(obj) {
	// local var
	var scroll,
		height = 1080,
		width = 5,
		x = 1500,
		y = 0,
        id = null,
		style = ScrollStyle.Scroll_Style_C,
		resoultion = ResoultionStyle.Resoultion_1080,
		path = "modules/WinsetUIElement/winsetImg/",
		pointingNormalThumbImageWidth = 5,
		pointingNormalThumbImageHeight = 40,
		pointingOverThumbImageWidth = 21,
		pointingOverThumbImageHeight = 40,
		pointingFocusThumbImageWidth = 29,
		pointingFocusThumbImageHeight = 49,
		pointingNormalThumbImage,
		pointingOverThumbImage,
		pointingFocusThumbImage,
		bgFocusImage,
		bgNormalImage;
		
	   	
	var m_analysisParameter = function(objParameter){
		if("undefined" != objParameter){
			if (objParameter.hasOwnProperty("style") 
				&& (typeof objParameter.style == "number")
				&& (ScrollStyle.Scroll_Style_A <= objParameter.style)
				&& (ScrollStyle.Scroll_Style_C >= objParameter.style)){
				
				style = objParameter.style;		
			}

			if (objParameter.hasOwnProperty("nResoultionStyle") 
				&& (typeof objParameter.nResoultionStyle == "number")
				&& (ResoultionStyle.Resoultion_720 <= objParameter.nResoultionStyle)
				&& (ResoultionStyle.Resoultion_Style_MAX > objParameter.nResoultionStyle)){
					resoultion = objParameter.nResoultionStyle;
			}			
            if(objParameter.hasOwnProperty("id")){
				id = objParameter.id;	
			}
            if(objParameter.hasOwnProperty("parent")){
				parent = objParameter.parent;	
			}
		
			if(objParameter.hasOwnProperty("x")
				&& (typeof objParameter.x == "number")){
				x = objParameter.x;	
			}
            
            if(objParameter.hasOwnProperty("height")
				&& (typeof objParameter.x == "number")){
				height = objParameter.height;	
			}
            if(objParameter.hasOwnProperty("width")
				&& (typeof objParameter.x == "number")){
				width = objParameter.width;	
			}
			
			if(objParameter.hasOwnProperty("y")
				&& (typeof objParameter.y == "number")){
				y = objParameter.y;	
			}	
		}	
	}

	var m_setDefaultValueByProgressStyle = function(){
		// set resource path
		if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
			path = path + "1080p/scroll/";
			//height = 1080;
		} else if (resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
			path = path + "720p/scroll/";
			//height = 720;
		}

		//set default value
		switch(style)
		{
			case ScrollStyle.Scroll_Style_A:
			case ScrollStyle.Scroll_Style_B:
			case ScrollStyle.Scroll_Style_C:
				{
					// image path
					pointingNormalThumbImage = path + "chvol_scroll_nor.png";
					pointingOverThumbImage = path + "chvol_scroll_over.png";
					pointingFocusThumbImage = path + "chvol_scroll_focus.png";
					
					bgFocusImage = path + "keyscreen_scroll_pn.png";
					bgNormalImage = path + "keyscreen_scroll_po.png";
					
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						pointingNormalThumbImageWidth = 5;
						pointingNormalThumbImageHeight = 40;
						pointingOverThumbImageWidth = 21;
						pointingOverThumbImageHeight = 40;
						pointingFocusThumbImageWidth = 29;
						pointingFocusThumbImageHeight = 49;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						height = 720;
						width = 4;
						pointingNormalThumbImageWidth = 4;
						pointingNormalThumbImageHeight = 26;
						pointingOverThumbImageWidth = 14;
						pointingOverThumbImageHeight = 26;
						pointingFocusThumbImageWidth = 19;
						pointingFocusThumbImageHeight = 32;					
					}
				}
				break;
			
			default:
				break;
		}
	}

	var getResoultion = function(){
		return ResoultionStyle.Resoultion_1080;
	}
	
	//resoultion = getResoultion();		
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	
    ("path is ------------ " + pointingNormalThumbImage);
	scroll = new Scroll({
        x : x,
        y : y,
		width: width,
		height: height,
        id : id,
        parent : parent,
		trackShadowHeight: 0,
		direction: "vertical",
		active: true,
        color:{r:0,g:0,b:0,a:0},
		backgroundColor: { r: 255, g: 0, b: 0, a: 5 },
		trackShadowColor: { r: 255, g: 0, b: 0, a: 51 },
		pointingNormalThumbImageWidth: pointingNormalThumbImageWidth,
		pointingNormalThumbImageHeight: pointingNormalThumbImageHeight,
		pointingNormalThumbImage: pointingNormalThumbImage,
		pointingOverThumbImageWidth: pointingOverThumbImageWidth,
		pointingOverThumbImageHeight: pointingOverThumbImageHeight,
		pointingOverThumbImage: pointingOverThumbImage,
		pointingFocusThumbImageWidth: pointingFocusThumbImageWidth,
		pointingFocusThumbImageHeight: pointingFocusThumbImageHeight,
		pointingFocusThumbImage: pointingFocusThumbImage,
		rolloverTopTrackHeight: pointingOverThumbImageWidth
	});
	
	//scroll.pointingNormalBackgroundImage = bgFocusImage;
	//scroll.pointingOverBackgroundImage = bgNormalImage;
	
	return scroll;
};

var ScrollStyle = {
	Scroll_Style_A:1,
	Scroll_Style_B:2,
	Scroll_Style_C:3
};

var ResoultionStyle = {
	Resoultion_720:0,	
	Resoultion_1080:1,
	Resoultion_720_21_9:2,
	Resoultion_1080_21_9:3,	
	Resoultion_Style_MAX:4
};

winsetScroll.ScrollStyle = ScrollStyle;
winsetScroll.ResoultionStyle = ResoultionStyle;
exports = winsetScroll;

