winsetCategoryTab = function(obj) {	
	// local var
	var categorytab,
		screenWidth = 1920,
		screenHeight = 1080,
		height,
		width,
		x = 460,
		y = 0,
		style = Categorytabtyle.Categorytab_Style_A,
		resoultion = ResoultionStyle.Resoultion_1080,
		path = "$VOLT_ROOT/modules/WinsetUIElement/winsetImg/",
		// background
		bgColor,
		bgImage,
		// arrow
		leftArrow,
		rightArrow,
		arrowWidth,
		arrowHeight,
		// tab
		tabSpacing,
		tabFontName = "Sans 20px",
		tabNormalFontSize,
		tabFocusFontSize,
		tabSelectFontSize,
		tabNormalTextColor = {},
		tabFocusTextColor = {},
		tabSelectTextColor = {},
		tabNormalBgColor,
		tabFocusBgColor,
		tabSelectBgColor,
		tabNormalBgImage,
		tabFocusBgImage,
		tabSelectBgImage,
		tabMargin = {},
		tabName = ["Tab", "Tab", "Tab", "Tab", "Tab"];
		
		
	   	
	var m_analysisParameter = function(objParameter){
		if("undefined" != objParameter){
			if (objParameter.hasOwnProperty("style") 
				&& (typeof objParameter.style == "number")
				&& (Categorytabtyle.Categorytab_Style_A == objParameter.style)){
				
				style = objParameter.style;		
			}
		
			if(objParameter.hasOwnProperty("x")
				&& (typeof objParameter.x == "number")){
				x = objParameter.x;	
			}
			
			if(objParameter.hasOwnProperty("y")
				&& (typeof objParameter.y == "number")){
				y = objParameter.y;	
			}
			
			if(objParameter.hasOwnProperty("height")
				&& (typeof objParameter.height == "number")){
				height = objParameter.height;	
			}
			
			if(objParameter.hasOwnProperty("width")
				&& (typeof objParameter.width == "number")){
				width = objParameter.width;	
			}
			
			if (objParameter.hasOwnProperty("nResoultionStyle") 
				&& (typeof objParameter.nResoultionStyle == "number")
				&& (ResoultionStyle.Resoultion_720 <= objParameter.nResoultionStyle)
				&& (ResoultionStyle.Resoultion_Style_MAX > objParameter.nResoultionStyle)){
					m_ResoultionStyle = objParameter.nResoultionStyle;
			}
			
			if(objParameter.hasOwnProperty("tabName")
				&& (Object.prototype.toString.call(objParameter.tabName) === "[object Array]")){
				if(5 <= objParameter.tabName.length){
					for(var i = 0; i < 5; i++){
						tabName[i] = objParameter.tabName[i];
					}
				}
				
				if(5 > objParameter.tabName.length){
					for(var i = 0; i < objParameter.tabName.length; i++){
						tabName[i] = objParameter.tabName[i];
					}
				}
			}
		}	
	}

	var m_setDefaultValueByProgressStyle = function(){
		// set resource path
		if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
			path = path + "1080p/categorytab/";
			screenHeight = 1080;
			width = 1080;
		} else if (resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
			path = path + "720p/categorytab/";
			screenHeight = 720;
			width = 720;
		}
		
		height = 0.1 * screenHeight;
		//set default value
		switch(style)
		{
			case Categorytabtyle.Categorytab_Style_A:
				{
					// image path
					bgColor = { r:223, g:223, b:223, a:255 };
					// bgImage =
					// arrow
					leftArrow = path + "chlist_title_arrow_left_s.png";
					rightArrow = path + "chlist_title_arrow_right_s.png";
					
					// tab
					tabSpacing = 0;
					tabMargin.Top = 0;
					tabMargin.Bottom = 0; 
					tabMargin.Left = 0;
					tabMargin.Right = 0;
					tabNormalTextColor = { r:70, g:70, b:70, a:255 };
					tabFocusTextColor = { r:255, g:255, b:255, a:255 };
					tabSelectTextColor = { r:33, g:158, b:230, a:255 };
					tabNormalBgColor = { r:70, g:70, b:70, a:255 };
					tabFocusBgColor = { r:33, g:158, b:230, a:255 };
					tabSelectBgColor = { r:33, g:158, b:230, a:255 };
					// tabNormalBgImage
					// tabFocusBgImage
					// tabSelectBgImage
					tabMargin = {};
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						arrowWidth = 18;
						arrowHeight = 34;
						tabNormalFontSize = 28;
						tabFocusFontSize = 31;
						tabSelectFontSize = 31;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						arrowWidth = 12;
						arrowHeight = 22;
						tabNormalFontSize = 18;
						tabFocusFontSize = 20;
						tabSelectFontSize = 20;
					}
				}
				break;
			default:
				break;
		}
	}

	var getResoultion = function(){
		return ResoultionStyle.Resoultion_1080;
	}
	
	resoultion = getResoultion();		
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	print("path is ------------ " + tabNormalBgImage);
	categorytab = new CategoryTab({
	    x: x,
	    y: y,
	    width: width,
	    height: height
	});
	
	categorytab.setMargin(tabMargin.Top, tabMargin.Bottom, tabMargin.Left, tabMargin.Right);
	//categorytab.setTabSpacing(tabSpacing);
	// categorytab.enableLooping(true);
	categorytab.setArrowsSize(arrowWidth, arrowHeight);
	categorytab.setArrowsImage(leftArrow, rightArrow);
	// tab
	categorytab.setTabFontName(tabFontName);
	categorytab.setTabFontSize("unselected", tabNormalFontSize);
	categorytab.setTabFontSize("selected", tabFocusFontSize);
	categorytab.setTabFontSize("highlighted", tabSelectFontSize);
	
	categorytab.setTabTextColor("unselected", tabNormalTextColor.r, tabNormalTextColor.g, tabNormalTextColor.b, tabNormalTextColor.a);
	categorytab.setTabTextColor("selected", tabFocusTextColor.r, tabFocusTextColor.g, tabFocusTextColor.b, tabFocusTextColor.a);
	categorytab.setTabTextColor("highlighted", tabSelectTextColor.r, tabSelectTextColor.g, tabSelectTextColor.b, tabSelectTextColor.a);
	
	// categorytab.setTabImage("unselected", tabNormalBgImage);
	// categorytab.setTabImage("selected", tabFocusBgImage);
	// categorytab.setTabImage("highlighted", tabSelectBgImage);
	
	categorytab.setTabTextColor("unselected", tabNormalBgColor.r, tabNormalBgColor.g, tabNormalBgColor.b, tabNormalBgColor.a);
	categorytab.setTabTextColor("selected", tabFocusBgColor.r, tabFocusBgColor.g, tabFocusBgColor.b, tabFocusBgColor.a);
	categorytab.setTabTextColor("highlighted", tabSelectBgColor.r, tabSelectBgColor.g, tabSelectBgColor.b, tabSelectBgColor.a);

	// categorytab.setBackgroundImage(bgImage);
	categorytab.setBackgroundColor(bgColor.r, bgColor.g, bgColor.b, bgColor.a);
	
	
	categorytab.addTab(tabName[0], 200, height);
	categorytab.addTab(tabName[1], 200, height);
	categorytab.addTab(tabName[2], 200, height);
	categorytab.addTab(tabName[3], 200, height);
	categorytab.addTab(tabName[4], 200, height);

	return categorytab;
};

var Categorytabtyle = {
	Categorytab_Style_A: 1
};

var ResoultionStyle = {
	Resoultion_720:0,	
	Resoultion_1080:1,
	Resoultion_720_21_9:2,
	Resoultion_1080_21_9:3,	
	Resoultion_Style_MAX:4
};

winsetCategoryTab.Categorytabtyle = Categorytabtyle;
winsetCategoryTab.ResoultionStyle = ResoultionStyle;
exports = winsetCategoryTab;

