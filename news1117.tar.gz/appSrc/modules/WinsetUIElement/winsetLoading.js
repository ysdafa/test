winsetLoading = function(obj) {
	// local var
	var loading,
		height = 58,
		width = 301,
		imageWidth = 301,
		imageHeight = 58,
		textWidth = 0,
		textHeight = 0,
		x = 1500,
		y = 0,
		parent = scene,
		id = null,
		gap = 0,
		style = LoadingStyle.Loading_Bright_20,
		resoultion = ResoultionStyle.Resoultion_1080,
		path = "images/",
		imageName = [],
		text = Volt.i18n.t('COM_SID_LOADING_DOT'),
		textFont,
		textColor;
		
	   	
	var m_analysisParameter = function(objParameter){
		if("undefined" != objParameter){
			if (objParameter.hasOwnProperty("style") 
				&& (typeof objParameter.style == "number" || typeof objParameter.style == "string")){
				
				if(typeof objParameter.style == "string"){
					style = parseInt(objParameter.style);
				}else{
					style = objParameter.style;	
				}
				
				if((1 > style) || (LoadingStyle.Loading_Style_Max <= style)){
					style = 1;
				}
			}
			
			if (objParameter.hasOwnProperty("nResoultionStyle") 
				&& (typeof objParameter.nResoultionStyle == "number" || typeof objParameter.nResoultionStyle == "string")){
					if(typeof objParameter.nResoultionStyle == "string"){
						resoultion = parseInt(objParameter.nResoultionStyle);
					}else{
						resoultion = objParameter.nResoultionStyle;
					}
					
				if((ResoultionStyle.Resoultion_720 > resoultion) || (ResoultionStyle.Resoultion_Style_MAX <= resoultion)){
					resoultion = ResoultionStyle.Resoultion_1080;
				}	
			}
			
			if(objParameter.hasOwnProperty("x")
				&& (typeof objParameter.x == "number" || typeof objParameter.x == "string")){
				if(typeof objParameter.x == "string"){
					x = parseInt(objParameter.x);	
				}else{
					x = objParameter.x;	
				} 
				
			}
			
			if(objParameter.hasOwnProperty("y")
				&& (typeof objParameter.y == "number" || typeof objParameter.y == "string")){
				if(typeof objParameter.y == "string"){
					y = parseInt(objParameter.y);	
				}else{
					y = objParameter.y;	
				}
			}	
			
			if(objParameter.hasOwnProperty("width")
				&& (typeof objParameter.width == "number" || typeof objParameter.width == "string")){
				if(typeof objParameter.width == "string"){
					width = parseInt(objParameter.width);
				}else{
					width = objParameter.width;
				}	
			}	
			
			if(objParameter.hasOwnProperty("height")
				&& (typeof objParameter.height == "number" || typeof objParameter.height == "string")){
				if(typeof objParameter.height == "string"){
					height = parseInt(objParameter.height);
				}else{
					height = objParameter.height;
				}			
			}
			
			if(objParameter.hasOwnProperty("id")
				&& (typeof objParameter.id == "string")){
				id = objParameter.id;	
			}
			
			if(objParameter.hasOwnProperty("text")
				&& (typeof objParameter.text == "string")){
				text = objParameter.text;	
			}
				
			if(objParameter.hasOwnProperty("parent")
				&& (typeof objParameter.parent == "object")){
				parent = objParameter.parent;	
			}
		}	
	}

	var m_setDefaultValueByProgressStyle = function(){
		// set resource path
		if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
			// height = 58;
			// width = 301;
			path = path + "1080/loading/";
		} else if (resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
			path = path + "720/loading/";
			// height = 39;
			// width = 201;
		}

		//set default value
		switch(style)
		{
			case LoadingStyle.Loading_Dark_20:
				{
					// image path
					path = path + "white/20x20/";
					
					for (var i = 1; i <= 63; ++i)
					{
					    if (i < 10) 
					    {
					        imageName[i-1] = "loading_bright_20_0" + i + ".png";
					    }
					    else
					    {
					        imageName[i-1] = "loading_bright_20_" + i + ".png";
					    }	
					}

					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						textFont = 40;
						gap = -1080 * 0.009259;
						imageWidth = 301;
						imageHeight = 58;
						textWidth = 0.156771 * 1920;
						textHeight = 0.055556 * 1080;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						textFont = 26;
						gap = -720 * 0.009259;
						imageWidth = 201;
						imageHeight = 39;
						textWidth = 0.156771 * 1280;
						textHeight = 0.055556 * 720;		
					}
					
					textColor = {r:255, g:255, b:255, a:217};
				}
				break;
			
			case LoadingStyle.Loading_Dark_17:
				{
					// image path
					path = path + "white/17x17/";
					
					for (var i = 1; i <= 63; ++i)
					{
					    if (i < 10) 
					    {
					        imageName[i-1] = "loading_bright_17_0" + i + ".png";
					    }
					    else
					    {
					        imageName[i-1] = "loading_bright_17_" + i + ".png";
					    }	
					}

					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						textFont = 40;
						gap = -1080 * 0.009259;
						imageWidth = 301;
						imageHeight = 58;
						textWidth = 0.156771 * 1920;
						textHeight = 0.055556 * 1080;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						textFont = 26;
						gap = -720 * 0.009259;
						imageWidth = 201;
						imageHeight = 39;
						textWidth = 0.156771 * 1280;
						textHeight = 0.055556 * 720;			
					}
					
					textColor = {r:58, g:58, b:58, a:230};
				}
				break;
				
			case LoadingStyle.Loading_Dark_14:
				{
					// image path
					path = path + "white/14x14/";
					
					for (var i = 1; i <= 63; ++i)
					{
					    if (i < 10) 
					    {
					        imageName[i-1] = "loading_bright_14_0" + i + ".png";
					    }
					    else
					    {
					        imageName[i-1] = "loading_bright_14_" + i + ".png";
					    }	
					}

					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						textFont = 34;
						gap = -1080 * 0.005556;
						imageWidth = 206;
						imageHeight = 40;
						textWidth = 0.107292 * 1920;
						textHeight = 0.046296 * 1080;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						textFont = 22;	
						gap = -720 * 0.005556;
						imageWidth = 137;
						imageHeight = 27;
						textWidth = 0.107292 * 1280;
						textHeight = 0.046296 * 720;			
					}
					
					textColor = {r:255, g:255, b:255, a:255};
				}
				break;	
				
			case LoadingStyle.Loading_Bright_20:
				{
					// image path
					path = path + "black/20x20/";
					
					for (var i = 1; i <= 63; ++i)
					{
					    if (i < 10) 
					    {
					        imageName[i-1] = "loading_dark_20_0" + i + ".png";
					    }
					    else
					    {
					        imageName[i-1] = "loading_dark_20_" + i + ".png";
					    }	
					}
	
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						textFont = 40;
						gap = -1080 * 0.009259;
						imageWidth = 301;
						imageHeight = 58;
						textWidth = 0.156771 * 1920;
						textHeight = 0.055556 * 1080;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						textFont = 26;	
						gap = -720 * 0.009259;
						imageWidth = 201;
						imageHeight = 39;
						textWidth = 0.156771 * 1280;
						textHeight = 0.055556 * 720;				
					}
					
					textColor = {r:58, g:58, b:58, a:230};
				}
				break;
				
			case LoadingStyle.Loading_Bright_17:
				{
					// image path
					path = path + "black/17x17/";
					
					for (var i = 1; i <= 63; ++i)
					{
					    if (i < 10) 
					    {
					        imageName[i-1] = "loading_dark_17_0" + i + ".png";
					    }
					    else
					    {
					        imageName[i-1] = "loading_dark_17_" + i + ".png";
					    }	
					}
	
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						textFont = 40;
						gap = -1080 * 0.009259;
						imageWidth = 301;
						imageHeight = 58;
						textWidth = 0.156771 * 1920;
						textHeight = 0.055556 * 1080;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						textFont = 26;	
						gap = -720 * 0.009259;
						imageWidth = 201;
						imageHeight = 39;
						textWidth = 0.156771 * 1280;
						textHeight = 0.055556 * 720;				
					}
					
					textColor = {r:255, g:255, b:255, a:217};
				}
				break;
				
				case LoadingStyle.Loading_Bright_14:
				{
					// image path
					path = path + "black/14x14/";
					
					for (var i = 1; i <= 63; ++i)
					{
					    if (i < 10) 
					    {
					        imageName[i-1] = "loading_dark_14_0" + i + ".png";
					    }
					    else
					    {
					        imageName[i-1] = "loading_dark_14_" + i + ".png";
					    }	
					}
	
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						textFont = 34;
						gap = -1080 * 0.005556;
						imageWidth = 206;
						imageHeight = 40;
						textWidth = 0.107292 * 1920;
						textHeight = 0.046296 * 1080;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						textFont = 22;	
						gap = -720 * 0.005556;
						imageWidth = 137;
						imageHeight = 27;
						textWidth = 0.107292 * 1280;
						textHeight = 0.046296 * 720;			
					}
					
					textColor = {r:58, g:58, b:58, a:230};
				}
				break;
				
			case LoadingStyle.Loading_Apps_White:
				{
					// image path
					path = path + "white/20x20/";
					
					for (var i = 1; i <= 63; ++i)
					{
					    if (i < 10) 
					    {
					        imageName[i-1] = "loading_bright_20_0" + i + ".png";
					    }
					    else
					    {
					        imageName[i-1] = "loading_bright_20_" + i + ".png";
					    }	
					}

					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						textFont = 32;
						gap = 1080 * 0.009259;
						imageWidth = 301;
						imageHeight = 58;
						textWidth = 0.268750 * 1920;
						textHeight = 0.037037 * 1080;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						textFont = 21;
						gap = 720 * 0.009259;
						imageWidth = 201;
						imageHeight = 39;
						textWidth = 0.268750 * 1280;
						textHeight = 0.037037 * 720;		
					}
					
					textColor = {r:255, g:255, b:255, a:217};
				}
				break;
				
			case LoadingStyle.Loading_Apps_Black:
				{
					// image path
					path = path + "black/20x20/";
					
					for (var i = 1; i <= 63; ++i)
					{
					    if (i < 10) 
					    {
					        imageName[i-1] = "loading_dark_20_0" + i + ".png";
					    }
					    else
					    {
					        imageName[i-1] = "loading_dark_20_" + i + ".png";
					    }	
					}
	
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						textFont = 32;
						gap = 1080 * 0.009259;
						imageWidth = 301;
						imageHeight = 58;
						textWidth = 0.268750 * 1920;
						textHeight = 0.037037 * 1080;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						textFont = 21;
						gap = 720 * 0.009259;
						imageWidth = 201;
						imageHeight = 39;
						textWidth = 0.268750 * 1280;
						textHeight = 0.037037 * 720;					
					}
					
					textColor = {r:58, g:58, b:58, a:230};
				}
				break;
				
			default:
				break;
		}
	}

	var getResoultion = function(){
		return ResoultionStyle.Resoultion_1080;
	}
	
	// resoultion = getResoultion();		
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	print("path is ------------ " + path);
	loading = new Loading({
		imageNum: 63,
        x: x,
        y: y,
        parent: parent,
        imageWidth: imageWidth,
		imageHeight: imageHeight,
		textWidth: textWidth,
		textHeight: textHeight,
        gap: gap,
        imageFPS: 15,
        fontSize: textFont,
        text: text,
        imagePath: path,
        imageName: imageName,
        textColor: textColor
	});
	
	if(null != id){
		loading.id = id;	
	}
	
	return loading;
};

var LoadingStyle = {
	Loading_Bright_20:1,
	Loading_Bright_17:2,
	Loading_Bright_14:3,
	Loading_Dark_20:4,
	Loading_Dark_17:5,
	Loading_Dark_14:6,
	Loading_Apps_White:7,
	Loading_Apps_Black:8,
	Loading_Style_Max:9
};

var ResoultionStyle = {
	Resoultion_720:0,	
	Resoultion_1080:1,
	Resoultion_720_21_9:2,
	Resoultion_1080_21_9:3,	
	Resoultion_Style_MAX:4
};

winsetLoading.LoadingStyle = LoadingStyle;
winsetLoading.ResoultionStyle = ResoultionStyle;
exports = winsetLoading;

