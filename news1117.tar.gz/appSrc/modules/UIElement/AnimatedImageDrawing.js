ControlBase = Volt.require("modules/UIElement/ControlBase.js");

function setTimeout(cb, interval, param) {
	return Volt.setTimeout(cb, interval, param);
}

function clearTimeout(id){
	if (id !== undefined)  {
		Volt.clearTimeout(id);
	}
}

function setInterval(cb, interval, param){
	return Volt.setInterval(cb, interval, param);
}

function clearInterval(id){
	if (id !== undefined) {
		Volt.clearInterval(id);
	}
}

AnimatedImageDrawing = function() {       
        this.AnimateState = {
						STATE_PLAY:0,
						STATE_STOP:1,
						STATE_PAUSE:2,
						STATE_IDLE:3
					 };
	
		//variable
		this.currentFrameIdx = 0;
		this.animateDuration = 0;
		this.currentState = this.AnimateState.STATE_IDLE;
		this.isLoopFlag = true;
		this.animateTimer = null;
		this.ImgSrc = [];

        this.t_create = function(obj) {
			this.ImgInstance = new ImageWidget({
				x : 0,
				y : 0,
				width : obj.width,
				height : obj.height,
				parent : obj.parent
			});
        };
        
        this.t_destroy = function() {
			var self = this;
		
        	if(this.currentState == this.AnimateState.STATE_PLAY) {
				this.pause();
			}
			
			if(self.animateTimer != null) {
				clearInterval(self.animateTimer);
			} 
        	
        	this.ImgSrc.splice(0, this.ImgSrc.length);
			this.currentFrameIdx = -1;
			this.animateDuration = -1;
			this.currentState = null;		       	
        };

        this.t_getFocus = function() {
        	
        };

        this.t_loseFocus = function() {
        	
        };

        this.t_keyHandler = function(keycode, keytype){
			if (keytype == Volt.EVENT_KEY_RELEASE) 
			{
				return false;
			}				
			return false;
        };
           
		this.setFrames = function(frames, index) {	
			if(this.isCreated == true) {
				
				if(index < 0) {
					return false;
				}
	
				if(this.currentState == this.AnimateState.STATE_PLAY) {					
					this.pause();
				}
	
				this.ImgSrc.push(frames);
				if(index == 0) {
					this.ImgInstance.src = this.ImgSrc[0];
					this.show();
				}				
				return true;
			}
			
			return false;	
		};
		
		this.deleteAllFrames = function() {
			if(this.isCreated == true) {
				if(this.currentState == this.AnimateState.STATE_PLAY) {
					this.pause();
					this.ImgInstance.src = "";
					this.ImgSrc.splice(0, this.ImgSrc.length);
	
				} else {
					this.ImgInstance.src = "";
					this.ImgSrc.splice(0, this.ImgSrc.length);
				}
				return true;
			}
			
			return false;
		};
		
		this.setPosition = function(xPos, yPos) {
			if(this.isCreated == true) {
				this.x = xPos;
				this.y = yPos;
				return true;
			}
			
			return false;
		};
		
		this.setSize = function(Width, Height) {
			if(this.isCreated == true) {
				if(Width < 0 || Height < 0) {
					return false;
				}	
				
				this.width = Width;
				this.height = Height;
				this.ImgInstance.width = Width;
				this.ImgInstance.height = Height;
				
				return true;
				
			}
			
			return false;
		};
		
		this.play = function(frameIdx, interval) {
			var self = this;
	
			if((this.ImgSrc.length < 1) || (frameIdx < 0) || (interval <= 0)) {
				return false;
			}
	
			if(this.currentState != this.AnimateState.STATE_PLAY) {
				this.animateDuration = interval;
				this.currentState = this.AnimateState.STATE_PLAY;
	
				this.animateTimer = setInterval(function() {
					if(frameIdx < (self.ImgSrc.length - 1)) {
						frameIdx++;
						self.ImgInstance.src = self.ImgSrc[frameIdx];
						self.currentFrameIdx = frameIdx;
					} else {
						if(self.isLoopFlag == true) {
							frameIdx = 0;
							self.ImgInstance.src = self.ImgSrc[frameIdx];
							self.currentFrameIdx = frameIdx;
						} else {
							result = clearInterval(self.animateTimer);
							self.currentFrameIdx = 0;
							self.currentState = self.AnimateState.STATE_STOP;
						}
					}
	
				}, interval);
				
				return true;
			}
			
			return false;
	
		};
		
		this.pause = function() {
			var self = this;
			var result;
	
			if(this.currentState == this.AnimateState.STATE_PLAY) {
				result = clearInterval(self.animateTimer);
				this.currentState = this.AnimateState.STATE_PAUSE;
				return true;
			}
			
			return false;
		};
		
		this.resume = function() {
			var self = this;
			var result;
	
			if(this.ImgSrc.length < 1) {
				return false;
			}
	
			if(this.currentState == this.AnimateState.STATE_PAUSE) {
				this.currentState = this.AnimateState.STATE_PLAY;
	
				this.animateTimer = setInterval(function() {
					if(self.currentFrameIdx < (self.ImgSrc.length - 1)) {
						self.currentFrameIdx++;
						self.ImgInstance.src = self.ImgSrc[self.currentFrameIdx];
					} else {
						if(self.isLoopFlag == true) {
							self.currentFrameIdx = 0;
							self.ImgInstance.src = self.ImgSrc[self.currentFrameIdx];
						} else {
							result = clearInterval(self.animateTimer);
							self.currentFrameIdx = 0;
							self.currentState = self.AnimateState.STATE_STOP;
						}
					}
	
				}, self.animateDuration);
				return true;
			}
			
			return false;
		};
		
		this.stop = function() {
			var self = this;
			var stopTimer;
			var result;
	
			if(this.currentState == this.AnimateState.STATE_PLAY) {
				if(this.currentFrameIdx == (this.ImgSrc.length - 1)) {
					result = clearInterval(self.animateTimer);
					this.currentFrameIdx = 0;
				} else {
					stopTimer = setInterval(function() {
						if(self.currentFrameIdx == (self.ImgSrc.length - 1)) {
							result = clearInterval(self.animateTimer);
							reuslt = clearInterval(stopTimer);
							self.currentFrameIdx = 0;
	
						}
					}, self.animateDuration);
				}
				this.currentState = this.AnimateState.STATE_STOP;
				return true;
			}
			
			return false;
		};
		
		this.setLoop = function(bLoopFlag) {
			this.isLoopFlag = bLoopFlag;
			return true;
		};
		
		this.getLoop = function() {
			return this.isLoopFlag;
		};
		
		this.getState = function() {
			return this.currentState;
		};        
}

AnimatedImageDrawing.prototype = new ControlBase();
exports = AnimatedImageDrawing;