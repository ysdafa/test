 /** 
 * @author  Daoli Dong (d.dong@samsung.com)
 * @fileoverview Definition of Button_Generic
 * @date    2014/08/07
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

ControlBase = Volt.require("modules/UIElement/ControlBase.js");

/**
 * Class Button_Generic.
class
 * @constructor
 * @extends UIElement/ControlBase
 */
Button_Generic = function() {
    //inner data
    this.bgImg = null;
    this.textWidget = null;
    this.icon = null;
    this.state = -1;
    this.callback = null;
    this.mouseOverCallback = null;
    this.mouseOutCallback = null;
    //parameter
    this.horiAlign = 'center';
    this.vertAlign = 'center';
    this.cornerDimensions = {x:4, y:4};
    this.sideGap = scene.width*0.010417;
    this.stateImgSrc = [];
    this.stateIconSrc = [];
    this.stateText = [];
    this.stateTextFont = [];
    this.stateTextColor = [];
    this.stateBorder = [];
    this.stateColor = [];
    
    //deprecated code begin
    this.buttonState = {
        STATE_UNFOCUSED:0,
        STATE_FOCUSED:1,
        STATE_PRESSED:2,
        STATE_DISABLED:3,
        STATE_MAX:4//do NOT define enum after this!
    };
    //deprecated code end
    
    this.btnState = {
        NORMAL:0,
        FOCUS:1,
        SELECTED:2,
        DIM:3,
        STATE_MAX:4//do NOT define enum after this!
    };
    this.m_setProperty = function(obj) {
		 if (obj.hasOwnProperty("width")
            && "number" == typeof obj.width && 0<obj.width) {
            this.width = obj.width;
		 }
		 if (obj.hasOwnProperty("height")
            && "number" == typeof obj.height && 0<obj.height) {
            this.height = obj.height;
		 }
        if (obj.hasOwnProperty("cornerDimensions") 
            && "object" == typeof obj.cornerDimensions
            && null != obj.cornerDimensions) {
            this.cornerDimensions = obj.cornerDimensions;
        }
        if(obj.hasOwnProperty("horizontalAlignment") 
            && "string" == typeof obj.horizontalAlignment
            && (obj.horizontalAlignment=='left' 
                || obj.horizontalAlignment=='right' 
                || obj.horizontalAlignment=='center')) {
            this.horiAlign = obj.horizontalAlignment;
        }
        if(obj.hasOwnProperty("verticalAlignment") 
            && "string" == typeof obj.verticalAlignment
            && (obj.verticalAlignment=='bottom' 
                || obj.verticalAlignment=='top' 
                || obj.verticalAlignment=='center')) {
            this.vertAlign = obj.verticalAlignment;
        }    
        if (obj.hasOwnProperty("sideGap") 
            && "number" == typeof obj.sideGap && 0<obj.sideGap) {
            this.sideGap = obj.sideGap;
        }
        if (obj.hasOwnProperty("ImgSrc") 
            && "object" == typeof obj.ImgSrc && null != obj.ImgSrc) {
            if (obj.ImgSrc.hasOwnProperty("normal") 
                && "string" == typeof obj.ImgSrc.normal && 0 < obj.ImgSrc.normal.length) {
                this.stateImgSrc[this.btnState.NORMAL] = obj.ImgSrc.normal;
            }
            if (obj.ImgSrc.hasOwnProperty("focus") 
                && "string" == typeof obj.ImgSrc.focus && 0 < obj.ImgSrc.focus.length) {
                this.stateImgSrc[this.btnState.FOCUS] = obj.ImgSrc.focus;
            }
            if (obj.ImgSrc.hasOwnProperty("selected") 
                && "string" == typeof obj.ImgSrc.selected && 0 < obj.ImgSrc.selected.length) {
                this.stateImgSrc[this.btnState.SELECTED] = obj.ImgSrc.selected;
            }
            if (obj.ImgSrc.hasOwnProperty("dim") 
                && "string" == typeof obj.ImgSrc.dim && 0 < obj.ImgSrc.dim.length) {
                this.stateImgSrc[this.btnState.DIM] = obj.ImgSrc.dim;
            }
        }
        if (obj.hasOwnProperty("IconSrc") 
            && "object" == typeof obj.IconSrc && null != obj.IconSrc) {
            if (obj.IconSrc.hasOwnProperty("normal") 
                && "string" == typeof obj.IconSrc.normal && 0 < obj.IconSrc.normal.length) {
                this.stateIconSrc[this.btnState.NORMAL] = obj.IconSrc.normal;
            }
            if (obj.IconSrc.hasOwnProperty("focus") 
                && "string" == typeof obj.IconSrc.focus && 0 < obj.IconSrc.focus.length) {
                this.stateIconSrc[this.btnState.FOCUS] = obj.IconSrc.focus;
            }
            if (obj.IconSrc.hasOwnProperty("selected") 
                && "string" == typeof obj.IconSrc.selected && 0 < obj.IconSrc.selected.length) {
                this.stateIconSrc[this.btnState.SELECTED] = obj.IconSrc.selected;
            }
            if (obj.IconSrc.hasOwnProperty("dim") 
                && "string" == typeof obj.IconSrc.dim && 0 < obj.IconSrc.dim.length) {
                this.stateIconSrc[this.btnState.DIM] = obj.IconSrc.dim;
            }
        }
        if (obj.hasOwnProperty("text") 
            && "object" == typeof obj.text && null != obj.text) {
            if (obj.text.hasOwnProperty("normal") 
                && "string" == typeof obj.text.normal && 0 < obj.text.normal.length) {
                this.stateText[this.btnState.NORMAL] = obj.text.normal;
            }
            if (obj.text.hasOwnProperty("focus") 
                && "string" == typeof obj.text.focus && 0 < obj.text.focus.length) {
                this.stateText[this.btnState.FOCUS] = obj.text.focus;
            }
            if (obj.text.hasOwnProperty("selected") 
                && "string" == typeof obj.text.selected && 0 < obj.text.selected.length) {
                this.stateText[this.btnState.SELECTED] = obj.text.selected;
            }
            if (obj.text.hasOwnProperty("dim") 
                && "string" == typeof obj.text.dim && 0 < obj.text.dim.length) {
                this.stateText[this.btnState.DIM] = obj.text.dim;
            }
        }
        if (obj.hasOwnProperty("textFont") 
            && "object" == typeof obj.textFont && null != obj.textFont) {
            if (obj.textFont.hasOwnProperty("normal") 
                && "string" == typeof obj.textFont.normal && 0 < obj.textFont.normal.length) {
                this.stateTextFont[this.btnState.NORMAL] = obj.textFont.normal;
            }
            if (obj.textFont.hasOwnProperty("focus") 
                && "string" == typeof obj.textFont.focus && 0 < obj.textFont.focus.length) {
                this.stateTextFont[this.btnState.FOCUS] = obj.textFont.focus;
            }
            if (obj.textFont.hasOwnProperty("selected") 
                && "string" == typeof obj.textFont.selected && 0 < obj.textFont.selected.length) {
                this.stateTextFont[this.btnState.SELECTED] = obj.textFont.selected;
            }
            if (obj.textFont.hasOwnProperty("dim") 
                && "string" == typeof obj.textFont.dim && 0 < obj.textFont.dim.length) {
                this.stateTextFont[this.btnState.DIM] = obj.textFont.dim;
            }
        }
        if (obj.hasOwnProperty("textColor") 
            && "object" == typeof obj.textColor && null != obj.textColor) {
            if (obj.textColor.hasOwnProperty("normal") 
                && "object" == typeof obj.textColor.normal && null != obj.textColor.normal) {
                this.stateTextColor[this.btnState.NORMAL] = obj.textColor.normal;
            }
            if (obj.textColor.hasOwnProperty("focus") 
                && "object" == typeof obj.textColor.focus && null != obj.textColor.focus) {
                this.stateTextColor[this.btnState.FOCUS] = obj.textColor.focus;
            }
            if (obj.textColor.hasOwnProperty("selected") 
                && "object" == typeof obj.textColor.selected && null != obj.textColor.selected) {
                this.stateTextColor[this.btnState.SELECTED] = obj.textColor.selected;
            }
            if (obj.textColor.hasOwnProperty("dim") 
                && "object" == typeof obj.textColor.dim && null != obj.textColor.dim) {
                this.stateTextColor[this.btnState.DIM] = obj.textColor.dim;
            }
        }
        if (obj.hasOwnProperty("textBorder") 
            && "object" == typeof obj.textBorder && null != obj.textBorder) {
            if (obj.textBorder.hasOwnProperty("normal") && "object" == typeof obj.textBorder.normal
                && null != typeof obj.textBorder.normal
                && obj.textBorder.normal.hasOwnProperty("width")
                && obj.textBorder.normal.hasOwnProperty("color")) {
                this.stateBorder[this.btnState.NORMAL] = obj.textBorder.normal;
            }
            if (obj.textBorder.hasOwnProperty("focus") && "object" == typeof obj.textBorder.focus
                && null != typeof obj.textBorder.focus
                && obj.textBorder.focus.hasOwnProperty("width")
                && obj.textBorder.focus.hasOwnProperty("color")) {
                this.stateBorder[this.btnState.FOCUS] = obj.textBorder.focus;
            }
            if (obj.textBorder.hasOwnProperty("selected") && "object" == typeof obj.textBorder.selected
                && null != typeof obj.textBorder.selected
                && obj.textBorder.selected.hasOwnProperty("width")
                && obj.textBorder.selected.hasOwnProperty("color")) {
                this.stateBorder[this.btnState.SELECTED] = obj.textBorder.selected;
            }
            if (obj.textBorder.hasOwnProperty("dim") && "object" == typeof obj.textBorder.dim
                && null != typeof obj.textBorder.dim
                && obj.textBorder.dim.hasOwnProperty("width")
                && obj.textBorder.dim.hasOwnProperty("color")) {
                this.stateBorder[this.btnState.DIM] = obj.textBorder.dim;
            }
        }
    };
    this.m_initialise = function() {
        for(var index = 0; index < this.btnState.STATE_MAX ; index++) {
            this.stateImgSrc[index] = "";
            this.stateIconSrc[index] = "";
            this.stateText[index] = "";
        }
        //this.stateText[this.btnState.NORMAL] = 'Button';
        this.stateTextFont[this.btnState.NORMAL] = 'Samsung SVD_Light 32px';
        this.stateTextColor[this.btnState.NORMAL] = {r:255, g:255, b:255, a:204};
        this.stateBorder[this.btnState.NORMAL] = {width:1, color:{r:255, g:255, b:255, a:204}};
        this.stateColor[this.btnState.NORMAL] = {a:0};
        
        //this.stateText[this.btnState.FOCUS] = 'Button';
        this.stateTextFont[this.btnState.FOCUS] = 'Samsung SVD_Light 36px';
        this.stateTextColor[this.btnState.FOCUS] = {r:255, g:255, b:255, a:255};
        this.stateBorder[this.btnState.FOCUS] = {width:4, color:{r:255, g:255, b:255, a:255}};
        this.stateColor[this.btnState.FOCUS] = {a:0};
        
        //this.stateText[this.btnState.SELECTED] = 'Button';
        this.stateTextFont[this.btnState.SELECTED] = 'Samsung SVD_Light 36px';
        this.stateTextColor[this.btnState.SELECTED] = {r:254, g:220, b:86, a:255};
        this.stateBorder[this.btnState.SELECTED] = {width:3, color:{r:255, g:255, b:255, a:255}};
        this.stateColor[this.btnState.SELECTED] = {a:0};
        
        //this.stateText[this.btnState.DIM] = 'Button';
        this.stateTextFont[this.btnState.DIM] = 'Samsung SVD_Light 32px';
        this.stateTextColor[this.btnState.DIM] = {r:255, g:255, b:255, a:26};
        this.stateBorder[this.btnState.DIM] = {width:1, color:{r:255, g:255, b:255, a:26}};
        this.stateColor[this.btnState.DIM] = {a:0};
                
        this.state = this.btnState.NORMAL;
        this.width = 270;
        this.height = 66;
        this.rootWidget.border = this.stateBorder[this.btnState.NORMAL];
    };
    this.t_create = function(obj) {
        if(null == obj || "object" != typeof obj){
            return null;
        }
        this.m_initialise();
        this.m_setProperty(obj);
        /*
        this.debugText = new TextWidget({
                       x: this.x/2,
                       y: this.y/2,
                       width: 500,
                       height: 50,
                       text: 'debug',
                       color:{r:0,g:0,b:0,a:0},
                       textColor: {r:255, g:255, b:255, a:255},
                       parent: scene,
        });
        */
        this.bgImg = new NinePatchWidget({
            x: 0,
            y: 0,
            width: this.width,
            height: this.height,
            src: this.stateImgSrc[this.btnState.NORMAL],
            cornerDimensions: this.cornerDimensions,
            parent: this.rootWidget,
        });                 
        this.textWidget = new TextWidget({
            x: 0,
            y: 0,
            width: this.width-2*this.sideGap,
            height: this.height,
            origin: {x:0.5,y:0.5},
            anchor: {x:0.5,y:0.5},
            text: this.stateText[this.btnState.NORMAL],
            font: this.stateTextFont[this.btnState.NORMAL],
            textColor: this.stateTextColor[this.btnState.NORMAL],
            color: {r:0,g:0,b:0,a:0},
            ellipsize : true,
            horizontalAlignment: "center",
            verticalAlignment: "center",
            parent: this.rootWidget,
        }); 
        if(this.stateIconSrc[this.btnState.NORMAL].length>0){
            this.icon = new ImageWidget({
                x: 0,
                y: 0,
                origin: {x:0.5,y:0.5},
                anchor: {x:0.5, y:0.5},
                src: this.stateIconSrc[this.btnState.NORMAL],
                parent: this.rootWidget,
            });
        }
        
        return this;
    };

    this.m_UpdateState = function() {
        if (this.isCreated == true && (0 <= this.state) && (this.btnState.STATE_MAX > this.state)) {
            this.rootWidget.border = this.stateBorder[this.state];
            this.rootWidget.color = this.stateColor[this.state];
            if (this.stateImgSrc[this.state].length > 0) {
                this.bgImg.src = this.stateImgSrc[this.state];
                //this.debugText.text = this.bgImg.src;
            }            
            if (null != this.icon && this.stateIconSrc[this.state].length > 0) {
                this.icon.src = this.stateIconSrc[this.state];
            }            
            if (this.stateText[this.state].length > 0) {
                this.textWidget.text = this.stateText[this.state];
                //this.debugText.text = this.state.toString()+':'+this.stateText[this.state];
            }
            this.textWidget.textColor = this.stateTextColor[this.state];
            this.textWidget.font = this.stateTextFont[this.state];
            //need to set alignment again after set font
            this.textWidget.horizontalAlignment = this.horiAlign;
            this.textWidget.verticalAlignment = this.vertAlign;            
        }
    };
    
    this.t_getFocus = function() {
        this.state = this.btnState.FOCUS;
        this.m_UpdateState();
    };
    this.t_loseFocus = function() {
        this.state = this.btnState.NORMAL;
        this.m_UpdateState();
    };
    this.t_destroy = function() {
    };    
    this.t_show = function() {
    };
    this.t_hide = function() {
        this.loseFocus();
    };
    this.t_getDim = function() {
        this.state = this.btnState.DIM;
        this.m_UpdateState();
        //this.debugText.text = 'disabled!';
    };
    this.t_loseDim = function() {
        if(this.isFocused){
            this.state = this.btnState.FOCUS;
        }
        else{
            this.state = this.btnState.NORMAL;
        }
        this.m_UpdateState();
        //this.debugText.text = 'enabled!';
    };
    this.t_selected = function() {
        this.state = this.btnState.SELECTED;
        this.m_UpdateState();
        //this.debugText.text = 'enabled!';
    };
    this.t_unSelected = function() {
        if(this.isFocused){
            this.state = this.btnState.FOCUS;
        }
        else{
            this.state = this.btnState.NORMAL;
        }
        this.m_UpdateState();
        //this.debugText.text = 'enabled!';
    };

    this.t_setMouseOverOutCallback = function(obj){
        if(this.isCreated == true){
            if(obj.hasOwnProperty("overCallback") && typeof obj.overCallback == "function"){
                this.mouseOverCallback=obj.overCallback;
            }
            if(obj.hasOwnProperty("outCallback") && typeof obj.outCallback == "function"){
                this.mouseOutCallback=obj.outCallback;
            }
        }
    };    
    this.buttonMouseOver = function(targetWidget, eventData) {
        if(this.isDimed){
            return false;
        }
        //if(!this.isFocused){
            //this.debugText.text = 'mouse over, get focus';
            //this.getFocus();
        //}
        if(null != this.mouseOverCallback){
            this.mouseOverCallback(this);
        }
        return false;
    };
    this.buttonMouseOverBind = this.buttonMouseOver.bind(this);
    this.buttonMouseOut = function(targetWidget, eventData) {
        if(this.isDimed){
            return false;
        }
        //if(this.isFocused){
            //this.debugText.text = 'mouse out, lose focus';
            //this.loseFocus();
        //}
        if(null != this.mouseOutCallback){
            this.mouseOutCallback(this);
        }
        return false;
    };
    this.buttonMouseOutBind = this.buttonMouseOut.bind(this);
    this.t_MouseOverOut = function(isOnFlag) {
        if(this.isCreated == true && "boolean" == typeof isOnFlag){
            if(isOnFlag){
                this.bgImg.addEventListener('OnMouseOver', this.buttonMouseOverBind);
                this.bgImg.addEventListener('OnMouseOut', this.buttonMouseOutBind);
            }
            else{
                this.bgImg.removeEventListener('OnMouseOver', this.buttonMouseOverBind);
                this.bgImg.removeEventListener('OnMouseOut', this.buttonMouseOutBind);
            }
        }
    };
            
    this.t_setMouseClickCallback = function(callback) {
        if(this.isCreated == true && typeof callback == "function"){
            this.callback = callback; 
        }
    };
    this.buttonMouseClick = function(targetWidget, eventData) {
        if(this.isDimed) {
            return false;
        }
        if(!this.isFocused)
            this.getFocus();
		 if (null != this.callback) {
            this.callback(this);
        }
        return false;
    };	
    this.buttonMouseClickBind = this.buttonMouseClick.bind(this);
    this.t_MouseClick = function(isOnFlag) {
        if(this.isCreated == true && "boolean" == typeof isOnFlag){
            if(isOnFlag){
                this.bgImg.addEventListener('OnMouseClick', this.buttonMouseClickBind);
            }
            else{
                this.bgImg.removeEventListener('OnMouseClick', this.buttonMouseClickBind);
            }
        }
    };
    
    this.buttonMouseDown =function(targetWidget, eventData) {
        if(this.isDimed){
            return false;
        }
        this.state = this.btnState.SELECTED;
        this.m_UpdateState();
        return false;
    };
    this.buttonMouseDownBind = this.buttonMouseDown.bind(this);
    this.buttonMouseUp = function(targetWidget, eventData) {
        if(this.isDimed){
            return false;
        }
        this.getFocus();
        return false;
    };
    this.buttonMouseUpBind = this.buttonMouseUp.bind(this);
    this.t_MouseUpDown = function(isOnFlag) {
        if(this.isCreated == true && "boolean" == typeof isOnFlag){
            if(isOnFlag){
                this.bgImg.addEventListener('OnMouseDown', this.buttonMouseDownBind);
                this.bgImg.addEventListener('OnMouseUp', this.buttonMouseUpBind);
            }
            else{
                this.bgImg.removeEventListener('OnMouseDown', this.buttonMouseDownBind);
                this.bgImg.removeEventListener('OnMouseUp', this.buttonMouseUpBind);
            }
        }
    };
    
    this.t_keyHandler = function(keycode, keytype){
        var ret = false;
        var tmp = this;
        
        switch(keycode) {
            case Volt.KEY_JOYSTICK_OK:{                  
					if (keytype == Volt.EVENT_KEY_PRESS){			
                    this.state = this.btnState.SELECTED;
                    this.m_UpdateState();
                    if (null != tmp.callback){
                         tmp.callback(tmp);
                         return true;
                    }
					}
					else if (keytype == Volt.EVENT_KEY_RELEASE){
						this.getFocus();		
					}
                  /*
                    if(false == this.isFocused)
                        this.getFocus();
                    if (null != tmp.callback){
                        tmp.callback(tmp);
                    }
                    */
					ret = true;
				}
				break;
        
            default:
                // to do
                break;
        }        
        return ret;
    };
    
    this.getText = function(state) {
        if(typeof state=='undefined'){
            //return current text when no parameter
            return this.stateText[this.state];
        }
        else{
            if (typeof state == 'number' && (0 <= state) && (this.btnState.STATE_MAX > state)){
                return this.stateText[state];
            }
            else{
                return '';
            }
        }
    };        
    
    this.getAbsolutePosition = function() {
       return this.rootWidget.getAbsolutePosition();
    };
    
    this.getAbsoluteSize = function() {
       return this.rootWidget.getAbsoluteSize();
    };
    
    //deprecated api begin
    this.disable = function() {
        this.isFocused = false;
        this.state = this.buttonState.STATE_DISABLED;
        this.m_UpdateState();
        //this.debugText.text = 'disabled!';
    };
    this.enable = function() {
        this.state = this.buttonState.STATE_UNFOCUSED;
        this.m_UpdateState();
        //this.debugText.text = 'enabled!';
    };
    
    this.setCorner = function(cornerDim) {
        if (this.isCreated == true && 'object' == typeof cornerDim){
            this.bgImg.cornerDimensions = cornerDim;
            //this.debugText.text = 'coner set!';
        }
    }
        
    this.setImage = function(state, imgSrc) {
        if (this.isCreated == true && typeof state == 'number' && (0 <= state) && (this.buttonState.STATE_MAX > state)
            && typeof imgSrc == 'string' && 0 != imgSrc.length) {
                this.stateImgSrc[state] = imgSrc;
                this.m_UpdateState();
                //this.debugText.text = this.stateImgSrc[state];
                return true;
        }
        
        return false;
    };
    
    this.setIcon = function(state, imgSrc) {
        if(this.isCreated == true){
            if(null == this.icon){
                this.icon = new ImageWidget({
                                x: this.bgImg.width/2,
                                y: this.bgImg.height/2,
                                parent: this.root,
                                anchor: {x:0.5, y:0.5},
                });
                this.icon.hide();
            }
            if (typeof state == 'number' && (0 <= state) && (this.buttonState.STATE_MAX > state)
                && typeof imgSrc == 'string' && 0 != imgSrc.length) {	
                    this.stateIconSrc[state] = imgSrc;
                    this.m_UpdateState();
                    this.icon.show();
                    return true;
            }
        }
        return false;
    };
                
    this.setText = function(state, text) {
        if (this.isCreated == true && typeof state == 'number'
            && (0 <= state) && (this.buttonState.STATE_MAX > state)) {
            if (('string' == typeof text) && (0 != text.length)) {
                this.stateText[state] = text;
                this.m_UpdateState();
                //this.debugText.text += state.toString()+':'+this.stateText[state];
                return true;
            }	
        }	 
        
        return false;   
    };  
	this.setTextHorizontalAlignment= function(horizontalAlignment){
		 if(this.isCreated == true && typeof horizontalAlignment == 'string'
            && (horizontalAlignment=='left' || horizontalAlignment=='right' || horizontalAlignment=='center')) {
			this.textWidget.horizontalAlignment= horizontalAlignment;
           this.horiAlign = horizontalAlignment;
			return true;
		}
		return false;
	};
	this.setTextVerticalAlignment= function(verticalAlignment){
		if(this.isCreated == true && typeof verticalAlignment == 'string'
            && (verticalAlignment=='top' || verticalAlignment=='bottom' || verticalAlignment=='center')) {
			this.textWidget.verticalAlignment= verticalAlignment;
           this.vertAlign = verticalAlignment;
			return true;
		}
		return false;
	};
    
    this.setTextColor = function(state, color) {
        if (this.isCreated == true && typeof state == 'number' && typeof color == 'object'
            && (0 <= state) && (this.buttonState.STATE_MAX > state)) {
            //this.debugText.text = 'color set!';
            this.stateTextColor[state] = color;
            this.m_UpdateState();
            return true;
        }	
        
        return false;
    };
        
    this.setTextFont = function(state, font) {
        if (this.isCreated == true && ('string' == typeof font) && (0 != font.length)
            && typeof state == 'number' && (0 <= state) && (this.buttonState.STATE_MAX > state)) {
            this.stateTextFont[state] = font;
            this.m_UpdateState();
            return true;
        }	
        return false;
    };
    
    this.setBorder = function(state, border) {
        if (this.isCreated == true && typeof state == 'number' && typeof border == 'object'
            && (0 <= state) && (this.buttonState.STATE_MAX > state)) {
            this.stateBorder[state] = border;
            this.m_UpdateState();
            //this.debugText.text = 'border set!';
            return true;
        }	
        return false;
    };
    
    this.setColor = function(state, color) {
        if (this.isCreated == true && typeof state == 'number' && typeof color == 'object'
            && (0 <= state) && (this.buttonState.STATE_MAX > state)) {
            this.stateColor[state] = color;
            this.m_UpdateState();
            return true;
        }   
        
        return false;
    };
    //deprecated api end
};
Button_Generic.prototype = new ControlBase();
exports = Button_Generic;
