ControlBase = Volt.require("modules/UIElement/ControlBase.js");
function setTimeout(cb, interval, param) {
	return Volt.setTimeout(cb, interval, param);
}

    
CheckBox = function() {     
    this.Status = {
        DISABLE:0,
        NORMAL:1,
        FOCUS:2,
        
        MAX_STATUS:3//dont add status after this!
    };

    this.CheckStatus = {
        UNCHECKED:0,
        CHECKED:1
    };
              
    this.status =  this.Status.NORMAL;
    this.checkStatus = this.CheckStatus.UNCHECKED;
    this.stateTextColor = [];
    this.stateIconBGURL = [];
    this.stateBGColor = [];
    this.CursorInstance = null;
    this.isCreated = false;
    this.checkBoxBGWidget = null;
    

        
    this.t_create = function(obj) {
        this.checkBoxBGWidget = new Widget({
                x : 0,
                y : 0,
                width : obj.width,
                height : obj.height,
                color : {r:166, g:166, b:166, a:255},
                cropOverflow : true,
                parent : obj.parent
        });
    
        this.IconBGInstance = new ImageWidget({
            x : 10,
            y : 0,
            width : 50,
            height : obj.height,
            parent : this.checkBoxBGWidget,
        });
    
        this.IconInstance = new ImageWidget({
            x : 0,
            y : 0,
            width : 50,
            height : obj.height,
            parent : this.IconBGInstance,
        });
        this.IconInstance.hide();
    
        this.TextInstance = new TextWidget({
            x : 65,
            y : 0,
            width : 100,
            height : obj.height,
            font : "Helvetica 20px",
            horizontalAlignment : "left",
            verticalAlignment : "center",
            textColor : {
                r : 0,
                g : 0,
                b : 0
            },
            parent : this.checkBoxBGWidget,
        });
        this.disableCover = new Widget({
            x : 0,
            y : 0,
            width : obj.width,
            height : obj.height,
            color : {
                r : 217,
                g : 217,
                b : 217,
                a : 150
            },
            parent : this.checkBoxBGWidget,
        });
    
        this.disableCover.hide();	

        for(var index = 0; index < this.Status.MAX_STATUS ; index++) {
            this.stateTextColor[index] = {r:255, g:255, b:255, a:255};
            this.stateIconBGURL[index] = "";
            this.stateBGColor[index] = {r:166, g:166, b:166, a:255};
        }
        
        //cursor
        cursorClass	= Volt.require("modules/CursorComponent.js");
        this.CursorInstance = new cursorClass(obj.focusImages);
        this.CursorInstance.x = 0;
        this.CursorInstance.y = 0;
        this.CursorInstance.parent = obj.parent;
        this.CursorInstance.move(this.checkBoxBGWidget.x,this.checkBoxBGWidget.y,this.checkBoxBGWidget.width,this.checkBoxBGWidget.height);
        this.CursorInstance.hide();
        
        this.checkBoxBGWidget.addEventListener("OnMouseOver", this.checkboxMouseOverBind);
        this.checkBoxBGWidget.addEventListener("OnMouseOut", this.checkboxMouseOutBind);
        this.checkBoxBGWidget.addEventListener("OnMouseClick", this.checkboxMouseClickBind);
        
        this.isCreated = true;

    };
  
    this.checkboxMouseOver =function(targetWidget, eventData) {
        this.t_getFocus();
    };
    this.checkboxMouseOverBind = this.checkboxMouseOver.bind(this);
    
    this.checkboxMouseOut = function(targetWidget, eventData) {
        this.t_loseFocus();
    };
    this.checkboxMouseOutBind = this.checkboxMouseOut.bind(this);
    
    this.checkboxMouseClick = function(targetWidget, eventData) {
        if(this.status == this.Status.DISABLE)
        {
            return;
        }
        if(this.checkStatus == this.CheckStatus.UNCHECKED)
        {
            this.setCheckBoxCheckStatus(this.CheckStatus.CHECKED);
        }
        else if(this.checkStatus == this.CheckStatus.CHECKED)
        {
            this.setCheckBoxCheckStatus(this.CheckStatus.UNCHECKED);
        }
        else
        {
            return;
        }
    };	
    this.checkboxMouseClickBind = this.checkboxMouseClick.bind(this);

    
    this.t_destroy = function() {
        if(this.checkBoxBGWidget != null)
            this.checkBoxBGWidget.destroy();
        this.checkBoxBGWidget = null;
        this.isCreated = false;
    };

    this.t_getFocus = function() {
        this.status = this.Status.FOCUS;
        this.checkBoxBGWidget.color = this.stateBGColor[this.status];
        this.TextInstance.textColor = this.stateTextColor[this.status];
        this.IconBGInstance.src = this.stateIconBGURL[this.status];
        this.CursorInstance.show();
    };

    this.t_loseFocus = function() {
        this.status = this.Status.NORMAL;
        this.checkBoxBGWidget.color = this.stateBGColor[this.status];
        this.TextInstance.textColor = this.stateTextColor[this.status];
        this.IconBGInstance.src = this.stateIconBGURL[this.status];
        this.CursorInstance.hide();
    };

    this.t_show = function() {
        this.checkBoxBGWidget.show();
    };

    this.t_hide = function() {
        this.checkBoxBGWidget.hide();
    };

    this.t_keyHandler = function(keycode, keytype){
		if (keytype == Volt.EVENT_KEY_RELEASE) 
		{
			return false;
		}
        if(this.status == this.Status.DISABLE)
        {
            return true;
        }
		
        var ret = false;
        switch(keycode) {
            case Volt.KEY_JOYSTICK_OK:
                if (this.checkStatus == this.CheckStatus.CHECKED){											
                    this.setCheckBoxCheckStatus(this.CheckStatus.UNCHECKED);							
                }
                else{							
                    this.setCheckBoxCheckStatus(this.CheckStatus.CHECKED);
                }	
                ret = true;
                break;
            default:
                // to do
                break;
		}	
        return ret;
    };
       
    this.setText = function(text) {
        var typeName = typeof text;
        if (this.isCreated == true){
            if(("string" == typeName) && (0 != text.length)) {
                this.TextInstance.text = text;
                return true;
            }
        }
    
        return false;
    };
    
	this.setTextHorizontalAlignment= function(horizontalAlignment){
		if(this.isCreated == true) {
			this.TextInstance.horizontalAlignment= horizontalAlignment;
			return true;
		}
		return false;
	}
	this.setTextVerticalAlignment= function(verticalAlignment){
		if(this.isCreated == true) {
			this.TextInstance.verticalAlignment= verticalAlignment;
			return true;
		}
		return false;
	}
    
    this.setTextFont = function(font) {
        var typeName = typeof font;
        if (this.isCreated == true){
            if(("string" == typeName) && (0 != font.length)) {
                this.TextInstance.font = font;
                return true;
            }
        }
    
        return false;
    };
    
    this.setTextColor = function(state,color) {
        if ((0 <= state) && (this.Status.MAX_STATUS > state) && (this.isCreated == true)) {
            this.stateTextColor[state] = color;
            return true;
        }	

        return false;
    };
    
   this.setSpace = function(spacewidth) {
       if(this.isCreated == true){
          this.TextInstance.x = this.IconBGInstance.x + this.IconBGInstance.width + spacewidth;
       }
   };
   
    this.setCheckBoxBGColor = function(state, color) {
        if ((this.isCreated == true) && (0 <= state) && (this.Status.MAX_STATUS > state)){
            this.stateBGColor[state] = color;
            return true;
        }
        return false;
    };
    
    this.setIconBG = function(state, imgSrc) {
        var typeName = typeof imgSrc;    
        if ((this.isCreated == true) && (0 <= state) && (this.Status.MAX_STATUS > state)){            
            this.IconBGInstance.src = imgSrc;
                this.stateIconBGURL[state] = imgSrc;
                return true;
        }    
        return false;
    };
    
   this.setIconSize = function(width, height) {
       if(this.isCreated == true){
          this.IconInstance.width = width;
          this.IconInstance.height = height;
          this.IconBGInstance.width = width;
          this.IconBGInstance.height = height;
          this.IconBGInstance.y = (this.checkBoxBGWidget.height-height)/2;      
      }
   };
    
    this.setSelectedIcon = function(imgSrc) {
        var typeName = typeof imgSrc;    
        if ((this.isCreated == true) && 
            ("string" == typeName) && (0 != imgSrc.length)) {
                this.IconInstance.src = imgSrc;
                return true;
        }
    
        return false;
    };
    
    this.setCheckBoxStatus = function(status){
    
        if((this.isCreated == false) ||(status < 0) || (status > this.Status.MAX_STATUS)){
            return false;
        }
        
        if (status == this.Status.DISABLE){
            this.disableCover.show();
            this.checkBoxBGWidget.color = this.stateBGColor[this.Status.DISABLE];
            this.TextInstance.textColor = this.stateTextColor[this.Status.DISABLE];
            this.IconBGInstance.src = this.stateIconBGURL[this.Status.DISABLE];
            this.status = this.Status.DISABLE;
            this.CursorInstance.hide();
        }
        else if (status == this.Status.NORMAL){
            this.t_loseFocus();
        }
        else if(status == this.Status.FOCUS){
            this.t_getFocus();
        }
        else{
        }
        
        return true;		
        
    };
    
    this.setCheckBoxCheckStatus = function(checkStatus) {		
        if ((this.isCreated == true) && (this.status != this.Status.DISABLE)){
            if(this.checkStatus != checkStatus) {
                this.checkStatus = checkStatus;
        
                if(this.checkStatus == this.CheckStatus.UNCHECKED) {
                    this.IconInstance.hide();                    
                }
                else if(this.checkStatus == this.CheckStatus.CHECKED) {			
                    this.IconInstance.show();				
                }
                else{
                    
                }
                return true;
            }
        }
    
        return false;
    }; 
};


CheckBox.prototype = new ControlBase();
exports = CheckBox;
