/** 
 * @author  Lei Wang (l0506.wang@samsung.com)
 * @fileoverview Definition of AutoScrollTextWidget
 * @date    2014/08/01
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
const ControlBase = Volt.require("modules/UIElement/ControlBase.js");
const Button_Generic = Volt.require("modules/UIElement/Button_Generic.js");
var setTimeout=function(cb, interval, param) {
	return Volt.setTimeout(cb, interval, param);
};

var clearTimeout=function (id){
	if (id !== undefined)  {
		Volt.clearTimeout(id);
	}
};
/**
 * Class MessagePopup.
class
 * @constructor
 * @extends UIElement/ControlBase UIElement/Button_Generic
 */
 
MessagePopup = function() {
	//variable
	this.PopupBGWidget = null;
	this.focusIndex = 0;
	this.buttonCount = 0;
	this.buttonList = [];
	this.bgWidth=1920;
	this.bgHeight=0;
	this.bgColor={r:10,g:93,b:136,a:255};//0a5d88
	this.bgOpacity=0.85*255;
	this.messageText="";
	this.title="";
	this.messageWidth=1122;
	this.messageFont="34px";
	this.messageHeight=0;
	//this.messageLineSpace=14;
	this.messageOpacity=0.9*255;
	this.messageTextColor={r:255,g:255,b:255,a:255};//ffffffff
	this.messageBgColor={r:69,g:187,b:163,a:255};//45bba3
	this.messagePositionX=399;
	this.messagePositionY=48;
	this.messageVerticalAlignment="center";
	this.messageHorizontalAlignment="left";
	this.messageInstance=null;
	this.titleInstance=null;
	this.focus=false;
	this.isCreate=false;
	this.titleFont="46px";
	this.titleTextColor={r:255,g:255,b:255,a:255};//ffffffff
	this.titleWidth=1122;
	this.titleHeight=90;
	this.titlePositionX=399;
	this.titlePositionY=5;
	this.titleVerticalAlignment="center";
	this.titleHorizontalAlignment="center";
	this.buttonPositionXList=[825,684,543,402];
	this.mouseOverCallBack=null;
	this.mouseOutCallBack=null;
	this.buttonWidth = 270;
	this.buttonHeight = 66;
	this.buttonCallbackList=[];
	var sceWidth = scene.width;
	var sceHeight = scene.height;
	this.messageInstance2=null;
	this.messageText2="";
	this.messageWidth2=1122;
	this.messageFont2="34px";
	this.messageHeight2=0.044444*sceHeight;
	//this.messageLineSpace=14;
	this.messageOpacity2=0.9*255;
	this.messageTextColor2={r:69,g:187,b:163,a:0.9*255};//45bba3
	this.messageBgColor2={r:69,g:187,b:163,a:0};//45bba3
	this.messagePositionX2=399;
	
	this.messageVerticalAlignment2="center";
	this.messageHorizontalAlignment2="center";
	this.returnKeyCallback=null;
	this.timer=null;
	this.timeOutCallBack=null;
	this.timeOutTime=10000;
	this.openOverout=false;
	this.openClick=false;
	this.openUpdown=false;
	this.t_create = function(obj) {
		if(obj==null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("width")){
			this.bgWidth=obj.width;
		}
		if(obj.hasOwnProperty("height")){
			this.bgHeight=obj.height;
		}
		if(obj.hasOwnProperty("color")){
			this.bgColor=obj.color;
		}
		
		if(obj.hasOwnProperty("opacity")){
			this.bgOpacity=obj.opacity;
		}
		this.PopupBGWidget = new ImageWidget({
			width : this.bgWidth,
			height : this.bgHeight,
			color : {r:10,g:93,b:136,a:0},
			parent : obj.parent
		});
		if(obj.hasOwnProperty("bgsrc")){
			if ("string"== typeof(obj.bgsrc)){
				this.PopupBGWidget.src=obj.bgsrc;
			}
		}
		else{
			this.PopupBGWidget.color=this.bgColor;
		}
		this.PopupBGWidget.opacity=this.bgOpacity;
		this.PopupBGWidget.hide();
		this.buttonPositionY=this.bgHeight-96;
		this.messagePositionY2=this.buttonPositionY-(0.042593+0.044444)*scene.height;
		this.initx=this.rootWidget.getAbsolutePosition().x;
		this.inity=this.rootWidget.getAbsolutePosition().y;
		this.isCreate=true;
	};
	
	this.t_destroy = function() {
		this.focusIndex = -1;
		this.PopupBGWidget = null;
		if(this.timer!=null){
			clearTimeout(this.timer);
			this.timer=null;
		}
	};
	
	this.t_show = function() {
		this.PopupBGWidget.show();
		if(this.timer!=null){
			clearTimeout(this.timer);
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
	};
	
	this.t_hide = function() {
		this.PopupBGWidget.hide();
	};
	
	this.t_keyHandler = function(keycode, keytype) {
		if(this.isCreated == false) {
			return false;
		}
		if (keytype == Volt.EVENT_KEY_RELEASE) {
			return false;
		}		
		
		var bRet = false;
		switch(keycode) {
			case Volt.KEY_JOYSTICK_RIGHT:
				if(this.focusIndex < this.buttonCount-1) {
					this.buttonList[this.focusIndex].loseFocus();
					this.focusIndex++;
					this.buttonList[this.focusIndex].getFocus();
					bRet = true;
				}
				break;
			case Volt.KEY_JOYSTICK_LEFT:
				if(this.focusIndex > 0) {
					this.buttonList[this.focusIndex].loseFocus();
					this.focusIndex--;
					this.buttonList[this.focusIndex].getFocus();
					bRet = true;
				}
				break;
			case Volt.KEY_JOYSTICK_OK:
					this.buttonList[this.focusIndex].keyHandler(keycode,keytype);
					bRet = true;			
				break;
			case Volt.KEY_RETURN:
				if(this.returnKeyCallback!=null){
					this.returnKeyCallback();
				}
				bRet = true;			
			break;
			default:
				break;
		}
		if(bRet == true){
			if(this.timer!=null){
				clearTimeout(this.timer);
				var self=this;
				self.timer=setTimeout(function(){
					self.timeOutCallBack();
				},self.timeOutTime);
			}
		}
		return bRet;
	};
	
	this.setReturnKeyCallBack=function(callback){
		if(true == this.isCreate){
			this.returnKeyCallback=callback;
		}
	};
	
	this.startTimeOut=function(obj){
		if(obj==null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("time") && obj.time > 0){
			this.timeOutTime=obj.time;
		} else {
		    return;
		}
		if(obj.hasOwnProperty("callback")){
			this.timeOutCallBack=obj.callback;
		}
		if(this.timeOutCallBack!=null){
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
	};
	
	this.setTitle=function(obj) {
		if(false == this.isCreate){
			return false;
		}
		if(obj==null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("x")){
			this.titlePositionX=obj.x;
		}
		if(obj.hasOwnProperty("y")){
			this.titlePositionY=obj.y;
		}
		if(obj.hasOwnProperty("width")){
			this.titleWidth=obj.width;
		}
		if(obj.hasOwnProperty("height")){
			this.titleHeight=obj.height;
		}
		if(obj.hasOwnProperty("textcolor")){
			this.titleTextColor=obj.textcolor;
		}
		if(obj.hasOwnProperty("font")){
			if ("string"== typeof(obj.font)){
				this.titleFont=obj.font;
			}	
		}
		if(obj.hasOwnProperty("VerticalAlignment")){
			this.titleVerticalAlignment=obj.VerticalAlignment;
		}
		if(obj.hasOwnProperty("HorizontalAlignment")){
			this.titleHorizontalAlignment=obj.HorizontalAlignment;
		}
		if(obj.hasOwnProperty("title")){
			if ("string" == typeof(obj.title)){
				this.title=obj.title;
			}
		}
		if(this.titleInstance==null){		
			this.titleInstance = new TextWidget({
				parent : this.PopupBGWidget
			});
			this.lineInstance = new Widget({
				height : 1,
				parent : this.PopupBGWidget
			});
		}
		this.titleInstance.x=this.titlePositionX;
		this.titleInstance.y=this.titlePositionY;
		this.titleInstance.width=this.titleWidth;
		this.titleInstance.height=this.titleHeight;
		this.titleInstance.font=this.titleFont;
		this.titleInstance.horizontalAlignment=this.titleHorizontalAlignment;
		this.titleInstance.verticalAlignment=this.titleVerticalAlignment;
		this.titleInstance.text=this.title;
		this.titleInstance.textColor=this.titleTextColor;
		this.lineInstance.x=this.titlePositionX;
		this.lineInstance.y=this.titlePositionY+this.titleHeight;
		this.lineInstance.width=this.titleWidth;
		this.lineInstance.color=this.titleTextColor;
		if(obj.hasOwnProperty("titleopacity")){
			this.titleInstance.opacity=obj.titleopacity;
		}
		if(obj.hasOwnProperty("bgColor")){
			this.titleInstance.color=obj.bgColor;
		}
		this.lineInstance.opacity=0.2*255;
		if(this.messagePositionY==48){
			this.messagePositionY=this.titlePositionY+this.titleHeight+13;
			if(this.messageInstance!=null){
				this.messageInstance.y=this.messagePositionY;
			}
		}
		return true;
	};

	this.setMessage=function(obj) {
		if(false == this.isCreate){
			return false;
		}
		if(obj==null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("x")){
			this.messagePositionX=obj.x;
		}
		if(obj.hasOwnProperty("y")){
			this.messagePositionY=obj.y;
		}
		if(obj.hasOwnProperty("width")){
			this.messageWidth=obj.width;
		}
		if(obj.hasOwnProperty("height")){
			this.messageHeight=obj.height;
		}
		if(obj.hasOwnProperty("textcolor")){
			this.messageTextColor=obj.textcolor;
		}
		if(obj.hasOwnProperty("font")){
			if ("string"== typeof(obj.font)){
				this.messageFont=obj.font;
			}
		}
		if(obj.hasOwnProperty("VerticalAlignment")){
			this.messageVerticalAlignment=obj.VerticalAlignment;
		}
		if(obj.hasOwnProperty("HorizontalAlignment")){
			this.messageHorizontalAlignment=obj.HorizontalAlignment;
		}
		
		if(obj.hasOwnProperty("opacity")){
			this.messageOpacity=obj.opacity;
		}
		if(obj.hasOwnProperty("message")){
			if ("string"== typeof(obj.message)){
				this.messageText=obj.message;
			}
		}
		if(this.messageInstance==null){
			this.messageInstance = new TextWidget({
				x : this.messagePositionX,
				y : this.messagePositionY,
				width :this.messageWidth,
				height : this.messageHeight,
				parent : this.PopupBGWidget
			});
		}
		else{
			this.messageInstance.x=this.messagePositionX;
			this.messageInstance.y=this.messagePositionY;
			this.messageInstance.width=this.messageWidth;
			this.messageInstance.height=this.messageHeight;
		}
		this.messageInstance.font=this.messageFont;
		this.messageInstance.horizontalAlignment=this.messageHorizontalAlignment;
		this.messageInstance.verticalAlignment=this.messageVerticalAlignment;
		this.messageInstance.text=this.messageText;
		this.messageInstance.textColor=this.messageTextColor;
		this.messageInstance.opacity=this.messageOpacity;	
		if(obj.hasOwnProperty("bgcolor")){
			this.messageBgColor=obj.bgcolor;
			this.messageInstance.color=this.messageBgColor;
		}
		var sheight = scene.height;
		if(this.messagePositionY2==(48+this.messageHeight+0.02963*sceHeight)){
			this.messagePositionY2=this.messagePositionY+this.messageHeight+0.02963*sheight;
			if(this.messageInstance2 != null){
				this.messageInstance2.y=this.messagePositionY2;
			}
		}
		return true;
	};
	
	//set the second kind message
	this.setSecondMessage=function(obj) {
		if(false == this.isCreate){
			return false;
		}
		if(obj==null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("x")){
			this.messagePositionX2=obj.x;
		}
		if(obj.hasOwnProperty("y")){
			this.messagePositionY2=obj.y;
		}
		if(obj.hasOwnProperty("width")){
			this.messageWidth2=obj.width;
		}
		if(obj.hasOwnProperty("height")){
			this.messageHeight2=obj.height;
		}
		if(obj.hasOwnProperty("textcolor")){
			this.messageTextColor2=obj.textcolor;
		}
		if(obj.hasOwnProperty("font")){
			if ("string"== typeof(obj.font)){
				this.messageFont2=obj.font;
			}
		}
		if(obj.hasOwnProperty("VerticalAlignment")){
			this.messageVerticalAlignment2=obj.VerticalAlignment;
		}
		if(obj.hasOwnProperty("HorizontalAlignment")){
			this.messageHorizontalAlignment2=obj.HorizontalAlignment;
		}
		
		if(obj.hasOwnProperty("opacity")){
			this.messageOpacity2=obj.opacity;
		}
		if(obj.hasOwnProperty("message")){
			if ("string"== typeof(obj.message)){
				this.messageText2=obj.message;
			}
		}
		if(this.messageInstance2==null){
			this.messageInstance2 = new TextWidget({
				parent : this.PopupBGWidget
			});
		}
		this.messageInstance2.x=this.messagePositionX2;
		this.messageInstance2.y=this.messagePositionY2;
		this.messageInstance2.width=this.messageWidth2;
		this.messageInstance2.height=this.messageHeight2;
		this.messageInstance2.font=this.messageFont2;
		this.messageInstance2.horizontalAlignment=this.messageHorizontalAlignment2;
		this.messageInstance2.verticalAlignment=this.messageVerticalAlignment2;
		this.messageInstance2.text=this.messageText2;
		this.messageInstance2.textColor=this.messageTextColor2;
		this.messageInstance2.opacity=this.messageOpacity2;
		if(obj.hasOwnProperty("bgcolor")){
			this.messageBgColor2=obj.bgcolor;
			this.messageInstance2.color=this.messageBgColor2;
		}		
		return true;
	};
	/*
	 * set Button Properties
	 */
	/*
	 * set Button Properties
	 */
	this.setButton = function(buttonPropertyobj) {
		if(false == this.isCreate){
			return false;
		}
		if(buttonPropertyobj==null||typeof(buttonPropertyobj) == "undefined"){
			return false;
		}
		var buttonCount=buttonPropertyobj.length;
		if(buttonCount > 0) {
			var firstset=true;
			this.buttonCount = buttonCount;
			this.buttonPositionX = this.buttonPositionXList[buttonCount-1];
			var buttonpositionx = 0;
			//var buttonpositiony = 0;
			var num=this.buttonList.length;
			if(num!=0){
				for(var i=num-1;i>=0;i--){
					this.buttonList[i].destroy();
					this.buttonList.splice(i,0);
				}
				this.buttonList = [];
			}
			for(var index = 0; index < buttonCount; index++) {
				var tempButton = new Button_Generic();
				this.buttonList.push(tempButton);
				if(buttonPropertyobj[index].hasOwnProperty("x")){
					buttonpositionx=buttonPropertyobj[index].x;
				}
				else {
					buttonpositionx=this.buttonPositionX+282*index;
				}
				if(buttonPropertyobj[index].hasOwnProperty("y")){
					this.buttonPositionY=buttonPropertyobj[index].y;
				}
				if(buttonPropertyobj[index].hasOwnProperty("width")){
					this.buttonWidth=buttonPropertyobj[index].width;
				}
				if(buttonPropertyobj[index].hasOwnProperty("height")){
					this.buttonHeight=buttonPropertyobj[index].height;
				}
				
				this.buttonList[index].create({
					x : buttonpositionx,
					y : this.buttonPositionY,
					width : this.buttonWidth,
					height : this.buttonHeight,
					parent:this.PopupBGWidget
				});
				if(buttonPropertyobj[index].hasOwnProperty("buttonborder")){
					if(buttonPropertyobj[index].buttonborder.hasOwnProperty("normal")){
						this.buttonList[index].setBorder(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttonborder.normal);
					}
					if(buttonPropertyobj[index].buttonborder.hasOwnProperty("focus")){
						this.buttonList[index].setBorder(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttonborder.focus);
					}
					if(buttonPropertyobj[index].buttonborder.hasOwnProperty("selected")){
						this.buttonList[index].setBorder(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttonborder.selected);
					}
					if(buttonPropertyobj[index].buttonborder.hasOwnProperty("dim")){
						this.buttonList[index].setBorder(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttonborder.dim);
					}
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttontextcolor")){
					if(buttonPropertyobj[index].buttontextcolor.hasOwnProperty("normal")){
						this.buttonList[index].setTextColor(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttontextcolor.normal);
					}
					if(buttonPropertyobj[index].buttontextcolor.hasOwnProperty("focus")){
						this.buttonList[index].setTextColor(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttontextcolor.focus);
					}
					if(buttonPropertyobj[index].buttontextcolor.hasOwnProperty("selected")){
						this.buttonList[index].setTextColor(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttontextcolor.selected);
					}
					if(buttonPropertyobj[index].buttontextcolor.hasOwnProperty("dim")){
						this.buttonList[index].setTextColor(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttontextcolor.dim);
					}
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttontextfont")){
					if(buttonPropertyobj[index].buttontextfont.hasOwnProperty("normal")){
						if ("string" == typeof(buttonPropertyobj[index].buttontextfont.normal)){
							this.buttonList[index].setTextFont(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttontextfont.normal);
						}
					}
					if(buttonPropertyobj[index].buttontextfont.hasOwnProperty("focus")){
						if ("string" == typeof(buttonPropertyobj[index].buttontextfont.focus)){
							this.buttonList[index].setTextFont(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttontextfont.focus);
						}
					}
					if(buttonPropertyobj[index].buttontextfont.hasOwnProperty("selected")){
						if ("string" == typeof(buttonPropertyobj[index].buttontextfont.selected)){
							this.buttonList[index].setTextFont(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttontextfont.selected);
						}
					}
					if(buttonPropertyobj[index].buttontextfont.hasOwnProperty("dim")){
						if ("string" == typeof(buttonPropertyobj[index].buttontextfont.dim)){
							this.buttonList[index].setTextFont(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttontextfont.dim);
						}
					}
				}
				
				if(buttonPropertyobj[index].hasOwnProperty("buttontextVerticalAlignment")){
					this.buttonList[index].setTextVerticalAlignment(buttonPropertyobj[index].buttontextVerticalAlignment);
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttontextHorizontalAlignment")){
					this.buttonList[index].setTextHorizontalAlignment(buttonPropertyobj[index].buttontextHorizontalAlignment);
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttontext")){
					if(buttonPropertyobj[index].buttontext.hasOwnProperty("normal")){
						if ("string" == typeof(buttonPropertyobj[index].buttontext.normal)){
							this.buttonList[index].setText(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttontext.normal);
						}
					}
					if(buttonPropertyobj[index].buttontext.hasOwnProperty("focus")){
						if ("string" == typeof(buttonPropertyobj[index].buttontext.focus)){
							this.buttonList[index].setText(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttontext.focus);
						}
					}
					if(buttonPropertyobj[index].buttontext.hasOwnProperty("selected")){
						if ("string" == typeof(buttonPropertyobj[index].buttontext.selected)){
							this.buttonList[index].setText(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttontext.selected);
						}
					}
					if(buttonPropertyobj[index].buttontext.hasOwnProperty("dim")){
						if ("string" == typeof(buttonPropertyobj[index].buttontext.dim)){
							this.buttonList[index].setText(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttontext.dim);
						}
					}
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttonimage")){
					if(buttonPropertyobj[index].buttonimage.hasOwnProperty("normal")){
						this.buttonList[index].setImage(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttonimage.normal);
					}
					if(buttonPropertyobj[index].buttonimage.hasOwnProperty("focus")){
						this.buttonList[index].setImage(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttonimage.focus);
					}
					if(buttonPropertyobj[index].buttonimage.hasOwnProperty("selected")){
						this.buttonList[index].setImage(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttonimage.selected);
					}
					if(buttonPropertyobj[index].buttonimage.hasOwnProperty("dim")){
						this.buttonList[index].setImage(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttonimage.dim);
					}
				}
				if(buttonPropertyobj[index].hasOwnProperty("callbackfunction")){
					if(firstset == true){
						this.buttonCallbackList=[];
						firstset=false;
					}
					this.buttonCallbackList[index]=buttonPropertyobj[index].callbackfunction;
					this.buttonList[index].setMouseClickCallback(this.t_buttonClickCallbackBind);
				}
				this.buttonList[index].index=index;
				this.buttonList[index].show();			
			}
			if(this.focus==true){
				if(this.focusIndex<buttonCount)
				{
					this.buttonList[this.focusIndex].getFocus();
				}
				
			}
			return true;
		}
		return false;
	};
	
	this.t_buttonClickCallback=function(widget){
		var index=widget.index;
		if(typeof(this.buttonCallbackList[index]) != "undefined"||this.buttonCallbackList[index]!=null){
			this.buttonCallbackList[index]();
		}
		if(this.timer!=null){
			clearTimeout(this.timer);
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
	};
	this.t_buttonClickCallbackBind=this.t_buttonClickCallback.bind(this);
	
	this.m_buttonMouseOverCallBack = function(widget){
		var index=widget.index;
		if(this.focus == true && this.focusIndex!=index){
			this.buttonList[this.focusIndex].loseFocus();
			this.focusIndex=index;
			this.buttonList[this.focusIndex].getFocus();
			if(this.timer!=null){
				clearTimeout(this.timer);
				var self=this;
				self.timer=setTimeout(function(){
					self.timeOutCallBack();
				},self.timeOutTime);
			}
		}
	};
	this.m_buttonMouseOverCallBackBind=this.m_buttonMouseOverCallBack.bind(this);
	
	this.m_buttonMouseOutCallBack = function(widget){
		
	};
	this.m_buttonMouseOutCallBackBind=this.m_buttonMouseOutCallBack.bind(this);
	
	this.t_messagePopupMouseOver = function(targetWidget, eventData) {
		//this.getFocus();
		if(null!=this.mouseOverCallBack){
			this.mouseOverCallBack(this);
		}
		if(this.timer!=null){
			clearTimeout(this.timer);
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
		return false;
	};
	this.t_messagePopupMouseOverBind=this.t_messagePopupMouseOver.bind(this);

	this.t_messagePopupMouseOut = function(targetWidget, eventData) {
		var x=eventData.coordinates.x;
		var y=eventData.coordinates.y;
		var abx=x-this.initx;
		var aby=y-this.inity;
		if(abx<=this.bgWidth&&abx>=0&&aby<=this.bgHeight&&aby>=0){
			return false;
		}
		else{
			//this.loseFocus();
			if(null!=this.mouseOutCallBack){
				this.mouseOutCallBack(this);
			}
		}
		if(this.timer!=null){
			clearTimeout(this.timer);
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
		return false;
	};
	this.t_messagePopupMouseOutBind=this.t_messagePopupMouseOut.bind(this);
	
	this.t_setMouseOverOutCallback = function(obj){
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("overCallback")){
			this.mouseOverCallBack=obj.overCallback;
		}
		if(obj.hasOwnProperty("outCallback")){
			this.mouseOutCallBack=obj.outCallback;
		}
	}
	
	this.t_MouseOverOut = function(isOnFlag){
		if(this.isCreated == true){
			if(isOnFlag==true){
				if(this.openOverout==false){
					this.PopupBGWidget.addEventListener("OnMouseOver",this.t_messagePopupMouseOverBind);										
					this.PopupBGWidget.addEventListener("OnMouseOut",this.t_messagePopupMouseOutBind);
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseOverOut(true);
							this.buttonList[index].setMouseOverOutCallback({overCallback:this.m_buttonMouseOverCallBackBind,
																			outCallback:this.m_buttonMouseOutCallBackBind});
						}					
							
					}
					this.openOverout=true;
				}
			}
			else{
				if(this.openOverout==true){
					this.PopupBGWidget.removeEventListener("OnMouseOver",this.t_messagePopupMouseOverBind);										
					this.PopupBGWidget.removeEventListener("OnMouseOut",this.t_messagePopupMouseOutBind);
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseOverOut(false);
						}					
							
					}
					this.openOverout=false;
				}
			}
		}
	};
	
	this.t_MouseUpDown = function(isOnFlag){
		if(this.isCreated == true){
			if(isOnFlag==true){
				if(this.openUpdown==false){
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseUpDown(true);
						}					
							
					}
					this.openUpdown=true;
				}	
			}
			else{
				if(this.openUpdown==true){
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseUpDown(false);
						}					
							
					}
					this.openUpdown=false;
				}	
			}
		}
	};
	
	this.t_MouseClick= function(isOnFlag){
		if(this.isCreated == true){
			if(isOnFlag==true){
				if(this.openClick==false){
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseClick(true);
							
						}					
							
					}
					this.openClick=true;
				}	
			}
			else{
				if(this.openClick==true){
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseClick(false);	
						}							
					}
					this.openClick=false;
				}	
			}
		}
	};
	
	this.t_getFocus = function() {
		if(true == this.focus){
			return false;
		}
		else{
			this.buttonList[this.focusIndex].getFocus();
			this.focus=true;
			return true;
		}
	    	
	};
	
	this.t_loseFocus = function() {
		
		if(false == this.focus){
			return false;
		}
		else{
			this.buttonList[this.focusIndex].loseFocus();
			this.focus=false;
			return true;
		}
	};

	this.setFocusBtnIndex = function(focusIdx) {	
		if(focusIdx >= 0 && focusIdx < this.buttonCount) {
			this.focusIndex = focusIdx;
			
			return true;
		}
		return false;
	};
}

MessagePopup.prototype = new ControlBase();
exports = MessagePopup;
