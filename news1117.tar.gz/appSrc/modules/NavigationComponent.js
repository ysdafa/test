var NavigationComponent = function(startingZone) {
	this.zoneMap = [
		[startingZone]
	];
	this.currentZone = {
		x: 0,
		y: 0
	};
};

NavigationComponent.prototype.addRow = function(zone) {
	this.zoneMap.push([zone]);
};

NavigationComponent.prototype.addRowAtIndex = function(rowIndex, zone) {
	this.zoneMap.splice(rowIndex, 0, [zone]);
};

NavigationComponent.prototype.addColumn = function(rowIndex, zone) {
	this.zoneMap[rowIndex].push(zone);
};

NavigationComponent.prototype.addColumnAtIndex = function(rowIndex, columnIndex, zone) {
	this.zoneMap[rowIndex].splice(columnIndex, 0, zone);
};

NavigationComponent.prototype.handleKey = function(key) {
	var result = this.zoneMap[this.currentZone.y][this.currentZone.x].handleKey(key);
	if (result.handled) {
		return result;
	} else {
		if (this.keyDirectionFunctions[key]) {
			return this.keyDirectionFunctions[key].call(this);
		}
	}
};


NavigationComponent.prototype.keyDirectionFunctions = {
	up: function() {
		if (this.currentZone.y > 0) {
			this.currentZone.y--;
			if (this.currentZone.x >= this.zoneMap[this.currentZone.y].length) {
				this.currentZone.x = this.zoneMap[this.currentZone.y].length - 1;
			}
			return this.zoneMap[this.currentZone.y][this.currentZone.x].handleKey("focus");
		} else {
			return {
				handled: false
			};
		}
	},
	down: function() {
		if (this.currentZone.y < this.zoneMap.length - 1) {
			this.currentZone.y++;
			if (this.currentZone.x >= this.zoneMap[this.currentZone.y].length) {
				this.currentZone.x = this.zoneMap[this.currentZone.y].length - 1;
			}
			return this.zoneMap[this.currentZone.y][this.currentZone.x].handleKey("focus");
		} else {
			return {
				handled: false
			};
		}
	},
	left: function() {
		if (this.currentZone.x > 0) {
			this.currentZone.x--;
			return this.zoneMap[this.currentZone.y][this.currentZone.x].handleKey("focus");
		} else {
			return {
				handled: false
			};
		}
	},
	right: function() {
		if (this.currentZone.x < this.zoneMap[this.currentZone.y].length - 1) {
			this.currentZone.x++;
			return this.zoneMap[this.currentZone.y][this.currentZone.x].handleKey("focus");
		} else {
			return {
				handled: false
			};
		}
	}
};

exports = NavigationComponent;