

var Message = Volt.require("modules/Message/Message.js");

var isArray = function (o) {
    return (o instanceof Array) ||
        (Object.prototype.toString.apply(o) === '[object Array]');
};

var MessageCenter = {
	id:"Message_Manager",
	
	m_workersInc:null,
	m_firstScreenInc:null,
	
	m_MessageListeners:{},
	
	m_getWorkerName:function(workerInc){
		for(var index in this.m_workersInc) {
			if (workerInc == this.m_workersInc[index] ) {
				return index;
			}
		}
	},
	
	m_getWorkerInc:function(workerName){
		if (!this.m_workersInc[workerName]) {
			return null;
		}
		
		return this.m_workersInc[workerName];
	},
	
	m_onMessageCenter:function(Message){
		
		// Message has 2 parameters  
		//1 > messageData  
		//2 > the corresponding worker instance
		var messageData = Message.data
		
		var MessageObj = JSON.parse(Message.data);
		
		// if the woker provide the name property it will better
		MessageObj.sender = MessageCenter.m_getWorkerName.call(MessageCenter, Message.worker);
		
		MessageCenter.handleMessageCenter.call(MessageCenter, MessageObj);
	},
	
	sendMessage:function(messageType, messageSubtype, sender, receiver, data){
		
		if (typeof (messageType) == "object") {
			var workerInc = this.m_getWorkerInc(messageType.receiver);
			
			if (workerInc != null) {
				workerInc.postMessage(JSON.stringify(messageType));	
			}
			return;
		}
		
		if (arguments.length < 4) {
			return;
		}
		
		var newMessage = new Message();
		newMessage.messageType = messageType;
		newMessage.messageSubtype = messageSubtype;
		
		newMessage.sender = "FirstScreen";
		
		if (arguments.length >= 5) {
			for(var index in data) {
				newMessage.makeValue(index, data[index]);
			}
		} 
		
		if (typeof(receiver) == "string") {
			
			if (receiver == "null" || receiver == "") {
				for(var index in this.m_workersInc) {
					newMessage.receiver = index;
					print("The Message is ::" + newMessage.toString());
					this.m_workersInc[index].postMessage(newMessage.toString());	
				}
			} else {
				newMessage.receiver = receiver;
				
				print("The Message is ::" + newMessage.toString());
				
				var workerInc = this.m_getWorkerInc(receiver);
					
				if (workerInc != null) {
					workerInc.postMessage(newMessage.toString());	
				}
			}
		
		} else if (isArray(receiver)) {
			// the multi receivers
			for(var index = 0; index < receiver.length; index ++) {
				
				newMessage.receiver = receiver[index];
				
				print("The Message is ::" + newMessage.toString());
				
				var workerInc = this.m_getWorkerInc(receiver[index]);
					
				if (workerInc != null) {
					workerInc.postMessage(newMessage.toString());	
				}
			}
			
		}
	},
	
///////////////////////////////////////////////////////////////////////////////////////////////////////////
	m_callMessageListeners:function(Message){
		if (!this.m_MessageListeners[Message.type]) {
			return;
		}
		
		var tempListeners = this.m_MessageListeners[Message.type];
		for(var index = 0 ; index < tempListeners.length; index ++) {
			if (tempListeners[index].m_object == null) {
				tempListeners[index].m_listener(Message);
			} else {
				tempListeners[index].m_listener.call(tempListeners[index].m_object, Message);
			}
			
		}
	},

	addMessageListener:function(MessageType, listener, object){
		if (!listener || arguments.length < 2) {
			return;
		}
		
		if (!this.m_MessageListeners[MessageType]) {	
			this.m_MessageListeners[MessageType] = [];
		}

	    var tempObj = null;
	    if (arguments.length == 3) {
	    	tempObj = {
				m_listener:listener,
				m_object:object
			}
	    } else {
	    	tempObj = {
				m_listener:listener,
				m_object:null
			}
	    }
		
		this.m_MessageListeners[MessageType].push(tempObj);
	},
	
	handleMessage:function(Message){
		print("Handle the message from the PANELS");
		this.m_callMessageListeners(Message);
	},

	removeMessageListener:function(MessageType, listener){
		if (!listener) {
			return;
		}

		var tempListeners = this.m_MessageListeners[MessageType];
		if (!tempListeners) {
			return;
		}

		var index = tempListeners.indexOf(listener);
		if (index >= 0) {
			if (tempListeners.length == 1) {
				delete this.m_MessageListeners[MessageType];
			} else {
				tempListeners.splice(index, 1);
			}
		}
	},
///////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	registerWorker:function(workerInstance, workerName){
		
		if (this.m_workersInc == null) {
			this.m_workersInc = new Object();
		}
		
		if (!this.m_workersInc[workerName]) {
			this.m_workersInc[workerName] = workerInstance;
			workerInstance.onMessage = this.m_onMessageCenter; // Receive all of the workers's messages
		}
		
	},
	
	handleMessageCenter:function(Message){
		var MessageObj = null;
		if (typeof(Message) == "string") {
			MessageObj = JSON.parse(Message);
		} else {
			MessageObj = Message;
		}
		
		if (MessageObj.receiver == "FirstScreen") {
			
			this.handleMessage(Message);
			return;
		}
		
		if (this.m_workersInc[MessageObj.receiver]){
			this.m_workersInc[MessageObj.receiver].postMessage(JSON.stringify(Message));
			
			return;
		}
		
		// Send to other module
	}
}
exports = MessageCenter;

// Just used in firstScreen side

/*
var messgaeManager = require("MessageManager.js");

var workerInc = new VoltWorker({
	uri:"app.js",
	scene:new widget({....})  // do not need to set the onMessage callback
})


messgaeManager.registerWorker(wokerInc_APP, "AppPanel");
messgaeManager.registerWorker(wokerInc_MOVIE, "MoviePanel");
messgaeManager.registerWorker(wokerInc_GAME, "GamePanel");

var data = {
	name:"volt",
	age:2
}

messgaeManager.sendMessage("MessageType", "SubType", "sender", "receiver", data);

if the message reciever is FirstScreen

messgaeManager.addMessageListener(messageType, callbackfunc, this_property(Non-essential));

messgaeManager.removeMessageListener(messageType, callbackfunc);

Attention: In this side can not use addMessageListener(keyvalue, callback);
Just use Volt.addEventListener(keyValue, callback);


*/