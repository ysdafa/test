
(function () {
    Volt.pakages = {
        instances: {},
        modules: {}
    };
    //Volt.BASE_PATH = 'http://10.240.135.113:8080/'; // In case server environment
    Volt.BASE_PATH = 'file://';
    Volt.require = function (path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            if (path.indexOf('$') == -1) {
                return require(Volt.browser ? path : Volt.BASE_PATH + path);
            } else {
                return require(path);
            }
        }
    };
})();

////////////////////////////////////////////////////////////////////////////////
//// APP CONFIG
////////////////////////////////////////////////////////////////////////////////
// Change the config when merging to [INT]

Volt.__INT__ = true;  // Uncomment this when merging from [FET] to [INT]
Volt.AppsVersion = "A-AQUAGDSP-2141";   // Update this when merging from [FET] to [INT]

////////////////////////////////////////////////////////////////////////////////
//// GLOBALS
////////////////////////////////////////////////////////////////////////////////
/**
 * Include modules
 */
if (Volt.__INT__) {
    //// This should be required first.
    Volt.require('distribution.min.js');
}
//// Remove the path '$VOLT_ROOT/modules/' in require to fix bug of require twice.
// ALERT: This should NOT be commented.
Volt.require('$VOLT_ROOT/modules/modules_distribution.min.js');

HALOUtil.applyOrientation();
Volt.require('lib/volt-multi-resolution.js');
Volt.require('lib/volt-common.js');
Volt.require('lib/volt-nav.js');

Volt.require('lib/volt-debug.js').init({
    tag: '[APPS]',  // Tag of log
    extra: Volt.__INT__ ? false : true,    // Extra Information of log(file name, func name, line number)
    dlogutil: Volt.__INT__ ? false : true  // whether to show in dlogutil
});

Volt.require('app/router.js');
Volt.KpiMapper = Volt.require('app/common/kpiMapper.js');
Volt.DeviceInfoModel = Volt.require('app/models/deviceInfoModel.js');
Volt.i18n = Volt.require('lib/volt-multilingual.js');

var Backbone = Volt.require('lib/volt-backbone.js'),
    AppInstallMgr = Volt.require('app/common/appInstallMgr.js'),
    //Models = Volt.require('app/models/models.js'),
    DownloadedAppsMgr = Volt.require('app/common/downloadedAppsMgr.js'),
    EventMediator = Volt.require('app/common/eventMediator.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    voltapi = Volt.require('voltapi.js'),
    ServerAPI = Volt.require('app/common/serverAPI.js'),
    CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js'),
    CommonFunctions = Volt.require('app/common/commonFunctions.js');
    //localStorage = Volt.require("lib/volt-local-storage.js");
var MagicKey         = Volt.require('app/common/MagicKey.js');

// Indicate if the app is in Quick View Mode
Volt.bQuickView = false;
var startView = 'whatsnew';
var hiddenKeyArray = new Array();
var developKeyArray = new Array();

////////////////////////////////////////////////////////////////////////////////
//// PUBLIC FUNCTIONS
////////////////////////////////////////////////////////////////////////////////
/**
 * Entry point for Volt application
 */
var initialize = function () {
    Volt.err("[app.js] Apps Version: " + Volt.AppsVersion);
    
    ////
    setBackgroundBg();
    Stage.show(); // show apps panel, request from Volt UIFW

    setupEnv('PRE');

    //showMainView();

    if (startView == 'whatsnew') {
        Volt.bQuickView = true;
        Volt.setTimeout(function () {
            showQuickView();
        }, 100);

        Volt.setTimeout(function () {

            Volt.log('Async');

            //voltapi.vconf.setValue(CommonDefines.Vconf.DB_WAITING_SCREEN_APP_VISIBLE, true);
            //showMainView();

            Volt.bQuickView = false;

            setupEnv('POST');

            Backbone.history.navigate(startView, {
                trigger: true,
                replace: true
            });
        }, 2500);
    } else { // Into detail
        setupEnv('POST');
    }
    //DF141225-00850 disable PIP sound  
    VDUtil.AppControl_InitDbusConnection();
    VDUtil.AppControl_DisableItem("pip", "org.volt.apps");        
    VDUtil.AppControl_FiniDbusConnection();
};

/**
 * Key event listener from volt engine
 * @param keycode
 * @param type
 */
var onKeyEvent = function (keycode, type) {
    Volt.log("[app.js @onKeyEvent] keycode : " + Volt.getKeyName(keycode, type));
    
    if(type == Volt.EVENT_KEY_PRESS){
        MagicKey.onKeyPress(keycode);
    }
    if (true == checkSmartHubKey(keycode, type)) {
        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_SMARTHUB_INFO);
        return;
    }
    if (true == checkdevelopKey(keycode, type)) {
        Volt.err("[app.js] onKeyEvent show develop popupp ");
        var param = {};
        Backbone.history.navigate('commonpopup/' + JSON.stringify(param), {
            trigger: true
        });
        return;
    }
    var loadingPopup = Volt.require("lib/views/loading-popup.js");
    //when loading popup is show,only reactive to KEY_RETURN/EVENT_KEY_PRESS
    if (true == loadingPopup.createFlag) {
        if (keycode == Volt.KEY_RETURN && type == Volt.EVENT_KEY_PRESS) {
            Volt.log("[app.js] loadingPopup:" + JSON.stringify(loadingPopup.options));
            if (loadingPopup.options && loadingPopup.options.bLaunching) {

                EventMediator.trigger('COMMON_POPUP_KEY_RETURN_RELEASE');
                return;
            } else {
                EventMediator.trigger(CommonDefines.Event.EVENT_HOME_HIDE_LOADING);
            }

        } else {
            Volt.log("[app.js] loadingPopup return");
            return;
        }
    }

    // if Volt.Nav didn't process the event, the app will process it.
    if (Volt.Nav.onKeyEvent(keycode, type) === false) {
        if (keycode == Volt.KEY_RETURN && type == Volt.EVENT_KEY_PRESS) {
            //if (!Backbone.history.back()) {
            if (Backbone.history.getCount() > 1) {
                Backbone.history.back();
            } else if (Backbone.history.getCache('_type') != 'main') {
                Volt.log('[app.js] exit apps panel, apps panel will hide in background');
                Volt.quit();
            } else {
                Volt.log('[app.js] exit apps panel, apps panel will hide in background');
                Volt.exit();
                //Volt.quit();
            }
        }
    }
};
Volt.onKeyEvent = onKeyEvent;


////////////////////////////////////////////////////////////////////////////////
//// PRIVATE FUNCTIONS
////////////////////////////////////////////////////////////////////////////////
// phase: 'PRE', 'POST'
function setupEnv(phase) {
    if (phase == 'PRE') {
        Volt.log("[app.js] @setupEnv PRE");
        
        if (Volt.browser) {
            Volt.DeviceInfoModel.set('networksStatus', 'OK');
        }
        //if (SystemInfo.getIntValue(SystemInfo.KEY_SCREEN_WIDTH) == 1280) {
        //    HALOUtil.enable720P = true;
        //}
        Volt.APPS_REVERSE = (HALOUtil.getOrientation() == 'right-to-left');
        Volt.log("[app.js] Volt.APPS720P = " + (scene.width == 1280));
        Volt.log("[app.js] Volt.APPS_REVERSE = " + Volt.APPS_REVERSE);

        var lang = Volt.DeviceInfoModel.getLanguageCode();
        Volt.i18n.init({
            lng: lang,
            resGetPath: 'lang/<<lng>>.json',
            getAsync: false,
            interpolationPrefix: '<<',
            interpolationSuffix: '>>'
        }, function (t) {});

        checkReset(); //use this api need the image after 2014 11.11

        // This only should be called once.
        // Fix: DF150107-01112: [Apps] Encountered fatal error happen when enter to Skype install page
        Backbone.history.start();

    } else if (phase == 'POST') {
        Volt.log("[app.js] @setupEnv POST");
        
        // Initialize Models
        Volt.require('app/models/models.js').initialize();

        initWASEmp();
        initNetworkEmp();
        initContentsMgrEmp();
        DownloadedAppsMgr.initialize();
        AppInstallMgr.initialize();
    }
}


function onLoad() {
    Volt.log("[app.js @onLoad]");
}

// From outside
var onShow = function (data) {
    Volt.err("[app.js] onShow");

    for (var i in data) {
        Volt.err('******************************************SHOW data[' + i + ']:' + data[i]);
        switch (i) {
        case 'Sub_Menu':
            var viewName = data[i];
            if (viewName == 'Event') {
                startView = 'events';
            } else {
                startView = 'detail/';
            }
            break;
        case 'widget_id':
            startView += data[i];
            break;
        }
    }
};

var onReset = function (data) {
    Volt.err("[app.js] onReset data: " + JSON.stringify(data));
    Stage.show(); // show apps panel, request from Volt UIFW

    if (startView != 'whatsnew') {
        startView = 'whatsnew';
    }
    
    if (data) {
        var route, replace = false;

        if (data.Sub_Menu == 'detail' && data.widget_id) {
            route = data.Sub_Menu + '/' + data.widget_id;

            if (data.caller_id && data.caller_id == 'org.tizen.search-all') {
                Volt.err("[app.js] onReset, caller_id: " + data.caller_id);
                route += '/' + data.caller_id;
            } else {
                Volt.err("[app.js] onReset, caller_id is not exist.");
            }
            
            // If only one detail in history, replace it
            // if (Backbone.history.getCount() == 1) {
                // var href = Backbone.history.hashstack[Backbone.history.hashstack.length - 1];
                // if ((/#detail/g).test(href)) {
                    // replace = true;
                // }
            // }
        } else if (data.Sub_Menu == 'Event') {
            
            var Models = Volt.require('app/models/models.js');
            
            route = 'events';
            Models.menuVMCollection.where({
                index: Models.menuVMCollection.currentMenuIndex
            })[0].set('uiState', 'NORMAL');
            Models.menuVMCollection.where({
                route: route
            })[0].set('uiState', 'SELECTED');
            
        } 
        // else if (data.caller_id == 'org.volt.firstscreen') {
            // if (Backbone.history.getCount() == 1 && Backbone.history.getCache('_type') != 'main') {
                // route = 'whatsnew';
                // replace = 'true';
            // }
        // }
        
        Volt.log('route: ' + route);
        if (route) {
            Backbone.history.navigate(route, {
                trigger: true,
                //replace: replace
            });
            
            Volt.Nav.resume(); //fix bug of DF141206-00669:Key is blocked after installed facebook
        }
    }
    
    EventMediator.trigger('VOLT_RESUME');

    // DF141114-00502, DF141115-00373, DF141119-00405: Added code by VOLT Team's guide. 
    voltapi.vconf.setValue(CommonDefines.Vconf.DB_WAITING_SCREEN_APP_VISIBLE, true);
};

var onActivate = function () {
    Volt.err("[app.js] onActivate");
    CommonFunctions.setAppState(CommonDefines.AppState.APP_STATE_ACTIVATE);
    
    //// TODO: Remove this later when OverlayView added
    if (!Volt.bQuickView) {
        EventMediator.trigger('VOLT_ACTIVATE');
	  EventMediator.trigger(CommonDefines.Event.MLS_UNDIM_MYAPPS_VIEW);
    }
};

var onDeactivate = function () {
    Volt.err("[app.js] onDeactivate");
    var result = Vconf.getInteger("db/mls/mls_state"); //add for Multi-link screen
    if (result == 1) {
        Volt.err("[app.js] onDeactivate:result is 1,do not need deactive");
	   EventMediator.trigger(CommonDefines.Event.MLS_DIM_MYAPPS_VIEW);
    } else {
        Volt.err("[app.js] onDeactivate:result is 0, need deactive");
        CommonFunctions.setAppState(CommonDefines.AppState.APP_STATE_DEACTIVATE);
        EventMediator.trigger('VOLT_DEACTIVATE');
    }
};

var onResume = function () {
    Volt.err("[app.js] onResume");
    EventMediator.trigger('VOLT_RESUME');
};

var onPause = function () {
    Volt.err("[app.js] onPause");
    EventMediator.trigger('VOLT_PAUSE');
};

var onHide = function () {
    Volt.err("[app.js] onHide");
    EventMediator.trigger('VOLT_HIDE');
    Volt.KpiMapper.endKPI();
};

var onUnload = function () {
    Volt.err("[app.js] onUnload");
    EventMediator.trigger('VOLT_UNLOAD');
};

Volt.addEventListener(Volt.ON_LOAD, onLoad);
Volt.addEventListener(Volt.ON_SHOW, onShow);
Volt.addEventListener(Volt.ON_DEACTIVATE, onDeactivate);
Volt.addEventListener(Volt.ON_PAUSE, onPause);
Volt.addEventListener(Volt.ON_RESUME, onResume);
Volt.addEventListener(Volt.ON_ACTIVATE, onActivate);
Volt.addEventListener(Volt.ON_HIDE, onHide);
Volt.addEventListener(Volt.ON_UNLOAD, onUnload);
Volt.addEventListener(Volt.ON_RESET, onReset);

function showQuickView() {
    
    //Models.initialize();
    // if(startView == 'whatsnew'){
    // Backbone.history.start();
    // Backbone.history.navigate(startView, { trigger: true });
    // }
    
    //Backbone.history.start();
    Backbone.history.navigate('main', {
        trigger: true
    });
};
var setBackgroundBg = function () {
    // var bg = new WidgetEx({
    // x : 0,
    // y : 0,
    // width :  Volt.width,
    // height : Volt.height,
    // color: Volt.hexToRgb('#0f1826'),
    // parent : scene
    // });
    scene.color = {
        r: 0x0f,
        g: 0x18,
        b: 0x26,
        a: 0xff
    };
};

var checkSmartHubKey = function (keycode, type) {
    var ret = false;
    var arrayPopNum = 0;
    if (type == Volt.EVENT_KEY_RELEASE) {
        return;
    }
    //Volt.log("[app.js] checkSmartHubKey - keycode : " + keycode);
    switch (hiddenKeyArray.length) {
    case 0:
        if (Volt.KEY_MUTE == keycode || '269025047' == keycode) {
            hiddenKeyArray[0] = keycode;
        }
        break;
    case 1:
        if (Volt.KEY_MUTE == keycode || '50' == keycode) {
            hiddenKeyArray[1] = keycode;
        } else {
            arrayPopNum = 1;
        }
        break;
    case 2:
        if ('269025043' == keycode || '56' == keycode) {
            hiddenKeyArray[2] = keycode;
        } else {
            arrayPopNum = 2;
        }
        break;
    case 3:
        if ('269012995' == keycode || '57' == keycode) {
            hiddenKeyArray[3] = keycode;
        } else {
            arrayPopNum = 3;
        }
        break;
    case 4:
        if (Volt.KEY_MUTE == keycode || '49' == keycode) {
            Volt.log("[app.js] checkSmartHubKey -Hidden Key is ok");
            ret = true;
        }
        arrayPopNum = 4;
        break;
    default:
        break;
    }
    for (var i = 0; i < arrayPopNum; i++) {
        hiddenKeyArray.pop();
    }
    //Volt.log("[app.js] checkSmartHubKey -hiddenKeyArray.length is " + hiddenKeyArray.length);
    return ret;
};
var checkdevelopKey = function (keycode, type) {
    var ret = false;
    var arrayPopNum = 0;
    if (type == Volt.EVENT_KEY_RELEASE) {
        return;
    }
    //Volt.log("[app.js] checkdevelopKey - keycode : " + keycode);
    switch (developKeyArray.length) {
    case 0:
        if ('49' == keycode) {
            developKeyArray[0] = keycode;
        }
        break;
    case 1:
        if ('50' == keycode) {
            developKeyArray[1] = keycode;
        } else {
            arrayPopNum = 1;
        }
        break;
    case 2:
        if ('51' == keycode) {
            developKeyArray[2] = keycode;
        } else {
            developKeyArray = 2;
        }
        break;
    case 3:
        if ('52' == keycode) {
            developKeyArray[3] = keycode;
        } else {
            arrayPopNum = 3;
        }
        break;
    case 4:
        if ('53' == keycode) {
            Volt.log("[app.js] checkdevelopKey -Hidden Key is ok");
            ret = true;
        }
        arrayPopNum = 4;
        break;
    default:
        break;
    }
    for (var i = 0; i < arrayPopNum; i++) {
        developKeyArray.pop();
    }
    //Volt.log("[app.js] checkdevelopKey -developKeyArray.length is " + developKeyArray.length);
    return ret;
};
var checkReset = function () {
    Volt.log("[app.js] checkReset()");
    //use this api need the image after 2014 11.11
    if (SmartHubReset && SmartHubReset.needReset) {
        if (SmartHubReset.needReset()) {
            
            var localStorage = Volt.require("lib/volt-local-storage.js");
            localStorage.clear();
            SmartHubReset.resetComplete();
        } else {
            Volt.log("[app.js] not need reset");
        }
    }
};
var checkAccessibility = function () {
    var highContrast = Volt.DeviceInfoModel.get('highContrast');
    Volt.log("[app.js] checkAccessibility:highContrast is " + highContrast);
    if (highContrast) {
        HALOUtil.highContrast = true;
    } else {
        HALOUtil.highContrast = false;
    }

    var focusZoom = Volt.DeviceInfoModel.get('focusZoom');
    Volt.log("[app.js] checkAccessibility:focusZoom is " + focusZoom);
    if (focusZoom) {
        HALOUtil.enlarge = true;
    } else {
        HALOUtil.enlarge = false;
    }
};
var initNetworkListener = function (networkList) {
    Volt.err("[app.js] Callback of network.initAsync()");
    Volt.err("[app.js] initNetworkListener wireless checkPhysicalConnection : " + voltapi.network.checkPhysicalConnection(0));
    Volt.err("[app.js] initNetworkListener wired checkPhysicalConnection : " + voltapi.network.checkPhysicalConnection(1));
    networkList[0].setWatchListener({
        onconnect: function (type) {
            Volt.err("[app.js] wireless network onconnect");
            EventMediator.trigger(CommonDefines.Event.CONNECT_NETWORK);
        },
        ondisconnect: function (type) {
            Volt.err("[app.js] wireless network ondisconnect");
            if (voltapi.network.checkPhysicalConnection(1) > 0) {
                Volt.err("[app.js] wired network onconnect");
                return;
            }
            EventMediator.trigger(CommonDefines.Event.DISCONNECT_NETWORK);
        }
    }, function () {
        Volt.err("[app.js] wireless network error");
        EventMediator.trigger(CommonDefines.Event.NETWORK_ERROR);
    });
    networkList[1].setWatchListener({
        onconnect: function (type) {
            Volt.err("[app.js] wired network onconnect");
            EventMediator.trigger(CommonDefines.Event.CONNECT_NETWORK);
        },
        ondisconnect: function (type) {
            Volt.err("[app.js] wired network ondisconnect");
            if (voltapi.network.checkPhysicalConnection(0) > 0) {
                Volt.err("[app.js] wireless network onconnect");
                return;
            }
            EventMediator.trigger(CommonDefines.Event.DISCONNECT_NETWORK);
        }
    }, function () {
        Volt.err("[app.js] wired network error");
        EventMediator.trigger(CommonDefines.Event.NETWORK_ERROR);
    });
};
var addNetworkListener = function () {
    voltapi.network.getAvailableNetworks(initNetworkListener, function (errorMessage) { //fix bugs of 
        Volt.err("[app.js] network error errorMessage : " + errorMessage);
        EventMediator.trigger(CommonDefines.Event.NETWORK_ERROR);
        initNetworkListener(errorMessage);
    });
    Volt.err('[app.js] networksStatus: ' + Volt.DeviceInfoModel.get('networksStatus'));
};
var initNetworkEmp = function () {
    Volt.err("[app.js] initNetworkEmp()");
    var retry = 0;
    var self = this;

    function networkAsyncCallback(is_success) {
        Volt.log('networkAsyncCallback Successful or not:::' + is_success);
        if (is_success) {
            self.addNetworkListener();
        } else {
            Volt.log('networkAsyncCallback Fail, retry::' + retry);
            if (retry < 1) {
                voltapi.network.initAsync(networkAsyncCallback);
                retry++;
            }
        }
    }
    voltapi.network.initAsync(networkAsyncCallback);
};
var initContentsMgrEmp = function () {
    print("[app.js] initContentsMgrEmp()");
    var retry = 0;
    var onOpenCallback = function (is_success) {
        Volt.log('contentMgrAsynCallback:::::is_success=>' + is_success);
        if (is_success) {
            Volt.log("[app.js] Success Callback of ContentsMgr.initAsync()");
            var bConnect = voltapi.ContentsMgr.connect();
            Volt.log("[app.js] checkUSB(), connect: " + bConnect);
        } else {
            Volt.log("[app.js] Fail Callback of ContentsMgr.initAsync(), retry::" + retry);
            if (retry < 1) {
                voltapi.ContentsMgr.initAsync(onOpenCallback, onSuccessCallback, onFailCallback);
                retry++;
            }
        }
    }

    var onSuccessCallback = function () {
        Volt.err("[app.js] checkUSB(), connected USB");
        EventMediator.trigger(CommonDefines.Event.CONNECT_USB);
    }

    var onFailCallback = function () {
        Volt.err("[app.js] checkUSB(), disconnected USB");
        EventMediator.trigger(CommonDefines.Event.DISCONNECT_USB);
    }

    voltapi.ContentsMgr.initAsync(onOpenCallback, onSuccessCallback, onFailCallback);
};

function initWASEmp() {
    Volt.log('[app.js] initWASEmp()');
    var retry = 0;

    function WASAsyncCallback(is_success) {
        Volt.log('WASAsyncCallback Successful or not:::' + is_success);
        if (is_success) {
            Volt.err("[app.js] Callback of WAS.initAsync()");
            ServerAPI.initialize();
            EventMediator.trigger(CommonDefines.Event.WAS_READY);
	      checkAccessibility(); //Volt Panel Accessibility (High Contrast & Enlarge)
            Volt.KpiMapper.init();
            if (startView != 'whatsnew') {
                Backbone.history.navigate(startView, {
                    trigger: true
                });
            }

        } else {
            Volt.log('WASAsyncCallback Fail, retry :::' + retry);
            if (retry < 1) {
                voltapi.WAS.initAsync(WASAsyncCallback, WASAsyncReopenCallback);
                retry++;
            }
        }
    }

    function WASAsyncReopenCallback() {
        Volt.log('WASAsyncReopenCallback Successful');
        EventMediator.trigger(CommonDefine.Event.WAS_READY);
    }
    
    if (voltapi.WAS.isOpened() === false) {
        voltapi.WAS.initAsync(WASAsyncCallback, WASAsyncReopenCallback);
    } else {
        Volt.err("[app.js] Callback of WAS.initAsync()");
        ServerAPI.initialize();
        EventMediator.trigger(CommonDefines.Event.WAS_READY);
	 checkAccessibility(); //Volt Panel Accessibility (High Contrast & Enlarge)
        if (startView != 'whatsnew') {
            Backbone.history.navigate(startView, {
                trigger: true
            });
        }
    }
}

