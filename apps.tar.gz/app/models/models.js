 /** 
 * @author donghyun Lee (donghyun81.lee@samsung.com)
 * @fileoverview This module manages models of app.
 * @date    2014/07/03 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var MenuVMCollection = Volt.require('app/models/menuVMCollection.js'),
    CategoriesInfoCollection = Volt.require('app/models/categoriesInfoCollection.js'),
    CategoriesListCollection = Volt.require('app/models/categoriesListCollection.js'),
    WhatsNewCollection = Volt.require('app/models/whatsNewCollection.js'),
    EventCollection = Volt.require('app/models/eventCollection.js'),
    MostPopularCollection = Volt.require('app/models/mostPopularCollection.js'),
    DetailModel = Volt.require('app/models/detailModel.js'),
    ExternalStorageModel = Volt.require("app/models/externalStorageModel.js"),
    MyAppsCollection = Volt.require("app/models/myAppsCollection.js");
    UpdateAppsCollection = Volt.require("app/models/updateAppsCollection.js");

/**
 * Models for apps panel
 * @class
 */
var Models = {

    menuVMCollection: null,
    categoriesInfoCollection: null,
//    categoriesListCollection: null,
    categoriesListCollection: [],
    whatsNewCollection: null,
    eventCollection: null,
    mostPopularCollection: null,
    detailModel: null,
    externalStorageModel: null,
    myAppsCollection: null,
    updateAppsCollection: null,

    /**
     * Initialize every model
     * @method
     */
    initialize: function() {
        this.menuVMCollection = new MenuVMCollection();
        this.categoriesInfoCollection = new CategoriesInfoCollection();
//        this.categoriesListCollection = new CategoriesListCollection();
        this.whatsNewCollection = new WhatsNewCollection();
        this.eventCollection = new EventCollection();
        this.mostPopularCollection = new MostPopularCollection();
        this.detailModel = new DetailModel();
        this.externalStorageModel = new ExternalStorageModel();
        this.myAppsCollection = new MyAppsCollection();
        this.updateAppsCollection = new UpdateAppsCollection();
    },

    createCategoriesList: function(id){        
        this.categoriesListCollection[id] = new CategoriesListCollection();
    }

}

exports = Models;