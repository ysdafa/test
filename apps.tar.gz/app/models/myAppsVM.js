/** 
* @author donghyun Lee (donghyun81.lee@samsung.com)
* @fileoverview MyApps View Model.
* @date    2014/09/17 (last modified date)
*
* Copyright 2014 by Samsung Electronics, Inc.,
* 
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information").  You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung.
*/

var Backbone = Volt.require('lib/volt-backbone.js'),
    EventMediator = Volt.require('app/common/eventMediator.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    _ = Volt.require('modules/underscore.js')._;

/**
 * @name MyAppsVM
 */
var MyAppsVM = Backbone.Model.extend(
    /** @lends MyAppsVM.prototype */
    {
        defaults: {
            app_featured: '',
            app_icon_path: '',
            app_id: '',
            app_index: '',
            app_installed_path: '',
            app_package_name: '',
            app_panel_icon_path: '',
            app_runtitle: '',
            app_size: '',
            app_title: '',
            app_tizen_id: '',
            app_type: '',
            app_version: '',
            app_widget_category: '',
            icon_colorpick: '',
            installState: '',
            install_date: '',
            installed_source_type: '',
            is_display: '',
            is_hidden: '',
            is_lock: '',
            is_multi_screen: '',
            is_need_update: '',
            is_network: '',
            is_premium_game: '',
            is_removable: '',
            is_support_gesture: '',
            is_support_voice: '',
            is_updated: '',
            rating: '',
            title_font_colorpick: '',
            type: '',
            use_count: '',
            panel_icon: '',

            is_edit_mode : false,
            is_checked : false,
            is_dim : false,
            is_updating : false,
            is_checkable: false,
            dimFlag:false,
            state: '', // UPDATE_START, DOWNLOADING, DOWNLOAD_COMPLETED, INSTALLING, INSTALL_COMPLETED
            progress: 0
        },

        idAttribute: 'app_id',

        /**
         * Initialize MyAppsVM
         * @name MyAppsVM
         * @constructs
         */
        initialize: function () {
            
        },

        /**
         * parse Model's data
         * @method
         * @param  {Model} myAppsModel myAppsModel
         * @return {object}              myAppsModel's data object
         */
        parse: function(myAppsModel) {
            return myAppsModel.attributes;
        },

        setChecked: function() {
            if (this.get('is_checked')) {
                this.set('is_checked', false);
                this.set('is_dim', false);
            } else {
                this.set('is_checked', true);
                this.set('is_dim', true);
            }
        },

        destroyView: function() {
            Volt.log('[MyAppsVM] destroyView ' + this.get('app_title'));
            this.trigger('DESTROY_VIEW');
        },
        updateView: function(thumbnail) {
            this.trigger('UPDATE_VIEW', thumbnail);
        }
    });

exports = MyAppsVM;