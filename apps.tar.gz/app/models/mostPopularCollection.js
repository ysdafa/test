 /** 
 * @author youngil baek (yi01.baek@samsung.com)
 * @fileoverview collection to manage mostPopular models.
 * @date    2014/07/18 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._,
    Q = Volt.require('modules/q.js'),
    ServerAPI = Volt.require("app/common/serverAPI.js"),
    AppInfoModel = Volt.require("app/models/appInfoModel.js");

/**
 * @name MostPopularCollection
 */
var MostPopularCollection = Backbone.Collection.extend({
    /** @lends MostPopularCollection.prototype */
    
    model: AppInfoModel,

    /**
     * Initialize MostPopularCollection
     * @name MostPopularCollection
     * @constructs
     */
    initialize: function() {},

/**
 * request to fetch data
 * @method
 */
    fetch : function() {

        var self = this;
        var deferred = Q.defer();

        ServerAPI.getMostPopular({
            success: function(data, status, response) {
                self.parse(data, status, response);
                deferred.resolve();
            },
            
            error: function(serverError) {
                self.error(serverError);
                deferred.reject();
            },
            
            complete: function(object, status) {

            }
        });
        return deferred.promise;
    },
/**
 * on fetch success, call this func to parse given data from server.
 * @method
 * @param  {obejct} data      received data from server
 * @param  {object} status    RequestRequest's status
 * @param  {object} exception exception object
 */
    parse : function(data, status, exception) {
        
        var self = this,
            aAppList = [],
            results = JSON.parse(data).apps;
      
        _.each(results, function(app) {
            
            var appInfoModel = new AppInfoModel(app, { parse: true });

            if (appInfoModel.get('id')) {
                aAppList.push(appInfoModel);
            }
        });

        this.reset(aAppList);
    },
/**
 * error func when fetch error occur
 * @method
 * @param  {object} object    received data from server
 * @param  {object} status    RequestRequest's status
 * @param  {object} exception exception object
 */
    error : function(serverError) {
        print('[MostPopularCollection.js] fetch error : ' + serverError.code + ':::' + serverError.message);
        this.trigger('error', serverError);
    },
/**
 * reset collection 
 * @method
 */
    clear: function() {
        this.reset([]);
    }
});

exports = MostPopularCollection;
