 /** 
 * @author donghyun Lee (donghyun81.lee@samsung.com)
 * @fileoverview Categories list collection.
 * @date    2014/07/23 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._,

    ServerAPI = Volt.require("app/common/serverAPI.js"),
    AppInfoModel = Volt.require("app/models/appInfoModel.js");

/**
 * @name CategoriesListCollection
 */
var CategoriesListCollection = Backbone.Collection.extend({
    /** @lends CategoriesListCollection.prototype */
    
    categoryId: '',
    lastPage: 0,
    page: 0,
    perPage: 0,
    total: 0,
    model: AppInfoModel,

    /**
     * Initialize CategoriesListCollection
     * @name CategoriesListCollection
     * @constructs
     */
    initialize: function() {},

    /**
     * Collection fetch function
     * @method
     */
    fetch : function(param) {
        Volt.log('[CategoriesInfoCollection] fetch');

        this.categoryId = param.categoryId;

        var self = this;

        ServerAPI.getCategoryAppList({
            id: self.categoryId,
            param: param.param,
            success: function(data, status, response) {
                self.parse(data, status, response);
            },
            
            error: function(serverError) {
                self.error(serverError);
            },
            
            complete: function(object, status) {

            }
        });
    },

    /**
     * Parse the fetched data
     * @method
     * @param  {string} data     Raw data
     * @param  {string} status   Response status of server
     * @param  {string} response Response from server
     */
    parse : function(data, status, exception) {

        var self = this,
            aAppList = [],
            results = JSON.parse(data).apps ? JSON.parse(data).apps : '';
        Volt.log("categoriesListCollection.js:data is " + JSON.stringify(data));
        if (results.length && results.length > 0) {
            _.each(results, function(apps) {

                self.setPageInfo(_.pick(apps, 'lastPage', 'page', 'perPage', 'total'));
                
                if (apps.app.length) {                
                    _.each(apps.app, function(appList) {
                        var appInfoModel = new AppInfoModel(appList, { parse: true });
                        if (appInfoModel.get('id')) {
                            aAppList.push(appInfoModel);
                        }
                    });
                } 
            })
        } 
        
        if (this.length > 0) { // App list append
            this.add(aAppList);
        } else {  // App list reset
            this.reset(aAppList);
        }
    },

    /**
     * Set page information
     * @method
     * @param {object} pageData Page data object
     */ 
    setPageInfo: function(pageData) {
        this.lastPage = pageData.lastPage || 1;
        this.page = pageData.page || 1;
        this.perPage = pageData.perPage || 1;
        this.total = pageData.total || 1;
    },

    /**
     * Get page information
     * @method
     * @return {object} Page data object
     */
    getPageInfo: function() {
        return {
            lastPage: this.lastPage,
            page: this.page,
            perPage: this.perPage,
            total: this.total
        };
    },

    /**
     * Parse error handler
     * @method
     * @param  {string} object   Eror object 
     * @param  {string} status   Response status of server
     * @param  {string} exception Error response from server
     */
    error : function(serverError) {
        print('[CategoriesListCollection.js] fetch error : ' + serverError.code + ':::' + serverError.message);

        this.trigger('error', serverError);
    },

    /**
     * Clear this collection's data
     * @method
     */
    clear: function() {
        this.reset([]);
    }
});

exports = CategoriesListCollection;
