var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require('modules/underscore.js')._,

    voltapi = Volt.require('voltapi.js'),
    MyAppsModel = Volt.require('app/models/myAppsModel.js'),
    EventMediator = Volt.require('app/common/eventMediator.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js');

var localStorage = Volt.require("lib/volt-local-storage.js");

var MyAppsCollection = Backbone.Collection.extend({

    model: MyAppsModel,
    viewmode : CommonDefines.WAS.VIEWMODE_LASTDOWNLOAD,

    initialize: function() {
        Volt.log('[MyAppsCollection] initialize');

        this.bindEventListener();
    },

    fetch: function(viewmode) {
        Volt.log('[MyAppsCollection] fetch');

        var appList = this.getAppList(viewmode);

        try {

            // for debug
            var jsonStr = JSON.stringify(appList);
            Volt.err('[MyAppsCollection] WAS.getAppList : ' + jsonStr);

            this.reset(this.parse(appList));

        } catch(e) {
            Volt.err('[MyAppsCollection] WAS.getAppList Error : ' + e);

            this.trigger('error', e);
        }
    },

    getAppList: function(viewmode) {

        if (viewmode !== undefined) {
            this.viewmode = viewmode;
        }

        var type = CommonDefines.WAS.APPS_TYPE_ALL,
            premium = CommonDefines.WAS.APPS_INFO_PREMIUM_GAME_FALSE,
            feature = CommonDefines.WAS.APPS_INFO_FEATURED_ALL,
            index = 0, // from
            count, appList;

        count = voltapi.WAS.getAppCount(type, premium, feature);
        appList = voltapi.WAS.getAppList(type, premium, feature, this.viewmode, index, count);

        return appList;
    },

    parse: function(appList) {
        Volt.log('[MyAppsCollection] parse');

        var filtered = [];

        _.each(appList, function(appData) {

            if (appData.app_id) {
                if ((appData.app_featured == CommonDefines.WAS.APPS_INFO_FEATURED_MYAPP
                    || appData.app_featured == CommonDefines.WAS.APPS_INFO_FEATURED_RECOMMONDED) 
                    && appData.is_hidden == 0) {
                    filtered.push(appData);
                }
            }
        });

        return filtered;
    },

    refresh: function() {
        Volt.log('[MyAppsCollection] refresh');

        var appList = this.getAppList();

        try {

            // for debug
            var jsonStr = JSON.stringify(appList);
            Volt.err('[MyAppsCollection] WAS.getAppList : ' + jsonStr);

            this.set(this.parse(appList));

        } catch (e) {
            Volt.err('[MyAppsCollection] WAS.getAppList Error : ' + e);

            this.trigger('error', e);
        }
    },

    bindEventListener: function() {
        Volt.log('[MyAppsCollection] bindEventListener');

        this.listenTo(EventMediator, CommonDefines.Event.WAS_READY, _.bind(this.onWASReady, this));
        this.listenTo(EventMediator, CommonDefines.Event.INSTALL_COMPLETED, _.bind(this.onInstallComp, this));
        this.listenTo(EventMediator, CommonDefines.Event.UNINSTALL_COMPLETED, _.bind(this.onUninstallComp, this));

        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.MEMORY_WAS_APP_CHANGE, _.bind(this.onWASAppChange, this));
    },

    onWASReady: function() {
        Volt.log('[MyAppsCollection] onWASReady');

        var sortOption = localStorage.getItem('sortOption') || 0,
            viewmode = CommonDefines.WAS.VIEWMODE_LASTDOWNLOAD;

        switch(sortOption) {
            case 0:
            viewmode = CommonDefines.WAS.VIEWMODE_LASTDOWNLOAD;
            break;

            case 1:
            viewmode = CommonDefines.WAS.VIEWMODE_MOSTLYPLAYED;
            break;

            case 2:
            viewmode = CommonDefines.WAS.VIEWMODE_A_TO_Z;
            break;

            case 3:
            viewmode = CommonDefines.WAS.VIEWMODE_Z_TO_A;
            break;
        }

        this.fetch(viewmode);
    },

    onInstallComp: function(info) {
        Volt.log('[MyAppsCollection] onInstallComp');

        // info: {
        //     app_id
        //     result
        // }

        var appData = voltapi.WAS.getAppInfo(info.app_id);

        // for debug
        try {
            var jsonStr = JSON.stringify(appData);
            Volt.err('[MyAppsCollection] WAS.getAppInfo : ' + jsonStr);
        } catch(e) {
            Volt.err('[MyAppsCollection] WAS.getAppInfo Error : ' + e);
        }

        this.add(this.parse([appData]));
    },

    onUninstallComp: function(info) {
        Volt.log('[MyAppsCollection] onUninstallComp');

        this.remove(this.findWhere({app_id: info.app_id}));
    },

    onWASAppChange: function() {
        Volt.err('[MyAppsCollection] onWASAppChange');

        // http://kms.sec.samsung.net/club/club.menu.bbs.read.screen?page_num=1&p_club_id=4968&p_menu_id=15&p_group_id=null&message_id=3005970
        // When user do the installation, uninstallation , update, usb plugin/plugin out(some apps has been installed in usb) operation, WAS will set the vconf value to be 1.

        var appList = this.getAppList();

        try {

            // for debug
            var jsonStr = JSON.stringify(appList);
            Volt.err('[MyAppsCollection] WAS.getAppList : ' + jsonStr);

            this.set(this.parse(appList), {remove: false});

        } catch(e) {
            Volt.err('[MyAppsCollection] WAS.getAppList Error : ' + e);

            this.trigger('error', e);
        }

    }

});

exports = MyAppsCollection;