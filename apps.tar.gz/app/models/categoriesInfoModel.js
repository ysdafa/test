 /** 
 * @author donghyun Lee (donghyun81.lee@samsung.com)
 * @fileoverview Categories info model.
 * @date    2014/07/23 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._;

/**
 * @name CategoriesInfoModel
 */
var CategoriesInfoModel = Backbone.Model.extend(
    /** @lends CategoriesInfoModel.prototype */
    {
        defaults: {
            id: '',
            name: '',
            title: '',
            uri: ''
        },

        /**
         * Initialize CategoriesInfoModel
         * @name CategoriesInfoModel
         * @constructs
         */
    initialize: function() {},

        /**
         * Parse the fetched data
         * @method
         * @param  {object} categoriesInfoData Fetched data object from server
         * @return {object} CategoriesInfoData object
         */
        parse: function (categoriesInfoData) {
            try {
                var oCategoriesInfoData = {
                    id: categoriesInfoData.id,
                    name: categoriesInfoData.name,
                    title: categoriesInfoData.title,
                    uri: categoriesInfoData.uri
                };

                return oCategoriesInfoData;

            } catch (e) {
                console.error('[CategoriesInfoModel.js] parse error : ' + e);
                return false;
            }

        }
    });

exports = CategoriesInfoModel;