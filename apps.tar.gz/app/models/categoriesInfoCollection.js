 /** 
 * @author donghyun Lee (donghyun81.lee@samsung.com)
 * @fileoverview Categories info collection.
 * @date    2014/07/23 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._,
    Q = Volt.require('modules/q.js'),

    ServerAPI = Volt.require("app/common/serverAPI.js"),
    CategoriesInfoModel = Volt.require("app/models/categoriesInfoModel.js");

/**
 * @name CategoriesInfoCollection
 */
var CategoriesInfoCollection = Backbone.Collection.extend({
    /** @lends CategoriesInfoCollection.prototype */
    
    model: CategoriesInfoModel,

    /**
     * Initialize CategoriesInfoCollection
     * @name CategoriesInfoCollection
     * @constructs
     */
    initialize: function() {},

    /**
     * Collection fetch function
     * @method
     */
    fetch : function(){
        Volt.log('[CategoriesInfoCollection] fetch');
        var self = this;
        var deferred = Q.defer();

        ServerAPI.getCategoryList({
            success: function(data, status, response) {
                self.parse(data, status, response);
                deferred.resolve();
            },
            
            error: function(serverError) {
                self.error(serverError);
                deferred.reject();
            },
            
            complete: function(object, status) {

            }
        });

        return deferred.promise;
    },

    /**
     * Parse the fetched data
     * @method
     * @param  {string} data     Raw data
     * @param  {string} status   Response status of server
     * @param  {string} response Response from server
     */
    parse : function(data, status, response){
        var aCategories = [],
            oJson = JSON.parse(data);
            results = oJson.categories ? oJson.categories : '';

        _.each(results, function(categories) {
            var categoriesInfoVM = new CategoriesInfoModel(categories, { parse: true });
            if (categoriesInfoVM.get('id')) {
                aCategories.push(categoriesInfoVM);
            }
        });
        this.reset(aCategories);
    },

    /**
     * Parse error handler
     * @method
     * @param  {string} object   Eror object 
     * @param  {string} status   Response status of server
     * @param  {string} exception Error response from server
     */
    error : function(serverError){
        Volt.log('[CategoriesInfoCollection] fetch error : ' + serverError.code + ':::' + serverError.message);

        this.trigger('error', serverError);
    },

    /**
     * Clear this collection's data
     * @method
     */
    clear: function() {
        this.reset([]);
    }
});

exports = CategoriesInfoCollection;
