/** 
* @author hyoseon Ju (hyoseon.ju@samsung.com)
* @fileoverview MyApps Model.
* @date    2014/09/17 (last modified date)
*
* Copyright 2014 by Samsung Electronics, Inc.,
* 
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information").  You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung.
*/

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._;

/**
 * @name UpdateAppsModel
 */
var UpdateAppsModel = Backbone.Model.extend(
    /** @lends UpdateAppsModel.prototype */
    {
        defaults: {
            app_id : '',
            app_featured: '',
            app_title : '',
            app_icon : '',
            app_version : '',
            app_size : '',
            app_state : '',
            icon_colorpick : '',
            title_font_colorpick: '',
            panel_icon: '',
            firstscreen_icon: '',
            is_selected : false,
            is_checked : false
        },

        /**
         * Initialize UpdateAppsModel
         * @name UpdateAppsModel
         * @constructs
         */
        initialize: function() {},
        
        /**
         * parse given data
         * @method
         * @param  {object} appInfoData object coverted into json string
         * @return {object}             object coverted into json string
         */
        parse: function (appInfoData) {

            try {
                Volt.log('[UpdateAppsModel.js] parse ' + appInfoData);
                return appInfoData;
            } catch (e) {
                console.error('[UpdateAppsModel.js] parse error : ' + e);
                return false;
            }

        }
    });

exports = UpdateAppsModel;