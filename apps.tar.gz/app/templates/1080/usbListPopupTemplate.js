var USBListPopupTemplate = {
   
    container : {
        parent: scene,
        type: 'widget',
       	x: 0, y: 0, width: Volt.width, height: Volt.height,
       	color: Volt.hexToRgb('#000000', 50),
       	children: [
       		{
       			type: 'widget',
       			id  : 'usbList-popup',
       			x: 0, y: Volt.height*0.15, width: Volt.width, height: Volt.height*0.7,
       			color: Volt.hexToRgb('#0f1826', 100),
                 
       			children: [
		            {
		                type : 'widget',
		                id : 'usbList-title-container',
		                x : 0, y : 0, width : Volt.width, height : Volt.height*0.088889,                
		                color : {r: 0, g: 0, b: 0, a: 0}
		            },{
		                type : 'widget',
		                id : 'usbList-line-container',
		                x : Volt.width*0.2078125, y : Volt.height*0.088889, width : Volt.width*0.584375, height : 1,                
		                color : {r: 0, g: 0, b: 0, a: 0}
		            },{
		                type : 'widget',
		                id : 'usbList-selectedUSBInfo-container',
		                x : Volt.width*0.2078125, y : Volt.height*0.139815, width : Volt.width*0.422917, height : Volt.height*0.022222,
		                color : {r: 0, g: 0, b: 0, a: 0},
		                opacity:229
		            },{
		                type : 'widget',
		                x : Volt.width * 0.199479, 
		                y : Volt.height * (0.088889+0.026851+0.088889+0.019444), 
		                width : Volt.width * 0.423958, 
		                height : Volt.height * (0.066667 * 5 + 0.080556 * 2),
		                id : 'usbList-list-container',
		                color : {r: 0, g: 0, b: 0, a: 0},
		                horizontalAlignment : 'center',
		                opacity:216,
		            },
		            {
		                type : 'widget',
		                x : Volt.width * 0.6515625, y : Volt.height * 0.336111, width : Volt.width*0.140625 , height : Volt.height * 0.061111,
		                id : 'usbList-button-container',
		                color : {r: 0, g: 0, b: 0, a: 0},
		                opacity:216,
		                custom:{'focusable' : true}
		            }
			        
       			]
                
       		}
       	]
    },
    
    title: {
    	type: 'widget',
        x : 0, y : 0, width : Volt.width, height : Volt.height * 0.088889,         
        color: Volt.hexToRgb('#0f1826'),
        children:[
            {
                type: 'text',
                x : 0, y : 0, width : Volt.width, height : Volt.height * 0.088889,         
                horizontalAlignment : 'center',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#ffffff', 255),
                text : Volt.i18n.t('COM_SID_CHOOSE_WHERE_INSTALL_THE_APP'),
                font : (Volt.APPS720P)? '31px' : '46px'
            }
        ]
    },
    
    line:{
        type: 'widget',
        x : 0, y : 0, width : Volt.width*0.584375, height : 1,   
        color: Volt.hexToRgb('#0f1826'),
        children:[
        	{
	            type:"widget",
	            x: 0, y: 0, width: Volt.width*0.584375, height: 1,
	            color : Volt.hexToRgb('#a0a0a0', 255),
        	}
        ]
    },

    usbItem: {
        type: 'widget',
        x: 0, y: 0, width: Volt.width*0.422917, height: Volt.height * 0.044444,
        color: Volt.hexToRgb('#0f1826'),
        children:[
	    	{
	        	type: 'text',
	        	id  :"usbList-usb-name",
	        	x: 0, y: 0, width: Volt.width*0.1984375, height: Volt.height * 0.044444,
	        	horizontalAlignment : 'left',
	        	verticalAlignment : 'center',
	        	textColor : Volt.hexToRgb('#ffffff', 255),
	        	font : (Volt.APPS720P)? '23px' : '34px'
	    	},{
	            type: 'text',
	            id:"usbList-usb-storage",
	            x: Volt.width*0.213542, y: 0, width: Volt.width*0.1984375, height: Volt.height * 0.044444,
	        	horizontalAlignment : 'right',
	        	verticalAlignment : 'center',
	        	textColor : Volt.hexToRgb('#ffffff', 255),
	        	opacity: 255,
	        	font : (Volt.APPS720P)? '23px' : '34px'
	    	},        
        ]
    },
    
    button :{
		type : 'WinsetBtn',
		style : '{{style}}',
		buttonType : '{{buttonType}}',
		resoultion : '{{resoultion}}',
		id : "usbList-cancel-button",
		x : 0,
        y : 0,
        width : Volt.width*0.140625,
        height : Volt.height * 0.061111,
		text : Volt.i18n.t('COM_SID_CANCEL'),
	},

    list :{
        type : 'Singlelist',
        x: 0,
        y: 0,//scene.height * 0.080556,
        width: Volt.width * 0.423958,
		height: Volt.height * (0.066667 * 5 + 0.080556 * 2),
		scrollType: "Vertical"
    },

    deviceInfo : {
        type : 'widget',
        width : Volt.width * 0.423958,
        height : Volt.height * 0.066667,
        color : Volt.hexToRgb('#0f1826', 0),
        children : [{
            type : 'widget',
            y : Volt.height * 0.066667 - 1,
            width : Volt.width * 0.423958,
            height : 1,
            color : Volt.hexToRgb('#ffffff', 10),
        },{
            type : 'image', 
            width :0,
            height :0,
            src:'',
            fillMode:"stretch",
        }, {
            type : 'text',
            x : Volt.width * 0.008333,
            width: Volt.width * (0.423958 - 0.008333 * 2 - 0.006250)/2,
            height: Volt.height * 0.066667 - 1,
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            font : (Volt.APPS720P)? "SVD Light 23px" : "SVD Light 34px",
            textColor : Volt.hexToRgb('#ffffff', 80)
        }, {
            type : 'text',
            x : Volt.width * (0.423958 + 0.006250)/2,
            width: Volt.width * (0.423958 - 0.008333 * 2 - 0.006250)/2,
            height: Volt.height * 0.066667 - 1,
            horizontalAlignment : 'right',
            verticalAlignment : 'center',
            font : (Volt.APPS720P)? "SVD Light 23px" : "SVD Light 34px",
            textColor : Volt.hexToRgb('#ffffff', 80)
        }]
    },
    
    deviceInfoStyle : {//style E
        textColor : {
            normal : Volt.hexToRgb('#ffffff', 80),
            focused : Volt.hexToRgb('#464646', 100),
            selected : Volt.hexToRgb('#ffc21f', 80),
            disabled : Volt.hexToRgb('#ffffff', 30)
        },
        font : {
            normal : (Volt.APPS720P)? "Samsung SVD_Light 23px" : "Samsung SVD_Light 34px",
            focused : (Volt.APPS720P)? "Samsung SVD_Light 27px" : "Samsung SVD_Light 40px",
            selected : (Volt.APPS720P)? "Samsung SVD_Light 27px" : "Samsung SVD_Light 40px",
            disabled : (Volt.APPS720P)? "Samsung SVD_Light 23px" : "Samsung SVD_Light 34px",
        }
    },

   /* upArrow: {
        x : 0, y : 0,
        unHighlightSrc: Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_n.png'),
        hilightSrc: Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_f.png')
    },

    downArrow: {
		x : 0, y : 510,
        unHighlightSrc: Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_n.png'),
        hilightSrc: Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_f.png')
    }*/
   
}

exports = USBListPopupTemplate;


