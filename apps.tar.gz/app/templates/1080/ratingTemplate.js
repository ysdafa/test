var RatingTemplate = {

    container : {
        parent: scene,
        type: 'widget',
        x: 0, y: 0, width: Volt.width, height : Volt.height,
        color: Volt.hexToRgb('#000000', 50),
        custom : {
            'focusable' : true,
            'onKeyEvent' : null
        },
        children: [
            {
                type: 'widget',
                id  : 'rating-popup-container',
                x:0, y:Volt.height*0.350926, width: Volt.width, height: Volt.height*0.342592,
                color: Volt.hexToRgb('#0f1826', 85),
                children: [
                    {
                        type : 'text',
                        x : Volt.width*0.2078125, y : 0, width : Volt.width*0.584375, height : Volt.height*0.088889,
                        horizontalAlignment : 'center',
                        verticalAlignment : 'center',
                        font : (Volt.APPS720P)? '29px' : '44px', textColor : Volt.hexToRgb('#ffffff'),
                        opacity : Volt.getPercentage(80),
                        text : Volt.i18n.t('TV_SID_RATING_POINT')
                    },{     
                        type: 'widget',
                        id: 'rating-line',
                        x : Volt.width*0.2078125, y : Volt.height*0.088889, width : Volt.width*0.584375, height : 1,
                        color: {r:255,g:255,b:255},
                        opacity:51,
                    },
                    /*
                    {
                        type : 'text',
                        x : (1920-1122)/2, y : 96+12, width : 1122, height : 48,
                        horizontalAlignment : 'center',
                        verticalAlignment : 'center',
                        font : '32px', textColor : Volt.hexToRgb('#ffffff'),
                        opacity : Volt.getPercentage(80),
                        text : Volt.i18n.t('COM_SID_WHAT_THINK_OF_THIS_APP')
                    },
                    */
                    {     
                        type: 'widget',
                        id: 'rating-star-container',
                        x: Volt.width*0.428646, y: Volt.height*0.134259, width: Volt.width*0.142708, height: Volt.height*0.042592,
                        color: {r:0,g:0,b:0,a:0},
                        // custom: { 'focusable': true }
                    },{
                        type : 'widget',
                        id: 'rating-button-container',
                        color: {r:0,g:0,b:0,a:0},
                        x : Volt.width*0.3515625, y: Volt.height*0.218518, width: Volt.width*0.296875, height: Volt.height*0.061111,
                    },{
                        type : 'image',
                        id: 'rating-left-arrow',
                        x : Volt.width*0.3765625, y : Volt.height*0.127778, width: Volt.width*0.03125, height: Volt.height*0.057407,
                        src : Volt.getRemoteUrl('images/1080/common/popup/popup_rating_arrow_l_n.png'),
                        custom: { 'focusable': true }
                    },{
                        type : 'image',
                        id: 'rating-right-arrow',
                        x : Volt.width*0.5921875, y : Volt.height*0.127778, width: Volt.width*0.03125, height : Volt.height*0.057407,
                        src : Volt.getRemoteUrl('images/1080/common/popup/popup_rating_arrow_r_n.png'),
                        custom: { 'focusable': true }
                    }
                ]
            }
        ]
    },

    starGap : Volt.width*0.0296875,

    ratingStar : {
        type : 'image',
        x   : 0, y : 0, width: Volt.width*0.023958, height : Volt.height*0.042592
    },

    buttonGap: Volt.width*0.15625,

    button : {
        type : 'widget',
        id   : '{{id}}',
        x : 0, y : 0, width : Volt.width*0.140625, height : Volt.height*0.061111,
        color: {r:0,g:0,b:0,a:0},
        border : {
            width : 2 , color :  Volt.hexToRgb('#aabbcc', 80)
        },
        children : [
            {
                type : 'text',
                x : 0, y : 0, width : Volt.width*0.140625, height : Volt.height*0.061111,
                horizontalAlignment : 'center',
                verticalAlignment : 'center',
                font : (Volt.APPS720P)? '21px' : '32px', textColor : Volt.hexToRgb('#ffffff'),
                opacity : Volt.getPercentage(80),
                text : '{{name}}'
            }
        ],
        custom: { 'focusable': true }
    }
};

exports = RatingTemplate;
