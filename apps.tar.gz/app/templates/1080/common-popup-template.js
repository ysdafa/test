var CommonPopup = {
	container : {
		type : 'widget',
		x : 0, y : 0, width : 1920, height : 1080,
        color :  Volt.hexToRgb('#000000', 60),
        parent : scene,
        children : [
		{
				type : 'widget',
				x : 0, y : (1080-142)/2, width : 1920, height : 142,
				color : Volt.hexToRgb('#0f1826', 90),
				custom : {
					className : 'common-popup-message-background'
				}
			}
        ]
	},

	title : {
		type : 'widget',
		x : 399, y : 0, width : 1920-399-399, height: 97,
		color: {r:0,g:0,b:0,a:0},
		children : [
			{
				type : 'text',
				x : 0, y : 0, width : 1920-399-399, height : 96,
				verticalAlignment : 'center', horizontalAlignment : 'center',
				font : '46px', textColor : Volt.hexToRgb('#ffffff'),
				text : '{{messagetitle}}'
			},
			{
				type : 'widget',
				x : 0, y : 5+91, width : 1920-399-399, height : 1,
				color : Volt.hexToRgb('#ffffff', 30)
			}
		]
	},

	message : {
		type : 'text',
		x : 399, y : 5, width : 1920-399-399, 
		color: {r:0,g:0,b:0,a:0}, lineSpacing : (48-34)/2,
		font : '34px', textColor : Volt.hexToRgb('#ffffff', 90),
		text : '{{message}}'
	},

	button : {
	    type : 'widget',
	    width : 270, height : 66,
	    color: {r:0,g:0,b:0,a:0},
	    border : {
	        width : 2 , color :  Volt.hexToRgb('#ffffff', 80)
	    },
	    children : [
	        {
	            type : 'text',
	            x : 0, y : 0, width : 270, height : 66,
	            horizontalAlignment : 'center',
	            verticalAlignment : 'center', 
	            font : '32px', textColor : Volt.hexToRgb('#ffffff'),
	            opacity : Volt.getPercentage(100),
	            text : '{{text}}',
	            custom: { className: 'label' }
	        }
	    ],
	    custom: { 'name':'button', 'focusable': true }
	},


/*	loading : {
		icon : {
			type : 'image',
			x:0, y : 0,  width : 301, height:58,
			src : Volt.getRemoteUrl('images/1080/common/loading/white/20x20/loading_bright_20_01.png')
		},
		text : {
			type : 'text',
			x:0, y : 48, height : 60,
			font : '40px', textColor : Volt.hexToRgb('#ffffff', 85),
			text : 'Loading...'
		}
	},*/

    loading : {
		type : 'WinsetLoading',
		x : (Volt.width - 301) / 2,
		y : (Volt.height - 58) / 2,
		style : '{{style20}}',
		nResoultionStyle : '{{nResoultionStyle}}',
		text : Volt.i18n.t('COM_TV_SID_LOADING')
	},

	loadingPop : {
		type : 'widget',
		x : 1920-11-340, y : 17, width : 340, height : 126,
		color: {r:0,g:0,b:0,a:0},
		children : [
			{
				type : 'image',
				x:(340-206)/2, y : 19,  width : 206, height:40,
				src : Volt.getRemoteUrl('images/1080/common/loading/white/14x14/loading_bright_14_01.png'),
				custom: { 'className':'loadingIcon'}
			},
			{
				type : 'text',
				x:(340-206)/2, y : 19+40+6,  width : 206, height:50,
				font : '34px', textColor : Volt.hexToRgb('#ffffff'),
				horizontalAlignment : 'center',
				text : Volt.i18n.t('COM_TV_SID_LOADING')
			}
		]
	}
};

exports = CommonPopup;