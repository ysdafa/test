/** 
 * @author  Daeho Song (daehor.song@samsung.com)
 * @fileoverview Context Menu Template for UI
 * @date    2014/10/7 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var contextMenuTemplate = {

    contextMenu:{
       	x: 0,
		y: Volt.height*0.009259,
		width: Volt.width*0.140625,
		height: Volt.height*0.138889,
		nResoultionStyle: (Volt.APPS720P)? "0" : "1",
		parent:scene,
		subSelectIndex:0,
		bgColor:{ r: 39, g: 124, b: 175, a: 200 },
		showNumber: 1,
		items: [ { style: 3, text: "" }],
    },
}

exports = contextMenuTemplate;