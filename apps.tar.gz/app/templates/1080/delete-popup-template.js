var DeletePopupTemplate = {
    container : {
        parent:scene,
        type: 'widget',
       
        x: 0, y: (1-0.287037)*Volt.height/2, width: Volt.width, height : Volt.height*0.287037,
        color : Volt.hexToRgb('#0f1826',85),
        children : [
            {
                type : 'widget',
                id : 'delete-description-container',
                x : 0.239583*Volt.width, y : 0.034259*Volt.height, width : Volt.width*0.276042, height : Volt.height*0.101851,
                color : Volt.hexToRgb('#ffffff',0),
            },
            {
                type : 'widget',
                x : 0.239583*Volt.width, y : 0.13611*Volt.height, width : 0.492188*Volt.width, height : 0.001852*Volt.height,
                id : 'progressbar-container',
                color : Volt.hexToRgb('#ffff00',0),
            },
            {
                type : 'widget',
                x : (1-0.140625)*Volt.width/2, y : 0.199999*Volt.height, width : 0.140625*Volt.width , height : 0.061111*Volt.height,
                id : 'button-container',
                color : Volt.hexToRgb('#ffffff',0),
            },
            {
                type : 'text',
                x : (0.239583+0.492188+0.005208)*Volt.width, y : 0.112963*Volt.height, width : 0.046875*Volt.width , height : 0.044444*Volt.height,
                id : 'percentText-container',
				horizontalAlignment : 'right',
				verticalAlignment : 'center',
				color: Volt.hexToRgb('#ff0000',0),
				textColor : Volt.hexToRgb('#ffffff',100),
				text : '0%',
				font : 'Samsung SVD_Light 32px',
            }
        ]
    },
    description: {
        type : 'widget',
        x : 0, y : 0, width : Volt.width*0.276042, height : Volt.height*0.101851,
        color : Volt.hexToRgb('#000000',0),
        children: [
			{
				type: 'text',
				x: 0, y: 0, width: Volt.width*0.276042, height: Volt.height*0.044444,
				horizontalAlignment : 'left',
				verticalAlignment : 'center',
				color: Volt.hexToRgb('#0f1826',0),
				textColor : Volt.hexToRgb('#ffffff',100),
				id :'deleting_Text',
				text : 'Deleting...',
				font : 'Samsung SVD_Light 34px'
			},
			{
				type: 'text',
				x: 0, y: Volt.height*0.044444, width: Volt.width*0.276042, height: Volt.height*0.044444,
				horizontalAlignment : 'left',
				verticalAlignment : 'center',
				color: Volt.hexToRgb('#0f1826',0),
				textColor : Volt.hexToRgb('#ffffff',100),
				id :'deleting_Number_Text',
				text : 'Total()',
				font : 'Samsung SVD_Light 34px'
			}
		]
    },
    
    progressBar: {
        type: 'widget',        
        x: 0, y: 0, width: 0.492188*Volt.width, height: 0.001852*Volt.height,
        color : Volt.hexToRgb('#000000',0),
        id:'progressBar',        
    },
           
    deleteCancelBtn :{
		type : 'WinsetBtn',
		style : '{{style}}',
		buttonType : '{{buttonType}}',
		resoultion : '{{resoultion}}',
		id : "deleteCancelBtn",
		x : 0,
        y : 0,
        width : 0.140625*Volt.width,
        height : 0.061111*Volt.height,
		text : Volt.i18n.t('COM_SID_CANCEL'),
	},
};

exports = DeletePopupTemplate;