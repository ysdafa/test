var CategoriesListTemplate = {
    container: {
        parent: scene,
        type: 'widget',
        x: 0, y: 0, width: Volt.width, height: Volt.height*0.8,
        color: Volt.hexToRgb('#dfdfdf'),
        children: [
            /*{
                id: 'categories-list-header-container',
                type: 'widget',
                x: 0, y: 0, width: 1920, height: 144,
                color: Volt.hexToRgb('#0f1826')
            },*/
            {
                id: 'categories-list-content-container-{{ type }}',
                type: 'widget',
                x: 0, y: 0, width: Volt.width, height: Volt.height*0.8,
                color: Volt.hexToRgb('#dfdfdf')
            },
            {
                id: 'categories-list-no-content-container-{{ type }}',
                type: 'text',
                x: Volt.width*0.046875, y: Volt.height*0.285185, height: Volt.height*0.050926, width: Volt.width*0.90625,
                horizontalAlignment : 'center',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#000000', 60),
                text : '',
                font : '35px'
            }
        ]
    },

   dim: {
        id : 'categories-list-dim',
        type: 'widget',
        x: 0, y: 0, width: Volt.width, height : Volt.height,
        color : Volt.hexToRgb('#000000'),
        opacity : Volt.getPercentage(80)
    },    
    
    categoriesListItem : {
        
    },

    progressbar : {
        x: 20, y: 160, width: 156, height: 2,
        percentage: 0
    },
    gridList : {
        x : 0,
        y : 0,
        width : Volt.width,
        height : Volt.height*0.8,
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : 0,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0,
        itemHeight : Volt.height*0.4,
        itemWidth : Volt.width*0.196875,
        rows : 2
    },

    optionMenuBG: {
        type: 'widget',
        x: 0, y: 0, width: 1920, height: 1080,
        color: {r:0, g:0, b:0, a:153},
        parent: scene,
        children: [{
            type : 'image',
            x: 1854, y: 55, width : 33, height : 33,
            opacity: 153,
            src : Volt.getRemoteUrl('images/1080/common/comn_icon_topmenu_option.png')
        }]
    },

    optionMenu: {
        type: 'OptionMenu',
        x: 1461, y: 120, width: 439,
        text:[Volt.i18n.t('TV_SID_RELEASE_DATE_KR_DATE'), Volt.i18n.t('COM_SID_TITLE_A_Z'), Volt.i18n.t('COM_SID_TITLE_Z_A')],
        custom: { focusable: true },
        loop: true,
        selectedIdx: 0,
        parent: scene
    },
    optionMenuPara:{
       	x: Volt.width*(1-0.186458-0.010417),
		y: Volt.height*0.111111,
		width: Volt.width*0.186458,
		id:"option",
		nResoultionStyle: "1",
		parent:scene,
		mainSelectIndex:0,
		subSelectIndex:0,
		bgColor:{ r: 39, g: 124, b: 175, a: 200 },
		showNumber: 4,
		items: [ { style: 2, text: Volt.i18n.t('TV_SID_RELEASE_DATE_KR_DATE') }, { style: 2, text: 'Popularity' }, { style: 2, text: Volt.i18n.t('COM_SID_TITLE_A_Z') }, { style: 2, text: Volt.i18n.t('COM_SID_TITLE_Z_A') }],
    },
		
    /*thumbnailStyle: {

        visibleStyles: ( 0x01 |    // CommonDefines.Const.THUMB_STYLE_IMAGE
                         0x20 ),   // CommonDefines.Const.THUMB_STYLE_INFO
        image: {
            x: 0, y: 0, width: 196, height: 162,
            src: '',
            async: true
        },
        progressBar: {
            x: 20, y: 160, width: 156, height: 2,
            backgroundColor: Volt.hexToRgb('#ffffff', 10),
            progressColor: Volt.hexToRgb('#ffffff', 100),
            normalThumbSrc: '',
            focusThumbSrc: '',
            thumbWidth: 8,
            thumbHeight: 10,
        },
        information: {
            x : 0, y: 162, width : 196, height : 126,
            text1: {
                x: 0, y: 0, width: 196, height: 126,
                font: 'SamsungSVD_Light 28px',
                singleLineMode: true,
                horizontalAlignment: "center",
                verticalAlignment: "center",
                //text: data.title
            },
            icon1: {
                x : 196-32-11, y : 126-32-11, width : 32, height : 32,
                src: Volt.getRemoteUrl('images/1080/common/icon_downloaded.png'),
                async: true
            }
        }
    }*/
   thumbnailStyle : {
        visibleStyles: ( 0x01 |    // CommonDefines.Const.THUMB_STYLE_IMAGE
                         0x20 ),   // CommonDefines.Const.THUMB_STYLE_INFO
        image: {
            x: Volt.width*0.013542, y: Volt.height*0.056481, width: Volt.width*(0.196875 - 0.013542*2)/*328*/, height: Volt.height*(0.4-0.056481-0.030556-0.056481-0.087963)/*184*/, async: true
        },
        progressBar: {
            x: Volt.width*0.013542, y: Volt.height*0.22778, width: Volt.width*(0.196875 - 0.013542*2), height: 2,
            backgroundColor: Volt.hexToRgb('#ffffff', 40),
            progressColor: Volt.hexToRgb('#ffffff', 100),
            normalThumbSrc: '',
            focusThumbSrc: '',
            thumbWidth: 8,
            thumbHeight: 10,
        },
        information: {
                x : 0, y: Volt.height*(0.4-0.056481-0.087963)+2/*278*/, width : Volt.width*0.196875, height : Volt.height*0.14259,
                colorPickingRange: {l: 0, r: 100, t: 80, b: 100}, // Left to Right: 0 -100, Top to Bottom: 80 - 100, means 20% from bottom
                icon2: {
                    x: Volt.width*0.013542, y: 0, width: Volt.width*0.059896, height: Volt.height*0.087963,    //115*95
                    src: '',
                    async: true
                },
                text1: {  
                    x: Volt.width*(0.196875-0.101042-0.013542), y: 0, width: Volt.width*0.101042, height: Volt.height*0.040741,
                    font: (Volt.APPS720P)? 'SamsungSVD_Light 19px' : 'SamsungSVD_Light 28px',
                    singleLineMode: true,
                    horizontalAlignment: "left",
                    verticalAlignment: "center",
                    text: '',
                    enlarge: {
                       factor: 1.5,
                       //anchorPoint: "center",
                	},
                },
                text2: {
                    x: Volt.width*(0.196875-0.101042-0.013542), y: Volt.height*0.040741, width: Volt.width*0.101042, height: Volt.height*0.025926,
                    font: (Volt.APPS720P)? 'SamsungSVD_Light 13px' : 'SamsungSVD_Light 20px',
                    singleLineMode: true,
                    horizontalAlignment: "left",
                    verticalAlignment: "center",
                    text: '',
                    enlarge: {
                       factor: 1.5,
                       //anchorPoint: "center",
                	},

                },
                text3: {
                    x: Volt.width*(0.196875-0.101042-0.013542), y: Volt.height*(0.040741+0.025926), width: Volt.width*(0.101042-0.016667), height: Volt.height*0.028926, //Volt.height*0.025926,
                    font: (Volt.APPS720P)? 'SamsungSVD_Light 13px' : 'SamsungSVD_Light 20px',
                    singleLineMode: true,
                    horizontalAlignment: "left",
                    verticalAlignment: "center",
                    text: '',                    
                    enlarge: {
                       factor: 1.5,
                       //anchorPoint: "center",
                	},

                },
                icon1: {
                    x: Volt.width*(0.196875-0.014583-0.016667), y: Volt.height*(0.040741+0.025926), width: Volt.width*0.016667, height: Volt.height*0.02963,
                    src: Volt.getRemoteUrl('images/1080/common/icon_downloaded.png'),
                    async: true
                },
        }
    } 
};

exports = CategoriesListTemplate;
