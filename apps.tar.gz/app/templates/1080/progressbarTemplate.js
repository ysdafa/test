var ProgressBarTemplate = {

    bg : {
        type: 'widget',
        x:0,
        y:Volt.height*(0.011111+0.059259),
        width:Volt.width*0.213542,
        height:2,
        color:Volt.hexToRgb('#ffffff', 0),
        children:[
            {
                type: 'WinsetProgress',
                x:0,
                y:0,
                width:Volt.width*0.213542,
                height:2,
                nProgressStyle: '{{nProgressStyle}}',
        		nResoultionStyle: '{{nResoultionStyle}}'
            }
        ]
    }
};

exports = ProgressBarTemplate;
