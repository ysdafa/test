 /** 
 * @author dohyoung Kim (dohyoung7.kim@samsung.com)
 * @fileoverview This module defines common values.
 * @date    2014/07/25 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var sceneResolution = String(Volt.height) ? String(Volt.height) : '1080';
var CommonDefines = {

    Event: {
        CONNECT_NETWORK:                    'EVENT_CONNECT_NETWORK',
        DISCONNECT_NETWORK:                 'EVENT_DISCONNECT_NETWORK',
        CHANGE_NETWORK_STATUS:              'EVENT_CHANGE_NETWORK_STATUS',
        NETWORK_ERROR:                      'EVENT_NETWORK_ERROR',
        NETWORK_ERROR_MESSAGE:              'EVENT_NETWORK_ERROR_MESSAGE',

        CONNECT_USB:                        'EVENT_CONNECT_USB',
        DISCONNECT_USB:                     'EVENT_DISCONNECT_USB',

        CHANGE_COUNTRY_CODE:                'EVENT_CHANGE_COUNTRY_CODE',
        CHANGE_LANGUAGE:                    'EVENT_CHANGE_LANGUAGE',
        CHANGE_HIGH_CONTRAST:               'EVENT_CHANGE_HIGH_CONTRAST',
        CHANGE_TTS:                         'EVENT_CHANGE_TTS',
        CHANGE_VISIBLE_CURSOR:              'EVENT_CHANGE_VISIBLE_CURSOR',
        CHANGE_FOCUS_ZOOM:                  'EVENT_CHANGE_FOCUS_ZOOM',
        CHANGE_AUDIO_DESCRIPTION:           'EVENT_CHANGE_AUDIO_DESCRIPTION',
        CHAHGE_LOCAL_MEMORY:                'CHAHGE_LOCAL_MEMORY',
        CHANGE_DOWNLOADED_APPS:             'CHANGE_LOCK_UNLOCK_APPS',

        WAS_READY:                          'EVENT_WAS_READY',
        DEVICE_INFO_READY:                  'EVENT_DEVICE_INFO_READY',
        DOWNLOADED_MGR_READY:               'EVENT_DOWNLOADED_MGR_READY',   
        DOWNLOADED_MGR_SORT_READY:          'EVENT_DOWNLOADED_MGR_SORT_READY',   

        INSTALL_START:                      'EVENT_INSTALL_START',
        UPDATE_START:                       'EVENT_UPDATE_START',
        UNINSTALL_START:                    'EVENT_UNINSTALL_START',

        DOWNLOADING:                        'EVENT_DOWNLOADING',
        DOWNLOAD_COMPLETED:                 'EVENT_DOWNLOAD_COMPLETED',
        DOWNLOAD_FAIL_NOT_EXIST:            '102',
        DOWNLOAD_FAIL_NOSPACE:              '103',
        DOWNLOAD_FAIL_LICENSE_ERROR:        '104',
        DOWNLOAD_FAIL_SERVER_ERROR:         '105',
        DOWNLOAD_FAIL_NETWORK_ERROR:        '106',
        DOWNLOAD_FAIL_OTHERS:               '107',

        INSTALLING:                         'EVENT_INSTALLING',
        INSTALL_CANCEL_COMPLETED:           'EVENT_INSTALL_CANCEL_COMPLETED',
        INSTALL_CANCEL_FAILED:              '202',
        INSTALL_COMPLETED:                  'EVENT_INSTALL_COMPLETED',
        INSTALL_FAIL_EXIST:                 '204',
        INSTALL_FAIL_PKGMGR_ERROR:          '205',
        INSTALL_FAIL_LICENSE_ERROR:         '206',
        INSTALL_FAIL_OTHERS:                '207',
        INSTALL_FAIL_APPSYNC_NOT_COMPLETE:  '208',

        UNINSTALLING:                       'EVENT_UNINSTALLING',
        UNINSTALL_COMPLETED:                'EVENT_UNINSTALL_COMPLETED',
        UNINSTALL_FAIL_NOT_EXIST:           'EVENT_UNINSTALL_FAIL_NOT_EXIST',
        UNINSTALL_FAIL_PKGMGR_ERROR:        'EVENT_UNINSTALL_FAIL_PKGMGR_ERROR',
        UNINSTALL_FAIL_NOT_REMOVABLE:       'EVENT_UNINSTALL_FAIL_NOT_REMOVABLE',
        UNINSTALL_FAIL_OTHERS:              'EVENT_UNINSTALL_FAIL_OTHERS',

        UPDATE_CANCEL_COMPLETED:            'EVENT_UPDATE_CANCEL_COMPLETED',

        APPS_SYNC_COMPLETED:                'EVENT_APPS_SYNC_COMPLETED',
        APPS_SYNC_FAIL_NETWORK_ERROR:       'EVENT_APPS_SYNC_FAIL_NETWORK_ERROR',
        APPS_SYNC_FAIL_OTHERS:              'EVENT_APPS_SYNC_FAIL_OTHERS',

        LAUNCHER_LAUNCH_START:              'EVENT_LAUNCHER_LAUNCH_START',
        LAUNCHER_LAUNCH:                    'EVENT_LAUNCHER_LAUNCH',
        LAUNCHER_SHOW:                      'EVENT_LAUNCHER_SHOW',
        LAUNCHER_TERMINATE:                 'EVENT_LAUNCHER_TERMINATE',
        LAUNCHER_FAIL_NOT_EXIST:            'EVENT_LAUNCHER_FAIL_NOT_EXIST',
        LAUNCHER_FAIL_TIMEOUT:              'EVENT_LAUNCHER_FAIL_TIMEOUT',
        LAUNCHER_FAIL_EMP:                  'EVENT_LAUNCHER_FAIL_EMP',
        LAUNCHER_FAIL_SMARTHUB:             'EVENT_LAUNCHER_FAIL_SMARTHUB',
        LAUNCHER_FAIL_CAPH_APP:             'EVENT_LAUNCHER_FAIL_CAPH_APP',
        LAUNCHER_FAIL_NETWORK:              'EVENT_LAUNCHER_FAIL_NETWORK',
        LAUNCHER_FAIL_OTHERS:               'EVENT_LAUNCHER_FAIL_OTHERS',
        LAUNCHER_FAIL_MLS:                  'EVENT_LAUNCHER_FAIL_MLS',

        APPS_LIST:                          'EVENT_APPS_LIST',
        REQUEST_APP_LIST:                   'EVENT_REQUEST_APP_LIST',

        GRID_NAV_FOCUS_CHANGED:             'EVENT_GRID_NAV_FOCUS_CHANGED',
        GRID_NAV_FOCUS_BLURED:              'EVENT_GRID_NAV_FOCUS_BLURED',

        EVENT_HOME_SHOW_LOADING:            'EVENT_HOME_SHOW_LOADING',
        EVENT_HOME_HIDE_LOADING:            'EVENT_HOME_HIDE_LOADING',
        EVENT_MAIN_CATEGORY_FOCUS:          'EVENT_MAIN_CATEGORY_FOCUS',
        EVENT_MAIN_CATEGORY_BLUR:           'EVENT_MAIN_CATEGORY_BLUR',

        EVENT_MAIN_CATEGORY_CHANGE:         'EVENT_MAIN_CATEGORY_CHANGE',
        EVENT_HIDE_POPUP:                   'EVENT_HIDE_POPUP',

        EVENT_USB_INSTALL_APP:              'EVENT_USB_INSTALL_APP',

        EVENT_MY_APPS_SINGLE_DELETE:        'EVENT_MY_APPS_SINGLE_DELETE',

        MOVE_FOCUS_MYAPPS:                     'MOVE_FOCUS_MYAPPS',
        CLOSE_RATING_POPUP:			    'CLOSE_RATING_POPUP',
        MSGBOX_BUTTON:						'MSGBOX_BUTTON',
        SELECT_BTN1:						'SELECT_BTN1',
        SELECT_BTN2:						'SELECT_BTN2',
        SELECT_BTN3:						'SELECT_BTN3',
        SELECT_RETURN:  					'SELECT_RETURN',
        OPTION_MENU:						'OPTION_MENU',
        MLS_DIM_MYAPPS_VIEW:				'MLS_DIM_MYAPPS_VIEW',
        MLS_UNDIM_MYAPPS_VIEW:			'MLS_UNDIM_MYAPPS_VIEW',
        REST_SETHEADER_FAIL:                'REST_SETHEADER_FAIL',

        EVENT_CLOSE_POPUP:        'EVENT_CLOSE_POPUP',

		EVENT_MYAPP_CHECK_ITEMNUM_CHANGE: 	'EVENT_MYAPP_CHECK_ITEMNUM_CHANGE',

		EVENT_LONGPRESS_RELEASE:    		'EVENT_LONGPRESS_RELEASE',
		CLOSE_DELETING_POPUP :  'CLOSE_DELETING_POPUP',
    },

    Vconf: {
        DB_COMSS_COUNTRYCODE:                               'db/comss/countrycode',
        DB_COMSS_MODELID:                                   'db/comss/modelid',
        DB_COMSS_DUID:                                      'db/comss/duid',
        DB_MENU_WIDGET_LANGUAGE:                            'db/menu_widget/language',
        DB_MENU_SYSTEM_ACCESSIBILITY_HIGHCONTRAST:          'db/menu/system/accessibility/highcontrast',
        DB_MENU_SYSTEM_ACCESSIBILITY_AUDIO_DESCRIPTION:     'db/menu/system/accessibility/audio_description',
        DB_MENU_SYSTEM_ACCESSIBILITY_FOCUSZOOM:             'db/menu/system/accessibility/focuszoom',
        DB_MENU_ACCESSIBILITY_TTS:                          'db/menu/accessibility/tts',
        DB_MENU_SYSTEM_CHANGE_PIN:                          'db/menu/system/change_pin',
        RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE:          'memory/window_system/input/cursor_visible',
        MEMORY_VOLT_PANEL_HIDE:                             'memory/volt/panel_hide',
        DB_WAITING_SCREEN_APP_VISIBLE:                      'db/WaitingScreenApp/Visible',
        MEMORY_WAS_APP_CHANGE:                              'memory/was/app_change',
        DB_DEVELOP_MODE:                                     'db/sdk/develop/mode',
        DB_DEVELOP_IP:                                          'db/sdk/develop/ip'

    },

    WAS: {
        // Event
        WAS_EVENT_DOWNLOADING:                          100,
        WAS_EVENT_DOWNLOAD_COMPLETED:                   101,
        WAS_EVENT_DOWNLOAD_FAIL_NOT_EXIST:              102,
        WAS_EVENT_DOWNLOAD_FAIL_NOSPACE:                103,
        WAS_EVENT_DOWNLOAD_FAIL_LICENSE_ERROR:          104,
        WAS_EVENT_DOWNLOAD_FAIL_SERVER_ERROR:           105,
        WAS_EVENT_DOWNLOAD_FAIL_NETWORK_ERROR:          106,
        WAS_EVENT_DOWNLOAD_FAIL_OTHERS:                 107,
        //install       
        WAS_EVENT_INSTALLING:                           200,
        WAS_EVENT_INSTALL_CANCEL_COMPLETED:             201,
        WAS_EVENT_INSTALL_CANCEL_FAILED:                202,
        WAS_EVENT_INSTALL_COMPLETED:                    203,
        WAS_EVENT_INSTALL_FAIL_EXIST:                   204,
        WAS_EVENT_INSTALL_FAIL_PKGMGR_ERROR:            205,
        WAS_EVENT_INSTALL_FAIL_LICENSE_ERROR:           206,
        WAS_EVENT_INSTALL_FAIL_OTHERS:                  207,
        WAS_EVENT_INSTALL_FAIL_APPSYNC_NOT_COMPLETE:    208,
        //uninstall     
        WAS_EVENT_UNINSTALLING:                         300,
        WAS_EVENT_UNINSTALL_COMPLETED:                  301,
        WAS_EVENT_UNINSTALL_FAIL_NOT_EXIST:             302,
        WAS_EVENT_UNINSTALL_FAIL_PKGMGR_ERROR:          303,
        WAS_EVENT_UNINSTALL_FAIL_NOT_REMOVABLE:         304,
        WAS_EVENT_UNINSTALL_FAIL_OTHERS:                305,
        //apps sync     
        WAS_EVENT_APPS_SYNC_COMPLETED:                  400,
        WAS_EVENT_APPS_SYNC_FAIL_NETWORK_ERROR:         401,
        WAS_EVNET_APPS_SYNC_FAIL_OTHERS:                402,
        //emp monitor       
        WAS_EVENT_EMP_MONITOR_INSTALL:                  500,
        WAS_EVENT_EMP_MONITOR_UNINSTALL:                501,
        WAS_EVENT_EMP_MONITOR_UPDATE:                   502,
        // launcher     
        WAS_EVENT_LAUNCHER_LAUNCH_START:                600,
        WAS_EVENT_LAUNCHER_LAUNCH:                      601,
        WAS_EVENT_LAUNCHER_SHOW:                        602,
        WAS_EVENT_LAUNCHER_TERMINATE:                   603,
        WAS_EVENT_LAUNCHER_FAIL_NOT_EXIST:              604,
        WAS_EVENT_LAUNCHER_FAIL_TIMEOUT:                605,
        WAS_EVENT_LAUNCHER_FAIL_EMP:                    606,
        WAS_EVENT_LAUNCHER_FAIL_SMARTHUB:               607,
        WAS_EVENT_LAUNCHER_FAIL_CAPH_APP:               608,
        WAS_EVENT_LAUNCHER_FAIL_NETWORK:                609,
        WAS_EVENT_LAUNCHER_FAIL_OTHERS:                 610,
        WAS_EVENT_LAUNCHER_FAIL_MLS:                    611,

        WAS_DEFAULT:                                    1000,

        WAS_APPS_LIST:                                  2000,
        WAS_REQUEST_APP_LIST:                           2001,

        WAS_SSO_REQUEST_ACCESS_TOKEN:                   3000,
        WAS_SSO_STATE_CHANGE:                           3001,
        WAS_SSO_SHOW_POPUP:                             3002,

        WAS_AD_START:                                   4000,
        WAS_AD_PLAY:                                    4001,

        // apps sync state
        WAS_APPS_SYNC_STATE_INIT:                       10,
        WAS_APPS_SYNC_STATE_START:                      11,
        WAS_APPS_SYNC_STATE_UNINSTALL_COMPLETED:        12,
        WAS_APPS_SYNC_INSTALL_COMPLETED:                13,
        WAS_APPS_SYNC_COMPLETED:                        14,

        // app state for app sync list
        WAS_APP_STATE_DEFAULT:                          0,
        WAS_APP_STATE_NEED_INSTALL:                     1,
        WAS_APP_STATE_NEED_UNINSTALL:                   2,
        WAS_APP_STATE_NEED_UPDATE:                      3,

        // Type
        APPS_TYPE_WIDGET:                   1,
        APPS_TYPE_TIZEN_WEB_APP:            2,
        APPS_TYPE_TIZEN_NATIVE_APP:         4,
        APPS_TYPE_TIZEN_NETFLIX_APP:        8,
        APPS_TYPE_TIZEN_GPLAYER_APP:        16,
        APPS_TYPE_TIZEN_RACH_APP:           32,
        APPS_TYPE_TIZEN_SDK_APP:            64,
        APPS_TYPE_ALL:                      65535,

        // Premium
        APPS_INFO_PREMIUM_GAME_FALSE:       1,
        APPS_INFO_PREMIUM_GAME_TRUE:        2,
        APPS_INFO_PREMIUM_GAME_ALL:         65535,
        
        // Feature
        APPS_INFO_FEATURED_MYAPP:           1,
        APPS_INFO_FEATURED_RECOMMONDED:     2,
        APPS_INFO_FEATURED_ALL:             65535,
        
        // View Mode
        VIEWMODE_MOSTLYPLAYED:              0,
        VIEWMODE_CUSTOM:                    1,
        VIEWMODE_LASTDOWNLOAD:              2,
        VIEWMODE_A_TO_Z:                    3,
        VIEWMODE_Z_TO_A:                    4,


        WAS_LIST_TYPE_APP_UPDATE_LIST:      0
    },

    AppInstallMgr: {
        // Install Status    
        STATUS_INSTALL_READY:               0,
        STATUS_DOWNLOAD_PROGRESS:           1,
        STATUS_DOWNLOAD_RESULT:             2,
        STATUS_INSTALL_PROGRESS:            3,
        STATUS_UPDATE_READY:                4,
        STATUS_UNINSTALL_READY:             5,
        STATUS_UNINSTALL_PROGRESS:          6,

        TYPE_INSTALL:                       0,
        TYPE_UPDATE:                        1,
        TYPE_UNINSTALL:                     2,
        TYPE_SYNC:                          3
    },

    AppInfoVM: {
        STATUS_INSTALL_READY:               0,
        STATUS_DOWNLOAD_PROGRESS:           1,
        STATUS_DOWNLOAD_RESULT:             2,
        STATUS_INSTALL_PROGRESS:            3,
        STATUS_INSTALL_RESULT:              4,
        STATUS_INSTALL_FAIL:                5
    },

    ImageSize: {
        DETAIL_ICON_WIDTH : sceneResolution == '1080' ? 512 : 342,
        DETAIL_ICON_HEIGHT: sceneResolution == '1080' ? 423 : 282,
        SCREENSHOT_WIDTH : sceneResolution == '1080' ? 312 : 261,
        SCREENSHOT_HEIGHT: sceneResolution == '1080' ? 175 : 147,
        SCREENSHOT_LARGE_WIDTH : sceneResolution == '1080' ? 1206 : 800,
        SCREENSHOT_LARGE_HEIGHT: sceneResolution == '1080' ? 678 : 450,
        PNG_ICON_WIDTH : sceneResolution == '1080' ? 115 : 85,
        PNG_ICON_HEIGHT: sceneResolution == '1080' ? 95  : 70,
        JPG_ICON_WIDTH : sceneResolution == '1080' ? 115 : 85,
        JPG_ICON_HEIGHT: sceneResolution == '1080' ? 95  : 70,
        DETAIL_PNG_ICON_WIDTH : sceneResolution == '1080' ? 196 : 130,
        DETAIL_PNG_ICON_HEIGHT: sceneResolution == '1080' ? 162 : 108,
        DETAIL_JPG_ICON_WIDTH : sceneResolution == '1080' ? 196 : 130,
        DETAIL_JPG_ICON_HEIGHT: sceneResolution == '1080' ? 162 : 108
    },

    Popup: {
        ONE_LINE_TOP_GAP: 96,
        ONE_LINE_MIDDEL_GAP: 70,
        MULTI_LINE_TOP_GAP: 48,
        MULTI_LINE_MIDDEL_GAP: 22,
        TITLE_UNDER_GAP: 29,
        BOTTOM_GAP: 30,
        TYPE_NETWORK: 'NETWORK',
        TYPE_PIN : 'PIN_POPUP'
    },

    Const: {
        HALO_ITEM_ALL_SAME:                 0,
        HALO_ITEM_NOT_ALL_SAME:             1,
        THUMB_STYLE_BLANK:                  0x00,
        THUMB_STYLE_IMAGE:                  0x01,
        THUMB_STYLE_ICON:                   0x02,
        THUMB_STYLE_TEXT:                   0x04,
        THUMB_STYLE_PROGRESSBAR:            0x08,
        THUMB_STYLE_CHECKBOX:               0x10,
        THUMB_STYLE_INFO:                   0x20
    },
    MsgBoxType: {
		MSGBOX_TYPE_NONE:                              -1,
		MSGBOX_TYPE_CONNECT_SEVER_ERROR:                0,
		MSGBOX_TYPE_MEMORY_FULL_CONNECT_USB_INSTALL:	1,
		MSGBOX_TYPE_DLD_BEFORE_RATE:		            2,
        MSGBOX_TYPE_APPSYNC_NOT_COMPLETE:               3,
        MSGBOX_TYPE_NETWORK_ERROR:                      4,
        MSGBOX_TYPE_INSTALL_FAIL:    		            5,
        MSGBOX_TYPE_REQUIRE_NETWORK:                    6,
        MSGBOX_TYPE_INVALID_COUPON:                     7,
        MSGBOX_TYPE_RATEING:                            8,
        MSGBOX_TYPE_PIN:                                9,
        MSGBOX_TYPE_LATEST_VERSIONS_OF_ALL_APPS:        10,
		MSGBOX_TYPE_SERVER_ERROR_GUIDE:                 11,
		TYPE_DELETE_MY_APPS :                           12,
        MSGBOX_TYPE_SETHEADER_ERROR:                    13,
        MSGBOX_TYPE_FAIL_DOWNLOAD :                     14,
        MSGBOX_TYPE_CANNT_DOWNLOADTOUSB :               15,
        MSGBOX_TYPE_SMARTHUB_INFO:                      16,
        TYPE_NETWORK:                                   17,
		MSGBOX_TYPE_OPTIONMENU:                         18,
		MSGBOX_TYPE_CONTEXTMENU:                        19,
		MSGBOX_TYPE_DEVELOP:                        20,
		MSGBOX_TYPE_FAIL_TO_UNINSTALL:                      21,
    },
    AppState: {
        APP_STATE_ACTIVATE:				'APP_STATE_ACTIVATE',
	 APP_STATE_DEACTIVATE:			'APP_STATE_DEACTIVATE',
    },
    
     Magic: {
        SHOW_VERSION: '12321',
    }
}

exports = CommonDefines;