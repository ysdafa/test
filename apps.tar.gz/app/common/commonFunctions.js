 /** 
 * @author lihao Zha (lihao.zha@samsung.com)
 * @fileoverview This module defines common functions.
 * @date    2014/11/15 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var DeviceInfoModel = Volt.require('app/models/deviceInfoModel.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');

var bForceDisableVoiceGuide = true;
var firstEnterMark = 2;
var appState = CommonDefines.AppState.APP_STATE_ACTIVATE;

var voiceGuide = function(voiceText,bQueuingPlay){
    Volt.log('[commonFunctions.js] voice guide text : ' + voiceText);
    if(bForceDisableVoiceGuide){
       Volt.log('[commonFunctions.js] forceDisableVoiceGuide, do not need to play unnecessary tts');
       return;
    }
	if(1 != DeviceInfoModel.get('tts')){
		Volt.log('[commonFunctions.js] voice guide function is off, do not need to play tts');
		return;
	}
    if(bQueuingPlay){
        Volt.log('[commonFunctions.js] queuingPlay');
        TTS.queuingPlay(voiceText);
    }
    else{
	    TTS.setText(voiceText);
        TTS.play();
    }
}

var forceDisableVoiceGuide = function(bForceDisable){
    bForceDisableVoiceGuide =  bForceDisable;
}

var getAppState = function(){
	return appState;
}

var setAppState = function(state){
	appState = state;
}

var getFirstEnterMark = function(){
    return firstEnterMark;
}

var setFirstEnterMark = function(value){
    firstEnterMark = value;
}

exports = {
    voiceGuide : voiceGuide,
    forceDisableVoiceGuide : forceDisableVoiceGuide,
    getAppState : getAppState,
    setAppState : setAppState,
    getFirstEnterMark : getFirstEnterMark,
    setFirstEnterMark : setFirstEnterMark
};