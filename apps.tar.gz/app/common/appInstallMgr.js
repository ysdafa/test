 /** 
 * @author dohyoung Kim (dohyoung7.kim@samsung.com)
 * @fileoverview This module manages installation of app.
 * @date    2014/07/18 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var _ = Volt.require("modules/underscore.js")._,
    EventMediator = Volt.require('app/common/eventMediator.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    voltapi = Volt.require('voltapi.js');

var self;

/**
 * AppInstallMgr manages status of installing app or ready to install app.
 * @class
 */
var AppInstallMgr = {

    installList: [],
    unInstallList: [],
    launchedAppID: "",

    /**
     * initialize AppInstallMgr
     * @method
     */
    initialize: function() {
        Volt.err("[appInstallMgr.js] initialize()");
        self = this;

        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_DOWNLOADING, this.downloadCallback);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_DOWNLOAD_COMPLETED, this.downloadCallback);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_DOWNLOAD_FAIL_NOT_EXIST, this.downloadCallback);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_DOWNLOAD_FAIL_NOSPACE, this.downloadCallback);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_DOWNLOAD_FAIL_LICENSE_ERROR, this.downloadCallback);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_DOWNLOAD_FAIL_SERVER_ERROR, this.downloadCallback);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_DOWNLOAD_FAIL_NETWORK_ERROR, this.downloadCallback);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_DOWNLOAD_FAIL_OTHERS, this.downloadCallback);

        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_INSTALLING, this.installCallback);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_INSTALL_COMPLETED, this.installCallback);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_EXIST, this.installCallback);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_PKGMGR_ERROR, this.installCallback);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_LICENSE_ERROR, this.installCallback);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_OTHERS, this.installCallback);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_APPSYNC_NOT_COMPLETE, this.installCallback);

        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_INSTALL_CANCEL_COMPLETED, this.installCancelCallBack);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_INSTALL_CANCEL_FAILED, this.installCancelCallBack);

        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_UNINSTALLING, this.unInstallCallback);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_UNINSTALL_COMPLETED, this.unInstallCallback);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_UNINSTALL_FAIL_NOT_EXIST, this.unInstallCallback);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_UNINSTALL_FAIL_PKGMGR_ERROR, this.unInstallCallback);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_UNINSTALL_FAIL_NOT_REMOVABLE, this.unInstallCallback);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_UNINSTALL_FAIL_OTHERS, this.unInstallCallback);

        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_LAUNCHER_LAUNCH_START, this.launcherCallBack);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_LAUNCHER_LAUNCH, this.launcherCallBack);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_LAUNCHER_SHOW, this.launcherCallBack);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_LAUNCHER_TERMINATE, this.launcherCallBack);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_LAUNCHER_FAIL_NOT_EXIST, this.launcherCallBack);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_LAUNCHER_FAIL_TIMEOUT, this.launcherCallBack);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_LAUNCHER_FAIL_EMP, this.launcherCallBack);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_LAUNCHER_FAIL_SMARTHUB, this.launcherCallBack);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_LAUNCHER_FAIL_CAPH_APP, this.launcherCallBack);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_LAUNCHER_FAIL_NETWORK, this.launcherCallBack);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_LAUNCHER_FAIL_OTHERS, this.launcherCallBack);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_LAUNCHER_FAIL_MLS, this.launcherCallBack);

        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_APPS_LIST, this.appsSyncCallBack);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_APPS_SYNC_COMPLETED, this.appsSyncCallBack);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVENT_APPS_SYNC_FAIL_NETWORK_ERROR, this.appsSyncCallBack);
        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_EVNET_APPS_SYNC_FAIL_OTHERS, this.appsSyncCallBack);

        voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_REQUEST_APP_LIST, this.updateCallBack);
    },

    /**
     * Request to install app
     * @method
     * @param {string} appID
     */
    installApp: function(appID, usbPath) {
        Volt.err("[appInstallMgr.js] installApp()");
        this.addInstallList(appID, CommonDefines.AppInstallMgr.TYPE_INSTALL, usbPath ? usbPath: '');
        if (!this.checkInstallingApp()) {
            this.installHandler();
        }
    },

    /**
     * Request to cancel about installing app
     * @method
     * @param {string} appID
     */
    cancelInstallApp: function(appID) {
        Volt.err("[appInstallMgr.js] cancelInstallApp()");

        var findObj = _.find(this.installList, function(obj){
            if (obj.app_id === appID && obj.type == CommonDefines.AppInstallMgr.TYPE_INSTALL) {
                return obj;
            }
        });

        if (findObj !== undefined) {
            if (findObj.status === CommonDefines.AppInstallMgr.STATUS_INSTALL_READY) {
                this.removeInstallList(findObj.app_id);
                EventMediator.trigger(CommonDefines.Event.INSTALL_CANCEL_COMPLETED, {
                    "eventType": CommonDefines.Event.INSTALL_CANCEL_COMPLETED,
                    "app_id": findObj.app_id,
                    "result": 0
                });
            }
            else {
                if((findObj.status === CommonDefines.AppInstallMgr.STATUS_DOWNLOAD_PROGRESS
                    && findObj.value === 100) || findObj.status == CommonDefines.AppInstallMgr.STATUS_DOWNLOAD_RESULT){
                    Volt.err("[appInstallMgr.js] cancelInstallApp Downloading is finished, can not cancel");
                    return;
                }
                var ret = voltapi.WAS.cancelInstallApp(findObj.app_id);
                Volt.err("[appInstallMgr.js] voltapi.WAS.cancelInstallApp() ret : " + ret);
            }
        }
    },

    /**
     * Return a installList matching appID.
     * @method
     * @param {string} appID
     * @returns {object} a installList
     * @example 
     * return example
     * empty installList : return [];
     * INSTALL_READY
     * {
     *     app_id: "111199000560",
     *     status: 0,      // INSTALL_READY / DOWNLOAD_PROGRESS / DOWNLOAD_RESULT / INSTALL_PROGRESS
     * }
     * DOWNLOAD_PROGRESS
     * {
     *     app_id: "111199000560",
     *     status: 1,
     *     value : 50
     * }
     * DOWNLOAD_RESULT
     * {
     *     app_id: "111199000560",
     *     status: 2,
     *     value : 0
     * }
     * INSTALL_PROGRESS
     * {
     *     app_id: "111199000560",
     *     status: 3,
     *     value : 90
     * }    
     */
    getInstallList: function(appID) {
        var findObj = _.find(this.installList, function(obj){
            if (obj.app_id === appID && obj.type == CommonDefines.AppInstallMgr.TYPE_INSTALL) {
                return obj;
            }
        });

        if (findObj === undefined) {
            findObj = {};
        }

        return findObj;
    },

    /**
     * Return all installList.
     * @method
     * @returns {object} all installList
     */
    getAllInstallList: function() {
        Volt.err("[appInstallMgr.js] getAllInstallList()");

        var findObj = _.filter(this.installList, function(obj) {
            if (obj.type == CommonDefines.AppInstallMgr.TYPE_INSTALL) {
                return obj;
            }
        });

        if (findObj === undefined) {
            findObj = [];
        }

        return findObj;
    },

    /**
     * Remove all install list.
     * @method
     */
    removeAllInstallList: function() {
        Volt.err("[appInstallMgr.js] removeAllInstallList()");

        var findObj = _.reject(this.installList, function(obj) {
            if (obj.type == CommonDefines.AppInstallMgr.TYPE_INSTALL) {
                return obj;
            }
        });

        this.installList = findObj;
    },

    /**
     * Check installing app
     * @method
     * @returns {boolean} If there is installing app, return true.
     */
    checkInstallingApp: function() {
        Volt.err("[appInstallMgr.js] checkInstallingApp()");

        var firstObj = _.first(this.installList);
        if (firstObj !== undefined) {
            if (firstObj.type == CommonDefines.AppInstallMgr.TYPE_INSTALL) {
                if (firstObj.status === CommonDefines.AppInstallMgr.STATUS_INSTALL_READY) {
                    Volt.err("[appInstallMgr.js] Install Ready...");
                    return false;
                }
                else {
                    Volt.err("[appInstallMgr.js] Installing...");
                    return true;
                }
            }
            else if (firstObj.type == CommonDefines.AppInstallMgr.TYPE_UPDATE) {
                if (firstObj.status === CommonDefines.AppInstallMgr.STATUS_UPDATE_READY) {
                    Volt.err("[appInstallMgr.js] Update Ready...");
                    return false;
                }
                else {
                    Volt.err("[appInstallMgr.js] Updating...");
                    return true;
                }
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    },

    /**
     * Handle to install app
     * @method
     */
    installHandler: function() {
        Volt.err("[appInstallMgr.js] installHandler()");

        var firstObj = _.first(this.installList);

        if (firstObj !== undefined && firstObj.status === CommonDefines.AppInstallMgr.STATUS_INSTALL_READY) {
            firstObj.status = CommonDefines.AppInstallMgr.STATUS_DOWNLOAD_PROGRESS;
            firstObj.value = 0;
            
	     Volt.log("[appInstallMgr.js] voltapi.WAS.installApp() app_id is :" + firstObj.app_id);
            var ret = voltapi.WAS.installApp(firstObj.app_id, "", firstObj.path ? firstObj.path:"");
            Volt.err("[appInstallMgr.js] voltapi.WAS.installApp() ret : " + ret);

            EventMediator.trigger(CommonDefines.Event.INSTALL_START, {
                "eventType": CommonDefines.Event.INSTALL_START,
                "app_id": firstObj.app_id,
                "value": ret
            });
        }
        else if (firstObj !== undefined && firstObj.status === CommonDefines.AppInstallMgr.STATUS_UPDATE_READY) {
            firstObj.status = CommonDefines.AppInstallMgr.STATUS_DOWNLOAD_PROGRESS;
            firstObj.value = 0;

            var ret = voltapi.WAS.updateApp(firstObj.app_id);
            Volt.err("[appInstallMgr.js] voltapi.WAS.updateApp() ret : " + ret);

            EventMediator.trigger(CommonDefines.Event.UPDATE_START, {
                "eventType": CommonDefines.Event.UPDATE_START,
                "app_id": firstObj.app_id,
                "value": ret
            });
        }
    },

    /**
     * Add status to installList.
     * @method
     * @param {string} appID
     */
    addInstallList: function(appID, type, usbPath) {
        Volt.err("[appInstallMgr.js] addInstallList() appID = " + appID);

        var findObj = _.find(this.installList, function(obj){
            if (obj.app_id === appID) {
                return obj;
            }
        });

        if (findObj === undefined) {
            var newObj = {};
            newObj.app_id = appID;

            if (type == CommonDefines.AppInstallMgr.TYPE_INSTALL) {
                newObj.status = CommonDefines.AppInstallMgr.STATUS_INSTALL_READY;
            }
            else if (type == CommonDefines.AppInstallMgr.TYPE_UPDATE) {
                newObj.status = CommonDefines.AppInstallMgr.STATUS_UPDATE_READY;
            }

            newObj.type = type;

            if( usbPath ){
                newObj.path = usbPath;
            }

            this.installList.push(newObj);
        }
    },
    
    /**
     * Remove status to installList.
     * @method
     * @param {string} appID
     */
    removeInstallList: function(appID) {  
        Volt.err("[appInstallMgr.js] removeInstallList()");

        var findObj = _.find(this.installList, function(obj){
            if (obj.app_id === appID) {
                return obj;
            }
        });

        if (findObj === undefined)
            return;

        var findIndex = _.indexOf(this.installList, findObj);

        this.installList.splice(findIndex, 1);
    },

    /**
     * Set status to installList.
     * @method
     * @param {string} appID
     * @param {int} install status
     * @param {int} install progress
     */
    setInstallListStatus: function(appID, status, progress) {
        Volt.err("[appInstallMgr.js] setInstallListStatus() appID = " + appID + " status = " + status);

        var findObj = _.find(this.installList, function(obj){
            if (obj.app_id === appID) {
                return obj;
            }
        });

        if (findObj === undefined)
            return;

        findObj.status = status;
        findObj.value = progress;

        var findIndex = _.indexOf(this.installList, findObj);
        this.installList.splice(findIndex, 1, findObj);
    },

    /**
     * Request to update app
     * @method
     * @param {String|String[]} appID
     */
    updateApp: function(appID) {
        Volt.err("[appInstallMgr.js] updateApp()");

        if (appID.constructor.name === 'Array') {
            _.each(appID, function(id) {
                self.addInstallList(id, CommonDefines.AppInstallMgr.TYPE_UPDATE);
            });
        }
        else if (appID.constructor.name === 'String') {
            this.addInstallList(appID, CommonDefines.AppInstallMgr.TYPE_UPDATE);
        }

        if (!this.checkInstallingApp()) {
            this.installHandler();
        }
    },

    /**
     * Return a updateList matching appID.
     * @method
     * @param {string} appID
     * @returns {object} a updateList
     * @example 
     * return example
     * empty updateList : return [];
     * UPDATE_READY
     * {
     *     app_id: "111199000560",
     *     status: 4,      // UPDATE_READY / DOWNLOAD_PROGRESS / DOWNLOAD_RESULT / INSTALL_PROGRESS
     * }
     * DOWNLOAD_PROGRESS
     * {
     *     app_id: "111199000560",
     *     status: 1,
     *     value : 50
     * }
     * DOWNLOAD_RESULT
     * {
     *     app_id: "111199000560",
     *     status: 2,
     *     value : 0
     * }
     * INSTALL_PROGRESS
     * {
     *     app_id: "111199000560",
     *     status: 3,
     *     value : 90
     * }    
     */
    getUpdateList: function(appID) {
        var findObj = _.find(this.installList, function(obj){
            if (obj.app_id === appID && obj.type == CommonDefines.AppInstallMgr.TYPE_UPDATE) {
                return obj;
            }
        });

        if (findObj === undefined) {
            findObj = {};
        }

        return findObj;
    },

    /**
     * Return all updateList.
     * @method
     * @returns {object} all updateList
     */
    getAllUpdateList: function() {
        Volt.err("[appInstallMgr.js] getAllUpdateList()");

        var findObj = _.filter(this.installList, function(obj) {
            if (obj.type == CommonDefines.AppInstallMgr.TYPE_UPDATE) {
                return obj;
            }
        });

        if (findObj === undefined) {
            findObj = [];
        }

        return findObj;
    },

    /**
     * Remove all update list.
     * @method
     */
    removeAllUpdateList: function() {
        Volt.err("[appInstallMgr.js] removeAllUpdateList()");

        var findObj = _.reject(this.installList, function(obj) {
            if (obj.type == CommonDefines.AppInstallMgr.TYPE_UPDATE) {
                return obj;
            }
        });

        this.installList = findObj;
    },

    /**
     * Request to uninstall app
     * @method
     * @param {String|String[]} appID
     */
    unInstallApp: function(appID) {
        Volt.err("[appInstallMgr.js] unInstallApp()");

        if (appID.constructor.name === 'Array') {
            _.each(appID, function(id) {
                self.addUnInstallList(id, CommonDefines.AppInstallMgr.TYPE_UNINSTALL);
            });
        }
        else if (appID.constructor.name === 'String') {
            this.addUnInstallList(appID, CommonDefines.AppInstallMgr.TYPE_UNINSTALL);
        }

        if (!this.checkUnInstallingApp()) {
            this.unInstallHandler();
        }
    },

    /**
     * Return a unInstallList matching appID.
     * @method
     * @param {string} appID
     * @returns {object} a unInstallList
     * @example 
     * return example
     * empty unInstallList : return [];
     * UNINSTALL_READY
     * {
     *     app_id: "111199000560",
     *     status: 4,      // UPDATE_READY / DOWNLOAD_PROGRESS / DOWNLOAD_RESULT / INSTALL_PROGRESS / UNINSTALL_READY / UNINSTALL_PROGRESS
     * }
     * UNINSTALL_PROGRESS
     * {
     *     app_id: "111199000560",
     *     status: 1,
     *     value : 50
     * }
     */
    getUnInstallList: function(appID) {
        var findObj = _.find(this.unInstallList, function(obj){
            if (obj.app_id === appID && obj.type == CommonDefines.AppInstallMgr.TYPE_UNINSTALL) {
                return obj;
            }
        });

        if (findObj === undefined) {
            findObj = {};
        }

        return findObj;
    },

    /**
     * Return all unInstallList.
     * @method
     * @returns {object} all unInstallList
     */
    getAllUnInstallList: function() {
        Volt.err("[appInstallMgr.js] getAllUnInstallList()");

        var findObj = _.filter(this.unInstallList, function(obj) {
            if (obj.type == CommonDefines.AppInstallMgr.TYPE_UNINSTALL) {
                return obj;
            }
        });

        if (findObj === undefined) {
            findObj = [];
        }

        return findObj;
    },

    /**
     * Remove all unInstallList.
     * @method
     */
    removeAllUnInstallList: function() {
        Volt.err("[appInstallMgr.js] removeAllUnInstallList()");

        var findObj = _.reject(this.unInstallList, function(obj) {
            if (obj.type == CommonDefines.AppInstallMgr.TYPE_UNINSTALL) {
                return obj;
            }
        });

        this.unInstallList = findObj;
    },

    /**
     * Check unInstalling app
     * @method
     * @returns {boolean} If there is uninstalling app, return true.
     */
    checkUnInstallingApp: function() {
        Volt.err("[appInstallMgr.js] checkUnInstallingApp()");

        var firstObj = _.first(this.unInstallList);

        if (firstObj !== undefined) {
            if (firstObj.type == CommonDefines.AppInstallMgr.TYPE_UNINSTALL) {
                if (firstObj.status === CommonDefines.AppInstallMgr.STATUS_UNINSTALL_READY) {
                    Volt.err("[appInstallMgr.js] UnInstall Ready...");
                    return false;
                }
                else {
                    Volt.err("[appInstallMgr.js] UnInstalling...");
                    return false;//if UnInstalling also return false
                }
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    },

    /**
     * Handle to uninstall app
     * @method
     */
    unInstallHandler: function() {
        Volt.err("[appInstallMgr.js] unInstallHandler() this.unInstallList.length = " + this.unInstallList.length);
	 if(this.unInstallList.length > 1){
	 	var uninstallAppId = [];
		for(i = 0; i < this.unInstallList.length; i++){
			uninstallAppId.push({"app":this.unInstallList[i].app_id});
		}
		var ret = voltapi.WAS.mutilUnInstallApps(uninstallAppId);
		Volt.err("[appInstallMgr.js] voltapi.WAS.mutilUnInstallApps() ret : " + ret);
	 }
	 else{
	        var firstObj = _.first(this.unInstallList);

	       // if (firstObj !== undefined && firstObj.status === CommonDefines.AppInstallMgr.STATUS_UNINSTALL_READY) {
		   if (firstObj !== undefined) {
	            firstObj.status = CommonDefines.AppInstallMgr.STATUS_UNINSTALL_PROGRESS;
	            firstObj.value = 0;

			Volt.log("[appInstallMgr.js] unInstallHandler firstObj.app_id = " + firstObj.app_id);
	            var ret = voltapi.WAS.unInstallApp(firstObj.app_id);
	            Volt.err("[appInstallMgr.js] voltapi.WAS.unInstallApp() ret : " + ret);
	            EventMediator.trigger(CommonDefines.Event.UNINSTALL_START, {
	                "eventType": CommonDefines.Event.UNINSTALL_START,
	                "app_id": firstObj.app_id,
	                "value": ret
	            });
	        }
	 }
    },

    /**
     * Add status to unInstallList.
     * @method
     * @param {string} appID
     */
    addUnInstallList: function(appID, type, usbPath) {
        Volt.err("[appInstallMgr.js] addUnInstallList()");
        
        var findObj = _.find(this.unInstallList, function(obj){
            if (obj.app_id === appID) {
                return obj;
            }
        });

        if (findObj === undefined) {
            var newObj = {};
            newObj.app_id = appID;

            if (type == CommonDefines.AppInstallMgr.TYPE_UNINSTALL) {
                newObj.status = CommonDefines.AppInstallMgr.STATUS_UNINSTALL_READY;
            }

            newObj.type = type;

            this.unInstallList.push(newObj);
        }
    },

    /**
     * Remove status to unInstallList.
     * @method
     * @param {string} appID
     */
    removeUnInstallList: function(appID) {  
        Volt.err("[appInstallMgr.js] removeUnInstallList()");

        var findObj = _.find(this.unInstallList, function(obj){
            if (obj.app_id === appID) {
                return obj;
            }
        });

        if (findObj === undefined)
            return;

        var findIndex = _.indexOf(this.unInstallList, findObj);

        this.unInstallList.splice(findIndex, 1);
    },

    /**
     * Set status to unInstallList.
     * @method
     * @param {string} appID
     * @param {int} uninstall status
     * @param {int} uninstall progress
     */
    setUnInstallListStatus: function(appID, status, progress) {
        Volt.err("[appInstallMgr.js] setUnInstallListStatus()");

        var findObj = _.find(this.unInstallList, function(obj){
            if (obj.app_id === appID) {
                return obj;
            }
        });

        if (findObj === undefined)
            return;

        findObj.status = status;
        findObj.value = progress;

        var findIndex = _.indexOf(this.unInstallList, findObj);
        this.unInstallList.splice(findIndex, 1, findObj);
    },

    /**
     * Launch App.
     * @method
     * @param {string} appID
     * @param {string} payload
     * @returns {int} true : 0, false : -1
     */
    launchApp: function(appID, payload) {
        Volt.err("[appInstallMgr.js] launchApp()");

        var ret = voltapi.WAS.launchApp(appID, payload, 'org.volt.apps');
        Volt.err("[appInstallMgr.js] voltapi.WAS.launchApp() ret : " + ret);

        this.launchedAppID = appID;

        return ret;
    },

    /**
     * Terminate App.
     * @method
     * @param {string} appID
     * @returns {int} true : 0, false : -1
     */
    terminateApp: function(appID) {
        Volt.err("[appInstallMgr.js] terminateApp()");

        var ret = voltapi.WAS.terminateApp(appID);
        Volt.err("[appInstallMgr.js] voltapi.WAS.terminateApp() ret : " + ret);

        return ret;
    },

    /**
     * Get Launched AppID.
     * @method
     * @returns {string} appID
     */
    getLaunchedAppID: function() {
        Volt.err("[appInstallMgr.js] getLaunchedAppID()");

        return this.launchedAppID;
    },

    /**
     * Callback for WAS_MANAGER_DOWNLOAD.
     * @method
     * @param {object} data1 is JSON object passed from WAS
     * @param {object} data2
     * @example 
     * event
     * {
     *     "eventType" : CommonDefines.Event.DOWNLOAD_COMPLETED,
     *     "app_id" : "111199000560",
     *     "result" : 0
     * }
     */
    downloadCallback: function(eventType, data1, data2) {
        Volt.err("[appInstallMgr.js] downloadCallback() eventType : " + eventType);
        Volt.err("[appInstallMgr.js] downloadCallback() data1 : " + data1);
        data1 = JSON.parse(data1);

        switch (eventType) {
            case CommonDefines.WAS.WAS_EVENT_DOWNLOADING:
                if (data1.app_id !== undefined && data1.result !== undefined) {
                    self.setInstallListStatus(data1.app_id, CommonDefines.AppInstallMgr.STATUS_DOWNLOAD_PROGRESS, data1.result);
                    data1.eventType = CommonDefines.Event.DOWNLOADING;
                    EventMediator.trigger(data1.eventType, data1);
                }
                break;
            case CommonDefines.WAS.WAS_EVENT_DOWNLOAD_COMPLETED:
                if (data1.app_id !== undefined && data1.result !== undefined) {
                    self.setInstallListStatus(data1.app_id, CommonDefines.AppInstallMgr.STATUS_DOWNLOAD_RESULT, data1.result);
                    data1.eventType = CommonDefines.Event.DOWNLOAD_COMPLETED;
                    EventMediator.trigger(data1.eventType, data1);
                }
                break;
            case CommonDefines.WAS.WAS_EVENT_DOWNLOAD_FAIL_NOT_EXIST:
            case CommonDefines.WAS.WAS_EVENT_DOWNLOAD_FAIL_NOSPACE:
            case CommonDefines.WAS.WAS_EVENT_DOWNLOAD_FAIL_LICENSE_ERROR:
            case CommonDefines.WAS.WAS_EVENT_DOWNLOAD_FAIL_SERVER_ERROR:
            case CommonDefines.WAS.WAS_EVENT_DOWNLOAD_FAIL_NETWORK_ERROR:
            case CommonDefines.WAS.WAS_EVENT_DOWNLOAD_FAIL_OTHERS:
                if (data1.app_id !== undefined && data1.result !== undefined) {
                    self.removeInstallList(data1.app_id);

                    switch (eventType) {
                        case CommonDefines.WAS.WAS_EVENT_DOWNLOAD_FAIL_NOT_EXIST:
                            data1.eventType = CommonDefines.Event.DOWNLOAD_FAIL_NOT_EXIST;
                            break;
                        case CommonDefines.WAS.WAS_EVENT_DOWNLOAD_FAIL_NOSPACE:
                            data1.eventType = CommonDefines.Event.DOWNLOAD_FAIL_NOSPACE;
                            break;
                        case CommonDefines.WAS.WAS_EVENT_DOWNLOAD_FAIL_LICENSE_ERROR:
                            data1.eventType = CommonDefines.Event.DOWNLOAD_FAIL_LICENSE_ERROR;
                            break;
                        case CommonDefines.WAS.WAS_EVENT_DOWNLOAD_FAIL_SERVER_ERROR:
                            data1.eventType = CommonDefines.Event.DOWNLOAD_FAIL_SERVER_ERROR;
                            break;
                        case CommonDefines.WAS.WAS_EVENT_DOWNLOAD_FAIL_NETWORK_ERROR:
                            data1.eventType = CommonDefines.Event.DOWNLOAD_FAIL_NETWORK_ERROR;
                            break;
                        case CommonDefines.WAS.WAS_EVENT_DOWNLOAD_FAIL_OTHERS:
                            data1.eventType = CommonDefines.Event.DOWNLOAD_FAIL_OTHERS;
                            break;
                        default:
                            break;
                    }

                    EventMediator.trigger(data1.eventType, data1);
                    self.installHandler();
                }
                break;
            default:
                break;
        }
    },

    /**
     * Callback for WAS_MANAGER_INSTALL.
     * @method
     * @param {object} data1 is JSON object passed from WAS
     * @param {object} data2
     * @example 
     * event
     * {
     *     "eventType" : CommonDefines.Event.INSTALL_COMPLETED
     *     "app_id" : "111199000560",
     *     "result" : 0
     * }
     */
    installCallback: function(eventType, data1, data2) {
        Volt.err("[appInstallMgr.js] installCallback() eventType : " + eventType);
        Volt.err("[appInstallMgr.js] installCallback() data1 : " + data1);
        data1 = JSON.parse(data1);

        switch (eventType) {
            case CommonDefines.WAS.WAS_EVENT_INSTALLING:
                if (data1.app_id !== undefined && data1.result !== undefined) {
                    self.setInstallListStatus(data1.app_id, CommonDefines.AppInstallMgr.STATUS_INSTALL_PROGRESS, data1.result);
                    data1.eventType = CommonDefines.Event.INSTALLING;
                    EventMediator.trigger(data1.eventType, data1);
                }
                break;
            case CommonDefines.WAS.WAS_EVENT_INSTALL_COMPLETED:
                if (data1.app_id !== undefined && data1.result !== undefined) {
                    self.removeInstallList(data1.app_id);
                    data1.eventType = CommonDefines.Event.INSTALL_COMPLETED;
                    EventMediator.trigger(data1.eventType, data1);
                    self.installHandler();
                }
                break;
            case CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_EXIST:
            case CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_PKGMGR_ERROR:
            case CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_LICENSE_ERROR:
            case CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_OTHERS:
            case CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_APPSYNC_NOT_COMPLETE:
                if (data1.app_id !== undefined && data1.result !== undefined) {
                    self.removeInstallList(data1.app_id);

                    switch (eventType) {
                        case CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_EXIST:
                            data1.eventType = CommonDefines.Event.INSTALL_FAIL_EXIST;
                            break;
                        case CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_PKGMGR_ERROR:
                            data1.eventType = CommonDefines.Event.INSTALL_FAIL_PKGMGR_ERROR;
                            break;
                        case CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_LICENSE_ERROR:
                            data1.eventType = CommonDefines.Event.INSTALL_FAIL_LICENSE_ERROR;
                            break;
                        case CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_OTHERS:
                            data1.eventType = CommonDefines.Event.INSTALL_FAIL_OTHERS;
                            break;
                        case CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_APPSYNC_NOT_COMPLETE:
                            data1.eventType = CommonDefines.Event.INSTALL_FAIL_APPSYNC_NOT_COMPLETE;
                            break;
                        default:
                            break;
                    }

                    EventMediator.trigger(data1.eventType, data1);
                    self.installHandler();
                }
                break;
            default:
                break;
        }
    },

    /**
     * Callback for WAS_MANAGER_DOWNLOAD_CANCELED.
     * @method
     * @param {object} data1 is JSON object passed from WAS
     * @param {object} data2
     * @example 
     * event
     * {
     *     "eventType" : CommonDefines.WAS.WAS_EVENT_INSTALL_CANCEL_COMPLETED,
     *     "app_id" : "111199000560",
     *     "result" : 0
     * }
     */
    installCancelCallBack: function(eventType, data1, data2) {
        Volt.err("[appInstallMgr.js] downloadCanceledCallBack() eventType : " + eventType);
        Volt.err("[appInstallMgr.js] downloadCanceledCallBack() data1 : " + data1);
        data1 = JSON.parse(data1);

        switch (eventType) {
            case CommonDefines.WAS.WAS_EVENT_INSTALL_CANCEL_COMPLETED:
                if (data1.app_id !== undefined && data1.result !== undefined) {
                    self.removeInstallList(data1.app_id);
                    data1.eventType = CommonDefines.Event.INSTALL_CANCEL_COMPLETED;
                    EventMediator.trigger(data1.eventType, data1);
                    self.installHandler();
                }
                break;
            case CommonDefines.WAS.WAS_EVENT_INSTALL_CANCEL_FAILED:
                data1.eventType = CommonDefines.Event.INSTALL_CANCEL_FAILED;
                EventMediator.trigger(data1.eventType, data1);
                break;
            default:
                break;
        }
    },

    /**
     * Callback for WAS_MANAGER_UNINSTALL.
     * @method
     * @param {object} data1 is JSON object passed from WAS
     * @param {object} data2
     * @example 
     * event
     * {
     *     "eventType" : CommonDefines.Event.UNINSTALL_COMPLETED,
     *     "app_id" : "111199000560",
     *     "result" : 0
     * }
     */
    unInstallCallback: function(eventType, data1, data2) {
        Volt.err("[appInstallMgr.js] unInstallCallback() eventType : " + eventType);
        Volt.err("[appInstallMgr.js] unInstallCallback() data1 : " + data1);
        data1 = JSON.parse(data1);

        switch (eventType) {
            case CommonDefines.WAS.WAS_EVENT_UNINSTALLING:
                if (data1.app_id !== undefined && data1.result !== undefined) {
                    self.setUnInstallListStatus(data1.app_id, CommonDefines.AppInstallMgr.STATUS_UNINSTALL_PROGRESS, data1.result);
                    data1.eventType = CommonDefines.Event.UNINSTALLING;
                    EventMediator.trigger(data1.eventType, data1);
                }
                break;
            case CommonDefines.WAS.WAS_EVENT_UNINSTALL_COMPLETED:
                if (data1.app_id !== undefined && data1.result !== undefined) {
                    self.removeUnInstallList(data1.app_id);
                    data1.eventType = CommonDefines.Event.UNINSTALL_COMPLETED;
                    EventMediator.trigger(data1.eventType, data1);
                    //self.unInstallHandler();
                }
                break;
            case CommonDefines.WAS.WAS_EVENT_UNINSTALL_FAIL_NOT_EXIST:
            case CommonDefines.WAS.WAS_EVENT_UNINSTALL_FAIL_PKGMGR_ERROR:
            case CommonDefines.WAS.WAS_EVENT_UNINSTALL_FAIL_NOT_REMOVABLE:
            case CommonDefines.WAS.WAS_EVENT_UNINSTALL_FAIL_OTHERS:
                if (data1.app_id !== undefined && data1.result !== undefined) {
                    self.removeUnInstallList(data1.app_id);

                    switch (eventType) {
                        case CommonDefines.WAS.WAS_EVENT_UNINSTALL_FAIL_NOT_EXIST:
                            data1.eventType = CommonDefines.Event.UNINSTALL_FAIL_NOT_EXIST;
                            break;
                        case CommonDefines.WAS.WAS_EVENT_UNINSTALL_FAIL_PKGMGR_ERROR:
                            data1.eventType = CommonDefines.Event.UNINSTALL_FAIL_PKGMGR_ERROR;
                            break;
                        case CommonDefines.WAS.WAS_EVENT_UNINSTALL_FAIL_NOT_REMOVABLE:
                            data1.eventType = CommonDefines.Event.UNINSTALL_FAIL_NOT_REMOVABLE;
                            break;
                        case CommonDefines.WAS.WAS_EVENT_UNINSTALL_FAIL_OTHERS:
                            data1.eventType = CommonDefines.Event.UNINSTALL_FAIL_OTHERS;
                            break;
                        default:
                            break;
                    }

                    EventMediator.trigger(data1.eventType, data1);
                    //self.unInstallHandler();
                }
                break;
            default:
                break;
        }
    },

    /**
     * Callback for WAS_MANAGER_LAUNCH.
     * @method
     * @param {object} data1 is JSON object passed from WAS
     * @param {object} data2
     * @example 
     * event
     * {
     *     "eventType" : CommonDefines.WAS.WAS_EVENT_LAUNCHER_LAUNCH_START,
     *     "app_id" : "111199000560",
     *     "result" : 0
     * }
     */
    launcherCallBack: function(eventType, data1, data2) {
        Volt.err("[appInstallMgr.js] launcherCallBack() eventType : " + eventType);
        Volt.err("[appInstallMgr.js] launcherCallBack() data1 : " + data1);
        data1 = JSON.parse(data1);

        switch (eventType) {
            case CommonDefines.WAS.WAS_EVENT_LAUNCHER_LAUNCH_START:
                data1.eventType = CommonDefines.Event.LAUNCHER_LAUNCH_START;
                EventMediator.trigger(data1.eventType, data1);
                break;
            case CommonDefines.WAS.WAS_EVENT_LAUNCHER_LAUNCH:
                data1.eventType = CommonDefines.Event.LAUNCHER_LAUNCH;
                EventMediator.trigger(data1.eventType, data1);
                break;
            case CommonDefines.WAS.WAS_EVENT_LAUNCHER_SHOW:
                data1.eventType = CommonDefines.Event.LAUNCHER_SHOW;
                EventMediator.trigger(data1.eventType, data1);
                break;
            case CommonDefines.WAS.WAS_EVENT_LAUNCHER_TERMINATE:
                data1.eventType = CommonDefines.Event.LAUNCHER_TERMINATE;
                EventMediator.trigger(data1.eventType, data1);
                break;
            case CommonDefines.WAS.WAS_EVENT_LAUNCHER_FAIL_NOT_EXIST:
                data1.eventType = CommonDefines.Event.LAUNCHER_FAIL_NOT_EXIST;
                EventMediator.trigger(data1.eventType, data1);
                break;
            case CommonDefines.WAS.WAS_EVENT_LAUNCHER_FAIL_TIMEOUT:
                data1.eventType = CommonDefines.Event.LAUNCHER_FAIL_TIMEOUT;
                EventMediator.trigger(data1.eventType, data1);
                break;
            case CommonDefines.WAS.WAS_EVENT_LAUNCHER_FAIL_EMP:
                data1.eventType = CommonDefines.Event.LAUNCHER_FAIL_EMP;
                EventMediator.trigger(data1.eventType, data1);
                break;
            case CommonDefines.WAS.WAS_EVENT_LAUNCHER_FAIL_SMARTHUB:
                data1.eventType = CommonDefines.Event.LAUNCHER_FAIL_SMARTHUB;
                EventMediator.trigger(data1.eventType, data1);
                break;
            case CommonDefines.WAS.WAS_EVENT_LAUNCHER_FAIL_CAPH_APP:
                data1.eventType = CommonDefines.Event.LAUNCHER_FAIL_CAPH_APP;
                EventMediator.trigger(data1.eventType, data1);
                break;
            case CommonDefines.WAS.WAS_EVENT_LAUNCHER_FAIL_NETWORK:
                data1.eventType = CommonDefines.Event.LAUNCHER_FAIL_NETWORK;
                EventMediator.trigger(data1.eventType, data1);
                break;
            case CommonDefines.WAS.WAS_EVENT_LAUNCHER_FAIL_OTHERS:
                data1.eventType = CommonDefines.Event.LAUNCHER_FAIL_OTHERS;
                EventMediator.trigger(data1.eventType, data1);
                break;
            case CommonDefines.WAS.WAS_EVENT_LAUNCHER_FAIL_MLS:
                data1.eventType = CommonDefines.Event.LAUNCHER_FAIL_MLS;
                EventMediator.trigger(data1.eventType, data1);
                break;
            default:
                break;
        }
    },

    /**
     * Callback for update.
     * @method
     * @param {object} data1 is JSON object passed from WAS
     * @param {object} data2
     * @example 
     * event
     * {
     *     "eventType" : CommonDefines.WAS.WAS_REQUEST_APP_LIST,
     *     "app_id" : ,
     *     "app_icon" : ,
     *     "app_title" : ,
     *     "app_version" : ,
     *     "app_size" : ,
     *     "app_featured" : ,
     *     "app_state" : ,
     * }
     */
    updateCallBack: function(eventType, data1, data2) {
        Volt.err("[appInstallMgr.js] updateCallBack() eventType : " + eventType);
        Volt.err("[appInstallMgr.js] updateCallBack() data1 : " + data1);
        data1 = JSON.parse(data1);

        switch (eventType) {
            case CommonDefines.WAS.WAS_REQUEST_APP_LIST:
                if (data1 != null) {
                    data1.eventType = CommonDefines.Event.REQUEST_APP_LIST;
                }
                EventMediator.trigger(CommonDefines.Event.REQUEST_APP_LIST, data1);
                break;
            default:
                break;
        }
    },

    /**
     * Callback for app sync.
     * @method
     * @param {object} data1 is JSON object passed from WAS
     * @param {object} data2
     * @example 
     * event
     * {
     *     "eventType" : CommonDefines.WAS.WAS_APPS_LIST,
     *     "app_id" : ,
     *     "app_icon" : ,
     *     "app_title" : ,
     *     "app_version" : ,
     *     "app_size" : ,
     *     "app_featured" : ,
     *     "app_state" : ,
     * }
     */
    appsSyncCallBack: function(eventType, data1, data2) {
        Volt.err("[appInstallMgr.js] appsSyncCallBack() eventType : " + eventType);
        Volt.err("[appInstallMgr.js] appsSyncCallBack() data1 : " + data1);
        data1 = JSON.parse(data1);

        switch (eventType) {
            case CommonDefines.WAS.WAS_APPS_LIST:
                if (data1 != null) {
                    data1.eventType = CommonDefines.Event.APPS_LIST;
                }
                EventMediator.trigger(CommonDefines.Event.APPS_LIST, data1);
                break;
            case CommonDefines.WAS.WAS_EVENT_APPS_SYNC_COMPLETED:
                if (data1 != null) {
                    data1.eventType = CommonDefines.Event.APPS_SYNC_COMPLETED;
                }
                EventMediator.trigger(CommonDefines.Event.APPS_SYNC_COMPLETED, data1);
                break;
            case CommonDefines.WAS.WAS_EVENT_APPS_SYNC_FAIL_NETWORK_ERROR:
                if (data1 != null) {
                    data1.eventType = CommonDefines.Event.APPS_SYNC_FAIL_NETWORK_ERROR;
                }
                EventMediator.trigger(CommonDefines.Event.APPS_SYNC_FAIL_NETWORK_ERROR, data1);
                break;
            case CommonDefines.WAS.WAS_EVNET_APPS_SYNC_FAIL_OTHERS:
                if (data1 != null) {
                    data1.eventType = CommonDefines.Event.APPS_SYNC_FAIL_OTHERS;
                }
                EventMediator.trigger(CommonDefines.Event.APPS_SYNC_FAIL_OTHERS, data1);
                break;
            default:
                break;
        }
    },

    /**
     * Callback for Jasmine unit test.
     * @method
     * @param {String} eventType event from WAS
     * @param {function} cb callback function
     */
    registerCallback: function(eventType, cb) {
        switch (eventType) {
            case 'voltapi.WAS.WAS_MANAGER_DOWNLOAD_PROGRESS':
                voltapi.WAS.addEventListener(voltapi.WAS.WAS_MANAGER_DOWNLOAD_PROGRESS, cb);
                break;
            case 'voltapi.WAS.WAS_MANAGER_DOWNLOAD':
                voltapi.WAS.addEventListener(voltapi.WAS.WAS_MANAGER_DOWNLOAD, cb);
                break;
            case 'voltapi.WAS.WAS_MANAGER_INSTALL_PROGRESS':
                voltapi.WAS.addEventListener(voltapi.WAS.WAS_MANAGER_INSTALL_PROGRESS, cb);
                break;
            case 'voltapi.WAS.WAS_MANAGER_INSTALL':
                voltapi.WAS.addEventListener(voltapi.WAS.WAS_MANAGER_INSTALL , cb);
                break;
            case 'voltapi.WAS.WAS_MANAGER_DOWNLOAD_CANCELED':
                voltapi.WAS.addEventListener(voltapi.WAS.WAS_MANAGER_DOWNLOAD_CANCELED, cb);
                break;
            default:
                break;
        }
    }
};

exports = AppInstallMgr;
