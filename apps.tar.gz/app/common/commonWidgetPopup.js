var CommonDefines = Volt.require('app/common/commonDefines.js');
var EventMediator = Volt.require('app/common/eventMediator.js');
var message_Box = Volt.require('lib/views/message-box-popup.js');
var winsetDimView = Volt.require("lib/views/dim-view.js");
var winsetMessageBox = Volt.require("WinsetUIElement/winsetMessageBox.js");
var Q = Volt.require('modules/q.js');
var voltapi = Volt.require('voltapi.js');
var ratingPopup = null;
var PinPopup = null;
var configXML = null;
var self = this;
var CommonFunctions = Volt.require('app/common/commonFunctions.js');
var commonWidgetPopup = {
    //initialize: function () {},
    showMessage: function (messageId, params) {
        //this.destroyWidgetPopup();
        winsetDimView.show();
        var bNeedDelay = this.destroyNavigatePopup();
        if (bNeedDelay) {
            Volt.log('[commonWidgetPopup.js] bNeedDelay == true');
            var ErrorSelf = this;
            Volt.setTimeout(function () {
                ErrorSelf.showMessagePopupView(messageId, params);
            }, 200);

        } else {
            Volt.log('[commonWidgetPopup.js] bNeedDelay == false');
            this.showMessagePopupView(messageId, params);
        }
    },

    showMessagePopupView: function (messageId, params) {
        Volt.log('[commonWidgetPopup.js] showMessagePopupView');
        switch (messageId) {
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_MEMORY_FULL_CONNECT_USB_INSTALL:
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_MEMORY_FULL_CONNECT_USB_INSTALL,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResoultionStyle: (Volt.APPS720P) ? winsetMessageBox.ResoultionStyle.Resoultion_720 : winsetMessageBox.ResoultionStyle.Resoultion_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('COM_SID_MEMORY_FULL_CONNECT_USB_INSTALL'),
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
            };
            message_Box.show(param); /**** switch to halo component****/
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_FAIL_TO_UNINSTALL:
			print("CommonDefines.MsgBoxType.MSGBOX_TYPE_FAIL_TO_UNINSTALL");
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_FAIL_TO_UNINSTALL,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResoultionStyle: (Volt.APPS720P) ? winsetMessageBox.ResoultionStyle.Resoultion_720 : winsetMessageBox.ResoultionStyle.Resoultion_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: 'Failed to delete.',
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
            };
            message_Box.show(param); /**** switch to halo component****/
            break;

        case CommonDefines.MsgBoxType.MSGBOX_TYPE_APPSYNC_NOT_COMPLETE:
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_APPSYNC_NOT_COMPLETE,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResoultionStyle: (Volt.APPS720P) ? winsetMessageBox.ResoultionStyle.Resoultion_720 : winsetMessageBox.ResoultionStyle.Resoultion_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('TV_SID_PREPARING_TV_TRY_AGAIN'),
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
            };
            message_Box.show(param); /**** switch to halo component****/

            break;

        case CommonDefines.MsgBoxType.MSGBOX_TYPE_DLD_BEFORE_RATE:
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_DLD_BEFORE_RATE,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_NoTitle_Button_2_8Line,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResoultionStyle: (Volt.APPS720P) ? winsetMessageBox.ResoultionStyle.Resoultion_720 : winsetMessageBox.ResoultionStyle.Resoultion_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('COM_SID_MUST_DOWNLOAD_APP_RATING'),
                button1Text: Volt.i18n.t('COM_SID_DOWNLOAD'),
                button2Text: Volt.i18n.t('COM_SID_CANCEL'),
                contextLineNumber: 1,
                prePage: '',
            };
            message_Box.show(param); /**** switch to halo component****/
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_LATEST_VERSIONS_OF_ALL_APPS:
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_LATEST_VERSIONS_OF_ALL_APPS,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResoultionStyle: (Volt.APPS720P) ? winsetMessageBox.ResoultionStyle.Resoultion_720 : winsetMessageBox.ResoultionStyle.Resoultion_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('COM_TV_SID_YOU_HAVE_LATEST_VERSIONS_OF_ALL_APPS_MSG'),
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
            };
            message_Box.show(param); /**** switch to halo component****/
            break;

        case CommonDefines.MsgBoxType.MSGBOX_TYPE_RATEING:
            Volt.log('[common-content.js]showRatingPopup, params = ' + params);
            EventMediator.on(CommonDefines.Event.CLOSE_RATING_POPUP, this.destroyRatingPopup);
            ratingPopup = Volt.require('lib/views/rating-popup.js');
            ratingPopup.show(params);
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_DELETE:
                    Volt.log('[common-content.js]showDeletingPopup, params = ' + params);
                    EventMediator.on(CommonDefines.Event.CLOSE_DELETING_POPUP, this.destroyDeletingPopup);
                    deletingPopup = Volt.require('app/views/delete-popup.js');
                    print('myAppsVMcollection.js deleteApps'+ params);
                    deletingPopup.show(params);
                    break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_PIN:
            //EventMediator.on(CommonDefines.Event.CLOSE_RATING_POPUP, this.destroyRatingPopup);
            PinPopup = Volt.require('lib/views/pin-popup.js');
            PinPopup.show(params);
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_OPTIONMENU:
            optionMenuPopup = Volt.require('lib/views/option-menu-popup.js');
            optionMenuPopup.show(params);
            var Models = Volt.require("app/models/models.js");
            Models.updateAppsCollection.fetch();
            if (Models.updateAppsCollection.length == 0) {
                optionMenuPopup.dimListItem(2);
            }
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_CONTEXTMENU:
            ContextMenuPopup = Volt.require('app/views/contextMenuPopup.js');
            ContextMenuPopup.show(params);
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_SERVER_ERROR_GUIDE:
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_SERVER_ERROR_GUIDE,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResoultionStyle: (Volt.APPS720P) ? winsetMessageBox.ResoultionStyle.Resoultion_720 : winsetMessageBox.ResoultionStyle.Resoultion_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: params.message + '(' + params.code + ')',
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
            };
            message_Box.show(param);
            break;
        case CommonDefines.MsgBoxType.TYPE_DELETE_MY_APPS:
            var param = {
                type: CommonDefines.MsgBoxType.TYPE_DELETE_MY_APPS,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_NoTitle_Button_1Line,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResoultionStyle: (Volt.APPS720P) ? winsetMessageBox.ResoultionStyle.Resoultion_720 : winsetMessageBox.ResoultionStyle.Resoultion_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('TV_SID_DELETE_SELECTED_ITEMS_QUES'),
                button1Text: Volt.i18n.t('COM_SID_YES'),
                button2Text: Volt.i18n.t('COM_SID_NO'),
                contextLineNumber: 1,
                prePage: '',
                defaultfocus: "button_2",
            };
            param.appID = params;
            print("param.appID = params:" + param.appID);
            message_Box.show(param);
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_SETHEADER_ERROR:
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_SETHEADER_ERROR,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResoultionStyle: (Volt.APPS720P) ? winsetMessageBox.ResoultionStyle.Resoultion_720 : winsetMessageBox.ResoultionStyle.Resoultion_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('TV_SID_MIX_UABLE_CONNECT_SAMSUNG_SERVER').replace('<<A>>', '(' + params.code + ')'),
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
            };
            message_Box.show(param);
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_DEVELOP:
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_DEVELOP,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResoultionStyle: (Volt.APPS720P) ? winsetMessageBox.ResoultionStyle.Resoultion_720 : winsetMessageBox.ResoultionStyle.Resoultion_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: params.message,
                button1Text: Volt.i18n.t('COM_SID_CLOSE'),
                contextLineNumber: 1,
                prePage: '',
            };
            message_Box.show(param);
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_SMARTHUB_INFO:
            Volt.log('commonWidgetPopup.js: getDebugInfo is ' + JSON.stringify(voltapi.WAS.getDebugInfo()));
            var debugInfo = voltapi.WAS.getDebugInfo();
            var smartHubInfo = '"apps_db_status":' + debugInfo.apps_db_status + ', "category_type":' + debugInfo.category_type + ', "chip_info":' + debugInfo.chip_info + '\n' + '"country":' + debugInfo.country + ', "lineup_model":' + debugInfo.lineup_model + ', "local_set":' + debugInfo.local_set + '\n' + '"model_id":' + debugInfo.model_id + ', "networks_status:' + debugInfo.networks_status + ', "product_type":' + debugInfo.product_type + '\n' + '"sef_version":' + debugInfo.sef_version + ', "server_type":' + debugInfo.server_type + ', "sync_status":' + debugInfo.sync_status + '\n' + '"wp_baseline":' + debugInfo.wp_baseline + ', "mac_addr":' + debugInfo.mac_addr + '\n' + '"hubsite_status":' + debugInfo.hubsite_status + ', "duid":' + debugInfo.duid + '\n' + '"firmware_version":' + debugInfo.firmware_version + ', "manager_status":' + debugInfo.manager_status + '\n' + '"local_time":' + debugInfo.local_time;
            Volt.log('commonWidgetPopup.js: smartHub information is ' + smartHubInfo);
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_SMARTHUB_INFO,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResoultionStyle: (Volt.APPS720P) ? winsetMessageBox.ResoultionStyle.Resoultion_720 : winsetMessageBox.ResoultionStyle.Resoultion_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: smartHubInfo,
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
            };
            message_Box.show(param); /**** switch to halo component****/
            break;
        case CommonDefines.MsgBoxType.TYPE_NETWORK:
            var param = {
                type: CommonDefines.MsgBoxType.TYPE_NETWORK,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_NoTitle_Button_2_8Line,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResoultionStyle: (Volt.APPS720P) ? winsetMessageBox.ResoultionStyle.Resoultion_720 : winsetMessageBox.ResoultionStyle.Resoultion_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('TV_SID_NOT_CONNECTED_INTERNET_REQUIRES_NETWORK'),
                //button_1_Text:'Troubleshoot',
                button1Text: Volt.i18n.t('COM_TV_SID_NETWORK_STATUS'),
                button2Text: Volt.i18n.t('COM_SID_CANCEL'),
                contextLineNumber: 1,
                prePage: '',
            };
            // print("Volt.i18n.t('COM_TV_SID_NETWORK_STATUS')"+Volt.i18n.t('COM_TV_SID_NETWORK_STATUS'));
            message_Box.show(param); /**** switch to halo component****/
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_FAIL_DOWNLOAD:
			if (CommonDefines.AppState.APP_STATE_DEACTIVATE == CommonFunctions.getAppState()){
	            Volt.log('[commonWidgetPopup.js] now app status is APP_STATE_DEACTIVATE, do not show this messagepopup');
				return false;
			}
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_FAIL_DOWNLOAD,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResoultionStyle: (Volt.APPS720P) ? winsetMessageBox.ResoultionStyle.Resoultion_720 : winsetMessageBox.ResoultionStyle.Resoultion_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('TV_SID_MIX_FAILED_TO_DOWNLOAD').replace('<<A>>', 'Code: ' + params),
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
                defaultfocus: "button_1",
            };
            message_Box.show(param);
            break;
	  case CommonDefines.Magic.SHOW_VERSION:
               getConfigXML().then(function(configXML){
                    var param = {
			     type: CommonDefines.Magic.SHOW_VERSION,
                        style : winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                        buttonStyle : winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                        bgStyle : winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                        contentText : configXML.widget.ver,
                        button : true,
                        button_1_Text : Volt.i18n.t('COM_SID_OK'),
                        contextLineNumber : 1,
                        focusIndex : 1,
                    };
			 message_Box.show(param);
                });   
            break;
        default:
            Volt.log('message-id:::' + messageId);
            winsetDimView.hide();
            break;
        }
    },
    destroyRatingPopup: function () {
        Volt.log('[commonWidgetPopup.js]destroyRatingPopup');
        EventMediator.off(CommonDefines.Event.CLOSE_RATING_POPUP, this.destroyRatingPopup);
        if (ratingPopup != null) {
            ratingPopup.hide();
            ratingPopup = null;
        }
        winsetDimView.hide();
    },
    destroyDeletingPopup: function () {
        Volt.log('[commonWidgetPopup.js]destroyDeletingPopup');
        EventMediator.off(CommonDefines.Event.CLOSE_DELETING_POPUP);
        if (deletingPopup != null) {
            deletingPopup.hide();
            deletingPopup = null;
        }
        winsetDimView.hide();
    },
    destroyWidgetPopup: function () { //destroy all widget type popups
        EventMediator.trigger(CommonDefines.Event.EVENT_CLOSE_POPUP);
    },

    destroyNavigatePopup: function () {
        return false;
    },
};
var getConfigXML = function(){
        Volt.log('[commonWidgetPopup.js] getConfigXML configXML = ' + configXML);
        var deferred = Q.defer();
        if(configXML == null) {
	      Volt.log('[commonWidgetPopup.js] getConfigXML configXML11111111111111');
            var configPath = Volt.getRemoteUrl('config.xml');
            _XMLToJSON(configPath).then(function(obj){
                configXML = obj;
                deferred.resolve(obj);
            });
	     Volt.log('[commonWidgetPopup.js] getConfigXML configXML222222');
        } else {
            deferred.resolve(configXML);
        }
        return deferred.promise;
};
    
var _XMLToJSON = function(xmlFileUrl){
    Volt.log('[commonWidgetPopup.js] _XMLToJSON ..... url = ' + xmlFileUrl);
    var deferred = Q.defer();
    var resourceRequest = new ResourceRequest(xmlFileUrl);
    resourceRequest.method = 'GET';
    resourceRequest.async = true;
    resourceRequest.success = function (data, textStatus, xhr) {
        _parseConfig(data)
        .then(function (obj) {
            deferred.resolve(obj);
        })
        .fail(function (err) {
            deferred.reject(err);
        });
    };
    resourceRequest.error = function (xhr, textStatus, errorStr) {
        deferred.reject(errorStr);
    };
    resourceRequest.process();
    return deferred.promise;
};

var _parseConfig = function(data){
Volt.log('[commonWidgetPopup.js] _parseConfig ..... data = ' + data);
var xmlString = data.replace("\ufeff", "");
var deferred = Q.defer();
var xml = Volt.require('modules/SaxParser.js');
var obj = {};
var currentTag = null;
var parser = new xml.SaxParser(function(cb){
    cb.onEndDocument(function () {
        Volt.log("[commonWidgetPopup.js] onEndDocument obj = " + JSON.stringify(obj));
        deferred.resolve(obj);
    });
    cb.onStartElementNS(function (elem) {
        if(elem == "_name" || elem == "_parent" || elem == "_value"){
            Volt.log("[commonWidgetPopup.js] XXXXXXXXXXXXXXX onStartElementNS used keyword = " + elem);
            return;
        }
        var tag = {
            _name : elem,
            _parent : currentTag
        };
        currentTag = tag;
    });
    cb.onCharacters(function(value){
        if(currentTag && value.indexOf('\n') !== 0) {
            currentTag._value = value;
        } else {
            Volt.log("[commonWidgetPopup.js] onCharacters Invalid Value:" + JSON.stringify(arguments));
        }
    });
    cb.onEndElementNS(function (elem) {
        if(elem == "_name" || elem == "_parent" || elem == "_value"){
            Volt.log("[commonWidgetPopup.js] XXXXXXXXXXXXXXX onStartElementNS used keyword = " + elem);
            return;
        }
        if(currentTag && currentTag._parent) {
            if(currentTag._value) {
                currentTag._parent[currentTag._name] = currentTag._value;
            } else {
                currentTag._parent[currentTag._name] = currentTag;
                delete currentTag._name;
            }
            var p = currentTag._parent;
            delete currentTag._parent;
            currentTag = p;
        } else {
            obj[currentTag._name] = currentTag;
            delete currentTag._name;
            delete currentTag._parent;
        }
    });
    cb.onError(function (msg) {
        deferred.reject(msg);
    });
});
    parser.parseString(xmlString);
    return deferred.promise;
}

exports = commonWidgetPopup;