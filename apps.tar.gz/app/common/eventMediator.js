 /** 
 * @author donghyun Lee (donghyun81.lee@samsung.com)
 * @fileoverview This module manages event mediator.
 * @date    2014/07/03 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._;

/** 
 * EventMediator is a global backbone event handler
 * @class EventMediator
 */
EventMediator = _.extend({}, Backbone.Events);

exports = EventMediator;