 /** 
 * @author hyoseon Ju (hyoseon.ju@samsung.com)
 * @fileoverview This module requests to Apps Store Server for receiving data.
 * @date    2014/07/18 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var Backbone = Volt.require('lib/volt-backbone.js');
var Q = Volt.require("modules/q.js");
var _ = Volt.require("modules/underscore.js")._;
//var DeviceInfoModel = Volt.require('app/models/deviceInfoModel.js');
var CommonDefines = Volt.require('app/common/commonDefines.js'),
    voltapi = Volt.require('$VOLT_ROOT/modules/voltapi.js'),
    EventMediator = Volt.require('app/common/eventMediator.js');

var oGlobalParams = {
    modelid: '14_GOLFP', // 13_FOXP
    countrycode: 'US',
    lang: 'en', // en
    resolution: '1080',
    firmcode: 'T-INFOLINK2014-1000', // 
    timestamp: '' // 1378895947 // second
};

/** 
 * ServerAPI is Module for accessing to Server
 * @class ServerAPI
 */
var ServerAPI = {
    initFlag:false,
    /**
     * Initialize ServerAPI
     * @method
     * @memberof ServerAPI
     * @param {object} options It is needed for options for accessing server.
     * @example 
     * ServerAPI.initialize();
     */
    initialize: function(options) {

        Volt.log('[ServerAPI] initialize()');

        // REST_HEADER_STATUS:{
        //     PARAMETER_ERROR:0,
        //     SUCCESS:1,
        //     FAIL_A_TOKEN:2,
        //     FAIL_USER_TOKEN:3,
        //     FAIL_DUID:4,
        //     FAIL_SW_VERSION:5,
        //     FAIL_INFOLINK_VERSION:6,
        //     FAIL_GPM_URL:7,
        //     UNKNOWN:999
        // }
        this.REST_HEADER_STATUS = 1;

        EventMediator.on(CommonDefines.Event.DEVICE_INFO_READY, this.setGlobalParams, this);

        if (Volt.browser) {
        //
        } else {
            if (false === voltapi.rest.isOpened()) {
                voltapi.rest.init();
            }
            
            var ret = voltapi.rest.setSmartTVHeader(true);
            Volt.err('[ServerAPI] setSmartTVHeader Value :::: ' + ret);
            voltapi.rest.setHeader('SmartTVClient', 'Apps/1.0');
            
            if (ret != 1) {
                this.REST_HEADER_STATUS = ret;
                Volt.DeviceInfoModel.set('restHeaderStatus', ret);
            } 
        }
    },


    /**
     * setGlobalParameters when initialize ServerAPI
     * @method
     * @memberof ServerAPI
     * @example 
     * this.listenTo( DeviceInfoModel.updateInfoFromWAS,'change', this.setGlobalParams() ));
     */
    setGlobalParams: function() {

        Volt.log('[ServerAPI] setGlobalParams()');

        oGlobalParams = _.extend(oGlobalParams, {
            modelid: Volt.DeviceInfoModel.get('modelId'),
            countrycode: Volt.DeviceInfoModel.get('countryCode'),
            lang: Volt.DeviceInfoModel.getLanguageCode(),
            resolution: Volt.DeviceInfoModel.get('resolution'),
            firmcode: Volt.DeviceInfoModel.get('firmwareVersion')
        });
	 this.initFlag = true;
    },

    /**
     * Requests Categories data to Apps Store Server.
     * @method
     * @memberof ServerAPI
     * @param {object} options 
     * @param {function} options.success A function to be called if the request succeeds.
     * @param {function} options.error A function to be called if the request fails.
     * @param {function} options.complete A function to be called if the request completes.
     */
    getCategoryList: function (options) {
        
        // options : { 
        //      success:
        //      error:
        //      complete:
        // }

        Volt.log('[ServerAPI] getCategoryList()');

        var opts = {
            success: options.success,
            error: options.error,
            complete: options.complete || null
        };

        return call({
            type: 'GET',
            url: 'apps/store/v3/categories'
        }, opts);
    },

    /**
     * Requests Categories App Lists data to Apps Store Server.
     * @method
     * @memberof ServerAPI
     * @param {object} options
     * @param {object} options.id The object is used the url to request to Server.
     * @param {object} options.param The object has parameters for request to Server.
     * @param {string} options.param.perpage This param is the number of apps the server gives.
     * @param {string} options.param.sort This param gives how to sort to Server.
     * @param {string} options.param.page This param gives the number of pages to Server.
     * @param {function} options.success A function to be called if the request succeeds.
     * @param {function} options.error A function to be called if the request fails.
     * @param {function} options.complete A function to be called if the request completes.
     */
    getCategoryAppList: function (options) {
        Volt.log('[ServerAPI] getCategoryAppList()');

        var opts = {
            param: {
                perpage: (options.param && options.param.perPage) || 30,
                sort: (options.param && options.param.sort) || 'releasedate', // default : releasedate | popularity, titleasc, titledesc
                page: (options.param && options.param.page) || '1' // 1
            },
            success: options.success,
            error: options.error,
            complete: options.complete || null
        };

        return call({
            type: 'GET',
            url: 'apps/store/v3/categories/' +options.id + '/apps'
        }, opts);
    },

    /**
     * Requests MostPopular App Lists data to Apps Store Server.
     * @method
     * @memberof ServerAPI
     * @param {object} options
     * @param {object} options.param The object has parameters for request to Server.
     * @param {string} options.param.perpage This param is the number of apps the server gives.
     * @param {function} options.success A function to be called if the request succeeds.
     * @param {function} options.error A function to be called if the request fails.
     * @param {function} options.complete A function to be called if the request completes.
     */
    getMostPopular :function(options){

        Volt.log('[ServerAPI] getMostPopular()');

        var opts = {
            param : {
                perpage: (options.param && options.param.perpage) || 12
            },
            success: options.success,
            error: options.error,
            complete: options.complete || null
        };

        return call({
            type: 'GET',
            url: 'apps/store/v3/mostpopular'
        }, opts);
    },

    /**
     * Requests What's New App Lists data to Apps Store Server.
     * @method
     * @memberof ServerAPI
     * @param {object} options
     * @param {object} options.param The object has parameters for request to Server.
     * @param {string} options.param.perpage This param is the number of apps the server gives.
     * @param {function} options.success A function to be called if the request succeeds.
     * @param {function} options.error A function to be called if the request fails.
     * @param {function} options.complete A function to be called if the request completes.
     */
    getWhatsNew: function(options){

        Volt.log('[ServerAPI] getWhatsNew()');

        var opts = {
            param : {
                perPage: (options.param && options.param.perpage) || 12
            },
            success: options.success,
            error: options.error,
            complete: options.complete || null
        };

        return call({
            type: 'GET',
            url: 'apps/store/v3/whatsnew'
        }, opts);
    },

    /**
     * Requests What's New App Lists data to Apps Store Server.
     * @method
     * @memberof ServerAPI
     * @param {object} options
     * @param {object} options.param The object has parameters for request to Server.
     * @param {string} options.param.perpage This param is the number of apps the server gives.
     * @param {function} options.success A function to be called if the request succeeds.
     * @param {function} options.error A function to be called if the request fails.
     * @param {function} options.complete A function to be called if the request completes.
     */
    getEvent: function(options){

        Volt.log('[ServerAPI] getEvent()');

        var opts = {
            param : {
                perPage: (options.param && options.param.perpage) || 12
            },
            success: options.success,
            error: options.error,
            complete: options.complete || null
        };

        return call({
            type: 'GET',
            url: '/apps/store/v1/event'
        }, opts);
    },

    /**
     * Requests App's Detail data to Apps Store Server.
     * @method
     * @memberof ServerAPI
     * @param {object} options
     * @param {object} options.path The object has parameters for request to Server.
     * @param {string} options.path.id This param is used the url to request the server.
     * @param {function} options.success A function to be called if the request succeeds.
     * @param {function} options.error A function to be called if the request fails.
     * @param {function} options.complete A function to be called if the request completes.
     */
    getAppDetail: function(options){
        Volt.log('[ServerAPI] getAppDetail()');

        var opts = {
            success: options.success,
            error: options.error,
            complete: options.complete || null
        };

        return call({
            type: 'GET',
            url: 'apps/store/v3/apps/' + options.path.appId
        }, opts);
    },

    /**
     * Requests User's Rating data to Apps Store Server.
     * @method
     * @memberof ServerAPI
     * @param {object} options
     * @param {object} options.param The object has parameters for request to Server.
     * @param {string} options.param.rate This param is the rates of app user sets.
     * @param {string} options.path.id This param is used the url to request the server.
     * @param {function} options.success A function to be called if the request succeeds.
     * @param {function} options.error A function to be called if the request fails.
     * @param {function} options.complete A function to be called if the request completes.
     */
    putAppGradePoint: function(options){
        Volt.log('[ServerAPI] putAppGradePoint()');

        var opts = {
                param: {
                    rate: (options.param && options.param.rate) || 3
                },
                success: options.success,
                error: options.error,
                complete: options.complete || null
            };

        return call({
            type: 'POST',
            url: 'apps/store/v2/apps/' + options.path.appId.toString() +'/gradepoint'
        }, opts);
    },
    
    getServiceInitFlag: function(){
        return this.initFlag;
    }
};

exports = ServerAPI;

function call (requestInfo, options) {
    Volt.log('[ServerAPI] call() [' + requestInfo.type + '] ' + requestInfo.url);
    
    // requestInfo: {
    //     type
    //     url
    // }
    // options: {
    //     param: {
    //         prop: value
    //     },
    //     success
    //     error
    // }

    var self = this;

    var dNow = new Date(),
        nEpochMs = (dNow.getFullYear() != 1970) ? dNow.getTime() : (new Date('2014-01-01')).getTime(),
        sURL = requestInfo.url,
        sParamValue = makeQueryString(_.extend({}, oGlobalParams, options.param, {timestamp: parseInt(nEpochMs)})),
        param = (requestInfo.type == 'GET' ? _.extend({}, oGlobalParams, options.param, {timestamp: parseInt(nEpochMs)}) : {timestamp: parseInt(nEpochMs)}),
        onSuccess = options.success,
        onError = options.error,
        onComplete = options.complete;

    if (requestInfo.type == 'POST') {

        var oParam = {
            "gradePoint": options.param.rate.toString(),
            "countryCode": oGlobalParams.countrycode.toString(),
            "modelId": oGlobalParams.modelid.toString(),
            "lang": oGlobalParams.lang.toString(),
            "firmCode": oGlobalParams.firmcode.toString()
        };      
        var sValue = JSON.stringify(oParam);
        Volt.err(sValue);            
    }

    Volt.err('[ServerAPI] sURL : ' + sURL);

    if (false === voltapi.rest.isOpened()) {
        voltapi.rest.init();
        var ret = voltapi.rest.setSmartTVHeader(true);
        if (ret != 1) {
            this.REST_HEADER_STATUS = ret;
            EventMediator.trigger('REST_SETHEADER_FAIL', this.REST_HEADER_STATUS);
        } else {
            voltapi.rest.setHeader('SmartTVClient', 'SamsungApps/6.1');
        }
    }

    voltapi.rest.clearParam();
    voltapi.rest.clearBody();

    if (sValue) {
        voltapi.rest.setBody(sValue);
    }

    for (var key in param){
        Volt.err('[ServerAPI] !param! ' + key + ':::' + param[key]);
        voltapi.rest.setParam(key, param[key].toString());
    }
    
    voltapi.rest.sendAsync(requestInfo.type, requestInfo.url,
    function successCallback (data, status, response) {
        try {            
            var jsonData = JSON.parse(data).rsp;
            
            Volt.err('[ServerAPI] success Callback  ' + jsonData.stat);

            if (jsonData.stat =='ok') {
                onSuccess(JSON.stringify(jsonData), status, response);
            } else {
                Volt.err(jsonData.stat);
                
                iServerError =  getServerError({
                    xhrStatus : status || 'UNEXPECTED',
                    code : jsonData.err.code || 'UNEXPECTED',
                    message: jsonData.err.msg || 'UNEXPECTED'
                });

                Volt.err('[ServerAPI] !ERROR CODE! [' + jsonData.err.code + '] ');
                Volt.err('[ServerAPI] !ERROR MSG! [' + jsonData.err.msg + '] ');
                Volt.err('[ServerAPI] !textStatus! ' + xhrStatus );

                onError(iServerError);
            }
        } catch (e) {
            iServerError =  getServerError({
                xhrStatus : status || 'UNEXPECTED',
                code : 'UNEXPECTED',
                message: 'UNEXPECTED'
            });

            Volt.err('[ServerAPI] !ERROR CODE! [' + e + '] ');
            Volt.err('[ServerAPI] !textStatus! ' + status );

            onError(iServerError);
        } finally {

        }
    }, 
    function errorCallback(oError) {
        try {
            var iServerError = null,
                xhrStatus = oError ? oError.status : 0,
                jsonErrorData = oError.data ? JSON.parse(oError.data).rsp : null;

            switch (xhrStatus) {
                case 400:
                case 401:
                case 403:
                case 404:
                case 405:
                case 406:
                case 408:
                case 409:
                case 500:
                case 503:
                    iServerError = getServerError({
                        xhrStatus : xhrStatus,
                        code : jsonErrorData.err.code || 'UNEXPECTED',
                        message: jsonErrorData.err.msg || 'UNEXPECTED'
                    });
                    break;
                case 0:
                    iServerError = getServerError({
                        xhrStatus : xhrStatus,
                        code : 'NONNETWORK',
                        message: 'NONNETWORK'
                    });
                    break;
                default :
                    iServerError =  getServerError({
                        xhrStatus : 'UNEXPECTED',
                        code : 'UNEXPECTED',
                        message: 'UNEXPECTED'
                    });
                    break;
            }
            Volt.err('[ServerAPI] !ERROR CODE! [' + jsonErrorData.err.code + '] ');
            Volt.err('[ServerAPI] !ERROR MSG! [' + jsonErrorData.err.msg + '] ');
            Volt.err('[ServerAPI] !ERROR! [' + requestInfo.type + '] ' + sURL);
            Volt.err('[ServerAPI] !textStatus! ' + xhrStatus);
        } catch(e) {
            iServerError =  getServerError({
                xhrStatus : 'EXCEPTION',
                code : 'EXCEPTION',
                message: 'EXCEPTION'
            });
            Volt.err('[ServerAPI] !EXCEPTION! ' + e, 1);
        } finally {
            Volt.err(iServerError);
            onError(iServerError);
            onComplete();
        }
    }, 
    function completeCallback() {
        onComplete();
    }, 
    function readyCallback() {
        Volt.log('[ServerAPI.js] readyCallback');
    });
}

function makeQueryString(options) {
    
    Volt.log('[ServerAPI] makeQueryString()');
    var sQueryString = '', aQuery = [];
    
    for (var prop in options) {
        aQuery.push(prop + '=' + options[prop]);
    }
    sQueryString = aQuery.join('&');
    
    return encodeURI(sQueryString);
}

function ServerError (code, message) {
    this.code = code;
    this.message = message;
}

function getServerError(options) {

    // options: {
    //     type
    //     message
    // }
    
    var sErrorCode = '', sErrorMsg = '';

    switch (options.xhrStatus) {

        // Fail -> XHR Status
        case 400:
            sErrorCode ='AS400';
            sErrorMsg = Volt.i18n.t('TV_SID_MIX_UABLE_CONNECT_SAMSUNG_SERVER').replace('<<A>>', 'AS400');
            break;
        
        case 401:
            sErrorCode ='AS401';
            sErrorMsg = Volt.i18n.t('TV_SID_MIX_UABLE_CONNECT_SAMSUNG_SERVER').replace('<<A>>', 'AS401');
            break;

        case 403:
            sErrorCode ='AS403';
            sErrorMsg = Volt.i18n.t('TV_SID_MIX_UABLE_CONNECT_SAMSUNG_SERVER').replace('<<A>>', 'AS403');
            break;
        
        case 404:
            sErrorCode ='AS404';
            sErrorMsg = Volt.i18n.t('TV_SID_MIX_UABLE_CONNECT_SAMSUNG_SERVER').replace('<<A>>', 'AS404');
            break;

        case 405:
            sErrorCode ='AS405';
            sErrorMsg = Volt.i18n.t('TV_SID_MIX_UABLE_CONNECT_SAMSUNG_SERVER').replace('<<A>>', 'AS405');
            break;

        case 406:
            sErrorCode ='AS406';
            sErrorMsg = Volt.i18n.t('TV_SID_MIX_UABLE_CONNECT_SAMSUNG_SERVER').replace('<<A>>', 'AS406');
            break;

        case 408:
            sErrorCode ='AS408';
            sErrorMsg = Volt.i18n.t('TV_SID_MIX_UABLE_CONNECT_SAMSUNG_SERVER').replace('<<A>>', 'AS408');
            break;

        case 409:
            sErrorCode ='AS409';
            sErrorMsg = Volt.i18n.t('TV_SID_MIX_UABLE_CONNECT_SAMSUNG_SERVER').replace('<<A>>', 'AS409');
            break;
        
        case 500:
            sErrorCode ='AS500';
            sErrorMsg = Volt.i18n.t('TV_SID_MIX_SERVER_IS_UNDER_MAINTENANCE_ERROR_NO').replace('<<A>>', 'AS500');
            break;

        case 503:
            sErrorCode ='AS503';
            sErrorMsg = Volt.i18n.t('TV_SID_MIX_SERVER_IS_UNDER_MAINTENANCE_ERROR_NO').replace('<<A>>', 'AS503');
            break;

        case 0:
            sErrorCode = 'AS666';
            sErrorMsg = Volt.i18n.t('TV_SID_MIX_CONNECTED_FEATURE_NETWORK');
            break;

        case 'EXCEPTION':
            sErrorCode ='AS000';
            sErrorMsg = Volt.i18n.t('TV_SID_MIX_UNEXPECTED_PROBLEM_OCCURRED').replace('<<A>>', sErrorCode);
            break;

        case 'UNEXPECTED':
        default :
            sErrorCode = 'AS900';
            sErrorMsg = Volt.i18n.t('TV_SID_MIX_UNEXPECTED_PROBLEM_OCCURRED').replace('<<A>>', sErrorCode);
            break;
    }

    return new ServerError(sErrorCode, sErrorMsg);
}