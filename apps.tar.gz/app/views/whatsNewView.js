 /** 
 * @author youngil baek (yi01.baek@samsung.com)
 * @fileoverview WhatNewView
 * @date    2014/07/18 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js');
var FeaturedListView = Volt.require('app/views/featuredListView.js').listView;
var AppInfoView = Volt.require('app/views/featuredListView.js').appInfoView;
var FeaturedListTemplate = Volt.require('app/templates/1080/featuredListTemplate.js');
var _ = Volt.require("modules/underscore.js")._;
var voltapi = Volt.require('voltapi.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');
var localStorage = Volt.require("lib/volt-local-storage.js");
var EventMediator = Volt.require('app/common/eventMediator.js');
var CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');
var ServerAPI = Volt.require('app/common/serverAPI.js');
/**
 * @name WhatsNewView
 */
var WhatsNewView = FeaturedListView.extend({
	/** @lends WhatsNewView.prototype */
    featuredType : "whatsNew",
    isFirstFetch : true,

    /**
     * Initialize WhatsNewView
     * @name WhatsNewView
     * @constructs
     */
    initialize: function(){},

    setAppInfoView: function() {
        this.appInfoView = WhatsNewInfoView;
        this.piaView = PIAView;
    },

     fetch: function() {

         var cachingData = localStorage.getItem('apps-whatsnew-caching-data');
        
         if (!this.gridListView) {
             if (cachingData && cachingData.length > 0) {

                 Volt.err("[WhatsNewView.js] cacheData exists!!");
                 this.fetchCache();	 
                        
             }else{
                  Volt.err("[WhatsNewView.js] cachingData is empty!");
		     if(ServerAPI.getServiceInitFlag()){
			 Volt.err("[WhatsNewView.js] WAS ready");
			 this.fetchDatafromServer();
		     }else{
		          Volt.err("[WhatsNewView.js] WAS not ready");
                        this.listenTo(EventMediator, CommonDefines.Event.WAS_READY, this.fetchDatafromServer);
		     }
            }
        }
     },
    fetchDatafromServer: function() {
        Volt.err("[WhatsNewView.js] fetchDatafromServer");
        var restHeaderStatus = Volt.DeviceInfoModel.get('restHeaderStatus');
        if(restHeaderStatus !== 1 ){
            this.listenTo(EventMediator, CommonDefines.Event.MSGBOX_BUTTON,  this.processMsgBoxEvent, this);
            this.showFailRestHeaderPopup(restHeaderStatus);
            return;                    
        }
        EventMediator.trigger(CommonDefines.Event.EVENT_HOME_SHOW_LOADING);
         this.fetchServer();    
    },
	 
    showFailRestHeaderPopup: function(errCode){
        Volt.err('[WhatsNewView.js] showFailRestHeaderPopup:'+errCode);
        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_SETHEADER_ERROR, {code: errCode});
    },

    processMsgBoxEvent: function(data) {
        Volt.err('[WhatsNewView.js] processMsgBoxEvent:type is:', data.msgBoxtype + " eventType is:" + data.eventType);
        if(data.eventType == CommonDefines.Event.SELECT_BTN1) {
            switch(data.msgBoxtype) {
                case CommonDefines.MsgBoxType.MSGBOX_TYPE_SETHEADER_ERROR:
                    Volt.log('[WhatsNewView.js][MSGBOX_TYPE_SETHEADER_ERROR] , exit apps panel, apps panel will hide in background');
			Volt.exit();
			//Volt.quit();
                    break;
                default:
                    break;
                } 
        }
    },

});

var WhatsNewInfoView = AppInfoView.extend({   	

    extendData: function(mustache, data){
// 2012-12-26T10:47:00+09:00

        return _.extend(mustache, {
            variable: data.updated.slice(0,10)      
        });
    }

});

var PIAView = AppInfoView.extend({   

    imagepath : null,
    thumbnail : null,
    scrollMark : true,
    showFlag:false,
    thumb:null,

    initialize: function(model, type, thumbnail){
        this.VM = model;
		this.thumb = thumbnail;
	    if(ServerAPI.getServiceInitFlag()){
			 Volt.err("[WhatsNewView.js] PIAView:WAS ready");
			voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_AD_START, _.bind(this.startADCallback, this));
                     voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_AD_PLAY, _.bind(this.playADCallback, this));
          }else{
		         Volt.err("[WhatsNewView.js]PIAView: WAS not ready");
                        this.listenTo(EventMediator, CommonDefines.Event.WAS_READY, this.addAdListener);
	   }
	   this.listenTo(this.VM, 'DESTROY_VIEW', this.hideProgressBar);
    },
    
    render : function(index, iThumbnail, gridlist) {

        this.downloadable = false;
        if( iThumbnail ){
            this.thumbnail = iThumbnail;

            var thumbListener = new ThumbnailListener;
            this.thumbnail.setThumbnailStyle(FeaturedListTemplate.piainfo);
            this.thumbnail.addThumbnailListener(thumbListener);
            this.thumbnail.customTitle = "Advertising Banner Area";
            this.setWidget(this.thumbnail);

	      this.showProgressBar();
        }

    },
    addAdListener: function(){
        Volt.log('PIAView addAdListener()');
         voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_AD_START, _.bind(this.startADCallback, this));
         voltapi.WAS.addEventListener(CommonDefines.WAS.WAS_AD_PLAY, _.bind(this.playADCallback, this));
	  this.showProgressBar();
    },
    startADPlay: function(){
        Volt.log('PIAView updateItemView, startADPlay()');
        try{
            var ret = voltapi.WAS.startAD('0');
            Volt.err('PIAView startAD result : '+ ret);
        }catch(e){
            Volt.err('PIAView startAD error : '+ e);
        }  
    },

    stopADPlay: function(){
        Volt.log('PIAView updateItemView, stopADPlay()');
        try{
            var ret = voltapi.WAS.stopAD('0');
            Volt.err('PIAView stopAD result : '+ ret);
        }catch(e){
            Volt.err('PIAView stopAD error : '+ e);
        } 
    },

    updateItemView: function(Thumbnail,data){
        Volt.log('PIAView updateItemView ');
    },

    startADCallback : function(eventType, data1) {
        Volt.err('PIAView startADCallback : '+ JSON.stringify(data1));
        this.imagepath = JSON.parse(data1).result; 
        Volt.err('PIAView startADCallback : '+ this.imagepath);

        try{
            if(this.scrollMark){
                this.thumbnail.setScrollPlayerImage({
                    src2: this.imagepath,
                });
                this.scrollMark = false;
            }
            else{
                this.thumbnail.setScrollPlayerImage({
                    src1: this.imagepath,
                });
                this.scrollMark = true;
            }
            this.thumbnail.scrollImage();

            var imageWidget = new ImageWidgetEx({
                x:-Volt.width,
                y:-Volt.height,
                src:this.imagepath,
                parent: this.thumb
            })
            imageWidget.onReady = function (success) {
                var colorPicking = imageWidget.getColorPicking(100);
                
                this.thumbnail.color = {
                    r : colorPicking.color.r,
                    g : colorPicking.color.g,
                    b : colorPicking.color.b,
                    a : 255
                };
            }.bind(this)
        }catch(e){
            
        }
    },

    playADCallback : function(eventType, data1) {
        Volt.err('PIAView playADCallback : '+ JSON.stringify(data1)); 
        
        voltapi.WAS.notifyADServer('0', this.imagepath);
    },

    onSelect : function(index){
        Volt.err('PIAView onSelect : ' + this.imagepath);
        if(this.imagepath != null){
           var ret = voltapi.WAS.playAD('0', this.imagepath);      
           Volt.err('PIAView playAD result : '+ ret);
        }        
    },

    renderChange: function(changedModel){

    },

    hideProgressBar: function(){
         if(false == this.showFlag){
		return;
        }
        this.stopListening(EventMediator);
        this.stopADPlay();
	  this.showFlag = false;
    },

    showProgressBar: function(){
        if(true == this.showFlag){
		return;
        }
	  if(ServerAPI.getServiceInitFlag()){
               this.listenTo(EventMediator, 'VOLT_ACTIVATE', this.startADPlay);
               this.listenTo(EventMediator, 'VOLT_DEACTIVATE', this.stopADPlay);
               this.startADPlay();
       	  this.showFlag = true;
	  }
    }
}); 

exports = WhatsNewView;

