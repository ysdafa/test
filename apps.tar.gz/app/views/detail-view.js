/** 
 * @author hocheol lee (hocheol7.lee@opentide.com)
 * @fileoverview This module show app's detail information
 * @date    2014/07/21 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

////////////////////////////////////////////////////////////////////////////////
// REQUIRE MODULES
////////////////////////////////////////////////////////////////////////////////

//// Include Basic Modules
var Backbone = Volt.require("modules/backbone.js");
var _ = Volt.require("modules/underscore.js")._;
var VoltJSON = Volt.require("modules/VoltJSON.js");
var Q = Volt.require('modules/q.js');
var voltapi = Volt.require('voltapi.js');

//// Include UI-Components Modules
//var ProgressBarUI = Volt.require("UIElement/Progress.js"),
var WinsetBtn = Volt.require("WinsetUIElement/winsetButton.js");
var WinsetBg = Volt.require("WinsetUIElement/winsetBackground.js");
var WinsetScroll = Volt.require("WinsetUIElement/winsetScroll.js");
var WinsetProgress = Volt.require('WinsetUIElement/winsetProgress.js');
var WinsetToolTip = Volt.require('WinsetUIElement/winsetToolTip.js');
var WinsetLoading = Volt.require('WinsetUIElement/winsetLoading.js');

//// Require Lib
var PanelCommon = Volt.require('lib/panel-common.js');

var DimView = Volt.require("lib/views/dim-view.js");
var loadingPopup = Volt.require("lib/views/loading-popup.js");
var CmButtonView = Volt.require('lib/views/cm-button-view.js');

//// Include View Models
var DeviceInfoModel = Volt.require("app/models/deviceInfoModel.js");
var Models = Volt.require('app/models/models.js'),
    DetailVM = Volt.require("app/models/detailVM.js");

//// Include Templates
//var Template = Volt.require("app/templates/1080/detailTemplate.js");
var Template = Volt.require("app/templates/detail-template.js");

//// Include Common Views
var GridListView = Volt.require('app/views/gridListView.js'),
    ProgressBarView = Volt.require('app/views/progressbarView.js'),
    AppInfoProgressView = Volt.require("app/views/appInfoProgressView.js"),

    //// Include Commons
    EventMediator = Volt.require('app/common/eventMediator.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    CommonFunctions = Volt.require('app/common/commonFunctions.js');

var AppInstallMgr = Volt.require("app/common/appInstallMgr.js"),
    DownloadedAppsMgr = Volt.require("app/common/downloadedAppsMgr.js"),
    CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');

var GridListTemplate = Volt.require('app/templates/grid-list-template.js');

////////////////////////////////////////////////////////////////////////////////
// PREPARATIONS
////////////////////////////////////////////////////////////////////////////////

// Map Widgets
PanelCommon.mapWidget('WinsetBtn', WinsetBtn);
PanelCommon.mapWidget('WinsetBg', WinsetBg);
PanelCommon.mapWidget('WinsetScroll', WinsetScroll);
Volt.mapWidget('WinsetProgress', WinsetProgress);
Volt.mapWidget('WinsetToolTip', WinsetToolTip);
Volt.mapWidget('WinsetLoading', WinsetLoading);

////////////////////////////////////////////////////////////////////////////////
// GLOBALS
////////////////////////////////////////////////////////////////////////////////

var tvResoultion = (Volt.APPS720P) ? WinsetBtn.ResoultionStyle.Resoultion_720 : WinsetBtn.ResoultionStyle.Resoultion_1080;

var MAX_RATING_NUM = 5;

var Createflag = false;

/**
 * @name DetailView
 */
var DetailView = Volt.BaseView.extend({
    /** @lends DetailView.prototype */
    template: Template.container,

    pickedColor: null, //// Picked Color from Icon

    subViewMap: null, //// Map of Sub View Classes

    viewList: null,
    bLoading: false,
    screenShotViewShow: false,

    ////////////////////////////////////
    // Public Functions
    ////////////////////////////////////

    /**
     * Initialize DetailView
     * @name DetailView
     * @constructs
     */
    initialize: function () {
        Volt.log("[DetailView.js] initialize");
        detailview = this;

        //// Init Map of Sub View Classes
        this.subViewMap = {
            AppInfo: AppInfoView,
            StorageInfo: StorageInfoView,
            Description: DescriptionView,
            Buttons: ButtonsView
        };
    },

    /**
     * To request server fetch
     * @method
     * @memberof DetailView
     * @param  {string}  viewInfo  Widget ID
     */
    show: function (viewInfo, animationType) {
        Volt.log("[DetailView.js] show(), viewInfo: " + JSON.stringify(viewInfo));
        Volt.log(Createflag + "******************************************************");

        ////
        Volt.Nav.reset();

        //// If we have showed, return
        if (Createflag) {
            /***fix bug tempory**/
            return;
        }

        //// show apps panel, request from Volt UIFW
        Stage.show();

        //// Action s1: Init this.widget
        // Load from template
        this.setWidget(Volt.loadTemplate(this.template, {
            highconstract: DeviceInfoModel.get('highContrast') || '0'
        }));

        //// Action s2: Set the flag
        Createflag = true;

        this.widget.show();
        this.widget._navOnKeyEvent = _.bind(this._onkeyEvent, this);

        // Only consider requested detail by SearchAll
        var bRequestedSearchAll = viewInfo && viewInfo.caller;
        DetailVM.setDefault(bRequestedSearchAll);

        //// Action s3: Add Event Listeners and start listening
        this.addListeners();

        //// Action s4: Check network state and fetch data
        if (Volt.DeviceInfoModel.get('networksStatus') == 'OK') {

            var restHeaderStatus = Volt.DeviceInfoModel.get('restHeaderStatus');

            if (restHeaderStatus !== 1) {
                this.listenTo(EventMediator, CommonDefines.Event.MSGBOX_BUTTON, this.msgBoxEvent, this);
                this.showFailRestHeaderPopup(restHeaderStatus);
                return;
            }

            //this.showLoading();
            loadingPopup.show();
            if (Backbone.history.isHistoryBack) {
                if (!DetailVM.pullCachedData(viewInfo.id)) {
                    DetailVM.fetch(viewInfo.id);
                }
            } else {
                DetailVM.fetch(viewInfo.id);
            }
        } else {
            //var networkPopup = new MsgPopupView({type: CommonDefines.Popup.TYPE_NETWORK});
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
        }

        Volt.Nav.setRoot(this.widget);
        //deferred.resolve();
        //return deferred.promise;
    },

    /**
     * When hide view, handle stop event listening and hided view
     * @method
     * @memberof DetailView
     */
    hide: function () {
        Volt.log("[DetailView.js] hide ");

        ////
        Volt.Nav.reset();

        //// Remove everything in hide
        this.remove();

        // @xj-2014/12/20: Someone removed the Q.defer
        // var deferred = Q.defer();
        //deferred.resolve();
        //return deferred.promise;
    },

    /**
     * To request server fetch
     * @method
     * @memberof DetailView
     * @param  {string}  viewInfo  Widget ID
     */
    render: function () {
        Volt.log("[DetailView.js] render ");
    },

    /**
     * Destroy everything created in this view
     * @method
     * @memberof DetailView
     */
    remove: function () {
        try {
            //// Move focus out
            Volt.Nav.focus(null);

            // TODO: Check if we should cancel fetch in Action 4

            //// Action 3: Remove Event Listeners
            this.removeListeners();

            //// Action x: Remove View
            // Opposite of renderView
            this.removeView();

            //// Remove Related Apps View
            for (var i in this.viewList) {
                this.viewList[i].remove();
            }
            //// Action: Destroy this.widget
            this.widget.destroy();
            this.widget = null;

            // Action : Clear the flag
            Createflag = false;

        } catch (e) {
            Volt.log('[detail-view] hide(), occured exception: ' + e);
        }
    },

    /**
     * Pause this view.
     * @method
     */
    pause: function () {
        Volt.log('[DetailView] pause');
        // DetailVM.stopListening();
        this.hideLoading();
        //this.widget.hide();
        Volt.Nav.pause();
        this.listenTo(EventMediator, 'VOLT_RESUME', this.resume);
    },

    /**
     * When returned focus from popup, it reset focus.
     * @method
     * @memberof DetailView
     */
    resume: function () {
        Volt.log("[DetailView.js] resume ");
        //DetailVM.startListeningEvent();
        this.stopListening(EventMediator, 'VOLT_RESUME');
        Volt.Nav.resume();
        this.widget.show();
        Volt.Nav.setRoot(this.widget);
        Volt.Nav.reload();
        //add by lihao.zha, temporarily fix can not get VOLT_DEACTIVATE event (refer to DF141223-01431)
        if (Volt.Nav.getFocusedWidget() && Volt.Nav.getFocusedWidget().id == "download_button_widget") {
            var tempWidget = Volt.Nav.getFocusedWidget();
            Volt.Nav.focus();
            Volt.Nav.focus(tempWidget);
        }
        if (this.screenShotViewShow) {
            this.screenShotViewShow = false;
            if (CommonDefines.AppState.APP_STATE_DEACTIVATE == CommonFunctions.getAppState()) {
                //to update wzlastFocus of Nav
                Volt.Nav.pause();
                Volt.Nav.unblock();
            }
        }
    },

    _onkeyEvent: function (keyCode, keyType) {
        if (keyType == Volt.EVENT_KEY_RELEASE) {
            return false;
        }
        switch (keyCode) {
        case Volt.KEY_RETURN:

            var descriptionView = this.Description;

            //// 1. Return from More Description
            if (descriptionView && descriptionView.onReturn()) {
                return true;
            }

            // Hide Tooltip first before navigate back to Main View
            EventMediator.trigger('EVENT_HIDE_TOOLTIP');

            if (DetailVM.get('bSearchAll')) {

                Volt.setTimeout(function () {
                    //Volt.quit();
                }, 1);

                var appName = "org.tizen.search-all",
                    args = {
                        "--root": "/usr/apps/org.tizen.search-all/",
                        "domain": "apps"
                    },
                    aulApp = new Aul();

                var result = aulApp.launchApp(appName, args);

                Volt.err('[DetailView] Launch Search-All, result: ' + result);
            }
            return false;
            /*
            //// 2. Navigate Back
            if (!Backbone.history.back()) {
                Volt.log('[DetailView.js] exit apps panel, apps panel will hide in background');
                Volt.exit();
                //Volt.quit();

            } else if (DetailVM.get('bSearchAll')) { //// 3. What?
                var appName = "org.tizen.search-all",
                    args = {
                        "--root": "/usr/apps/org.tizen.search-all/",
                        "domain": "apps"
                    },
                    aulApp = new Aul();

                var result = aulApp.launchApp(appName, args);

                Volt.err('[DetailView] Launch Search-All, result: ' + result);
            }
    */
            return this.onReturn();
            break;

        default:
            return false;
            break;
        }

        return true;
    },

    addListeners: function () {
        Volt.log('[DetailView]');

        EventMediator.on('VOLT_PAUSE', this.pause, this);
        EventMediator.on('VOLT_HIDE', this.pause, this);
        this.listenTo(EventMediator, 'VOLT_DEACTIVATE', this.dim);

        this.listenTo(DetailVM, 'change:id', this.renderView);
        this.listenTo(DetailVM, 'error', this.showErrorPopup);

        this.listenTo(EventMediator, 'EVENT_PRESS_DETAIL_MORE_BTN', this.hideGridList);
        this.listenTo(EventMediator, 'EVENT_PRESS_DETAIL_CLOSE_BTN', this.showGridList);

        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_NETWORK_STATUS, this.onNetworkStatus);

        this.listenTo(EventMediator, 'DETAIL_LAUNCH_APP', this.startLaunch);
        this.listenTo(EventMediator, 'COMMON_POPUP_KEY_RETURN_RELEASE', this.cancelLaunch);

        this.listenTo(EventMediator, 'EVENT_DETAIL_SET_COLORPICK', this.setColorPick);

        //// Show and Hide Tooltip from Sub View 
        this.listenTo(EventMediator, 'EVENT_SHOW_TOOLTIP', this.showToolTip);
        this.listenTo(EventMediator, 'EVENT_HIDE_TOOLTIP', this.hideToolTip);

        //// Return Event
        this.listenTo(EventMediator, 'EVENT_DETAIL_RETURN', this.onReturn);
    },

    removeListeners: function () {
        Volt.log('[DetailView]');
        // @xj-2014/12/20: Stop listening to prevent unexpected event-processing
        this.stopListening();

        // @xj-2014/12/22: Why we should stop listening here? Where is the listening started
        DetailVM.stopListeningEvent();
    },

    ////////////////////////////////////
    // Private Functions
    ////////////////////////////////////
    /**
     * Taken data from server then called this to render view
     * @method
     * @memberof DetailView
     */
    renderView: function () {
        Volt.log("[DetailView.js] renderView ");

        this.hideLoading();
        //hide winset BG color when show loading, reset winsetBG color when loading hide
        this.widget.getDescendant('detail-title-area').color = (Volt.hexToRgb('#1f2b3d'));
        this.widget.getDescendant('detail-list-area').getChild(0).color = (Volt.hexToRgb('#1f2b3d'));

        this.renderSubView('AppInfo');
        this.renderSubView('StorageInfo');
        this.renderSubView('Description');
        this.renderSubView('Buttons');

        this.renderScreenShot();
        this.renderRelatedApps();

        if (this.Description.moreButtonParent) {
            Volt.Nav.setNextItemRule(this.Description.moreButtonParent, 'down', this.ScreenShotgridList.widget);
        }

        // Set init focus
        if (!Backbone.history.isHistoryBack) {
            Volt.Nav.focus(this.widget.getDescendant('download_button_widget'));
        }
    },
    /**
     * Remove the view, clear all content inside this view
     */
    removeView: function () {

        this.removeGrid();

        //        if (this.buttonView) {
        //            this.buttonView.hide();
        //        }
        this.removeSubView('AppInfo');
        this.removeSubView('StorageInfo');
        this.removeSubView('Description');
        this.removeSubView('Buttons');

        this.widget.hide();

        //// TODO: hideLoading will call resume, this will cause 'access destroyed error'
        this.hideLoading(); // Hide Loading
    },

    /**
     * Render a sub view
     * @method
     * @memberof DetailView
     */
    renderSubView: function (subViewName) {
        Volt.log("@renderSubView: subViewName: " + subViewName);

        var SubView = this.subViewMap[subViewName];
        if (!SubView) {
            // Not a valid Sub View Name
            return;
        }

        // Create if not exists.
        if (!this[subViewName]) {
            // Unified interface to create a sub view.
            this[subViewName] = new SubView({
                parent: this
            }).render();

            //this[subViewName].show && this[subViewName].show();
        }
    },
    /**
     * Destroy a Sub View
     */
    removeSubView: function (subViewName) {
        Volt.log("@removeSubView: subViewName: " + subViewName + this[subViewName]);

        if (this[subViewName]) {
            // Unified interface to remove a sub view.
            this[subViewName].remove();
            this[subViewName] = null;
        }
    },

    ////////////////////////////////////
    // Response to return event
    onReturn: function () {
        Volt.onKeyEvent(Volt.KEY_RETURN, Volt.EVENT_KEY_PRESS);
    },

    ////////////////////////////////////
    showFailRestHeaderPopup: function (errCode) {
        Volt.err('[DetailView.js] showFailRestHeaderPopup:' + errCode);
        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_SETHEADER_ERROR, {
            code: errCode
        });
    },

    msgBoxEvent: function (data) {
        if (data.eventType == CommonDefines.Event.SELECT_BTN1) {
            switch (data.msgBoxtype) {
            case CommonDefines.MsgBoxType.MSGBOX_TYPE_SETHEADER_ERROR:
                Volt.log('[DetailView.js] MSGBOX_TYPE_SETHEADER_ERROR, exit apps panel, apps panel will hide in background');
                Volt.exit();
                //Volt.quit();
                break;
            default:
                break;
            }
        }
    },

    /**
     * Show loading popup
     * @method
     * @memberof DetailView
     * @param  {string}  viewInfo  Widget ID
     */
    showLoading: function (options) {
        /*if (!this.bLoading){ 
	      DimView.show();
            var mustache = {
                style20 : WinsetLoading.LoadingStyle.Loading_Dark_20,
                nResoultionStyle : (Volt.APPS720P)? WinsetLoading.ResoultionStyle.Resoultion_720 : WinsetLoading.ResoultionStyle.Resoultion_1080
            }
            this.loading = Volt.loadTemplate(Template.loading,mustache,scene);
            this.loading.play();
            CommonFunctions.voiceGuide(Volt.i18n.t('COM_SID_LOADING_WAIT'));
	        this.bLoading = true;        
        }*/
        var options = {
            bLaunching: (options ? options.bLaunching : false)
        };

        Volt.log(options);

        if (!this.bLoading) {
            this.bLoading = true;
            loadingPopup.show(options);
        }
    },

    /**
     * Hide loading popup
     * @method
     * @memberof DetailView
     * @param  {string}  viewInfo  Widget ID
     */
    hideLoading: function () {
        this.bLoading = false;
        /*if(this.loading){
            this.loading.stop();
            this.loading.hide();
            this.loading.destroy();
            this.loading = null;
		DimView.hide();
        }*/
        loadingPopup.hide();
        //Volt.Nav.setRoot(this.widget);
    },

    startLaunch: function () {
        Volt.log('[DetailView] startLaunch');

        if (!this.bLaunching) {
            this.bLaunching = true;
        }

        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_NOT_EXIST, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_TIMEOUT, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_EMP, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_CAPH_APP, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_NETWORK, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_OTHERS, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_TERMINATE, this.failLaunch);
    },

    cancelLaunch: function () {
        Volt.log('[DetailView] cancelLaunch');
        var sLaunchedAppId = AppInstallMgr.getLaunchedAppID();

        if (this.bLaunching) {
            AppInstallMgr.terminateApp(sLaunchedAppId);
        }
    },

    failLaunch: function () {
        Volt.log('[DetailView] failLaunch');
        this.bLaunching = false;

        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_NOT_EXIST);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_TIMEOUT);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_EMP);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_CAPH_APP);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_NETWORK);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_OTHERS);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_TERMINATE);
    },


    /**
     * Set colorPick info to apply color
     * @method
     * @memberof DetailView
     */
    setColorPick: function (colorPick) {
        Volt.log(JSON.stringify(colorPick));
        //// Update Picked Color in Detail View. This color will be used by all Sub Views
        //this.pickedColor = colorPick;

        try {
            var highContrast = DeviceInfoModel.get('highContrast');
            Volt.log('[detailView] highContrast  : ' + highContrast);
            Volt.log('[detailView] colorPick  : ' + colorPick);


            //colorPick = false;

            if (colorPick) {
                Volt.log('[detailView] colorPick  : ' + colorPick.r + '  ' + colorPick.g + '  ' + colorPick.b);
                this.widget.color = {
                    r: colorPick.r,
                    g: colorPick.g,
                    b: colorPick.b,
                    a: 255
                };
                this.widget.getChild('detail-thumb-area').color = {
                    r: colorPick.r,
                    g: colorPick.g,
                    b: colorPick.b,
                    a: 255
                };
                if (!highContrast) {
                    this.widget.getChild('detail-background-colorpick').color = Volt.hexToRgb('#000000', 25);
                    //this.widget.getChild('detail-center-colorpick').color = {r:0, g:0, b:0, a:0}; 
                    this.widget.getChild('detail-title-area').color = Volt.hexToRgb('#000000', 8);
                    this.widget.getChild('detail-list-area').getChild(0).color = Volt.hexToRgb('#000000', 8);
                }

                var color = {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 64
                };
                this.widget.getChild('detail-background-colorpick').setBackgroundColor(color);
                //this.widget.getChild('detail-center-colorpick').color = {r:0, g:0, b:0, a:0}; 
                this.widget.getChild('detail-title-area').setBackgroundColor({
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 20.4
                });
                this.widget.getChild('detail-list-area').getChild(0).setBackgroundColor({
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 20.4
                });


            } else {
                //this.widget.getChild('detail-title-area').color = Volt.hexToRgb('#1f2b3d'); 
                //this.widget.getChild('detail-list-area').getChild(0).color = Volt.hexToRgb('#1f2b3d');
            }
            // this.textColorPick = '#ffffff';
        } catch (e) {
            Volt.log('[detailView] setColorPick(), occured exception: ' + e);
        }
    },

    /**
     * Render screenshot images
     * @method
     * @memberof DetailView
     */
    renderScreenShot: function () {
        Volt.log("[DetailView.js] renderScreenShot ");

        /*var container = this.widget.getDescendant('detail-screenshot-area');
		_.each(DetailVM.get('screenshotList'), function(screenShotURL, i){
			var bBlockLeft = (i == 0) ? true : false;
			container.addChild(new ScreenshotView().render(screenShotURL, i, bBlockLeft).widget);
		});
		Volt.Nav.reload();*/

        this.ScreenShot = this.widget.getChild('detail-screenshot-area');
        //var thumbArea = this.widget.getChild('detail-thumb-area');
        Volt.log('screenshotList:' + JSON.stringify(DetailVM.get('screenshotList')));

        if (DetailVM.get('screenshotList').length > 0) {
            this.ScreenShotgridList = this.initScreenShotGrid();
            this.ScreenShotgridList.color = Volt.hexToRgb('#000000', 0);
            this.ScreenShot.addChild(this.ScreenShotgridList.widget);

            if (this.ScreenShotgridList) {
                this.ScreenShotgridList.widget.custom = {
                    focusable: true
                };
                this.ScreenShotgridList.widget.showWithAnimation();
            }
            Volt.Nav.reload();
        }
    },

    /**
     * Render related apps list
     * @method
     * @memberof DetailView
     */
    renderRelatedApps: function () {
        Volt.log("[DetailView.js] renderRelatedApps ");

        var relatedAppText = Volt.loadTemplate(Template.relatedText);

        if (this.textColorPick) {
            relatedAppText.textColor = Volt.hexToRgb(this.textColorPick, 60);
        }
        this.relatedApps = this.widget.getChild('detail-list-area');
        this.relatedApps.addChild(relatedAppText);


        if (DetailVM.get('appInfoVMCollection').length > 0) {
            this.gridListView = this.initNativeGrid();
            this.gridListView.color = Volt.hexToRgb('#000000', 0);
            this.relatedApps.addChild(this.gridListView.widget);

            if (this.gridListView) {
                this.gridListView.widget.custom = {
                    focusable: true
                };
                this.gridListView.widget.showWithAnimation();
            }

            Volt.Nav.reload();

            if (Backbone.history.isHistoryBack) {
                if (DetailVM.get('lastIndex') !== undefined) {
                    this.gridListView.widget.setFocusItemIndex(0, DetailVM.get('lastIndex'));
                    Volt.Nav.focus(this.gridListView.widget);
                } else {
                    EventMediator.trigger('EVENT_DETAIL_SET_BUTTON_FOCUS', true);
                }
            }
        }
    },


    initNativeGrid: function () {
        var self = this;
        var wzGridView = null;
        var gridTemplate = _.clone(Template.setGridList);
        gridTemplate.parent = this.relatedApps;
        this.viewList = new Array();

        var gridListView = new GridListView({
            gridListControlParam: gridTemplate,
            listeners: {
                onDrawLoadData: function (thumbnail, data) {
                    Volt.log('[DetailView] onDrawLoadData ' + data._index);
                    var model = data.model;

                    var iRelatedAppView = new RelatedAppView(model, null);
                    iRelatedAppView.render(data._index, thumbnail);
                    self.viewList[data._index] = iRelatedAppView;
                },
                onDrawUpdateData: function (thumbnail, data) {
                    Volt.log('[DetailView] onDrawUpdateData');
                },
                onDrawUnloadData: function (thumbnail, data) {
                    Volt.log('[DetailView] onDrawUnloadData');
                    var VM = data.model;

                    if (VM) {
                        VM.destroyView();
                    }
                },
                onGridFocus: function (wzFocused) {
                    Volt.log('[DetailView] onGridFocus');
                    if (wzFocused && typeof wzFocused.trigger == 'function') {
                        wzFocused.trigger('NAV_FOCUS');
                    }
                },
                onGridBlur: function (wzFocused) {
                    Volt.log('[DetailView] onGridBlur');
                    if (wzFocused && typeof wzFocused.trigger == 'function') {
                        wzFocused.trigger('NAV_BLUR');
                    }
                },
                onFocusChangeStart: function (wzFrom, wzTo) {

                },
                onFocusChanged: function (wzFrom, wzTo) {
                    Volt.log('[DetailView] onFocusChanged');

                    if (wzTo) {
                        var voiceText = wzTo.customTitle;
                        if (wzFrom == null) {
                            voiceText = Volt.i18n.t('TV_SID_USER_THIS_APP_DOWNLOADED') + ',' +
                                DetailVM.get('appInfoVMCollection').length + ' ' + Volt.i18n.t('TV_SID_ITEMS') +
                                ' ' + wzTo.customTitle;
                        }
                        CommonFunctions.voiceGuide(voiceText);
                    }
                },
                onItemPress: function (wz, itemData, data) {
                    Volt.log('[DetailView] onItemPress');
					if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
						CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
						return;
					}
                    var model = data.model;
                    var index = itemData.itemIndex;
                    if (model.get('id')) {
                        print(' index is   ' + index);
                        DetailVM.cacheData(index);

                        //// xj|20141226: hide loading will call Volt.Nav.resume(), but wzLastFocused is destroyed.
                        //// Blur focus first to prevent resume() error 
                        Volt.Nav.blur();

                        Volt.setTimeout(function () {
                            Backbone.history.navigate('detail/' + model.get('id'), {
                                trigger: true
                            });
                        }, 10);

                        Volt.KpiMapper.addEventLog('RELATEDAPP', {
                            d: {
                                appid: model.get('id'),
                            }
                        });
                    }

                },

                onEnterKeyLongPressed: function () {

                },
            }
        });

        return gridListView.render(DetailVM.get('appInfoVMCollection'));
    },

    initScreenShotGrid: function () {
        var self = this;
        var wzGridView = null;
        var gridTemplate = _.clone(Template.screenShotGridList);
        gridTemplate.parent = this.ScreenShot;
        this.viewList = new Array();
        Volt.log('initScreenShotGrid itemWidth:' + gridTemplate.itemWidth);
        var gridListView = new GridListView({
            gridListControlParam: gridTemplate,
            listeners: {
                onDrawLoadData: function (thumbnail, data) {
                    Volt.log('[initScreenShotGrid] onDrawLoadData ' + data._index);
                    var model = data.model;

                    var iScreenShotView = new ScreenshotView(model, null);
                    iScreenShotView.render(data._index, thumbnail);
                    self.viewList[data._index] = iScreenShotView;
                },
                onDrawUpdateData: function (thumbnail, data) {
                    Volt.log('[initScreenShotGrid] onDrawUpdateData');
                },
                onDrawUnloadData: function (thumbnail, data) {
                    Volt.log('[initScreenShotGrid] onDrawUnloadData');
                    var VM = data.model;

                    if (VM) {
                        VM.destroyView();
                    }
                },
                onGridFocus: function (wzFocused) {
                    Volt.log('[initScreenShotGrid] onGridFocus');
                    if (wzFocused && typeof wzFocused.trigger == 'function') {
                        wzFocused.trigger('NAV_FOCUS');
                    }
                },
                onGridBlur: function (wzFocused) {
                    Volt.log('[initScreenShotGrid] onGridBlur');
                    if (wzFocused && typeof wzFocused.trigger == 'function') {
                        wzFocused.trigger('NAV_BLUR');
                    }
                },
                onFocusChangeStart: function (wzFrom, wzTo) {

                },
                onFocusChanged: function (wzFrom, wzTo) {
                    Volt.log('[initScreenShotGrid] onFocusChanged');

                    if (wzFrom && typeof wzFrom.trigger == 'function') {
                        wzFrom.trigger('NAV_BLUR');
                    }
                    if (wzTo && typeof wzTo.trigger == 'function') {
                        wzTo.trigger('NAV_FOCUS');
                    }
                },
                onItemPress: function (wz, itemData) {
                    Volt.log('[initScreenShotGrid] @@@@ onItemPress' + itemData.itemIndex);
                    Backbone.history.navigate('detail/popup/screenShot/' + itemData.itemIndex, {
                        trigger: true
                    });
                    self.screenShotViewShow = true;

                    Volt.KpiMapper.addEventLog('SCREENSHOT');
                },

                onEnterKeyLongPressed: function () {

                },
            },
            bShowScroll: false,

        });
        Volt.log('initScreenShotGrid data:#################' + JSON.stringify(DetailVM.get('screenshotList')));

        var screenShotCollection = this.getScreenShotCollection();

        return gridListView.render(screenShotCollection);
    },

    getScreenShotCollection: function () {
        Volt.log("DetailVM.get('screenshotList')[i]:@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        var screenShotArray = new Array();
        for (var i = 0; i < DetailVM.get('screenshotList').length; i++) {
            Volt.log("DetailVM.get('screenshotList')[i]:" + DetailVM.get('screenshotList')[i]);
            screenShotArray[i] = {};
            screenShotArray[i].icon = DetailVM.get('screenshotList')[i];
            Volt.log('screenShotArray[i].icon' + screenShotArray[i].icon);
        };
        var ScreenShotListModel = Backbone.Model.extend({
            defaults: {
                'icon': null,
            },
        });
        var screenShotCollection = Backbone.Collection.extend({
            model: ScreenShotListModel,
        });
        var screenShot = new screenShotCollection;
        screenShot.add(screenShotArray);
        return screenShot;
    },

    removeGrid: function () {
        Volt.log('[DetailView] remove grid list');

        if (this.gridListView) {
            this.gridListView.widget.custom = {
                focusable: false
            };
            this.gridListView = null;
            delete this.gridListView;
        }
    },
    /**
     * Hide related apps area
     * @method
     * @memberof DetailView
     */
    hideGridList: function () {
        if (detailview.gridListView) {
            detailview.gridListView.widget.custom = {
                focusable: false
            };
        }
        if (detailview.ScreenShotgridList) {
            detailview.ScreenShotgridList.widget.custom = {
                focusable: false
            };
        }
        detailview.gridListView.widget.hideWithAnimation("autoDestroy");
        detailview.ScreenShotgridList.widget.hideWithAnimation("autoDestroy");

        detailview.relatedApps.hide();
        detailview.ScreenShot.hide();

    },

    /**
     * Show related apps area
     * @method
     * @memberof DetailView
     */
    showGridList: function () {
        if (detailview.gridListView) {
            detailview.gridListView.widget.custom = {
                focusable: true
            };
            Volt.Nav.reload();
        }
        if (detailview.ScreenShotgridList) {
            detailview.ScreenShotgridList.widget.custom = {
                focusable: true
            };
            Volt.Nav.reload();
        }

        detailview.gridListView.widget.showWithAnimation();
        detailview.ScreenShotgridList.widget.showWithAnimation();

        detailview.relatedApps.show();
        detailview.ScreenShot.show();
    },

    /**
     * Return to convert app size
     * @method
     * @memberof DetailView
     */
    convertByte: function (value) {
        if (value >= 1048576) {
            return parseFloat(value / 1048576).toFixed(2) + " " + Volt.i18n.t('SID_MB');
        } else if (value >= 1024) {
            return parseInt(value / 1024) + " " + Volt.i18n.t('SID_KB');
        } else {
            return parseInt(value) + " " + Volt.i18n.t('SID_BYTE');
        }
    },

    /**
     * Destory this view's widget and release memory.
     * @method
     * @memberof DetailView
     */
    destroy: function (widget) {
        Volt.log("[DetailView.js] destroy");
        if (!widget) return;
        var nChildLength = widget.getChildCount();
        if (nChildLength > 0) {
            for (var i = 0; i < nChildLength; i++) {
                this.destroy(widget.getChild(i));
            }
        }
        widget.id = '';
        delete widget;
        widget = null;
    },

    showErrorPopup: function (serverError) {
        Volt.log("[DetailView.js] showErrorPopup");

        this.hideLoading();

        if (serverError.code == 'AS666') {
            //var networkPopup = new MsgPopupView({type: CommonDefines.Popup.TYPE_NETWORK});
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
        } else {
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_SERVER_ERROR_GUIDE, serverError);
        }
        /*
        var setPopup = {
            title: "Server Error",
            text : serverError.message + '(' + serverError.code +')',
            buttons: [
                {
                    name: "OK",
                    callback: function(){
                    	Backbone.history.back();
                    }
                }
            ]
        };
		*/
        // var guidePopup = new MsgPopupView(setPopup);
        return;
    },

    onNetworkStatus: function () {
        if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
        }
    },

    dim: function () {
        Volt.log('[DetailView] dim');
        if (this.screenShotViewShow) {
            Backbone.history.back();
            Volt.KpiMapper.addEventLog('COUNTSCREENSHOT', {
                d: {
                    css: this.nScreenShot
                }
            });
        }
        DimView.show();
    },

    showToolTip: function (widget) {
        if (!(widget && widget.getAbsolutePosition)) {
            return;
        }

        var absolutePosition = widget.getAbsolutePosition();
        var text = '';
        //var postionOffset = 0;
        if (widget && widget.id == 'rating_button_widget') {
            text = Volt.i18n.t('TV_SID_RATING_POINT');
        } else if (widget && widget.id == 'detail-more-button') {
            text = Volt.i18n.t('TV_SID_MORE');
        } else if (widget && widget.id == 'detail-return-button') {
            text = Volt.i18n.t('SID_RETURN');
        } else if (widget && widget.id == 'detail-exit-button') {
            text = Volt.i18n.t('SID_EXIT');
        }
        if (text == '') {
            Volt.log("[detailView.js] showtooltip error, text is empty");
            return;
        }
        var mustache = {
            x: absolutePosition.x + widget.width / 2 - Volt.getTextWidth({
                text: text,
                font: (Volt.APPS720P) ? "SVD Light 20px" : "SVD Light 30px"
            }) / 2 - Volt.width * 0.0078125,
            y: absolutePosition.y + widget.height,
            w: Volt.getTextWidth({
                text: text,
                font: (Volt.APPS720P) ? "SVD Light 20px" : "SVD Light 30px"
            }) + Volt.width * 0.015625,
            style: WinsetToolTip.TooltipStyle.Tooltip_Tail_Up,
            nResoultionStyle: (Volt.APPS720P) ? WinsetToolTip.ResoultionStyle.Resoultion_720 : WinsetToolTip.ResoultionStyle.Resoultion_1080,
            text: text,
            tailPostion: "center"
        };
        if (mustache.x + mustache.w > Volt.width) {
            mustache.x = absolutePosition.x + widget.width / 2 + Volt.width * 0.0109375 - mustache.w;
            mustache.tailPostion = "end";
        }

        if (this.toolTip) {
            this.hideToolTip();
        }
        this.toolTip = Volt.loadTemplate(Template.toolTip, mustache);
        //if (0 != postionOffset) {
        //    this.toolTip.setTailPosition("up", Volt.getTextWidth({
        //        text: text,
        //        font: (Volt.APPS720P) ? "SVD Light 20px" : "SVD Light 30px"
        //    }) / 2 + Volt.width * 0.003125 + postionOffset, 0);
        //}
        this.toolTip.show();
        this.startToolTipTimeOut(); //set timeout to 3s   DF141120-01530,add by yangpei 20141112

    },
    hideToolTip: function () {
        Volt.log('hideToolTip');
        if (this.toolTip) {
            this.toolTip.destroy();
            this.toolTip = null;
        }
        this.clearToolTipTimeOut();
    },

    startToolTipTimeOut: function () {
        this.clearToolTipTimeOut();
        this.timeId = Volt.setTimeout(_.bind(this.hideToolTip, this), 2000);
    },

    clearToolTipTimeOut: function () {
        if (this.timeId) {
            Volt.clearTimeout(this.timeId);
            this.timeId = null;
        }
    },

});

/**
 * @name AppInfoView
 */
var AppInfoView = Volt.BaseView.extend({
    parent: null, // Parent View of this view

    // Return Button for Mouse
    returnButton: null,
    exitButton: null,

    mouseListener: null,

    ////////////////////////////////////
    // Public Functions
    ////////////////////////////////////

    initialize: function (options) {
        this.parent = options.parent;
    },

    /**
     * Render static widgets
     * Render both left side thumb area and right side description of app
     * @method
     * @memberof DetailView
     */
    render: function () {
        Volt.log("[detail-view.js ::AppInfoView @render]");

        var parentWidget = this.parent.widget;

        //// Get 3 sub areas
        var titleArea = parentWidget.getChild('detail-title-area');
        var thumbArea = parentWidget.getChild('detail-thumb-area');
        var appInfoArea = parentWidget.getChild('detail-appInfo-area');

        //// Render Title
        Volt.loadTemplate(Template.title, {
            title: DetailVM.get('title')
        }, titleArea);

        this.returnButton = titleArea.getDescendant('detail-return-button');
        this.exitButton = titleArea.getDescendant('detail-exit-button');
        CmButtonView.render(this.returnButton);
        CmButtonView.render(this.exitButton);

        //// Update View according to Cursor state
        this.onChangeCursor(Vconf.getInteger(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE));

        //// Render Thumbnail
        var thumb = Volt.loadTemplate(Template.ThumbArea, {
            thumbnail: DetailVM.get('icon').replace("{w}", CommonDefines.ImageSize.DETAIL_ICON_WIDTH).replace("{h}", CommonDefines.ImageSize.DETAIL_ICON_HEIGHT)
        }, thumbArea);

        //// Update Color Pick
        this.getIconColorPick(thumb.getChild(0));

        //// Render AppInfo

        //'{{avgrate}} Free | Size: {{filesize}} | Updated: {{updated}}'
        //'Developer Samsung | Rating: {{rated}} | Version {{version}}',
        var nAvgRating = parseInt(DetailVM.get('gradeAvg') * 10) / 10;
        var strInstalled = '';
        var strEmail = '';

        if (DetailVM.get('isDownloaded')) {
            strInstalled = "(" + DetailVM.get('installedVersion') + Volt.i18n.t('TV_SID_INSTALLED') + ")";
        }

        if (DetailVM.get('contact')) {
            strEmail = '(' + DetailVM.get('contact') + ')';
        }

        var appInfoTemplate = Volt.loadTemplate(Template.appInfo, {
            avgRating: nAvgRating,
            size: this.convertByte(DetailVM.get('fileSize')),
            updated: DetailVM.get('updated').slice(0, 10),
            installed: strInstalled,
            developer: DetailVM.get('vendor') + strEmail,
            rated: DetailVM.get('rated'),
            version: DetailVM.get('version'),
        }, appInfoArea);

        var nImageWidth = 0;
        var nSecondLineWidth = appInfoTemplate.getChild(1).width;
        if (DetailVM.get('ratedIcon')) {
            // Add to set image of rate for Brazil
            var ratedIcon = appInfoTemplate.getChild(2);
            nImageWidth = ratedIcon.x + ratedIcon.width;
            ratedIcon.x = nSecondLineWidth;
            ratedIcon.src = DetailVM.get('ratedIcon');
        }

        appInfoTemplate.getChild(3).x = nImageWidth + nSecondLineWidth;

        //// Render Stars
        var srcStarOn = Volt.getRemoteUrl('images/1080/common/dp_like_star_on.png');
        var srcStarOff = Volt.getRemoteUrl('images/1080/common/dp_like_star_off.png');
        var srcStarHalf = Volt.getRemoteUrl('images/1080/common/dp_like_star_half.png');

        var integerRating = Math.floor(nAvgRating);
        var pointRating = nAvgRating - integerRating;

        for (var i = 0; i < MAX_RATING_NUM; i++) {
            var starUrl = '';
            if (i < integerRating) {
                starUrl = srcStarOn;
            } else {
                if (i == integerRating && pointRating >= 0.5) {
                    starUrl = srcStarHalf;
                } else {
                    starUrl = srcStarOff;
                }
            }

            Template.contentStar.x = Volt.width * 0.013021 * i;
            var starTemplate = Volt.loadTemplate(Template.contentStar, {
                imageUrl: starUrl
            }, appInfoArea);

            //starTemplate.x = 
            //            appInfoTemplate.addChild(starTemplate);
        }

        //// Add Listeners
        // After we showed, we can response to listeners
        this.addListeners();

        return this;
    },

    remove: function () {
        Volt.log('[AppInfoView @remove]');

        //// Remove Listeners Here
        this.removeListeners();

        this.returnButton = null;
        this.exitButton = null;
    },

    //// Add Event Listeners
    addListeners: function () {
        Volt.log('[AppInfoView]');

        var mouseListener = this.mouseListener = new MouseListener;

        mouseListener.onMousePointerIn = function (actor, event) {
            EventMediator.trigger('EVENT_SHOW_TOOLTIP', actor);
            //actor.setFocus();
        };
        mouseListener.onMousePointerOut = function (actor, event) {
            EventMediator.trigger('EVENT_HIDE_TOOLTIP');
        };
        mouseListener.onMouseButtonReleased = function (actor, event) {
            print('onMouseButtonReleased');

            if (actor.id == 'detail-return-button') {
                //// Fix Bug of DF141224-01332:
                //// [ST5][Hawk-P][AppStore][Detail New] Mouse, B detail view,press more, then press Return with mouse, it should return to B
                //Backbone.history.back();
                EventMediator.trigger('EVENT_DETAIL_RETURN');
            } else if (actor.id == 'detail-exit-button') {

                // Quit Service when click close
                Volt.quit();
            }
        };

        this.returnButton.addMouseListener(mouseListener);
        this.exitButton.addMouseListener(mouseListener);

        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, this.onChangeCursor);
    },

    // Remove Event Listeners
    removeListeners: function () {
        Volt.log('[AppInfoView]');
        // Stop listen to EventMediator of CHANGE_VISIBLE_CURSOR
        this.stopListening();
        this.returnButton.removeMouseListener(this.mouseListener);
        this.exitButton.removeMouseListener(this.mouseListener);
        this.mouseListener = null;
    },

    ////////////////////////////////////
    // Private Functions
    ////////////////////////////////////
    // Invoked when Cusor State changes
    onChangeCursor: function (visible) {
        Volt.log('[AppInfoView] visible: ' + visible);
        // Add this if to prevent the ODD invoke after stopListening
        if (this.returnButton) {
            if (visible) {
                this.returnButton.show();
                this.exitButton.show();
            } else {
                this.returnButton.hide();
                this.exitButton.hide();
            }
        }
    },

    getIconColorPick: function (imageWidget) {
        Volt.log("[AppInfoView]");

        if (imageWidget) {
            var pickedColor = {};
            imageWidget.onReady = function (success) {
                if (success) {
                    Volt.err('[detail-view.js] getIconColorPick()');
                    imageWidget.show();
                    var colorPicking = imageWidget.getColorPicking(5);
                    if (colorPicking.success && colorPicking.color) {
                        pickedColor = colorPicking.color;
                        pickedColor.a = 255;
                        EventMediator.trigger('EVENT_DETAIL_SET_COLORPICK', pickedColor);
                        return;
                    }
                }
                EventMediator.trigger('EVENT_DETAIL_SET_COLORPICK', null);
            };
        } else {
            Volt.err("[detail-view.js] getIconColorPick(), Not exist imageWidget ");
            EventMediator.trigger('EVENT_DETAIL_SET_COLORPICK', null);
        }
    },

    /**
     * Return to convert app size
     * @method
     * @memberof DetailView
     */
    convertByte: function (value) {
        if (value >= 1048576) {
            return parseFloat(value / 1048576).toFixed(2) + " " + Volt.i18n.t('SID_MB');
        } else if (value >= 1024) {
            return parseInt(value / 1024) + " " + Volt.i18n.t('SID_KB');
        } else {
            return parseInt(value) + " " + Volt.i18n.t('SID_BYTE');
        }
    }
});
/**
 * @name StorageView
 */
var StorageInfoView = Volt.BaseView.extend({
    /** @lends DetailView.prototype */
    parent: null,

    //// Widgets inside this sub view
    allMemoryText: null,
    usedMemoryText: null,
    availableMemoryText: null,
    storageProgressbar: null,

    ////////////////////////////////////
    // Public Functions
    ////////////////////////////////////

    /**
     * Initialize StorageView to register event
     * @name StorageView
     * @constructs
     */
    initialize: function (options) {
        this.parent = options.parent;
    },

    /**
     * Render ProgressBar to show local memory
     * @method
     * @memberof StorageView
     */
    render: function () {
        Volt.log("[detail-view.js @StorageInfoView @renderStorageInfo]");

        var container = this.parent.widget.getDescendant('detail-storage-area');
        //container.addChild(this.stgView.render(this.textColorPick).widget);

        var LocalMemory = DetailVM.get('storageInfo');
        var widget = Volt.loadTemplate(Template.storage, null, container, false);

        this.allMemoryText = widget.getDescendant('storage-info-text-all');
        this.usedMemoryText = widget.getDescendant('storage-info-text-used');
        this.availableMemoryText = widget.getDescendant('storage-info-text-available');
        this.allMemoryValueText = widget.getDescendant('storage-info-text-all-value');
        this.usedMemoryValueText = widget.getDescendant('storage-info-text-used-value');
        this.availableMemoryValueText = widget.getDescendant('storage-info-text-available-value');

        ////
        var mustache = {
            nProgressStyle: WinsetProgress.ProgressStyle.Progress_Style_A,
            nResoultionStyle: (Volt.APPS720P) ? WinsetProgress.ResoultionStyle.Resoultion_720 : WinsetProgress.ResoultionStyle.Resoultion_1080,
        };

        this.storageProgressbar = Volt.loadTemplate(Template.storageProgressBar, mustache, widget.getDescendant('storage-info-progress-bg'));

        Volt.log("render, LocalMemory.storageRate = " + LocalMemory.storageRate);

        //// Update Color Pick
        var pickedColor = this.parent.pickedColor;
        if (pickedColor) {
            var textColor = {
                r: pickedColor.r,
                g: pickedColor.g,
                b: pickedColor.b,
                a: 255 * 0.6
            };
            widget.getChild('storage-info-text-all').textColor = textColor;
            widget.getChild('storage-info-text-used').textColor = textColor;
            widget.getChild('storage-info-text-available').textColor = textColor;
            widget.getChild('storage-info-text-all-value').textColor = textColor;
            widget.getChild('storage-info-text-used-value').textColor = textColor;
            widget.getChild('storage-info-text-available-value').textColor = textColor;
        }

        //// @xj|2014/12/13: After view rendered, update data
        this.update();

        ////
        this.addListeners();

        ////
        this.setWidget(widget);
        widget.show();

        return this;
    },

    remove: function () {
        //// @xj|2014/12/23: Theoretically, we should destroy this.widget here. Since we will destroy widget of parent, we don't need to destroy widget here.
        this.removeListeners();
    },

    /**
     * Show storage area
     * @method
     * @memberof StorageView
     */
    show: function () {
        this.widget.show();
    },

    /**
     * Hide storage area
     * @method
     * @memberof StorageView
     */
    hide: function () {
        this.widget.hide();
    },

    /**
     * When changed local storage memory, it update progressbar
     * @method
     * @memberof StorageView
     */
    update: function () {
        if (this.storageProgressbar && DetailVM.get('storageInfo')) {
            var LocalMemory = DetailVM.get('storageInfo');

            //this.storageProgressbar.percentage = LocalMemory.storageRate;
            Volt.log("update, LocalMemory.storageRate = " + LocalMemory.storageRate);

            this.storageProgressbar.value = LocalMemory.storageRate * 100;

            this.allMemoryValueText.text = '(' + this.getMemoryText().all + ')';
            this.usedMemoryValueText.text = this.getMemoryText().used;
            this.availableMemoryValueText.text = this.getMemoryText().available;

            this.allMemoryText.width = Volt.getTextWidth({
                text: this.allMemoryText.text,
                font: (Volt.APPS720P) ? '13px' : '20px'
            }) + Volt.width * 0.003125;
            this.allMemoryValueText.width = Volt.getTextWidth({
                text: this.allMemoryValueText.text,
                font: (Volt.APPS720P) ? '13px' : '20px'
            }) + Volt.width * 0.003125;
            this.allMemoryValueText.x = this.allMemoryText.x + this.allMemoryText.width;
        }
    },

    addListeners: function () {
        this.listenTo(DetailVM, 'change:storageInfo', this.update);
        this.listenTo(EventMediator, 'EVENT_PRESS_DETAIL_MORE_BTN', this.hide);
        this.listenTo(EventMediator, 'EVENT_PRESS_DETAIL_CLOSE_BTN', this.show);
    },

    removeListeners: function () {
        this.stopListening();
    },

    ////////////////////////////////////
    // Private Functions
    ////////////////////////////////////
    getMemoryText: function () {
        if (!DetailVM || !DetailVM.get('storageInfo') && !DetailVM.get('storageInfo').storageInfo) {
            return {
                used: "0KB",
                available: "0KB",
                all: "0KB"
            };
        }
        var used = DetailVM.get('storageInfo').storageInfo.split("/")[0];
        var all = DetailVM.get('storageInfo').storageInfo.split("/")[1];

        if (used.search(/GB/g) != -1) {
            used = Number(used.split("G")[0]) * 1024 * 1024;
        } else if (used.search(/MB/g) != -1) {
            used = Number(used.split("M")[0]) * 1024;
        } else if (used.search(/KB/g) != -1) {
            used = Number(used.split("K")[0]);
        }
        if (all.search(/GB/g) != -1) {
            all = Number(all.split("G")[0]) * 1024 * 1024;
        } else if (all.search(/MB/g) != -1) {
            all = Number(all.split("M")[0]) * 1024;
        } else if (all.search(/KB/g) != -1) {
            all = Number(all.split("K")[0]);
        }
        var available = all - used;
        return {
            used: this.transferMemoryText(used),
            available: this.transferMemoryText(available),
            all: this.transferMemoryText(all),
        };
    },

    transferMemoryText: function (num) {
        if (num > 1024 * 1024) {
            return String((num / 1024 / 1024).toFixed(2)) + "GB";
        } else if (num > 1024) {
            return String((num / 1024).toFixed(2)) + "MB";
        } else {
            return String(num.toFixed(2)) + "KB";
        }
    }
});

/**
 * @name DescriptionView
 */
var DescriptionView = Volt.BaseView.extend({
    /** @lends DescriptionView.prototype */
    parent: null, // Parent View

    // Widgets
    moreButtonParent: null,
    closeButtonParent: null,
    moreButton: null,
    closeButton: null,

    // Data
    descriptionHeight: 0, // Real height of description

    currentPage: 0,
    maxPage: 0,
    scroll: null,
    //btnListener: new ButtonListener(),

    //// Flag
    moreDescriptionFlag: false,

    events: {
        //'NAV_SELECT ':'onSelect',
        'NAV_SELECT #detail-description-up-arrow': 'onSelect',
        'NAV_SELECT #detail-description-down-arrow': 'onSelect',
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    ////////////////////////////////////
    // Public Functions
    ////////////////////////////////////
    /**
     * Initialize DescriptionView
     * @name DescriptionView
     * @constructs
     */
    initialize: function (options) {
        this.parent = options.parent;
    },

    /**
     * Render description info.
     * @method
     * @memberof DescriptionView
     */
    render: function () {
        Volt.log("[DescriptionView.js] render");
        try {
            var strDescription = this.escapeHtml(DetailVM.get('description'));

            //// Load Template
            var widget = Volt.loadTemplate(Template.description, {
                description: strDescription
            }, this.parent.widget.getDescendant('detail-description-area'));

            this.setWidget(widget);

            // TODO: Check if color pick is working?
            // Color Pick
            var pickedColor = this.parent.pickedColor;
            if (pickedColor) {
                //widget.getChild(0).textColor = Volt.hexToRgb(this.parent.pickedColor, 80);
                widget.getDescendant('detail-description-text').textColor = {
                    r: pickedColor.r,
                    g: pickedColor.g,
                    b: pickedColor.b,
                    a: 255 * 0.8,
                };
            }

            this.descriptionText = widget.getChild(0).getChild('detail-description-text');
            this.upArrow = widget.getChild('detail-description-up-arrow');
            this.downArrow = widget.getChild('detail-description-down-arrow');

            this.descriptionHeight = this.descriptionText.height;

            if (this.descriptionHeight > Template.descriptionLineHeight) {
                //// need More Button

                //                this.btnListener.onButtonClicked = function (button, type) {
                //                    this.onSelect(button);
                //                }.bind(this);

                this.maxPage = Math.ceil(this.descriptionHeight / Template.descriptionMaxLineHight);
	            Volt.log('[descriptionView] this.maxPage: ' + this.maxPage );

			
                this.descriptionText.height = Template.descriptionLineHeight;
                this.descriptionText.ellipsize = true;

                //// Set up More Button
                this.moreButtonParent = this.widget.getChild('detail-more-button');

                var btnStyle = {
                    style: WinsetBtn.ButtonStyle.Button_image_O_Style_G_FOCUS1,
                    buttonType: WinsetBtn.ButtonType.BUTTON_ICON,
                    resoultion: tvResoultion,
                };

                this.moreButton = PanelCommon.loadTemplate(Template.moreBtn, btnStyle, this.moreButtonParent);

                //                var moreBtnBG = widget.getChild('detail-more-button');
                //                moreBtnBG.custom = {
                //                    focusable: true
                //                };

                //                Volt.Nav.reload();
                //                this.moreButton.addListener(this.btnListener);

                this.moreButton.setIconImage({
                    state: "normal",
                    src: Volt.getRemoteUrl("images/1080/common/btn_icon_more.png"),
                });
                this.moreButton.setIconImage({
                    state: "focused",
                    src: Volt.getRemoteUrl("images/1080/common/btn_icon_more_f.png"),
                });
                this.moreButton.setIconImage({
                    state: "focused-roll-over",
                    src: Volt.getRemoteUrl("images/1080/common/btn_icon_more_f.png"),
                });
                this.moreButton.setIconImage({
                    state: "selected",
                    src: Volt.getRemoteUrl("images/1080/common/btn_icon_more.png"),
                });

				this.moreButton.setIconAlpha({
					state: "normal",
					alpha: 255
				});
			


                //// Set up Close Button
                this.closeButtonParent = this.widget.getChild('detail-close-button');

                var btnStyleText = {
                    style: WinsetBtn.ButtonStyle.Button_image_O_Style_G_FOCUS1,
                    buttonType: WinsetBtn.ButtonType.BUTTON_TEXT,
                    resoultion: tvResoultion,
                };

                this.closeButton = PanelCommon.loadTemplate(Template.closeBtn, btnStyleText, this.closeButtonParent);

                //                var closeBtnBG = widget.getChild('detail-close-button');
                //                this.closeButton.addListener(this.btnListener);
                //                this.widget.getChild('detail-close-button').hide();

                this.closeButtonParent.hide();

                //// Update Volt.Nav Candidate List
                Volt.Nav.addItem(this.moreButtonParent, true);
            }

            this.hideArrow();
            //descriptionView = this;

            //// Add Event Listener
            this.addListeners();

            return this;

        } catch (e) {
            Volt.log('[descriptionView] occured exception: ' + e);
        }
    },

    remove: function () {
        //// @xj|2014/12/23: Theoretically, we should destroy this.widget here. Since we will destroy widget of parent, we don't need to destroy widget here.
        this.removeListeners();
    },

    addListeners: function () {
        //// Add Event Listener
        if (this.moreButton && this.closeButton) {
            var btnListener = new ButtonListener();
            btnListener.onButtonClicked = function (button, type) {
                this.onSelect(button);
            }.bind(this);

            this.moreButton.addListener(btnListener);
            this.closeButton.addListener(btnListener);
        }
    },

    removeListeners: function () {
        this.stopListening();
    },

    ////////////////////////////////////
    // Private Functions
    ////////////////////////////////////

    onReturn: function () {

        if (this.moreDescriptionFlag) {
            //Volt.log("detailView.js KEY_JOYSTICK_OK:!!!!!!!!!!" + descriptionView.moreDescriptionFlag);
            this.onSelect(this.closeButton);
            this.moreDescriptionFlag = false;
            return true;
        }
        return false;
    },

    escapeHtml: function (descriptionText) {

        var escapeText = descriptionText;

        if (escapeText) {

            if (escapeText.match(/\n/gi)) {
                escapeText = escapeText.replace(/\n/gi, '');
            }

            if (escapeText.match(/\r/gi)) {
                escapeText = escapeText.replace(/\r/gi, '');
            }

            if (escapeText.match(/\t/gi)) {
                escapeText = escapeText.replace(/\t/gi, '');
            }

            if (escapeText.match(/&quot;/gi)) {
                escapeText = escapeText.replace(/&quot;/gi, '"');
            }

            if (escapeText.match(/<br>/gi)) {
                escapeText = escapeText.replace(/<br>/gi, /\/n/).replace(/\//gi, '');
            }

            if (escapeText.match(/<br\/>/gi)) {
                escapeText = escapeText.replace(/<br\/>/gi, /\/n/).replace(/\//gi, '');
            }

            if (escapeText.match(/<br \/>/gi)) {
                escapeText = escapeText.replace(/<br \/>/gi, /\/n/).replace(/\//gi, '');
            }
        }

        return escapeText;
    },

    /**
     * When select button, doing button's action
     * @method
     * @memberof DescriptionView
     * @param {object} widget  selected widget's object
     */
    onSelect: function (widget) {

        switch (widget.id) {
        case 'moreBtn':
            EventMediator.trigger('EVENT_PRESS_DETAIL_MORE_BTN', true);
            this.moreDescriptionFlag = true;
            this.moreDescription();
            break;

        case 'closeBtn':
            EventMediator.trigger('EVENT_PRESS_DETAIL_CLOSE_BTN', true);
            this.moreDescriptionFlag = false;
            this.normalDescription();
            break;

        }
    },

    moreDescription: function () {

        Volt.Nav.removeItem(this.moreButtonParent, true);
        this.moreButtonParent.hide();

        Volt.Nav.addItem(this.closeButtonParent, true);
        this.closeButtonParent.show();

        this.widget.height = Template.descriptionMaxLineHight;
        this.descriptionText.height = this.descriptionHeight;
        this.descriptionText.ellipsize = false;
        this.widget.getChild('detail-close-button').show();

        //if descriptionText's length is more than one page, add scroll and keyboardlistener to listen up/down key
        if (this.descriptionText.height > Template.descriptionMaxLineHight) {
            this.setScrollbar();

		    this.keyboardListener = new KeyboardListener;
		    this.keyboardListener.onKeyReleased = function (actor, keyCode) {
	            switch(keyCode){
	                case Volt.KEY_JOYSTICK_UP: {
	                    Volt.log("@@@UP key");
						this.textRollUp();
						break;
	                }
	                case Volt.KEY_JOYSTICK_DOWN: {
	                    Volt.log("@@@DOWN key");
						this.textRollDown();
	                    break;
	                }
	                default:
	                    return false;
	            }
				
	    	}.bind(this);
		    this.closeButton.addKeyboardListener(this.keyboardListener);
			this.renderArrow();  //add mouse listener
	        this.showArrow();
        }
        //Volt.Nav.reload();
        //Volt.Nav.focus(this.widget.getDescendant('detail-close-button'));
        Volt.Nav.focus(this.closeButtonParent);
    },

    normalDescription: function () {
        //        this.widget.getChild('detail-close-button').custom = {
        //            focusable: false
        //        };
        //        this.widget.getChild('detail-close-button').hide();
        //        this.widget.getChild('detail-more-button').custom = {
        //            focusable: true
        //        };
        //        this.widget.getChild('detail-close-button').hide();
        //        this.widget.getChild('detail-more-button').show();
        Volt.Nav.removeItem(this.closeButtonParent, true);
        this.closeButtonParent.hide();

        Volt.Nav.addItem(this.moreButtonParent, true);
        this.moreButtonParent.show();

        this.widget.height = Template.descriptionLineHeight;
        this.descriptionText.y = 0;
        this.descriptionText.height = Template.descriptionLineHeight;
        this.descriptionText.ellipsize = true;
        this.hideArrow();
        if (this.scroll) {
            this.scroll.clearTimeOut();
            this.scroll.destroy();
            this.scroll = null;
        }
        this.currentPage = 0; //reset 
        
		this.closeButton.removeKeyboardListener(this.keyboardListener);
		this.keyboardListener.destroy();
		this.keyboardListener = null;

		
        this.upArrow.removeMouseListener(this.mouseListener);
        this.downArrow.removeMouseListener(this.mouseListener);
		this.mouseListener.destroy();
		this.mouseListener = null;
		
        this.stopListening(EventMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, this.onShowScroll);

        //Volt.Nav.reload();
        //Volt.Nav.focus(this.widget.getDescendant('detail-more-button'));
        Volt.Nav.focus(this.moreButtonParent);

    },

    showArrow: function () {

        if (this.descriptionText.height <= Template.descriptionMaxLineHight) {
            this.upArrow.hide();
            this.downArrow.hide();
            return;
        }

        if (this.currentPage > 0) {
            this.upArrow.show();
            this.scroll.setValue(Math.ceil(this.currentPage / this.maxPage * 100));
            Volt.log("this.currentPage    " + this.currentPage + "~~~~~~~~~Math.ceil(this.currentPage/this.maxPage * 100)~~~~~~~~~~~~~" + Math.ceil(this.currentPage / this.maxPage * 100));
        } else {
            this.upArrow.hide();
            this.scroll.setValue(0);

        }

        if (this.currentPage < this.maxPage - 1) {
            this.downArrow.show();
        } else {
            this.downArrow.hide();

            this.scroll.setValue(100);
        }

        Volt.Nav.reload();
    },

    hideArrow: function () {

        if (this.upArrow) {
            this.upArrow.hide();

        }

        if (this.downArrow) {
            this.downArrow.hide();

        }
    },

    setScrollbar: function () {

        if (this.scroll) {
            return;
        }

        var scroll = new WinsetScroll({
            style: 3,
            parent: this.widget.getChild('detail-description-text-container'),
            x: 1236 - 10,
            y: 0,
            minValue: 0,
            maxValue: 100,
            value: 0,
            width: Template.descriptionMaxLineHight * 0.004630,
            height: Template.descriptionMaxLineHight,
        });

        //Volt.log(' ***********moredescription.setScrollBar********  ');

        scroll.timer = -1;

        scroll.setTimerOut = function () {
			//Volt.log("[common-content.js] scroll setTimerOut - hide scroll after 2 sec");
			scroll.show();
			if (scroll.timer) {
			Volt.clearTimeout(scroll.timer);
			}
			scroll.timer = Volt.setTimeout(function () {
			scroll.hide();
			}, 1000 * 2);
        };

        scroll.clearTimeOut = function () {
             //Volt.log("[common-content.js] scroll clearTimeOut - hide scroll");
            if (scroll.timer) {
                Volt.clearTimeout(scroll.timer);
            }
        };

        this.scroll = scroll;
        scroll.hide();


        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, this.onShowScroll);

        //judge mouse status
        if (voltapi.vconf.getValue('memory/window_system/input/cursor_visible')) {
            //print(' voltapi.vconf.getValue(memory/window_system/input/cursor_visible)   ' + voltapi.vconf.getValue('memory/window_system/input/cursor_visible'));
            this.onShowScroll(true);
        }

        return scroll;

    },

    onShowScroll: function (visible) {
        if (this.scroll) {
            if (visible) {
                this.scroll.show();
                this.scroll.clearTimeOut();
                this.scroll.setTimerOut();
            } else {
                this.scroll.hide();
                this.scroll.clearTimeOut();
                this.closeButton.setFocus();
            }
        }
    },


	textRollUp : function() {
         Volt.log("[detail-view.js] textRollUp    this.currentPage =  " + this.currentPage);
         Volt.log("[detail-view.js] textRollUp    this.descriptionText.y =  " + this.descriptionText.y);
		 if (this.currentPage > 0) {
            this.currentPage--;
            this.descriptionText.y = -this.currentPage * Template.descriptionMaxLineHight;
            this.scroll.show();
            this.scroll.clearTimeOut();
            this.scroll.setTimerOut();
	        this.showArrow();	                    
        }

	},


	
	textRollDown : function() {
         Volt.log("[detail-view.js] textRollDown    this.currentPage =  " + this.currentPage);
         Volt.log("[detail-view.js] textRollDown    this.descriptionText.y =  " + this.descriptionText.y);
		if (this.currentPage < (this.maxPage - 1)) {
            this.currentPage++;
            this.descriptionText.y = -this.currentPage * Template.descriptionMaxLineHight;
            this.scroll.show();
            this.scroll.clearTimeOut();
            this.scroll.setTimerOut();
	        this.showArrow();						
        }

	},


	renderArrow : function(){

	/*
        this.upArrow.addEventListener('OnMouseClick', function() {
            this.textRollUp();
        }.bind(this));
        
        this.upArrow.addEventListener('OnMouseOver', function() {
            Volt.Nav.blur();
            this.upArrow.opacity =255;
        }.bind(this));
        
        this.upArrow.addEventListener('OnMouseOut', function() {
            this.upArrow.opacity = 153;
        }.bind(this));
        
        this.downArrow.addEventListener('OnMouseClick', function() {
            this.textRollDown();
        }.bind(this));
        
        this.downArrow.addEventListener('OnMouseOver', function() {
            this.downArrow.opacity =255;
        }.bind(this));
        
        this.downArrow.addEventListener('OnMouseOut', function() {
            this.downArrow.opacity = 153;
        }.bind(this));

*/


	    this.mouseListener = new MouseListener;
		this.mouseListener.onMousePointerIn = function (actor, event) {
		    print('    onMousePointerIn     event  ', event);
		    if ( actor.id == 'detail-description-up-arrow' ){
	            Volt.Nav.blur();
	            this.upArrow.opacity =255;
	    	}else if ( actor.id == 'detail-description-down-arrow' ){
	            Volt.Nav.blur();
	            this.downArrow.opacity =255;
    		}
		}.bind(this);
		this.mouseListener.onMousePointerOut = function (actor, event) {
		    print('    onMousePointerOut     event  ', event);
		    if ( actor.id == 'detail-description-up-arrow' ){
	            this.upArrow.opacity =153;
	    	}else if ( actor.id == 'detail-description-down-arrow' ){
	            this.downArrow.opacity =153;
    		}
		}.bind(this);
		this.mouseListener.onMouseButtonReleased  = function (actor, event) {
		    print('    onMouseButtonReleased      event  ', event);
		    if ( actor.id == 'detail-description-up-arrow' ){
	            this.textRollUp();
	    	}else if ( actor.id == 'detail-description-down-arrow' ){
	            this.textRollDown();
    		}
		}.bind(this);

        this.upArrow.addMouseListener(this.mouseListener);
        this.downArrow.addMouseListener(this.mouseListener);

	},
	

    /**
     * When focued button, changed border
     * @method
     * @memberof DescriptionView
     * @param {object} widget  focued widget's object
     */
    onFocus: function (widget) {
        if (widget) {
            switch (widget.id) {
            case 'detail-more-button':
                //this.moreButton.color = Volt.hexToRgb('#ffffff', 95);
                //this.moreButton.getChild(0).src = Volt.getRemoteUrl('images/1080/common/btn_icon_more_f.png');
                this.moreButton.setFocus();
                EventMediator.trigger('EVENT_SHOW_TOOLTIP', widget);
                break;
            case 'detail-close-button':
                this.closeButton.setFocus();
                break;
            default:
                widget.color = Volt.hexToRgb('#ffffff', 95);
                widget.getChild(0).textColor = Volt.hexToRgb('#464646', 100);
                widget.getChild(0).font = '36px';
                widget.border = {
                    width: 2,
                    color: Volt.hexToRgb('#ffffff', 95)
                };
                break;
            }
        }
    },

    /**
     * When blured button, changed border
     * @method
     * @memberof DescriptionView
     * @param {object} widget  blured widget's object
     */
    onBlur: function (widget) {
        if (widget) {
            switch (widget.id) {
            case 'detail-more-button':
                //this.moreButton.color = Volt.hexToRgb('#ffffff', 0);
                //this.moreButton.getChild(0).src = Volt.getRemoteUrl('images/1080/common/btn_icon_more.png');
                this.moreButton.killFocus();
                EventMediator.trigger('EVENT_HIDE_TOOLTIP', widget);
                break;
            case 'detail-close-button':
                this.closeButton.killFocus();
                EventMediator.trigger('EVENT_HIDE_TOOLTIP', widget);
                break;
            default:
                widget.color = Volt.hexToRgb('#ffffff', 0);
                widget.getChild(0).textColor = Volt.hexToRgb('#ffffff', 80);
                if (widget.getChild(0) && widget.getChild(0).font) {
                    widget.getChild(0).font = '32px';
                }
                widget.border = {
                    width: 2,
                    color: Volt.hexToRgb('#ffffff', 80)
                };
                break;
            }
        }
    }
});

/**
 * @namespace DetailView
 * @name ButtonsView
 */
var ButtonsView = Volt.BaseView.extend({
    /** @lends ButtonsView.prototype */
    parent: null,

    StarOnURL: Volt.getRemoteUrl('images/1080/common/btn_icon_like_star_on.png'),
    StarOffURL: Volt.getRemoteUrl('images/1080/common/btn_icon_like_star_off.png'),
    StarHalfUrl: Volt.getRemoteUrl('images/1080/common/btn_icon_like_star_half.png'),
    ratingStarList: [],
    buttonColorPick: "#ffffff",
    bFirstFocus: true,

    btnListener: null,

    events: {
        //'NAV_SELECT ':'onSelect',
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    ////////////////////////////////////
    // Public Functions
    ////////////////////////////////////
    /**
     * Initialize DetailView
     * @name ButtonsView
     * @constructs
     */
    initialize: function (options) {
        this.parent = options.parent;
        btnView = this;
    },
    /**
     * Render buttons : Download, Rating
     * @method
     * @memberof ButtonsView
     */
    render: function (textColorPick) {
        Volt.log();

        //this.btnContainer = Volt.loadTemplate(Template.buttonContainer);
        this.btnContainer = Volt.loadTemplate(Template.buttonContainer, null, this.parent.widget.getDescendant('detail-button-area'));
        this.setWidget(this.btnContainer);

        var btnStyle = {
            style: WinsetBtn.ButtonStyle.Button_image_O_Style_G_FOCUS1,
            buttonType: WinsetBtn.ButtonType.BUTTON_TEXT,
            resoultion: tvResoultion,
        };

        var downloadBtnBG = this.widget.getChild('download_button_widget');
        this.downloadBtn = PanelCommon.loadTemplate(Template.downloadBtn, btnStyle, downloadBtnBG);
        this.downloadBtn.setText({
            state: "all",
            text: DetailVM.getDownloadBtnName()
        });

        if (Volt.DeviceInfoModel.get('focusZoom')) {
            this.downloadBtn.setFontSize({
                state: "normal",
                size: (Volt.APPS720P) ? 20 : 31
            });
            this.downloadBtn.setFontSize({
                state: "focused",
                size: (Volt.APPS720P) ? 24 : 36
            });
            this.downloadBtn.setFontSize({
                state: "roll-over",
                size: (Volt.APPS720P) ? 24 : 36
            });
            this.downloadBtn.setFontSize({
                state: "focused-roll-over",
                size: (Volt.APPS720P) ? 24 : 36
            });
            this.downloadBtn.setFontSize({
                state: "selected",
                size: (Volt.APPS720P) ? 24 : 36
            });
            this.downloadBtn.setFontSize({
                state: "disabled",
                size: (Volt.APPS720P) ? 20 : 31
            });
        }

        // Rating Button
        /*this.ratingBtn = Volt.loadTemplate(Template.button, {
			id   : 'detail-rating-button',
			name : ''
		});
		this.ratingBtn.x = Template.buttonGap * 1;*/
        var ratingBtnBG = this.widget.getChild('rating_button_widget');
        this.ratingBtn = PanelCommon.loadTemplate(Template.ratingBtn, btnStyle, ratingBtnBG);

       
		this.ratingBtn.setBackgroundColor({
			state: "roll-over",
			color: { r: 255, g: 255, b: 255, a: 0 },
		});


		this.ratingBtn.setBorder({
			state: "roll-over",
			border: {
				width: 2,
				color: { r: 255, g: 255, b: 255, a: 204 }
			}
		});

		this.ratingBtn.setIconAlpha({
			state: "normal",
			alpha: 255
		});

        for (var i = 0; i < MAX_RATING_NUM; i++) {
            this.ratingStarList[i] = Volt.loadTemplate(Template.btnStar);
            this.ratingStarList[i].x = Volt.width * 0.0609375 + Volt.width * 0.01875 * i;
            //this.ratingBtn.addChild(this.ratingStarList[i]);
            ratingBtnBG.addChild(this.ratingStarList[i]);
        }

        //this.btnContainer.addChild(this.ratingBtn);
        this.updateRatingBtn();

        if (!DetailVM.isDownloadableApp()) {
            this.showLowMemoryMessage();
        }

        if (DetailVM.get('isInstalling')) {
            this.setProgressBar(DetailVM.get('nInitProgress'));
        }

        ////
        this.addListeners();
        //this.setDimRatingButton();

        Volt.Nav.reload();
        return this;
    },

    remove: function () {
        this.removeListeners();
    },

    /**
     * Show this widget
     * @method
     * @memberof ButtonsView
     */
    show: function () {
        /*this.widget.getChild('download_button_widget').custom = {
    		focusable : true
    	};

    	if( !DetailVM.get('isDownloaded') ){
	    	this.widget.getChild('rating_button_widget').custom = {
	    		focusable : true
	    	};
    	}else{
    		this.ratingBtn.custom = {
	    		focusable : true
	    	};
    	}*/
        Volt.log("rating_button_widget focusable true");
        this.listenTo(EventMediator, 'EVENT_UPDATE_DOWNLOAD_BUTTON', this.updateDownloadBtn);
        this.listenTo(DetailVM, 'change:userRating', this.updateRatingBtn);
        this.listenTo(DetailVM, 'change:isInstalling', this.setProgressBar);
        if (this.widget.getChild('download_button_widget')) {
            btnView.widget.getChild('download_button_widget').custom = {
                focusable: true
            };
        }

        if (this.widget.getChild('rating_button_widget')) {
            btnView.widget.getChild('rating_button_widget').custom = {
                focusable: true
            };
        }

        this.ratingBtn.addListener(this.btnListener);
        this.downloadBtn.addListener(this.btnListener);
        this.widget.show();
        Volt.Nav.reload();
    },

    /**
     * Hide this widget
     * @method
     * @memberof ButtonsView
     */
    hide: function () {
        this.stopListening(DetailVM, 'change:userRating');
        this.stopListening(DetailVM, 'change:isInstalling');
        this.stopListening(EventMediator, 'EVENT_UPDATE_DOWNLOAD_BUTTON');

        if (this.widget.getChild('download_button_widget')) {
            this.widget.getChild('download_button_widget').custom = {
                focusable: false
            };
        }

        Volt.log("rating_button_widget focusable flase");

        if (this.widget.getChild('rating_button_widget')) {
            this.widget.getChild('rating_button_widget').custom = {
                focusable: false
            };
        }
        //this.ratingBtn.killFocus();
        this.ratingBtn.removeListener(this.btnListener);
        this.downloadBtn.removeListener(this.btnListener);
        Volt.Nav.reload();
        //this.hideToolTip();
        EventMediator.trigger('EVENT_HIDE_TOOLTIP');

        this.widget.hide();
    },

    setFocus: function () {
        Volt.Nav.focus(this.widget.getChild('download_button_widget'));
    },

    addListeners: function () {
        this.listenTo(DetailVM, 'change:userRating', this.updateRatingBtn);
        this.listenTo(DetailVM, 'change:isInstalling', this.setProgressBar);
        //this.listenTo(DetailVM, 'change:isDownloaded', this.setDimRatingButton);
        this.listenTo(EventMediator, 'EVENT_PRESS_DETAIL_MORE_BTN', this.hide);
        this.listenTo(EventMediator, 'EVENT_PRESS_DETAIL_CLOSE_BTN', this.show);
        this.listenTo(EventMediator, 'EVENT_DETAIL_SUCCESS_DOWNLOAD', this.updateProgressBar);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_NOSPACE, this.showLowMemoryMessage);
        this.listenTo(EventMediator, 'EVENT_DETAIL_SET_BUTTON_FOCUS', this.setFocus);
        this.listenTo(EventMediator, CommonDefines.Event.MSGBOX_BUTTON, this.processMsgBoxEvent, this); //add by yangpei 20141110
        this.listenTo(EventMediator, 'EVENT_UPDATE_DOWNLOAD_BUTTON', this.updateDownloadBtn);
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_FOCUS_ZOOM, this.updateBtnFont);

        var btnListener = this.btnListener = new ButtonListener();
        btnListener.onButtonClicked = function (button, type) {
            this.onSelect(button);
        }.bind(this);


        this.downloadBtn.addListener(btnListener);
        this.ratingBtn.addListener(btnListener);
    },

    removeListeners: function () {
        this.stopListening();

        this.ratingBtn.removeListener(this.btnListener);
        this.downloadBtn.removeListener(this.btnListener);
    },

    ////////////////////////////////////
    // Private Functions
    ////////////////////////////////////
    setDimRatingButton: function () {

        if (this.ratingBtn) {
            if (!DetailVM.get('isDownloaded')) {
                this.ratingBtn.custom = {
                    focusable: false
                };

                // this.setRatingStarOpacity(0.3);
                this.ratingBtn.opacity = Volt.getPercentage(30);
                this.ratingBtn.border = {
                    width: 2,
                    color: Volt.hexToRgb('#ffffff')
                };

            } else {
                this.ratingBtn.custom = {
                    focusable: true
                };

                this.ratingBtn.opacity = Volt.getPercentage(100);

                this.onBlur(this.ratingBtn);
            }

            Volt.Nav.reload();
        }
    },

    setRatingStarOpacity: function (opacity) {

        if (this.ratingStarList && opacity) {
            var nOpacity = 255 * opacity;
            for (var i = 0; i < MAX_RATING_NUM; i++) {
                this.ratingStarList[i].opacity = nOpacity;
            }
        }

    },

    showLowMemoryMessage: function () {
        if (this.lowMemoryText) {
            this.lowMemoryText.show();
        } else {
            this.lowMemoryText = Volt.loadTemplate(Template.downloadGuideText);
            this.btnContainer.addChild(this.lowMemoryText);
        }
    },
    /**
     * When changed download button's state, updated both button's name and progressBar
     * @method
     * @memberof ButtonsView
     */
    updateDownloadBtn: function () {
        Volt.log("detailView.js:updateDownloadBtn");
        if (this.downloadBtn) {
            Volt.log('updateDownloadBtn:text is ' + +DetailVM.getDownloadBtnName());
            this.downloadBtn.setText({
                state: "all",
                text: DetailVM.getDownloadBtnName()
            });
        }
    },

    updateBtnFont: function () {
        Volt.log("detailView.js:updateBtnFont focuszoom is " + Volt.DeviceInfoModel.get('focusZoom'));
        if (this.downloadBtn) {
            if (Volt.DeviceInfoModel.get('focusZoom')) {
                this.downloadBtn.setFontSize({
                    state: "normal",
                    size: (Volt.APPS720P) ? 20 : 31
                });
                this.downloadBtn.setFontSize({
                    state: "focused",
                    size: (Volt.APPS720P) ? 24 : 36
                });
                this.downloadBtn.setFontSize({
                    state: "roll-over",
                    size: (Volt.APPS720P) ? 24 : 36
                });
                this.downloadBtn.setFontSize({
                    state: "focused-roll-over",
                    size: (Volt.APPS720P) ? 24 : 36
                });
                this.downloadBtn.setFontSize({
                    state: "selected",
                    size: (Volt.APPS720P) ? 24 : 36
                });
                this.downloadBtn.setFontSize({
                    state: "disabled",
                    size: (Volt.APPS720P) ? 20 : 31
                });
            } else {
                this.downloadBtn.setFontSize({
                    state: "normal",
                    size: (Volt.APPS720P) ? 17 : 26
                });
                this.downloadBtn.setFontSize({
                    state: "focused",
                    size: (Volt.APPS720P) ? 20 : 30
                });
                this.downloadBtn.setFontSize({
                    state: "roll-over",
                    size: (Volt.APPS720P) ? 20 : 30
                });
                this.downloadBtn.setFontSize({
                    state: "focused-roll-over",
                    size: (Volt.APPS720P) ? 20 : 30
                });
                this.downloadBtn.setFontSize({
                    state: "selected",
                    size: (Volt.APPS720P) ? 20 : 30
                });
                this.downloadBtn.setFontSize({
                    state: "disabled",
                    size: (Volt.APPS720P) ? 17 : 26
                });
            }
        }
    },
    /**
     * When start download app, set to show progressbar
     * @method
     * @memberof ButtonsView
     * @param  {object}  eventInfo  app_id, value
     */
    setProgressBar: function (nProgress) {
        Volt.log("detailView.js:setProgressBar");
        if (DetailVM.get('isInstalling')) {
            if (this.progressbarView) {
                this.progressbarView.show();
            } else {
                var value;
                if (nProgress && nProgress > 0) {
                    value = nProgress;
                }
                this.progressbarView = new ProgressBarView({
                    id: 'detail-download-button' + DetailVM.get('id'),
                    parent: this.downloadBtn,
                    value: value,
                });
                this.downloadBtn.addChild(this.progressbarView.render().widget);
            }

            this.listenTo(EventMediator, CommonDefines.Event.DOWNLOADING, this.updateProgressBar);
        } else {

            if (this.progressbarView) {
                this.progressbarView.hide();
                delete this.progressbarView;
                this.progressbarView = null;
            }

            this.stopListening(EventMediator, CommonDefines.Event.DOWNLOADING);
        }

        this.updateDownloadBtn();
    },

    /**
     * When changed progress to install app, updated progressbar
     * @method
     * @memberof ButtonsView
     * @param  {object}  widget  focued widget
     */
    updateProgressBar: function (eventInfo) {
        if (eventInfo && eventInfo.app_id == DetailVM.get('id') && eventInfo.result) {
            if (this.progressbarView) {
                this.progressbarView.updateProgressBar(eventInfo.result);
            }
        }
    },

    /**
     * When changed userRating updated rated stars
     * @method
     * @memberof ButtonsView
     */
    updateRatingBtn: function () {
        if (!this.ratingStarList) {
            return;
        }

        var nUserRating = DetailVM.get('userRating');

        for (var i = 0; i < MAX_RATING_NUM; i++) {

            if (i < nUserRating) {
                this.ratingStarList[i].src = this.StarOnURL;
            } else {
                this.ratingStarList[i].src = this.StarOffURL;
            }
        }
    },

    /**
     * When selected button, to handle calling function.
     * @method
     * @memberof ButtonsView
     * @param {object} widget selected widget's object
     */
    onSelect: function (widget) {
        if (widget) {
            Volt.log("widget.id: " + widget.id);

            // widget.border  = {
            // 		width : 3 , color :  Volt.hexToRgb('#fbba2d', 100)
            // };

            if (Volt.DeviceInfoModel.get('networksStatus') == "NG") {
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
                return;
            }



            switch (widget.id) {
            case "downloadBtn":
                var appID = DetailVM.get('id');

                if (DownloadedAppsMgr.isDownloaded(appID)) {
                    DetailVM.runApp();
                    Volt.KpiMapper.addEventLog('OPEN', {
                        d: {
                            appid: appID,
                        }
                    });
                } else {
                    var result = AppInstallMgr.getInstallList(appID);

                    if (result && result.app_id == appID) {
                        DetailVM.cancelInstallApp();
                        Volt.KpiMapper.addEventLog('CANCEL', {
                            d: {
                                appid: appID,
                            }
                        });

                    } else {
                        DetailVM.installApp();
                        Volt.KpiMapper.addEventLog('DOWNLOAD', {
                            d: {
                                appid: appID,
                            }
                        });

                    }
                }
                break;
            case "ratingBtn":
                if (DetailVM.get('isDownloaded')) {
                    DetailVM.showRatingPopup();
                } else {
                    CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_DLD_BEFORE_RATE);
                }
                // Models.externalStorageModel.checkConnectUSB(DetailVM.get('id'));
                break;
            }
        }
    },
    processMsgBoxEvent: function (data) {
        Volt.log('[detail-view.js] processMsgBoxEvent:type is:' + data.msgBoxtype + " eventType is:" + data.eventType);
        if (data.eventType == CommonDefines.Event.SELECT_BTN1) {
            switch (data.msgBoxtype) {
            case CommonDefines.MsgBoxType.MSGBOX_TYPE_DLD_BEFORE_RATE:
                Volt.log('[detail-view.js] processMsgBoxEvent:start to download app');
                if (DetailVM.get('isDownloaded') == false) {
                    var appID = DetailVM.get('id');
                    DetailVM.installApp();
                    Volt.KpiMapper.addEventLog('DOWNLOAD', {
                        d: {
                            appid: appID,
                        }
                    });
                }
                Volt.Nav.focus(this.widget.getChild('download_button_widget'));
                break;
            default:
                break;
            }
        } else if (data.eventType == CommonDefines.Event.SELECT_BTN2) {
            Volt.log('[detail-view.js] processMsgBoxEvent:SELECT_BTN2');
        }
    },
    /**
     * When focued focus on button, changed border
     * @method
     * @memberof ButtonsView
     * @param  {object}  widget  focued widget
     */
    onFocus: function (widget) {
        if (widget) {
            if (widget.id == 'download_button_widget') {
                this.downloadBtn.setFocus();
                if (this.bFirstFocus) {
                    CommonFunctions.voiceGuide(DetailVM.get('title') + ' ' + DetailVM.getDownloadBtnName() + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON'));
                    this.bFirstFocus = false;
                } else {
                    CommonFunctions.voiceGuide(DetailVM.getDownloadBtnName() + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON'));
                }
            } else {
                this.ratingBtn.setFocus();
                this.StarOnURL = Volt.getRemoteUrl('images/1080/common/btn_icon_like_star_on_f.png'),
                this.StarOffURL = Volt.getRemoteUrl('images/1080/common/btn_icon_like_star_off_f.png'),
                this.StarHalfUrl = Volt.getRemoteUrl('images/1080/common/btn_icon_like_star_half_f.png'),
                this.updateRatingBtn();

                EventMediator.trigger('EVENT_SHOW_TOOLTIP', widget);

                CommonFunctions.voiceGuide(Volt.i18n.t('TV_SID_RATING_POINT') + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON'));
            }
        }
    },

    /**
     * When blured on button, changed border
     * @method
     * @memberof ButtonsView
     * @param  {object}  widget  focued widget
     */
    onBlur: function (widget) {
        if (widget) {

            if (widget.id == 'download_button_widget') {
                //this.downloadBtn.killFocus();//DF141204-01069 Lock the app Detail page - open selected button flashes.
            } else {
                this.StarOnURL = Volt.getRemoteUrl('images/1080/common/btn_icon_like_star_on.png'),
                this.StarOffURL = Volt.getRemoteUrl('images/1080/common/btn_icon_like_star_off.png'),
                this.StarHalfUrl = Volt.getRemoteUrl('images/1080/common/btn_icon_like_star_half.png'),
                this.updateRatingBtn();

                EventMediator.trigger('EVENT_HIDE_TOOLTIP');
                //this.hideToolTip(widget);
            }
        }
    },
});

/**
 * @name ScreenshotView
 */
var ScreenshotView = Volt.BaseView.extend({

    thumbnail: null,

    events: {
        //'NAV_SELECT' : 'onSelect',
        'NAV_BLUR': 'onBlur',
        'NAV_FOCUS': 'onFocus'
    },

    initialize: function (model, type) {
        this.VM = model;
    },

    bindListener: function () {
        //this.listenTo(this.VM, 'change', this.renderChange);     
        this.listenTo(this.VM, 'DESTROY_VIEW', this.onDestroyView);
    },

    unbindListener: function () {
        this.stopListening();
    },

    onDestroyView: function () {
        Volt.log('[DetailView] onDestroyView');
        this.unbindListener();
    },
    render: function (index, iThumbnail) {
        Volt.log('[DetailView]index ' + index);
        var data = this.VM.toJSON();
        var self = this;
        var iconURL = data.icon;

        if (iThumbnail) {

            this.thumbnail = iThumbnail;
            iconURL = data.icon.replace("{w}", CommonDefines.ImageSize.SCREENSHOT_WIDTH).replace("{h}", CommonDefines.ImageSize.SCREENSHOT_HEIGHT);
            var thumbnailStyle = _.clone(Template.screenShotThumbnailStyle);
            this.thumbnail.setFoveaImageScaleFactor(0.1);
            this.thumbnail.setFoveaImageInterpolatorType(0);
            thumbnailStyle.image.src = iconURL;
            this.thumbnail.setThumbnailStyle(thumbnailStyle);
            this.thumbnail.dim(false);
            //this.thumbnail.setTTSText({text: data.title || ''});
            this.bindListener();
        }
        return this;
    },
    onSelect: function (index) {
        Volt.log("ScreenshotView onSelect");
        Backbone.history.navigate('detail/popup/screenShot/' + index, {
            trigger: true
        });
    },
    onBlur: function () {

    },

    onFocus: function () {

    },
    show: function () {

        var data = this.VM.toJSON();
        var template = '';
        var id = '';
    },

});


/**
 * @name RelatedAppView
 */
var RelatedAppView = Volt.BaseView.extend({
    /** @lends RelatedAppView.prototype */
    template: GridListTemplate.getThumbnailTemplate('THUMB_RELATED'),

    thumbnail: null, // Thumbnail Widget
    thumbListener: null, // Thumbnail Listener for color pick
    
    titleWidth: null,

    // events: {
    // //'NAV_SELECT' : 'onSelect',
    // 'NAV_BLUR': 'onBlur',
    // 'NAV_FOCUS': 'onFocus'
    // },

    /**
     * Initialize RelatedAppView
     * @name RelatedAppView
     * @constructs
     * @param {object} model each Related app model
     */
    initialize: function (model, type) {
        this.VM = model;
    },

    /**
     * Render related app
     * @method
     * @memberof RelatedAppView
     * @param {number} index  index of this relatedApp
     * @param {object} widget this widget's object
     */
    render: function (index, iThumbnail) {
        Volt.log('[RelatedAppView]index ' + index);
        var data = this.VM.toJSON();
        var self = this;
        var iconURL = data.icon;

        if (iThumbnail) {

            this.thumbnail = iThumbnail;

            if (data.icon.lastIndexOf('png') != -1) {
                iconURL = data.icon.replace("{w}", CommonDefines.ImageSize.DETAIL_PNG_ICON_WIDTH).replace("{h}", CommonDefines.ImageSize.DETAIL_PNG_ICON_HEIGHT);
            } else {
                iconURL = data.icon.replace("{w}", CommonDefines.ImageSize.DETAIL_JPG_ICON_WIDTH).replace("{h}", CommonDefines.ImageSize.DETAIL_JPG_ICON_HEIGHT);
            }

            var thumbnailStyle = _.clone(this.template);

            thumbnailStyle.image.src = iconURL;
            thumbnailStyle.information.text1.text = data.title;

            this.thumbnail.setThumbnailStyle(thumbnailStyle);
            
            // Update downloaded icon state
            this.update(data.isDownloaded, data.title);

            this.thumbListener = new ThumbnailListener;
            this.thumbListener.onImageReady = function (thumbnail, id, success) {

                if (success == true) {
                    var informationColorpick = thumbnail.getInformationColorPicking();
                    thumbnail.color = {
                        r: informationColorpick.r,
                        g: informationColorpick.g,
                        b: informationColorpick.b,
                        a: 255
                    };
                } else { // parse false, set default image instead
                    Volt.log("********************");
                    thumbnail.timeId = Volt.setTimeout(function () {
                        thumbnail.setContentImage(GridListTemplate.defaultScreenShot);//getRemoteUrl('images/1080/common/apps_screenshot_default.png'));
                        thumbnail.timeId = null;
                    }, 0);
                }
            };
            
            this.thumbnail.addThumbnailListener(this.thumbListener);
            this.thumbnail.setDimBackgroundColor({
                r: 0,
                g: 0,
                b: 0,
                a: 153
            });
            
            this.thumbnail.dim(false);
            this.thumbnail.setProgressRange(0, 100);
            
            this.setWidget(this.thumbnail);
            this.thumbnail.customTitle = data.title || '';
            //this.thumbnail.setTTSText({text: data.title || ''});
            this.bindListener();
        }
        return this;
    },
    remove: function () {
        if (this.thumbnail) {
            this.thumbnail.removeThumbnailListener(this.thumbListener);
            this.unbindListener();

            if (this.thumbnail.timeId) {
                Volt.clearTimeout(this.thumbnail.timeId);
                this.thumbnail.timeId = null;
            }

            this.thumbnail = null;
            this.thumbListener = null;
        }
    },

    /**
     * show view
     * @method
     */
    show: function () {

        var data = this.VM.toJSON();
        var template = '';
        var id = '';

        if (this.appInfoProgressView == null) {
            this.appInfoProgressView = new AppInfoProgressView(this.thumbnail, this.VM);
        }

        this.appInfoProgressView.show();
    },

    update: function(bDownloaded, text) {
        if (!text && this.titleWidth === null) {
            return;
        }
        
        if (this.titleWidth === null) {
            // store overflow state of title
            this.titleWidth = Volt.getTextWidth({
                text: text,
                font: this.template.information.text1.font
            });
        }
        
        var x = this.template.information.text1.x,
            width = this.template.information.text1.width,
            iconWidth = this.template.information.icon1.width;
        
        if (bDownloaded) {
            this.thumbnail.visualizeInformationIcon(true, 'icon1');
            
            if (this.titleWidth > width - iconWidth) {
                width -= iconWidth;
            } else if (this.titleWidth > width - iconWidth * 2) {
                x -= iconWidth - (width - this.titleWidth) / 2;
            }
        } else {
            this.thumbnail.visualizeInformationIcon(false, 'icon1');
        }
        
        this.thumbnail.setElementAllocation('information-text1', {
            x: x,
            width: width
        });
    },

    bindListener: function () {
        this.listenTo(this.VM, 'change', this.renderChange);
        this.listenTo(this.VM, 'DESTROY_VIEW', this.remove);
        this.showProgressBar();
    },

    unbindListener: function () {
        this.stopListening();
        this.hideProgressBar();
    },

    // onDestroyView: function () {
    // Volt.log('[DetailView] onDestroyView');
    // this.unbindListener();
    // },

    /**
     * When select related app, go to detail screen.
     * @method
     * @memberof RelatedAppView
     * @param {number} index  index of this relatedApp
     */
    renderChange: function (changedModel) {
        if (_.keys(changedModel.changed)[0] == 'isDownloaded') {
            // if (changedModel.changed.isDownloaded) {
                // this.thumbnail.setElementAllocation('information-text1', {
                    // width: partialTextWidth
                // });
                // this.thumbnail.visualizeInformationIcon(true, 'icon1');
            // } else {
                // this.thumbnail.visualizeInformationIcon(false, 'icon1');
            // }
            
            // Update downloaded icon state
            this.update(changedModel.changed.isDownloaded);
        }
    },

    /**
     * Call when it is blurred
     * @method
     * @memberof RelatedAppView
     */
    // onBlur: function () {
    // 
    // },

    /**
     * Call when it is focused
     * @method
     * @memberof RelatedAppView
     */
    // onFocus: function () {
    // 
    // },

    showProgressBar: function () {
        try {
            if (this.AppInfoProgressView == null) {
                this.AppInfoProgressView = new AppInfoProgressView(this.thumbnail, this.VM);
            }
            this.AppInfoProgressView.updateThumbnail(this.thumbnail);
            this.AppInfoProgressView.show();
        } catch (e) {

        }
    },
    /**
     * hide view
     * @method
     */
    hideProgressBar: function () {

        if (this.AppInfoProgressView) {
            this.AppInfoProgressView.hideProgressBar();
        }
    },
});

exports = DetailView;

/*
 *     onChangeCursor: function (visible) {

        if (this.pageBackArrow) {
            if (visible) {
                this.pageBackArrow.show();
                this.exitArrow.show();
            } else {
                this.pageBackArrow.hide();
                this.exitArrow.hide();
            }
        }
    },
    */