var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require('modules/underscore.js')._,
    CommonDefines = Volt.require('app/common/commonDefines.js');

var PanelCommon = Volt.require('lib/panel-common.js');
var WinsetScroll = Volt.require("WinsetUIElement/winsetScroll.js");
PanelCommon.mapWidget('WinsetScroll', WinsetScroll);
var EventMediator = Volt.require('app/common/eventMediator.js');

var GridlistView = Volt.BaseView.extend({

    gridListControl: null,

    gridListControlParam: null,
    listeners: null,

    bHandleKeyRelease: false,
    bLongPress: false,
    bFocused: false,
    bshowScroll: true,

    rows: 0,
    cols: 0,

    events: {
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    dataPointers: [],

    initialize: function(options) {

        // options: {
        //     gridListControlParam: {
        //         x : 0, y : 0, width : 1920, height : 864,
        //         titleSpace : 0, groupSpace : 0, cellSpace : 0,
        //         focusRangeStartOffset : 0, focusRangeEndOffset : 0,
        //         itemWidth : 196, itemHeight : 288
        //     },
        //     
        //     listeners: {
        //         onDrawLoadData
        //         onDrawUpdateData
        //         onItemPress
        //         onGridFocus
        //         onGridBlur
        //         onEnterKeyLongPressed
        //     }
        // }
        
        this.gridListControlParam = options.gridListControlParam;
        this.listeners = options.listeners;
		this.bshowScroll = options.bShowScroll != undefined ? options.bShowScroll : true;

        this.gridListControl = this.initGridListControl(options.gridListControlParam);
        this.setWidget(this.gridListControl);

        // Relations with volt-nav
        this.widget.onKeyEvent = _.bind(this.onKeyEvent, this);
        this.gridListControl.widgetType = 'NativeGrid';


	    var keyboardListener = new KeyboardListener;
	    keyboardListener.onKeyReleased = function (actor, keyCode) {
	        if (keyCode == Volt.KEY_JOYSTICK_OK) {
		        Volt.err('[GridListView] keyboardListener.onKeyReleased');
                if (!this.bLongPress) {
                    var focusItem = actor.getFocusItemIndex();
					var data = actor.getData(focusItem.groupIndex,focusItem.itemIndex);
                    this.listeners.onItemPress(this.getFocusedWidget(), focusItem,data);
                }else{
			        Volt.err('[GridListView] ************************trigger    EVENT_LONGPRESS_RELEASE*******************************');
				     EventMediator.trigger(CommonDefines.Event.EVENT_LONGPRESS_RELEASE,actor);
            	}
	            this.bLongPress = false;
	        }
	    }.bind(this);
	    this.gridListControl.addKeyboardListener(keyboardListener);	

    },
    render: function(collection) {
        Volt.err('[GridListView] render');

        // Add empty cells
        var gridInfo = this.gridListControlParam;

        this.rows = Math.floor(gridInfo.height / gridInfo.itemHeight);
        this.cols = Math.ceil(collection.length / this.rows);

        this.gridListControl.addRegularGrid({
            groupIndex: 0,
            styleIndex: 0,
            columnNumber: this.cols,
            rowNumber: this.rows,
            columnWidth: gridInfo.itemWidth,
            rowHeight: gridInfo.itemHeight
        });

        // Add data
        var data = null;
        for (var i = 0; i < collection.length; i++) {
            this.addData(collection.at(i), i);
        }
       this.gridListControl.loadData();
	this.gridListControl.enableFocus();
       //this.gridListControl.showFocus('false');
	//this.gridListControl.hideFocus('true');
        return this;
    },

    onFocus: function() {
        Volt.err('[GridListView] onFocus');

        // below 2 APIs makes onEnterKeyLongPressed work.
        if( this.gridListControl ){
            this.gridListControl.enableFocus();
            this.gridListControl.setFocus();
            this.gridListControl.showFocus('false');
			//this.gridListControl.showWithAnimation();
        }
        
        this.bFocused = true;
        this.listeners.onGridFocus(this.getFocusedWidget());
    },

    onBlur: function() {
        Volt.err('[GridListView] onBlur');
        if( this.gridListControl ){
            this.gridListControl.hideFocus('true');
			//this.gridListControl.hideWithAnimation();
        }
        this.bFocused = false;
        this.listeners.onGridBlur(this.getFocusedWidget());
    },

    onItemPress: function() {
        Volt.err('[GridListView] onItemPress');

    },

    onKeyEvent: function(keycode, keytype) {
        Volt.err('[GridListView] onKeyEvent   keytype    ' +  keytype);

/*
        if (keycode == Volt.KEY_JOYSTICK_OK) {
            
            if (keytype == Volt.EVENT_KEY_PRESS) {
                this.bHandleKeyRelease = true;
            }

            if (keytype == Volt.EVENT_KEY_RELEASE) {

                if (!this.bHandleKeyRelease) { return; }
                this.bHandleKeyRelease = false;

                if (!this.bLongPress) {
                    var focusItem = this.widget.getFocusItemIndex();
					var data = this.widget.getData(focusItem.groupIndex,focusItem.itemIndex);
                    this.listeners.onItemPress(this.getFocusedWidget(), focusItem,data);
                }
            }
            this.bLongPress = false;
        }
*/
        if (keytype == Volt.EVENT_KEY_RELEASE) {
            return;
        }

        switch (keycode) {
            case Volt.KEY_JOYSTICK_UP:
                return this.gridListControl.moveFocus('Up');
            case Volt.KEY_JOYSTICK_DOWN:
                return this.gridListControl.moveFocus('Down');
            case Volt.KEY_JOYSTICK_LEFT:
                return this.gridListControl.moveFocus('Left');
            case Volt.KEY_JOYSTICK_RIGHT:
                return this.gridListControl.moveFocus('Right');
            default:
                return false;
        }
    },

    getFocusedWidget: function() {
        var itemIdx = this.gridListControl.getFocusItemIndex(),
            focusedWz = this.getWidget(itemIdx.groupIndex, itemIdx.itemIndex);

        Volt.err('[GridListView] getFocusedWidget ' + JSON.stringify(itemIdx));
        Volt.err('[GridListView] getFocusedWidget returns ' + focusedWz);
        return focusedWz;
    },

    getWidget: function(groupIndex, itemIndex) {
        var itemData = null, wz = null;
        if (groupIndex >= 0 && itemIndex >= 0) {
            itemData = this.gridListControl.getData(groupIndex, itemIndex);
            
            if (itemData) {
                wz = itemData.thumbnail;
            }
        }

        return wz;
    },

    addData: function(model, index) {
        Volt.log('[GridListView] addData');

        var data = new Data();
        data.isReady = false;

        data.model = model;
        data.thumbnail = null; // this property will set at onDraw()

        // Avoid garbage collecting Halo Data instances
        this.dataPointers.push(data);

        if( String(index) ){
            data._index = index;    
        }

        this.gridListControl.addData({
            groupIndex: 0,
            data: data
        });
    },

    addItem: function(model) {
        Volt.log('[GridListView] addItem');

        if (this.isFull()) {
            this.addColumn();
        }

        this.addData(model);
        this.gridListControl.loadData();
    },

    removeItem: function(fromItemIndex, toItemIndex) {
        Volt.err('[GridListView] removeItem ' + fromItemIndex + ',' + toItemIndex);
        
        this.gridListControl.removeData({
            groupIndex : 0,
            fromItemIndex : fromItemIndex,
            toItemIndex : toItemIndex,
            needUpdate : true
        });
    },

    isFull: function() {
        var groupIndex = 0, styleIndex = 0,
            columnCount, itemCount, bFull;

        columnCount = this.gridListControl.columnCount(groupIndex, styleIndex);
        itemTotal = this.gridListControl.itemCount(groupIndex);

        bFull = (columnCount * this.rows) <= itemTotal;
        Volt.err('[GridListView] isFull returns ' + bFull);
        
        return bFull;
    },

    addColumn: function() {
        Volt.err('[GridListView] addColumn');

        var groupIndex = 0, styleIndex = 0, 
            columnWidth = this.gridListControlParam.itemWidth,
            rowHeight = this.gridListControlParam.itemHeight,
            columnIndex;

        columnIndex = this.gridListControl.addColumn({
            groupIndex: groupIndex,
            styleIndex: styleIndex,
            columnWidth: columnWidth
        });

        for (var i = 0; i < this.rows; i++) {
            this.gridListControl.addRowToColumn({
                groupIndex : groupIndex,
                styleIndex : styleIndex,
                columnIndex : columnIndex,
                rowHeight : rowHeight
            });
        }
    },

    initGridListControl: function(options) {
        Volt.err('[GridListView] initGridListControl');

        // options: {
        //     x : 0, y : 0, width : 1920, height : 864,
        //     titleSpace : 0, groupSpace : 0, cellSpace : 0,
        //     focusRangeStartOffset : 0, focusRangeEndOffset : 0,
        //     itemWidth : 196, itemHeight : 288
        // }

        // RendererProvider & Renderer
        var rendererProvider = new RendererProvider();
        rendererProvider.funcGetRenderer = _.bind(getRenderer, this);

        // GridListControlListener
        var gridListener = new GridListControlListener();
        gridListener.onItemLoaded = _.bind(onItemLoaded, this);
        gridListener.onItemUnloaded = _.bind(onItemUnloaded, this);
        gridListener.onFocusChanged = _.bind(onFocusChanged, this);
        gridListener.onFocusChangeStart = _.bind(onFocusChangeStart, this);
        gridListener.onMoveOut = _.bind(onMoveOut, this);
        gridListener.onItemIndexChanged = _.bind(onItemIndexChanged, this);
        gridListener.onItemClicked = _.bind(onItemClicked, this);
        gridListener.onEnterKeyLongPressed = _.bind(onEnterKeyLongPressed, this);

        //var scroll = getScroll(options);

        var gridListControl = new GridListControl(options);
        //gridListControl.attachScrollBar(scroll);
        gridListControl.setRendererProvider(rendererProvider);
        gridListControl.addListListener(gridListener);
        gridListControl.addGroup(1);
        gridListControl.addDataGroup(1);
        gridListControl.enlargeFocusItem(20, 20);
        gridListControl.setAnimationDuration(200);
        gridListControl.addStyle(1);
        gridListControl.setStyle(0);
        gridListControl.shadowEffectFlag = false;
        //gridListControl.showFocus('false');
        gridListControl.setFocusImage(Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png'), -4*Volt.width/1920, -4*Volt.height/1080);
        //gridListControl.hideFocus('false');

        if (isReverseLanguage(Volt.DeviceInfoModel.getLanguageCode())) {
            gridListControl.setOrientation('right-to-left');
        }

	

		if ( this.bshowScroll ){
	        var scroll = getScroll(options);
	        gridListControl.attachScrollBar(scroll);
		}

        return gridListControl;
    }

});

// Renderer
function getRenderer(parentWidth, parentHeight, data) {
    Volt.log('[GridListView] getRenderer');

    var renderer = new Renderer(parentWidth, parentHeight);

    renderer.root = new WidgetEx({
        x : 0,
        y : 0,
        width : parentWidth,
        height : parentHeight,
        parent : scene
    });
    renderer.root.show();

    renderer.thumbnail = new Thumbnail({width:parentWidth, height:parentHeight});
    renderer.thumbnail.setStyleTransAnimation(330);
    renderer.thumbnail.setScaleAnimation(330);
    renderer.thumbnail.show();

    renderer.onDraw = _.bind(function(rendererInstance, drawTypeString, data, parentWidth, parentHeight) {

        if (!data) {
            Volt.err('[GridListView][Renderer] onDraw() -> data is null!');
            return; 
        }

        data.thumbnail = rendererInstance.thumbnail;

        Volt.err('[GridListView][Renderer] onDraw() ' + drawTypeString + ' : ' + (data.model.get('app_title') || data.model.get('title')));

        if (drawTypeString == 'LoadData') {
            this.listeners.onDrawLoadData(rendererInstance.thumbnail, data);
        } else if (drawTypeString == 'UpdateData') {
            this.listeners.onDrawUpdateData(rendererInstance.thumbnail, data);
        } else if (drawTypeString == 'UnloadData') {
            this.listeners.onDrawUnloadData(rendererInstance.thumbnail, data);
        }

    }, this);
    renderer.onResize = _.bind(function(data, destWidth, destHeight, flagWithAni, duration) {
        Volt.err('[GridListView][Renderer] onResize');
    }, this);
    renderer.onRelease = _.bind(function() {
        Volt.err('[GridListView][Renderer] onRelease');
        renderer.root.destroy();
        renderer.thumbnail.destroy();
        delete renderer;
    }, this);

    return renderer;
}

// GridListControlListener
function onItemLoaded(gridList, groupIndex, itemIndex) {
    Volt.err('[GridListControlListener] onItemLoaded -> ' + itemIndex);

    var data = gridList.getData(groupIndex, itemIndex);
    if (data) {
        data.isReady = true;
    }
}

function onItemUnloaded(gridList, groupIndex, itemIndex) {
    Volt.err('[GridListControlListener] onItemUnloaded -> ' + itemIndex);

    var data = gridList.getData(groupIndex, itemIndex);
    if (data) {
        data.isReady = false;
    }
}

function onFocusChanged(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
    Volt.err('[GridListControlListener] onFocusChanged from(' + fromGroupIndex + ','  + fromItemIndex + ')' + ' to(' + toGroupIndex + ',' + toItemIndex + ')');

    var data, wzFrom = null, wzTo = null;

    if (typeof this.listeners.onFocusChanged != 'function') { return; }

    if (fromGroupIndex >= 0 && fromItemIndex >= 0) {
        data = gridList.getData(fromGroupIndex, fromItemIndex);
        wzFrom = data ? data.thumbnail : null;
    }
    if (toGroupIndex >= 0 && toItemIndex >= 0) {
        data = gridList.getData(toGroupIndex, toItemIndex);
        wzTo = data ? data.thumbnail : null;
    }
    this.listeners.onFocusChanged(wzFrom, wzTo,fromItemIndex,toItemIndex);
}

function onFocusChangeStart(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
    Volt.err('[GridListControlListener] onFocusChangeStart from(' + fromGroupIndex + ','  + fromItemIndex + ')' + ' to(' + toGroupIndex + ',' + toItemIndex + ')');

    var data, wzFrom = null, wzTo = null;

    if (typeof this.listeners.onFocusChangeStart != 'function') { return; }

    if (fromGroupIndex >= 0 && fromItemIndex >= 0) {
        data = gridList.getData(fromGroupIndex, fromItemIndex);
        wzFrom = data ? data.thumbnail : null;
    }
    if (toGroupIndex >= 0 && toItemIndex >= 0) {
        data = gridList.getData(toGroupIndex, toItemIndex);
        wzTo = data ? data.thumbnail : null;
    }
    this.listeners.onFocusChangeStart(wzFrom, wzTo);
}

function onMoveOut(gridList, directionString, fromGroupIndex, fromItemIndex) {
    Volt.err('[GridListControlListener] onMoveOut ' + directionString);
}

function onItemIndexChanged(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
    Volt.err('[GridListControlListener] onItemIndexChanged');
}

function onItemClicked(gridList, groupIndex, itemIndex) {
    Volt.err('[GridListControlListener] onItemClicked');
	
    var focusItem = this.widget.getFocusItemIndex();
	var data = this.widget.getData(focusItem.groupIndex,focusItem.itemIndex);
    this.listeners.onItemPress(this.getFocusedWidget(), focusItem,data);
}

function onEnterKeyLongPressed(gridList, groupIndex, itemIndex, type) {
    Volt.err('[GridListControlListener] onEnterKeyLongPressed ' + this.bLongPress + ' ' + this.bFocused);

    var wz = null;
    wz = this.getWidget(groupIndex, itemIndex);
    if (type == 'keyboard' && !this.bLongPress && this.bFocused) { // grid???? ??????? ?????? long press ???T?? ???? ?? ó????? ???? ?????? isFocused üu??
        this.bLongPress = true;  //blongpress is used for keyboard to judge, mouse process do not need this flag
        this.listeners.onEnterKeyLongPressed(wz, itemIndex, type);
    }else if ( type == 'mouse' && this.bFocused ){
        this.listeners.onEnterKeyLongPressed(wz, itemIndex, type);
	}
}

// Scroll
function getScroll(options) {
    Volt.err('[GridListView] getScroll');

    var scroll = new WinsetScroll({
    	style : 4,
        parent : scene,
        x : 0,
        y : options.height - Math.floor(Volt.height * 0.021296),
        minValue: 0,
        maxValue: 100,
        value: 0,
        width : options.width,
        height : Volt.height * 0.006481,
    });

    return scroll;
}

function isReverseLanguage(languageCode) {
    return (languageCode == 'ar') || (languageCode == 'fa') || (languageCode == 'he') || (languageCode == 'ur');
}

exports = GridlistView;
