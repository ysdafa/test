// Include libraries
var _              		= Volt.require('modules/underscore.js')._;
var Backbone       		= Volt.require('lib/volt-backbone.js');
var CommonDefine   		= Volt.require('app/common/commonDefines.js');
var PanelCommon    		= Volt.require('lib/panel-common.js');
var Mediator       		= Volt.require('app/common/eventMediator.js');
//var CommonFucntion 		= Volt.require('app/common/common-function.js');
var DeletePopupTemplate = Volt.require('app/templates/1080/delete-popup-template.js');
//var CommonContent 		= Volt.require('app/common/common-content.js');
//var voltApiWrapper    = Volt.require("app/common/voltapi-wrapper.js");
var WinsetBtn = Volt.require("$VOLT_ROOT/modules/WinsetUIElement/winsetButton.js");
var CommonFunctions = Volt.require('app/common/commonFunctions.js');
PanelCommon.mapWidget('WinsetBtn', WinsetBtn);
var winsetDimView = Volt.require("lib/views/dim-view.js");
var tvResoultion = WinsetBtn.ResoultionStyle.Resoultion_1080;
var CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');
var voltapi = Volt.require('voltapi.js');
var DeletePopup = PanelCommon.BaseView.extend({
    template : DeletePopupTemplate.container,
    params : null,
    totalNum :0,
    currentNum: 0,
    progressBar:null,
	appID:null,
	currentID:null,
	isMulti: false,
	timer: null,
	isShow : false,
	btnListener : new ButtonListener(),
	percentText : null,
	successFlag : true,
    render : function() {
    },
	
    show : function(options) {
        Volt.log('[delete-popup.js] show options =' + options);
        
        this.params =JSON.parse(options);
		this.currentNum = 1;
		this.appID = this.params.app_id;
		this.isMulti = this.params.isMulti;
		if(!this.isMulti) {
       		this.totalNum = 1;
		} else {
			this.totalNum = this.appID.length;
		}
        this.setWidget(PanelCommon.loadTemplate(this.template));
        this.widget.show();
        this.renderDescrption();
        this.renderProgressBar();
		this.renderButton();
		this.updateDescription();
		this.isShow = true;
 		Volt.Nav.beginModal(this.widget);
		this.cancelButton.setFocus();
		this.percentText = this.widget.getChild('percentText-container');
		this.widget._navOnKeyEvent = _.bind(this._onkeyEvent, this);
		this.bindListening();
		//this.setTimeOut();
    },
    
    bindListening : function(){
		this.listenTo(Mediator, 'VOLT_DEACTIVATE', this.hide);
		this.listenTo(Mediator, CommonDefine.Event.UNINSTALLING, _.bind(this.updateProgress, this));
		this.listenTo(Mediator, CommonDefine.Event.UNINSTALL_COMPLETED, _.bind(this.finishDelete, this));
		this.listenTo(Mediator, CommonDefine.Event.UNINSTALL_FAIL_NOT_EXIST, _.bind(this.failDelete, this));
		this.listenTo(Mediator, CommonDefine.Event.UNINSTALL_FAIL_PKGMGR_ERROR, _.bind(this.failDelete, this));
		this.listenTo(Mediator, CommonDefine.Event.UNINSTALL_FAIL_NOT_REMOVABLE, _.bind(this.failDelete, this));
		this.listenTo(Mediator, CommonDefine.Event.UNINSTALL_FAIL_OTHERS, _.bind(this.failDelete, this));
    },
    
    unbindListening : function(){
		//Mediator.off(CommonDefine.Event.UNINSTALLING);
		//Mediator.off(CommonDefine.Event.UNINSTALL_COMPLETED);
		this.stopListening(Mediator,CommonDefine.Event.UNINSTALLING);
		this.stopListening(Mediator,CommonDefine.Event.UNINSTALL_COMPLETED);
		this.stopListening(Mediator,CommonDefine.Event.UNINSTALL_FAIL_NOT_EXIST);
		this.stopListening(Mediator,CommonDefine.Event.UNINSTALL_FAIL_PKGMGR_ERROR);
		this.stopListening(Mediator,CommonDefine.Event.UNINSTALL_FAIL_NOT_REMOVABLE);
		this.stopListening(Mediator,CommonDefine.Event.UNINSTALL_FAIL_OTHERS);
		this.stopListening(Mediator, 'VOLT_DEACTIVATE');
    },
	failDelete :function(){
		this.successFlag = false;
	},
	_onkeyEvent: function (keyCode, keyType) {
        if (keyType == Volt.EVENT_KEY_RELEASE) {
            return false;
        }
        switch (keyCode) {
        case Volt.KEY_RETURN:
			this.clearTimeOut();
			Mediator.trigger(CommonDefine.Event.CLOSE_DELETING_POPUP);
            break;
        default:
            return false;
            break;
        }

        return true;
    },
    renderDescrption : function() {
        Volt.log('[delete-popup.js] renderDescrption');
        var container = this.widget.getChild('delete-description-container');
        var description = new descriptionView().render().widget;
        container.addChild(description);
        /*var isInUSB = this.isWidgetInstalledInUSB(this.appID);
        if(isInUSB){
            description.text = "Deleting ...\nDo not remove storage device.";
            this.widget.getChild('progressbar-container').y += description.height;
            this.widget.getChild('button-container').y += description.height;
            this.widget.getChild('description-container').height += description.height;
            this.widget.height += description.height;
            description.height *= 2;
        } 
		else 
		{
            description.getChild('description-container').text = "Deleting ...";
        }*/
    },

    renderProgressBar : function() {
		var container = this.widget.getChild('progressbar-container');
		if(this.isMulti == false) {
			Volt.log('[delete-popup.js] render single ProgressBar');
			
		} else {
			Volt.log('[delete-popup.js] render multi ProgressBar, appID = ' + this.appID + ' totalNum = ' + this.totalNum);
		}
		this.progressBar = this.createProgressControl(container, 0, 0, 945, 2);
    },
    renderButton : function() {
		var container = this.widget.getChild('button-container');
		var btnStyleText = {
			style : WinsetBtn.ButtonStyle.Button_image_O_Style_F_FOCUS1,
			buttonType : WinsetBtn.ButtonType.BUTTON_TEXT,
			resoultion : tvResoultion,
		}
		this.btnListener.onButtonClicked = function(button, type) {
				this.onSelect();
		}.bind(this);
		this.cancelButton = PanelCommon.loadTemplate(DeletePopupTemplate.deleteCancelBtn, btnStyleText, container);
		this.cancelButton.addListener(this.btnListener);
		

    },
	onSelect:function(){
		this.clearTimeOut();
		if(this.isMulti == true)
		{
			//voltapi.WAS.CancelMutilUnInstallApps();  /*voltapi.js not update yet*/
		}
		Mediator.trigger(CommonDefine.Event.CLOSE_DELETING_POPUP);
	},
    createProgressControl : function(widget, xValue, yValue, width, height){
        var progress = new Progress({
            parent : widget,
            width : width,
            height : height,
            x : xValue,
            y : yValue,
            direction: "horizontal",
            minValue : 0,
            value : 0,
            maxValue : width,
            color: Volt.hexToRgb('#ffffff', 40),
            progressColor: Volt.hexToRgb('#ffffff', 100)
        });
        progress.show();
        return progress;
    },
    hide : function() {
        Volt.log('[delete-popup.js] hide');
		this.clearTimeOut();
        this.unbindListening();
		Volt.Nav.endModal();         
		this.widget.hide();
		this.progressBar = null;
		this.appID = null;
		this.isShow = false;
		Volt.setTimeout(_.bind(this.destroy,this),1);
 		if(CommonDefine.AppState.APP_STATE_ACTIVATE == CommonFunctions.getAppState()){
			Volt.log('[delete-popup.js] CommonDefines.AppState.APP_STATE_ACTIVATE');
			winsetDimView.hide();
		}
		else if(CommonDefine.AppState.APP_STATE_DEACTIVATE == CommonFunctions.getAppState()){
			Volt.log('[delete-popup.js] CommonDefines.AppState.APP_STATE_DEACTIVATE');
			Volt.Nav.focus();
		}
        return;
    },

    destroy : function(widget) {
		this.widget.destroy();
    },

	updateProgress: function(eventInfo) {
			Volt.log("[delete-popup.js] updateProgress@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			if(eventInfo) {
				Volt.log("[delete-popup.js] " + eventInfo.app_id + " " + eventInfo.result);
					if (eventInfo.result <= 100) {
						if(this.progressBar) {
							this.progressBar.value = eventInfo.result * 945 / 100;
							//this.setTimeOut();
						}
						this.percentText.text =  eventInfo.result +'%';
					}
			}
	},
	updateDescription:function(){
		this.widget.getDescendant('deleting_Number_Text').text = "Total("+this.currentNum+"/"+this.totalNum+")";
		
		
	},
    isWidgetInstalledInUSB : function(appID){
            var bRet = voltapi.WAS.getAppInfo(appID);
            if(bRet != undefined && bRet != -1 && bRet != false && bRet.type == "user_usb"){
                return true;
            }
            return false;
    },
	finishDelete: function(eventInfo) {
		if(this != null && this != undefined) {
			if(this.isMulti == false) {
				Volt.log("[delete-popup.js] finish single delete");
				if(eventInfo != null && eventInfo != undefined && eventInfo.app_id == this.appID) {
					Volt.log("trigger CommonDefine.Event.EVENT_DELETE_SUCCESS, finish delete.isMulti == false");
					this.allUninstallFinishedCB();
					//Mediator.trigger(CommonDefine.Event.CLOSE_DELETING_POPUP);
					/*var voiceGuide = 'Deleting ,Completed,' + this.currentNum + 'of ' + this.totalNum + ',OK,button.';
					CommonContent.voiceGuide(voiceGuide);
						
					var param = {
						reult : 'success',
					};
					Mediator.trigger(CommonDefine.Event.EVENT_DELETE_SUCCESS, param);*/
				}
			} else {
				Volt.log("[delete-popup.js] receive multi delete event");
				if(eventInfo != null && eventInfo != undefined) {
					Volt.log("[delete-popup.js] eventInfo.app_id = ", eventInfo.app_id);
					Volt.log("[delete-popup.js] before appID = " + this.appID);
					for(var i = 0; i < this.appID.length; ++i) {
						if(this.appID[i] == eventInfo.app_id) {
							this.currentNum++;
							Volt.log('this.currentNum:'+this.currentNum+'this.totalNum'+this.totalNum);
							if(this.currentNum > this.totalNum) {
								//this.currentNum = this.totalNum;
								this.allUninstallFinishedCB();
								//Mediator.trigger(CommonDefine.Event.CLOSE_DELETING_POPUP);
								return;
							}
							this.appID.splice(i, 1);
							Volt.log("[delete-popup.js] after appID = " + this.appID);
							this.updateDescription();
							break;
						}
					}
					/*if(this.currentNum == this.totalNum) {
						Volt.log("trigger CommonDefine.Event.EVENT_DELETE_SUCCESS, finish delete.isMulti == true");
					}*/
				}
			}
		}
	},
	allUninstallFinishedCB:function(){
		Volt.log("allUninstallFinishedCB");
		if (this.successFlag == false)
		{
			this.clearTimeOut();
			Mediator.trigger(CommonDefine.Event.CLOSE_DELETING_POPUP);
			CommonWidgetPopup.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_TO_UNINSTALL);
			return;
		}
		descriptionText.widget.getChild('deleting_Text').text=Volt.i18n.t('TV_SID_DELETED_SUCCESSFULLY');
		this.cancelButton.setText({state:"all",text: Volt.i18n.t('COM_SID_OK')});
		this.setTimeOut();
	},
	setTimeOut: function(){
		this.clearTimeOut();
	    this.timer = Volt.setTimeout(function(){
			Volt.log('[delete-popup.js] time out');
			Mediator.trigger(CommonDefine.Event.CLOSE_DELETING_POPUP);
		},1000 * 10);

	},

	clearTimeOut: function(){
		if(this.timer != null && this.timer != undefined) {
	        Volt.clearTimeout(this.timer);
	    }
	},
});

//template of description
var descriptionView = PanelCommon.BaseView.extend({
    template : DeletePopupTemplate.description,

    render : function() {
        this.setWidget(PanelCommon.loadTemplate(this.template));
		descriptionText = this;
        return this;
    }
});


exports = new DeletePopup;
