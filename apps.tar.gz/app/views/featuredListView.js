/** 
 * @author youngil baek (yi01.baek@samsung.com)
 * @fileoverview This module manages featured list view of app.
 * @date    2014/07/23 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._,
    Q = Volt.require('modules/q.js'),
    VoltJSON = Volt.require("modules/VoltJSON.js");

// Implements
var EventMediator = Volt.require('app/common/eventMediator.js'),
    FeaturedListTemplate = Volt.require('app/templates/1080/featuredListTemplate.js'),
    GridListView = Volt.require('app/views/gridListView.js');

var AppInfoVMCollection = Volt.require('app/models/appInfoVMCollection.js');
var voltapi = Volt.require('voltapi.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');
var CommonFunctions = Volt.require('app/common/commonFunctions.js');
var AppInfoProgressView = Volt.require("app/views/appInfoProgressView.js");
var CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');
/**
 * @name FeaturedListView
 */
var FeaturedListView = Volt.BaseView.extend({
    /** @lends FeaturedListView.prototype */
    appInfoVMCollection: null,
    template: FeaturedListTemplate.container,
    gridlist: FeaturedListTemplate.gridList,    
    appInfoView : null,
    piaView : null,
    viewList: null,
    gridListView: null,
    isShown: false,

    /**
     * Initialize this view
     * @name FeaturedListView
     * @constructs
     */
    initialize: function() {
		this.listenTo(EventMediator, CommonDefines.Event.MSGBOX_BUTTON,  this.processMsgBoxEvent, this);
	},
    /**
     * set msgbox button click callback
     * @method  caoyr 11.14
     * @memberof FeaturedListView
     */
    processMsgBoxEvent: function(data) {
		Volt.err('[FeaturedListView] processMsgBoxEvent:type is:', data.msgBoxtype + " eventType is:" + data.eventType);
		if(data.eventType == CommonDefines.Event.SELECT_BTN1) {
			switch(data.msgBoxtype) {
				case CommonDefines.MsgBoxType.MSGBOX_TYPE_SERVER_ERROR_GUIDE:
                                    Volt.err('[FeaturedListView] processMsgBoxEvent: ok');
									Backbone.history.back();

					break;
				default:
					break;
				} 
		} else if(data.eventType == CommonDefines.Event.SELECT_BTN2) {
		    Volt.err('[detail-view.js] processMsgBoxEvent:SELECT_BTN2');
		}
	},
    /**
 * render once after view is created
 * @method
 * @param  {widget} parentWidget parentWidget
 * @return {View}              this View
 */
    render: function(parentWidget) {
        Volt.err('[FeaturedListView] render');

        var contentContainer = parentWidget.widget.getChild('main-content-container');
        
        this.setWidget(Volt.loadTemplate(this.template, { type : this.featuredType }));
        contentContainer.addChild(this.widget);

        if (!this.appInfoVMCollection) {
            this.appInfoVMCollection = new AppInfoVMCollection();
            this.appInfoVMCollection.setCollection(this.featuredType);
        }

        this.setAppInfoView();
        return this;
    },

    fetch: function() {
        if (!this.gridListView) {
            EventMediator.trigger(CommonDefines.Event.EVENT_HOME_SHOW_LOADING);
            this.fetchServer();    
        }
    },

    fetchCache: function(data){   

        Q.all([
            this.appInfoVMCollection.offline(data)
        ])
        .then(_.bind(function(){        
        //    this.fetchServer();
        },this))
        .fail(_.bind(function(){        
        //    EventMediator.trigger(CommonDefines.Event.EVENT_HOME_SHOW_LOADING);
        //    this.fetchServer();
        },this));
    },     

    fetchServer: function(isReset){        

        if(Volt.DeviceInfoModel.get('networksStatus') == "OK"){     

            Q.all([
                this.appInfoVMCollection.fetch(isReset)
            ])
            .then(_.bind(function(){
                EventMediator.trigger(CommonDefines.Event.EVENT_HOME_HIDE_LOADING);            
            },this))
            .fail(_.bind(function(){                
                EventMediator.trigger(CommonDefines.Event.EVENT_HOME_HIDE_LOADING);                            
            },this));

        }else if(Volt.DeviceInfoModel.get('networksStatus') == "NG"){
            EventMediator.trigger(CommonDefines.Event.EVENT_HOME_HIDE_LOADING);       
            this.showDisconnectPopup();
        }
    },
    updateContent : function() {
	 print('update content');
	 if(this.gridListView&& this.gridListView.gridListControl){
	 	if (this.appInfoVMCollection.length > 0) {
                 for (var i = 0; i < this.appInfoVMCollection.length; i++) {
                     var data = this.gridListView.gridListControl.getData(0, i);
                      data.model = this.appInfoVMCollection.at(i);
			   print('update content:data.model.title ' + data.model.get('title'));
                 }
             }
		this.gridListView.gridListControl.updateAllItems(0);
	 }
    },
/**
 * make it be gridList style.
 * @method
 * @param  {Collection} collection appInfoVMCollection
 */
    renderContent: function(collection, options) {
        Volt.err('[FeaturedListView] renderContent');

        EventMediator.trigger(CommonDefines.Event.EVENT_HOME_HIDE_LOADING);                   

        if (this.appInfoVMCollection.length > 0) {                        
            if(this.featuredType == 'event'){
                this.renderEventBanner(options);
            }                           
            if (!this.gridListView) {                                
                var container = this.widget.getChild('featured-list-content-container-' + this.featuredType);
                this.gridlist.parent = container;                
                this.gridListView = this.initNativeGrid();
                container.addChild(this.gridListView.render(this.appInfoVMCollection).widget);
                this.gridListView.widget.showWithAnimation();
            }else{
                 this.updateContent();
		}

            if (this.gridListView) {
                this.gridListView.widget.custom = {focusable : true};
                
                for (var i in this.viewList) {
                    this.viewList[i].showProgressBar();
                }
            }            

            //this.widget.getChild('featured-list-content-index-' + this.featuredType).text =  " / "+ this.appInfoVMCollection.length;
            this.widget.getChild('featured-list-no-content-' + this.featuredType).text = ""; 

            Volt.Nav.setNextItemRule(this.gridListView.widget, 'up', 'category-list-container');

            Volt.Nav.reload();

            if("whatsNew" == this.featuredType){
			//add by lihao.zha@20141222 for fixing first enter panel voice guide issue
			Volt.Nav.focus();
			Volt.Nav.focus(this.gridListView.widget);//make first page's default focus to first item of gridlist. 
            	}     
            
        }else{            
            this.widget.getChild('featured-list-no-content-' + this.featuredType).text = "No Content Found. Please Select different filtering options.";
        }
    },


    initNativeGrid: function() {
        Volt.err('[FeaturedView] initNativeGrid');

        this.viewList = new Array();      
        var bFirstEnterMark = true;
        var gridListView = new GridListView({
            gridListControlParam: this.gridlist,

            listeners: {
                onDrawLoadData: function(thumbnail, data) {
                    Volt.err('[FeaturedView] onDrawLoadData '+ data._index);
                    var model = data.model;//this.appInfoVMCollection.at(parseInt(data._index, 10));
                    var iView = null;
                    if(self.featuredType == 'whatsNew' && self.piaView != null && data._index == 1){
                        iView = new self.piaView(model, self.featuredType ,thumbnail );    
                    }else{                        
                        iView = new self.appInfoView(model, self.featuredType);    
                    }                    
                    iView.render(data._index, thumbnail);
                    self.viewList[data._index] = iView; 
                },
                onDrawUpdateData: function(thumbnail, data) {
                    Volt.err('[FeaturedView] onDrawUpdateData ' + data._index);
			 self.viewList[data._index].updateItemView(thumbnail,data); 

                },
                onDrawUnloadData: function(thumbnail, data) {
                    Volt.err('[FeaturedView] onDrawUnloadData');

                    var VM = data.model;

                    if (VM) {
                        VM.destroyView();
                    }
                },
                onGridFocus: function(wzFocused) {
                    Volt.err('[FeaturedView] onGridFocus');

                    if(bFirstEnterMark){
                        bFirstEnterMark = false;
                        return;
                    }
                    if(wzFocused){
                        var voiceText;
                        if(wzFocused.customType == 'whatsNew'){
                            voiceText = Volt.i18n.t('TV_SID_APPS_KR_PANEL') + ' ' + 
                                Volt.i18n.t('UID_APPS_WHATS_NEW');
                        }
                        else{
                            voiceText =Volt.i18n.t('TV_SID_APPS_KR_PANEL') + ' ' +  
                                Volt.i18n.t('COM_SID_MOSTPOPULAR_CATEGORY');
                        }
                        voiceText = voiceText + ' ' + Volt.i18n.t('SID_CATEGORY_KR_CA') + ',' + 
                                self.appInfoVMCollection.length +  ' ' + Volt.i18n.t('TV_SID_ITEMS') +  ',' + 
                                wzFocused.customTitle; 
                        CommonFunctions.forceDisableVoiceGuide(false);
                        CommonFunctions.voiceGuide(voiceText);
                    }
                },
                onGridBlur: function(wzFocused) {
                    Volt.err('[FeaturedView] onGridBlur');

                    if (wzFocused && typeof wzFocused.trigger == 'function') {
                        wzFocused.trigger('NAV_BLUR');
                    }
                },
                onFocusChangeStart: function(wzFrom, wzTo) {

                },
                onFocusChanged: function(wzFrom, wzTo) {
                    Volt.err('[FeaturedView] onFocusChanged');
                    if (wzTo) {
                        CommonFunctions.voiceGuide(wzTo.customTitle);
                    }
                },
                onItemPress: function(wz, itemData, data) {
					Volt.err('[FeaturedView] onItemPress');
					self.SelectItem( itemData.itemIndex, data.model, self.featuredType);
                    
                },
                onEnterKeyLongPressed: function(wzFocused, itemData, type) {
//                    Volt.err('[MyAppsView] onEnterKeyLongPressed' + itemData + self.myAppsVMCollection.at(itemData));
                    if (wzFocused && itemData != -1) {
                        if(Volt.DeviceInfoModel.get('networksStatus') == "NG"){
            				CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
            				return;
            		    }
                        var vmSelected = self.appInfoVMCollection.collection.at(itemData);
                            iSelectedContext = self.viewList[itemData];

                        if (iSelectedContext.downloadable){
                            var param = {
                                baseWidget : wzFocused,
                                appInfoVM : vmSelected,
                                parentView : iSelectedContext,
                                type : iSelectedContext.type,
                                feature : iSelectedContext.feature
                            }
                            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_CONTEXTMENU,param);

							if ( type == 'mouse'){
								EventMediator.trigger(CommonDefines.Event.EVENT_LONGPRESS_RELEASE);
							}
                        }    

                        switch (self.appInfoVMCollection.type) {
                            case 'whatsNew':
                            Volt.KpiMapper.addEventLog('LONGPRESSWN');
                            break;

                            case 'mostPopular':
                            Volt.KpiMapper.addEventLog('LONGPRESSMP');
                            break;
                        }     
                    }
                }
            }
            
        });

        // for test
        var self = this;

        return gridListView;
    },


	
/**
 * callback on selecting
 * @method
 * @param  {number} index selected item's indext
 */
    SelectItem : function(index,model,type){
        Volt.err('AppInfoView onSelect : ' + index);
        if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
			CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
			return;
		}
        if('whatsNew' == type){
		 Volt.err('AppInfoView play ad');
		if(1 == index){
		    if(this.viewList[index]){
                       if(this.viewList[index].onSelect){
				this.viewList[index].onSelect();   	
                       }
		    }
		    return;
		}
	}
        Backbone.history.navigate('detail/' + model.get('id'), { trigger: true });
        switch(type) {

            case 'mostPopular':
                Volt.KpiMapper.addEventLog('SELECTMP', {
                    d: {
                        appid: model.get('id'),
                        pn: model.get('order')
                    }
                });
            break;

            case 'event': 
                Volt.KpiMapper.addEventLog('SELECTEV', {
                    d: {
                        appid: model.get('id'),
                        pn: model.get('order')
                    }
                });
            break;

            case 'whatsNew': 
                Volt.KpiMapper.addEventLog('SELECTWN', {
                    d: {
                        appid: model.get('id'),
                        pn: model.get('order')
                    }
                });
            break;
        }
    },


    removeGrid: function() {
        Volt.err('[FeaturedListView] remove grid list');

        if (this.gridListView) {
            this.gridListView = null;
        }
    },

    setAppInfoView: function() {
        this.appInfoView = AppInfoView;
    },

/**
 * show this view
 * @method
 * @param  {object} param         additional data
 * @param  {number} animationType showing animation type 
 * @return {object}               promise obj to synchronize logic.
 */
    show: function(param, animationType) {
        Volt.log('@show');
        this.listenTo(EventMediator, 'VOLT_PAUSE', this.pause);
        this.listenTo(EventMediator, 'VOLT_HIDE', this.pause);

        var deferred = Q.defer();
        var self = this;

        this.isShown = true;
        // Listen to model
        if(this.appInfoVMCollection){
            this.listenTo(this.appInfoVMCollection, 'reset', this.renderContent);
            this.listenTo(this.appInfoVMCollection, 'add', function(added) {
                this.gridListView.addItem(added);
            });
            this.listenTo(this.appInfoVMCollection, 'error', this.showErrorPopup);
            this.appInfoVMCollection.startListeningEvent();
        }
        
        this.listenTo(EventMediator, 'TEMP_LONGPRESSKEY', this.onLongPressed);
        this.listenTo(EventMediator, CommonDefines.Event.GRID_NAV_FOCUS_CHANGED, this.onFocusChanged);
        this.listenTo(EventMediator, CommonDefines.Event.GRID_NAV_FOCUS_BLURED, this.onFocusBlured);

        this.fetch();

        this.widget.show();
        
        if (this.gridListView) {
            this.gridListView.widget.custom = {focusable : true};
            this.gridListView.widget.showWithAnimation();
            
            for(var i in this.viewList){
                this.viewList[i].showProgressBar();    
            }
        }        

        Volt.Nav.reload();

        if( this.gridListView ){
            var previousHistory = Backbone.history.hashstack[Backbone.history.hashstack.length - 2];
            var isDetail = (/#detail/g).test(previousHistory);
            if (isDetail) {
                Volt.Nav.focus(this.gridListView.widget);
            }
            // else this.gridListView.widget.setFocusItemIndex(0, 0);
        }
        deferred.resolve();
        return deferred.promise;
    },
/**
 * hide this view
 * @method
 * @param  {number} animationType hiding animation type 
 * @return {object}               promise obj to synchronize logic.
 */
    hide: function(animationType) {
        Volt.err('[FeaturedListView] hide');
        this.isShown = false;

        var deferred = Q.defer();
        deferred.resolve();
        
        this.widget.hide();

        if (this.gridListView) {
            this.gridListView.widget.custom = {focusable : false};
            this.gridListView.widget.hideWithAnimation("autoDestroy");
            for(var i in this.viewList){
                this.viewList[i].hideProgressBar();    
            }
        }

        if(this.appInfoVMCollection){
            this.stopListening(this.appInfoVMCollection);
            this.appInfoVMCollection.stopListeningEvent();
        }

        return deferred.promise;
    },
    /**
     * Pause this view.
     * @method
     */
    pause: function() {
        Volt.err('[FeaturedListView] pause');
        if(this.isShown){
            //this.widget.hide();        
            this.listenTo(EventMediator, 'VOLT_RESUME', this.resume);
            for(var i in this.viewList){
                this.viewList[i].hideProgressBar();    
            }            
        }
    },

    /**
     * Resume this view.
     * @method
     */
    resume: function() {
        Volt.err('[FeaturedListView] resume');
        if(this.isShown){
            this.widget.show();
            for(var i in this.viewList){
                this.viewList[i].showProgressBar();    
            }
            this.stopListening(EventMediator, 'VOLT_RESUME');
        }        
    },

    showErrorPopup: function(serverError) {

        if (serverError.code == 'AS666') {
            //var networkPopup = new MsgPopupView({type: CommonDefines.Popup.TYPE_NETWORK});
			 CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
        } else {
            /*var setPopup = {
                text : serverError.message + '(' + serverError.code +')',
                buttons: [
                    {
                        name: Volt.i18n.t('COM_SID_OK')
                    }
                ]
            }

            var guidePopup = new MsgPopupView(setPopup,serverError);*/
			CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_SERVER_ERROR_GUIDE,serverError);
        }
        return;
    },

    showDisconnectPopup : function(){
        //var networkPopup = new MsgPopupView({type: CommonDefines.Popup.TYPE_NETWORK});
		 CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
        return;
    }

});

/**
 * @name AppInfoView
 */
var AppInfoView = Volt.BaseView.extend({
    /** @lends AppInfoView.prototype */
    template: FeaturedListTemplate,
    appinfo: FeaturedListTemplate.appinfo,
    bgmode: "LIGHT",
    downloadable: true,
    thumbnail: null,
    AppInfoProgressView:null,
/**
 * initialize
 * @name AppInfoView
 * @constructs
 * @param  {Model} model VM correspond to this
 * @param  {string} type   featuredType
 */
    initialize : function(model, type){
        this.VM = model;
        this.type = type;
    },

    bindListener: function() {        
        this.listenTo(this.VM, 'change', this.renderChange);        
        this.listenTo(this.VM, 'DESTROY_VIEW', this.onDestroyView);
        this.showProgressBar();
    },

    unbindListener: function() {
        this.stopListening();
        this.hideProgressBar();
    },

    onDestroyView: function() {
        Volt.err('[FeaturedAppInfoView] onDestroyView');
        this.unbindListener();
    },
/**
 * render this view
 * @method
 * @param  {number} index  rendering appInfoView's index
 * @param  {type} widget rendering appInfoView's widget
 */
    render : function(index, iThumbnail){
        Volt.err('AppInfoView render : ');
        if( iThumbnail ){
            var self = this;	
            this.thumbnail = iThumbnail;
            var data = this.VM.toJSON();
            var icon = data.icon.replace("{w}", CommonDefines.ImageSize.PNG_ICON_WIDTH ).replace("{h}", CommonDefines.ImageSize.PNG_ICON_HEIGHT);
            var screenshot = data.screenshot.replace("{w}", CommonDefines.ImageSize.SCREENSHOT_WIDTH ).replace("{h}", CommonDefines.ImageSize.SCREENSHOT_HEIGHT);
            var oThumbnailStyle = _.clone(this.appinfo);

            if(screenshot){
                oThumbnailStyle.image.src = screenshot;
                this.useDefaultImage = false;
            }
            else{
                oThumbnailStyle.image.src = Volt.getRemoteUrl('images/1080/common/apps_screenshot_default.png');
                this.useDefaultImage = true;
            }
            oThumbnailStyle.information.icon1.src  = icon;
            oThumbnailStyle.information.text1.text = data.title ? data.title : '';

            if( this.type == 'whatsNew' ){
                oThumbnailStyle.information.text2.text = data.updated ? data.updated.split('T')[0] : '';
                oThumbnailStyle.information.text3.text = data.fileSize ? this.convertByte(data.fileSize) : '';
            }else{
                // MostPopular
                
				var ratings = data.gradeAvg ? (data.gradeAvg*2) : 0;
				if (ratings == 0){
					oThumbnailStyle.information.text3.text = 'No Ratings';
					oThumbnailStyle.information.text2.text = data.fileSize ? this.convertByte(data.fileSize) : '';
					oThumbnailStyle.information.rating.opacity = 0;
				}
				else{
					oThumbnailStyle.information.text2.text = data.fileSize ? this.convertByte(data.fileSize) : '';
					oThumbnailStyle.information.rating.value = ratings;
					oThumbnailStyle.information.rating.opacity = 255;
					oThumbnailStyle.information.text3.text = '';
				}
            }
            
            var thumbListener = new ThumbnailListener;
            thumbListener.onImageReady = function (thumbnail, id, success) {
                if( success ){
                    Volt.setTimeout(function(){
                        if(self.useDefaultImage){
                            thumbnail.color = {r:0x46,g:0x55,b:0x63,a:255};
                            thumbnail.setInformationColor({r:0x46,g:0x55,b:0x63,a:255});
                        }
                        else{
                            var color = thumbnail.getInformationColorPicking();
                            var cc = HALOUtil.extractIconColor(color.r, color.g, color.b);

                            thumbnail.color = {
                                r : color.r,
                                g : color.g,
                                b : color.b,
                                a : color.a
                            };
                        }

                        if( self.type !== 'whatsNew' )  { 
                           if( cc == HALOUtil.CC_WHITE ){
                                thumbnail.setInformationRatingImage({
                                    onSrc:   Volt.getRemoteUrl('images/1080/common/apps_contents_star_bk.png'),
                                    halfSrc: Volt.getRemoteUrl('images/1080/common/apps_contents_star_bk_half.png'), 
                                    offSrc:  Volt.getRemoteUrl('images/1080/common/apps_contents_star_bg.png'), 
                                }); 
                            }

                            thumbnail.visualizeInformationRating(true);
                        }

                    }, 0);
                }else{
                    var defaultImageURL = Volt.getRemoteUrl('images/1080/common/apps_screenshot_default.png');
                    thumbnail.setContentImage(defaultImageURL);
                    self.usbDefaultImage = true;
                }
            }

            this.thumbnail.setThumbnailStyle(oThumbnailStyle);
            this.thumbnail.addThumbnailListener(thumbListener);
            this.thumbnail.setDimBackgroundColor({r:0, g:0, b:0, a:153});
            this.thumbnail.dim(false);

            this.thumbnail.visualizeInformationIcon(false, 'icon2');
            
            if( this.type !== 'whatsNew' ){
                this.thumbnail.visualizeInformationRating(false);
            }
            
            this.thumbnail.setProgressRange(0, 100);
            this.setWidget(this.thumbnail);
            this.thumbnail.customTitle = data.title || '';
            this.thumbnail.customType = this.type;
	     this.thumbnail.customSupportVoice = data.is_support_voice;
            //this.thumbnail.setTTSText({text: data.title || ''});

            this.setDownloadColorPicking(this.VM.get('isDownloaded'));
            this.bindListener();
        } 
    },
   updateItemView: function(Thumbnail,data){
        Volt.err('AppInfoView updateItemView : ');
        this.VM = data.model;
	  this.hideProgressBar();
	  if( Thumbnail ){
            var self = this;
            this.thumbnail = Thumbnail;

            var data = this.VM.toJSON();
            var icon = data.icon.replace("{w}", CommonDefines.ImageSize.PNG_ICON_WIDTH ).replace("{h}", CommonDefines.ImageSize.PNG_ICON_HEIGHT);
            var screenshot = data.screenshot.replace("{w}", CommonDefines.ImageSize.SCREENSHOT_WIDTH ).replace("{h}", CommonDefines.ImageSize.SCREENSHOT_HEIGHT);
 
            if(screenshot){
                this.thumbnail.setContentImage(screenshot);
                this.useDefaultImage = false;
            }
            else{
                this.thumbnail.setContentImage(Volt.getRemoteUrl('images/1080/common/apps_screenshot_default.png'));
                this.useDefaultImage = true;
            }
	     this.thumbnail.setInformationIcon("icon1",icon);

		this.thumbnail.setInformationText("text1",data.title ? data.title : '');
		 if( this.type == 'whatsNew' ){
		 	 this.thumbnail.setInformationText("text2",data.updated ? data.updated.split('T')[0] : '');
		       this.thumbnail.setInformationText("text3",data.fileSize ? this.convertByte(data.fileSize) : '');	
		 }else{
					
                    this.thumbnail.setInformationText("text2",data.fileSize ? this.convertByte(data.fileSize) : '');
					var ratings = data.gradeAvg ? (data.gradeAvg*2) : 0;
					if (ratings==0)
					{
						this.thumbnail.setInformationText("text3",'No Ratings');
						this.thumbnail.visualizeInformationRating(false);
					}
					else{
						this.thumbnail.setInformationRatingValue(ratings);
						this.thumbnail.setInformationText("text3",'');
						this.thumbnail.visualizeInformationRating(true);
					}
		 }
            this.thumbnail.visualizeInformationIcon(false, 'icon2');

            this.thumbnail.customTitle = data.title || '';
            this.thumbnail.customType = this.type;
	     this.thumbnail.customSupportVoice = data.is_support_voice;

			
            if( this.type !== 'whatsNew' ){
                this.thumbnail.visualizeInformationRating(false);
            }
            this.setDownloadColorPicking(this.VM.get('isDownloaded'));
	      this.bindListener();
        }
	   this.showProgressBar();
    },
    extendData: function(mustache, data){
        return mustache;
    },

    setDownloadColorPicking : function(bFlag){

        if(bFlag){
            if( this.thumbnail ){
                this.thumbnail.visualizeInformationIcon(true, 'icon2'); 
            }
        }            
        else{
            if( this.thumbnail ){
                this.thumbnail.visualizeInformationIcon(false, 'icon2'); 
            }
        }
    },
/**
 * convert bytes mark
 * @method
 * @param  {number} value app size
 * @return {string}       converted size 
 */
    convertByte : function(value){
        
        if( value >= 1048576 ){
            return parseFloat(value/1048576).toFixed(2)  + " "+ Volt.i18n.t('SID_MB');
        }else if(value >= 1024){
            return parseInt(value/1024) + " "+ Volt.i18n.t('SID_KB');
        }else{
            return parseInt(value) + " "+ Volt.i18n.t('SID_BYTE');
        }
    },
/**
 * callback func when changed.
 * @method
 * @param  {Model} changedModel changedModel
 */
    renderChange: function(changedModel){
        Volt.err('AppInfoView renderChange : ');        

        if (_.keys(changedModel.changed)[0] == 'isDownloaded') {
            this.setDownloadColorPicking(changedModel.changed.isDownloaded);
        }
    },    

    events : {
        //'NAV_SELECT' : 'onSelect',
        'NAV_BLUR' : 'onBlur',
        'NAV_FOCUS' : 'onFocus'
    },

    /**
     * Call when it is blurred
     * @method
     */
    onBlur: function() {
      
    },

    /**
     * Call when it is focused
     * @method
     */
    onFocus: function() {

    },

/**
 * install
 * @method
 */
    installApp : function(){

        if( this.AppInfoProgressView == null ){
            this.AppInfoProgressView = new AppInfoProgressView(this.thumbnail, this.VM);
        }

        this.AppInfoProgressView.installApp();
    },

    cancelInstallApp: function(){
        // [TODO] When press Cancel button, cancal installing app.
        if( this.AppInfoProgressView == null ){
            this.AppInfoProgressView = new AppInfoProgressView(this.thumbnail, this.VM);
        }
        
        this.AppInfoProgressView.cancelInstallApp();
    },

/**
 * show view
 * @method
 */
    showProgressBar : function(){
        try{
            if( this.AppInfoProgressView == null ){
                this.AppInfoProgressView = new AppInfoProgressView(this.thumbnail, this.VM);
            }

              this.AppInfoProgressView.updateThumbnail(this.thumbnail);
       	 this.AppInfoProgressView.show();
        }catch(e){

        }
        
    },
/**
 * hide view
 * @method
 */
    hideProgressBar : function(){

        if (this.AppInfoProgressView){
            this.AppInfoProgressView.hideProgressBar();
        } 
    },
/**
 * resume view
 * @method
 */
    resume : function(){
    },
/**
 * pause view
 * @method
 */
    pause : function(){
    }

});

exports = {
    'listView': FeaturedListView,
    'appInfoView': AppInfoView
};
