/** 
 * @author donghyun Lee (donghyun81.lee@samsung.com)
 * @fileoverview This module manages installation of app.
 * @date    2014/07/23 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Q = Volt.require('modules/q.js');
var Backbone = Volt.require('lib/volt-backbone.js'),
    //BackboneUI = Volt.require('lib/volt-backbone-ui.js'),
    _ = Volt.require("modules/underscore.js")._,
    VoltJSON = Volt.require("modules/VoltJSON.js");

// Implements
var EventMediator = Volt.require('app/common/eventMediator.js'),
    MenuTemplate = Volt.require('app/templates/1080/menuTemplate.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    CommonFunctions = Volt.require('app/common/commonFunctions.js'),
    WinsetCategoryTab = Volt.require('WinsetUIElement/winsetCategoryTab.js'),
    Models = Volt.require('app/models/models.js');

var MENU_ANIM_DURATION = 200;

/**
 * @name MenuListView
 */
var MenuListView = Volt.BaseView.extend({
    /** @lends MenuListView.prototype */

    /**
     * Initialize MenuListView
     * @name MenuListView
     * @constructs
     */
    parent: null,   // Parent View
    
    isFetching: false,
    categoryTabs: null, // Category Tab Control
    //bFirstChange: true, // Initial setting of CategoryTabs
    
    initialize: function (options) {
        if (options) {
            this.parent = options.parent;
        }
        
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MAIN_CATEGORY_FOCUS, this.expand);
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MAIN_CATEGORY_BLUR, this.shrink);
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MAIN_CATEGORY_CHANGE, this.changeFocus);
        this.listenTo(EventMediator, 'START_EDIT_MODE', this.moveMyApps);
        this.listenTo(EventMediator, CommonDefines.Event.MOVE_FOCUS_MYAPPS, this.moveMyApps);
        this.listenTo(Models.menuVMCollection, 'change:isDefault', this.onMenuChanged);
        this.listenTo(Models.menuVMCollection, 'reset', this.updateCategoryTabs);

        this.aMenuView = [];
    },

    render: function () {
        Volt.log('[menuListView.js] render');

        this.setWidget(Volt.loadTemplate(MenuTemplate.categoryTab, null, this.parent.widget.getChild('main-category-container')));

         if (!this.categoryTabs) {
            this.initCategoryTabs();
            this.widget.addChild(this.categoryTabs);
        }

        this.updateCategoryTabs();
        this.listenTo(EventMediator, CommonDefines.Event.WAS_READY, this.fetch);
        this.listenTo(EventMediator, CommonDefines.Event.CONNECT_NETWORK, this.onConnectNetwork);

        this.widget.onKeyEvent = _.bind(this._onkeyEvent, this);

        //Volt.Nav.reload();
        return this;
    },
    
    _onkeyEvent: function (keycode, type) {
        Volt.log('[menuListView.js] keycode is ' + keycode);
        switch (keycode) {
        case Volt.KEY_JOYSTICK_LEFT:
        case Volt.KEY_JOYSTICK_RIGHT:
            return true;
        default:
            return false;
        }
    },
    
    events: {
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    onFocus: function (widget) {
        Volt.log('[menuListView.js] onFocus');
        Volt.log('[menuListView.js] count is ' + this.categoryTabs.numberOfTab());
        EventMediator.trigger(CommonDefines.Event.EVENT_MAIN_CATEGORY_FOCUS);
        var container = this.parent.widget.getChild('main-category-underbar-container');
        //comment by lihao.zha, Volt won't change animation coordinate to fit 720P automatically
        //so use scene.height to get the correct value for 720P
        container.animate('y', scene.height * 0.1, MENU_ANIM_DURATION);
        this.categoryTabs.animate('y', -scene.height * 0.033333, MENU_ANIM_DURATION);
        this.categoryTabs.animate('height', scene.height * 0.1, MENU_ANIM_DURATION);
        this.categoryTabs.setFocus();

        CommonFunctions.voiceGuide(Models.menuVMCollection.at(this.categoryTabs.currentTabIndex()).get('tmpName') + ' ' + Volt.i18n.t('SID_CATEGORY_KR_CA'));
    },
    onBlur: function (widget) {
        Volt.log('[menuListView.js] onBlur');
        var container = this.parent.widget.getChild('main-category-underbar-container');
        if (!this.parent.bLoading) {
            container.animate('y', scene.height * 0.133333, MENU_ANIM_DURATION);
            this.categoryTabs.animate('y', 0, MENU_ANIM_DURATION);
            this.categoryTabs.animate('height', scene.height * 0.066667, MENU_ANIM_DURATION);
            EventMediator.trigger(CommonDefines.Event.EVENT_MAIN_CATEGORY_BLUR);
        }
    },
    
    ////
    onConnectNetwork: function () {
        Volt.log('[categoriesView.js] onConnectNetwork');
        if (this.isFetching == false && Models.menuVMCollection.isExpand == false) {
            this.fetch();
        }
    },
    
    initCategoryTabs: function () {
        this.categoryTabs = new WinsetCategoryTab({
            style: WinsetCategoryTab.Categorytabtyle.Categorytab_Style_A,
            x: 0,
            y: 0,
            unFocusHighlightbarHeight: 2,
            focusHighlightbarHeight: Volt.height * 0.1,
            width: Volt.width,
            height: Volt.height * 0.066667,
        });
        
        var tabListener = new CategoryTabListener;

        tabListener.onTabChanged = function (ctab, index) {
            Volt.log('[menuListView.js] onTabChanged: index is ' + index);
            CommonFunctions.voiceGuide(Models.menuVMCollection.at(this.categoryTabs.currentTabIndex()).get('tmpName') + ' ' + Volt.i18n.t('SID_CATEGORY_KR_CA'));
            this.menuChanged(ctab, index);
        }.bind(this);
        this.categoryTabs.addCategoryTabListener(tabListener);
    },
    
    updateMenu: function () {
        Volt.log('[menuListView.js] updateMenu: index is ' + Models.menuVMCollection.nextMenuIndex);
        Models.menuVMCollection.setSwitchFlag(false);
        this.menuChanged(null, Models.menuVMCollection.nextMenuIndex);
    },
    
    menuChanged: function (ctab, index) {
        Volt.log('[menuListView.js] menuChanged: index is ' + index);
        
        //// To prevent callback when first time of tab change.
        // if (this.bFirstChange) {
            // this.bFirstChange = false;
            // return;
        // }
        
        if (true == Models.menuVMCollection.getSwitchFlag()) {
            Volt.log('[menuListView.js] menu is switching,please wait...');
            Models.menuVMCollection.nextMenuIndex = index;
            return;
        }
        var sRoute = Models.menuVMCollection.at(index).get('route'),
            sPageName = Models.menuVMCollection.at(index).get('pageName');

        if (Models.menuVMCollection.currentMenuIndex != index) {
            Models.menuVMCollection.currentMenuIndex = index;
            Models.menuVMCollection.nextMenuIndex = index;
            Models.menuVMCollection.setSwitchFlag(true);
            Volt.setTimeout(_.bind(this.updateMenu, this), 500);
            Backbone.history.navigate(sRoute, {
                trigger: true,
                replace: true
            });
        }

        Volt.KpiMapper.addEventLog('SELECTMENU', {
            d: {
                sm: sPageName
            }
        });

        //CommonFunctions.voiceGuide(Models.menuVMCollection.at(index).get('tmpName') + ' ' + Volt.i18n.t('SID_CATEGORY_KR_CA'));
    },
    
    updateCategoryTabs: function () {
        Volt.log('[menuListView.js] updateCategoryTabs');

        var i = 0;
        var n = this.categoryTabs.numberOfTab();
        Volt.log('[menuListView.js] updateCategoryTabs numberOfTab is ' + n);
        for (i = n - 1; i >= 0; i--) {
            Volt.log('[menuListView.js] i  ' + i);
            this.categoryTabs.removeTab(i);
        }
        
        if (Models.menuVMCollection.length <= 0) {
            return;
        }
        
        for (var idx = 0; idx < Models.menuVMCollection.length; idx++) {
            if (Models.menuVMCollection.at(idx).get('isDefault')) {
                Volt.log('[menuListView.js] addTab is ' + Models.menuVMCollection.at(idx).get('tmpName'));
                this.categoryTabs.addTab(Models.menuVMCollection.at(idx).get('tmpName'));
            }
        }
        //this.categoryTabs.setFocus(); 
        Volt.log('[menuListView.js] count is ' + this.categoryTabs.numberOfTab());
        this.categoryTabs.setTabSpliterSize(2, Volt.height * 0.02037, 3);
        
        //// Set initial selected Category Tab
        //this.bFirstChange = true;
        this.categoryTabs.changeTab(1);
    },

    fetch: function () {
        Volt.log('[categoriesView.js] fetch');

        if (Volt.DeviceInfoModel.get('networksStatus') == 'OK') {

            this.isFetching = true;
            Q.all([
                Models.menuVMCollection.fetch()
            ])
                .then(_.bind(function () {
                    this.isFetching = false;
                }, this))
                .fail(_.bind(function () {
                    this.isFetching = false;
                }, this));

        } else {}
    },
/*
    renderDefault: function () {
        Volt.log('[MenuListView] renderDefault()');

        var items = [];

        for (var idx = 0; idx < Models.menuVMCollection.length; idx++) {
            if (Models.menuVMCollection.at(idx).get('isDefault')) {
                items.push(new MenuView(Models.menuVMCollection.at(idx)).render());
            }
        }
        if (!items.length) {
            items.push();
        }

        var View = BackboneUI.SubCategoryList.extend({
            container: this.widget.find('.list-container')[0],
            items: items,
            onFocus: this.onMenuFocused,
            onBlur: this.onMenuBlurred,
            firstMenuIndex: Models.menuVMCollection.where({
                route: Backbone.history.getFragment()
            })[0].get('index')
        });
        this.listView = new View();
        this.listenTo(this.listView, 'SHOW_LIST_ARROW', this.showArrow);
        this.listView.render();

        //        this.wzCategoryContent = this.widget.find('.category-content')[0];

        this.wzCategoryContent = this.widget.find('.category-content')[0];
        this.wzListContainer = this.widget.find('.list-container')[0];

        return this;
    },
*/
    /**
     * Render once after view is created
     * @method
     * @return {widget} Rendered widget
     */

    renderContent: function () {
        Volt.log('[MenuListView] renderContent()');

        var items = [];

        for (var idx = 0; idx < Models.menuVMCollection.length; idx++) {
            if (Models.menuVMCollection.at(idx).get('isDefault')) {
                items.push(new MenuView(Models.menuVMCollection.at(idx)).render());
            }
        }
        if (!items.length) {
            items.push();
        }

        this.listView.items = items;
        this.listView.buildList();
        if (Backbone.history.isRoot() && Models.menuVMCollection.length > 0) Models.menuVMCollection.where({
            route: Backbone.history.getFragment()
        })[0].set('uiState', 'SELECTED');

        return this;
    },

    /**
     * Change menu
     * @method
     * @param {model} menuVM Menu viewmodel
     */
    onMenuChanged: function (menuVM) {
        Volt.log('[MenuListView] onMenuChanged()');

        this.listView.widget.destroyChildren();
        var results = [];
        for (var idx = 0; idx < Models.menuVMCollection.length; idx++) {
            if (Models.menuVMCollection.at(idx).get('isDefault')) {
                results.push(new MenuView(Models.menuVMCollection.at(idx)).render());
            }
        }

        this.listView.items = results;
        this.listView.render();
    },

    /**
     * Call when menu focused
     * @method
     */
    onMenuFocused: function () {
        EventMediator.trigger(CommonDefines.Event.EVENT_MAIN_CATEGORY_FOCUS);
    },

    /**
     * Call when menu blurred
     * @method
     */
    onMenuBlurred: function () {
        EventMediator.trigger(CommonDefines.Event.EVENT_MAIN_CATEGORY_BLUR);
    },

    /**
     * Expand category area on focus
     */
    expand: function () {
        return;
        Volt.log('[MenuListView] expand()');
        this.widget.animate('y', -36, MENU_ANIM_DURATION);
        this.widget.animate('height', 108, MENU_ANIM_DURATION);
        this.wzCategoryContent.animate('y', 18, MENU_ANIM_DURATION);
        this.wzCategoryContent.animate('height', 90, MENU_ANIM_DURATION);
        this.wzListContainer.animate('height', 90, MENU_ANIM_DURATION);

        this.listView.items[this.listView.cursor].isExpand = true;

        if (this.listView.focusCursor) {
            if (this.listView.focusCursor != this.listView.cursor) {
                this.listView.items[this.listView.cursor].onStateChange('EXPAND_SELECTED');
            } else {
                this.listView.items[this.listView.cursor].onStateChange('EXPAND_FOCUSED');
            }
        } else {
            this.listView.items[this.listView.cursor].onStateChange('EXPAND_FOCUSED');
        }
    },

    /**
     * Shrink category area on blur
     */
    shrink: function () {
        return;
        Volt.log('[MenuListView] shrink()');
        if (!this.parent.bLoading) {
            this.widget.animate('y', 0, MENU_ANIM_DURATION);
            this.widget.animate('height', 72, MENU_ANIM_DURATION);
            this.wzCategoryContent.animate('y', 0, MENU_ANIM_DURATION);
            this.wzCategoryContent.animate('height', 72, MENU_ANIM_DURATION);
            this.wzListContainer.animate('height', 72, MENU_ANIM_DURATION);

            this.listView.items[this.listView.cursor].isExpand = false;
            this.listView.items[this.listView.cursor].onStateChange('SHRINK');
        }
    },

    /**
     * Show this view.
     * @method
     * @param  {object} param Parameters
     * @param  {enum} animationType Animation type to showing this view.
     * @return {deferred} Deferred promise return.
     */
    show: function (param, animationType) {
        var deferred = Q.defer();
        deferred.resolve();
        this.widget.show();

        return deferred.promise;
    },

    changeFocus: function () {
        this.listView.cursor = Models.menuVMCollection.currentMenuIndex;
    },

    moveMyApps: function () {
        //navigate my apps
        Volt.log('[MenuListView] moveMyApps()');
        Volt.Nav.focus(null);
        this.categoryTabs.changeTab(0);
    },

    /**
     * hide this view.
     * @method
     * @param  {enum} animationType Animation type to hiding this view.
     * @return {deferred} Deferred promise return.
     */
    hide: function (animationType) {
        var deferred = Q.defer();
        deferred.resolve();
        this.widget.hide();

        return deferred.promise;
    },

    showArrow: function (direction) {
        var that = this;

        if (!this.leftArrow && !this.rightArrow) {

            this.leftArrow = this.widget.find('.list-arrow')[0];
            this.rightArrow = this.widget.find('.list-arrow')[1];
            this.leftArrow.addEventListener('OnMouseClick', function () {
                //                that.KPIprevArrow.send();
                that.listView.arrowClicked('LEFT');
            });
            this.rightArrow.addEventListener('OnMouseClick', function () {
                //                that.KPInextArrow.send();
                that.listView.arrowClicked('RIGHT');
            });
        }

        if (direction == 'LEFT') {
            this.leftArrow.show();
            this.rightArrow.hide();
        } else if (direction == 'RIGHT') {
            this.leftArrow.hide();
            this.rightArrow.show();
        } else if (direction == 'ALL') {
            this.leftArrow.show();
            this.rightArrow.show();
        } else if (direction == 'NONE') {
            this.leftArrow.hide();
            this.rightArrow.hide();
        }
    }

});

/**
 * @name MenuView
 */
var MenuView = Volt.BaseView.extend({
    /** @lends MenuView.prototype */

    /**
     * Initialize this view
     * @name MenuView
     * @constructs
     */
    isExpand: null,
    initialize: function (menuVM) {
        this.model = menuVM;

        this.listenTo(this.model, 'change:uiState', this.menuStateChange);
    },

    /**
     * Render once after view is created
     * @method
     * @return {widget} Rendered widget
     */
    render: function () {
        Volt.log('[MenuView] render()');

        this.setWidget(Volt.loadTemplate(MenuTemplate.menu, {
            menuName: this.model.get('tmpName')
        }));

        this.widget.getChild(0).hide();
        return this;
    },

    /**
     * Event listener on state change of category item
     * @method
     * @param state
     */
    onStateChange: function (state) {
        Volt.err('[MenuView] onStateChange() ::: ' + this.model.get('tmpName') + state);

        this.model.set('uiState', state);
    },

    routing: function () {
        var sRoute = this.model.get('route'),
            nIndex = this.model.get('index'),
            sPageName = this.model.get('pageName');

        if (nIndex != this.collection.currentMenuIndex) {
            Backbone.history.navigate(sRoute, {
                trigger: true
            });
            this.collection.currentMenuIndex = nIndex;
            EventMediator.trigger(CommonDefines.Event.EVENT_MAIN_CATEGORY_CHANGE);
            Volt.KpiMapper.addEventLog('SELECTMENU', {
                d: {
                    sm: sPageName
                }
            });
        }
    },

    /**
     * Event listener on state change of category item
     * @method
     * @param state
     */
    menuStateChange: function (changedModel) {
        if (_.keys(changedModel.changed)[0] == 'uiState') {
            switch (_.values(changedModel.changed)[0]) {
            case 'NORMAL':
                this.widget.getChild(1).textColor = Volt.hexToRgb('#464646', 40);
                this.widget.getChild(0).font = '28px';
                this.widget.getChild(0).hide();
                break;
            case 'SELECTED':
                if (this.isExpand) {
                    this.widget.getChild(0).y = 90 - 4;
                } else {
                    this.widget.getChild(0).y = 72 - 4;
                }
                this.widget.getChild(1).textColor = Volt.hexToRgb('#219ee6', 100);
                this.widget.getChild(0).height = 4;
                this.widget.getChild(0).font = '31px';
                this.widget.getChild(0).show();
                this.collection.currentMenuIndex = this.model.get('index');
                EventMediator.trigger(CommonDefines.Event.EVENT_MAIN_CATEGORY_CHANGE);
                break;

            case 'FOCUSED':
                this.widget.getChild(1).textColor = Volt.hexToRgb('#ffffff', 100);
                this.widget.getChild(0).font = '31px';
                this.widget.getChild(0).y = -18;
                this.widget.getChild(0).height = 108;
                this.widget.getChild(0).show();
                break;

            case 'EXPAND_FOCUSED':
                this.widget.getChild(1).textColor = Volt.hexToRgb('#ffffff', 100);
                this.widget.getChild(0).animate('y', -18, MENU_ANIM_DURATION);
                this.widget.getChild(0).animate('height', 108, MENU_ANIM_DURATION);
                this.widget.getChild(0).show();
                break;
            case 'EXPAND_SELECTED':
                this.widget.getChild(1).textColor = Volt.hexToRgb('#219ee6', 100);
                this.widget.getChild(0).animate('y', 90 - 4, MENU_ANIM_DURATION);
                this.widget.getChild(0).animate('height', 4, MENU_ANIM_DURATION);
                this.widget.getChild(0).show();
                break;
            case 'SHRINK':
                this.widget.getChild(1).textColor = Volt.hexToRgb('#219ee6', 100);
                this.widget.getChild(0).animate('y', 72 - 4, MENU_ANIM_DURATION);
                this.widget.getChild(0).animate('height', 4, MENU_ANIM_DURATION);
                this.widget.getChild(0).show();
                break;
            }
        }
    }
});

exports = MenuListView;
