/** 
 * @author youngil baek (yi01.baek@samsung.com)
 * @fileoverview This module manages featured list view of app.
 * @date    2014/07/23 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ('Confidential Information').  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require('modules/underscore.js')._,
    Q = Volt.require('modules/q.js'),
    VoltJSON = Volt.require('modules/VoltJSON.js');

var EventMediator = Volt.require('app/common/eventMediator.js'),
    MyAppsTemplate = Volt.require('app/templates/1080/myAppsTemplate.js'),
    Models = Volt.require('app/models/models.js'),
    GridListView = Volt.require('app/views/gridListView.js');

var MyAppsVMCollection = Volt.require('app/models/myAppsVMCollection.js');
var voltapi = Volt.require('voltapi.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');
var CommonFunctions = Volt.require('app/common/commonFunctions.js');
var AppInfoProgressView = Volt.require('app/views/appInfoProgressView.js');
var localStorage = Volt.require('lib/volt-local-storage.js');
var DownloadedAppsMgr = Volt.require('app/common/downloadedAppsMgr.js');
var AppInstallMgr = Volt.require('app/common/appInstallMgr.js');
var MENU_ANIM_DURATION = 200,
    sortOption = ['releasedate', 'popularity', 'titleasc', 'titledesc'];
var CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');
var WinsetBtn = Volt.require("WinsetUIElement/winsetButton.js");
var PanelCommon = Volt.require('lib/panel-common.js');
var winsetDimView = Volt.require("lib/views/dim-view.js");
PanelCommon.mapWidget('WinsetBtn', WinsetBtn);
var WinsetBg = Volt.require("WinsetUIElement/winsetBackground.js");
Volt.mapWidget('WinsetBg', WinsetBg);
var DeviceInfoModel = Volt.require("app/models/deviceInfoModel.js");


var tvResoultion = (Volt.APPS720P) ? WinsetBtn.ResoultionStyle.Resoultion_720 : WinsetBtn.ResoultionStyle.Resoultion_1080;
/**
 * @name MyAppsView
 */
var MyAppsView = Volt.BaseView.extend({
    /** @lends MyAppsView.prototype */

    myAppsVMCollection: null,
    template: MyAppsTemplate.container,
    gridlistTmpl: MyAppsTemplate.gridList,

    gridListView: null,
    sortStandard: sortOption[0],
    headerCover: null,

    /**
     * Initialize this view
     * @name MyAppsView
     * @constructs
     */
    initialize: function () {
        Volt.log('[MyAppsView] initialize');
        this.myAppsVMCollection = new MyAppsVMCollection();
    },

    /**
     * render once after view is created
     * @method
     * @param  {widget} parentWidget parentWidget
     * @return {View}              this View
     */
    render: function (parentWidget) {
        Volt.log('[MyAppsView] render');

        this.contentContainer = parentWidget.widget.getChild('main-content-container');

        this.setWidget(Volt.loadTemplate(this.template));
        this.contentContainer.addChild(this.widget);

        return this;
    },

    /**
     * make it be gridList style.
     * @method
     * @param  {Collection} collection myAppsVMCollection
     */
    renderContent: function (collection, common) {
        Volt.log('[MyAppsView] renderContent');

        if (this.myAppsVMCollection.length > 0) {

            if (!this.gridListView) {
                var container = this.widget.getChild('myapps-content-container');
                this.gridlistTmpl.parent = container;
                this.gridListView = this.initNativeGrid();

                container.addChild(this.gridListView.render(this.myAppsVMCollection).widget);
                this.gridListView.widget.showWithAnimation();
            }

            this.gridListView.widget.custom = {
                focusable: true
            };

            this.widget.getChild('myapps-no-content').text = '';

            Volt.Nav.setNextItemRule(this.gridListView.widget, 'up', 'category-list-container');
            Volt.Nav.reload();
        }
    },

    renderCount: function () {
        try {
            var wzSelectedItemsCount = this.contentContainer.parent.getChild('main-category-container').getChild('edit-mode-container').find('.edit-mode-selected-count');
            if (wzSelectedItemsCount.length > 0) {
                wzSelectedItemsCount[0].text = String(this.myAppsVMCollection.getCheckedItemCount());
                if (this.myAppsVMCollection.getCheckedItemCount() == this.myAppsVMCollection.getCheckableItemCount()) {
                    this.editButtonGroupView.isSelectAll = true;
                    this.editButtonGroupView.buttonSelect.setText({
                        state: "all",
                        text: Volt.i18n.t('SID_DESELECT_ALL_KR_CANCEL_ALL')
                    });
                } else if (this.myAppsVMCollection.getCheckedItemCount() == 0) {
                    this.editButtonGroupView.isSelectAll = false;
                    this.editButtonGroupView.buttonSelect.setText({
                        state: "all",
                        text: Volt.i18n.t('COM_SID_SELECT_ALL')
                    });
                }
            }
        } catch (e) {}
    },

    initNativeGrid: function () {
        Volt.log('[MyAppsView] initNativeGrid');

        var gridListView = new GridListView({
            gridListControlParam: this.gridlistTmpl,

            listeners: {
                onDrawLoadData: function (thumbnail, data) {
                    Volt.log('[MyAppsView] onDrawLoadData ' + data.model.get('app_title'));

                    // data: {
                    //     model
                    // }

                    var iView = new MyAppsItemView(data.model, self);
                    iView.render(thumbnail);
                },
                onDrawUpdateData: function (thumbnail, data) {
                    Volt.log('[MyAppsView] onDrawUpdateData');

                    var myAppsVM = data.model;

                    if (myAppsVM) {
                        myAppsVM.updateView(thumbnail);
                    }
                },
                onDrawUnloadData: function (thumbnail, data) {
                    Volt.log('[MyAppsView] onDrawUnloadData');

                    var myAppsVM = data.model;

                    if (myAppsVM) {
                        myAppsVM.destroyView();
                    }
                },
                onGridFocus: function (wzFocused) {
                    Volt.log('[MyAppsView] onGridFocus');
                    if (wzFocused){
                        var voiceText;
                        if (self.myAppsVMCollection.modeType == 'delete' ||
                            self.myAppsVMCollection.modeType == 'lock') {
                            if(self.myAppsVMCollection.modeType == 'delete'){
                                voiceText = Volt.i18n.t('TV_SID_DELETE_MY_APPS') + ',' + 
                                    self.myAppsVMCollection.length + ',' + Volt.i18n.t('TV_SID_ITEMS');
                            }
                            else{
                                voiceText = Volt.i18n.t('TV_SID_LOCK_UNLOCK_MY_APPS') + ',' + 
                                    self.myAppsVMCollection.length + ',' + Volt.i18n.t('TV_SID_ITEMS')
                            }
                            if (wzFocused.customIsDim === true && wzFocused.customIsChecked !== true) {
                                voiceText = voiceText + wzFocused.customTitle + ',' + 
                                    Volt.i18n.t('TV_SID_DISABLED');
                            } else if (wzFocused.customIsChecked === true) {
                                voiceText = voiceText + Volt.i18n.t('TV_SID_CHECKBOX_ACC') + ',' + 
                                    Volt.i18n.t('TV_SID_CHECKED') + ',' + wzFocused.customTitle;
                            } else if (wzFocused.customIsChecked === false) {
                                voiceText = voiceText + Volt.i18n.t('TV_SID_CHECKBOX_ACC') + ',' + 
                                    Volt.i18n.t('TV_SID_UNCHECKED') + ',' + wzFocused.customTitle;
                            }
                        } else {
                            voiceText = Volt.i18n.t('TV_SID_APPS_KR_PANEL') + ' ' + 
                                Volt.i18n.t('TV_SID_MY_APPS_KR_PANEL') + ' ' +
                                Volt.i18n.t('SID_CATEGORY_KR_CA') + ',' +
                                self.myAppsVMCollection.length + ' ' + Volt.i18n.t('TV_SID_ITEMS') + ',' +
                                wzFocused.customTitle;
                            
                            if (wzFocused.customTitle == 'Browser' || wzFocused.customTitle == 'e-Manual') {
                                voiceText = voiceText + ',' + Volt.i18n.t('TV_SD_VOICE_GUIDE_AVAILABLE_SCREEN');
                            }
                        }
                        CommonFunctions.forceDisableVoiceGuide(false);
                        CommonFunctions.voiceGuide(voiceText);
                    }
                },
                onGridBlur: function (wzFocused) {
                    Volt.log('[MyAppsView] onGridBlur');

                    if (wzFocused && typeof wzFocused.trigger == 'function') {
                        wzFocused.trigger('NAV_BLUR');
                    }
                },
                onFocusChangeStart: function (wzFrom, wzTo) {

                },
                onFocusChanged: function (wzFrom, wzTo) {
                    Volt.log('[MyAppsView] onFocusChanged');
                    
                    if (wzTo){
                        var voiceText = "";
                        Volt.log("[myAppsView.js] onFocusChanged myAppsVMCollection.modeType = " + self.myAppsVMCollection.modeType);
                        if (self.myAppsVMCollection.modeType == 'delete' ||
                            self.myAppsVMCollection.modeType == 'lock') {
                            if (wzTo.customIsDim === true && wzTo.customIsChecked !== true) {
                                voiceText = wzTo.customTitle + ',' + Volt.i18n.t('TV_SID_DISABLED');
                            } else if (wzTo.customIsChecked === true) {
                                voiceText = Volt.i18n.t('TV_SID_CHECKBOX_ACC') + ',' + Volt.i18n.t('TV_SID_CHECKED') + ',' + wzTo.customTitle;
                            } else if (wzTo.customIsChecked === false) {
                                voiceText = Volt.i18n.t('TV_SID_CHECKBOX_ACC') + ',' + Volt.i18n.t('TV_SID_UNCHECKED') + ',' + wzTo.customTitle;
                            } 
                        } else { 
                            voiceText =  wzTo.customTitle; 
                            if (wzTo.customTitle == 'Browser' || wzTo.customTitle == 'e-Manual') {
                                voiceText = voiceText + ',' + Volt.i18n.t('TV_SD_VOICE_GUIDE_AVAILABLE_SCREEN');
                            } 
                        }
                        CommonFunctions.voiceGuide(voiceText);
                    }
                },
                onItemPress: function (wz, itemData, data) {
                    Volt.log('[MyAppsView] onItemPress');

                    self.SelectItem(data.model);
                },
                onEnterKeyLongPressed: function (wzFocused, itemData, type) {
                    Volt.log('[MyAppsView] onEnterKeyLongPressed' + itemData + self.myAppsVMCollection.at(itemData) + ' ' + self.myAppsVMCollection.at(itemData).get('app_featured'));

                    if (wzFocused && itemData != -1) {
                        if (Volt.DeviceInfoModel.get('networksStatus') == "NG") {
                            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
                            return;
                        }
                        var vmSelected = self.myAppsVMCollection.at(itemData);
                        if (self.myAppsVMCollection.at(itemData).get('dimFlag')) { 
                            Volt.log('[onEnterKeyLongPressed] dimFlag is  true');
                            return;
                        }
                        var param = {
                            baseWidget: wzFocused,
                            appInfoVM: vmSelected,
                            type: 'myapps',
                            feature: self.myAppsVMCollection.at(itemData).get('app_featured'),
                            is_removable: self.myAppsVMCollection.at(itemData).get('is_removable'),
                        }
                        Volt.log("[MyAppsView] app_title = " + self.myAppsVMCollection.at(itemData).get('app_title'));
                        Volt.log("[MyAppsView] app_feature = " + param.feature);
                        Volt.log("[MyAppsView] is_removable = " + param.is_removable);
                        if (self.myAppsVMCollection.at(itemData).get('app_title') == 'Browser') {
                            param.feature = 2;
                        }
                        if (self.myAppsVMCollection.at(itemData).get('app_title') == 'e-Manual') {
                            param.feature = 2;
                        }
                        if (self.myAppsVMCollection.at(itemData).get('is_edit_mode')) {
                            Volt.log('[MyAppsView] view is on edit mode do not show longpress popup');
                            return;
                        }
                        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_CONTEXTMENU, param);
						if ( type == 'mouse'){
							EventMediator.trigger(CommonDefines.Event.EVENT_LONGPRESS_RELEASE);
						}

                        Volt.KpiMapper.addEventLog('LONGPRESSMA');
                    }
                }
            }

        });

        // for test
        var self = this;

        return gridListView;
    },

    /**
     * callback on selecting
     * @method
     */
    SelectItem: function (model) {
        Volt.log('[MyAppsItemView] onSelect');

        //var self = this;

        if (model.get('is_updating')) { // Updating -> NR
            Volt.log('[MyAppsItemView] NR - state : ' + model.get('state'));
            return;
        }
	if (model.get('dimFlag')) { // Updating -> NR
            Volt.log('[MyAppsItemView] dimFlag is  true');
            return;
        }
        
        if (model.get('is_edit_mode')) { // Edit mode -> toggle checkbox
            Volt.log("model.get(is_edit_mode):" + model.get('is_edit_mode'));
            if (model.get('is_checkable')) model.setChecked();
        } else { // Launch app
            if (0 == AppInstallMgr.launchApp(model.get('app_id'), '')) { //fix bugs of DF141204-01236  Infinite loading add by pei828.yang 20141209
                EventMediator.trigger('HOMEVIEW_LAUNCH_APP');
            }
            model.set('is_updated', 0);

            Volt.KpiMapper.addEventLog('SELECTMA', {
                d: {
                    appid: model.get('app_id'),
                    pn: model.get('app_index')
                }
            });
        }
    },

    removeGrid: function () {
        Volt.log('[MyAppsView] remove grid list');

        if (this.gridListView && this.gridListView.gridListControl) {
            this.gridListView.gridListControl.hide();
            this.gridListView.gridListControl.destroy();
            this.gridListView = null;
        }
    },

    /**
     * show this view
     * @method
     * @param  {object} param         additional data
     * @param  {number} animationType showing animation type
     * @return {object}               promise obj to synchronize logic.
     */
    show: function (param, animationType) {
        Volt.log('[MyAppsView] show');

        var nLocalSortIndex = localStorage.getItem('sortOption') ? localStorage.getItem('sortOption') : 0,
            sLastSort = sortOption[nLocalSortIndex];

        if (this.sortStandard != sLastSort) {
            this.requestFetch(nLocalSortIndex);
        }

        var deferred = Q.defer();

        if (!this.gridListView) {
            this.renderContent();
        } else {
            // this.gridListView.widget.setFocusItemIndex(0, 0);
            this.gridListView.widget.custom = {
                focusable: true
            };
            this.gridListView.widget.showWithAnimation();

            //fix focus issue,  longpress->more->return
            var previousHistory = Backbone.history.hashstack[Backbone.history.hashstack.length - 2];
            var isDetail = (/#detail/g).test(previousHistory);

            if (isDetail) {
                Volt.Nav.focus(this.gridListView.widget);
            }
        }

        if (this.myAppsVMCollection.length == 0) {
            EventMediator.trigger(CommonDefines.Event.EVENT_HOME_SHOW_LOADING); // hide at onReset
        }

        this.widget.show();
        this.bindListener();

        Volt.Nav.reload();

        if (this.isNeedSync()) {
            this.startSync();
        }

        deferred.resolve();
        return deferred.promise;
    },


    /**
     * hide this view
     * @method
     * @param  {number} animationType hiding animation type
     * @return {object}               promise obj to synchronize logic.
     */
    hide: function (animationType) {
        Volt.log('[MyAppsView] hide');

        var deferred = Q.defer();
        deferred.resolve();

        this.widget.hide();
        this.unbindListener();

        if (this.gridListView) {
            this.gridListView.widget.custom = {
                focusable: false
            };
            this.gridListView.widget.hideWithAnimation("autoDestroy");
        }

        return deferred.promise;
    },
    /**
     * pause
     * @method
     */
    pause: function () {
        Volt.log('[MyAppsView] pause');
    },

    bindListener: function () {
        Volt.log('[MyAppsView] bindListener');

        // ���� ��ġ�Ǵ� ���� ������ �ϱ� ���� hide�� stoplistening ���� �ʰ� ���Խ� �ߺ� �������� ���� ������ ��
        this.stopListening(this.myAppsVMCollection);

        this.listenTo(this.myAppsVMCollection, 'reset', this.onReset);

        this.listenTo(this.myAppsVMCollection, 'add', this.onItemAdded);
        this.listenTo(this.myAppsVMCollection, 'remove', this.onItemRemoved);

        this.listenTo(this.myAppsVMCollection, 'error', this.showErrorPopup);
        this.listenTo(this.myAppsVMCollection, 'change:is_checked', this.renderCount);

        this.listenTo(EventMediator, 'SHOW_EDIT_MODE', this.showEditMode);
        this.listenTo(EventMediator, 'HIDE_EDIT_MODE', this.hideEditMode);
        this.listenTo(EventMediator, 'EDIT_MODE_SELECT_ALL', this.setSelectAll);
        this.listenTo(EventMediator, 'EDIT_MODE_EXECUTE', this.editModeExecute);

        this.listenTo(EventMediator, 'SORT_GRID_LIST', this.onSortGridList);
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MY_APPS_SINGLE_DELETE, this.checkAppIsLockForDelete);
        this.listenTo(EventMediator, CommonDefines.Event.MSGBOX_BUTTON, this.processMsgBoxEvent, this);
    },

    unbindListener: function () {
        Volt.log('[MyAppsView] unbindListener');

        this.stopListening(EventMediator, 'SHOW_EDIT_MODE');
        this.stopListening(EventMediator, 'HIDE_EDIT_MODE');
        this.stopListening(EventMediator, 'SORT_GRID_LIST');
        this.stopListening(EventMediator, 'EDIT_MODE_EXECUTE');
        this.stopListening(EventMediator, CommonDefines.Event.EVENT_MY_APPS_SINGLE_DELETE);
        this.stopListening(EventMediator, CommonDefines.Event.MSGBOX_BUTTON);

    },

    onReset: function () {
        Volt.log('[MyAppsView] onReset');
        this.removeGrid();
        this.renderContent();
        EventMediator.trigger(CommonDefines.Event.EVENT_HOME_HIDE_LOADING);
    },

    onItemAdded: function (model, collection, options) {
        Volt.log('[MyAppsView] onItemAdded');

        if (options && options.add) {
            this.gridListView.addItem(model);
            if (('delete' == this.myAppsVMCollection.modeType) || ('lock' == this.myAppsVMCollection.modeType)) {
                Volt.log('[MyAppsView] set to is_edit_mode');
                model.set('is_edit_mode', true);
                this.editButtonGroupView.isSelectAll = false;
                this.editButtonGroupView.buttonSelect.setText({
                    state: "all",
                    text: Volt.i18n.t('COM_SID_SELECT_ALL')
                });

            }
        }
    },

    onItemRemoved: function (model, collection, options) {
        // options.index : deleted model's index in collection

        Volt.log('[MyAppsView] onItemRemoved');

        if (options && options.index !== undefined) {
            this.gridListView.removeItem(options.index, options.index);

            var uninstallList = AppInstallMgr.getAllUnInstallList();
            if (uninstallList && uninstallList.length === 0) {
                //EventMediator.trigger(CommonDefines.Event.EVENT_HOME_HIDE_LOADING);
            }
        } else {
            Volt.log('[MyAppsView] options exist : ' + (options != null));
            if (options) {
                Volt.log('[MyAppsView] options.index : ' + options.index);
            }
        }
    },
    /**
     * set msgbox button click callback
     * @method  caoyr 11.14
     * @memberof FeaturedListView
     */
    processMsgBoxEvent: function (data) {
        Volt.log('[myAppsView] processMsgBoxEvent:type is:' + data.msgBoxtype + " eventType is:" + data.eventType);
        if (data.eventType == CommonDefines.Event.SELECT_BTN1) {
            switch (data.msgBoxtype) {
            case CommonDefines.MsgBoxType.TYPE_DELETE_MY_APPS:
                Volt.log('[myAppsView] processMsgBoxEvent: ok' + data.appID);
                //EventMediator.trigger('HIDE_EDIT_MODE');
                this.hideEditMode();
                //EventMediator.trigger(CommonDefines.Event.EVENT_HOME_SHOW_LOADING);//delete loading view when delete locked app item
                //Volt.Nav.focus();
                if (data.appID.length == 1) {
                    this.myAppsVMCollection.deleteApps('single', data.appID,this.bIsLock);
                }
                if (data.appID.length > 1) {
                    this.myAppsVMCollection.deleteApps('multi', data.appID,this.bIsLock);
                }



                break;
            case CommonDefines.MsgBoxType.MSGBOX_TYPE_SERVER_ERROR_GUIDE:
                Volt.log('[myappsView] processMsgBoxEvent: ok');
                Backbone.history.back();
                break;
            default:
                break;
            }
        } else if (data.eventType == CommonDefines.Event.SELECT_BTN2) {
            Volt.log('[myAppsView.js] processMsgBoxEvent:SELECT_BTN2');
            switch (data.msgBoxtype) {
            case CommonDefines.MsgBoxType.TYPE_DELETE_MY_APPS:
                Volt.log('[myAppsView] processMsgBoxEvent: ok');
                //fix DF141215-01487,user may still want to delete the other items, do not need to exit delete mode
                //EventMediator.trigger('HIDE_EDIT_MODE');
                break;
            default:
                break;
            }
        }
    },
    /**
     * Callback function of plus button select.
     * @method
     * @param  {int} index    Selected index of menu
     * @param  {int} subIndex Selected index of sub menu
     */
    requestFetch: function (sLastSort) {
        Volt.log('[MyAppsView] requestFetch(' + sLastSort + ')');

        this.myAppsVMCollection.clear();

        switch (sLastSort) {
        case 0:
            this.myAppsVMCollection.fetch(CommonDefines.WAS.VIEWMODE_LASTDOWNLOAD);
            break;

        case 1:
            this.myAppsVMCollection.fetch(CommonDefines.WAS.VIEWMODE_MOSTLYPLAYED);
            break;

        case 2:
            this.myAppsVMCollection.fetch(CommonDefines.WAS.VIEWMODE_A_TO_Z);
            break;

        case 3:
            this.myAppsVMCollection.fetch(CommonDefines.WAS.VIEWMODE_Z_TO_A);
            break;
        }

        this.sortStandard = sortOption[sLastSort];
    },

    showErrorPopup: function (serverError) {
        Volt.log('[MyAppsView] showErrorPopup');

        if (serverError.code == 'AS666') {
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
        } else {
            /*var setPopup = {
                text: serverError.message + '(' + serverError.code + ')',
                buttons: [{
                    name: Volt.i18n.t('COM_SID_OK')
                }]
            };

            var guidePopup = new MsgPopupView(setPopup);*/
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_SERVER_ERROR_GUIDE, serverError);
        }
    },

    showDisconnectPopup: function () {
        Volt.log('[MyAppsView] showDisconnectPopup');

        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
    },

    showDeleteConfirmPopup: function (app_id) {
        Volt.log('[MyAppsView] showDeleteConfirmPopup');
        Volt.log('CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_DELETE_MY_APPS,app_id:)' + app_id);
        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_DELETE_MY_APPS, app_id);
    },

    checkAppIsLockForDelete: function (app_id) {
        Volt.log('[MyAppsView] checkAppIsLockForDelete' + app_id);
        this.bIsLock = false,
            self = this;
		
        var app_ID = [];
        if (app_id == null)
		{
			app_ID = this.myAppsVMCollection.getCheckedItemAppID();
			if (app_ID.length == 0) {
				EventMediator.trigger('HIDE_EDIT_MODE');
				return;
			}
		}
		else{
			print("app_id" +app_id);
			app_ID[0] = app_id;
		}
		print("app_id" +app_id);
		this.bIsLock = this.myAppsVMCollection.getLockedFlag(app_id);
        // when param not exist, may be multi delete 
        /*if (!app_id) {
            if (!this.myAppsVMCollection.checkHaveMultiDeleteApps()) {
                EventMediator.trigger('HIDE_EDIT_MODE');
                return;
            } else if (this.myAppsVMCollection.where({ is_lock : 1, is_checked : true }).length > 0) {
                this.bIsLock = true;
            }
        } 
        if (this.myAppsVMCollection.where({ app_id : app_id, is_lock : 1 }).length > 0) { // for single delete
            this.bIsLock = true;
        }*/

        Volt.log("showDeleteConfirmPopup^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^"+this.bIsLock); //do not need check lock,volt team will lunch pinpopup
        this.showDeleteConfirmPopup(app_ID);
    },

    showEditMode: function (sType) {
        Volt.log('[MyAppsView] showEditMode');
        if (true == this.myAppsVMCollection.modeType) {
            Volt.log('[MyAppsView] already show edit view');
            return;
        }
        this.renderHeaderCover();
        var wzMenuListContainer = this.contentContainer.parent.getChild('main-category-container');
        var wzMenuList = wzMenuListContainer.getDescendant('category-list-container');
        Volt.Nav.focus(null); //unfocus menu
        wzMenuList.hide();

        this.myAppsVMCollection.setEditMode(sType, true);

        if (!this.editButtonGroupView) {
            this.editButtonGroupView = new EditButtonGroupView(this.contentContainer.parent);
            this.editButtonGroupView.render(this);
            wzMenuListContainer.addChild(this.editButtonGroupView.widget);
        }

        if (this.editButtonGroupView) this.editButtonGroupView.show(sType);

        if (this.gridListView) {
            Volt.Nav.setNextItemRule(this.gridListView.widget, 'up', 'edit-select-button');
            Volt.Nav.setNextItemRule(this.editButtonGroupView.widget.getDescendant('edit-select-button'), 'down', this.gridListView.widget);
            Volt.Nav.setNextItemRule(this.editButtonGroupView.widget.getDescendant('edit-select-button'), 'left', this.editButtonGroupView.widget.getDescendant('edit-select-button'));
            Volt.Nav.setNextItemRule(this.editButtonGroupView.widget.getDescendant('edit-exceute-button'), 'down', this.gridListView.widget);
            Volt.Nav.setNextItemRule(this.editButtonGroupView.widget.getDescendant('edit-cancel-button'), 'down', this.gridListView.widget);
        }

        // focus first item
        this.gridListView.widget.setFocusItemIndex(0, 0);
        Volt.Nav.focus(this.gridListView.widget);
        this.gridListView.widget.event = false; // EVENT_KEY_RELEASE is delievered to gridListView. This makes the first item checked.
    },

    hideEditMode: function (sType) {
        Volt.log('[MyAppsView] hideEditMode');
        if (false == this.myAppsVMCollection.modeType) {
            Volt.log('[MyAppsView] hide edit view');
            return;
        }
        var wzMenuListContainer = this.contentContainer.parent.getChild('main-category-container');
        var wzMenuList = wzMenuListContainer.getDescendant('category-list-container');
        //this.contentContainer.parent.find('.list-arrow')[0].show();
        //      this.contentContainer.parent.find('.list-arrow')[1].show();

        Volt.Nav.focus(null);
        if (this.editButtonGroupView) this.editButtonGroupView.hide();

        if (this.gridListView) Volt.Nav.setNextItemRule(this.gridListView.widget, 'up', 'category-list-container');

        this.myAppsVMCollection.setEditMode(sType, false);

        if (wzMenuList.custom) wzMenuList.custom.focusable = true;
        wzMenuList.show();

        this.destroyHeaderCover();
        Volt.Nav.reload();
        Volt.Nav.focus(Volt.Nav.getItem(1));
    },

    setSelectAll: function (flag) {
        CommonFunctions.forceDisableVoiceGuide(true);
        this.myAppsVMCollection.setSelectAll(flag);
        CommonFunctions.forceDisableVoiceGuide(false);
    },

    editModeExecute: function (type) {
        if (type == 'delete') {
            this.checkAppIsLockForDelete();
        } else if (type == 'lock') {
            this.myAppsVMCollection.setAppLock();
            EventMediator.trigger('HIDE_EDIT_MODE');
        }
    },

    /**
     * Callback function of plus button select.
     * @method
     * @param  {int} index    Selected index of menu
     * @param  {int} subIndex Selected index of sub menu
     */
    onSortGridList: function (index) {
        Volt.log('[MyAppsView] onSortGridList');

        var optionMenu = parseInt(index, 10);

        if (index == -1) return;

        this.myAppsVMCollection.clear();
        EventMediator.trigger(CommonDefines.Event.EVENT_HOME_SHOW_LOADING);
        switch (optionMenu) {
        case 0:
            this.myAppsVMCollection.fetch(CommonDefines.WAS.VIEWMODE_LASTDOWNLOAD);
            break;

        case 1:
            this.myAppsVMCollection.fetch(CommonDefines.WAS.VIEWMODE_MOSTLYPLAYED);
            break;

        case 2:
            this.myAppsVMCollection.fetch(CommonDefines.WAS.VIEWMODE_A_TO_Z);
            break;

        case 3:
            this.myAppsVMCollection.fetch(CommonDefines.WAS.VIEWMODE_Z_TO_A);
            break;
        }
        this.sortStandard = sortOption[optionMenu];
    },

    isNeedSync: function () {
        Volt.log('[MyAppsView] isNeedSync');

        var wasSyncState = voltapi.WAS.getAppsSyncState(),
            bNeedSync = wasSyncState != CommonDefines.WAS.WAS_APPS_SYNC_COMPLETED;

        // for test
        // bNeedSync = true;

        // for debug
        var enum2str = {
            '10': 'WAS_APPS_SYNC_STATE_INIT',
            '11': 'WAS_APPS_SYNC_STATE_START',
            '12': 'WAS_APPS_SYNC_STATE_UNINSTALL_COMPLETED',
            '13': 'WAS_APPS_SYNC_INSTALL_COMPLETED',
            '14': 'WAS_APPS_SYNC_COMPLETED'
        };
        Volt.log('[MyAppsView] voltapi.WAS.getAppsSyncState() returns ' + wasSyncState + ' : ' + enum2str[wasSyncState]);

        return bNeedSync;
    },

    startSync: function () {
        Volt.log('[MyAppsView] startSync');

        var AppsSyncVM = Volt.require('app/models/appsSyncVM.js');

        this.appsSyncVM = new AppsSyncVM();

        this.listenTo(this.appsSyncVM, 'SYNC_TO_BE_INSTALL', this.onSyncToBeInstall);
        this.listenTo(this.appsSyncVM, 'APPS_SYNC_COMPLETED', this.onAppsSyncCompleted);

        this.appsSyncVM.start();

        Volt.Nav.reload();
    },

    onSyncToBeInstall: function (apps) {
        Volt.log('[MyAppsView] onSyncToBeInstall');

        // for debug
        Volt.log(JSON.stringify(apps));

        this.myAppsVMCollection.add(apps);
    },

    onAppsSyncCompleted: function () {
        Volt.log('[MyAppsView] onAppsSyncCompleted');

        if (this.appsSyncVM) {
            this.appsSyncVM.destroy();
            this.appsSyncVM = null;
        }

        this.myAppsVMCollection.refresh();

        Volt.Nav.reload();
    },

    renderHeaderCover: function () {
        Volt.log('[MyAppsView] renderHeaderCover');

        if (this.headerCover) {
            return;
        }

        this.headerCover = Volt.loadTemplate(MyAppsTemplate.headerCover);
        this.headerCover.addEventListener('OnMouseOver', this._blockMouse);
    },

    destroyHeaderCover: function () {
        Volt.log('[MyAppsView] destroyHeaderCover');
        if (this.headerCover) {
            this.headerCover.removeEventListener('onMouseOver', this._blockMouse);
            this.headerCover.destroy();
            this.headerCover = null;
        }
    },

    _blockMouse: function () {}

});

/**
 * @name MyAppsItemView
 */
var MyAppsItemView = Volt.BaseView.extend({
    /** @lends MyAppsItemView.prototype */

    thumbnail: null,
    myAppsVM: null,
    bgmode: 'DARK',
    renderedIcons: null,
    MAX_ICON: 4,
    parentView: null,

    events: {
        //'NAV_SELECT': 'onSelect',
        'NAV_BLUR': 'onBlur',
        'NAV_FOCUS': 'onFocus'
    },

    /**
     * initialize
     * @name MyAppsItemView
     * @constructs
     * @param  {Model} model VM correspond to this
     */
    initialize: function (model, parentView) {
        Volt.log('[MyAppsItemView] initialize');

        this.myAppsVM = model;
        this.parentView = parentView;
        this.bindListener();
    },

    /**
     * render this view
     * @method
     * @param  {type} widget rendering appItemView's widget
     */
    render: function (thumbnail) {
        Volt.log('[MyAppsItemView] render');

        var self = this;
        var data, textColor, itemTmpl, iconTmpls, thumbListener;

        this.thumbnail = thumbnail;

        data = this.myAppsVM.toJSON();

        // Make thumbnail template
        itemTmpl = JSON.parse(JSON.stringify(MyAppsTemplate.item)); // use JSON for deep copy
        iconTmpls = this.makeIconTmpls();

        _.extend(itemTmpl.information, iconTmpls);

        itemTmpl.image.src = data.app_panel_icon_path || data.panel_icon || Volt.getRemoteUrl('images/1080/common/apps_screenshot_default.png'); // AppsSync() returns 'panel_icon' instead of 'app_panel_icon_path'
        itemTmpl.information.text1.text = data.app_title;

        // Color pick
        thumbListener = new ThumbnailListener();
        thumbListener.onImageReady = function (thumbnail, id, success) {


            if (success == true) {
                Volt.setTimeout(function () {
                    var informationColorpick = thumbnail.getInformationColorPicking(),
                        textColorpick = HALOUtil.extractIconColor(informationColorpick.r, informationColorpick.g, informationColorpick.b);

                    // set thumbnail color pick
                    thumbnail.color = {
                        r: informationColorpick.r,
                        g: informationColorpick.g,
                        b: informationColorpick.b,
                        a: 255
                    };

                    thumbnail.setInformationColor({
                        r: 0,
                        g: 0,
                        b: 0,
                        a: 20.4
                    });

                    // set bg color type
                    if (textColorpick == HALOUtil.CC_WHITE) {
                        self.bgmode = 'LIGHT';
                    } else {
                        self.bgmode = 'DARK';
                    }

                    self.renderIcons(thumbnail);
                }, 10);
            } else { // parse false, set default image instead
                Volt.setTimeout(function () {
                    Volt.log("********************");
                    thumbnail.setContentImage(Volt.getRemoteUrl('images/1080/common/apps_screenshot_default.png'));
                }, 10);
            }
        };
        thumbnail.addThumbnailListener(thumbListener);

        // Set thumbnail template
        thumbnail.setThumbnailStyle(itemTmpl);

        //add by lihao.zha@10141118, to pass app title to onFocusChanged function
        thumbnail.customTitle = data.app_title || '';
        thumbnail.customSupportVoice = data.is_support_voice;

        var dimWin = new WidgetEx({
            parent: thumbnail,
            x: itemTmpl.information.x,
            y: itemTmpl.information.y,
            width: itemTmpl.information.width,
            height: itemTmpl.information.height,
            color: {
                r: 0,
                g: 0,
                b: 0,
                a: 20.4
            }
        });

        // Set component properties
        thumbnail.setProgressRange(0, 200); // downloading + installing

        // Set widget
        this.setWidget(thumbnail);

        // Render checkbox
        this.onIsCheckedChanged(this.myAppsVM, this.myAppsVM.get('is_checked'));

        // Render progress
        this.onStateChanged(this.myAppsVM, this.myAppsVM.get('state'));

        // Render dim
        Volt.log("[myAppsView.js] data.is_multi_screen2 is " + data.is_multi_screen2);
        var result = Vconf.getInteger("db/mls/mls_state"); //add for Multi-link screen
        if (result == 1) {
            Volt.log("[myAppsView.js] MLS:result is 1");
            if (1 == data.is_multi_screen2) {
                this.onIsDimChanged(this.myAppsVM, this.myAppsVM.get('is_dim'));
            } else {
                this.thumbnail.customIsDim = true;
                this.thumbnail.dim(true);
		   this.dimFlag = true;
		   this.myAppsVM.set('dimFlag',true);
            }
        } else {
            this.onIsDimChanged(this.myAppsVM, this.myAppsVM.get('is_dim'));
        }

        // TTS
        //removed by lihao.zha@20141118, move tts to onFocusChanged function
        //thumbnail.setTTSText({text: data.app_title || ''});
    },

    makeIconTmpls: function () {
        var iconTmpls = {},
            aIcons = this.getIconsToRender();

        for (var i = 0; i < aIcons.length; i++) {

            tmpl = aIcons[i].tmpl;
            iconId = 'icon' + (i + 1); // 1-base

            iconTmpls[iconId] = aIcons[i].tmpl;
        }

        // Save to find 'update' icon position
        this.renderedIcons = aIcons;

        return iconTmpls;
    },

    renderIcons: function (thumbnail) {
        Volt.log('[MyAppsItemView] renderIcons');

        var aIcons = this.getIconsToRender(),
            tmpl, iconId;

        for (var i = 0; i < this.MAX_ICON; i++) {

            iconId = 'icon' + (i + 1); // 1-base

            if (i < aIcons.length) {
                tmpl = aIcons[i].tmpl;

                thumbnail.visualizeInformationIcon(true, iconId);
                thumbnail.setElementAllocation('information-' + iconId, {
                    x: tmpl.x,
                    y: tmpl.y,
                    width: tmpl.width,
                    height: tmpl.height
                });
                thumbnail.setInformationIcon(iconId, tmpl.src);
            } else {
                thumbnail.visualizeInformationIcon(false, iconId);
            }

        }
    },

    getIconsToRender: function () {

        // Filter icons to render
        var iconTmpls = this.getIconTmpls(),
            aIcons = [];

        if (this.myAppsVM.get('type') == 'user_usb') aIcons.push({
            type: 'usb',
            tmpl: iconTmpls.usb
        });
        if (this.myAppsVM.get('is_lock') == 1) aIcons.push({
            type: 'lock',
            tmpl: iconTmpls.lock
        });

        // for test
        // aIcons.push({type: 'usb', tmpl: iconTmpls.usb});
        // aIcons.push({type: 'lock', tmpl: iconTmpls.lock});

        // Arrage icon position
        var MARGIN = 7,
            x = 20;

        _.each(aIcons, function (icon) {
            icon.tmpl.x = x;
            x = x + icon.tmpl.width + MARGIN;
        });

        // for debug
        // for (var i = 0; i < aIcons.length; i++) {
        //     Volt.log('ICON TYPE: ' + aIcons[i].type);
        //     Volt.log('ICON X   : ' + aIcons[i].tmpl.x);
        // }

        if (this.myAppsVM.get('is_need_update') == 1) aIcons.push({
            type: 'update',
            tmpl: iconTmpls.update
        });
        if (this.myAppsVM.get('is_updated') == 1) aIcons.push({
            type: 'updated',
            tmpl: iconTmpls.updated
        });

        // for test
        // aIcons.push({type: 'update', tmpl: iconTmpls.update});
        // aIcons.push({type: 'updated', tmpl: iconTmpls.updated});

        // for adjustment of information text field's X position.
        var xForUpdateIcons = 0;
        if (this.myAppsVM.get('is_need_update') == 1 || this.myAppsVM.get('is_updated') == 1) xForUpdateIcons = iconTmpls.update.width;

        this.thumbnail.setElementAllocation('information-text1', {
            x: x,
            y: MyAppsTemplate.item.information.text1.y,
            width: MyAppsTemplate.gridList.itemWidth - x - MARGIN - 20 - xForUpdateIcons,
            height: MyAppsTemplate.item.information.text1.height
        });

        return aIcons;
    },

    getIconTmpls: function () {
        var iconTmpls;
        if (this.bgmode == 'DARK') {
            iconTmpls = {
                usb: MyAppsTemplate.usbIcon_w,
                lock: MyAppsTemplate.lockIcon_w,
                update: MyAppsTemplate.updateIcon,
                updated: MyAppsTemplate.updatedIcon
            };
        } else { // 'LIGHT'
            iconTmpls = {
                usb: MyAppsTemplate.usbIcon_b,
                lock: MyAppsTemplate.lockIcon_b,
                update: MyAppsTemplate.updateIcon,
                updated: MyAppsTemplate.updatedIcon
            };
        }
        return _.extend({}, iconTmpls);
    },

    /**
     * Call when it is focused
     * @method
     */
    onFocus: function () {
        Volt.log('[MyAppsItemView] onFocus');
    },

    /**
     * Call when it is blurred
     * @method
     */
    onBlur: function () {
        Volt.log('[MyAppsItemView] onBlur');
    },

    dimMlsView: function () {
        Volt.log('[MyAppsItemView] dimMlsView');
        var data = this.myAppsVM.toJSON();
        Volt.log('[MyAppsItemView] data.is_multi_screen2 is ' + data.is_multi_screen2);
        if (0 == data.is_multi_screen2) {
            this.thumbnail.dim(true);
	      this.myAppsVM.set('dimFlag',true);
        }
    },
    unDimMlsView: function () {
        Volt.log('[MyAppsItemView] unDimMlsView');
        var data = this.myAppsVM.toJSON();
        Volt.log('[MyAppsItemView] data.is_multi_screen2 is ' + data.is_multi_screen2);
        if (0 == data.is_multi_screen2) {
            this.thumbnail.dim(false);
            this.onIsDimChanged(this.myAppsVM, this.myAppsVM.get('is_dim'));
	      this.myAppsVM.set('dimFlag',false);
        }
    },
    bindListener: function () {
        this.listenTo(this.myAppsVM, 'DESTROY_VIEW', this.onDestroyView);
        this.listenTo(this.myAppsVM, 'UPDATE_VIEW', this.onUpdateView);

        this.listenTo(this.myAppsVM, 'change:state', this.onStateChanged);
        this.listenTo(this.myAppsVM, 'change:progress', this.onProgressChanged);
        this.listenTo(this.myAppsVM, 'change:is_checked', this.onIsCheckedChanged);
        this.listenTo(this.myAppsVM, 'change:is_lock', this.onIsLockChanged);
        this.listenTo(this.myAppsVM, 'change:is_updated', this.onIsUpdatedChanged);
        this.listenTo(this.myAppsVM, 'change:is_dim', this.onIsDimChanged);
        this.listenTo(EventMediator, CommonDefines.Event.MLS_DIM_MYAPPS_VIEW, this.dimMlsView);
        this.listenTo(EventMediator, CommonDefines.Event.MLS_UNDIM_MYAPPS_VIEW, this.unDimMlsView);

    },

    unbindListener: function () {
        this.stopListening();
    },

    onDestroyView: function () {
        Volt.log('[MyAppsItemView] onDestroyView ' + this.myAppsVM.get('app_title'));

        this.unbindListener();
    },

    onUpdateView: function (thumbnail) {
        Volt.log('[MyAppsItemView] onUpdateView ' + this.myAppsVM.get('app_title'));

        this.thumbnail = thumbnail;
        this.setWidget(thumbnail);

        // Update information
        thumbnail.setContentImage(this.myAppsVM.get('app_panel_icon_path') || this.myAppsVM.get('panel_icon'));
        thumbnail.setInformationText('text1', this.myAppsVM.get('app_title'));
        thumbnail.customTitle = this.myAppsVM.toJSON().app_title || '';
        thumbnail.customSupportVoice = this.myAppsVM.toJSON().is_support_voice;
        this.renderIcons(thumbnail);

        // Render checkbox
        this.onIsCheckedChanged(this.myAppsVM, this.myAppsVM.get('is_checked'));

        // Render progress
        this.onStateChanged(this.myAppsVM, this.myAppsVM.get('state'));

        // Render dim
        this.onIsDimChanged(this.myAppsVM, this.myAppsVM.get('is_dim'));

        // TTS
        //modified by lihao.zha@20141118, move tts to onFocusChanged function
        //thumbnail.setTTSText({text: this.myAppsVM.get('app_title') || ''});
    },

    onStateChanged: function (model, value, options) {
        Volt.log('[MyAppsItemView] onStateChanged ' + value);

        switch (value) {
        case 'UPDATE_START':
            // [TODO] Dim ó��
            this.thumbnail.setProgressValue(0);
            this.thumbnail.visualizeThumbnailStyle(true, CommonDefines.Const.THUMB_STYLE_PROGRESSBAR);
            break;
        case 'DOWNLOADING':
        case 'DOWNLOAD_COMPLETED':
        case 'INSTALLING':
            break;
        case 'INSTALL_COMPLETED':
            // [TODO] Dim ó��
            this.thumbnail.visualizeThumbnailStyle(false, CommonDefines.Const.THUMB_STYLE_PROGRESSBAR);
            this.aniUpdateComplete();
            break;
        case 'DOWNLOAD_FAIL':
        case 'INSTALL_FAIL':
            this.thumbnail.visualizeThumbnailStyle(false, CommonDefines.Const.THUMB_STYLE_PROGRESSBAR);
            this.thumbnail.setProgressValue(0);
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_FAIL_DOWNLOAD, options.eventType);
            break;
        default:
            this.thumbnail.visualizeThumbnailStyle(false, CommonDefines.Const.THUMB_STYLE_PROGRESSBAR);
            this.thumbnail.setProgressValue(0);
            break;
        }

    },

    onProgressChanged: function (model, value, options) {
        Volt.log('[MyAppsItemView] onProgressChanged ' + value + ' : ' + this.myAppsVM.get('app_title'));

        var state = this.myAppsVM.get('state');

        switch (state) {
        case 'DOWNLOADING':
            this.thumbnail.visualizeThumbnailStyle(true, CommonDefines.Const.THUMB_STYLE_PROGRESSBAR);
            this.thumbnail.setProgressValue(value);
            break;
        case 'INSTALLING':
            this.thumbnail.visualizeThumbnailStyle(true, CommonDefines.Const.THUMB_STYLE_PROGRESSBAR);
            this.thumbnail.setProgressValue(100 + value);
            break;
        default:
            break;
        }
    },

    onIsCheckedChanged: function (model, value, options) {
        Volt.log('[MyAppsItemView] onIsCheckedChanged ' + value);

        if (value) {
            this.thumbnail.setDimBackgroundColor({
                r: 0x21,
                g: 0x9e,
                b: 0xe6,
                a: 255 * 0.6
            }); // default dim color
            this.thumbnail.customIsChecked = true;
            if (this.parentView.myAppsVMCollection.modeType == 'delete' || this.parentView.myAppsVMCollection.modeType == 'lock') {
                CommonFunctions.voiceGuide(Volt.i18n.t('TV_SID_CHECKED'));
            }
        } else {
            this.thumbnail.setDimBackgroundColor({
                r: 0,
                g: 0,
                b: 0,
                a: 255 * 0.8
            }); // default dim color
            this.thumbnail.customIsChecked = false;
            if (this.parentView.myAppsVMCollection.modeType == 'delete' || this.parentView.myAppsVMCollection.modeType == 'lock') {
                CommonFunctions.voiceGuide(Volt.i18n.t('TV_SID_UNCHECKED'));
            }
        }
        EventMediator.trigger(CommonDefines.Event.EVENT_MYAPP_CHECK_ITEMNUM_CHANGE);
        this.thumbnail.visualizeThumbnailStyle(value, CommonDefines.Const.THUMB_STYLE_CHECKBOX);
    },

    onIsLockChanged: function (model, value, options) {
        Volt.log('[MyAppsItemView] onIsLockChanged ' + value);

        this.renderIcons(this.thumbnail);
    },

    onIsUpdatedChanged: function (model, value, options) {
        Volt.log('[MyAppsItemView] onIsUpdatedChanged ' + value);

        this.renderIcons(this.thumbnail);
    },

    onIsDimChanged: function (model, value, options) {
        Volt.log('[MyAppsItemView] onIsDimChanged ' + model.get('app_title') + ' ' + value);

        this.thumbnail.customIsDim = value;
        this.thumbnail.dim(value);
        this.thumbnail.raiseElement('progressBar');
        this.thumbnail.raiseElement('checkBox');
    },

    aniUpdateComplete: function () {
        Volt.log('[MyAppsItemView] aniUpdateComplete');

        var self = this,

            // animation image sources
            aniImgPath = Volt.getRemoteUrl('images/1080/common/icon_update_sequence_0<<A>>.png'),
            aniImgNums = [1, 2, 3, 4, 5, 6],

            // find 'update' icon position
            icon = _.findWhere(this.renderedIcons, {
                type: 'update'
            }),
            idx = _.indexOf(this.renderedIcons, icon),
            iconId;

        if (idx >= 0) {

            iconId = 'icon' + (idx + 1); // 1-base

            for (var i = 0; i < aniImgNums.length; i++) {
                (function (idx) {
                    Volt.setTimeout(function () {
                        self.thumbnail.setInformationIcon(iconId, aniImgPath.replace('<<A>>', aniImgNums[idx]));
                    }, 100 * idx);
                })(i);
            }
        }
    },

});

var EditButtonGroupView = Volt.BaseView.extend({
    /** @lends EditButtonGroupView.prototype */

    template: MyAppsTemplate.editModeContainer,
    isSelectAll: false,
    executeType: null,
    btnListener: new ButtonListener(),
    parentView: null,
    /**
     * Initialize EditButtonGroupView
     * @method
     */
    initialize: function (parentWidget) {
        this.parent = parentWidget;
        this.btnListener.onButtonClicked = function (button, type) {
            this.onSelectButton(button);
        }.bind(this);
    },

    events: {
        'NAV_FOCUS #edit-select-button': 'onFocusButton',
        'NAV_BLUR #edit-select-button': 'onBlurButton',
        //'NAV_SELECT #edit-select-button' : 'onSelectButton',

        'NAV_FOCUS #edit-cancel-button': 'onFocusButton',
        'NAV_BLUR #edit-cancel-button': 'onBlurButton',
        //'NAV_SELECT #edit-cancel-button' : 'onSelectButton',

        'NAV_FOCUS #edit-exceute-button': 'onFocusButton',
        'NAV_BLUR #edit-exceute-button': 'onBlurButton',
        //'NAV_SELECT #edit-exceute-button' : 'onSelectButton'
    },

    /**
     * Render this view.
     * @method
     */
    render: function (parentView) {
        this.parentView = parentView;

        var highContrast = DeviceInfoModel.get('highContrast');

        var flag = highContrast || '0';

        this.container = Volt.loadTemplate(this.template, {
            highconstract: flag
        });

        var title_w = this.container.getChild('select-title').width;
        this.container.getChild('select-count').x = this.container.getChild('select-title').x + title_w;


        this.selectAllBg = this.container.getDescendant('edit-select-button');
        this.buttonSelect = this.createButton(this.selectAllBg, Volt.i18n.t('COM_SID_SELECT_ALL'));
        this.buttonSelect.id = "select-all-button";

        this.isChecked = false;
        this.deleteBg = this.container.getDescendant('edit-exceute-button');
        this.buttonExecute = this.createButton(this.deleteBg, Volt.i18n.t('SID_DESELECT_ALL_KR_CANCEL_ALL'));
        this.buttonExecute.id = "delete-button";

        this.cancelBg = this.container.getDescendant('edit-cancel-button');
        this.buttonCancel = this.createButton(this.cancelBg, Volt.i18n.t('COM_SID_CANCEL'));
        this.buttonCancel.id = "cancel-button";

        if (Volt.APPS_REVERSE) {
            this.selectAllBg.x = Volt.width - this.selectAllBg.x - this.selectAllBg.width;
            this.deleteBg.x = Volt.width - this.deleteBg.x - this.deleteBg.width;
            this.cancelBg.x = Volt.width - this.cancelBg.x - this.cancelBg.width;
        }
        this.container.addChild(this.selectAllBg);
        this.container.addChild(this.deleteBg);
        this.container.addChild(this.cancelBg);
        this.buttonExecute.enable(false);
        this.setWidget(this.container);

        return this;
    },

    /**
     * Show this view.
     * @method
     */
    show: function (sType) {
        Volt.log("[EditButtonGroupView] show()");
        this.executeType = sType;
        this.setExecuteButtonText();

        this.parent.getDescendant('main-header-icon-search').custom.focusable = false;
        this.parent.getDescendant('main-header-icon-option').custom.focusable = false;
        this.parent.getDescendant('main-header-icon-close').custom.focusable = false;
        this.parent.getDescendant('category-list-container').custom.focusable = false;

        this.widget.getChild('edit-cancel-button').custom.focusable = true;
        this.widget.getChild('edit-select-button').custom.focusable = true;

        this.buttonExecute.enable(false);
        this.widget.getChild('edit-exceute-button').custom.focusable = false;

        this.widget.find('.edit-mode-selected-count')[0].text = String(this.parentView.myAppsVMCollection.getCheckedItemCount());
        this.buttonSelect.setText({
            state: "all",
            text: Volt.i18n.t('COM_SID_SELECT_ALL')
        });
        this.isSelectAll = false;

        this.widget.show();

        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MAIN_CATEGORY_FOCUS, this.expand);
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MAIN_CATEGORY_BLUR, this.shrink);
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MYAPP_CHECK_ITEMNUM_CHANGE, this.updateDeleteBtn);

        Volt.Nav.reload();
    },

    /**
     * Hide this view.
     * @method
     */
    hide: function () {
        this.parent.getDescendant('main-header-icon-search').custom.focusable = true;
        this.parent.getDescendant('main-header-icon-option').custom.focusable = true;
        this.parent.getDescendant('main-header-icon-close').custom.focusable = true;
        this.parent.getDescendant('category-list-container').custom.focusable = true;

        this.widget.getChild('edit-cancel-button').custom.focusable = false;
        this.widget.getChild('edit-exceute-button').custom.focusable = false;
        this.widget.getChild('edit-select-button').custom.focusable = false;
        this.stopListening(EventMediator, CommonDefines.Event.EVENT_MAIN_CATEGORY_FOCUS);
        this.stopListening(EventMediator, CommonDefines.Event.EVENT_MAIN_CATEGORY_BLUR);
        this.widget.hide();
        this.shrink();
    },

    onFocusButton: function (widget) {
        EventMediator.trigger(CommonDefines.Event.EVENT_MAIN_CATEGORY_FOCUS);
        if (widget) {
            switch (widget.id) {
            case 'edit-select-button':
                Volt.log('[myAppsView.js] this.buttonSelect.setFocus();^^^');
                this.buttonSelect.setFocus();
                CommonFunctions.voiceGuide(this.buttonSelect.text() + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON'));
                break;
            case 'edit-exceute-button':
                Volt.log('[myAppsView.js] this.exceute.setFocus();^^^');
                this.buttonExecute.setFocus();
                CommonFunctions.voiceGuide(this.buttonExecute.text() + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON'));
                break;
            case 'edit-cancel-button':
                Volt.log('[myAppsView.js] this.exceute.setFocus();^^^');
                this.buttonCancel.setFocus();
                CommonFunctions.voiceGuide(this.buttonCancel.text() + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON'));
                break;
            default:
                break;
            }
        }
    },

    onBlurButton: function (widget) {
        EventMediator.trigger(CommonDefines.Event.EVENT_MAIN_CATEGORY_BLUR);

        if (widget) {

            switch (widget.id) {
            case 'edit-select-button':
                this.buttonSelect.killFocus();
                break;
            case 'edit-exceute-button':
                this.buttonExecute.killFocus();
                break;
            case 'edit-cancel-button':
                //this.moreButton.color = Volt.hexToRgb('#ffffff', 95);
                //this.moreButton.getChild(0).src = Volt.getRemoteUrl('images/1080/common/btn_icon_more_f.png');
                this.buttonCancel.killFocus();
                break;
            default:
                break;
            }
        }
    },

    renderSelectAll: function (flag) {
        if (flag) {
            this.isSelectAll = true;
            EventMediator.trigger('EDIT_MODE_SELECT_ALL', true);
        } else {
            this.isSelectAll = false;
            EventMediator.trigger('EDIT_MODE_SELECT_ALL', false);
        }
    },

    setExecuteButtonText: function () {
        var buttonText = null;

        switch (this.executeType) {
        case 'delete':
            buttonText = Volt.i18n.t('COM_SID_DELETE');
            break;
        case 'lock':
            buttonText = Volt.i18n.t('COM_BUTTON_SAVE');
            break;
        }

        this.buttonExecute.setText({
            state: "all",
            text: buttonText
        });
    },

    updateDeleteBtn: function () {
        Volt.log("[EditButtonGroupView]updateDeleteBtn getCheckedItemCount = " + this.parentView.myAppsVMCollection.getCheckedItemCount());
        if (this.parentView.myAppsVMCollection.modeType == 'delete') {
            if (this.parentView.myAppsVMCollection.getCheckedItemCount() > 0) {
                if (this.buttonExecute) {
                    this.buttonExecute.enable(true);
                    this.widget.getChild('edit-exceute-button').custom.focusable = true;
                    Volt.Nav.reload();
                }
            } else {
                if (this.buttonExecute) {
                    this.buttonExecute.enable(false);
                    this.widget.getChild('edit-exceute-button').custom.focusable = false;
                    Volt.Nav.reload();
                }
            }
        } else {
            if (this.buttonExecute) {
                Volt.log("[EditButtonGroupView]updateDeleteBtn buttonExecute enable");
                this.buttonExecute.enable(true);
                this.widget.getChild('edit-exceute-button').custom.focusable = true;
                Volt.Nav.reload();
            }
        }
    },

    /**
     * Expand category area on focus
     */
    expand: function () {
        Volt.log('[EditButtonGroupView] expand()');
        var editCategory = this.parent.getChild('main-category-container');
        editCategory.animate('y', scene.height * 0.1, MENU_ANIM_DURATION);
        editCategory.animate('height', scene.height * 0.1, MENU_ANIM_DURATION);
        this.widget.animate('y', 0, MENU_ANIM_DURATION);
        this.widget.animate('height', scene.height * 0.1, MENU_ANIM_DURATION);

        if (this.parentView && this.parentView.headerCover) {
            this.parentView.headerCover.animate('height', scene.height * 0.1, MENU_ANIM_DURATION);
        }

        var underbarBg = this.parent.getChild('main-category-underbar-container');
        underbarBg.animate('y', scene.height * 0.1, MENU_ANIM_DURATION);

        Volt.find(this.widget, '.edit-mode-selected-text')[0].animate('y', scene.height * 0.0166667, MENU_ANIM_DURATION);
        Volt.find(this.widget, '.edit-mode-selected-count')[0].animate('y', scene.height * 0.0166667, MENU_ANIM_DURATION);
        this.deleteBg.animate('height', scene.height * 0.099074, MENU_ANIM_DURATION);
        this.buttonExecute.setSize(Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8), Volt.height * 0.099074 + ((Volt.APPS720P) ? 6 : 8));
        this.selectAllBg.animate('height', scene.height * 0.099074, MENU_ANIM_DURATION);
        this.buttonSelect.setSize(Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8), Volt.height * 0.099074 + ((Volt.APPS720P) ? 6 : 8));
        this.cancelBg.animate('height', scene.height * 0.099074 + 8, MENU_ANIM_DURATION);
        this.buttonCancel.setSize(Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8), Volt.height * 0.099074 + ((Volt.APPS720P) ? 6 : 8));
        _.each(this.widget.find('.multi_seletion_buttons_bar'), function (wz) {
            wz.animate('height', scene.height * 0.099074, MENU_ANIM_DURATION);
        });
    },

    /**
     * Shrink category area on blur
     */
    shrink: function () {
        Volt.log('[EditButtonGroupView] shrink()');
        var editCategory = this.parent.getChild('main-category-container');
        editCategory.animate('y', scene.height * 0.133333, MENU_ANIM_DURATION);
        editCategory.animate('height', scene.height * 0.066667, MENU_ANIM_DURATION);
        this.widget.animate('y', 0, MENU_ANIM_DURATION);
        this.widget.animate('height', scene.height * 0.066667, MENU_ANIM_DURATION);
        if (this.parentView && this.parentView.headerCover) {
            this.parentView.headerCover.animate('height', scene.height * 0.133333, MENU_ANIM_DURATION);
        }

        var underbarBg = this.parent.getChild('main-category-underbar-container');
        underbarBg.animate('y', scene.height * 0.133333, MENU_ANIM_DURATION);

        Volt.find(this.widget, '.edit-mode-selected-text')[0].animate('y', 0, MENU_ANIM_DURATION);
        Volt.find(this.widget, '.edit-mode-selected-count')[0].animate('y', 0, MENU_ANIM_DURATION);
        this.deleteBg.animate('height', scene.height * 0.065741, MENU_ANIM_DURATION);
        this.selectAllBg.animate('height', scene.height * 0.065741, MENU_ANIM_DURATION);
        this.cancelBg.animate('height', scene.height * 0.065741, MENU_ANIM_DURATION);
        this.buttonExecute.setSize(Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8), Volt.height * 0.065741 + ((Volt.APPS720P) ? 6 : 8));
        this.buttonSelect.setSize(Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8), Volt.height * 0.065741 + ((Volt.APPS720P) ? 6 : 8));
        this.buttonCancel.setSize(Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8), Volt.height * 0.065741 + ((Volt.APPS720P) ? 6 : 8));
        _.each(this.widget.find('.multi_seletion_buttons_bar'), function (wz) {
            wz.animate('height', scene.height * 0.065741, MENU_ANIM_DURATION);
        });

    },

    onSelectButton: function (widget) {
        Volt.log('[MyAppsView] onSelectButton   this.isSelectAll    ' + this.isSelectAll);

        switch (widget.id) {
        case 'select-all-button':
            if (this.isSelectAll) { //title is deselect
                this.renderSelectAll(false);
            } else { //title is select
                this.renderSelectAll(true);
            }
            break;
        case 'delete-button':
            EventMediator.trigger('EDIT_MODE_EXECUTE', this.executeType);
            break;
        case 'cancel-button':
            EventMediator.trigger('HIDE_EDIT_MODE');
            break;
        }
    },
    createButton: function (parent, text) {
        Volt.log("[multi-selection.js]In function createButton");
        var that = this;



        var btn = PanelCommon.loadTemplate(MyAppsTemplate.generalBtn);




        btn.setText({
            state: "all",
            text: text
        });


        btn.setTextColor({
            state: 'normal',
            color: {
                r: 255,
                g: 255,
                b: 255,
                a: 255
            }
        });
        btn.setTextColor({
            state: 'focused',
            color: {
                r: 255,
                g: 255,
                b: 255,
                a: 255
            }
        });
        btn.setTextColor({
            state: 'roll-over',
            color: {
                r: 255,
                g: 255,
                b: 255,
                a: 255
            }
        });
        btn.setTextColor({
            state: 'focused-roll-over',
            color: {
                r: 255,
                g: 255,
                b: 255,
                a: 255
            }
        });
        btn.setTextColor({
            state: 'selected',
            color: {
                r: 255,
                g: 255,
                b: 255,
                a: 255
            }
        });
        btn.setTextColor({
            state: 'disabled',
            color: {
                r: 255,
                g: 255,
                b: 255,
                a: 77
            }
        });


        btn.setFontSize({
            state: "normal",
            size: (Volt.APPS720P) ? 18 : 28
        });
        btn.setFontSize({
            state: "disabled",
            size: (Volt.APPS720P) ? 18 : 28
        });
        btn.setFontSize({
            state: "disabled-focused",
            size: (Volt.APPS720P) ? 18 : 28
        });
        btn.setFontSize({
            state: "roll-over",
            size: (Volt.APPS720P) ? 20 : 31
        });
        btn.setFontSize({
            state: "focused-roll-over",
            size: (Volt.APPS720P) ? 20 : 31
        });
        btn.setFontSize({
            state: "selected",
            size: (Volt.APPS720P) ? 20 : 31
        });
        btn.setFontSize({
            state: "focused",
            size: (Volt.APPS720P) ? 20 : 31
        });


        btn.setBackgroundColor({
            state: "all",
            color: {
                r: 255,
                g: 0,
                b: 255,
                a: 0
            }
        });


        btn.setBackgroundImage({
            state: "focused",
            src: Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png')
        });
        btn.setBackgroundImage({
            state: "normal",
            src: '',
        });
        btn.setBackgroundImage({
            state: "roll-over",
            src: Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png')
        });
        btn.setBackgroundImage({
            state: "focused-roll-over",
            src: Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png')
        });
        btn.setBackgroundImage({
            state: "disabled",
            src: '',
        });
        btn.setBackgroundImage({
            state: "disabled-focused",
            src: Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png')
        });
        btn.setBackgroundImage({
            state: "selected",
            src: Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png')
        });

        btn.setTextAttr({
            x: ((Volt.APPS720P) ? 6 : 8),
            y: 0,
            width: Volt.width * 0.15625 - ((Volt.APPS720P) ? 6 : 8) ,
            height: Volt.height * 0.063889 + ((Volt.APPS720P) ? 12 : 16), //to avoid letters cutting, add the magic number. add by caoyr 
            hAlign: "center",
            vAlign: "middle"
        });

        btn.parent = parent;
        btn.addListener(that.btnListener);
        btn.show();

        return btn;
    },
});

exports = MyAppsView;