(function(){
    Volt.pakages = { instances: {}, modules: {} };
    Volt.BASE_PATH = 'file://';
    Volt.require = function(path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            return require(Volt.browser ? path : Volt.BASE_PATH + path);
        }
    };
})();
Volt.require('$VOLT_ROOT/modules/modules_distribution.min.js');
Volt.require('distribution.min.js');

var IsDeepLink       = false;
var DeepLinkWidgetID = "";
var editMode         = false;

var PanelCommon      = Volt.require('lib/panel-common.js');
var EventMediator    = Volt.require('app/common/event-mediator.js');
var CommonDefine     = Volt.require('app/common/common-define.js');
var dimView          = Volt.require('app/views/dim-view.js'); 
var DeviceModel      = Volt.require("app/models/device-model.js");
var Backbone         = Volt.require('modules/backbone.js');
var networkStatus    = Volt.require('app/common/network-state.js');
var ErrorHandling    = Volt.require('app/common/error-handling.js');
var Utils            = Volt.require('app/common/utils.js');
var voltapi          = Volt.require('voltapi.js');
var voltapiWrapper   = Volt.require('app/common/voltapi-wrapper.js');
Volt.KPIMapper       = Volt.require('app/common/kpi-mapper.js');
var ServerController = Volt.require('app/controller/server-controller.js');
var VoiceGuide       = Volt.require('app/common/voiceGuide.js');
var CommonContent = Volt.require('app/common/common-content.js');

Volt.previousPage = 'main';
Volt.pageItemIndex = 0;
Volt.KPIParams = {event:'',cp:'',ssoby:'',appid:'',sp:'',content:'',status:''};
var MagicKey         = Volt.require('app/common/MagicKey.js');

/**
 * Entry point for Volt application
 */
var initialize = function() {
	Volt.log('[app.js] initialize .....');
    
    //EventMediator.on(CommonDefine.Event.MSGBOX_BUTTON, processMsgBoxEvent, this);
    preload();
    startApp();
    Volt.log('initialize, Stage show=====');
    Stage.show();
};

function preload(){
    Volt.log('preload.......');
    setupEnv();    
    loadModules();
}

function postload(){
    Volt.log('postload.......');
    initNetwork();
    voltapiWrapper.init();//before initWAS
    ServerController.init(); //before initWAS
    initWAS();
    checkUSB();
}

function loadModules() {
    Volt.require('lib/volt-global.js');
    Volt.require('lib/volt-nav.js');
    Volt.require('app/router.js');
    
    var WinsetBtn      = Volt.require("WinsetUIElement/winsetButton.js");   
    var WinsetToolTip  = Volt.require("WinsetUIElement/winsetToolTip.js");
    var WinsetInputBox = Volt.require("WinsetUIElement/winsetInputBox.js");
    if(WinsetBtn.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA){
    	Volt.log("[app.js]================  new button style");
    	CommonDefine.Winset.BUTTON_IMAGE_O_STYLE_F_FOCUS1 = 22;
    }
    PanelCommon.mapWidget('WinsetBtn',      WinsetBtn); 
    PanelCommon.mapWidget('WinsetToolTip',  WinsetToolTip);
    PanelCommon.mapWidget('WinsetInputBox', WinsetInputBox);
}

function setupEnv() { 
    DeviceModel.init();
    //multilingual
    Volt.i18n = Volt.require('lib/volt-multilingual.js');
    //drawSplashImage();
    Volt.log('[app.js] setupEnv lauguage = ' + DeviceModel.get('languageCode'));
    Volt.i18n.init({
            lng : DeviceModel.get('languageCode'),
            resGetPath : 'lang/<<lng>>.json',
            getAsync : false,
            interpolationPrefix : '<<',
            interpolationSuffix : '>>'
        }, function(t) {}
    );
    
    checkAccessibility();
    HALOUtil.applyOrientation();
    Volt.GAMES_REVERSE = (HALOUtil.getOrientation() == 'right-to-left');
}

function initNetwork(){
    networkStatus.init();
    if(voltapi.network.isOpened() === false){
        Volt.log('[app.js] network not initialized........');
        var retry = 0;
        function networkAsyncCallback(is_success){
            Volt.log('networkAsyncCallback Successful or not:::'+is_success);
            if(is_success){
                EventMediator.trigger(CommonDefine.Event.NETWORK_READY);
            } else {
                Volt.log('networkAsyncCallback Fail, retry::'+retry);
                if(retry < 1){
                    voltapi.network.initAsync(networkAsyncCallback);
                    retry++;
                }
            }
        }
        voltapi.network.initAsync(networkAsyncCallback);
    }
}

function initWAS(){
    if(voltapi.WAS.isOpened() === false) {
        Volt.log('[app.js] was not initialized........');
        var retry = 0;
        function WASAsyncCallback(is_success){
            Volt.log('WASAsyncCallback Successful or not:::'+is_success);
            if(is_success){
                EventMediator.trigger(CommonDefine.Event.WAS_READY);
                Volt.KPIMapper.init();
                checkReset();
            } else {
                Volt.log('WASAsyncCallback Fail, retry :::'+retry);
                if(retry < 1){
                    voltapi.WAS.initAsync(WASAsyncCallback, WASAsyncReopenCallback);
                    retry++;
                }
            }
        }

        function WASAsyncReopenCallback(){
            Volt.log('WASAsyncReopenCallback Successful');
            EventMediator.trigger(CommonDefine.Event.WAS_READY);      
        }

        voltapi.WAS.initAsync(WASAsyncCallback, WASAsyncReopenCallback);
	}
}

function startApp(){
    Volt.APP_STATUS = CommonDefine.Event.GAMES_ON_ACTIVATE;
    Volt.bQueuingPlay = true;
    Backbone.history.start();

    //if network error, first screen will popup network error
    /*var status = networkStatus.getNetWorkState();
    print('[app.js] status ::' + status);
    if(!status){
        print('!!!!!!!!!!!!!!!!network error!!!!!!!!!!!!!!!!!!!!!!!');
        networkPopup = true;
        ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR);
        return;
    } */
	ErrorHandling.initialize();
    if (!IsDeepLink) {
        Volt.log("[App.js]Is not deeplink");
		Volt.previousPage = 'main';
        EventMediator.on('GAMES_POST_LOAD', postload, this);
        Backbone.history.navigate('home', {
            trigger : true
        });
        Volt.first = true;
    } else {
        Volt.log("[App.js]Is deeplink,widget ID = " + DeepLinkWidgetID);
        postload();
		Volt.previousPage = 'detail';
        Backbone.history.navigate('detail/' + DeepLinkWidgetID, {
            trigger : true
        });
    }
}

var onShow = function(data){
    Volt.log("[App.js]receive event ON_SHOW:" + JSON.stringify(data));
    if (data == undefined || data == null) {
        Volt.log('data is null or undefined');
        return;
    }

    if (data["Sub_Menu"] == "detail") {
		IsDeepLink = true;
        DeepLinkWidgetID = data["widget_id"];
    }
};

var onResume = function() {
    Volt.log('[app.js] ON_RESUME .....');
    EventMediator.trigger(CommonDefine.Const.UPDATE_ITEMS);
};

var onPause = function() {
    Volt.log('[app.js] ON_PAUSE .....');
};

var onHide = function() {
	Volt.log('[app.js] ON_HIDE .....');
	EventMediator.trigger(CommonDefine.Event.GAMES_EXIT, true);
    Volt.KPIMapper.KPILogLeavePage(); 
};

//note:need refine later.
var onReset = function(data) {
    Volt.log("[App.js]receive event ON_RESET::" + JSON.stringify(data));
    Volt.bQueuingPlay = false;
    voltapi.vconf.setValue('db/WaitingScreenApp/Visible', true);
    var visible = voltapi.vconf.getValue('db/WaitingScreenApp/Visible');
    Volt.log('visible::::'+visible);
    
    Stage.show();
    Volt.log("Call Stage.show()");	
	
	var mlsMode = voltapi.vconf.getValue('memory/mls/state');
    Volt.log(' vconf MLS_STATE : ' + mlsMode);
    if(mlsMode == 1){
        Volt.log('MLS mode, do not show dim');
        dimView.hide();
    }
    
	if(data && data.widget_id){
		Volt.log('[App.js] enter into detail view.....');
        if(data.Sub_Menu == 'detail' ){
			Volt.log('[app.js] onReset DeepLinkWidgetID = ' + DeepLinkWidgetID + ',,,data.widget_id = ' + data.widget_id);
			if(DeepLinkWidgetID != data.widget_id){
				DeepLinkWidgetID = data.widget_id;
				Volt.previousPage = 'detail';
				Backbone.history.navigate('detail/' + data.widget_id, {
					replace:true,
		            trigger : true
		        });
			}
        }
	}else{
		Volt.log('[app.js] enter into main view.....');
		DeepLinkWidgetID = '';
		if('detail' == Volt.previousPage){
			Volt.log('[app.js] enter into main view.....need to navigate again');
			Volt.previousPage = 'main';
			Backbone.history.navigate('home', {
				replace:true,
	            trigger : true
	        });
		}
	}
};

var onDeactive = function(){
    Volt.log("[App.js]receive event  CommonDefine.Event.GAMES_ON_DEACTIVATE");
    //stop voiceGuide first
    VoiceGuide.stopVoiceGuide();
    Volt.KPIMapper.KPILogLeavePage();
    CommonContent.checkDeleteResultPopup();
    ErrorHandling.destroyWidgetPopup();
    ErrorHandling.destroyNavigatePopup();
    //dimView.show({parent : scene});
    //EventMediator.trigger(CommonDefine.Event.GAMES_ON_PAUSE);
    EventMediator.trigger(CommonDefine.Event.GAMES_ON_DEACTIVATE);
};

var onActive = function(){
    Volt.log("[App.js]receive event CommonDefine.Event.GAMES_ON_ACTIVATE");
    Volt.KPIMapper.KPILogEnterPage();
    //EventMediator.trigger(CommonDefine.Event.GAMES_ON_RESUME);
    EventMediator.trigger(CommonDefine.Event.GAMES_ON_ACTIVATE);
    //dimView.hide();
};

var checkLastFocus = function(){
    Volt.log('[app.js] checkLastFocus');
    CommonContent.checkDeleteResultPopup();
    var result = CommonContent.isDeleteResultPopup();
    if(result && CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS == result.type){
        Volt.log('[app.js] checkLastFocus return from delete-success popup ');
        EventMediator.trigger(CommonDefine.Event.MSG_POPUP_TIMEOUT, CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS);
    }   
};

/**
 * Key event listener from volt engine
 * @param keycode
 * @param type
 */
var onKeyEvent = function(keycode, type) {
    Volt.log("[app.js] onKeyEvent - keycode : " + keycode + " type : " + type);

    if(type == Volt.EVENT_KEY_PRESS){
        MagicKey.onKeyPress(keycode);
    }
    
    // if Volt.Nav didn't process the event, the app will process it.
    if (Volt.Nav.onKeyEvent(keycode, type) === false) {
        if (keycode == Volt.KEY_RETURN && type == Volt.EVENT_KEY_PRESS) {
			var optionMenu = CommonContent.getOptionMenu();
			if (optionMenu) {
				if (optionMenu.getOptionMenuState()) {
					optionMenu.hide();
					return;
				}
			}
            if (Backbone.history.getCount() > 1) {
                Volt.log("[app.js]onKeyEvent Nav Return ..... ");
                checkLastFocus();
                Backbone.history.back();
                Utils.Timer.clearTimeOut();
            } else {
                Volt.log("[app.js]onKeyEvent Nav Return Key press.....");
                Volt.log("[app.js]Nav Exit Games Panel.....");
                EventMediator.trigger(CommonDefine.Event.GAMES_EXIT, false);
                Volt.exit();
            }
        }
    }
};

Volt.addEventListener(Volt.ON_SHOW,       onShow);
Volt.addEventListener(Volt.ON_HIDE,       onHide);
Volt.addEventListener(Volt.ON_PAUSE,      onPause);
Volt.addEventListener(Volt.ON_RESUME,     onResume);
Volt.addEventListener(Volt.ON_DEACTIVATE, onDeactive);
Volt.addEventListener(Volt.ON_ACTIVATE,   onActive);
Volt.addEventListener(Volt.ON_RESET,      onReset); 

var checkReset = function() {
    Volt.log("[app.js] checkReset()");
    if(SmartHubReset && SmartHubReset.needReset){ 
        Volt.log('smarthub reset.....');    
		if(SmartHubReset.needReset()){
            //1.delete some config file & cached data....
            var localStorage = Volt.require("lib/volt-local-storage.js");
	        localStorage.clear();
            SmartHubReset.clearCacheFolder();
	        //2.call reset API to SERVER.
            DeviceReset();
        }
        else{
          	Volt.log("[app.js] not need reset");
        }
    }  
};

var DeviceReset = function(){
    Volt.log('DeviceReset:::Smart Hub Reset');
    ServerController.callAPI({
            type: 'DELETE',
            url: "game/device/v2/reset"
        },{
            bodyValue: {},
            success : function(data, status, response) {
                print("[------------Reset callback-----------] success result:" + data);
                //After Complete should call below API.
                SmartHubReset.resetComplete();
            },
            error : function(response, status, exception) {
                print("[------------Reset callback-----------] error result:" + exception + JSON.stringify(response));
            },
            complete: function(response, status) {   
                print("[------------completeCallback-----------] " + status);	
            }
        }
    );
};

var checkUSB = function() {
    Volt.log("[app.js] checkUSB()");
    var retry = 0;
    var onOpenCallback = function(is_success){
        Volt.log('contentMgrAsynCallback:::::is_success=>'+is_success);
        if(is_success){
            Volt.log("[app.js] Success Callback of ContentsMgr.initAsync()");
            var bConnect = voltapi.ContentsMgr.connect();
            Volt.log("[app.js] checkUSB(), connect: "+bConnect);
        } else {
            Volt.log("[app.js] Fail Callback of ContentsMgr.initAsync(), retry::"+retry);
            if(retry < 1){
                voltapi.ContentsMgr.initAsync(onOpenCallback, onSuccessCallback, onFailCallback);
                retry++;
            }
        }
    };

    var onSuccessCallback = function(){
        Volt.log("[app.js] checkUSB(): CONNECT_USB");
        CommonContent.setUsbState(true);
        EventMediator.trigger(CommonDefine.Event.CONNECT_USB, arguments);
    };

    var onFailCallback = function(){
        Volt.log("[app.js] checkUSB(): DISCONNECT_USB");
        CommonContent.setUsbState(false);
        EventMediator.trigger(CommonDefine.Event.DISCONNECT_USB, arguments);
    };

    voltapi.ContentsMgr.initAsync(onOpenCallback, onSuccessCallback, onFailCallback);
};

var checkAccessibility = function(){
    var highContrast = DeviceModel.get('highContrast');
    Volt.log("[app.js] checkAccessibility:highContrast is " + highContrast);
    if(highContrast){
        HALOUtil.highContrast = true;
    }else{
        HALOUtil.highContrast = false;
    }

    var focusZoom = DeviceModel.get('focusZoom');
    Volt.log("[app.js] checkAccessibility:focusZoom is " + focusZoom);
    if(focusZoom){
        HALOUtil.enlarge = true;
    }else{
        HALOUtil.enlarge = false;
    }
};

/*
var processMsgBoxEvent = function(data){
    if(data.eventType == CommonDefine.Event.SELECT_BTN1) {
        switch(data.msgBoxtype) {
            case CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR:
                var aulApp = new Aul();
                aulApp.launchApp("org.tizen.NetworkSetting-Tizen");
                break;
            case CommonDefine.MsgBoxType.MSGBOX_TYPE_REQUIRE_NETWORK:
                Volt.quit();
                var aulApp = new Aul();
                aulApp.launchApp("org.volt.firstscreen");
                break;
            default:
                break;
        }
    } else if(data.eventType == CommonDefine.Event.SELECT_BTN2) {
        switch(data.msgBoxtype) {
            case CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR:
                Volt.quit();
                var aulApp = new Aul();
                aulApp.launchApp("org.volt.firstscreen");
                break;
            default:
                break;
        }
    }
}*/