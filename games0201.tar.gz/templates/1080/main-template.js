var MainTemplate = {
    container: {
        parent: scene,
        type: 'widget',
        x: 0, y: 0, width: scene.width, height: scene.height,
        color: Volt.hexToRgb('#000000', 100),
        children: [
            {
                id: 'main-header-container',
                type: 'widget',
                x: 0, y: 0, width: scene.width, height: scene.height * 0.133333,
                color: Volt.hexToRgb('#000000',0)
            }, {
                id: 'main-category-container',
                type: 'widget',
                x: 0, y: scene.height * 0.133333, width: scene.width, height: scene.height * 0.066667,
                color: Volt.hexToRgb('#f2f2f2')
            }, {
                id: 'main-content-container',
                type: 'widget',
                x: 0, y: scene.height * (0.133333 + 0.066667), width: scene.width, height: scene.height * 0.8,
                color: Volt.hexToRgb('#dfdfdf'),
                children : [{
                    id : 'main-no-content-text',
                    type: 'text',
                    x : scene.width * 0.16875,
                    y : scene.height * 0.8 / 2 - 70,
                    width : scene.width * (1 - 0.16875),
                    height : 100,
                    font : "SVD Light 36px",
                    textColor : Volt.hexToRgb('#000000', 60),
                    horizontalAlignment : 'center',
                    verticalAlignment : 'center',
                    text : ""
                }]
            },
            {
                id: 'multi-selection-container',
                type: 'widget',
                x: 0, y: 0, width: scene.width, height: scene.height,
                color: {r:0,g:0,b:0,a:0},
            },
            {
                id: 'main-popup-container',
                type: 'widget',
                x: 0, y: 0, width: scene.width, height: scene.height,
                color: Volt.hexToRgb('#000000',0),
            }
        ]
    }
};

exports = MainTemplate;
