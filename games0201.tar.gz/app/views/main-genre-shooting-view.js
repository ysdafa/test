var MainGenreBaseView = Volt.require('app/views/main-genre-base-view.js');
var PanelCommon  = Volt.require('lib/panel-common.js');
var ShootingBranchView = PanelCommon.BaseView.extend({
	viewType : "shooting",
	genreSubView: null,
	initialize : function() {
		print('[main-genre-shooting-view.js] initialize');
	},

	render : function(parentWidget) {
		print('[main-genre-shooting-view.js] MainView.render');
		this.genreSubView = new MainGenreBaseView();
		this.genreSubView.render(parentWidget, this.viewType);
	},
	
	show : function(){
		print('[main-genre-shooting-view.js] show');
		this.genreSubView.show();
	},

	hide : function(){
		print('[main-genre-shooting-view.js] hide');
		this.genreSubView.hide();
	},
});

exports = ShootingBranchView;