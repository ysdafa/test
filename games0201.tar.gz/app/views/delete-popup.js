// Include libraries
var _              		= Volt.require('modules/underscore.js')._;
var Backbone       		= Volt.require('lib/volt-backbone.js');
var Q                   = Volt.require('modules/q.js');
var CommonDefine   		= Volt.require('app/common/common-define.js');
var PanelCommon    		= Volt.require('lib/panel-common.js');
var Mediator       		= Volt.require('app/common/event-mediator.js');
var CommonFucntion 		= Volt.require('app/common/common-function.js');
var DeletePopupTemplate = Volt.require('app/templates/1080/delete-popup-template.js');
var CommonContent 		= Volt.require('app/common/common-content.js');
var voltApiWrapper      = Volt.require("app/common/voltapi-wrapper.js");
var ErrorHandling       = Volt.require('app/common/error-handling.js');
var VoiceGuide    = Volt.require('app/common/voiceGuide.js');
var voltapi = Volt.require('voltapi.js');

var deletePopupSelf = null;
var singleTimeID = null;
var multiTimeID = null;

var DeletePopup = PanelCommon.BaseView.extend({
    template : DeletePopupTemplate.container,
    params : null,
    totalNum : 0,
    currentNum : 0,
    progress : 0,
    progressBar : null,
    appID : null,
    isMulti : false,
    isShow : false,
    gamesID : null,
    descView : null,
    progressBarView : null,
    popupBtnView : null,
    percentTextWgt : null,
    timer: null,
    winsetBackground : null,
    
    render : function() {
    },

    show : function(options) {
        Volt.log('[delete-popup.js] show options =' + options);
        deletePopupSelf = this;
        this.startListening();
        this.params = JSON.parse(options);
        this.currentNum = 0;
        this.appID = this.params.app_id;
        this.gamesID = this.params.app_id;
        this.isMulti = this.params.isMulti;
        if (!this.isMulti) {
            this.totalNum = 1;
        } else {
            this.totalNum = this.appID.length;
        }
        
        this.winsetBackground = CommonContent.loadTemplateInWinsetBackgroud(this.template);
        this.setWidget(this.winsetBackground.getChild(0));
        this.winsetBackground.show();
        
        this.renderDescrption();
        this.renderProgressBar();
        this.renderButton();
        
        this.isShow = true;
        //Volt.Nav.beginModal(this.widget);
        Volt.Nav.setRoot(this.widget);
        //this.setTimeOut();
    },

    startListening : function() {
        Mediator.on(CommonDefine.Event.EVENT_CLOSE_POPUP, _.bind(function() {
            //this.clearTimeOut();
            this.showDeleteFailPopup();
        }), this);
        Mediator.on(CommonDefine.Event.UNINSTALL_PROGRESS, this.updateProgress, this);
        Mediator.on(CommonDefine.Event.UNINSTALL, this.finishDelete, this);
    },

    stopListening : function() {
        Mediator.off(CommonDefine.Event.EVENT_CLOSE_POPUP,null, this);
        Mediator.off(CommonDefine.Event.UNINSTALL_PROGRESS,null, this);
        Mediator.off(CommonDefine.Event.UNINSTALL, null, this);
    },

    renderDescrption : function() {
        Volt.log('[delete-popup.js] renderDescrption');
        var container = this.widget.getChild('description-container');
        var description = new descriptionView().render().widget;
        container.addChild(description);
        var isInUSB = voltApiWrapper.isWidgetInstalledInUSB(this.appID);
        if (isInUSB) {
            //description.text = "Deleting ...\nDo not remove storage device.";
            description.getChild(0).text = "Deleting ...\nDo not remove storage device.";
            description.getChild(0).height*=2;
            /*
            //description.height *= 2;
            this.widget.getChild('progressbar-container').y += description.height;
            this.widget.getChild('button-container').y += description.height;
            this.widget.getChild('description-container').height += description.height;
            this.widget.height += description.height;
            */
            
            
            
        } else {
            //description.text = Volt.i18n.t('COM_SID_DELETING_KR_PANEL');
            description.getChild(0).text = Volt.i18n.t('COM_SID_DELETING_KR_PANEL');
        }
    },

    renderProgressBar : function() {
        var container = this.widget.getChild('progressbar-container');
        var progressWgt = new progressView().render().widget;
        container.addChild(progressWgt);
    },
    
    renderButton : function() {
        Volt.log('[delete-popup.js] renderButton');
        var container = this.widget.getChild('button-container');
        var btnViewWgt = new buttonView().render().widget
        container.addChild(btnViewWgt);
        if(!this.isMulti){
            btnViewWgt.hide();
        } else {
            btnViewWgt.show();
        }
    },

    hide : function() {
        Volt.log('[delete-popup.js] hide');
        var deferred = Q.defer();

        this.clearTimeOut();
        this.stopListening();
        if(this.progressBarView){
            this.progressBarView.destroy();
        }
        
        if(this.popupBtnView){
            this.popupBtnView.destroy();
        }
        
        this.reset();
        if(this.winsetBackground){
            this.winsetBackground.hide();
            this.destroy(this.winsetBackground);
            this.winsetBackground.destroy();
            this.winsetBackground = null;
        }
        
        deferred.resolve();
        return deferred.promise;
    },
    
    reset : function (){
        Volt.log('[delete-popup.js] reset');
        this.appID = null;
        this.isShow = false;
        this.params = null;
        this.totalNum = 0;
        this.currentNum = 0;
        this.progress = 0;
        this.isMulti = false;
        this.gamesID = null;
        this.descView = null;
        this.progressBarView = null;
        this.popupBtnView = null;
        this.timer = null;
        
        singleTimeID = null;
        multiTimeID = null;
        deletePopupSelf = null;
    },

    destroy : function(widget) {
        if (!widget)
            return;
        var nChildLength = widget.getChildCount();
        if (nChildLength > 0) {
            for (var i = nChildLength - 1; i >= 0; i--) {
                temp = widget.getChild(i);
                this.destroy(temp);
            }
        }
    },
    
    onKeyEvent : function (keyCode, keyType) {
        Volt.log("[delete-popup.js] onKeyEvent ");
        if(keyCode == Volt.KEY_RETURN && (keyType == Volt.EVENT_KEY_PRESS || keyType == Volt.EVENT_KEY_RELEASE)){
            if(deletePopupSelf.popupBtnView){
                Volt.log("[delete-popup.js] return  btn1.text =" +deletePopupSelf.popupBtnView.btn1.text());
                if (Volt.i18n.t('COM_SID_CANCEL') == deletePopupSelf.popupBtnView.btn1.text()) {
                    deletePopupSelf.popupBtnView.onSelectCancelButton();
                }
                if (Volt.i18n.t('COM_SID_OK') == deletePopupSelf.popupBtnView.btn1.text()) {
                    deletePopupSelf.popupBtnView.onSelectOkButton();
                }
            }
            return true;
        }
    },

    updateProgress : function(eventInfo) {
        Volt.log("[delete-popup.js] updateProgress");
        if (CommonFucntion.checkValid(this) && this.isMulti == false) {
            Volt.log("[delete-popup.js] updateProgress single delete");
            if (CommonFucntion.checkValid(eventInfo)) {
                Volt.log("[delete-popup.js] updateProgress result app_id =" + eventInfo.app_id + ", " + eventInfo.result);
                if (eventInfo.app_id == this.appID) {
                    if (eventInfo.result <= 100) {
                        if (CommonFucntion.checkValid(this.progressBar)) {
                            if(eventInfo.result < 100){
                                this.progress = eventInfo.result;
                                if(!singleTimeID){
                                    singleTimeID = Volt.setInterval(function(){
                                        if(eventInfo.result < 100){
                                            var voiceGuide = Volt.i18n.t('COM_SID_DELETING_KR_PANEL') + ',' + this.progress + ',percent,' 
                                                + Volt.i18n.t('TV_SID_PLEASE_WAIT') + ', ' + Volt.i18n.t('COM_SID_CANCEL') 
                                                + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
                                            VoiceGuide.getVoiceGuide(voiceGuide);
                                        }
                                    }.bind(this), 5000);
                                }
                            }else{
                                if(singleTimeID){
                                    Volt.clearInterval(singleTimeID);
                                }
                            }

                            this.progressBar.value = eventInfo.result * parseInt(scene.width * 0.40625) / 100;
                            if(this.percentTextWgt){
                                this.percentTextWgt.text = eventInfo.result + "%";
                            }
                            //this.setTimeOut();
                        }
                    }
                }
            }
        } else if(CommonFucntion.checkValid(this)) {
            Volt.log("[delete-popup.js] updateProgress multi delete");
            if (CommonFucntion.checkValid(eventInfo)) {
                for(var index = 0; index < this.totalNum; index ++){
                    if(this.gamesID[index] == eventInfo.app_id){
                        Volt.log("[delete-popup.js] updateProgress this.currentNum =" + this.currentNum);
                         
                        if (eventInfo.result <= 100) {
                            if (CommonFucntion.checkValid(this.progressBar)) {
                                var progressValue = ((this.currentNum + 1)/this.totalNum) * eventInfo.result * parseInt(scene.width * 0.40625)/ 100;
                                if(eventInfo.result < 100){
                                    if(!multiTimeID){
                                            multiTimeID = Volt.setInterval(function(){
                                            if(eventInfo.result < 100){
                                                var num = this.currentNum + 1;
                                                var voiceGuide = Volt.i18n.t('COM_SID_DELETING_KR_PANEL') + ',' + num + ' of ' + this.totalNum
                                                    + ',' + Volt.i18n.t('TV_SID_PLEASE_WAIT') + ', ' + Volt.i18n.t('COM_SID_CANCEL') 
                                                    + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
                                                VoiceGuide.getVoiceGuide(voiceGuide);
                                            }
                                        }.bind(this), 5000);
                                    }
                                }else{
                                    if(multiTimeID){
                                        Volt.clearInterval(multiTimeID);
                                    }
                                }
                        
                                if(progressValue > this.progressBar.value){
                                    this.progressBar.value = progressValue;
                                }
                                Volt.log("[delete-popup.js] updateProgress multi delete this.progressBar.value =" + this.progressBar.value);
                                //this.setTimeOut();
                            }
                        }
                    }
                    break;
                }
            }
        }
    },

    finishDelete : function(eventInfo) {
        if (CommonFucntion.checkValid(this)) {
            if (this.isMulti == false) {
                Volt.log("[delete-popup.js] finish single delete");
                if (CommonFucntion.checkValid(eventInfo) && eventInfo.app_id == this.appID) {
                    Volt.log("[delete-popup.js] finish delete.isMulti == false");
					
                    this.showDeleteSuccessPopup(eventInfo.app_id);
                }
            } else {
                Volt.log("[delete-popup.js] receive multi delete event");
                if (CommonFucntion.checkValid(eventInfo)) {
                    Volt.log("[delete-popup.js] eventInfo.app_id = ", eventInfo.app_id);
                    Volt.log("[delete-popup.js] before appID = " + this.appID);
                    for (var i = 0; i < this.appID.length; ++i) {
                        if (this.appID[i] == eventInfo.app_id) {
                            this.currentNum++;
                            if (this.currentNum > this.totalNum) {
                                this.currentNum = this.totalNum;
                            }
                            this.appID.splice(i, 1);//delete the specified item
                            Volt.log("[delete-popup.js] after appID = " + this.appID);
                            break;
                        }
                    }

                    if (CommonFucntion.checkValid(this.progressBar)) {
                        this.progressBar.value = this.currentNum * 780 / this.totalNum;
                        if (this.currentNum < this.totalNum) {
                            deletePopupSelf.descView.widget.getChild(1).text = Volt.i18n.t('COM_MIX_TOTAL_KR_OVERALL').replace('<<A>>',this.currentNum + 1).replace('<<B>>',this.totalNum);
                        }
                        
                        if(this.percentTextWgt){
                            var percent = this.currentNum/this.totalNum * 100;
                            this.percentTextWgt.text = percent + "%";
                        }
                        //this.setTimeOut();
                    }

                    if (this.currentNum == this.totalNum) {
                        Volt.log("[delete-popup.js] finish delete.isMulti == true");
                        /*var voiceGuide = Volt.i18n.t('TV_SID_MIX_COMPLETE').replace('<<A>>','') + this.currentNum + 'of ' 
                                         + this.totalNum + ',' + Volt.i18n.t('COM_SID_OK') + ',button.';
                        VoiceGuide.getVoiceGuide(voiceGuide);*/
                        this.showDeleteSuccessPopup(this.appID);
                    }
                }
            }
        }
    },

    showDeleteFailPopup : function() {
        Volt.log('[delete-popup.js] showDeleteFailPopup');
        Volt.setTimeout(function() {
            ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_FAIL);
        }, 200);
        Backbone.history.back();
    },

    showDeleteSuccessPopup : function(appId) {
        Volt.log('[delete-popup.js] showDeleteSuccessPopup appId =' + appId);
        deletePopupSelf.descView.widget.getChild(0).text = Volt.i18n.t('TV_SID_DELETED_SUCCESSFULLY');
        if(!this.isMulti){
            deletePopupSelf.popupBtnView.widget.show();
        }
        deletePopupSelf.popupBtnView.btn1.setText({
            state: "all",
            text: Volt.i18n.t('COM_SID_OK')
        });
        this.setTimeOut();
        /*
        Volt.setTimeout(function() {
            ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS, appId);
        }, 200);
        Backbone.history.back();
        */
    },
    
    setTimeOut: function () {
        this.clearTimeOut();
        this.timer = Volt.setTimeout(function () {
            Volt.log('[delete-success-popup.js] time out');
            Mediator.trigger(CommonDefine.Event.MSG_POPUP_TIMEOUT, CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS);
            Backbone.history.back();
        }, 1000 * 10);

    },

    clearTimeOut: function () {
        Volt.log('[delete-success-popup.js] clearTimeOut');
        if (this.timer != null && this.timer != undefined) {
            Volt.clearTimeout(this.timer);
        }
    },
});

//template of description
var descriptionView = PanelCommon.BaseView.extend({
    template : DeletePopupTemplate.description,

    render : function() {
        deletePopupSelf.descView = this;
        this.setWidget(PanelCommon.loadTemplate(this.template));
        if(!deletePopupSelf.isMulti){
            Volt.log('[delete-popup.js] descriptionView single');
            this.widget.getChild(1).hide();
        } else {
            Volt.log('[delete-popup.js] descriptionView multi');
            this.widget.getChild(1).show();
            this.widget.getChild(1).text = Volt.i18n.t('COM_MIX_TOTAL_KR_OVERALL').replace('<<A>>',deletePopupSelf.currentNum).replace('<<B>>',deletePopupSelf.totalNum);
        }
        return this;
    }
});

var progressView = PanelCommon.BaseView.extend({
    template : DeletePopupTemplate.progressBar,
    
    render : function() {
        deletePopupSelf.progressBarView = this;
        this.setWidget(PanelCommon.loadTemplate(this.template));
        var progressbarWgt = this.widget.getDescendant("progressBar");
        deletePopupSelf.percentTextWgt = this.widget.getDescendant("percentText");
        Volt.log('[delete-popup.js] progressView this.progressBar =' + deletePopupSelf.progressBar);
        if(deletePopupSelf.progressBar) {
            //deletePopupSelf.progressBar.show();
        } else {
            deletePopupSelf.progressBar = CommonContent.createProgressControl(progressbarWgt, 0, 0, parseInt(scene.width * 0.40625), 2);
        }
        return this;
    },
    
    destroy :function (){
        if(deletePopupSelf.progressBar) {
            deletePopupSelf.progressBar.destroy();
            deletePopupSelf.progressBar = null;
        }
        if(deletePopupSelf.percentTextWgt){
            deletePopupSelf.percentTextWgt = null;
        }
        if(this.widget){
            this.widget.destroyChildren();
            this.widget.destroy();
            this.widget = null;
        }
    },
});

var buttonView = PanelCommon.BaseView.extend({
    template : DeletePopupTemplate.button,
    btn1 : null,
    btnListener : new ButtonListener(),

    render : function() {
        Volt.log('[delete-popup.js] buttonView.render');
        deletePopupSelf.popupBtnView = this;
        
        deletePopupSelf.popupBtnView.btnListener.onButtonClicked=function(btn,type){
            Volt.log('[delete-popup.js] buttonView.onButtonClicked btn.text =' + btn.text());
            if(Volt.i18n.t('COM_SID_CANCEL') == btn.text()){
                deletePopupSelf.popupBtnView.onSelectCancelButton();
            }
            if(Volt.i18n.t('COM_SID_OK') == btn.text()){
                deletePopupSelf.popupBtnView.onSelectOkButton();
            }
        }
        
        var btnStyle = {
            style : CommonDefine.Winset.BUTTON_IMAGE_O_STYLE_F_FOCUS1,
            buttonType : CommonDefine.Winset.BUTTON_TEXT,
        };
        
        this.setWidget(PanelCommon.loadTemplate(this.template,btnStyle));
        this.btn1= this.widget.getDescendant('cancelBtn');
        this.btn1.addListener(this.btnListener);
        return this;
    },
    
    events : {
        'NAV_FOCUS #Cancel' : 'onFocusCancelButton',
    },
    
    onFocusCancelButton : function(widget) {
        Volt.log('[delete-popup.js] buttonView.onFocusCancelButton ' + widget.id);
        var voiceGuide = Volt.i18n.t('COM_SID_CANCEL') + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
        VoiceGuide.getVoiceGuide(voiceGuide);

        this.btn1.setFocus();
    },
    
    onSelectCancelButton : function(widget) {
        Volt.log('[delete-popup.js] buttonView.onSelectCancelButton');
        
        if (deletePopupSelf.isMulti == true) {
            voltapi.WAS.cancelMutilUnInstallApps(); /*voltapi.js not update yet*/
        }
        Mediator.trigger(CommonDefine.Event.MSG_POPUP_TIMEOUT, CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS);
        Backbone.history.back();
    },
    
    onSelectOkButton : function(widget) {
        Volt.log('[delete-popup.js] buttonView.onSelectOkButton');
        
        deletePopupSelf.clearTimeOut();
        Mediator.trigger(CommonDefine.Event.MSG_POPUP_TIMEOUT, CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS);
        Backbone.history.back();
    },
    
    destroy : function(){
        Volt.log('[delete-popup.js] buttonView destroy');
        if(this.btn1){
            this.btn1.destroy();
            this.btn1 = null;
        }
        if(this.widget){
            this.widget.destroyChildren();
            this.widget.destroy();
            this.widget = null;
        }
    }
});

//exports = new DeletePopup;
exports = DeletePopup; 