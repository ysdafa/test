var MainGenreBaseView = Volt.require('app/views/main-genre-base-view.js');
var PanelCommon  = Volt.require('lib/panel-common.js');
var RpgBranchView = PanelCommon.BaseView.extend({
    viewType : "rpg",
    genreSubView: null,
    initialize : function() {
        print('[main-genre-rpg-view.js] initialize');
    },

    render : function(parentWidget) {
        print('[main-genre-rpg-view.js] MainView.render');
        this.genreSubView = new MainGenreBaseView();
        this.genreSubView.render(parentWidget, this.viewType);
    },
    
    show : function(){
        print('[main-genre-rpg-view.js] show');
        this.genreSubView.show();
    },

    hide : function(){
        print('[main-genre-rpg-view.js] hide');
        this.genreSubView.hide();
    },
    
});

exports = RpgBranchView;