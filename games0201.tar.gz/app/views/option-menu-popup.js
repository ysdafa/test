// Include libraries
var _ = Volt.require('modules/underscore.js')._;
var Backbone = Volt.require('lib/volt-backbone.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var dimView = Volt.require('app/views/dim-view.js');
var CommonDefine = Volt.require('app/common/common-define.js');
var voltApiWrapper = Volt.require("app/common/voltapi-wrapper.js");
var Mediator       = Volt.require('app/common/event-mediator.js');
var Utils          = Volt.require("app/common/utils.js");
var networkStatus  = Volt.require('app/common/network-state.js');
var OptionMenuTemplate  = Volt.require('app/templates/1080/option-menu-popup.js');
var VoiceGuide    = Volt.require('app/common/voiceGuide.js');
var DeviceModel 		= Volt.require('app/models/device-model.js');
var WinsetSubList = Volt.require("WinsetUIElement/winsetSubList.js");
 
var OptionMenuPopup = PanelCommon.BaseView.extend({
	isShow : false,
	menuCallback : null,
	menuType : -1,
	menuOption : null,

	initialize : function(options) {
		Volt.log('[option-menu-popup.js] initialize');
		this.menuOption = options;
		this.render();
	},

	render : function() {
		Volt.log('[option-menu-popup.js] render');
		this.optionPopup = new WinsetSubList(this.setTemplate(this.menuOption));
		this.optionPopup.addKeyboardListener(this.onKeyboardEvent());
		this.optionPopup.addListener(this.initSubListener());
		this.setCallback(this.menuOption.callback);
		this.optionPopup.showTime = 30000;
		this.optionPopup.setAnimationDuration("loop", 0);
	},

	show : function() {
	    Volt.log('[option-menu-popup.js] show');
		Mediator.on(CommonDefine.Event.DESTORY_OPTION_MENU, this.hide, this);
		Mediator.on(CommonDefine.Event.GRID_LONG_PRESS, this.handleLongPress, this);
		Mediator.on(CommonDefine.Event.DISCONNECT_USB,this.onPullOutUSB,this);
		
		if (this.menuType == CommonDefine.Const.OPTION_MENU) {
			this.onOptionMenu(this.optionPopup);
			this.optionPopup.setFocus();
			Volt.Nav.block();
		} else if (this.menuType == CommonDefine.Const.LONG_PRESS_MENU) {
			this.onLongPressMenu(this.optionPopup);
		}
		
		this.optionPopup.showFocus("false");
		this.optionPopup.show();
		this.isShow = true;
	},
	
	handleLongPress:function(){
		if(this.menuType == CommonDefine.Const.LONG_PRESS_MENU){
			if(this.optionPopup){
				this.optionPopup.setFocus();
				Volt.Nav.block();
			}
		}
	},
	
	getOptionMenuState : function() {
		return this.isShow;
	},
	
	hide : function() {
	    Volt.log('[option-menu-popup.js] hide');
		this.isShow = false;
		Volt.Nav.unblock();
		if (this.menuType == CommonDefine.Const.OPTION_MENU) {
			Mediator.trigger(CommonDefine.Event.DESTROY_MENU);
		} else if (this.menuType == CommonDefine.Const.LONG_PRESS_MENU) {
			Mediator.trigger(CommonDefine.Event.DESTROY_LONG_PRESS_MENU);
		}
		if (this.optionPopup) {
			this.optionPopup.destroy();
			this.optionPopup = null;
		}
		Mediator.off(CommonDefine.Event.DESTORY_OPTION_MENU, null, this);
		Mediator.off(CommonDefine.Event.GRID_LONG_PRESS, null, this);
		Mediator.off(CommonDefine.Event.DISCONNECT_USB,null,this);
	},

	setTemplate : function(options) {
		Volt.log('[option-menu-popup.js] setTemplate');
		var winsetStyle = null;
		var template = null;

		if (options.style == CommonDefine.Const.OPTION_MENU) {
			winsetStyle = 5;
			// this is corresponding to winsetSublist style
			this.menuType = CommonDefine.Const.OPTION_MENU;
			template = OptionMenuTemplate.optionMenuMain;
		} else {
			winsetStyle = 5;
			// this is corresponding to winsetSublist style
			this.menuType = CommonDefine.Const.LONG_PRESS_MENU;
			template = OptionMenuTemplate.longPressPopup;
		}
		if(options.bgColor !=null){
			template.bgColor = options.bgColor;
		}
		if(WinsetSubList.SubListStyle.KeyScreen_Common_SMART_HUB_SUBLIST_Text){
			winsetStyle = 12;
			template.bKeyCommon = true;
		}
		
		template.items = [];
		if (Object.prototype.toString.call(options.listItems) === "[object Array]") {
			for (var i = 0; i < options.listItems.length; i++) {
				template.items[i] = {
					style : winsetStyle,
					text : options.listItems[i]
				};
			}
		}
		template.parent = scene;
		return template;
	},
	
	onKeyboardEvent : function() {
		Volt.log('[option-menu-popup.js] onKeyEvent');
		var keyboardListener = new KeyboardListener;
		keyboardListener.onKeyReleased = function(actor, keyCode) {
			if (keyCode == Volt.KEY_RETURN) {
				this.hide();
			}
		}.bind(this);
		return keyboardListener;
	},

	initSubListener : function() {
		Volt.log('[option-menu-popup.js] initSubListener');
		//add listener to process mouse click
		var subListListener = new SubListListener;
		subListListener.OnItemClicked = function(singleLineList, itemIndex) {
			if (this.menuCallback) {
			    Volt.log("[option-menu-popup]  optionMenu's onItemClicked callback is working !");
				this.menuCallback(this.optionPopup.focusItemIndex,this.menuOption.options);
			} else {
			    Volt.log("[option-menu-popup]  optionMenu's onItemClicked callback is null !");
			}
		}.bind(this);

		if (this.menuOption.style == CommonDefine.Const.OPTION_MENU) {
			subListListener.OnFocusChanged = onOptionMenuFocusChange;
		}
		
		subListListener.OnTimeOut = function(SubList){
		    Volt.log("[option-menu-popup]  optionMenu's OnTimeOut callback is working !");
			this.hide();
		}.bind(this);
		return subListListener;
	},

	setCallback : function(callback) {
		Volt.log("*****************************" + typeof callback);
		this.menuCallback = _.bind(callback, this);
	},

	onOptionMenu : function(menuWgt) {
		if (Utils.Account.getSignState()) {
			menuWgt.updateItem({
				index : 0,
				text : {
					itemTextString : Volt.i18n.t('UID_SIGN_OUT')
				}
			});
		} else {
			menuWgt.updateItem({
				index : 0,
				text : {
					itemTextString : Volt.i18n.t('UID_SIGN_IN')
				}
			});
		}
		
		menuWgt.setDim({index: 2, ifDim: true});
		//edit nickname
		menuWgt.setDim({index: 3, ifDim: true});
		//update

		var nativeGameListLength = voltApiWrapper.getNativeGameList().length;
		Volt.log("[option-menu-popup.js] nativeGameListLength = " + nativeGameListLength);
		if (nativeGameListLength > 0) {
			menuWgt.setDim({index: 1, ifDim: false});
			//undim delete
//			Mediator.trigger('ENTER_MY_PAGE');
		} else {
		    menuWgt.setDim({index: 1, ifDim: true});
	        //delete
		}

		if (voltApiWrapper.getNeedUpdateFlag()) {
			menuWgt.setDim({index: 3, ifDim: false});
			//undim update
		}

		if (Utils.Account.getSignState()) {
			menuWgt.setDim({index: 2, ifDim: false});
			//undim edit name
		}
	},
	
    onLongPressMenu : function(menuWgt) {
        Volt.log('[option-menu-popup.js] ==========   onLongPressMenu');
        if (this.menuType == CommonDefine.Const.LONG_PRESS_MENU) {
            var bIsStorageEnough = voltApiWrapper.IsStorageEnough(this.menuOption.options.size);
            var UsbStorages = voltApiWrapper.getUsbStorages();
            if(UsbStorages && UsbStorages.storages.length >= 1) {
                for(var i = 0; i < UsbStorages.storages.length; i++){
                    var tempAvailable = voltApiWrapper.setSuitablyUnit(UsbStorages.storages[i].availableSize);
                    if((tempAvailable.unit == 'GB' && (this.menuOption.options.size/1024<tempAvailable.size)) || (tempAvailable.unit == 'MB' && parseFloat(this.menuOption.options.size) <= tempAvailable.size)) {
                        bIsStorageEnough = true;
                        break;
                    }
                }
            }
            var download = Volt.i18n.t('COM_SID_DOWNLOAD');
            for (var i = 0; i < this.menuOption.listItems.length; ++i) {
                if (this.menuOption.listItems[i] == download) {
                    if (!bIsStorageEnough) {
                        this.optionPopup.setDim({
                            index : i,
                            ifDim : true
                        });
                    } else {
                        this.optionPopup.setDim({
                            index : i,
                            ifDim : false
                        });
                    }
                }
            }

        }
    },
    onPullOutUSB : function(){
	    if (this.menuType == CommonDefine.Const.LONG_PRESS_MENU) {
	        Volt.log('[option-menu-popup.js] ========== onPullOutUSB');
	        this.hide();
	    }
	},

});

//note:when have subOption,will add the logic processing
var onOptionMenuFocusChange = function(singleLineList, fromItemIndex, toItemIndex) {
    Volt.log("[option-menu-popup.js] onOptionMenuFocusChange fromItemIndex = " + fromItemIndex + " toItemIndex = " + toItemIndex);
	if(-1 == toItemIndex){
		return;
	}
	var text = '';
	var optionNum = singleLineList.numofItem();
	if (-1 == fromItemIndex) {
		text += Volt.i18n.t('UID_OPTIONS') + ',' + Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>',optionNum) + ",";
	}
	text += singleLineList.text({index: toItemIndex});
	if (singleLineList.ifDim({index:toItemIndex})) {
		text += ',' + Volt.i18n.t('TV_SID_DISABLED');
	}
	VoiceGuide.getVoiceGuide(text);
};
exports = OptionMenuPopup;
