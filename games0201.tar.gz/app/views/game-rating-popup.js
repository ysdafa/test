var _            = Volt.require('modules/underscore.js')._;
var Backbone     = Volt.require('lib/volt-backbone.js');
var Q            = Volt.require('modules/q.js');
var CommonDefine = Volt.require('app/common/common-define.js');
var PanelCommon  = Volt.require('lib/panel-common.js');
var DetailModel  = Volt.require("app/models/detail-model.js");
var Mediator     = Volt.require('app/common/event-mediator.js');
//var Utils        = Volt.require('app/common/utils.js');
//var CommonFucntion = Volt.require('app/common/common-function.js');
var networkStatus  = Volt.require('app/common/network-state.js');
var ErrorHandling  = Volt.require('app/common/error-handling.js');
var GameRatingTemplate = Volt.require('app/templates/1080/rating-template.js');
var WinsetRatingPopup = Volt.require("WinsetUIElement/winsetPopUpRating.js");
var VoiceGuide    = Volt.require('app/common/voiceGuide.js');

var GameRatingPopup = PanelCommon.BaseView.extend({
	template : GameRatingTemplate.container,
    ratingNum : 0,
    isShow: false,
	app_id: null,
	popupRating: null,
	popupRatingListener: null,
	firstTime  : false,
    render : function() {
    },

    initialize : function() {
        print('[game-rating-popup.js] initialize');
		ratingPopupSelf = this;
    },

    show : function(options) {
        print('[game-rating-popup.js] show,options =' + options);
		this.firstTime = true;
        var param = JSON.parse(options);
		this.setWidget(PanelCommon.loadTemplate(this.template));
        Volt.Nav.setRoot(this.widget);
		this.widget.show();  
        
        this.ratingNum = Math.floor(param.star_num, 10);
		this.app_id = param.app_id;
        print('[game-rating-popup.js] show,this.ratingNum =' + this.ratingNum);
		this.initRatingPopup(this.ratingNum,this.app_id);
		//Volt.Nav.beginModal(this.widget);
		this.isShow = true;
		this.widget.onKeyEvent = _.bind(this._onkeyEvent, this);
    },

    initRatingPopup : function(ratingNum,appId) {
    	var that = this;
    	this.popupRatingListener = new PopupRatingListener;
        
		this.popupRatingListener.OnButtonEvent = function(popupRating, nButtonIndex, eventType){
			Volt.log('[game-rating-popup.js] OnButtonEvent .....nButtonIndex = ' + nButtonIndex);
			if ("button_focus_in" == eventType){
				var voiceGuide = '';
				if(that.firstTime){
					voiceGuide += popupRating.titleText+ ',' + popupRating.contentText + ',';
					that.firstTime = false;
				}
				
				if('button_1' == nButtonIndex){
					voiceGuide += Volt.i18n.t('COM_SID_OK');
				}else if('button_2' == nButtonIndex){
					voiceGuide += Volt.i18n.t('COM_SID_CANCEL');
				}
				
				voiceGuide += ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
				VoiceGuide.getVoiceGuide(voiceGuide);
			}
			
			if ("button_clicked" == eventType &&  "button_1" == nButtonIndex){
		        Volt.log('[game-rating-popup.js] button_1 click');      
				//add EventLog
				Volt.KPIMapper.addEventLog('RATINGRQST', {
					d : {
						cp : 'G08_DETAIL',
						appid : appId,
						inputby:'',
					}
				});
				that.putData();
			}
			
			if ("button_clicked" == eventType &&  "button_2" == nButtonIndex){
		        Volt.log('[game-rating-popup.js] button_2 click');
				Volt.setTimeout(function() {
					Backbone.history.back();
		        }, 1);
			}
		}
        this.popupRatingListener.OnTimeOut = function(popupRating){
			Volt.log('[rating-popup.js]------------timeout');
			Volt.setTimeout(function() {
				Backbone.history.back();
				;
			}, 1);
		};
     
		this.popupRating = new WinsetRatingPopup({
            nPopUpRatingStyle : WinsetRatingPopup.PopUpRatingStyle.PopUpRatingStyle_B,
            buttonStyle:WinsetRatingPopup.ButtonStyle.Button_image_O_Style_F_Focus1,
            button1Text:Volt.i18n.t('COM_SID_OK'),
            button2Text:Volt.i18n.t('COM_SID_CANCEL'),
    		id : "test"
		});
		this.popupRating.setTitleText(Volt.i18n.t('UID_RATE'));
		this.popupRating.addListener(this.popupRatingListener);
		this.popupRating.showTime = 20000;
		this.popupRating.setContentText(Volt.i18n.t('COM_SID_WHAT_THINK_OF_THIS_GAME'));
		this.popupRating.markedStarIconNumber = (this.ratingNum)*2;
		this.popupRating.show();
		this.popupRating.defaultFocusIndex = 1;
    },
    
    hide : function() {
        print('[game-rating-popup.js] hide');
        var deferred = Q.defer();
        //Volt.Nav.endModal();
		this.isShow = false;
		this.app_id = null;
		this.firstTime = false;
		this.ratingNum = 0;
		if(this.popupRating) {
			this.popupRating.removeListener(this.popupRatingListener);
			this.popupRating.destroy();
			this.popupRating = null;
		}
		if(this.widget){
			this.widget.destroy();
			this.widget = null;
		}
		
		deferred.resolve();
        return deferred.promise;
    },

	_onkeyEvent: function(keycode, type) {
		print('[game-rating-popup.js] _onkeyEvent');
		var ret = false;
		if (type == Volt.EVENT_KEY_RELEASE) 
			return true;
		switch (keycode) {
			case Volt.KEY_RETURN: {
				print('[game-rating-popup.js] Volt.KEY_RETURN');
				Backbone.history.back();
				ret = true;
				break;
			}
			
			default:
				break;
		}
		return ret;
    },

	putData : function() {
		print('[game-rating-popup.js] putData');
        if (!networkStatus.getNetWorkState()) {
            Backbone.history.back();
            Volt.setTimeout( function() {
                ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR,'','505');
            }.bind(this), 200);
        } else {
        	print('ratingPopupSelf.popupRating = ' + ratingPopupSelf.popupRating);
			var starNum = ratingPopupSelf.popupRating.markedStarIconNumber;
			print('starNum = ' + starNum);
            function onSuccess() {
                print('[game-rating-popup.js]rating success');
                DetailModel.set('my_rating', String(starNum/2));
                Mediator.trigger(CommonDefine.Event.MY_RATING);
            }

            function onFail() {
                print('[game-rating-popup.js] on Fail');
            }

            DetailModel.put(this.app_id, starNum/2).then(onSuccess, onFail);
			//Mediator.trigger(CommonDefine.Event.CLOSE_RATING_POPUP);
			Backbone.history.back();
        }
    },

});

//exports = new GameRatingPopup;
exports = GameRatingPopup;
