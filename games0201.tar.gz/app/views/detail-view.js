// Include libraries

var _           = Volt.require('modules/underscore.js')._;
var Q           = Volt.require('modules/q.js');
var Backbone    = Volt.require('lib/volt-backbone.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var dimView     = Volt.require('app/views/dim-view.js');

// Include models
var DetailModel    = Volt.require("app/models/detail-model.js");
var DetailTemplate = Volt.require("app/templates/1080/detail-template.js");
var CommonContent  = Volt.require('app/common/common-content.js');
var CommonDefine   = Volt.require('app/common/common-define.js');
var CommonFucntion = Volt.require('app/common/common-function.js');
var voltapi        = Volt.require('voltapi.js');
var networkStatus  = Volt.require('app/common/network-state.js');
var Mediator       = Volt.require('app/common/event-mediator.js');
var LoadingView    = Volt.require('app/views/loading-view.js');
var voltApiWrapper = Volt.require("app/common/voltapi-wrapper.js");
var ErrorHandling = Volt.require('app/common/error-handling.js');
var Utils = Volt.require('app/common/utils.js');
var DeviceModel = Volt.require('app/models/device-model.js');
var ServerController = Volt.require('app/controller/server-controller.js');

var Gridlist         = Volt.require('app/views/grid-list-view.js');
var GridlistTemplate = Volt.require('app/templates/1080/grid-list-template.js');
var VoiceGuide    = Volt.require('app/common/voiceGuide.js');

var lastFocus = null;

/*define global object for view*/
var detailViewSelf = null;
var thumbnailView = null;
var buttonView = null;
var titleView = null;
var storageView = null;
var relatedView = null;
var descriptionView = null;
var screenView = null;
var infoView = null;
var moreInfoView = null;

/*define global object for button*/
var ratingBtn = null;
var shareBtn = null;
var downloadBtn = null;
var controllerBtn = null;
var moreBtn = null;
var _dim = null;

//var fontColor = null;
var bgColor = null;
var statusView = 'HIDE'; //SHOW HIDE ACTIVE DEACTIVE

var DetailView = PanelCommon.BaseView.extend({
	template       : DetailTemplate.container,
	firstFocus     : true,
	appID          : '',
	bAlreadyReder  : false,
    requestSuccess : true,
    viewIsVisible  : false,
    isActive       : false,
    closeIcon      : null,
	mlsModeChanged : false,
	
	initialize : function() {
		this.setWidget(PanelCommon.loadTemplate(this.template, null, null, false));
		detailViewSelf = this;
	},
    
	render : function() {

	},

	show : function(param, animationType) {
		Volt.log('[detail-view.js] show...this.firstFocus = ' + this.firstFocus);
        var deferred = Q.defer();
        statusView = 'SHOW';
        
        this.startListening();
        this.startNativeListening();
        if(param.bgColor){
            Volt.log('[detail-view.js] appID ='+ param.id);
            bgColor = param.bgColor;
        }
		
		this.appID = param.id;
		if (!this.widget) {
			this.setWidget(PanelCommon.loadTemplate(this.template, null, null, false));
		}
        this.updateColor();
		Volt.Nav.setRoot(this.widget, {focus: null});
		this.widget.show();
		this.isActive = true;
        
		if (this.firstFocus) {
			LoadingView.show(CommonDefine.Const.VIEW_LOADING);
            
            if(ServerController.isReady()){
                Volt.log('server api is not ready');
                this.requestData();
            } else {
                Mediator.on('SERVER_API_READY', this.requestData, this);
            }
           
			this.animationType = animationType;
			this.firstFocus = false;
		}
        
		deferred.resolve();
        return deferred.promise;
	},
	
	pause : function() {
        Volt.log("[detail-view.js] pause --------");
        detailViewSelf.enableButton(false);
        
        if (statusView == 'PAUSE') {
            Volt.log('detail view has already paused......');
            return;
        }

        statusView = 'PAUSE';
        Volt.lastFocus = Volt.Nav.getFocusedWidget();
        if (thumbnailView) {
            thumbnailView.pauseVideoObject();
        }
        Volt.Nav.blur();
		if(this.mlsModeChanged){
			Volt.log('[detail-view.js]mls Mode Changed! Do not show dim');
            this.mlsModeChanged = false;
		} else {
			dimView.show({
				parent : this.widget
			});
		}
    },
    
    resume : function(){
    	Volt.log('[detail-view.js] resume --------');
        detailViewSelf.enableButton(true);
        
    	if(statusView == 'SHOW') {
            Volt.log('detail view has already resumed.....');
            return;
        }
        
    	if(!this.requestSuccess){
            Backbone.history.back();
            return;
        }

        if (this.isActive) {
			dimView.hide();
			statusView = 'SHOW';
			Volt.log('[detail-view.js] this.viewIsVisible = ' + this.viewIsVisible);
			if(titleView) {
			    titleView.onChangeCursor(DeviceModel.get('visibleCursor'));
			}
			this.setLastFocus();
			
			if(thumbnailView){
				thumbnailView.resumeVideoObject();
			}
        }
	},
    
    active : function(){
        Volt.log('[detail-view.js] active.......');
        if(this.isActive){
            Volt.log('detail view has already active');
            return;
        }
        //statusView = 'ACTIVE';
        this.isActive = true;
		Volt.log('buttonView:::'+buttonView);
		if(buttonView){
			Volt.log('init download status!!!!!!!!!!!');
			buttonView.destroyProcessBar();
			if(downloadBtn) {
			    buttonView.InitDownloadBtn();
			}
		}
        detailViewSelf.startListening();
        detailViewSelf.resume();  		
    },
    
    deactive :function(){
        Volt.log('[detail-view.js] deactive.......'); 
        if(!this.isActive){
            Volt.log('detail view has already deactive');
            return;
		}
        //statusView = 'DEACTIVE';
        this.isActive = false;
        detailViewSelf.stopListening();
        detailViewSelf.pause();
    },
    
    exit : function(bHide){
        if(thumbnailView && thumbnailView.videoObject){
            Volt.log('[detail-view.js] GamesThumbnailView video hide [when Exit games]');
            thumbnailView.videoObject.hide();
            Volt.log('[detail-view.js] GamesThumbnailView video stop [when Exit games]');
            thumbnailView.videoObject.stop();
		}
		
		Volt.log('[detail-view.js]bHide = '+ bHide);
		if(bHide){
			voltApiWrapper.removeAllInstallList();
		}
	},

    pauseForChooseDevicePopup : function(){
        Volt.log("[detail-view.js] pauseForChooseDevicePopup --------");
        statusView = 'PAUSE';
        
        Mediator.off(CommonDefine.Event.GAMES_ON_ACTIVATE, null, detailViewSelf);
        Mediator.off(CommonDefine.Event.GAMES_ON_DEACTIVATE, null, detailViewSelf);
        
        detailViewSelf.enableButton(false);
        
        if(thumbnailView){
            thumbnailView.pauseVideoObject();
        }
        Volt.Nav.blur();
        _dim = dimView.show({
            parent : this.widget
        }, true);
    },

    resumeForChooseDevicePopup : function(){
        Volt.log("[detail-view.js] resumeForChooseDevicePopup --------");
        statusView = 'SHOW';
        
        Mediator.on(CommonDefine.Event.GAMES_ON_ACTIVATE, detailViewSelf.active, detailViewSelf);
        Mediator.on(CommonDefine.Event.GAMES_ON_DEACTIVATE, detailViewSelf.deactive, detailViewSelf);

        detailViewSelf.enableButton(true);

        dimView.hide(_dim);
        _dim = null;
        detailViewSelf.setLastFocus();

        if(thumbnailView){
            thumbnailView.resumeVideoObject();
        }
    },
	
    enableButton:function(flag){
        Volt.log('[detail-view.js] DetailView enableButton flag = ' + flag);
        if(downloadBtn && downloadBtn.canBeEnable !== false){
            downloadBtn.enable(flag);
        }
        if(ratingBtn){
            ratingBtn.enable(flag);
        }
        if(shareBtn){
            shareBtn.enable(flag);
        }
        if(controllerBtn){
            controllerBtn.enable(flag);
        }
        if(moreBtn){
            moreBtn.enable(flag);
        }
    },
    requestData:function(){
        function onSuccess(){
            LoadingView.hide();
            detailViewSelf.requestSuccess = true;
			var mlsMode = voltapi.vconf.getValue('memory/mls/state');
			Volt.log(' vconf MLS_STATE : ' + mlsMode);
            Volt.log('[detail-view.js]Current status, detailViewSelf.bAlreadyReder =' + detailViewSelf.bAlreadyReder + ' detailViewSelf.appID = ' + detailViewSelf.appID);
            if((statusView == 'SHOW' && detailViewSelf.bAlreadyReder == false && detailViewSelf.appID == DetailModel.get('app_id'))
				||(mlsMode == 1)){
                detailViewSelf.renderContent();
            } 
        }
        
        function onError(msg){ 
            LoadingView.hide();
            detailViewSelf.requestSuccess = false;
            Volt.log("[detail-view.js]" + CommonContent.getViewType() + 'error msg:'+JSON.stringify(msg));
            var viewType = CommonContent.getViewType();
            if(viewType == '#detail'){
                ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_CONNECT_SEVER_ERROR, detailViewSelf.appID, JSON.stringify(msg.status));
            }
        }
        
        DetailModel.fetch({appId: detailViewSelf.appID})
            .then(onSuccess,onError); 
    },
    
	renderContent : function() {
		Volt.log('[detail-view.js] DetailView renderContent....');
		if (!this.widget) {
			this.setWidget(PanelCommon.loadTemplate(this.template, null, null, false));
		}
		
		this.bAlreadyReder = true;
		this.renderGamesTitle();
		this.renderGamesThumbnail();
		this.renderStorageInfo();
		this.renderGamesInfo();
        this.renderDescription();
        this.renderScreenShot();
		this.renderButtons();
		this.renderRelated();
		
		this.widget.show();
		Volt.Nav.setRoot(this.widget, {focus: null});

		this.setDefaultFocus();
    },
    
    setLastFocus : function(){
        if(Volt.lastFocus) {
		    lastFocus = Volt.lastFocus;
		    Volt.lastFocus = null;// reset Volt.lastFocus after used it
		}
        if(lastFocus){
            Volt.Nav.setRoot(this.widget,{focus:lastFocus}); 
        }else{
            Volt.Nav.setRoot(this.widget);
        }
    },
    
    setDefaultFocus: function(){
        var downloadWidget = this.widget.getDescendant('download_button_widget');
        var controllerWidget = this.widget.getDescendant('controller_button_widget');
        var moreWidget = this.widget.getDescendant('more_button_widget');
        var screenshotList = this.widget.getDescendant('detail-view-screenshot-list');
        var bigThumbnail = this.widget.getDescendant('games_detail_big_thumbnail_list');
		//for loading condition
		if(Volt.APP_STATUS == CommonDefine.Event.GAMES_ON_DEACTIVATE){
			lastFocus = downloadWidget;
		}else{
			Volt.Nav.focus(downloadWidget);
		}
		
		Volt.Nav.setNextItemRule(screenshotList, 'left', bigThumbnail);
		Volt.Nav.setNextItemRule(downloadWidget, 'left', downloadWidget);
		Volt.Nav.setNextItemRule(controllerWidget, 'right', controllerWidget);
		if (moreWidget && moreWidget.focusable == true) {
			Volt.Nav.setNextItemRule(moreWidget, 'left', screenshotList);
			Volt.Nav.setNextItemRule(moreWidget, 'down', screenshotList);
			Volt.Nav.setNextItemRule(moreWidget, 'up', moreWidget);
			Volt.Nav.setNextItemRule(screenshotList, 'right', moreWidget);
		} else {
		    Volt.Nav.setNextItemRule(screenshotList, 'right', screenshotList);
		}
		
		this.setBigThumbnailRule();
	},
	
	setBigThumbnailRule : function(moreinfo){
	    var bigThumbnail = detailViewSelf.widget.getDescendant('games_detail_big_thumbnail_list');
	    if(moreinfo) {
	        var closeWidget = detailViewSelf.widget.getDescendant('moreinfo_close_button_widget');
	        Volt.Nav.setNextItemRule(bigThumbnail, 'right', closeWidget);
	        Volt.Nav.setNextItemRule(bigThumbnail, 'down', closeWidget);
	        Volt.Nav.setNextItemRule(closeWidget, 'left', bigThumbnail);
	        Volt.Nav.setNextItemRule(closeWidget, 'right', closeWidget);
	    } else {
	        var screenshotList = detailViewSelf.widget.getDescendant('detail-view-screenshot-list');
	        Volt.Nav.setNextItemRule(bigThumbnail, 'right', screenshotList);
	        Volt.Nav.setNextItemRule(bigThumbnail, 'down', screenshotList);
	    }
	},
    
    setColorPick: function(){
        
    },

	renderGamesTitle : function() {
		var container = this.widget.getDescendant('detail-view-title-area'); 
        new GamesTitelView().render(container);
        if(titleView)
            titleView.startListening();
	},

	renderGamesThumbnail : function() {
		var container = this.widget.getDescendant('detail-view-gamesthumbnail-area');
        new GamesThumbnailView().render(container);
	},

	renderStorageInfo : function() {
		var container = this.widget.getDescendant('detail-view-storage-area');
        new StorageInfoView().render(container);
        if(storageView)
            storageView.startListening();
	},
    
    renderScreenShot: function(){
        var container = this.widget.getDescendant('detail-view-screenshot-area');
        new ScreenShotView().render(container);
    },

	renderGamesInfo : function() {
		var container = this.widget.getDescendant('detail-view-gamesinfo-area');
		new GamesInfoView().render(container);
	},
    
    
    renderDescription: function(){
        var container = this.widget.getDescendant('detail-view-description-area');
        var moreInfoContainer = this.widget.getDescendant('detail-view-moreinfo-area');
		new GamesDescriptionView().render(container, moreInfoContainer);
		if(descriptionView)
            descriptionView.startListening();
    },

	renderRelated : function() {
		var container = this.widget.getDescendant('detail-relate-container');
		var videoText = this.widget.getDescendant('detail_relate_video_text');
		videoText.textColor = Volt.hexToRgb('#FFFFFF',60);
        new RelatedItemView().render(container);
	},
    
	renderButtons : function() {
		var container = this.widget.getDescendant('detail-view-button-area');
        new GamesButtonView().render(container);
        if(buttonView)
            buttonView.startListening();
	},

	hide : function() {
		Volt.log('[detail-view.js] hide .....');
		var deferred = Q.defer();
        
        if(statusView == 'HIDE') {
            Volt.log('detail view has already paused......');
            deferred.resolve();
			return deferred.promise;
        }
        statusView = 'HIDE';
        
		//this.widget.hide();
		this.stopListening();
		this.stopNativeListening();
        Volt.Nav.focus(null);
        Volt.Nav.reset();
        LoadingView.hide();
        this.viewIsVisible=false;
        this.isActive = false;
        DetailModel.stopRequestData();
		this.destroy();
		this.reset();
		
		deferred.resolve();
		return deferred.promise;
	},
    
	destroy : function() {
		if (!this.widget)
			return;
		Volt.log('[detail-view.js] destroy ...');
		if (!(typeof thumbnailView === 'undefined') && thumbnailView){ Volt.log("there there");thumbnailView.destroy();};
		if (!(typeof titleView === 'undefined') && titleView){titleView.destroy();};
		if (!(typeof storageView === 'undefined') && storageView){storageView.destroy();};
		if (!(typeof relatedView === 'undefined') && relatedView){relatedView.destroy();};
		if (!(typeof descriptionView === 'undefined') && descriptionView){descriptionView.destroy();};
		if (!(typeof screenView === 'undefined') && screenView){screenView.destroy();};
		if (!(typeof buttonView === 'undefined') && buttonView){buttonView.destroy();};
        this.widget.destroyChildren();
		this.widget.destroy();
		this.widget = null;
		this.firstFocus = true;
		this.bAlreadyReder = false;
		this.appID = '';
		delete thumbnailView;
		delete buttonView;
		delete titleView;
		delete storageView;
		delete relatedView;
		delete descriptionView;
		delete screenView;
	},
	
	reset : function(){
	    _dim = null;
	    Volt.lastFocus = null;
		lastFocus      = null;
		thumbnailView  = null;
		buttonView     = null;
		titleView      = null;
		storageView    = null;
		relatedView    = null;
		descriptionView = null;
		screenView     = null;
		infoView       = null;
		moreInfoView   = null;
		
		ratingBtn      = null;
		shareBtn       = null;
		downloadBtn    = null;
		controllerBtn  = null;
		moreBtn        = null;

		bgColor        = null;
		statusView     = 'HIDE'; //SHOW HIDE ACTIVE DEACTIVE
	},

    stopListening: function(){
        Mediator.off(CommonDefine.Event.MSGBOX_BUTTON,null,this);
        Mediator.off('EVENT_UPDATE_BIG_THUMBNAIL_NEXT_ITEM_RULE',null,this);
        Mediator.off(CommonDefine.Event.GAMES_ON_DEACTIVATE,null,this);
        Mediator.off(CommonDefine.Event.GAMES_EXIT,null,this);
        
        Mediator.off(CommonDefine.Event.BEGIN_DOWNLOAD,null,buttonView);
        Mediator.off(CommonDefine.Event.MY_RATING,null,buttonView);
        Mediator.off(CommonDefine.Event.CLOSE_RATING_POPUP, null, buttonView);
        Mediator.off(CommonDefine.Event.INSTALL_FAIL_APPSYNC_NOT_COMPLETE, null, buttonView);
        Mediator.off(CommonDefine.Event.INSTALL_FAIL, null, buttonView);
        
        Mediator.off(CommonDefine.Event.UPDATE_STORAGE,null,storageView);
        
        Mediator.off(CommonDefine.Event.EVENT_MORE_DESCRIPTION_CLOSE_CLICKED,null,descriptionView);
	},
    
    startListening:function(){
        Mediator.on(CommonDefine.Event.MSGBOX_BUTTON, this.processMsgBoxEvent, this);
		Mediator.on('EVENT_UPDATE_BIG_THUMBNAIL_NEXT_ITEM_RULE', this.setBigThumbnailRule, this);
        Mediator.on(CommonDefine.Event.GAMES_ON_DEACTIVATE,      this.deactive,            this);
		Mediator.on(CommonDefine.Event.GAMES_EXIT, this.exit, this);
        if(storageView)
            storageView.startListening();
        if(buttonView)
            buttonView.startListening();
        if(descriptionView)
            descriptionView.startListening();
    },

    startNativeListening : function(){
        Mediator.on(CommonDefine.Event.GAMES_ON_ACTIVATE, this.active, this);
        Mediator.on(CommonDefine.Event.CHANGE_HIGH_CONTRAST, this.changeHighContrast, this);
        Mediator.on(CommonDefine.Event.EVENT_UPDATE_WIDGET_COLOR, this.updateColor, this);
        Mediator.on(CommonDefine.Event.CHANGE_MLS, this.changeMLS, this);
        Mediator.on('EVENT_SHOW_CHOOSE_DEVICE_POPUP',            this.pauseForChooseDevicePopup, this);
        Mediator.on('EVENT_HIDE_CHOOSE_DEVICE_POPUP',            this.resumeForChooseDevicePopup, this);
    },

    stopNativeListening : function(){
        Mediator.off(CommonDefine.Event.GAMES_ON_ACTIVATE, null, detailViewSelf);
        Mediator.off(CommonDefine.Event.CHANGE_HIGH_CONTRAST, null, this);
        Mediator.off(CommonDefine.Event.EVENT_UPDATE_WIDGET_COLOR, null, this);
        Mediator.off(CommonDefine.Event.CHANGE_MLS, null, this);
        Mediator.off('EVENT_SHOW_CHOOSE_DEVICE_POPUP', null, this);
        Mediator.off('EVENT_HIDE_CHOOSE_DEVICE_POPUP', null, this);
        
        Mediator.off(CommonDefine.Event.CHANGE_VISIBLE_CURSOR, null, titleView);
        Mediator.off('SERVER_API_READY', null, this);
    },
    
	processMsgBoxEvent: function(data) {
		Volt.log('[detail-view.js] processMsgBoxEvent:type is:'+ data.msgBoxtype + " eventType is:" + data.eventType);
		if(data.eventType == CommonDefine.Event.SELECT_BTN1) {
			switch(data.msgBoxtype) {
				case CommonDefine.MsgBoxType.MSGBOX_TYPE_DLD_BEFORE_RATE:

					break;
				case CommonDefine.MsgBoxType.MSGBOX_TYPE_INSTALL_FACEBOOK:
				case CommonDefine.MsgBoxType.MSGBOX_TYPE_INSTALL_YOUTUBE:
					//show install popup
                    Volt.log('[detail-view.js] install youtube');
                    if (!networkStatus.getNetWorkState()) {
                        Volt.setTimeout( function() {
                            ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR, '', '505');
                        }.bind(this), 200);
                    } else {
                        Volt.setTimeout(function() {
                            CommonContent.showInstallPopup(data.appID);
                        }, 200);
                    }
                    break;

				case CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_INSTALLED:
					voltApiWrapper.startSSOPopup();
					break;
				case CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR:
                    var aulApp = new Aul();
                    aulApp.launchApp("org.tizen.NetworkSetting-Tizen");
                    break;
				default:
					break;
				} 
		} else if(data.eventType == CommonDefine.Event.SELECT_BTN2) {
			
		}
	},
    
    updateColor:function(){
        var highContrast = DeviceModel.get('highContrast');
        if(highContrast){
            if(thumbnailView) {
                thumbnailView.widget.color = Volt.hexToRgb('#000000', 100);
            }
            detailViewSelf.widget.getDescendant('detail-view-bg-area-dim-layer').color = Volt.hexToRgb('#000000', 100);
            detailViewSelf.widget.getDescendant('detail-view-title-area').color = Volt.hexToRgb('#ffffff', 6);
            detailViewSelf.widget.getDescendant('detail-view-relate-area-dim-layer').color = Volt.hexToRgb('#ffffff', 10);
            detailViewSelf.widget.getDescendant('detail-view-content-area').color = Volt.hexToRgb('#233146', 0);
        } else {
            if(bgColor){
                Volt.log('[detail-view.js]@@@@@@@@@@@@@@@@@@@ updateBgColor bgColor.r =' + bgColor.r + ' bgColor.g = ' + bgColor.g + ' bgColor.b = ' + bgColor.b);
                var tempBgColor = {
                    r : bgColor.r,
                    g : bgColor.g,
                    b : bgColor.b,
                    a : 255,
                };
                if(thumbnailView) {
                    thumbnailView.widget.color = tempBgColor;
                }
                detailViewSelf.widget.getDescendant('detail-view-bg-area').color = tempBgColor;
                detailViewSelf.widget.getDescendant('detail-view-content-area').color = Volt.hexToRgb('#233146', 0);
                detailViewSelf.widget.getDescendant('detail-view-bg-area-dim-layer').color = Volt.hexToRgb('#000000', 25);
                detailViewSelf.widget.getDescendant('detail-view-title-area').color = Volt.hexToRgb('#000000', 8);
                detailViewSelf.widget.getDescendant('detail-view-relate-area-dim-layer').color = Volt.hexToRgb('#000000', 8);
            }
        }
    },
    
    /*This is special onHighContrastChanged for detail bg*/
    changeHighContrast : function(flagHighContrast){
        Volt.log("[detail-view.js] changeHighContrast " + flagHighContrast);
        if(flagHighContrast){
            Mediator.trigger(CommonDefine.Event.EVENT_UPDATE_WIDGET_COLOR);
        }else{
            if(thumbnailView && thumbnailView.thumbnail) {
                bgColor = thumbnailView.thumbnail.getInformationColorPicking();
                Mediator.trigger(CommonDefine.Event.EVENT_UPDATE_WIDGET_COLOR);
            }
        }
    },
    
    changeMLS : function(mlsMode){
        Volt.log("[detail-view.js] changeMLS " + mlsMode);
        if(mlsMode) {
            if(thumbnailView){
                thumbnailView.destroyVideoObject();
            }
			dimView.hide();
			this.mlsModeChanged = true;
        }
    },

    onKeyEvent : function(keyCode, keyType){
        if(keyType == Volt.EVENT_KEY_RELEASE){
            return false;
        }
        if(moreInfoView && moreInfoView.isShown){
            switch(keyCode){
                case Volt.KEY_RETURN: {
                    Volt.log("@@@Return key");
                    moreInfoView.onSelect_Close();
                    return true;
                }
            }
        }
        return false;
    },
});

var GamesTitelView = PanelCommon.BaseView.extend({
	btnListener : new ButtonListener(),

	initialize : function() {
		titleView = this;
		this.btnListener.onButtonClicked = function(button, type) {
			switch(button.id) {
				case 'back-icon':
				    titleView.onSelect();
					break;
				case 'close-icon':
				    titleView.closeBtn.killFocus();
					Mediator.trigger(CommonDefine.Event.GAMES_EXIT);
					Volt.exit();
					break;
			}
		};
	},
	
	startListening : function(){
	    Volt.log("[detail-view.js] GamesTitelView startListening");
	    Mediator.on(CommonDefine.Event.CHANGE_VISIBLE_CURSOR, this.onChangeCursor, this);
	},
    
	render : function(parent) {
		Volt.log('[detail-view.js] GamesTitelView.render');
		var game_title = DetailModel.get('game_title');
		var titleWidget = PanelCommon.loadTemplate(DetailTemplate.games_title, { game_title : game_title }, parent);

		this.setWidget(titleWidget);
		this.backIcon = this.widget.getDescendant('detail-view-title-returnicon-area');
		this.closeIcon = this.widget.getDescendant('detail-view-title-closeicon-area');
		
		if(!DeviceModel.get('visibleCursor')){
            this.backIcon.hide();
			this.closeIcon.hide();
        } else {
            this.backIcon.show();
			this.closeIcon.show();
		}
		this.backBtn = new Button(DetailTemplate.backBtn);
		this.backBtn.parent = this.backIcon;
		this.backBtn.setBackgroundImage({
			state : "focused",
			src : "images/1080/highlight/4way_focus.png"
		});
		/*
		this.backBtn.setBackgroundImage({
			state : "focused-roll-over",
			src : "images/1080/highlight/4way_focus.png"
         });
         */
        this.backBtn.setIconScaleFactor({
            state : "focused-roll-over",
            scaleX : 1.1,
            scaleY : 1.1,
        });
		this.backBtn.setIconAlpha({
			state : "focused",
			alpha : 255
		});
		this.backBtn.setIconAlpha({
			state : "normal",
			alpha : 153
		});

		this.backBtn.addListener(titleView.btnListener);
		this.backIcon.addEventListener('OnMouseOver', function() {
			Volt.lastFocus = Volt.Nav.getFocusedWidget();
            Volt.Nav.blur();
			titleView.backBtn.setFocus();
			var AbsolutePosition = this.backIcon.getAbsolutePosition();
				var opt = {
					text: Volt.i18n.t('COM_SID_RETURN'),
					x: AbsolutePosition.x,
					y: AbsolutePosition.y,
					height: this.backIcon.height,
					width: this.backIcon.width,
					direction:'up',
					parent:this.backIcon,
				};
				
			CommonContent.showToolTip(opt,DetailTemplate);
        }.bind(this));
		this.backIcon.addEventListener('OnMouseOut', function() {
			CommonContent.hideToolTip();
		//	detailViewSelf.setLastFocus();
        }.bind(this));
		
		this.closeBtn = new Button(DetailTemplate.closeBtn);
		this.closeBtn.parent = this.closeIcon;
		this.closeBtn.setBackgroundImage({
			state : "focused",
			src : "images/1080/highlight/4way_focus.png"
		});
        /*
         this.closeBtn.setBackgroundImage({
         state : "focused-roll-over",
         src : "images/1080/highlight/4way_focus.png"
         });
         */
        this.closeBtn.setIconScaleFactor({
            state : "focused-roll-over",
            scaleX : 1.1,
            scaleY : 1.1,
        });
		this.closeBtn.setIconAlpha({
			state : "focused",
			alpha : 255
		});
		this.closeBtn.setIconAlpha({
			state : "normal",
			alpha : 153
		});
		this.closeBtn.addListener(titleView.btnListener);
		this.closeIcon.addEventListener('OnMouseOver', function() {
			Volt.log('[Detail-view.js]close button OnMouseOver');
			Volt.lastFocus = Volt.Nav.getFocusedWidget();
            Volt.Nav.blur();
			titleView.closeBtn.setFocus();
			var AbsolutePosition = this.closeIcon.getAbsolutePosition();
				var opt = {
					text: Volt.i18n.t('COM_SID_EXIT'),
					x: AbsolutePosition.x,
					y: AbsolutePosition.y,
					height: this.closeIcon.height,
					width: this.closeIcon.width,
					direction:'up',
					parent:this.closeIcon,
				};
				
			CommonContent.showToolTip(opt,DetailTemplate);
            
        }.bind(this));
		
        this.closeIcon.addEventListener('OnMouseOut', function() {
			Volt.log('[Detail-view.js]close button OnMouseOut');
			CommonContent.hideToolTip();
			//detailViewSelf.setLastFocus();
        }.bind(this));
		Volt.Nav.reload();
		return this;
	},
    
    onChangeCursor : function(visible){
    	Volt.log('[detail-view.js] onChangeCursor ..... visible is ' + visible);
		
		/*if(statusView != 'SHOW'){
			Volt.log('view status is not show');
			return;
		}*/
		 
		if( titleView && titleView.backIcon ){
			if(visible){
				Volt.log('[detail-view.js] onChangeCursor backIcon show .....');
				titleView.backIcon.show();
			}else{
				Volt.log('[detail-view.js] onChangeCursor backIcon hide .....');
				titleView.backIcon.hide();
			}
		}

		if( titleView && titleView.closeIcon ){
			if(visible){
				Volt.log('[detail-view.js] onChangeCursor closeIcon show .....');
				titleView.closeIcon.show();
			}else{
				Volt.log('[detail-view.js] onChangeCursor closeIcon hide .....');
				titleView.closeIcon.hide();
				if(statusView == 'SHOW'){
					detailViewSelf.setLastFocus();
				}
			}
		}
	},

	onSelect : function(widget) {
		Volt.log("[detail-view.js] detail-view-Games-title return onSelect");
		CommonContent.hideToolTip();
		//Backbone.history.back();
		if (Backbone.history.getCount() > 1) {
			Volt.log("Return");
			Backbone.history.back();
			Utils.Timer.clearTimeOut();
		} else {
			Volt.log("[detail-view.js]Exit Games Panel");
			Mediator.trigger(CommonDefine.Event.GAMES_EXIT);
			Volt.exit();
		}
    },
    
	destroy : function(widget){
		Volt.log('[detail-view.js] Games title.on destroy');
		if (!this.widget)
			return;
      
		this.widget.destroyChildren();
		this.widget.destroy();
        this.widget = null;
	},
});

var GamesThumbnailView = PanelCommon.BaseView.extend({
//	videoWidget:null,
    
	initialize:function(){
		thumbnailView = this;
	},
	
	render : function(parent) {
		Volt.log('[detail-view.js] GamesThumbnailView.render');
		
		var mlsMode = DeviceModel.get('mlsState');
        Volt.log('[detail-view.js] GamesThumbnailView check - vconf MLS_STATE : ' + mlsMode);
        if (mlsMode == 1) {
            Volt.log('~~~~~~~~~~~~~~~~~~ MLS mode, do not play video');
            this.videoObjectComplated = true;
        } 
        
		this.widget = this.initGrid();
        
        this.widget.color = Volt.hexToRgb('#233146', 100);
        this.widget.focusable = true;
        this.widget.id = "games_detail_big_thumbnail_list";
        this.widget.loopRightFlag = false;
        this.widget.loopLeftFlag = false;
        
        parent.addChild(this.widget);
        this.setWidget(this.widget);
        
        Volt.Nav.reload();
        return this;
	},
	
	initGrid : function(){
	    var thumbListener = new ThumbnailListener;
        thumbListener.onImageReady = function(thumbnail, id, success){
            if(success){
                Volt.log("~~~~~~~~~~~~~~~~~~ " + thumbnail + ":" + id + " load " + success);
                 if(bgColor == null){
                    this.thumbnail = thumbnail;
                    thumbnail.setInformationColorPickingRange(22,22,0,0);
                    bgColor = thumbnail.getInformationColorPicking();
                    Mediator.trigger(CommonDefine.Event.EVENT_UPDATE_WIDGET_COLOR); 
                }
                
                if(statusView == 'SHOW' && this.videoObjectComplated != true) {
                    if(DetailModel.get('trailer_id')) {
                        Volt.log("~~~~~~~~~~~~~~~~~~ play video after 10sec");
                        var renderer = this.widget.renderer(0, 0);
                        this.createVideoObject(renderer);
                    } else {
                        Volt.log("~~~~~~~~~~~~~~~~~~ video url = " + DetailModel.get('trailer_id') + ", it can not play");
                        this.thumbnail.visualizeAttachIcon(false, "icon1");
                        this.videoObjectComplated = true;
                    }
                } else {
                    Volt.log("~~~~~~~~~~~~~~~~~~ don't need play video");
                }
            }
        }.bind(this);
        
        var thumbnailData = {
            style : CommonDefine.Const.HALO_ITEM_ALL_SAME,
            groups : [{
                modelArr : [{
                    thumbnailSrc : DetailModel.get('thumbnail_url')
                }]
            }]
        };

        var gridView = new Gridlist(GridlistTemplate.detailPageBigThumbnail, JSON.stringify(thumbnailData), parseInt(scene.width * 0.341667), parseInt(scene.height * 0.341667));
        gridView.setItemData = function(mustache, modelData){
            mustache.imgUrl = modelData['thumbnailSrc'];
            Volt.log('~~~~~~~~~~~~~~~~~~ imgUrl - ' + mustache.imgUrl);
            mustache.bigThumbnail = true;
        };

        gridView.setItemTemplate = function(rendererInstance, parentWidth, parentHeight, data){
            CommonContent.setBlankStyle(rendererInstance, parentWidth, parentHeight);
            var thumbnailObj = rendererInstance.thumbnail;
            thumbnailObj.addThumbnailListener(thumbListener);
            thumbnailObj.setContentImage(data.imgUrl);
        };

        gridView.onItemPress = function(itemData, groupIndex, itemIndex){
            Volt.log('GamesThumbnailView onItemPress');
            this.onSelect();
        }.bind(this);

        gridView.disableLongPress();
        gridView.disableScroll();
        
        return gridView.render().widget;
    },
    
    createVideoObject : function(renderer){
        if(!this.videoObject) {
            this.videoObject = new VideoActor({
                parent : renderer.root,
                width : renderer.root.width,
                height : renderer.root.height,
                type : "mm_async",
                uri : DetailModel.get('trailer_id')
            });
            Volt.log('[detail-view.js] GamesThumbnailView video actor hide [when create]');
            this.videoObject.hide();
            this.videoActorListener = new VideoActorListener;
            this.videoActorListener.onVideoPlayCompleted = function(videoActor){
                Volt.log("[detail-view.js] GamesThumbnailView video play complated");
                this.videoObjectComplated = true;
                if(this.videoObject){
                    Volt.log('[detail-view.js] GamesThumbnailView video actor hide [when video play complated]');
                    this.videoObject.hide();
                    Volt.setTimeout(function(){
                        this.destroyVideoObject();
                    }.bind(this), 1);
                }
            }.bind(this);
            this.videoObject.addListener(this.videoActorListener);
            
            this.videoTimer = Volt.setTimeout(function(){
                if(this.thumbnail) {
                    this.thumbnail.hide();
                }
                if(this.videoObject){
                    Volt.log('[detail-view.js] GamesThumbnailView video actor show [when time ready]');
                    this.videoObject.show();
                    Volt.log('~~~~~~~~~~~~~~~~~~ video play - ' + this.videoObject.uri);
                    this.videoObject.play();
                }
                this.videoTimer = null;
            }.bind(this), 10000);
        }
    },
    
    pauseVideoObject : function() {
        if(this.videoObjectComplated) {
            Volt.log("[detail-view.js] GamesThumbnailView video has complated or no longer continue, don't need pause");
        } else {
            if(this.thumbnail) {
                this.thumbnail.show();
            }
            if(this.videoObject){
                Volt.log('[detail-view.js] GamesThumbnailView video actor hide [when pause]');
                this.videoObject.hide();
                if(this.videoTimer) {
                    Volt.log('[detail-view.js] GamesThumbnailView clearTimeout about video actor [when pause]');
                    Volt.clearTimeout(this.videoTimer);
                    this.videoTimer = null;
                } else {
                    Volt.log('[detail-view.js] GamesThumbnailView video actor pause [when pause]');
                    this.videoObject.pause();
                }
            }
        }
    },
    
    resumeVideoObject : function() {
        if(this.videoObjectComplated) {
            Volt.log("[detail-view.js] GamesThumbnailView video has complated or no longer continue, don't need resume");
        } else {
            if(this.thumbnail) {
                this.thumbnail.hide();
            }
            if(this.videoObject){
                Volt.log('[detail-view.js] GamesThumbnailView video actor show and play [when resume]');
                this.videoObject.show();
                this.videoObject.play();
            } else {
                if(this.thumbnail) {
                    Volt.log("~~~~~~~~~~~~~~~~~~ play video after 10sec [when resume]");
                    var renderer = this.widget.renderer(0, 0);
                    this.createVideoObject(renderer);
                }
            }
        }
    },
    
    destroyVideoObject : function(){
        if(this.thumbnail) {
            this.thumbnail.show();
        }
        if(this.videoObject){
            if(!this.videoObjectComplated) {
                Volt.log('[detail-view.js] GamesThumbnailView video actor hide [when destroy]');
                this.videoObject.hide();
                
                if(this.videoTimer) {
                    Volt.log('[detail-view.js] GamesThumbnailView clearTimeout about video actor [when destroy]');
                    Volt.clearTimeout(this.videoTimer);
                    this.videoTimer = null;
                } else {
                    Volt.log('[detail-view.js] GamesThumbnailView video actor stop [when destroy]');
                    this.videoObject.stop();
                }
            }
            
            if(this.videoActorListener) {
                Volt.log('[detail-view.js] GamesThumbnailView remove videoActorListener [when destroy]');
                this.videoObject.removeListener(this.videoActorListener);
                this.videoActorListener = null;
            }
            Volt.log('[detail-view.js] GamesThumbnailView destroy video actor [when destroy]');
            this.videoObject.destroy();
            this.videoObject = null;
        }
        this.videoObjectComplated = true;
    },

	events : {
		NAV_FOCUS  : 'onFocus',
		NAV_BLUR   : 'onBlur'
	},

    onSelect: function() {
        Volt.log('[detail-view.js] GamesThumbnailView.onSelect');

        addEventLog('VIDEOS', {
            cp : 'G08_DETAIL',
            appid : DetailModel.get('app_id'),
            sp : 'DV000',
            content : 'video' + '|' + DetailModel.get('trailer_id_kpi'),
            player : 'native',
            inputby : '',
        });
        var videoFilePath = DetailModel.get('trailer_id');
        Volt.log('[detail-view.js] GamesThumbnailView.onSelect videoFilePath = ' + videoFilePath);
        if (videoFilePath && videoFilePath.length > 0) {
            ThumbnailVideoPlayer();
        } else {
            //no videoFilePath,nothing to do
        }
    },

	onFocus : function(widget) {
		Volt.log('[detail-view.js] GamesThumbnailView.onFocus');
		VoiceGuide.getVoiceGuide(Volt.i18n.t('COM_SID_VIDEOS'));
		if(!widget) {
		    widget = this.widget;
		}
		lastFocus = widget;
		widget.onFocus();
	},

	onBlur : function(widget) {
		Volt.log('[detail-view.js] GamesThumbnailView.onBlur');
		if(!widget) {
            widget = this.widget;
        }
		widget.onBlur();
	},
    
	destroy : function(widget){
		Volt.log('[detail-view.js] GamesThumbnailView destroy');
		this.thumbnail = null;
		this.destroyVideoObject();
//		delete this.timer ;
//		delete this.videoWidget;
		if (!this.widget)
			return;
		this.widget.destroy();
        this.widget = null;
	},
});

var GamesInfoView = PanelCommon.BaseView.extend({

	initialize: function() {
		infoView = this;
    },
    
	render : function(parent) {
		Volt.log('[detail-view.js] GamesInfoView.render');
        var ratingValue = '0.0';
        if(DetailModel.get('rating') != 0){
            ratingValue = DetailModel.get('rating');
        }
        Volt.log('rating:::::'+ratingValue);
       
        var gameAgeRating = DetailModel.get('game_age_rating');
        var ageRatingUrl = DetailModel.get('age_rating_url');
        Volt.log("[detail-view.js]******************** game_age_rating = " + gameAgeRating);
        Volt.log("[detail-view.js]******************** age_rating_url = " + ageRatingUrl);
        if(ageRatingUrl != null && ageRatingUrl.indexOf("http") == 0){
            gameAgeRating = "";
        } else {
            ageRatingUrl = "";
        }
        
		var info = {
			genre         : DetailModel.get('genre'),
			rating        : ratingValue,
			price         : DetailModel.get('price'),
			gameAgeRating : gameAgeRating,
			ageRatingUrl  : ageRatingUrl,
			size          : Volt.i18n.t('COM_SID_MIX_MB').replace('<<A>>',DetailModel.get('size')),
			updatedDate   : DetailModel.get('updated_date'),
			version       : DetailModel.get('version'),
			language      : DetailModel.get('language'),
			//developer     : DetailModel.get('developer'),
		};
        
		this.setWidget(PanelCommon.loadTemplate(DetailTemplate.info_area, info, parent));
        
		var genreWgt = this.widget.getDescendant('genre');
		var ratingWgt = this.widget.getDescendant('rating');

		var starList = [];
		this.isHalf = (String(info.rating).indexOf(".") != -1);
		if(this.isHalf){
		    this.isHalf = String(info.rating).substring(String(info.rating).indexOf(".") + 1);
		    Volt.log('rating - ' + info.rating + ' isHalf - ' + this.isHalf);
		}
		this.ratingNum = parseInt(info.rating);
		//GamesInfo.data = gamesCollection.toJSON();
		for (var i = 0; i < 5; ++i) {
			starList[i]    = PanelCommon.loadTemplate(DetailTemplate.star, null, this.widget);
			starList[i].id = 'games_detail_info_star'+i;
			starList[i].y  = scene.height * (0.02963 + 0.008333);
			starList[i].x  = genreWgt.x + genreWgt.width + scene.width * 0.010417 + scene.width * 0.015625 * i;
			starList[i].show();
		}
		this.updateStar();
		ratingWgt.x = starList[4].width + starList[4].x + scene.width * 0.003125;
		addGameController(this.widget);
		Volt.Nav.reload();

		return this;
	},
	
	updateStar : function(){
	    for (var i = 0; i < this.ratingNum; i++) {
            this.widget.getDescendant('games_detail_info_star'+i).src = Volt.BASE_PATH + "images/1080/common/dp_like_star_white_on.png";
        }
        if(this.isHalf != 0) {
            this.widget.getDescendant('games_detail_info_star'+i).src = Volt.BASE_PATH + "images/1080/common/dp_like_star_white_half.png";
            for (var j = this.ratingNum + 1; j < 5; j++) {
                this.widget.getDescendant('games_detail_info_star'+j).src = Volt.BASE_PATH + "images/1080/common/dp_like_star_white_off.png";
            }
        } else {
            for (var j = this.ratingNum; j < 5; j++) {
                this.widget.getDescendant('games_detail_info_star'+j).src =Volt.BASE_PATH + "images/1080/common/dp_like_star_white_off.png";
            }
        }
	},
	destroy : function(widget){
		Volt.log('[detail-view.js] Games GamesInfoView destroy');
		if (!this.widget)
			return;
		
        this.widget.destroyChildren();
		this.widget.destroy();
        this.widget = null;
	},
});

var StorageInfoView = PanelCommon.BaseView.extend({
	StorageProgressbar: null,
    
	initialize: function() {
		storageView = this;
    },
    
    startListening : function(){
        Volt.log("[detail-view.js] StorageInfoView startListening");
        Mediator.on(CommonDefine.Event.UPDATE_STORAGE, storageView.updateStorage, storageView);
    },
    
	render : function(parent) {
		Volt.log('[detail-view.js] StorageInfoView.render');
		this.widget = PanelCommon.loadTemplate(DetailTemplate.storageinfo_area, null, parent);
		this.setWidget(this.widget);
		// var StorageInfoBG = this.widget.getDescendant('storageinfo_area');
		//var  StorageInfo= __initStorageInfo(StorageInfoBG);
        this.StorageProgressbar = CommonContent.createProgressControl(
            this.widget, 
            0, parseInt(scene.height * 0.027778), parseInt(scene.width * 0.144271), parseInt(scene.height * 0.001852));
        this.updateStorage();
		
		Volt.Nav.reload();
		return this;
	},
    
	updateStorage: function() {
		Volt.log('[detail-view.js] updateStorage');
		if(storageView.StorageProgressbar) {
			Volt.log('[detail-view.js] update processbar');
			var width = voltApiWrapper.getStoragePercent() * parseInt(scene.width * 0.144271);
			if(width < 2) {
				width = 2;
			}
			storageView.StorageProgressbar.value = width;
		}
        
		if(storageView.widget) {
			Volt.log('[detail-view.js] update text');
			var obj = voltApiWrapper.getMemoryObject({
			    freeUnit : 'default'
			});
			if(storageView.widget.getDescendant('storage_text')) {
                storageView.widget.getDescendant('storage_text').text = Volt.i18n.t('COM_SID_MEMORY_USE') + "(" + obj.total + obj.totalUnit +")";
            }
            if(storageView.widget.getDescendant('memory_used_text')) {
                storageView.widget.getDescendant('memory_used_text').text = obj.used + obj.usedUnit;
            }
            if(storageView.widget.getDescendant('memory_avaliable_text')) {
                storageView.widget.getDescendant('memory_avaliable_text').text = obj.free + obj.freeUnit;
            }
		}
	},
    
	destroy : function(widget){
		Volt.log('[detail-view.js] Games StorageInfoView destroy');
		if(this.StorageProgressbar) {
            this.StorageProgressbar.destroy();
            this.StorageProgressbar = null;
        }
		if (!this.widget)
			return;
            
		this.widget.destroyChildren();
		this.widget.destroy();
        this.widget = null;
	},
});

var ScreenShotView = PanelCommon.BaseView.extend({
    initialize: function() {
        screenView = this;
    },
    
    render: function(parent) {
        Volt.log('[detail-view.js] ScreenShotView.render');
        this.widget = this.initGrid();
        
        this.widget.color = Volt.hexToRgb('#1f2b3d', 0);
        this.widget.focusable = true;
        this.widget.id = "detail-view-screenshot-list";
        this.widget.useMarginWhenFocusEdgeItem = false;
        this.widget.loopRightFlag = false;
        this.widget.loopLeftFlag = false;
        
        parent.addChild(this.widget);
        this.setWidget(this.widget);
        this.widget.y = descriptionView.widget.y + descriptionView.widget.height;
        this.height = parent.height;
        
        Volt.Nav.reload();
        return this;
    },
    

    initGrid : function(){
        var screenshot_list = DetailModel.get('screenshot_list');
        var data = {
            style : CommonDefine.Const.HALO_ITEM_ALL_SAME,
            groups : [{
                modelArr : screenshot_list
            }]
        };
        var gridView = new Gridlist(GridlistTemplate.detailPageScreenShot, JSON.stringify(data), parseInt(scene.width * 0.140625), parseInt(scene.height * 0.138889));
        gridView.setItemData = function(mustache, modelData){
            mustache.imgUrl = modelData['thumbnail_url'];
            mustache.screenshot = true;
        };
        gridView.setItemTemplate = function(rendererInstance, parentWidth, parentHeight, data) {
            CommonContent.setBlankStyle(rendererInstance, parentWidth, parentHeight);
            var thumbnailObj = rendererInstance.thumbnail;
            thumbnailObj.setContentImage(data.imgUrl);
        };
        gridView.onItemPress = function(itemData,groupIndex, itemIndex){
            Volt.log('ScreenShotView onItemPress' + itemIndex);
			addEventLog('IMAGES',{
				cp : 'G08_DETAIL',
		        appid : DetailModel.get('app_id'),
		        sp : 'DP' + Volt.KPIMapper.getIndexFormat(itemIndex + 1),
		        inputby: '',
			});
            ScreenShotPhotoPlayer(itemIndex);
        };
        
        gridView.moveOut = function(gridList, directionString, fromGroupIndex, fromItemIndex){
            Volt.log('[detail-view.js] ScreenShotView moveOut fromGroupIndex = ' + fromGroupIndex +', fromItemIndex=' + fromItemIndex);
            var realIndex = gridList.getRealIndexInScreenRange(fromGroupIndex, fromItemIndex);
            if ("Up" == directionString) {
                var moreButton = descriptionView.widget.getDescendant('more_button_widget');
                if (moreButton.focusable == true && realIndex > 1) {
                    Volt.Nav.setNextItemRule(gridList, 'up', moreButton);
                } else {
                    var bigThumbnail = thumbnailView.widget.getDescendant('games_detail_big_thumbnail_list');
                    Volt.Nav.setNextItemRule(gridList, 'up', bigThumbnail);
                }
            } else if ("Down" == directionString) {
                if(realIndex == 0){
                    var downloadButton = buttonView.widget.getDescendant('download_button_widget');
                    Volt.Nav.setNextItemRule(gridList, 'down', downloadButton);
                } else if(realIndex == 1){
                    var ratingButton = buttonView.widget.getDescendant('rating_button_widget');
                    Volt.Nav.setNextItemRule(gridList, 'down', ratingButton);
                } else {
                    var controllerButton = buttonView.widget.getDescendant('controller_button_widget');
                    Volt.Nav.setNextItemRule(gridList, 'down', controllerButton);
                }
            }
        };

        gridView.focusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
            Volt.log('[detail-view.js] ScreenShotView focusChanged fromItemIndex = ' + fromItemIndex + ',toItemIndex = ' + toItemIndex + ',,,toGroupIndex = ' + toGroupIndex);
		    if(toItemIndex >= 0 && toGroupIndex >= 0){
                var voiceGuide = '';
                if(-1 == fromItemIndex){
                    
                    voiceGuide += Volt.i18n.t('TV_SID_MIX_LIST').replace('<<A>>',Volt.i18n.t('COM_SID_PHOTO')) + ',';
                    voiceGuide += Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>',screenshot_list.length) + ',';
                }

                voiceGuide += Volt.i18n.t('COM_SID_PHOTO') + ',' + (toItemIndex + 1) + '.'; 
                VoiceGuide.getVoiceGuide(voiceGuide);
            }
        };
        
        gridView.disableLongPress();
        gridView.disableScroll();
        
        return gridView.render().widget;
    },
    
    events :{
        NAV_FOCUS : 'onFocus',
        NAV_BLUR : 'onBlur'
    },
    
    onFocus : function(widget) {
		Volt.log('[detail-view.js] ScreenShotView.onFocus');
        if(!widget) {
            widget = this.widget;
        }

		if(lastFocus == widget) {
			//do noting
		} else if((thumbnailView && lastFocus == thumbnailView.widget.getDescendant('games_detail_big_thumbnail_list')) 
		    || lastFocus == buttonView.widget.getDescendant('download_button_widget')) {
		    var realItem = widget.getRealItemInScreenRange(0);
            widget.setFocusItemIndex(realItem.groupIndex, realItem.itemIndex);
		} else if(lastFocus == buttonView.widget.getDescendant('rating_button_widget')){
		    var realItem = widget.getRealItemInScreenRange(1);
            widget.setFocusItemIndex(realItem.groupIndex, realItem.itemIndex);
		} else if(lastFocus == descriptionView.widget.getDescendant('more_button_widget')){
            var realItem = widget.getRealItemInScreenRange(3);
            if(realItem.groupIndex === undefined) {
                realItem = widget.getRealItemInScreenRange(2);
            }
            widget.setFocusItemIndex(realItem.groupIndex, realItem.itemIndex);
        } else {
		    var realItem = widget.getRealItemInScreenRange(2);
            widget.setFocusItemIndex(realItem.groupIndex, realItem.itemIndex);
        } 
		lastFocus = widget;
		widget.onFocus(false);
	},
    
    onBlur : function(widget) {
		Volt.log('[detail-view.js] ScreenShotView.onBlur');
        if(!widget) {
            widget = this.widget;
        }
		widget.onBlur();
	},
    
	destroy : function(widget){
		Volt.log('[detail-view.js] Games ScreenShotView destroy');
		if (!this.widget)
			return;
		this.widget.destroy();
		this.widget = null;
	},
});

var GamesButtonView = PanelCommon.BaseView.extend({
	RatingStarsList : [],
	DownloadProgressbar: null,
	downloadingFlag:false, /*if the downloading is processing or not*/
	firstFocusDwnBut : true,
	isStorageEnough : true,
	isUSBStorageEnough : false,
	isConnectUSB : false,
	isWidgetInstalled : false,
	isWidgetInstalledInUSB : false,
	btnListener : new ButtonListener(),

	initialize : function() {
		buttonView = this;
		this.btnListener.onButtonClicked = function(button, type) {
			switch(button.id) {
				case 'downloadBtn':
				    if(CommonContent.isClickable(button.id)) {
				        buttonView.onSelect_download_button();
				    }
					break;
				case 'shareBtn':
				    if(CommonContent.isClickable(button.id)) {
				        buttonView.onSelect_share_button();
				    }
					break;
				case 'controllerBtn':
				    if(CommonContent.isClickable(button.id)) {
				        buttonView.onSelect_controller_button();
				    }
					break;
				case 'ratingBtn':
				    if(CommonContent.isClickable(button.id)) {
				        buttonView.onSelect_rating_button();
                    }
					break;
				default :
					break;
			}
		};
        this.isStorageEnough = voltApiWrapper.IsStorageEnough(DetailModel.get('size'));
        this.isWidgetInstalled = voltApiWrapper.isWidgetInstalled(DetailModel.get('app_id'));
        this.isWidgetInstalledInUSB = voltApiWrapper.isWidgetInstalledInUSB(DetailModel.get('app_id'));
	},
	
    startListening : function(){
        Volt.log("[detail-view.js] GamesButtonView startListening");
        Mediator.on(CommonDefine.Event.BEGIN_DOWNLOAD, function(eventInfo){
            buttonView.startDownloadListening();
            buttonView.beginDownload(eventInfo);
        }, buttonView);
        Mediator.on(CommonDefine.Event.MY_RATING, buttonView.updateRating, buttonView);
        Mediator.on(CommonDefine.Event.CLOSE_RATING_POPUP, CommonContent.destroyRatingPopup, buttonView);
        Mediator.on(CommonDefine.Event.INSTALL_FAIL_APPSYNC_NOT_COMPLETE, CommonContent.showAppSyncError, buttonView);
        Mediator.on(CommonDefine.Event.INSTALL_FAIL, CommonContent.installFail, buttonView);
    },
	
	startDownloadListening : function() {
	    if(!buttonView.downloadListening) {
	        buttonView.downloadListening = true;
	        Volt.log("[detail-view.js] GamesButtonView startDownloadListening");
	        Mediator.on(CommonDefine.Event.DOWNLOAD_PROGRESS, buttonView.updateProgressBar, buttonView);
	        Mediator.on(CommonDefine.Event.INSTALL, function(eventInfo){
	            buttonView.stopDownloadListening();
	            buttonView.installCompleted(eventInfo);
	        }, buttonView);
	        Mediator.on(CommonDefine.Event.DOWNLOAD_CANCELED, function(){
	            buttonView.stopDownloadListening();
	            buttonView.CancelDownload();
	        }, buttonView);
	    }
	},
	
	stopDownloadListening : function() {
	    Volt.log("[detail-view.js] GamesButtonView stopDownloadListening");
	    buttonView.downloadListening = false;
        Mediator.off(CommonDefine.Event.DOWNLOAD_PROGRESS, null, buttonView);
        Mediator.off(CommonDefine.Event.INSTALL, null, buttonView);
        Mediator.off(CommonDefine.Event.DOWNLOAD_CANCELED, null, buttonView);
    },

	render : function(parent) {
		Volt.log('GamesButtonView.render');
		this.parent = parent;
		this.setWidget(PanelCommon.loadTemplate(DetailTemplate.button_area, null, parent));
		this.widget.y = screenView.widget.y + screenView.height;
		this.renderDownloadButton();
		//this.renderShareButton();
		this.renderRatingButton();
		this.renderControllerButton();
        
		//Those Event don't need off when deactive
		if(!buttonView.isWidgetInstalled || buttonView.isWidgetInstalledInUSB){
            Mediator.on(CommonDefine.Event.MEMORY_APP_CHANGE, buttonView.memoryAppChange, buttonView);
            Mediator.on(CommonDefine.Event.CONNECT_USB, buttonView.connectUSBFirst, buttonView);
            Mediator.on(CommonDefine.Event.DISCONNECT_USB, buttonView.disconnectUSBFirst, buttonView);
        }
		Volt.Nav.reload();
		return this;
	},
	
	renderDownloadButton : function() {
	    Volt.log('DownloadButton.render');
		var downloadBtnBG = this.widget.getChild('download_button_widget');
		var btnStyle = {
			style : CommonDefine.Winset.BUTTON_IMAGE_O_STYLE_F_FOCUS1,
			buttonType : CommonDefine.Winset.BUTTON_TEXT,
		};
		downloadBtn = PanelCommon.loadTemplate(DetailTemplate.downloadBtn, btnStyle, downloadBtnBG);
//		downloadBtn.setTextColor({
//            state : "disabled-focused",
//            color : {
//                r : 70,
//                g : 70,
//                b : 70,
//                a : 102
//            }
//        });
//        downloadBtn.setBackgroundColor({
//            state : "disabled-focused",
//            color : {
//                r : 255,
//                g : 255,
//                b : 255,
//                a : 97
//            }
//        });
//        downloadBtn.setFontSize({
//            state: "disabled-focused",
//            size: 32,
//        });
		downloadBtn.addListener(this.btnListener);
		downloadBtn.show();
		this.InitDownloadBtn();
    }, 
        
    renderShareButton: function(){
		Volt.log('ShareButton.render');
        var shareBtnBG = this.widget.getChild('share_button_widget');
		var btnStyle = {
			style : CommonDefine.Winset.BUTTON_IMAGE_O_STYLE_F_FOCUS1,
			buttonType : CommonDefine.Winset.BUTTON_ICON,
		};
		shareBtn = PanelCommon.loadTemplate(DetailTemplate.shareBtn, btnStyle, shareBtnBG);
		shareBtn.addListener(this.btnListener);
        shareBtn.show();
    },
    
    renderControllerButton: function(){
		Volt.log('ControllerButton.render');
        var controllerBtnBG = this.widget.getChild('controller_button_widget');
		var btnStyle = {
			style : CommonDefine.Winset.BUTTON_IMAGE_O_STYLE_F_FOCUS1,
			buttonType : CommonDefine.Winset.BUTTON_ICON,
		};
		controllerBtn = PanelCommon.loadTemplate(DetailTemplate.controllerBtn, btnStyle, controllerBtnBG);
		controllerBtn.setIconAlpha({
				state: "normal",
				alpha: 242
			});
		controllerBtn.setIconImage({
	        state: "focused",
	        src: Volt.getRemoteUrl("images/1080/g_detail_icon_control_b.png")
	    });
	    controllerBtn.setIconImage({
	        state: "focused-roll-over",
	        src: Volt.getRemoteUrl("images/1080/g_detail_icon_control_b.png")
	    });
		controllerBtn.addListener(this.btnListener);
		controllerBtn.show();
	},

	renderRatingButton : function() {
		Volt.log('RatingButton.render');
		var ratingBtnBG = this.widget.getChild('rating_button_widget');
		var btnStyle = {
			style : CommonDefine.Winset.BUTTON_IMAGE_O_STYLE_F_FOCUS1,
			buttonType : CommonDefine.Winset.BUTTON_TEXT,
		};
		ratingBtn = PanelCommon.loadTemplate(DetailTemplate.ratingBtn, btnStyle, ratingBtnBG);
		ratingBtn.addListener(this.btnListener);
		var my_rating = parseInt(DetailModel.get('my_rating'));
		for (var i = 0; i < my_rating; i++) {
			var ratingBtnOnStarImg = new ImageWidgetEx({
				width : 32,
				height : 32,
				x : (scene.width * (0.161458 - 0.01875 * 4) - 32) / 2 + scene.width * 0.01875 * i,
				y : (scene.height * 0.060185 - 32)/2
			});
			ratingBtnOnStarImg.src = Volt.BASE_PATH + "images/1080/btn_icon_like_star_on.png";
			this.RatingStarsList[i] = ratingBtnOnStarImg;
			ratingBtnOnStarImg.parent = ratingBtn;
		}

		for (var j = my_rating; j < 5; j++) {
			var ratingBtnOffStarImg = new ImageWidgetEx({
				width : 32,
				height : 32,
				x : (scene.width * (0.161458 - 0.01875 * 4) - 32) / 2 + scene.width * 0.01875 * j,
				y : (scene.height * 0.060185 - 32)/2
			});
			ratingBtnOffStarImg.src = Volt.BASE_PATH + "images/1080/btn_icon_like_star_off.png";
			this.RatingStarsList[j] = ratingBtnOffStarImg;
			ratingBtnOffStarImg.parent = ratingBtn;
		}
		ratingBtn.show();
	},

	updateRating : function(){
        var my_rating = parseInt(DetailModel.get('my_rating'));
        Volt.log("[detail-view.js]my_rating = " + my_rating);

        for( var i = 0; i < my_rating; i++){
            buttonView.RatingStarsList[i].src = Volt.BASE_PATH + "images/1080/btn_icon_like_star_on_f.png";
        }
        for( var j = my_rating; j < 5; j++){
            buttonView.RatingStarsList[j].src = Volt.BASE_PATH + "images/1080/btn_icon_like_star_off_f.png";
        }
    },
	
	InitDownloadBtn: function() {
		Volt.log('[detail-view.js] InitDownloadBtn');
		this.downloadable = DetailModel.get('downloadable');
		if (voltApiWrapper.isWidgetInstalling(DetailModel.get('app_id'))) {
		    buttonView.startDownloadListening();
		    buttonView.changeDownloadBtnCancel();
			var Obj = voltApiWrapper.getWidgetInstallStatus(DetailModel.get('app_id'));
			if (Obj != undefined) {
				Volt.log('[detail-view.js] InitDownloadBtn status:' + Obj.status + " " + Obj.progress);
				if(Obj.status == 'downloading') {	
					this.updateDownloadProgress(Obj.progress);
				} else {
					this.updateDownloadProgress(100);
				}
			}
			Volt.log('[detail-view.js] InitDownloadBtn Installing Status = ' + Obj);
		} else if(buttonView.isWidgetInstalled) {
			Volt.log('[detail-view.js] InitDownloadBtn to Play');
			buttonView.changeDownloadBtnPlay();
			Volt.log('[detail-view.js] InitDownloadBtn Installed');
		} else {
		    this.InitMemoryLowDownloadBtn();
		    this.updateMemoryLowWarning();
		}
	},
	
	changeDownloadBtnCancel : function() {
	    buttonView.createProcessBar();
	    downloadBtn.setText({
            state : "all",
            text : Volt.i18n.t('COM_SID_CANCEL')
        });
        downloadBtn.show();
        buttonView.downloadingFlag= true;
        buttonView.updateMemoryLowWarning();
	},
	
	changeDownloadBtnPlay : function(obj) {
	    downloadBtn.setText({
            state : "all",
            text : Volt.i18n.t('COM_SID_PLAY_KR_RUN')
        });
        downloadBtn.show();
        buttonView.downloadingFlag= false;
        if(!obj || obj.needResetSize !== false) {
            DetailModel.set('size', DetailModel.get('install_size'));
            buttonView.isStorageEnough = true;
            if(infoView) {
                updateInfoSize(infoView.widget, true);
            }
        }
        if(!obj || obj.needResetButtonStatus !== false){
            downloadBtn.enable(true);
            downloadBtn.canBeEnable = true;
        }
        if(!obj || obj.needUpdateWarning !== false){
            buttonView.updateMemoryLowWarning();
        }
	},
	
	changeDownloadBtnDownload : function(obj) {
	    downloadBtn.setText({
            state : "all",
            text : Volt.i18n.t('COM_SID_DOWNLOAD')
        });
        downloadBtn.show();
        buttonView.downloadingFlag= false;
        if(!obj || obj.needResetSize !== false) {
            DetailModel.set('size', DetailModel.get('total_size'));
            buttonView.isStorageEnough = voltApiWrapper.IsStorageEnough(DetailModel.get('size'));
            if(infoView) {
                updateInfoSize(infoView.widget, true);
            }
        }
        if(!obj || obj.needUpdateWarning !== false){
            buttonView.updateMemoryLowWarning();
        }
	},
	
	InitMemoryLowDownloadBtn : function(){
	    if(this.downloadable == 'N') {
	        Volt.log('[detail-view.js] downloadable is N!!!!!');
            downloadBtn.enable(false);
            downloadBtn.canBeEnable = false;
	        return;
	    }
	    if(!buttonView.isStorageEnough){
	        buttonView.isUSBStorageEnough = false;
	        var UsbStorages = voltApiWrapper.getUsbStorages();
            if(UsbStorages && UsbStorages.storages.length >= 1) {
                var appSize = DetailModel.get('size');
                buttonView.isConnectUSB = true;
                for(var i = 0; i < UsbStorages.storages.length; i++){
                    Volt.log('parseFloat(appSize) - ' + parseFloat(appSize));
                    var tempAvailable = voltApiWrapper.setSuitablyUnit(UsbStorages.storages[i].availableSize);
                    Volt.log('availableSize - ' + UsbStorages.storages[i].availableSize);
                    Volt.log('availableSize - ' + JSON.stringify(tempAvailable));
                    if(tempAvailable.unit == 'GB' || (tempAvailable.unit == 'MB' && parseFloat(appSize) <= tempAvailable.size)) {
                        buttonView.isUSBStorageEnough = true;
                        break;
                    }
                }
            } else {
                buttonView.isConnectUSB = false;
            }
            if(buttonView.isConnectUSB && buttonView.isUSBStorageEnough){
                Volt.log('[detail-view.js] InitMemoryLowDownloadBtn ----------------------> USB Storage Enough');
                downloadBtn.enable(true);
                downloadBtn.canBeEnable = true;
            }else{
                Volt.log('[detail-view.js] InitMemoryLowDownloadBtn ----------------------> Storage Not Enough');
                downloadBtn.enable(false);
                downloadBtn.canBeEnable = false;
            }
        } else {
            Volt.log('[detail-view.js] InitMemoryLowDownloadBtn ----------------------> Storage Enough');
            downloadBtn.enable(true);
            downloadBtn.canBeEnable = true;
        }
	},
	
	memoryAppChange : function() {
	    Volt.log('[detail-view.js] memoryAppChange - ' + buttonView.lastUSBStatus);
	    buttonView.isWidgetInstalled = voltApiWrapper.isWidgetInstalled(DetailModel.get('app_id'));
	    if(buttonView.lastUSBStatus == 'connect') {
            buttonView.connectUSBSecond();
	    } else if(buttonView.lastUSBStatus == 'disconnect'){
            buttonView.disconnectUSBSecond();
	    } 
//	    else {
//	        buttonView.lastUSBStatus = 'memoryAppChange';
//	    }
	    buttonView.lastUSBStatus = '';
	},
	
	connectUSBFirst : function(data){
        Volt.log('[detail-view.js] connectUSBFirst - ' + data);
        if (buttonView.isWidgetInstalled){
//            if(buttonView.lastUSBStatus == 'memoryAppChange') { // for sometimes memoryAppChange received before connectUSB
//                buttonView.changeDownloadBtnPlay();
//                buttonView.InitMemoryLowDownloadBtn();
//            } else {
             // do noting
//            }
        } else if (voltApiWrapper.isWidgetInstalling(DetailModel.get('app_id'))) {
            // do noting
        } else {
            buttonView.lastUSBStatus = 'connect';
            buttonView.InitMemoryLowDownloadBtn();
        }
        buttonView.updateMemoryLowWarning();
    },
    
    connectUSBSecond : function(){
        Volt.log("[detail-view.js] connectUSBSecond isWidgetInstalled = " + buttonView.isWidgetInstalled);
        if(buttonView.isWidgetInstalled) {
            buttonView.changeDownloadBtnPlay();
        } else {
            buttonView.InitMemoryLowDownloadBtn();
            buttonView.updateMemoryLowWarning();
        }
    },
    
    disconnectUSBFirst : function(data){
        Volt.log('[detail-view.js] disconnectUSBFirst - ' + data);
        var lastDisconnetUSBPath = undefined;
        try{
            lastDisconnetUSBPath = CommonContent.getStoragePath(data[0].storage.mountPath);
            Volt.log('[detail-view.js] disconnectUSB usbMountPath = ' + lastDisconnetUSBPath);
        } catch(e){
            Volt.log('[detail-view.js] disconnectUSB usbMountPath error = ' + e);
        }
        
        if(voltApiWrapper.isWidgetInstalling(DetailModel.get('app_id'))){
            if(Volt.gamesInstallAppPath === lastDisconnetUSBPath) {
                buttonView.lastUSBStatus = 'disconnect';
                voltApiWrapper.cancelInstallApp(DetailModel.get('app_id'));
                Mediator.trigger(CommonDefine.Event.DOWNLOAD_CANCELED);
            } else {
                //do noting
            }
        } else {
            buttonView.lastUSBStatus = 'disconnect';
            if(buttonView.isWidgetInstalled) {
              //do noting
            } else {
                buttonView.changeDownloadBtnDownload({needUpdateWarning : false});
                buttonView.InitMemoryLowDownloadBtn();
            }
        }
        buttonView.updateMemoryLowWarning();
    },
	
	disconnectUSBSecond : function(){
	    Volt.log("[detail-view.js] disconnectUSBSecond isWidgetInstalled = " + buttonView.isWidgetInstalled);
	    if(buttonView.isWidgetInstalled) {
            // do noting
        } else {
            buttonView.changeDownloadBtnDownload();
            buttonView.InitMemoryLowDownloadBtn();
        }
    },
	
    updateProgressBar: function(eventInfo) {
		if(downloadBtn) {
			Volt.log("[detail-view.js] updateProgressBar");
			if(eventInfo != undefined) {
				Volt.log("[detail-view.js] " + eventInfo.app_id + " " + eventInfo.result);
				var appid = eventInfo.app_id;
				var downloadResult = eventInfo.result;
				if(appid === DetailModel.get('app_id') && downloadResult !=  undefined) {
					if (eventInfo.result <= 100) {
						if (!buttonView.DownloadProgressbar) {
							buttonView.changeDownloadBtnCancel();
							//voltApiWrapper.addInstallList(appid);
						}
						buttonView.updateDownloadProgress(eventInfo.result);
					}
				}
			}
		}
	},
 
	beginDownload: function(eventInfo) {
		Volt.log("[detail-view.js] showDownloadBar");
		if(eventInfo != undefined){
			Volt.log("[detail-view.js] beginDownload:" + JSON.stringify(eventInfo));
			if(eventInfo.app_id === DetailModel.get('app_id')) {
			    buttonView.downloadingFlag= true;
				buttonView.changeDownloadBtnCancel();
			}
		}
	},
    
	CancelDownload:function(){
		Volt.log("[detail-view.js] CancelDownload");
		buttonView.InitMemoryLowDownloadBtn();
		buttonView.changeDownloadBtnDownload();
		buttonView.destroyProcessBar();
	},
	
    createProcessBar: function() {
        if (buttonView.DownloadProgressbar == null) {
            Volt.log("[detail-view.js] createProcessBar buttonView.widget =" + buttonView.widget);
            Volt.log("[detail-view.js] createProcessBar this.widget =" + this.widget);
            buttonView.DownloadProgressbar = CommonFucntion.createProgressControl(buttonView.widget.getDescendant('download_button_progressbar'), 0, 0, parseInt(scene.width * 0.161458), parseInt(scene.height * 0.001852));
        }
    },

	destroyProcessBar: function() {
		if(this.DownloadProgressbar) {
			this.DownloadProgressbar.destroy();
			this.downloadingFlag= false;
			this.DownloadProgressbar = null;
		}
	},
	
	updateMemoryLowWarning: function(){
	    var WarningText = buttonView.widget.getDescendant('memory_running_low_text');
	    if(buttonView.downloadable == 'N') {
//            if(buttonView.isWidgetInstalled) {
//                WarningText.text = "";
//            } else {
//                WarningText.text = "Download button is dimmed";
//            }
            WarningText.text = "";
        } else if(buttonView.isStorageEnough) {
            WarningText.text = "";
        } else if(buttonView.isWidgetInstalled) {
            WarningText.text = "";
        } else if(voltApiWrapper.isWidgetInstalling(DetailModel.get('app_id')) && Volt.gamesInstallAppPath){
            WarningText.text = Volt.i18n.t('TV_SID_NOT_REMOVE_STORAGE_USE');
        } else if(buttonView.isConnectUSB && buttonView.isUSBStorageEnough) {
            WarningText.text = Volt.i18n.t('TV_SID_MIX_INTERNAL_MEMORY_LOW_ATTACHED').replace('<<A>>',Volt.i18n.t('COM_SID_GAME'));
        } else if(buttonView.isConnectUSB){
            WarningText.text = Volt.i18n.t('TV_SID_MIX_INTERNAL_MEMORY_LOW_ANOTHER_DEVICE_ATTACHED').replace('<<A>>',Volt.i18n.t('COM_SID_GAME'));
        } else {
            WarningText.text = Volt.i18n.t('TV_SID_MIX_INTERNAL_MEMORY_LOW_USB_ATTACHED').replace('<<A>>',Volt.i18n.t('COM_SID_GAME'));
        }
	    Volt.log("[detail-view.js] Update MemoryLowWarning: " + WarningText.text);
	},
    
	updateDownloadProgress:function(percent){
		//Volt.log("EVENT_MAIN_UPDATE_DOWNLOAD_PROGRESS:"+width);
		if(this.DownloadProgressbar)
		{
			this.DownloadProgressbar.value = percent * this.DownloadProgressbar.width / 100 ;
		}
		//this.DownloadProgressbar.show();
	},
    
	installCompleted:function(eventInfo){
		if(eventInfo.app_id === DetailModel.get('app_id') && eventInfo.result !=  undefined) {
			Volt.log("[detail-view.js] installCompleted, downloadBtn :::"+downloadBtn);
			buttonView.isWidgetInstalled = voltApiWrapper.isWidgetInstalled(DetailModel.get('app_id'));
			buttonView.changeDownloadBtnPlay();
			buttonView.destroyProcessBar();
			Mediator.trigger(CommonDefine.Event.UPDATE_STORAGE);
            var isUSB = buttonView.isWidgetInstalledInUSB == true ? 'usb' : 'tv';
			addEventLog('DWFIN',{cp : 'G08_DETAIL',target : isUSB,});
        }
	},
    
	events : {
		'NAV_FOCUS  #download_button_widget' : 'onFocus_download_button',
        'NAV_FOCUS  #share_button_widget'    : 'onFocus_share_button',
        'NAV_FOCUS  #rating_button_widget'   : 'onFocus_rating_button',
		'NAV_FOCUS  #controller_button_widget'   : 'onFocus_controller_button',
		'NAV_BLUR   #download_button_widget' : 'onBlur_download_button',
		'NAV_BLUR   #share_button_widget'    : 'onBlur_share_button',
		'NAV_BLUR   #rating_button_widget'   : 'onBlur_rating_button',
		'NAV_BLUR   #controller_button_widget'   : 'onBlur_controller_button',
	},
    
	onFocus_download_button : function(widget) {
		Volt.log('[detail-view.js] GamesButtonView.onFocus_download_button downloadBtn.text() = ' + downloadBtn.text());
		var voiceGuide = '';
		if(this.firstFocusDwnBut){
			voiceGuide += DetailModel.get('game_title') + ',';
		}
		
		voiceGuide += downloadBtn.text() + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
		this.firstFocusDwnBut = false;
		
		VoiceGuide.getVoiceGuide(voiceGuide);
		
		downloadBtn.setFocus();
		lastFocus = this.widget.getDescendant('download_button_widget');
	},
    
	onFocus_share_button : function(widget) {
		Volt.log('[detail-view.js] GamesButtonView.onFocus_share_button');
        var voiceGuide = 'Share,' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
		VoiceGuide.getVoiceGuide(voiceGuide);
		
		shareBtn.setFocus();
		var AbsolutePosition = shareBtn.getAbsolutePosition();
		var opt = {
			text: Volt.i18n.t('UID_SHARE_ON_FACEBOOK'),
			x: AbsolutePosition.x,
			y: AbsolutePosition.y,
			height: shareBtn.height,
			width: shareBtn.width,
			direction:'up',
			parent:this.widget.getDescendant('share_button_widget'),
		};
		
		CommonContent.showToolTip(opt,DetailTemplate);
		lastFocus = this.widget.getDescendant('share_button_widget');
	},
    
	onFocus_rating_button : function(widget) {
		Volt.log('[detail-view.js] GamesButtonView.onFocus_rating_button');
        var voiceGuide = Volt.i18n.t('UID_RATE') + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
		VoiceGuide.getVoiceGuide(voiceGuide);
		var tmpSrc = null;
		for(var i=0;i<buttonView.RatingStarsList.length;++i){
		    tmpSrc = buttonView.RatingStarsList[i].src.split(".");
		    tmpSrc[0]+="_f";
		    buttonView.RatingStarsList[i].src = tmpSrc.join(".");
		}
		
		ratingBtn.setFocus();

		var AbsolutePosition = ratingBtn.getAbsolutePosition();
		var opt = {
			text: Volt.i18n.t('UID_RATE'),
			x: AbsolutePosition.x,
			y: AbsolutePosition.y,
			height: ratingBtn.height,
			width: ratingBtn.width,
			direction:'up',
			parent:this.widget.getDescendant('rating_button_widget'),
		};
		
		CommonContent.showToolTip(opt,DetailTemplate);
		
		lastFocus = this.widget.getDescendant('rating_button_widget');
	},
	onFocus_controller_button : function(widget) {
		Volt.log('[detail-view.js] GamesButtonView.onFocus_controller_button');
		var voiceGuide = Volt.i18n.t('COM_SID_GAME_CONTROLLER_GUIDE') + ',' 
            + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
		VoiceGuide.getVoiceGuide(voiceGuide);
		
		controllerBtn.setFocus();
		var AbsolutePosition = controllerBtn.getAbsolutePosition();
		var opt = {
			text: Volt.i18n.t('COM_SID_GAME_CONTROLLER_GUIDE'),
			x: AbsolutePosition.x,
			y: AbsolutePosition.y,
			height: controllerBtn.height,
			width: controllerBtn.width,
			direction:'up',
			parent:this.widget.getDescendant('controller_button_widget'),
		};
		
		CommonContent.showToolTip(opt,DetailTemplate);
		lastFocus = this.widget.getDescendant('controller_button_widget');
	},
    
	onBlur_download_button : function(widget) {
		Volt.log('[detail-view.js] onBlur_download_button.onBlur');
		
		downloadBtn.killFocus();
	},
    
	onBlur_share_button : function(widget) {
		Volt.log('[detail-view.js] share_button.onBlur');
		
		shareBtn.killFocus();
		CommonContent.hideToolTip();
		Volt.log('[detail-view.js] shareBtn.t_loseFocus');
	},
    
	onBlur_rating_button : function(widget) {
		Volt.log('[detail-view.js] rating_button.onBlur');
		
		var tmpSrc = null;
        for(var i=0;i<buttonView.RatingStarsList.length;++i){
            
            tmpSrc = buttonView.RatingStarsList[i].src.split(".");
            var tmpLength = tmpSrc[0].length;
            tmpSrc[0]=tmpSrc[0].substring(0,tmpLength-2);
            buttonView.RatingStarsList[i].src = tmpSrc.join(".");
        }
        
		ratingBtn.killFocus();
		CommonContent.hideToolTip();
		Volt.log('[detail-view.js] ratingBtn.t_loseFocus');
	},
    
	onBlur_controller_button : function(widget) {
		Volt.log('[detail-view.js] onBlur_controller_button');
		
		controllerBtn.killFocus();
		CommonContent.hideToolTip();
		Volt.log('[detail-view.js] controllerBtn.t_loseFocus');
	},   
    
	//refine by chenry at 2014/07/25 start
	onSelect_download_button : function(widget) {
		Volt.log('[detail-view.js] onSelect_download_button');
		if (!networkStatus.getNetWorkState()) {
			ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR,'','505');
		} else {
			var bIsInstalled = voltApiWrapper.isWidgetInstalled(DetailModel.get('app_id'));
			var eventName = '';
			if (downloadBtn.text() == Volt.i18n.t('COM_SID_PLAY_KR_RUN')) {
			    if(thumbnailView) {
	                thumbnailView.destroyVideoObject();
	            }
			}

			switch(downloadBtn.text()){
				case Volt.i18n.t('COM_SID_PLAY_KR_RUN'):
					eventName = 'PLAYCLICK';
					break;
				case Volt.i18n.t('COM_SID_DOWNLOAD'):
					eventName = 'DWCLICK';
					break;
				case Volt.i18n.t('COM_SID_CANCEL'):
					eventName = 'DWCANCEL';
					break;
				default:
					break;
			}
			
            if(eventName != ''){
				addEventLog(eventName,{
						cp : 'G08_DETAIL',
						appid : DetailModel.get('app_id'),
						inputby:'',
				});
			}
			if (!bIsInstalled || downloadBtn.text() != Volt.i18n.t('COM_SID_PLAY_KR_RUN')) { //the case is when download to internal memory but insert a usb which installed games
				if(!bIsInstalled) {
				    Volt.log('[detail-view.js] this app is not installed');
				} else {
				    Volt.log('[detail-view.js] this app is not installed in internal memory');
				}
				var bIsInstalling = voltApiWrapper.isWidgetInstalling(DetailModel.get('app_id'));
				if (!bIsInstalling) {
					Volt.log('[detail-view.js] this app is not installed, will install it');
					CommonContent.installApp(DetailModel.get('app_id'), DetailModel.get('size'),DetailModel.get('game_title'));
				} else {
					if (downloadBtn.text() == Volt.i18n.t('COM_SID_CANCEL')) {
						Volt.log('[detail-view.js] this app is installing, will cancelInstall it');
						voltApiWrapper.cancelInstallApp(DetailModel.get('app_id'));
						var data = {
		                    app_id : DetailModel.get('app_id'),
						};
						Mediator.trigger(CommonDefine.Event.DOWNLOAD_CANCELED, data);
					}
				}
			} else {
					var Utils = Volt.require('app/common/utils.js');
					var bLogInStatus = Utils.Account.getSignState();
					if (bLogInStatus) {
						Volt.log('[detail-view.js] this app is installed and already login, run it');
						voltApiWrapper.launchApp(DetailModel.get('app_id'), '');
					} else {
						Volt.log('[detail-view.js] this app is installed and not login, pop up login');
						Volt.KPIParams.event = 'JUMPSSO';
						Volt.KPIParams.cp 	 = Volt.KPIMapper.getPageEvent().pageEvent;
						Volt.KPIParams.ssoby = 'game';
						ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_INSTALLED);
					}
			}
			
		}
	},
    
	//refine by chenry at 2014/07/25 end
	onSelect_rating_button : function(widget) {
		Volt.log('[detail-view.js] onSelect_download_button appId: ' + DetailModel.get('app_id'));
		addEventLog('RATINGCLICK',{
				cp : 'G08_DETAIL',
				appid : DetailModel.get('app_id'),
				inputby:'',
		});
        if (!buttonView.isWidgetInstalled) {//Game is installed?
            ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_DLD_BEFORE_RATE);
        } else {
            var params = {
                star_num : DetailModel.get('my_rating'),
                type : 'game-rating',
                app_id : DetailModel.get('app_id')
            };
            Backbone.history.navigate('popup/' + JSON.stringify(params), {
                trigger : true
            });
        }
	},
    
	onSelect_share_button : function(widget) {
		Volt.log('[detail-view.js] onSelect_share_button');
		/*if (!voltApiWrapper.isWidgetInstalled("11091000000")) {//Facebook ID: "11091000000"
            ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_INSTALL_FACEBOOK);
		} else {
			Backbone.history.navigate('popup/share', {
				trigger : true
			});
			popUpView = true;
			
		}*/
	},
    
 	onSelect_controller_button : function(widget) {
		Volt.log('[detail-view.js] onSelect_controller_button');
		addEventLog('GCGUIDECLICK',{
				cp : 'G08_DETAIL',
				appid : DetailModel.get('app_id'),
				inputby:'',
		});
        if(!networkStatus.getNetWorkState()){
            ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR,'','505');
        }
        else{
			Backbone.history.navigate('popup/game-controller-guide-new' , { trigger : true });
        }
	},  
    
	destroy : function(){
		Volt.log('[detail-view.js] ButtonView.destroy');
		buttonView.stopDownloadListening();
		if(this.RatingStarsList) {
		    this.RatingStarsList.length = 0;
		    this.RatingStarsList = null;
		}
		this.destroyProcessBar();
		if(ratingBtn) {
			Volt.log('ratingBtn destroyed');
		    ratingBtn.removeListener(this.btnListener);
		    ratingBtn.destroy();
		    ratingBtn = null;
		}
		if(shareBtn){
			Volt.log('shareBtn destroyed');
		    shareBtn.removeListener(this.btnListener);
		    shareBtn.destroy();
		    shareBtn = null;
		}
		if(downloadBtn){
			Volt.log('downloadBtn destroyed');
			downloadBtn.canBeEnable = null;
		    downloadBtn.removeListener(this.btnListener);
		    downloadBtn.destroy();
		    downloadBtn = null;
        }
		if(controllerBtn){
			Volt.log('controllerBtn destroyed');
		    controllerBtn.removeListener(this.btnListener);
		    controllerBtn.destroy();
		    controllerBtn = null;
        }
		this.btnListener = null;
        this.downloadingFlag = null;
        Mediator.off(CommonDefine.Event.CONNECT_USB,null,buttonView);
        Mediator.off(CommonDefine.Event.DISCONNECT_USB,null,buttonView);
        Mediator.off(CommonDefine.Event.MEMORY_APP_CHANGE, null, buttonView);
        
        this.isStorageEnough = true;
        this.isUSBStorageEnough = false;
        this.isConnectUSB = false;
        this.isWidgetInstalled = false;
        this.isWidgetInstalledInUSB = false;
		if (!this.widget)
			return;
            
		this.widget.destroyChildren();
		this.widget.destroy();
        this.widget = null;
	},
});


var GamesDescriptionView = PanelCommon.BaseView.extend({
	btnListener : new ButtonListener(),

	initialize : function() {
		descriptionView = this;
		this.btnListener.onButtonClicked = function(button, type) {
		    descriptionView.onSelect_more_button();
		};
	},
	
    startListening : function(){
        Volt.log("[detail-view.js] GamesDescriptionView startListening");
        Mediator.on(CommonDefine.Event.EVENT_MORE_DESCRIPTION_CLOSE_CLICKED, descriptionView.clickMoreDescriptionClose, descriptionView);
    },

	render : function(parent, moreInfoParent) {

		this.setWidget(PanelCommon.loadTemplate(DetailTemplate.description_area, null, parent));
		this.widget.y = infoView.widget.y + infoView.widget.height;
		this.renderContent(moreInfoParent);
		return this;
	},

    renderContent: function(moreInfoParent){
//		var decription_text = DetailModel.get('description').replace(/\n\n/g, '');
        var decription_text = DetailModel.get('description');
        var developerText = DetailModel.get('developer');
		var games_descriptionText = this.widget.getChild('games_description_text_content');
		games_descriptionText.text = decription_text + "\n\n" + Volt.i18n.t('COM_SID_DEVELOPER') + ': ' + developerText;
		if (games_descriptionText.height > Math.ceil(scene.height * 0.035185 * 3)) {
			var moreBtnBG = this.widget.getChild('more_button_widget');
			moreBtnBG.focusable = true;
			addGamesDescription(moreBtnBG);
			moreBtn.addListener(descriptionView.btnListener);
			moreInfoParent.hide();
			this.moreView = new GamesMoreInfoView().render(moreInfoParent);
		}
        
		games_descriptionText.ellipsize = true;
		games_descriptionText.height = Math.ceil(scene.height * 0.035185 * 3);
		var lineHeight = games_descriptionText.getLineHeight();
		games_descriptionText.lineSpacing = Math.ceil(scene.height * 0.035185) - lineHeight;
		Volt.log("lineHeight!!!!!!!!!!!!!" + games_descriptionText.getLineHeight());
	},

	events : {
		'NAV_FOCUS  #more_button_widget' : 'onFocus_more_button',
		'NAV_BLUR   #more_button_widget' : 'onBlur_more_button',
	},

	onSelect_more_button : function() {
		Volt.log('[detail-view.js] ButtonView.onSelectMore');
        
        //get detail view widget
        var ancestorWidget = descriptionView.widget.getAncestor('detail-view-bg-area');
		ancestorWidget.getDescendant('detail-view-button-area').hide();
		ancestorWidget.getDescendant('detail-view-storage-area').hide();
		ancestorWidget.getDescendant('detail-view-relate-area').hide();
        ancestorWidget.getDescendant('detail-view-screenshot-area').hide();
		ancestorWidget.getDescendant('detail-view-description-area').hide();
		Mediator.trigger('EVENT_UPDATE_BIG_THUMBNAIL_NEXT_ITEM_RULE', true);
		ancestorWidget.getDescendant('detail-view-moreinfo-area').show();
		Volt.Nav.focus(ancestorWidget.getDescendant('moreinfo_close_button_widget'));
		moreInfoView.isShown = true;
	},

	onFocus_more_button : function(widget) {
		lastFocus = descriptionView.widget.getDescendant('more_button_widget');
        var voiceGuide = Volt.i18n.t('UID_MORE') + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
        VoiceGuide.getVoiceGuide(voiceGuide);
		Volt.log('[detail-view.js] GamesButtonView.onFocus_more_button');
		if(moreBtn) {
		    moreBtn.setFocus();
		}

		var AbsolutePosition = moreBtn.getAbsolutePosition();
		var opt = {
			text: Volt.i18n.t('UID_MORE'),
			x: AbsolutePosition.x,
			y: AbsolutePosition.y,
			height: moreBtn.height,
			width: moreBtn.width,
			direction:'up',
			parent:descriptionView.widget.getDescendant('more_button_widget'),
		};
		
		CommonContent.showToolTip(opt,DetailTemplate);
	},
    
    onBlur_more_button : function(widget) {
		Volt.log('[detail-view.js] share_button.onBlur');
		if(moreBtn) {
		    moreBtn.killFocus();
		}
		
		CommonContent.hideToolTip();
		Volt.log('[detail-view.js] shareBtn.t_loseFocus');
	},
    
	clickMoreDescriptionClose : function() {
        var ancestorWidget = descriptionView.widget.getAncestor('detail-view-bg-area');
		ancestorWidget.getDescendant('detail-view-button-area').show();
		ancestorWidget.getDescendant('detail-view-storage-area').show();
		ancestorWidget.getDescendant('detail-view-relate-area').show();
		//ancestorWidget.getDescendant('detail_relate_video_text').show();
        ancestorWidget.getDescendant('detail-view-screenshot-area').show();
		ancestorWidget.getDescendant('detail-view-description-area').show();
		Mediator.trigger('EVENT_UPDATE_BIG_THUMBNAIL_NEXT_ITEM_RULE', false);
		ancestorWidget.getDescendant('detail-view-moreinfo-area').hide();
//		Volt.Nav.setRoot(ancestorWidget);
//		Volt.Nav.reload();
		Volt.Nav.focus(descriptionView.widget.getDescendant('more_button_widget'));
		moreInfoView.isShown = false;
	},
    
	destroy : function(widget){
	    if(this.moreView) {
	        this.moreView.destroy();
	        this.moreView = null;
	    }
	    Volt.log('[detail-view.js] Games GamesDescriptionView destroy');
		if(moreBtn) {
		    moreBtn.removeListener(this.btnListener);
		    moreBtn.destroy();
		    moreBtn = null;
		    this.btnListener = null;
		}
		if (!this.widget)
			return;
            
		this.widget.destroyChildren();
		this.widget.destroy();
		this.widget = null;
	},
});

var GamesMoreInfoView = PanelCommon.BaseView.extend({
	btnClose : null,
	focusOnClose : true, /***true:focus on closeBTN ; false :focus on big thumbnail ;null :focus on  up/down arrow****/
	games_descriptionText : null,
	btnListener : new ButtonListener(),
	initialize : function() {
	    moreInfoView = this;
		this.btnListener.onButtonClicked = function(button, type) {
		    moreInfoView.onSelect_Close();
		};
	},

	render : function(parent) {
		Volt.log('[detail-view.js] GamesMoreInfoView.render');
		var btnStyle = {
			style : CommonDefine.Winset.BUTTON_IMAGE_O_STYLE_F_FOCUS1,
			buttonType : CommonDefine.Winset.BUTTON_TEXT,
		};
		this.widget = PanelCommon.loadTemplate(DetailTemplate.more_description_area, btnStyle, parent);

		this.renderDescription();
		this.renderArrow();
		this.renderButton();
        
		this.setWidget(this.widget);
		this.isShown = false;
		return this;
	},
	
	renderDescription : function(){
	    var games_more_description_Content = this.widget.getDescendant('games_more_description_text_content');
//        var decription_text = DetailModel.get('description').replace(/\n\n/g, '');
	    var decription_text = DetailModel.get('description');
	    var developerText = DetailModel.get('developer');
	    decription_text = decription_text + "\n\n" + Volt.i18n.t('COM_SID_DEVELOPER') + ': ' + developerText; 
        this.games_descriptionText = new TextWidgetEx({
            x : 0,
            y : 0,
            width :games_more_description_Content.width,
            horizontalAlignment:"left",
            verticalAlignment:"center",
            textColor : Volt.hexToRgb('#FFFFFF',100),
            //justify:true,
            id :'more_info_text',
            font : "SVD Light 30px",
            text : decription_text,
            parent : games_more_description_Content
        });
        
        var lineHeight = this.games_descriptionText.getLineHeight();
        Volt.log("lineHeight!!!!!!!!!!!!!"+lineHeight);
        this.games_descriptionText.lineSpacing = Math.ceil(scene.height * 0.035185) - lineHeight;
        
        this.widget.getDescendant('up_arrow').hide();
        var TextHeight = this.games_descriptionText.height;
        if (this.games_descriptionText.height <= Math.ceil(scene.height * 0.035185 * 13)){
            this.widget.getDescendant('down_arrow').hide();
        } else {
            this.renderScroll(TextHeight);
        }
        Volt.log("TextHeight!!!!!!!!!!!!!!"+TextHeight);
	},
	
	renderArrow : function(){
	    var Arrow_up = this.widget.getDescendant('up_arrow');
        var Arrow_down = this.widget.getDescendant('down_arrow');
        //games_more_description_Content.addEventListener('OnMouseOver', function() {this.focusOnClose=null;}.bind(this));
        Arrow_up.addEventListener('OnMouseClick', function() {
            this.textRollUp();
        }.bind(this));
        
        Arrow_up.addEventListener('OnMouseOver', function() {
            Volt.Nav.blur();
            Arrow_up.opacity =255;
        }.bind(this));
        
        Arrow_up.addEventListener('OnMouseOut', function() {
            //Volt.Nav.focus(lastFocus);
            Arrow_up.opacity = 153;
        }.bind(this));
        
        Arrow_down.addEventListener('OnMouseClick', function() {
            this.textRollDown();
        }.bind(this));
        
        Arrow_down.addEventListener('OnMouseOver', function() {
            Volt.Nav.blur();
            Arrow_down.opacity =255;
        }.bind(this));
        
        Arrow_down.addEventListener('OnMouseOut', function() {
            //Volt.Nav.focus(lastFocus);
            Arrow_down.opacity = 153;
        }.bind(this));
	},
	
	renderButton : function(){
	    this.widget.getDescendant('moreinfo_close_button_widget').onKeyEvent = function(keyCode, keyType){
            if(keyType == Volt.EVENT_KEY_RELEASE){
                return false;
            }
            switch(keyCode){
                case Volt.KEY_JOYSTICK_UP: {
                    Volt.log("@@@UP key");
                    moreInfoView.textRollUp();
                    break;
                }
                case Volt.KEY_JOYSTICK_DOWN: {
                    Volt.log("@@@DOWN key");
                    moreInfoView.textRollDown();
                    break;
                }
//                case Volt.KEY_RETURN: {
//                    Volt.log("@@@Return key");
//                    moreInfoView.onSelect_Close();
//                    break;
//                }
                default:
                    return false;
            }
            return true;
        };
        this.btnClose = this.widget.getDescendant('closeBtn');
        this.btnClose.addListener(this.btnListener);
        
        
     	this.widget.getDescendant('moreinfo_close_button_widget').addEventListener('OnMouseOver', function() {
         	this.btnClose.setFocus();
       	}.bind(this));
	},
	
	renderScroll : function(TextHeight){
	    if(!this.games_moreInfoScroll) {
            Volt.log('[detail-view.js] create a scroll for more info');
            var scrollHeight = Math.ceil(scene.height * 0.035185 * 13);
            var maxValue = Math.ceil(TextHeight / Math.ceil(scene.height * 0.035185 * 13));
            
            var scrollParams = {
            	style :CommonDefine.Winset.SCROLL_VERTICAL,
                parent : this.widget,
                x : 1118 - 5,
                y : 53,
                width : 5,
                height : scrollHeight,
                active : false
            }; 
            this.games_moreInfoScroll = CommonContent.createScroll(scrollParams);
            this.games_moreInfoScroll.hide();
            this.games_moreInfoScroll.lastValue = 1;
            this.games_moreInfoScroll.setMinCurMaxValue(1, this.games_moreInfoScroll.lastValue, maxValue);
        }
	},
    
	events : {
		'NAV_FOCUS #moreinfo_close_button_widget' : 'onFocus_Close',
		'NAV_BLUR #moreinfo_close_button_widget' : 'onBlur_Close',
	},
    
	onSelect_Close : function() {
		Volt.log("detail-view-GamesInfo onSelect_Close");
//		Mediator.off('EVENT_UPDATE_MOREINFOVIEW_COLOR');
		if(moreInfoView.games_moreInfoScroll) {
		    moreInfoView.games_moreInfoScroll.clearTimeOut();
	        moreInfoView.games_moreInfoScroll.hide();
		}
		Mediator.trigger(CommonDefine.Event.EVENT_MORE_DESCRIPTION_CLOSE_CLICKED);
	},

	onFocus_Close : function(widget) {
		Volt.log('[detail-view.js] ~~~~~~~~~~~~~~~~~~onFocus_Close.onFocus');
		lastFocus = this.widget.getDescendant('moreinfo_close_button_widget');
        var voiceGuide = DetailModel.get('description') + ',' + lastFocus.getChild(0).text() 
            + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
        VoiceGuide.getVoiceGuide(voiceGuide);
		if(this.btnClose){
		    this.btnClose.setFocus();
		}
		this.focusOnClose = true;
	},

	onBlur_Close : function(widget) {
		Volt.log('[detail-view.js] ````````````````onBlur_Close.onBlur');
		if(this.btnClose){
		    this.btnClose.killFocus();
		}
		this.focusOnClose=false;
	},
    
	textRollDown : function() {
		Volt.log("detail-view-GamesInfo textRollDown");
		if (this.games_descriptionText.y + this.games_descriptionText.height > Math.ceil(scene.height * 0.035185 * 13) ){
			this.games_descriptionText.y -= Math.ceil(scene.height * 0.035185 * 13);
			this.widget.getDescendant('up_arrow').show();
			if(this.games_moreInfoScroll) {
			    this.games_moreInfoScroll.setTimerOut();
			    this.games_moreInfoScroll.lastValue = this.games_moreInfoScroll.value + 1;
			    this.games_moreInfoScroll.value = this.games_moreInfoScroll.lastValue;
			}
		}
        
		if (this.games_descriptionText.y + this.games_descriptionText.height <=Math.ceil(scene.height * 0.035185 * 13) ){
			if (this.widget.getDescendant('down_arrow').opacity == 255)
			{
				this.widget.getDescendant('up_arrow').opacity =255;
			}
			this.widget.getDescendant('down_arrow').hide();
			Volt.Nav.focus(lastFocus);
		}
	},
    
	textRollUp : function() {
		Volt.log("detail-view-GamesInfo textRollUp");
		if (this.games_descriptionText.y < 0){
			this.games_descriptionText.y += Math.ceil(scene.height * 0.035185 * 13);
			this.widget.getDescendant('down_arrow').show();
			if(this.games_moreInfoScroll) {
                this.games_moreInfoScroll.setTimerOut();
			    this.games_moreInfoScroll.lastValue = this.games_moreInfoScroll.value - 1;
                this.games_moreInfoScroll.value = this.games_moreInfoScroll.lastValue;
            }
		}
        
		if (this.games_descriptionText.y >= 0){
			if (this.widget.getDescendant('up_arrow').opacity == 255){
				this.widget.getDescendant('down_arrow').opacity =255;
			}
			this.widget.getDescendant('up_arrow').hide();
			Volt.Nav.focus(lastFocus);
		}
	},
    
	destroy : function() {
	    Volt.log('[detail-view.js] Games MoreInfo View destroy');
		if (!moreInfoView.widget)
			return;
		if(moreInfoView.btnClose){
		    moreInfoView.btnClose.removeListener(moreInfoView.btnListener);
		    moreInfoView.btnClose.destroy();
		    moreInfoView.btnClose = null;
		    moreInfoView.btnListener = null;
		}
		moreInfoView.focusOnClose = null;
		if(moreInfoView.games_descriptionText){
		    moreInfoView.games_descriptionText.destroy();
		    moreInfoView.games_descriptionText = null;
		}
		if(moreInfoView.games_moreInfoScroll){
		    moreInfoView.games_moreInfoScroll.clearTimeOut();
		    moreInfoView.games_moreInfoScroll = null;
		}
		
		var nChildLength = moreInfoView.widget.getChildCount();
		for (var i = nChildLength - 1; i >= 0; i--) {
			//this.destroy();
			var temp = moreInfoView.widget.getChild(i);
			temp.destroy();
		}
		moreInfoView.widget.destroy();
		moreInfoView.widget = null;
		delete moreInfoView;
	},
});

var RelatedItemView = PanelCommon.BaseView.extend({
	initialize : function(model) {
		this.model = model;
		relatedView = this;
	},
	
	render : function(parent) {
		Volt.log('[detail-view.js] RelatedItemView.render');
        this.widget = this.initGrid();
		
        this.widget.color = Volt.hexToRgb('#1f2b3d', 0);
        this.widget.focusable = true;
		
        parent.addChild(this.widget);
        this.setWidget(this.widget);
        
		Volt.Nav.reload();
		return this;
	},
	
	initGrid : function(){
		var shs_trailer_list = DetailModel.get('shs_trailer_list');
		//var youtube_trailer_list = DetailModel.get('youtube_trailer_list');
		var cp_trailer_list = DetailModel.get('cp_trailer_list');
        var spotlightData = {
            style : CommonDefine.Const.HALO_ITEM_ALL_SAME,
            groups : [{
                modelArr : shs_trailer_list
            },
            {
                modelArr : cp_trailer_list
            }]
		};

        var gridView = new Gridlist(GridlistTemplate.detailPageRelated, JSON.stringify(spotlightData), 292, 164);
        gridView.setItemData = function(mustache, modelData) {
            mustache.imgUrl = modelData['screenshot_url'];
			};
        
        gridView.setItemTemplate = function(rendererInstance, parentWidth, parentHeight, data) {
            CommonContent.setBlankStyle(rendererInstance, parentWidth, parentHeight);
			var thumbnailObj = rendererInstance.thumbnail;
			thumbnailObj.setContentImage(data.imgUrl);
			if(data.group == 1){
			    thumbnailObj.visualizeAttachIcon(true,"icon2");
			} else {
			    thumbnailObj.visualizeAttachIcon(false,"icon2");
			}
		};
        
        gridView.onItemPress = function(itemData,groupIndex, itemIndex){
			Volt.log('[detail-view.js] onItemPress .....');
            var ID = '';
			var spValue = '';
            var player = '';
            if(groupIndex == 0){
                VideoPlayer(itemIndex);
				ID = DetailModel.get('shs_trailer_list').at(itemIndex).get('trailer_id_kpi');
				spValue = 'DV' +  Volt.KPIMapper.getIndexFormat(itemIndex + 1);
                player = 'native';
            }
            else if(groupIndex == 1){
                YouTuBePlayer(itemIndex);
				ID = DetailModel.get('cp_trailer_list').at(itemIndex).get('trailer_id_kpi');
				spValue = 'DV' +  Volt.KPIMapper.getIndexFormat(itemIndex + 1 + DetailModel.get('shs_trailer_list').length);
                player = 'youtube';
            }

			addEventLog('VIDEOS',{
				cp : 'G08_DETAIL',
				appid : DetailModel.get('app_id'),
				sp:spValue,
				content:'video' + '|' + ID ,
				player : player,
				inputby:'',
			});
	    };
        
      gridView.itemLoaded = function(gridList,groupIndex, itemIndex){
			Volt.log('itemLoaded'); 
			Volt.log('groupIndex:'+groupIndex+'itemIndex'+itemIndex);
			var data = gridList.getData(groupIndex, itemIndex);
			data.group = groupIndex;
			data.item = itemIndex;
		};

		gridView.focusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
			Volt.log('[detail-view.js] gridView.focusChanged fromItemIndex = ' + fromItemIndex + ',toItemIndex = ' + toItemIndex + ',,,toGroupIndex = ' + toGroupIndex);
		
			if(toItemIndex >= 0 && toGroupIndex >= 0){
				var voiceText = '';
				var shs_trailer_list = DetailModel.get('shs_trailer_list');
				var cp_trailer_list = DetailModel.get('cp_trailer_list');
				if(-1 == fromItemIndex){
					var itemNums = parseInt(shs_trailer_list.length) + parseInt(cp_trailer_list.length);
                    voiceText += Volt.i18n.t('TV_SID_MIX_LIST').replace('<<A>>',DetailModel.get('game_title')) + ',';
					voiceText += Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>',itemNums) + ',';
				}
                voiceText += Volt.i18n.t('COM_SID_VIDEOS') + ',' + parseInt(toItemIndex + 1) + '.';
				VoiceGuide.getVoiceGuide(voiceText);
			}
		};
		
		gridView.moveOut = function(gridList, directionString, fromGroupIndex, fromItemIndex){
            Volt.log('[detail-view.js] RelatedItemView moveOut fromGroupIndex = ' + fromGroupIndex +', fromItemIndex=' + fromItemIndex);
            var realIndex = gridList.getRealIndexInScreenRange(fromGroupIndex, fromItemIndex);
            if ("Up" == directionString) {
                if(realIndex <= 2){
                    var downloadButton = buttonView.widget.getDescendant('download_button_widget');
                    Volt.Nav.setNextItemRule(gridList, 'up', downloadButton);
                } else if(realIndex <= 4){
                    var ratingButton = buttonView.widget.getDescendant('rating_button_widget');
                    Volt.Nav.setNextItemRule(gridList, 'up', ratingButton);
                } else {
                    var controllerButton = buttonView.widget.getDescendant('controller_button_widget');
                    Volt.Nav.setNextItemRule(gridList, 'up', controllerButton);
                }
            }
        };
		
		gridView.disableLongPress();
		
		return gridView.render().widget;
	},

	events : {
		NAV_FOCUS : 'onFocus',
		NAV_BLUR : 'onBlur'
	},

	onFocus : function(widget) {
		Volt.log("[detail-view.js] relate-area onFocus");
		if(!widget) {
		    widget = this.widget;
		}
		if(lastFocus == widget) {
            //do noting
        } else if(lastFocus == buttonView.widget.getDescendant('download_button_widget')) {
            var realItem = widget.getRealItemInScreenRange(2);
            widget.setFocusItemIndex(realItem.groupIndex, realItem.itemIndex);
        } else if(lastFocus == buttonView.widget.getDescendant('rating_button_widget')){
            var realItem = widget.getRealItemInScreenRange(4); 
            widget.setFocusItemIndex(realItem.groupIndex, realItem.itemIndex);
        } else {
            var realItem = widget.getRealItemInScreenRange(5);
            widget.setFocusItemIndex(realItem.groupIndex, realItem.itemIndex);
        } 
		lastFocus = widget;
		//this.widget.animate('scale', {x: 1.1, y: 1.1}, 300, 'cubic');
		widget.onFocus(false);
	},

	onBlur : function(widget) {
		//this.widget.animate('scale', {x: 1, y: 1}, 300, 'cubic');
	    if(!widget) {
            widget = this.widget;
        }
		widget.onBlur();
	},
    
	destroy : function(widget){
		Volt.log('[detail-view.js] Games related View destroy');
		if (!this.widget)
			return;
		this.widget.destroy();
        this.widget = null;
	},
 
 });

 
function YouTuBePlayer(index){
    if(thumbnailView) {
        thumbnailView.destroyVideoObject();
    }
    var cp_trailer_list = DetailModel.get('cp_trailer_list');
	var trailer_id = cp_trailer_list.at(index).get('trailer_id');
	
	var shs_trailer_list = DetailModel.get('shs_trailer_list');
	
	Volt.log('-------------YouTuBePlayer---payload: ' + trailer_id);
	if (!voltApiWrapper.isWidgetInstalled("111299001912")) {//Youtube ID:"111299001912"
        ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_INSTALL_YOUTUBE);
	} else {
		Volt.log('--[detail-view]--youtube is installed, run youtube: ' + trailer_id);
		Volt.Nav.blur();
		
		//voltApiWrapper.launchApp("111299001912", trailer_id);//need add payload
        voltapi.WAS.forceLaunchApp("111299001912", trailer_id);
	}
};

function VideoPlayer(index){
    if(thumbnailView) {
        thumbnailView.destroyVideoObject();
    }
	var shs_trailer_list = DetailModel.get('shs_trailer_list');
            
	var list = [];
    var videoNum = shs_trailer_list.length;
	for(var i = 0; i < videoNum; i++){
		var info = {
			"file_name"          : shs_trailer_list.at(i).get('trailer_title'),
			"file_format"        : "mp4",
			"file_size"          : "",
			"file_date"          : "",
			"file_location"      : "USB",
			"file_path"          : shs_trailer_list.at(i).get('trailer_id'),
			"subtitle_path"      : "",
			"function_trickplay" : true, 
			"function_pause"     : true, 
			"function_rotate"    : true, 
			"function_scenesearch" : true, 
			"function_repeat"    : false, 
			"thumbnail_path"     : []
		};
		list.push(info);
	}
	
	var args = {
		"app_id"     : "org.volt.games",
		"play_index" : index,
		"items"      : list,
		"function_trickplay"   : true,
        "function_pause"       : true,
        "function_rotate"      : false,
        "function_scenesearch" : false,
        "function_repeat"      : true,
        "xwindow_id"           : String(VDUtil.getXWindowID())        
	};

	var jsonData = JSON.stringify(args);
	Volt.log('jsonData:::::'+jsonData);
	var Play_list = {"play_list_data":jsonData};
	Volt.Nav.blur();
	
	var aulApp2 = new Aul();
	aulApp2.launchApp("org.tizen.video-player-tv", Play_list);
};

function ScreenShotPhotoPlayer(index){
    if(thumbnailView) {
        thumbnailView.destroyVideoObject();
    }
//    Volt.Nav.blur();

    var screenshot_list = DetailModel.get('screenshot_list');
    var screenshot_url = screenshot_list.at(index).get('screenshot_url');
    Volt.log("screenshot_url :::" + screenshot_url);

    var args = {
        "app_id"               : "org.volt.games",
        "play_index"           : index,
        "need_slideshow"       : false,
        "xwindow_id"           : String(VDUtil.getXWindowID()),
        "function_thumbnail"   : false, 
        "items" : []
    };

    for( var i = 0; i < screenshot_list.length; i++){
        args.items.push({
            "file_name" : DetailModel.get('game_title'),
            "file_date" : "",
            "file_size" : "",
            "file_location" : "",
            "file_path" : screenshot_list.at(i).get('screenshot_url')
        });
    }

    var jsonData = JSON.stringify(args);
    Volt.log('jsonData:::::' + jsonData);
    var Play_list = {
        "play_list_data" : jsonData
    };
    var aulApp2 = new Aul();
    aulApp2.launchApp("org.tizen.photo-player-tv", Play_list);
};

function ThumbnailVideoPlayer(){
    if(thumbnailView) {
        thumbnailView.destroyVideoObject();
    }
    var argVideo = {
        "app_id"               : "org.volt.games",
        "play_index"           : 0,
        "xwindow_id"           : String(VDUtil.getXWindowID()),
        "function_trickplay"   : true,
        "function_pause"       : true,
        "function_rotate"      : false,
        "function_scenesearch" : false,
        "function_repeat"      : true,
        "items" : [{
            "file_name"          : DetailModel.get('trailer_title'),
            "file_format"        : "mp4",
            "file_size"          : "",
            "file_date"          : "",
            "file_location"      : "USB",
            "file_path"          : DetailModel.get('trailer_id'),
            "subtitle_path"      : "",
            "function_trickplay" : true,
            "function_pause"     : true,
            "function_rotate"    : true,
            "function_scenesearch" : true,
            "function_repeat"    : false,
            "thumbnail_path"     : []
        }]
    };

    var jsonData = JSON.stringify(argVideo);
    Volt.log('jsonData:::::' + jsonData);
    var Play_list = {
        "play_list_data" : jsonData
    };

    var aulApp2 = new Aul();
    aulApp2.launchApp("org.tizen.video-player-tv", Play_list);
}

var updateInfoSize = function(bg, needResetSize){
    var ratedBarWgt = bg.getChild("ratedBar");
    var sizeTxtWgt = bg.getChild("sizeTxt");
    sizeTxtWgt.x = ratedBarWgt.x + ratedBarWgt.width + Math.floor(scene.width*0.00625);

    var sizeInfoTxtWgt = bg.getChild("sizeInfoTxt");
    sizeInfoTxtWgt.x = sizeTxtWgt.x + sizeTxtWgt.width;
    if(needResetSize) {
        sizeInfoTxtWgt.text = Volt.i18n.t('COM_SID_MIX_MB').replace('<<A>>',DetailModel.get('size'));
    }

    var sizeBarWgt = bg.getChild("sizeBar");
    sizeBarWgt.x = sizeInfoTxtWgt.x + sizeInfoTxtWgt.width + Math.floor(scene.width*0.00625);

    var updtTxtWgt = bg.getChild("updatedTxt");
    updtTxtWgt.x = sizeBarWgt.x + sizeBarWgt.width + Math.floor(scene.width*0.00625);

    var updtInfoTxtWgt = bg.getChild("updateInfoTxt");
    updtInfoTxtWgt.x = updtTxtWgt.x + updtTxtWgt.width;
    
    /*
    var updtBarWgt = bg.getChild("updatedBar");
    updtBarWgt.x = updtInfoTxtWgt.x + updtInfoTxtWgt.width + Math.floor(scene.width*0.00625);

    var lastVerTxtWgt = bg.getChild("lastVerTxt");
    lastVerTxtWgt.x = updtBarWgt.x + updtBarWgt.width + Math.floor(scene.width*0.00625);

    var verInfoTxtWgt = bg.getChild("verInfoTxt");
    verInfoTxtWgt.x = lastVerTxtWgt.x + lastVerTxtWgt.width;
    */
};

var addGameController = function(bg) {
	var priceTxtWgt = bg.getChild("price");
	priceTxtWgt.x = 0;
	var priceBarWgt = bg.getChild("priceBar");
	priceBarWgt.x = priceTxtWgt.x + priceTxtWgt.width + Math.floor(scene.width*0.00625);

	var ratedTxtWgt = bg.getChild("ratedTxt");
	ratedTxtWgt.x = priceBarWgt.x + priceBarWgt.width + Math.floor(scene.width*0.00625);
	
	var ageRatingImage = bg.getChild("ageRatingImage");
	var ratedNoTxtWgt = bg.getChild("ratedNoTxt");
	if(ageRatingImage.src != '') {
	    ageRatingImage.x = ratedTxtWgt.x + ratedTxtWgt.width + Math.floor(scene.width*0.004167);
//	    ratedNoTxtWgt.x = ageRatingImage.x + ageRatingImage.width + Math.floor(scene.width*0.002604);
	    ratedNoTxtWgt.x = ageRatingImage.x + ageRatingImage.width;
	} else {
	    ratedNoTxtWgt.x = ratedTxtWgt.x + ratedTxtWgt.width;
        ratedNoTxtWgt.text = " " + ratedNoTxtWgt.text;
	}
	
	var ratedBarWgt = bg.getChild("ratedBar");
    ratedBarWgt.x = ratedNoTxtWgt.x + ratedNoTxtWgt.width + Math.floor(scene.width*0.00625);
    
    updateInfoSize(bg);
    
    var lastVerTxtWgt = bg.getChild("lastVerTxt");
    var verInfoTxtWgt = bg.getChild("verInfoTxt");
    verInfoTxtWgt.x = lastVerTxtWgt.x + lastVerTxtWgt.width;
    
    var lastVerBarWgt = bg.getChild("lastVerBar");
    lastVerBarWgt.x = verInfoTxtWgt.x + verInfoTxtWgt.width + Math.floor(scene.width*0.00625); 

	var langTxtWgt = bg.getChild("lang");
	langTxtWgt.x = lastVerBarWgt.x + lastVerBarWgt.width + Math.floor(scene.width*0.00625);
	
	var langInfoTxtWgt = bg.getChild("langInfoTxt");
	langInfoTxtWgt.x = langTxtWgt.x + langTxtWgt.width;
	
	/*
	var langBarWgt = bg.getChild("langBar");
	langBarWgt.x = langInfoTxtWgt.x + langInfoTxtWgt.width + Math.floor(scene.width*0.00625);

	var devTxtWgt = bg.getChild("devTxt");
	devTxtWgt.x = langBarWgt.x + langBarWgt.width + Math.floor(scene.width*0.00625);

	var devInfoTxtWgt = bg.getChild("devInfo");
	devInfoTxtWgt.x = devTxtWgt.x + devTxtWgt.width;
	*/

	var ctrllerTxtWgt = bg.getChild("ctrllerTxt");
	var controller_list = DetailModel.get('controller_list');
	var smartControlImage = new Array();
	var smartControlText = new Array();
	var smartControlBar = new Array();
	Volt.log("controller_list.length: " + controller_list.length);
	for (var i = 0; i < controller_list.length; i++) {
        Volt.log("controller_list.at(i).get('controller_url'):" + controller_list.at(i).get('controller_url'));
        smartControlImage[i] = PanelCommon.loadTemplate(DetailTemplate.smartCtrllerImg, null, bg);
        if (i == 0) {
            smartControlImage[i].x = ctrllerTxtWgt.x + ctrllerTxtWgt.width + scene.width * 0.010417;
            smartControlImage[i].y = ctrllerTxtWgt.y;
        } else if (i == 2) {
            smartControlImage[i].x = smartControlImage[0].x;
            smartControlImage[i].y = smartControlImage[0].y + scene.height * 0.035185;
            bg.height += scene.height * 0.035185;
        } else {
            smartControlBar[i] = PanelCommon.loadTemplate(DetailTemplate.smartCtrllerBar, null, bg);
            smartControlBar[i].x = smartControlText[i - 1].x + smartControlText[i - 1].width + scene.width * 0.00625;
            smartControlBar[i].y = smartControlText[i - 1].y + scene.height * 0.008333;
            smartControlImage[i].x = smartControlBar[i].x + smartControlBar[i].width + scene.width * 0.00625;
            smartControlImage[i].y = smartControlText[i - 1].y;
        }
        smartControlImage[i].src = controller_list.at(i).get('controller_url');
        smartControlText[i] = PanelCommon.loadTemplate(DetailTemplate.smartCtrllerTxt, {
            text : controller_list.at(i).get('controller_name')
        }, bg);
        smartControlText[i].x = smartControlImage[i].x + smartControlImage[i].width + scene.width * 0.004167;
        smartControlText[i].y = smartControlImage[i].y;
        smartControlText[i].id = 'smartControlText'+i;
        bg.addChild(smartControlText[i]);
    }
};

var addGamesDescription = function(bg) {
	var btnStyle = {
		style : CommonDefine.Winset.BUTTON_IMAGE_O_STYLE_F_FOCUS1,
		buttonType : CommonDefine.Winset.BUTTON_ICON,
	};
    
	moreBtn = PanelCommon.loadTemplate(DetailTemplate.moreBtn, btnStyle, bg);
	moreBtn.setIconAlpha({
				state: "normal",
				alpha: 242
			});
	moreBtn.setIconImage({
        state: "focused",
        src: Volt.getRemoteUrl("images/1080/games/btn_icon_more_b.png")
    });
    moreBtn.setIconImage({
        state: "focused-roll-over",
        src: Volt.getRemoteUrl("images/1080/games/btn_icon_more_b.png")
    });
	moreBtn.show();
};

var addEventLog = function(eventName,options){
	Volt.log('[detail-view.js] addEventLog eventName = ' + eventName + ',,,options = ' + JSON.stringify(options));
	//add Event log
	if(!eventName){
		return;
	}
    Volt.KPIMapper.addEventLog(eventName, {d : options});
};

exports = DetailView;
