var Q                 = Volt.require('modules/q.js');
var PanelCommon       =  Volt.require('lib/panel-common.js');
var Backbone          = Volt.require('lib/volt-backbone.js');
var CommonContent     = Volt.require('app/common/common-content.js');

var MyPageModel       = Volt.require('app/models/my-page-model.js');
var CommonDefine      = Volt.require('app/common/common-define.js');
var Mediator          = Volt.require('app/common/event-mediator.js');
var LoadingView       = Volt.require('app/views/loading-view.js');
var Utils             = Volt.require('app/common/utils.js');
var voltApiWrapper    = Volt.require("app/common/voltapi-wrapper.js");
var MultiSelection    = Volt.require('app/views/multi-selection.js');
var Gridlist          = Volt.require('app/views/grid-list-view.js');
var ErrorHandling     = Volt.require('app/common/error-handling.js');
var VoiceGuide    	  = Volt.require('app/common/voiceGuide.js');
var NoContentView 	  = Volt.require('app/views/no-content-view.js');
var networkStatus     = Volt.require('app/common/network-state.js');

var isSigned       = false;
var isCheckBox     = false;
var selectedCount  = 0;
var checkableCount = 0;
var totalCount     = 0;
var isChecked      = [];
var itemIndex      = -1;
var itemGroupIndex = 0;
var myPageSelf     = null;
var optionName     = '';
var dimInProfile   = null;
var bStopVoiceGuide = false;

var MyPageView = PanelCommon.BaseView.extend({
    parent            : null,
    grid              : null,
    isCheckBoxCreated : false,
    multiWidget       : null,
    isButtonCreated   : false,
    menuText          : null,
    deleteCount       : 0,
    bListenerStatus   : false,
    leftItemNum       : 0,
    viewIsVisible     : false,
	downloadGameList  : [],
	signState         : false,
	gridView          : null,
	firstFocus        : true,
	renderResult      : false,
	bRefresh          : false,
	bReloaded         : false,
	bFocusGridUSB     : false,
	disConnectUsb     : false,
	lastFocusOnMypage : null,
	isActive          : false,
	bGridPopup     : false,

    initialize : function() {
        myPageSelf = this;
    },

    events : {
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },

    render : function(parentWidget) {
        Volt.log('[main-mypage-view.js] my page view render');
        this.parent = parentWidget.widget.getChild('main-content-container');
        this.multiWidget = parentWidget.widget.getChild('multi-selection-container');
        return this;
    },

    show : function(param, animationType) {
        Volt.log('[main-mypage-view.js] show');
        this.viewIsVisible = true;
        this.startListening();
        this.addEventListener();
        Mediator.on(CommonDefine.Event.GAMES_ON_ACTIVATE, this.active, this);
        Mediator.on(CommonDefine.Event.GAMES_ON_DEACTIVATE, this.deactive, this);
        Mediator.on(CommonDefine.Event.CONNECT_USB, this.connectUSB, this);
		if(this.isNeedRefresh() || !this.renderResult){
            Volt.log('need to refresh');
            this.requestData();
        } else {
            Volt.log(' no need to refresh');
            this.checkMultiSelection();
            var mypageList = MyPageModel.get('game_list');

            if (isSigned && mypageList.length == 0) {
                this.parent.getChild('main-no-content-text').text = Volt.i18n.t('TV_SID_YOU_DONT_SEEM_TO_HAVE_ANY_DOWNLOADED_OR_PURCHASED_GAMES');
            }
            
            if (this.grid) {
                Volt.log('grid show');
                if (this.grid.hasOwnProperty('focusable')) {
                    this.grid.focusable = true;
                }
                if ((this.grid.hasOwnProperty('id') && this.grid.id == "myPageContent")) {
                 //   this.grid.focusable = true;
                    this.grid.showWithAnimation();
                }else{
                    this.grid.show();
                }
            }

            if (this.gridView) {
                this.gridView.show();
            }
        }
        this.isActive = true;
        Volt.Nav.reload(); 
    },
	
	isNeedRefresh : function(){
		var result = true;
		Volt.log('[my-page-view.js]isNeedRefresh first focus:::'+this.firstFocus);
		if(this.firstFocus){
			result = true;
			//this.signState = Utils.Account.getSignState();
			this.signState = voltApiWrapper.getSSOLoginState();
			var currentGamesList = voltApiWrapper.getNativeGameList();
			this.downloadGameList = currentGamesList.slice(0);
			Volt.log('[my-page-view.js]isNeedRefresh, sign in state::::'+this.signState);
			//this.firstFocus = false;
		} else {
			//var currentSignState = Utils.Account.getSignState();
			var currentSignState = voltApiWrapper.getSSOLoginState();
			Volt.log('[my-page-view.js]isNeedRefresh current sign in state::::'+currentSignState);
			if (this.signState != currentSignState) {
				this.signState = currentSignState;
				result = true;
			} else {	
				var currentGamesList = voltApiWrapper.getNativeGameList();
				Volt.log("[my-page-view.js]isNeedRefresh current games length:::"+currentGamesList.length);
				Volt.log("[my-page-view.js]isNeedRefresh history games length:::"+this.downloadGameList.length);
				if(currentGamesList.length != this.downloadGameList.length){
					result = true;
				} else {
					var temp1 = currentGamesList.sort().toString();
					var temp2 = this.downloadGameList.sort().toString();
					Volt.log('[my-page-view.js]isNeedRefresh current games list:::'+temp1);
					Volt.log('[my-page-view.js]isNeedRefresh last games list:::'+JSON.stringify(temp2));
					if(temp1 == temp2){
						Volt.log('[my-page-view.js]isNeedRefresh current is equal history!!!!!!');
						result = false;
					} else {
						result = true;
					}
				}
				
				this.downloadGameList = currentGamesList.slice(0);
			}
		}
		Volt.log('[my-page-view.js]isNeedRefresh compare result:::'+result);
		return result;
	},

    checkMultiSelection: function(){
        Volt.log('[main-mypage-view.js] checkMultiSelection');
        var status = MultiSelection.getState();
        Volt.log('status::::::'+status);
        switch(status){
            case 'delete':
                this.onDeleteMenu();
                break;
            case 'update':
                this.onUpdateMenu();
                break;
            default:
                break;
        }
    },

    hide : function(animationType) {
        Volt.log('[main-mypage-view.js] hide');
        optionName = '';
        bStopVoiceGuide = false;
        this.removeEventListener();
        this.stopListening();
        
        Mediator.off(CommonDefine.Event.GAMES_ON_ACTIVATE, null, myPageSelf);
        Mediator.off(CommonDefine.Event.GAMES_ON_DEACTIVATE, null, myPageSelf);
        Mediator.off(CommonDefine.Event.CONNECT_USB, null, myPageSelf);
        this.viewIsVisible = false;
        this.parent.getChild('main-no-content-text').text = '';
        if(this.gridView){
            this.gridView.hide();
        }
        
        if (this.grid) {
			Volt.log('grid hide');
            if(this.grid.hasOwnProperty('focusable')){
               this.grid.focusable = false; 
            }
            if ((this.grid.hasOwnProperty('id') && this.grid.id == "myPageContent")) {
                this.grid.hideWithAnimation();
            }else{
                this.grid.hide();
            }
        }
        
        this.lastFocusOnMypage = null;
        this.bRefresh = false;
        this.bReloaded = false;
        this.bFocusGridUSB = false;
        this.disConnectUsb = false;
        this.isActive = false;
        this.bGridPopup = false;
    },
	
	handleError : function(noContentID, noContentText) {
        Volt.log('[main-mypage-view.js] handleError');	
		this.remove();		
		var noContentWgtId = "MY_PAGE";
		var textToShow = Volt.i18n.t('TV_SID_MIX_UABLE_CONNECT_SAMSUNG_SERVER').replace('<<A>>', "400");
		this.grid = new NoContentView().render(noContentWgtId, noContentText, noContentID).widget;
        this.parent.addChild(this.grid);
        this.setWidget(this.grid);
       // this.grid.focusable = true;
        Volt.Nav.reload();
       // Volt.Nav.focus(this.grid);
	},
	
    requestData : function() {
        var that = this;
        
        function onSuccess() {
            Volt.log('[main-mypage-view.js] onSuccess');
            LoadingView.hide();
            if (that.viewIsVisible == true) {
                that.renderContent();
				that.renderResult = true;
                that.checkMultiSelection();
                that.handlerFocus();
            } else {
				that.renderResult = false;
			}
        }

        function onError(msg) {
            LoadingView.hide();
            var viewType = CommonContent.getViewType();
            Volt.log("[main-mypage-view.js] viewType = " + viewType);
            if (viewType == '#My Page') {
			    var textToShow = Volt.i18n.t('TV_SID_MIX_UABLE_CONNECT_SAMSUNG_SERVER').replace('<<A>>', "400");
                that.handleError(CommonDefine.Const.NO_CONTENT_GENERAL, textToShow);
            }
        }
        
		var status = networkStatus.getNetWorkState();
		if(!status){
			var textToShow = Volt.i18n.t('TV_SID_MIX_CONNECTED_FEATURE_NETWORK').replace('<<A>>',"400");
			that.handleError(CommonDefine.Const.NO_CONTENT_WITH_BTN, textToShow);
		} else {
			LoadingView.show(CommonDefine.Const.SWITCH_WHILE_LOADING);
			MyPageModel.fetch().then(onSuccess, onError);
		}
    },
    
    handlerFocus : function () {
        Volt.log('[main-mypage-view.js] handlerFocus ');
        var that = this;
        var lastFocusWgt = Volt.Nav.getFocusedWidget();
        Volt.log('[main-mypage-view.js] onSuccess lastFocusWgt =' + lastFocusWgt);
        Volt.log('[main-mypage-view.js] handlerFocus that.firstFocus =' + that.firstFocus);
        Volt.log('[main-mypage-view.js] handlerFocus that.disConnectUsb =' + that.disConnectUsb);
        if(lastFocusWgt){
            if(that.firstFocus){
                Volt.log('[main-mypage-view.js] handlerFocus first focus');
                Volt.Nav.focus(null);
                Volt.Nav.focus(lastFocusWgt);
                that.firstFocus = false;
            } else if(that.disConnectUsb) {
                that.handlerFocusWhenUsb(lastFocusWgt,that);
            } else {
                Volt.log('[main-mypage-view.js] handlerFocus no USB');
                Volt.Nav.focus(null);
                Volt.Nav.focus(lastFocusWgt);
            }
        } else {
            if(that.disConnectUsb){
                that.handlerFocusWhenUsb(null,that);
            } else if (!that.firstFocus) {
                //login in when focus on grid item
                Volt.log('[main-mypage-view.js] handlerFocus login in when press grid item && insert usb when focus on grid');
                that.setFocusOnGrid();
            }
        }
    },
    
    handlerFocusWhenUsb : function(widget,that) {
        //that.disConnectUsb = true
        if (widget) {
            Volt.log('[main-mypage-view.js] handlerFocusWhenUsb lastfocus widget exists');
            if (!that.bFocusGridUSB && widget.hasOwnProperty("id") && widget.id) {
                Volt.log('[main-mypage-view.js] handlerFocusWhenUsb widget.id =' + widget.id);
            }

            if (!that.bFocusGridUSB) {
                Volt.log('[main-mypage-view.js] handlerFocusWhenUsb focus on lastFocusWgt when disconnenctUSB');
                Volt.Nav.focus(null);
                Volt.Nav.focus(widget);
            } else {
                Volt.log('[main-mypage-view.js] handlerFocusWhenUsb focus on grid when disconnenctUSB');
                that.setFocusOnGrid();
            }
        } else {
            Volt.log('[main-mypage-view.js] handlerFocusWhenUsb lastfocus widget is null');
            if (that.bFocusGridUSB) {
                Volt.log('[main-mypage-view.js] handlerFocusWhenUsb disConnectUsb when grid');
                that.setFocusOnGrid();
            } else if(that.headerWgt){
                if(that.bDeleteResultPopup){
                    Volt.log('[main-mypage-view.js] handlerFocusWhenUsb set focus on header icon');
                    Volt.Nav.focus(that.headerWgt);
                    that.bDeleteResultPopup = false;
                }
            } else {
                if (that.menuText) {
                    Volt.log('[main-mypage-view.js] handlerFocusWhenUsb disConnectUsb when multi delete-result');
                    //that.destoryMultiSelection();
                    var headerWidget = CommonContent.getHeaderSettingWidget();
                    if (headerWidget) {
                        Volt.Nav.focus(headerWidget);
                    }
                } else {
                    Volt.log('[main-mypage-view.js] handlerFocusWhenUsb disConnectUsb when longpress delete-result');
                    that.setFocusOnGrid();
                }
                                
            }
        }
        
        that.disConnectUsb = false;
    },

    renderContent : function() {
		this.remove();
        this.renderContentView();
    },
    
    renderContentView : function() {
        Volt.log('[main-mypage-view.js] renderContentView');
        if (this.grid != null) {
            return;
        }

        var mypageList = MyPageModel.get('game_list');
        Volt.log('[main-mypage-view.js] mypageList =' + mypageList);
        //var messageCnt = MyPageModel.get('message_count');
        var messageCnt = 0;
        var hasMsg = false;
        var leftItemCnt = 0;
        //isSigned = Utils.Account.getSignState();
        isSigned = voltApiWrapper.getSSOLoginState();
        Volt.log('[main-mypage-view.js] isSigned =' + isSigned);

        if (isSigned) {
            if (messageCnt > 0) {
                hasMsg = true;
                leftItemCnt = 3;
            } else {
                hasMsg = false;
                leftItemCnt = 2;
            }
            
        } else {
            if (messageCnt > 0) {
                hasMsg = true;
                leftItemCnt = 2;
            } else {
                hasMsg = false;
                leftItemCnt = 1;
            }
        }

        this.leftItemNum = leftItemCnt;
        
        if(isSigned && mypageList.length == 0) {
            this.parent.getChild('main-no-content-text').text = Volt.i18n.t('TV_SID_YOU_DONT_SEEM_TO_HAVE_ANY_DOWNLOADED_OR_PURCHASED_GAMES');
        }
        
        var itemNotAllSame = {
            style : CommonDefine.Const.HALO_ITEM_NOT_ALL_SAME,
            groups : [{
                hasMsg : hasMsg,
                leftItemCnt : leftItemCnt,
                modelArr : mypageList
            }]
        };
        var itemAllSame = {
            style : CommonDefine.Const.HALO_ITEM_ALL_SAME,
            groups : [{
                hasMsg : hasMsg,
                leftItemCnt : leftItemCnt,
                modelArr : mypageList
            }]
        };

        var downloadData = null;
        if (isSigned) {
            if(!hasMsg && mypageList.length > 0){
                downloadData = itemAllSame;
            } else {
                downloadData = itemNotAllSame;
            }
        } else {
            downloadData = itemAllSame;
        }

        this.grid = this.initGrid(downloadData);
        this.grid.setCheckStatus = function(groupIndex, itemIndex, isChecked,isMulti,isLastItem){
            Volt.log("[main-mypage-view.js] setCheckStatus = " + isChecked + ',,,isMulti = ' + isMulti + ',,,isLastItem = ' + isLastItem);
			if(!isMulti){
				var voiceGuide = Volt.i18n.t('TV_SID_UNCHECKED_KR_UN');
				if(isChecked){
					voiceGuide = Volt.i18n.t('TV_SID_CHECKED');
				}
				VoiceGuide.getVoiceGuide(voiceGuide);
			}else if(isLastItem){
				var voiceGuide = Volt.i18n.t('TV_SID_UNCHECKED_KR_UN');
				if(isChecked){
					voiceGuide = Volt.i18n.t('TV_SID_CHECKED');
				}
				VoiceGuide.getVoiceGuide(voiceGuide);
			}
			
            if(isChecked) {
                var renderer = this.grid.renderer(groupIndex, itemIndex);                
                if (renderer && renderer.thumbnail) {
                    var thumbnail = renderer.thumbnail;
                    thumbnail.dim(true);
                    thumbnail.setDimBackgroundColor({r:33, g:158, b:230, a:153});
                    thumbnail.raiseElement("checkBox");
                }
                
            } else {
                var renderer = this.grid.renderer(groupIndex, itemIndex);
                if(renderer && renderer.thumbnail){
                    var thumbnail = renderer.thumbnail;
                    thumbnail.dim(false);
                }
            }
            this.grid.setCheckToItem({
                groupIndex : groupIndex,
                itemIndex : itemIndex,
                isChecked : isChecked
            });
        }.bind(this);
        this.grid.id = 'myPageContent';
        this.grid.focusable = true;
        this.grid.showWithAnimation();
        this.parent.addChild(this.grid);
        this.setWidget(this.grid);
        Volt.Nav.reload();
        this.bRefresh = false;
        var lastFocusInMainView = CommonContent.getLastFocusForGrid();
        if(lastFocusInMainView && "grid" == lastFocusInMainView.widgetType && "mypage" == lastFocusInMainView.view){
            this.bRefresh = true;
            this.bReloaded = true;
            if(this.bFocusGridUSB && !this.bDeleteResultPopup){
                this.setFocusOnGrid();
            }
        }
    },

    remove : function() {
        Volt.log('[main-mypage-view.js]:remove');
        if (this.grid) {
            Volt.log('[main-mypage-view.js]:grid remove');
            Volt.Nav.removeItem(this.grid);
            this.parent.removeChild(this.grid);
            this.grid.id = '';
            this.grid.destroy();
            this.grid = null;
            this.gridView = null;
        }
        this.parent.getChild('main-no-content-text').text = "";

        this.isCheckBoxCreated = false;
    },

    onFocus : function(widget) {
        Volt.log('[main-mypage-view.js] ContentView.onFocus');
        Volt.log('[main-mypage-view.js] ContentView.onFocus widget = ' + widget);
        Mediator.trigger('EVENT_MULTI_SELECTION_BLUR');
        
        if(this.grid){
            widget = this.grid;
            Volt.Nav.focus(this.grid);
            widget.onFocus();
        }
    },
    
    setFocusOnGrid : function(){
        Volt.log('[main-mypage-view.js] setFocusOnGrid');
        Volt.log('[main-mypage-view.js] setFocusOnGrid this.bRefresh =' + this.bRefresh);
        if(this.bRefresh){
            Volt.log('[main-mypage-view.js] setFocusOnGrid this.bReloaded =' + this.bReloaded);
            if(this.bReloaded){
                Volt.log('[main-mypage-view.js] setFocusOnGrid this.grid =' + this.grid);
                if (this.grid) {
                    Volt.Nav.focus(this.grid);
                    var mypageList = MyPageModel.get('game_list');
                    var itemNum = this.leftItemNum + mypageList.length;
                    Volt.log('[main-mypage-view.js] setFocusOnGrid itemNum =' + itemNum);
                    var lastFocusInMainView = CommonContent.getLastFocusForGrid();
                    if (lastFocusInMainView.itemIndex >= itemNum) {
                        //set focus on the last item
                        Volt.log('[main-mypage-view.js] setFocusOnGrid set focus on the last item');
                        this.grid.setFocusItemIndex(lastFocusInMainView.groupIndex, itemNum - 1);
                    } else {
                        this.grid.setFocusItemIndex(lastFocusInMainView.groupIndex, lastFocusInMainView.itemIndex);
                    }
                    
                    this.bRefresh = false;
                    this.bReloaded = false;
                    this.bFocusGridUSB = false;
                    this.bGridPopup = false;
                }
            } else {
                //Volt.Nav.focus(null);
            }
            
        } else {
            Volt.Nav.focus(this.grid);
            /*
            if(this.bGridPopup){
                this.gridView.onBlur();
                LoadingView.show(CommonDefine.Const.POPUP_LOADING);
                this.bGridPopup = false;
            }
            */
        }
    },

    onBlur : function(widget) {
        Volt.log('[main-mypage-view.js] onBlur widget =' +widget);
        if(this.menuText && MultiSelection.isStatus("SHOW")){
            Mediator.trigger('EVENT_MULTI_SELECTION_FOCUS');
        }
        
        if (widget) {
            Volt.log('[main-mypage-view.js] ContentView.onBlur');
            if(this.grid) {
                this.grid.onBlur();
            }
        }
    },
    
    deactive : function(){
        Volt.log('[main-mypage-view.js] deactive');
        this.isActive = false;
    },
    
    active : function() {
        Volt.log('[main-mypage-view.js] active');
        this.isActive = true;
        Volt.log('[main-mypage-view.js] active this.disConnectUsb ='+ this.disConnectUsb);
        if(this.menuText && MultiSelection.isStatus("SHOW") && MultiSelection.isLastFocus() && this.disConnectUsb){
            Volt.Nav.focus(this.grid);
        }
    },

    startListening : function() {
        Volt.log('[main-mypage-view.js] startListening');
        Mediator.on(CommonDefine.Event.SIGN_STATE_UPDATE, this.refresh, this);
        //Mediator for multi-selection
        Mediator.on('EVENT_PRESS_DELETE_MENU', this.onDeleteMenu, this);
        Mediator.on('EVENT_PRESS_UPDATE_MENU', this.onUpdateMenu, this);

        Mediator.on('EVENT_SELECTALL_BUTTON', this.selectAllButtonCb, this);
        Mediator.on('EVENT_DELETE_BUTTON', this.deleteButtonCb, this);
        Mediator.on('EVENT_CANCEL_BUTTON', this.cancelButtonCb, this);
        Mediator.on("DELETE_SUCCESS_RETUREN", this.refresh, this);
        
        Mediator.on(CommonDefine.Const.UPDATE_ITEMS, this.updateItems, this);
        Mediator.on(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, this.updateListenerFlag, this);
        Mediator.on(CommonDefine.Event.SET_ROOT_COMPLETE, this.setFocusOnGrid, this);
        Mediator.on(CommonDefine.Event.EDIT_NICK_NAME_POPUP_YBUT,function(){
            bStopVoiceGuide = true;
            Mediator.on(CommonDefine.Event.EDIT_NICK_NAME_RESPONSE,function(){
                Volt.setTimeout( function() {
                    var voiceText = '';
                    if(MyPageModel.get('nick_name')){
                        voiceText += MyPageModel.get('nick_name') + ',';
                    }
                    voiceText += Volt.i18n.t('TV_SID_EDIT_NICKNAME') + '.';
                    VoiceGuide.getVoiceGuide(voiceText);
                }, 10);
                
            });
        });
        //Mediator.on(CommonDefine.Event.GAMES_ON_ACTIVATE, this.active, this);
    },

    stopListening : function() {
        Volt.log('[main-mypage-view.js] stopListening');
        Mediator.off(CommonDefine.Event.SIGN_STATE_UPDATE, null, this);
        //close Mediator for multi-selection
        Mediator.off('EVENT_PRESS_DELETE_MENU', null, this);
        Mediator.off('EVENT_PRESS_UPDATE_MENU', null, this);
        Mediator.off('EVENT_SELECTALL_BUTTON', null, this);
        Mediator.off('EVENT_DELETE_BUTTON', null, this);
        Mediator.off('EVENT_CANCEL_BUTTON', null, this);
        Mediator.off("DELETE_SUCCESS_RETUREN", null, this);
        
        Mediator.off(CommonDefine.Const.UPDATE_ITEMS, null, this);
        Mediator.off(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, null, this);
        Mediator.off(CommonDefine.Event.SET_ROOT_COMPLETE, null, this);
        Mediator.off(CommonDefine.Event.EDIT_NICK_NAME_POPUP_YBUT);
        //Mediator.off(CommonDefine.Event.GAMES_ON_ACTIVATE, null, this);
    },

    addEventListener : function() {
        Volt.log('[main-mypage-view.js] addEventListener, that.bListenerStatus = ' + this.bListenerStatus);
        if (this.bListenerStatus == false) {
            
            Mediator.on(CommonDefine.Event.BEGIN_DOWNLOAD, this.updateProgressBar, this);
            Mediator.on(CommonDefine.Event.DOWNLOAD_PROGRESS, this.updateProgressBar, this);
            Mediator.on(CommonDefine.Event.DOWNLOAD_CANCELED, this.updateProgressBar, this);
            Mediator.on(CommonDefine.Event.INSTALL, this.finishInstall, this);
            //Mediator.on(CommonDefine.Event.CONNECT_USB, this.connectUSB, this);
            Mediator.on(CommonDefine.Event.DISCONNECT_USB, this.disconnectUSB, this);
            
            Mediator.on(CommonDefine.Event.MSGBOX_BUTTON, this.processMsgBoxEvent, this);
            Mediator.on(CommonDefine.Event.EDIT_NICK_NAME, this.updateNickName, this);
            //Mediator.on(CommonDefine.Event.REGISTER_COUPON, this.updateCouponNum, this);
            Mediator.on(CommonDefine.Event.MSG_POPUP_TIMEOUT, this.handlerPopup, this);
            //Mediator.on(CommonDefine.Event.GAMES_ON_DEACTIVATE, this.deactive, this);
            Mediator.on("REMOVE_WHEN_INSERT_USB",this.removeWhenInsertUsb, this);

            this.bListenerStatus = true;
        }
    },

    removeEventListener : function() {
        Volt.log('[main-mypage-view.js] removeEventListener, that.bListenerStatus = ' + this.bListenerStatus);
        if (this.bListenerStatus == true) {
            Mediator.off(CommonDefine.Event.DOWNLOAD_PROGRESS, null, this);
            Mediator.off(CommonDefine.Event.INSTALL, null, this);
            Mediator.off(CommonDefine.Event.BEGIN_DOWNLOAD, null, this);
            Mediator.off(CommonDefine.Event.DOWNLOAD_CANCELED, null, this);
            //Mediator.off(CommonDefine.Event.CONNECT_USB, null, this);
            Mediator.off(CommonDefine.Event.DISCONNECT_USB, null, this);
            
            Mediator.off(CommonDefine.Event.MSGBOX_BUTTON, null, this);
            Mediator.off(CommonDefine.Event.EDIT_NICK_NAME, null, this);
            //Mediator.off(CommonDefine.Event.REGISTER_COUPON, null, this);
            Mediator.off(CommonDefine.Event.MSG_POPUP_TIMEOUT, this.handlerPopup, this);
            //Mediator.off(CommonDefine.Event.GAMES_ON_DEACTIVATE, null, this);
            Mediator.off("REMOVE_WHEN_INSERT_USB",null, this);
            
            this.bListenerStatus = false;
        }
    },

    updateListenerFlag : function(flag) {
        Volt.log('[main-mypage-view.js] updateListenerFlag,flag = ' + flag);
        if (flag == true) {
            this.addEventListener();
            //Mediator.on(CommonDefine.Event.GAMES_ON_ACTIVATE, this.active, this);
        } else {
            this.removeEventListener();
            //Mediator.off(CommonDefine.Event.GAMES_ON_ACTIVATE, null, this);
        }
        this.bListenerStatus = flag;
    },
    
    handlerPopup : function(popupType,headerWgt) {
        Volt.log('[main-mypage-view.js] handlerPopup when time out popupType = ' + popupType);
        Volt.log('[main-mypage-view.js] handlerPopup when time out headerWgt = ' + headerWgt);
        if (headerWgt) {
            this.headerWgt = headerWgt;
        }
        if (CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS == popupType) {
            if (isCheckBox == true) {
                this.destoryMultiSelection();
            }
            this.refresh();
        }
    },

    updateItems : function() {
        Volt.log("[main-mypage-view.js] updateAllItems~~");
        if (this.grid && 'myPageContent' == this.grid.id) {
            var data = MyPageModel.get('game_list');
            if (data.length === 0) {
                return;
            }

            this.grid.updateAllItems(0);
        }
    },

    updateNickName : function() {
        Volt.log("[main-mypage-view.js] updateNickName ");
        if(this.bGridPopup){
            this.gridView.onFocus();
            this.bGridPopup = false;
        }
        
        if (this.grid && 'myPageContent' == this.grid.id) {
            if (isSigned) {
                this.grid.updateItem(0, this.leftItemNum - 1);
            }
        }
    },

    refresh : function() {
        Volt.log('[main-mypage-view.js] refresh itemIndex = ' + itemIndex);
        /*
		var status = MultiSelection.getState();
		Volt.log('status::::'+status);
		if(status != ''){
			Volt.log('do not refresh when multi mode');
			return;
		}
		*/
		Volt.log('[main-mypage-view.js] refresh disConnectUsb = ' + this.disConnectUsb);
        if(this.disConnectUsb){
            this.handlerWhenUSB();
        } else {
            this.doRefresh();
        }
    },
    
    doRefresh : function(){
        Volt.log('[main-mypage-view.js] doRefresh');
        this.remove();
        this.bRefresh = true;
        this.requestData();
    },
    
    handlerWhenUSB : function(){
        Volt.log('[main-mypage-view.js] handlerWhenUSB');
        this.resetSelectNum();
        var tempWgt = Volt.Nav.getFocusedWidget();
        Volt.log('[main-mypage-view.js] handlerWhenUSB tempWgt = ' + tempWgt);
        if (tempWgt && tempWgt.hasOwnProperty("id") && "myPageContent" == tempWgt.id) {
            Volt.log('[main-mypage-view.js] focus is on grid');
            this.bFocusGridUSB = true;
            if (this.lastFocusOnMypage) {
                this.setLastFocus();
            }
            this.doRefresh();
        } else if (tempWgt) {
            // on other wgt but not grid
            if (MultiSelection.isStatus("SHOW") && MultiSelection.isLastFocus()) {
                Volt.log('[main-mypage-view.js] handlerWhenUSB focus on multi-selection');
                CommonContent.setLastFocusForGrid(null);
            }
            this.bFocusGridUSB = false;
            this.doRefresh();
        } else {
            //tempWgt is null
            if(this.bDeleteResultPopup){
                Volt.log('[main-mypage-view.js] handlerWhenUSB nothing to do when disconnectUSB while delete-result popup');
                /*
                if(this.menuText){
                    Volt.log('[main-mypage-view.js] handlerWhenUSB disconnectUSB when multi delete-result popup');
                    this.bFocusGridUSB = false;
                    this.lastFocusOnMypage = null;
                    CommonContent.setLastFocusForGrid(null);
                    this.doRefresh();
                } else {
                    Volt.log('[main-mypage-view.js] handlerWhenUSB disconnectUSB when longpress delete-result popup');
                    this.bFocusGridUSB = true;
                    if(this.lastFocusOnMypage){
                        this.setLastFocus();
                    }
                    this.doRefresh();
                }
                */
            } else {
                if(this.bGridPopup && this.lastFocusOnMypage){
                    // disconnectUSB when press item and show popup
                    Volt.log('[main-mypage-view.js] handlerWhenUSB disconnectUSB when popup');
                    this.bFocusGridUSB = true;
                    this.setLastFocus();
                    this.doRefresh(); 
                } else {
                    Volt.log('[main-mypage-view.js] handlerWhenUSB disconnectUSB when option -- edit nickname or multi-- delete check');
                    this.bFocusGridUSB = false;
                    this.doRefresh();
                }
            }
            
        }//temp is null
    },
    
    setLastFocus : function(){
        var params = {
            widgetType : "grid",
            widget : this.lastFocusOnMypage.widget,
            groupIndex : this.lastFocusOnMypage.groupIndex,
            itemIndex : this.lastFocusOnMypage.itemIndex,
            view : "mypage",
        };
        CommonContent.setLastFocusForGrid(params); 
    },
    
    removeWhenInsertUsb : function(){
        Volt.log('[main-mypage-view.js] removeWhenInsertUsb');
        this.resetSelectNum();
        this.doRefresh();
    },
    
    resetSelectNum : function () {
        Volt.log('[main-mypage-view.js] resetSelectNum');
        if(this.menuText){
            selectedCount = 0;
            checkableCount = 0;
            MultiSelection.updateSelectNum(selectedCount);
            MultiSelection.updateSelectAllState(false);
        }
    },
    
    connectUSB : function(param){
        Volt.log('[main-mypage-view.js] connectUSB');
    },
    
    disconnectUSB : function(param){
        Volt.log('[main-mypage-view.js] disconnectUSB');
        this.checkPopup();
        this.checkOptionMenu();
        this.disConnectUsb = true;
        this.refresh();
    },
    
    checkOptionMenu : function () {
        Volt.log('[main-mypage-view.js] checkOptionMenu');
        var optionMenu = CommonContent.getOptionMenu();
        Volt.log('[main-mypage-view.js] checkOptionMenu optionMenu =' + optionMenu);
        if(optionMenu) {
            Volt.log('[main-mypage-view.js] checkOptionMenu OptionMenu ' + optionMenu.getOptionMenuState());
            if (optionMenu.getOptionMenuState()) {
                optionMenu.hide();
            }
        }
    },
    
    checkPopup : function(){
        Volt.log('[main-mypage-view.js] checkPopup');
        CommonContent.checkDeleteResultPopup();
        var result = CommonContent.isDeleteResultPopup();
        //var isDeleting = CommonContent.checkDeleteingPopup();
        if(result){
            this.bDeleteResultPopup = true;
        }
        
        if(!this.bDeleteResultPopup){
            ErrorHandling.destroyNavigatePopup();
        }
        
        //ErrorHandling.destroyNavigatePopup();
    },
    
    setVoiceGuide : function(data, fromItemIndex, toItemIndex,menuText){
        Volt.log('[main-mypage-view.js]setVoiceGuide isCheckBox = ' + isCheckBox);
        var voiceText = '';
        if (isCheckBox) { //in editMode
        	if (-1 == fromItemIndex) {
        		var gameListCnt = parseInt(MyPageModel.get('game_list_cnt'));
        		voiceText += optionName + ',' + Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', gameListCnt) 
                    + ',' + Volt.i18n.t('TV_SID_CHECKBOX_ACC');
        	} else {
        		voiceText += Volt.i18n.t('TV_SID_CHECKBOX_ACC');
        	}

        	if (isChecked[toItemIndex] == false) {
        		voiceText += ',' + Volt.i18n.t('TV_SID_UNCHECKED_KR_UN');
        	} else {
        		voiceText += ',' + Volt.i18n.t('TV_SID_CHECKED');
        	}
        	voiceText += ',' + data.title;

			//in update model and can't update this item
        	if (Volt.i18n.t('TV_SID_GAMES_6') == optionName && !voltApiWrapper.haveNewVersion(data.app_id)) {
        		voiceText = data.title + ',disabled';
        	}
        } else {
        	if (!isSigned) {
        		if (0 == toItemIndex) { //This is CouponBox
        			voiceText += Volt.i18n.t('TV_SID_COUPONS');
        		} else {
        			voiceText += data.title;
        		}
        	} else {
        		if (0 == toItemIndex) { //This is CouponBox
        			voiceText += Volt.i18n.t('TV_SID_COUPONS');
        		} else if (1 == toItemIndex) {
                    if(bStopVoiceGuide){
                        bStopVoiceGuide = false;
                        return;
                    }
                    
                    if(MyPageModel.get('nick_name')){
                        voiceText += MyPageModel.get('nick_name') + ',';
                    }
                    voiceText += Volt.i18n.t('TV_SID_EDIT_NICKNAME');
        		} else { //gridList except coupons and profiles
        			voiceText += data.title;
        		}
        	}
        }
        voiceText += '.';
        VoiceGuide.getVoiceGuide(voiceText);
    },

	addEventLog : function(eventName,options){
		Volt.log('[main-mypage-view.js] addEventLog eventName = ' + eventName + ',,,options = ' + options);
		if(!options){
			return;
		}
		
		Volt.KPIMapper.addEventLog(eventName, {d : options});
	},
	
    initGrid : function(downloadData) {
        var that = this;
        var GridlistTemplate = Volt.require('app/templates/1080/grid-list-template.js');
        var gridView = new Gridlist(GridlistTemplate.myPageNew, JSON.stringify(downloadData), parseInt(scene.width * 0.16875), parseInt(scene.height * 0.4));

        gridView.setItemData = function(mustache, modelData) {
            Volt.log('[main-mypage-view.js] setItemData modelData= ' + modelData);
            if (modelData.leftItemCnt) {
                Volt.log('[main-mypage-view.js] setItemData left item');
                mustache.leftItemCnt = modelData['leftItemCnt'];
                mustache.itemIndex = modelData['itemIndex'];
                mustache.isProfileItem = modelData['isProfileItem'];
            } else {
                Volt.log('[main-mypage-view.js] setItemData right item');
                
                mustache.imgUrl = (modelData['thumbnail_url']) ? modelData['thumbnail_url'] : '';
                mustache.title  = (modelData['game_title']) ? modelData['game_title'] : '';
                mustache.genre  = (modelData['genre']) ? modelData['genre'] : '';
                mustache.app_id = (modelData['app_id']) ? modelData['app_id'] : '';
                mustache.rating = (modelData['rating']) ? modelData['rating'] : '';
                mustache.controller_list = (modelData['controller_list']) ? modelData['controller_list'] : '';
            }
        };

        gridView.setItemTemplate = function(rendererInstance, parentWidth, parentHeight, data) {
            Volt.log('[main-mypage-view.js] setItemTemplate ');

            var thumbnailObj = rendererInstance.thumbnail;
            var rootWgt = rendererInstance.root;

            if (data.leftItemCnt) {
                if (isSigned) {
                    var userIcon = myPageSelf.getUserIcon();
                    var bgColor = myPageSelf.getProfileBgColor(userIcon);
                    rootWgt.color = {
                        r : bgColor.r,
                        g : bgColor.g,
                        b : bgColor.b,
                    };
                } else {
                    rootWgt.color = Volt.hexToRgb('#667fdc');
                }

                Volt.log('[main-mypage-view.js] setItemTemplate leftItemCnt = ' + data.leftItemCnt);
                myPageSelf.setItemTemplateLeft(rootWgt,thumbnailObj, parentWidth, parentHeight, data);
            } else {
                Volt.log('[main-mypage-view.js] setItemTemplate app_id= ' + data.app_id);
                CommonContent.setBlankStyle(rendererInstance, parentWidth, parentHeight);
                CommonContent.addThumbnailListener(rendererInstance.thumbnail);
                CommonContent.setFoverFactor(rendererInstance.thumbnail,parentWidth);
                this.onItemUpdate(rendererInstance, data , "mypage");
                this.onItemIconLoad(data, rendererInstance, 'mypage');
            }
        };

        gridView.onItemPress = function(itemData, groupIndex, itemIndex) {
            Volt.log('[main-mypage-view.js] onItemPress');
            if (itemData.leftItemCnt) {
                myPageSelf.onItemPressLeft(gridView,itemData, groupIndex, itemIndex);
                return;
            }
            if (voltApiWrapper.isAppUpdating(itemData.app_id)) {
                Volt.log("[main-mypage-view.js]app is updating, don't process enter key");
                return;
            }
            if (isCheckBox === true) {
                Volt.log("[main-mypage-view.js] onItemPress checkBox");
                var focusItem = gridView.widget.getFocusItemIndex();
                var index = focusItem.itemIndex;
                Volt.log("[main-mypage-view.js]In gridView.onItemPress index is ", index);
                Volt.log("[main-mypage-view.js]In gridView.onItemPress groupIndex : " + groupIndex + ",itemIndex :" + itemIndex);
                if(typeof isChecked[index] == 'undefined') {
                    Volt.log("Update case: this item have no update version. isChecked[" + index + "] = " + isChecked[index]);
                    return;
                }

                if (isChecked[index] == false) {
                    selectedCount = selectedCount + 1;
                    isChecked[index] = true;

                    if (selectedCount == checkableCount) {
                        Mediator.trigger("UPDATE_SELECT_ALL_STATE", true);
                    }
                    //set checkbox checked
                    gridView.widget.setCheckStatus(groupIndex, itemIndex, true,false);
                } else {
                    selectedCount = selectedCount - 1;
                    isChecked[index] = false;
                    if (selectedCount >= 0 && selectedCount < checkableCount) {
                        Mediator.trigger("UPDATE_SELECT_ALL_STATE", false);
                    }
                    //set checkbox unchecked
                    gridView.widget.setCheckStatus(groupIndex, itemIndex, false,false);
                }

                MultiSelection.updateSelectNum(selectedCount);
                if (selectedCount > 0) {
                    MultiSelection.enableDeleteBtn();
                } else {
                    MultiSelection.disableDeleteBtn();
                }
                return;
            }

            //var bLogInStatus = Utils.Account.getSignState();
            var bLogInStatus = voltApiWrapper.getSSOLoginState();
			//add KPI log
			var tempIndex = itemIndex + 1 - that.leftItemNum;
			var spValue  = Volt.KPIMapper.getSelectPosition(tempIndex);
			var options = {cp : 'G01_MYPAGE',appid:itemData.app_id,sp:spValue,content:'n/a',inputby:'',};
			
            if (bLogInStatus) {
                if (voltApiWrapper.haveNewVersion(itemData.app_id)) {
                    Volt.KPIParams.event = 'MYUPDATE';
					Volt.KPIParams.cp 	 = 'G01_MYPAGE';
					Volt.KPIParams.appid = itemData.app_id;
                    
                    myPageSelf.addEventLog('UPDATEPOP',{cp:'G01_MYPAGE',appid:itemData.app_id,sp:spValue,inputby:''});
                    ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_UPDATE_NEW_VERSION, itemData.app_id);
                    return;
                } else {
                    myPageSelf.addEventLog('EXEGAME',options);
                    voltApiWrapper.launchApp(itemData.app_id);
                }
            } else {
                Volt.log('[main-mypage-view.js] this app is installed and not login, pop up login');
                //CommonContent.setFlagInMypage(true);
                Volt.KPIParams.event = 'JUMPSSO';
                Volt.KPIParams.cp 	 = Volt.KPIMapper.getPageEvent().pageEvent;
                Volt.KPIParams.ssoby = 'game';
                
                myPageSelf.addEventLog('EXEGAME',options);
                myPageSelf.bGridPopup = true;
                ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_INSTALLED);
            }
        };

        gridView.fromFocusChangeStart = function(parent, parentWidth, parentHeight, data) {
            Volt.log("gridView  fromFocusChangeStart");
            //this.onTextScrollStart(parent);
        };

        gridView.toFocusChangeEnd = function(parent, parentWidth, parentHeight, data) {
            Volt.log("gridView  toFocusChangeEnd");
            //this.onTextScrollEnd(parent);
        };

        gridView.focusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
            itemIndex = toItemIndex;
            itemGroupIndex = toGroupIndex;
            Volt.log('[main-mypage-view.js] gridView.focusChanged itemIndex = ' + itemIndex + ',itemGroupIndex = ' + itemGroupIndex);
            //note:should consider longPress-->delete-->complete situation,will refine later
            if (toItemIndex >= 0 && toGroupIndex >= 0) {
                var data = gridList.allGroupDataArr[toGroupIndex][toItemIndex];
				Volt.pageItemIndex = toItemIndex + 1 - that.leftItemNum;
				myPageSelf.setVoiceGuide(data, fromItemIndex, toItemIndex,that.menuText);
				
				myPageSelf.lastFocusOnMypage = {
                    widgetType : "grid",
                    widget : myPageSelf.grid,
                    groupIndex : toGroupIndex,
                    itemIndex : toItemIndex,
                    view : "mypage",
                };
            }
            
            //added for progressbar position when enlarger is on
            if(fromGroupIndex >= 0 && fromItemIndex >= 0 && HALOUtil.enlarge){
                var renderer = this.widget.renderer(fromGroupIndex, fromItemIndex);
                if(renderer && renderer.thumbnail){
                    var lastThumbnail = renderer.thumbnail;
                    var bProgressbar = lastThumbnail.visibleStyles() & CommonDefine.ThumbnailStyle.THUMB_STYLE_PROGRESSBAR;
                    if (bProgressbar) {
                        var inforAlloc = lastThumbnail.getElementAllocation("information");
                        lastThumbnail.setElementAllocation("progressBar", {
                            x : 0,
                            y : inforAlloc.y,
                            width : inforAlloc.width,
                            height : 2,
                        });
                    }
                }
            }
            
            if(toGroupIndex >= 0 && toItemIndex >= 0 && HALOUtil.enlarge){
                var renderer = this.widget.renderer(toGroupIndex, toItemIndex);
                if(renderer && renderer.thumbnail){
                    var focusedThumbnail = renderer.thumbnail;
                    var bProgressbar = focusedThumbnail.visibleStyles() & CommonDefine.ThumbnailStyle.THUMB_STYLE_PROGRESSBAR;
                    if (bProgressbar) {
                        var inforAlloc = focusedThumbnail.getElementAllocation("information");
                        focusedThumbnail.setElementAllocation("progressBar", {
                            x : 0,
                            y : inforAlloc.y,
                            width : inforAlloc.width,
                            height : 2,
                        });
                    }
                }
            }
        };

        gridView.moveOut = function(gridList, directionString, fromGroupIndex, fromItemIndex) {
            Volt.log("[main-mypage-view.js] moveOut  " + directionString);
        };

        gridView.itemLoaded = function(gridList, groupIndex, itemIndex) {
            Volt.log("[main-mypage-view.js] itemLoaded  ");
            Volt.log("[main-mypage-view.js] itemLoaded  groupIndex: " + groupIndex + ",itemIndex: " + itemIndex);
            var data = gridList.getData(groupIndex, itemIndex);
            data.group = groupIndex;
            data.item = itemIndex;
        };

        gridView.updateElements = function(parent, data) {
            Volt.log('[main-mypage-view.js] updateElements');
            //this.onItemIconLoad(data, parent, 'mypage');
            var thumbnailObj = parent.thumbnail;
            Volt.log('[main-mypage-view.js] updateElements data.leftItemCnt = ' + data.leftItemCnt);
            Volt.log('[main-mypage-view.js] updateElements data.app_id = ' + data.app_id);
            
            if(data.leftItemCnt){
                switch(data.leftItemCnt) {
                    case 1 :
                        //login out and only coupon
                        //updateCouponNum(thumbnailObj);
                        break;
                    case 2 :
                        //login in with coupon and profile
                        if(isSigned){
                            if (0 == data.itemIndex) {
                                //updateCouponNum(thumbnailObj);
                            }
                            if (1 == data.itemIndex) {
                                myPageSelf.updateUserNickName(thumbnailObj);
                            }
                        } else {
                            //login out with message and coupon 
                            if (0 == data.itemIndex) {
                                //update message num
                            }
                            if (1 == data.itemIndex) {
                                //updateCouponNum(thumbnailObj);
                            }
                        }
                        
                        break;
                    case 3:
                        //login in with message box,coupon box and profile
                        if (0 == data.itemIndex) {
                            //update message num
                        }
                        if (1 == data.itemIndex) {
                            //updateCouponNum(thumbnailObj);
                        }
                        if (2 == data.itemIndex) {
                            myPageSelf.updateUserNickName(thumbnailObj);
                        }
                        break;
                    default :
                        break;
                }

            } else if(data.app_id) {
                this.onItemIconLoad(data, parent, 'mypage');
            }

        };

        gridView.resetElements = function(parent, data) {
            Volt.log('[main-mypage-view.js] resetElements');
            this.onItemIconReset(data);
        };
		this.gridView = gridView;
        
        return gridView.render().widget;
    },

    updateUserNickName : function(thumbnailObj) {
        var userNickName = MyPageModel.get('nick_name');
        if (userNickName && userNickName.length > 0) {
            thumbnailObj.setInformationText("text1", userNickName);
        } else {
            var account = Utils.Account.getAccount();
            Volt.log('[main-mypage-view.js] updateUserNickName ~~~~~ account =' + account);
            if (account && account.length > 0) {
                var temp = account.split('@')[0];
                Volt.log('[main-mypage-vieww.js] updateUserNickName ~~~~~ temp =' + temp);
                thumbnailObj.setInformationText("text1", temp); 
            } else {
                //thumbnailObj.setInformationText("text1", Volt.i18n.t('TV_SID_EDIT_NICKNAME')); 
                thumbnailObj.setInformationText("text1", "Register Nickname");
            }
        }
    },

    updateCouponNum : function(thumbnailObj) {
        var couponNum = MyPageModel.get('coupon_count');
        if (couponNum) {
            thumbnailObj.setInformationText("text2",couponNum.toString());
        }
    },

    updateUserEmail : function(thumbnailObj) {
        var userEmail = Utils.Account.getAccount();
        if (userEmail && userEmail.length > 0) {
            thumbnailObj.setInformationText("text2", userEmail);
        } else {
            thumbnailObj.setInformationText("text2", "lego@samsung.com");
        }
    },

    setItemTemplateLeft : function(rootWgt,thumbnailObj, parentWidth, parentHeight, data) {
        Volt.log('[main-mypage-view.js] setItemTemplateLeft leftItemCnt= ' + data.leftItemCnt);
        Volt.log('[main-mypage-view.js] setItemTemplateLeft itemIndex= ' + data.itemIndex);

        switch(data.leftItemCnt) {
            case 1:
                //login out and only Coupon
                myPageSelf.setItemTemplateCoupon(rootWgt,thumbnailObj,parentWidth,parentHeight);
                break;
            case 2:
                if (isSigned) {//login in with coupon box and profile,no msgbox
                    if (0 == data.itemIndex) {
                        myPageSelf.setItemTemplateCoupon(rootWgt,thumbnailObj,parentWidth,parentHeight);
                    }
                    if (1 == data.itemIndex) {
                        myPageSelf.setItemTemplateProfile(rootWgt,thumbnailObj,parentWidth,parentHeight);
                    }
                } else {//login out with message box and coupon box
                    if (0 == data.itemIndex) {
                        myPageSelf.setItemTemplateMessage(rootWgt,thumbnailObj,parentWidth,parentHeight);
                    }
                    if (1 == data.itemIndex) {
                        myPageSelf.setItemTemplateCoupon(rootWgt,thumbnailObj,parentWidth,parentHeight);
                    }
                }
                break;
            case 3:
                //login in with message box,coupon box and profile
                if (0 == data.itemIndex) {
                    myPageSelf.setItemTemplateMessage(rootWgt,thumbnailObj,parentWidth,parentHeight);
                }

                if (1 == data.itemIndex) {
                    myPageSelf.setItemTemplateCoupon(rootWgt,thumbnailObj,parentWidth,parentHeight);
                }

                if (2 == data.itemIndex) {
                    myPageSelf.setItemTemplateProfile(rootWgt,thumbnailObj,parentWidth,parentHeight);
                }

                break;
            default:
                break;
        }
    },
        
    setFoverForMsgAndCoupon : function(thumbnailObj){
        //thumbnail.setFoveaImageScaleFactor(0.06);
        //thumbnail.setFoveaImageInterpolatorType(0);
        
        thumbnailObj.setFoveaInfoBoxScaleFactor(0.06);
        thumbnailObj.setFoveaInfoBoxInterpolatorType(0);
    },
    
    createOverlay :function(rootWgt,parentWidth, parentHeight,alpa){
        Volt.log("[main-mypage-view.js] createOverlay alpa ="+ alpa);
        Volt.log("[main-mypage-view.js] createOverlay rootWgt ="+ rootWgt);
        var overlayWgt = new WidgetEx({
            parent : rootWgt,
            x : 0,
            y : 0,
            width : parentWidth,
            height : parentHeight,
            color : {
                r : 0,
                g : 0,
                b : 0,
                a : alpa
            },
        }); 

    },

    setItemTemplateMessage : function(rootWgt,thumbnailObj,parentWidth,parentHeight) {
        thumbnailObj.setInformationIcon("icon1",Volt.BASE_PATH + "images/1080/g_icon_massage.png");
        thumbnailObj.setInformationText("text1", "Message");
        myPageSelf.setFoverForMsgAndCoupon(thumbnailObj);
        myPageSelf.createOverlay(rootWgt,parentWidth,parentHeight,255 * 0.2);
    },

    setItemTemplateCoupon : function(rootWgt,thumbnailObj,parentWidth,parentHeight) {
        thumbnailObj.setInformationIcon("icon1",Volt.BASE_PATH + "images/1080/g_icon_coupon.png");
        thumbnailObj.setInformationText("text1", Volt.i18n.t('TV_SID_COUPONS'));
        //updateCouponNum(thumbnailObj);
        thumbnailObj.visualizeInformationText(false, "text2");
        thumbnailObj.visualizeInformationIcon(false,"icon2");
        myPageSelf.setFoverForMsgAndCoupon(thumbnailObj);
        if(isSigned){
            myPageSelf.createOverlay(rootWgt,parentWidth,parentHeight,255 * 0.15);
        } else {
            myPageSelf.createOverlay(rootWgt,parentWidth,parentHeight,255 * 0.1);
        }
    },

    setItemTemplateProfile : function(rootWgt,thumbnailObj,parentWidth,parentHeight) {
        var userThumbnail = myPageSelf.getUserIcon();
        var profileWidget = new WidgetEx({
            parent : thumbnailObj,
            x : scene.width * 0.042708,
            y : scene.height * 0.087037,
            width : 160,
            height : 160,
            cropOverflow : true,
            roundedCorners : {
                radius : 80.0,
                arcStep : 0.1
            },
        });
        var userImage = new ImageWidgetEx ({
            parent : profileWidget,
            x : 0,
            y : 0,
            width : 160,
            height : 160,
            src : userThumbnail,
        });
        myPageSelf.createOverlay(userImage,160,160,255 * 0.1);
        
        var userStroke = new ImageWidgetEx ({
            parent : profileWidget,
            x : 0,
            y : 0,
            width : 160,
            height : 160,
            src : Volt.BASE_PATH + "images/1080/common/g_thumb_id_stroke.png",
        });
        dimInProfile = new WidgetEx({
            parent : profileWidget,
            x : 0,
            y : 0,
            width : 160,
            height : 160,
            color : Volt.hexToRgb('#000000'),
            opacity : 0
        });
        
        myPageSelf.updateUserNickName(thumbnailObj);
        myPageSelf.updateUserEmail(thumbnailObj);
        
        //thumbnail.setFoveaImageScaleFactor(0.03);
        //thumbnail.setFoveaImageInterpolatorType(0);
        
        thumbnailObj.setFoveaInfoBoxScaleFactor(0.03);
        thumbnailObj.setFoveaInfoBoxInterpolatorType(0);
        myPageSelf.createOverlay(rootWgt,parentWidth,parentHeight,255 * 0.1);
    },

    getUserIcon : function() {
        var userThumbnail = null;
        if (isSigned) {
            var accountInfo = voltApiWrapper.getSSOLoginInfo();
            if(accountInfo && accountInfo.user_icon){
                var path = accountInfo.user_icon;
                Volt.log('[main-mypage-view.js]  userIcon :' + path);
                if (path.length > 0) {
                    var account_list = JSON.parse(path);
                    Volt.log('path:::' + account_list);
                    var bFound = false;
                    for (var i = 0; i < account_list.length; i++) {
                        if (account_list[i].hasOwnProperty('iconPath_173')) {
                            bFound = true;
                            var temp = account_list[i].iconPath_173;
                            if (temp && temp.length > 0) {
                                userThumbnail = temp;
                            } else {
                                Volt.log('[main-mypage-view.js] string of iconPath_173 is null');
                                userThumbnail = Volt.BASE_PATH + "images/1080/dummy/id_image_01.png";
                            }
                            break;
                        }
                    }

                    if (!bFound) {
                        Volt.log('[main-mypage-view.js] no iconPath_173 property');
                        userThumbnail = Volt.BASE_PATH + "images/1080/dummy/id_image_01.png";
                    }
                } else {
                    userThumbnail = Volt.BASE_PATH + "images/1080/dummy/id_image_01.png";
                }
            } else {
                userThumbnail = Volt.BASE_PATH + "images/1080/dummy/id_image_01.png";
            }
        }
        return userThumbnail;
    },

    getProfileBgColor : function(userIcon) {
        Volt.log('[main-mypage-view.js]  getProfileBgColor userIcon:' + userIcon);
        var suffixIndex = userIcon.search(/.png/i);
        //ignore uppercase and lowercase
        var subStr = userIcon.substr(suffixIndex - 2, 2);
        var thumbnailIndex = 1;
        if (subStr.indexOf('_') >= 0) {
            thumbnailIndex = parseInt(subStr.split('_')[1]);
        } else {
            thumbnailIndex = parseInt(subStr);
        }

        var bgColor = CommonContent.getProfileColorByIndex(thumbnailIndex);

        return bgColor;
    },

    onItemPressLeft : function(gridView,itemData, groupIndex, itemIndex) {
        var focusItem = gridView.widget.getFocusItemIndex();
        var index = focusItem.itemIndex;
        Volt.log("[main-mypage-view.js]onItemPressLeft index = " + index);
        var leftCnt = itemData.leftItemCnt;
        Volt.log("[main-mypage-view.js]onItemPressLeft leftCnt = " + leftCnt);
        
        var isEnabled = gridView.widget.isItemEnabled(groupIndex, itemIndex);
        if (isEnabled) {
            switch(leftCnt) {
                case 1:
                    //login out and only Coupon
                    myPageSelf.pressCouponWhenLoginOut();
                    break;
                case 2:
                    if (isSigned) {//login in with coupon box and profile,no msgbox
                        if (0 == index)
                            myPageSelf.pressCouponWhenLoginIn();
                        if (1 == index)
                            myPageSelf.pressProfileWhenLoginin();
                    } else {//login out with message box and coupon box
                        if (0 == index)
                            myPageSelf.pressMessageWhenLoginOut();
                        if (1 == index)
                            myPageSelf.pressCouponWhenLoginOut();
                    }
                    break;
                case 3:
                    //login in with message box,coupon box and profile
                    if (0 == index) {
                        //TBD
                        //pressMessageWhenLoginIn();
                    }

                    if (1 == index)
                        myPageSelf.pressCouponWhenLoginIn();
                    if (2 == index)
                        myPageSelf.pressProfileWhenLoginin();
                    break;
                default:
                    break;
            }
        }
    },

    pressCouponWhenLoginIn : function() {
        Volt.log('[main-mypage-view.js] pressCouponWhenLoginIn');
        myPageSelf.addEventLog('MOVECOUPON',{cp : 'G01_MYPAGE',inputby:'',});
        var bgColor = CommonContent.getProfileColor();
        Volt.log('[main-mypage-view.js] onCouponSelect bgColor.r = ' + bgColor.r);
        if(networkStatus.getNetWorkState()){
            Backbone.history.navigate('coupon', {
                trigger : true,
                bgColor : bgColor
            });
        } else {
            Volt.log('[main-my-page-view.js]network disconnected!!!!!!');
            ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR, '', 400);
        }
    },

    pressCouponWhenLoginOut : function() {
        Volt.log('[main-mypage-view.js] pressCouponWhenLoginOut');
        //CommonContent.setFlagInMypage(true);
        
        ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_COUPON);
    },

    pressProfileWhenLoginin : function() {
        Volt.log('[main-mypage-view.js] pressProfileWhenLoginin');
        myPageSelf.addEventLog('NICKCLICK',{cp : 'G01_MYPAGE',inputby:'',});
        myPageSelf.bGridPopup = true;

        var params = {
            "event" : "edit-name",
            "type" : 'input-text',
            'cp' : 'G01_MYPAGE',
            'from': 'click-profile',
            
        };
        Backbone.history.navigate('popup/' + JSON.stringify(params), {
            trigger : true
        });
    },

    pressMessageWhenLoginIn : function() {
        Volt.log('[main-mypage-view.js] pressMessageWhenLoginIn');

        Backbone.history.navigate('message', {
            trigger : true
        });
        var messagesCollection = Volt.require('app/models/messages-collection.js');
        messagesCollection.fetch(messagesCollection.mode.MODE_TEST);
    },

    pressMessageWhenLoginOut : function() {
        Volt.log('[main-mypage-view.js] pressMessageWhenLoginOut');
        ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_MESSAGE);
    },
        
    returnEditMode : function() {
        Volt.log("In function returnEditMode~~~");
        if (isCheckBox) {
            Volt.log("isCheckBox=== true");
            this.destoryMultiSelection();
            Mediator.off('EVENT_RETURN_EDIT_MODE', null, this);
        }
    },

    onDeleteMenu : function() {
        Volt.log('[main-mypage-view.js] onDeleteMenu');
        optionName = Volt.i18n.t('TV_SID_GAMES_7'); 
        Mediator.on('EVENT_RETURN_EDIT_MODE', this.returnEditMode, this);
        this.menuText = Volt.i18n.t('COM_SID_DELETE');
        MultiSelection.show(this.isButtonCreated, this.menuText, this.multiWidget);
        this.isButtonCreated = true;
        this.addCheckBox();
        Volt.setTimeout(function(){
            Volt.log('[main-mypage-view.js] onDeleteMenu set focus on grid,isActive =' + this.isActive);
            if(this.isActive){
                Volt.Nav.focus(this.grid);
            }
        }.bind(this), 1);
    },

    onUpdateMenu : function() {
        Volt.log('[main-mypage-view.js] onUpdateMenu');
        optionName = Volt.i18n.t('TV_SID_GAMES_6'); 
        Mediator.on('EVENT_RETURN_EDIT_MODE', this.returnEditMode, this);
        this.menuText = Volt.i18n.t('COM_SID_UPDATE');
        MultiSelection.show(this.isButtonCreated, this.menuText, this.multiWidget);
        this.isButtonCreated = true;
        this.addCheckBox();
        Volt.setTimeout(function(){
            Volt.log('[main-mypage-view.js] onUpdateMenu set focus on grid');
            if(this.isActive){
                Volt.Nav.focus(this.grid);
            }
        }.bind(this), 1);
        //this.updateCheckBox();
    },

    addCheckBox : function() {
        Volt.log("[main-mypage-view.js] addCheckBox.");
        //leftview unfocus
        for (var index = 0; index < this.leftItemNum; index++) {
            Volt.log("[main-mypage-view.js] addCheckBox set left items unfocusable");
            this.grid.enableItem(0, index, false);
            var renderer = this.grid.renderer(0, index);
            Volt.log("[main-mypage-view.js] addCheckBox renderer ="+renderer);
            Volt.log("[main-mypage-view.js] addCheckBox renderer.thumbnail ="+renderer.thumbnail);
            if (renderer && renderer.thumbnail) {
                var thumbnail = renderer.thumbnail;
                thumbnail.dim(true);
                thumbnail.setDimBackgroundColor({r:0, g:0, b:0, a:204});
            }
        }
        
        if(isSigned){
            if(dimInProfile) {
                dimInProfile.opacity = 204;
            }
        }
        
        Volt.Nav.reload();

        isCheckBox = true;
        checkableCount = 0;

        var data = MyPageModel.get('game_list');
        if (data.length === 0) {
            return;
        }
        //var totalCount = data.length;
        totalCount = this.leftItemNum + data.length;
        Volt.log("[main-mypage-view.js] totalCount is " + totalCount);
        
        if(this.leftItemNum < totalCount) {
            this.grid.setFocusItemIndex(0, this.leftItemNum);
        }
        
        if (this.isCheckBoxCreated === false) {
            Volt.log("[main-mypage-view.js] add CheckBox");
            this.isCheckBoxCreated = true;
            //create check box image
            switch(this.menuText) {
                case Volt.i18n.t('COM_SID_DELETE'):
                    for (var i = this.leftItemNum; i < totalCount; i++) {
                        this.addCheckBoxImage(i);
                    }
                    break;
                case Volt.i18n.t('COM_SID_UPDATE') :
                    for (var i = this.leftItemNum; i < totalCount; i++) {
                        var appID = data.at(i - this.leftItemNum).get('app_id');
                        if (voltApiWrapper.haveNewVersion(appID) && !voltApiWrapper.isAppUpdating(appID)) {
                            Volt.log('items have update version');
                            this.addCheckBoxImage(i);
                        } else {
                            Volt.log('items have no update version');
                            var renderer = this.grid.renderer(0, i);
                            Volt.log("[main-mypage-view.js] renderer ="+renderer);
                            Volt.log("[main-mypage-view.js] renderer.thumbnail ="+renderer.thumbnail);
                            if (renderer && renderer.thumbnail) {
                                var thumbnail = renderer.thumbnail;
                                thumbnail.dim(true);
                                thumbnail.setDimBackgroundColor({r:0, g:0, b:0, a:204});
                            }
                            
                        }
                    }
                    break;
                default :
                    break;
            }
        } else {
            //show check box image
            Volt.log("[main-mypage-view.js] show CheckBox");
        }
    },

    addCheckBoxImage : function(index) {
        //add checkbox image
        Volt.log("[main-mypage-view.js] addCheckBoxImage itemIndex " + index);
        //get item widget
        var Renderer = this.grid.renderer(0, index);
        Volt.log("[main-mypage-view.js] addCheckBoxImage Renderer ="+Renderer);
        Volt.log("[main-mypage-view.js] addCheckBoxImage Renderer.thumbnail ="+Renderer.thumbnail);
        if(Renderer && Renderer.thumbnail){
            var thumbnailObj = Renderer.thumbnail;
            thumbnailObj.visualizeThumbnailStyle(true, CommonDefine.ThumbnailStyle.THUMB_STYLE_CHECKBOX);
        }
        
        isChecked[index] = false;
        checkableCount++;
    },

    selectAllButtonCb : function(checkedFlag) {
        Volt.log("[my-page-view.js] selectAllButtonCb checkedFlag = " + checkedFlag);
        Volt.log("[my-page-view.js] selectAllButtonCb 00 selectedCount = " + selectedCount);
        if (checkedFlag) {
            this.selectedAll();
        } else {
            this.unSelectedAll();
        }
        
        Volt.log("[my-page-view.js] selectAllButtonCb 11 selectedCount = " + selectedCount);
        MultiSelection.updateSelectNum(selectedCount);

        if (selectedCount > 0) {
            MultiSelection.enableDeleteBtn();
        } else {
            MultiSelection.disableDeleteBtn();
        }
    },
    
    selectedAll : function(){
        Volt.log("[my-page-view.js] selectedAll checkableCount is " + checkableCount + " totalCount is " + totalCount);
        if (checkableCount === 0) {
            return;
        }
		var isLastItem = false;
        switch(this.menuText) {
            case Volt.i18n.t('COM_SID_DELETE') :
                selectedCount = checkableCount;
                for (var i = this.leftItemNum; i < totalCount; i++) {
                    isChecked[i] = true;
					if(i == totalCount - 1){
						isLastItem = true;
					}
                    this.grid.setCheckStatus(0, i, true,true,isLastItem);
                }
                break;
            case Volt.i18n.t('COM_SID_UPDATE') :
                for (var i = this.leftItemNum; i < totalCount; i++) {
                    selectedCount = checkableCount;
                    if (isChecked[i] === false) {
                        isChecked[i] = true;
						if(i == totalCount - 1){
							isLastItem = true;
						}
                        this.grid.setCheckStatus(0, i, true,true,isLastItem);
                    }
                }
                break;
            default :
                break;
        }
    },
    
    unSelectedAll : function(){
        Volt.log("[my-page-view.js] unSelectedAll checkableCount is " + checkableCount + " totalCount is " + totalCount);
        if (checkableCount === 0) {
            return;
        }

		var isLastItem = false;
        switch(this.menuText) {
            case Volt.i18n.t('COM_SID_DELETE') :
                selectedCount = 0;
                for (var i = this.leftItemNum; i < totalCount; i++) {
                    isChecked[i] = false;
					if(i == totalCount - 1){
						isLastItem = true;
					}
                    this.grid.setCheckStatus(0, i, false,true,isLastItem);
                }
                break;
            case Volt.i18n.t('COM_SID_UPDATE') :
                selectedCount = 0;
                for (var i = this.leftItemNum; i < totalCount; i++) {
                    if (isChecked[i] === true) {
                        isChecked[i] = false;
						if(i == totalCount - 1){
							isLastItem = true;
						}
                        this.grid.setCheckStatus(0, i, false,true,isLastItem);
                    }
                }
                break;
            default :
                break;
        }
    },

    deleteButtonCb : function() {
        if (this.menuText === Volt.i18n.t('COM_SID_DELETE')) {
            Volt.log('[main-mypage-view.js] Delete case');
            var data = MyPageModel.get('game_list');
            var count = 0;
            var app_id = [];
            //delete item(s)
            for (var i = this.leftItemNum; i < this.leftItemNum + data.length; i++) {
                if (isChecked[i] === true) {
                    var appID = data.at(i - this.leftItemNum).get('app_id');
                    Volt.log('[main-mypage-view.js] Delete case appID =' + appID);
                    app_id[count] = appID;
                    count++;
                }
            }

            if (count === 0) {
                Volt.log("No item selected");
                return;
            }
            
			var appIDStr = '';
			for(var i = 0;i < app_id.length;i++){
				if(0 == i){
					appIDStr += app_id[i];
				}else{
					appIDStr += '|' + app_id[i];
				}
			}
			
			Volt.KPIParams.event = 'MYDELETE';
			Volt.KPIParams.cp 	 = 'G01_MYPAGE';
			Volt.KPIParams.appid = appIDStr;
            ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_CHECK, app_id);

        } else if (this.menuText === Volt.i18n.t('COM_SID_UPDATE')) {
            Volt.log('[main-mypage-view.js] Update case');
            var data = MyPageModel.get('game_list');
			//add eventLog
			var appIDStr = '';
            var count = 0;
            var app_id = [];
			for (var i = this.leftItemNum; i < this.leftItemNum + data.length; i++) {
                if (isChecked[i] === true) {
                    app_id[count] = data.at(i - this.leftItemNum).get('app_id');
                    count++;
                }
            }

            for(var i = 0;i < app_id.length;i++){
                if(0 == i){
                    appIDStr += app_id[i];
                }else{
                    appIDStr += '|' + app_id[i];
                }
            }
            myPageSelf.addEventLog('MYUPDATE',{cp : 'G01_MYPAGE',appid:appIDStr,inputby:'',});
            
            for (var i = this.leftItemNum; i < this.leftItemNum + data.length; i++) {
                if (isChecked[i] === true) {
                    var appID = data.at(i - this.leftItemNum).get('app_id');
                    Volt.log('[main-mypage-view.js] Update app: ' + appID);
                    voltApiWrapper.updateApp(appID);
                    var param = {
                        app_id : appID,
                    };
                    Mediator.trigger(CommonDefine.Event.BEGIN_DOWNLOAD, param);
                    isChecked[i] = false;
                }
            }
            this.destoryMultiSelection();
        }
    },

    cancelButtonCb : function() {
        var data = MyPageModel.get('game_list');
        Volt.log("data.length is " + data.length);
        //destory multi-selection
        this.destoryMultiSelection();
    },

    destoryMultiSelection : function() {
        Volt.log('[main-mypage-view.js] destoryMultiSelection');
        //focusable = true
        for (var index = 0; index < this.leftItemNum; index++) {
            Volt.log("[main-mypage-view.js] addCheckBox set left items unfocusable");
            this.grid.enableItem(0, index, true);
            var renderer = this.grid.renderer(0,index);
            if(renderer && renderer.thumbnail){
                var thumbnail = renderer.thumbnail;
                thumbnail.dim(false);
            }
        }
        
        if (isSigned) {
            if(dimInProfile) {
                dimInProfile.opacity = 0;
            }
        }
        
        var data = MyPageModel.get('game_list');
        for (var index = this.leftItemNum; index < totalCount; index++) {
            var Renderer = this.grid.renderer(0, index);
            if(Renderer && Renderer.thumbnail){
                var thumbnailObj = Renderer.thumbnail;
                thumbnailObj.visualizeThumbnailStyle(false, CommonDefine.ThumbnailStyle.THUMB_STYLE_CHECKBOX);
                thumbnailObj.dim(false);
            }
        }

        Volt.Nav.reload();

        isCheckBox = false;
        selectedCount = 0;
        checkableCount = 0;
        totalCount = 0;
        isChecked = [];
        //destory button
        this.isCheckBoxCreated = false;
        this.menuText = null;
        Mediator.trigger('EVENT_MULTI_SELECTION_BLUR');
        Mediator.trigger('EVENT_DESTROY_MULTI_SELECTION');
        MultiSelection.hide();
    },

    processMsgBoxEvent : function(data) {
        Volt.log('[main-mypage-view.js] processMsgBoxEvent:type is:', data.msgBoxtype + " eventType is:" + data.eventType + data.appID);
        if (data.eventType == CommonDefine.Event.SELECT_BTN1) {
            switch(data.msgBoxtype) {
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS:
                    Volt.log('[main-mypage-view.js]SELECT_BTN1 :MSGBOX_TYPE_DELETE_SUNCCESS');
                    //Backbone.history.back();
                    if (isCheckBox == true) {
                        this.destoryMultiSelection();
                    }
                    
                    this.refresh();
                    break;
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_FAIL:
                    Volt.log('[main-mypage-view.js]SELECT_BTN1 :MSGBOX_TYPE_DELETE_FAIL');
                    if (isCheckBox == true) {
                        this.destoryMultiSelection();
                    }
                    break;
                
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_CHECK:
                    Volt.log('[main-mypage-view.js] begin delete');
                    MultiSelection.prepareHideMultiSelection();
                    Volt.setTimeout(function() {
                        //isChecked.length
                        Volt.log('[main-mypage.js] begin delete appNum = ' + data.appID.length);
                        if (data.appID.length > 1) {
                            CommonContent.showDeletePopup(true, data.appID);
                        } else {
                            CommonContent.showDeletePopup(false, data.appID);
                        }

                    }, 200);

                    break;
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_MESSAGE:
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_COUPON:
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_INSTALLED:
                    voltApiWrapper.startSSOPopup();
                    break;
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_UPDATE_NEW_VERSION:
                    Volt.log('[main-mypage-view.js]begin update appID:' + data.appID);
                    voltApiWrapper.updateApp(data.appID);
                    var tempData = {
                        app_id : data.appID,
                    };
                    Mediator.trigger(CommonDefine.Event.BEGIN_DOWNLOAD, tempData);
                    break;
                default:
                    //Backbone.history.back();
                    break;
            }
        } else if (data.eventType == CommonDefine.Event.SELECT_BTN2) {
            switch(data.msgBoxtype) {
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_UPDATE_NEW_VERSION:
                    Volt.log("[main-mypage-view.js]Don't update app, run directly:" + data.appID);
                    voltApiWrapper.launchApp(data.appID);
                    break;
                default:
                    break;
            }
        } else if (data.eventType == CommonDefine.Event.EVENT_CLOSE_POPUP) {
            switch(data.msgBoxtype) {
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS:
                    Volt.log('[main-mypage-view.js]EVENT_CLOSE_POPUP: MSGBOX_TYPE_DELETE_SUNCCESS');
                    //Backbone.history.back();
                    if (isCheckBox == true) {
                        this.destoryMultiSelection();
                    }
                    this.refresh();
                    break;
                default:
                    break;
            }
        }
    },

    updateProgressBar : function(eventInfo) {
        if (myPageSelf && myPageSelf.viewIsVisible == false) {
            return;
        }
        Volt.log('[main-mypage-view.js] updateProgressBar, ID = ' + eventInfo.app_id);
        myPageSelf.checkItem(eventInfo);
    },

    finishInstall : function(eventInfo) {
        if (myPageSelf && myPageSelf.viewIsVisible == false) {
            return;
        }
        Volt.log('[main-mypage-view.js] finishInstall, ID = ' + eventInfo.app_id);
        myPageSelf.checkItem(eventInfo);
    },
    
    checkItem : function(eventInfo){
        var index;
        var gamesList = MyPageModel.get('game_list');
        for ( index = myPageSelf.leftItemNum; index < myPageSelf.leftItemNum + gamesList.length; index++) {
            if(myPageSelf.grid){
                var itemCount = myPageSelf.grid.itemCount(0);
                if(index < itemCount){
                    var data = myPageSelf.grid.getData(0, index);
                    if (data.app_id == eventInfo.app_id) {
                        break;
                    }
                }
                
            }
        }
        Volt.log('[main-mypage-view.js] index = ' + index + ', game_list_cnt = ' + MyPageModel.get('game_list_cnt'));
        //update install icon
        //update progress bar
        if (index < myPageSelf.leftItemNum + gamesList.length && myPageSelf.grid) {
            var itemCount = myPageSelf.grid.itemCount(0);
            if (index < itemCount) {
                myPageSelf.grid.updateItem(0, index);
            }
        }
    },
});

exports = MyPageView;
