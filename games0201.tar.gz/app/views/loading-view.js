var Q            = Volt.require('modules/q.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var CommonDefine = Volt.require('app/common/common-define.js');
var WinsetLoading = Volt.require("WinsetUIElement/winsetLoading.js");
var LoadingTemplate = Volt.require('app/templates/1080/loading-template.js');
var VoiceGuide    = Volt.require('app/common/voiceGuide.js');
var Backbone    = Volt.require('lib/volt-backbone.js');
PanelCommon.mapWidget('WinsetLoading',WinsetLoading);
var Mediator          = Volt.require('app/common/event-mediator.js');

var LoadingView = PanelCommon.BaseView.extend({
	viewIsVisiable : false,
	type : 0, //default 01 loading
	viewLoading : null,
	popupLoading : null,
	loadingView : null,
	dimWgt : null,
	data : {},
	resoultion : null,
	bNoNeedBack : false,
	
	initialize : function() {
		this.data.style20=WinsetLoading.LoadingStyle.Loading_Dark_20;
        this.data.style14=WinsetLoading.LoadingStyle.Loading_Dark_14;
        
        this.dimWgt = PanelCommon.loadTemplate(LoadingTemplate.dimWgt,this.data);
        this.dimWgt.addEventListener("onMouseOver",function(){
            Volt.log('[loading-view.js]onMouseOver');
        });
        this.dimWgt.hide();
        var that = this;
        var list = new KeyboardListener();
        
        list.onKeyPressed = function() {
            Volt.log('[loading-view.js]onKeyPressed');
        };
        list.onKeyReleased = function(actor,keyCode) {
            Volt.log('[loading-view.js]onKeyReleased');
            if(keyCode == Volt.KEY_RETURN){
                that.hide();
                if(this.bNoNeedBack){
                    //for loading when coupon-register 
                    Mediator.trigger(CommonDefine.Event.NO_NEED_BACK_WHEN_CUT_LOADING);
                    this.bNoNeedBack = false;
                } else {
                    Backbone.history.back();
                }
            }
        }.bind(this);
        this.dimWgt.addKeyboardListener(list);
        this.viewLoading = this.dimWgt.getDescendant('viewLoading');
        this.popupLoading = this.dimWgt.getDescendant('popupLoading');
	},
    
	render: function() {
		
	},
	
	show : function(type,flag) {
		Volt.log("[loading-view.js]-----------------------show");
        var voiceGuide = Volt.i18n.t('COM_TV_SID_LOADING') + ',' + Volt.i18n.t('TV_SID_PLEASE_WAIT') + '.';
		VoiceGuide.getVoiceGuide(voiceGuide);
		Volt.Nav.block();
		var that =this;
		this.viewIsVisiable = true;
		var deferred =  Q.defer();
		this.type = type;
		if(flag){
		    this.bNoNeedBack = true;
		} else {
		    this.bNoNeedBack = false;
		}
		switch(type) {
			case CommonDefine.Const.VIEW_LOADING:
			case CommonDefine.Const.SWITCH_WHILE_LOADING:
				this.loadingView = this.viewLoading;
				break;
			case CommonDefine.Const.POPUP_LOADING:
				this.loadingView = this.popupLoading;
				break;
			default:
				this.loadingView = this.viewLoading;
		}
		
		scene.removeChild(that.dimWgt);
		scene.addChild(that.dimWgt);
		this.dimWgt.enableFocus(true);
		this.dimWgt.show();
		if(type == CommonDefine.Const.POPUP_LOADING){
			this.dimWgt.getChild('pupLoadingBg').show();
		}else{
			this.dimWgt.getChild('pupLoadingBg').hide();
		}
		//this.loadingView.imageFPS = 60;
		this.dimWgt.setFocus();
		this.loadingView.play();
		deferred.resolve();
		return deferred.promise;
	},
	
	hide : function() {
		Volt.log("[loading-view.js]-----------------------hide");
		var deferred = Q.defer();
		Volt.Nav.unblock();
		this.dimWgt.enableFocus(false);
		this.dimWgt.hide();
		if (this.loadingView) {
			this.loadingView.stop();
		}
		deferred.resolve();
		this.viewIsVisiable = false;
		return deferred.promise;
	},
});
exports =  new LoadingView();
