// Include libraries
var Backbone        	= Volt.require('lib/volt-backbone.js');
var Q               	= Volt.require('modules/q.js');
var CommonDefine    	= Volt.require('app/common/common-define.js');
var PanelCommon     	= Volt.require('lib/panel-common.js');
var CouponBoxModel  	= Volt.require('app/models/coupon-box-model.js');
var Utils           	= Volt.require('app/common/utils.js');
var EventMediator   	= Volt.require('app/common/event-mediator.js');
var Gridlist        	= Volt.require('app/views/grid-list-view.js');
var VoltApiWrapper  	= Volt.require("app/common/voltapi-wrapper.js");
var CommonContent       = Volt.require('app/common/common-content.js');
var DeviceModel 	    = Volt.require('app/models/device-model.js');
var SelectGamesTemplate = Volt.require('app/templates/1080/select-games-popup.js');
var VoiceGuide    = Volt.require('app/common/voiceGuide.js');

selectGamesSelf = null;
var SelectGamesPopup = PanelCommon.BaseView.extend({
    template : SelectGamesTemplate.container,
    params : null,
    winsetBackground : null,
    gameView : null,
    btnView : null,

    render : function() {
    },

    initialize : function() {
        print('[select-games-popup.js] initialize');
    },

    show : function(options, animationType) {
        print('[select-games-popup.js] show,options =' + options);
        this.params = JSON.parse(options);
        selectGamesSelf = this;
        
        this.winsetBackground = CommonContent.loadTemplateInWinsetBackgroud(this.template);
        this.setWidget(this.winsetBackground.getChild(0));
        this.winsetBackground.show();

        this.renderTitle();
        this.renderLine();
        this.renderDescription();
        this.renderGameGrid(this.params.couponNo, this.params.index);
        this.renderButton();

        Volt.Nav.setRoot(this.widget);
        Volt.Nav.focus(Volt.Nav.getItem(0));
    },

    renderTitle : function() {
        print('[select-games-popup.js] renderTitle');
        var container = this.widget.getChild('title-container');
        container.addChild(new titleView().render().widget);
    },

    renderLine : function() {
        print('[select-games-popup.js] renderLine');
        var container = this.widget.getChild('line-container');
        container.addChild(new lineView().render().widget);
    },

    renderDescription : function() {
        print('[select-games-popup.js] renderDescription');
        var container = this.widget.getChild('description-container');
        container.addChild(new description().render().widget);
    },

    renderGameGrid : function(couponNo, itemIndex) {
        print('[select-games-popup.js] renderGameGrid couponNo = ' + couponNo);
        var container = this.widget.getChild('grid-container');
        container.addChild(new gameGridView().render(container, couponNo, itemIndex).widget);
    },

    renderButton : function() {
        print('[select-games-popup.js] renderButton');
        var container = this.widget.getChild('button-container');
        container.addChild(new buttonView().render().widget);
    },

    hide : function() {
        print('[select-games-popup.js] hide');
        var deferred = Q.defer();
        
        Volt.Nav.focus(null);
        Volt.Nav.reset();
        
        if(this.gameView){
            this.gameView.destroy();
            this.gameView = null;
        }
        
        if(this.btnView){
            this.btnView.destroy();
        }
        
        if(this.winsetBackground){
            this.winsetBackground.hide();
            this.destroy(this.winsetBackground);
            this.winsetBackground.destroy();
            this.winsetBackground = null;
        }

        deferred.resolve();
        return deferred.promise;
    },

    destroy : function(widget) {
        if (!widget)
            return;
        var nChildLength = widget.getChildCount();
        if (nChildLength > 0) {
            for (var i = nChildLength - 1; i >= 0; i--) {
                this.destroy(widget.getChild(i));
            }
        }
    },
});

//template of title area
var titleView = PanelCommon.BaseView.extend({
    template : SelectGamesTemplate.title,

    render : function() {
        popupTitle = this;
        SelectGamesTemplate.title.children[0].text = Volt.i18n.t('TV_SID_SELECT_GAMES');
        this.setWidget(PanelCommon.loadTemplate(this.template));
        return this;
    }
});

//template of line area
var lineView = PanelCommon.BaseView.extend({
    template : SelectGamesTemplate.line,

    render : function() {
        this.setWidget(PanelCommon.loadTemplate(this.template));
        return this;
    }
});

//template of description area
var description = PanelCommon.BaseView.extend({
    template : SelectGamesTemplate.description,

    render : function() {
        SelectGamesTemplate.description.children[0].text = Volt.i18n.t('TV_SID_CAN_USE_COUPON_ON_THE_GAMES_BELOW')
            + Volt.i18n.t('TV_SID_EARN_REWARDS_FOR_PLAYING_GAMES') + "!\n" + Volt.i18n.t('TV_SID_SELECT_JUST_ONE_GAME');
        this.setWidget(PanelCommon.loadTemplate(this.template));
        return this;
    }
});

//template of text field area
var gameGridView = PanelCommon.BaseView.extend({
    grid : null,

    render : function(container, couponNo, itemIndex) {
        print('[select-games-popup.js] gameGridView render begin');
        selectGamesSelf.gameView = this;
        if (!this.widget.created) {
            var coupon_game_list = CouponBoxModel.get("coupon_list").at(itemIndex).get('game_list');
            var gameListCount = CouponBoxModel.get("coupon_list").at(itemIndex).get('game_list_count');
            
            var couponGameData = {
                style : CommonDefine.Const.HALO_ITEM_ALL_SAME,
                groups : [{
                    modelArr : coupon_game_list
                }]
            };

            var gridView = null;
            if(gameListCount ==2){
                gridView = new Gridlist(SelectGamesTemplate.grid2, JSON.stringify(couponGameData), parseInt(scene.width * 0.16875), parseInt(scene.height * 0.377778));
            }else if(gameListCount ==3){
                gridView = new Gridlist(SelectGamesTemplate.grid3, JSON.stringify(couponGameData), parseInt(scene.width * 0.16875), parseInt(scene.height * 0.377778));
            }

            gridView.setItemData = function(mustache, modelData) {
                mustache.imgUrl = modelData['thumbnail_url'];
                mustache.title = modelData['game_title'];
                mustache.appId = modelData['app_id'];
            };

            gridView.setItemTemplate = function(rendererInstance, parentWidth, parentHeight, data) {
                print('[select-games-popup.js] setItemTemplate');
                CommonContent.setBlankStyle(rendererInstance, parentWidth, parentHeight);
                CommonContent.addThumbnailListener(rendererInstance.thumbnail);
                CommonContent.setFoverFactor(rendererInstance.thumbnail,parentWidth);
                var thumbnailObj = rendererInstance.thumbnail;
                thumbnailObj.setContentImage(data.imgUrl);
                if (thumbnailObj.visibleStyles() & CommonDefine.ThumbnailStyle.THUMB_STYLE_INFO) {
                    thumbnailObj.setInformationText("text1", data.title);
                    thumbnailObj.visualizeInformationText(false,"text2");
                }
                thumbnailObj.visualizeThumbnailStyle(false, CommonDefine.ThumbnailStyle.THUMB_STYLE_PROGRESSBAR | CommonDefine.ThumbnailStyle.THUMB_STYLE_CHECKBOX);
                thumbnailObj.visualizeInformationIcon(false,"icon1");
                thumbnailObj.visualizeInformationRating(false);
            };

            gridView.onItemPress = function(itemData, groupIndex, itemIndex) {
                print("[select-games-popup.js] onItemPress itemIndex =" + itemIndex);

                Utils.Timer.clearTimeOut();
                //games is installed?
                var appId = itemData.appId;
                print("[select-game-popup.js] onItemPress, appId = " + appId);
                var installed = VoltApiWrapper.isWidgetInstalled(appId);
                print("[select-game-popup.js] onItemPress, installed = " + installed);
                var Renderer = this.widget.renderer(groupIndex, itemIndex);
                var itemBGColor = null;
                
                itemBGColor = Renderer.thumbnail.getInformationColorPicking();

                Volt.setTimeout(function(appId, itemBGColor, installed) {
                    if (installed) {
                        //run this game
                        VoltApiWrapper.launchApp(appId);
                    } else {
                        //enter into detail-view
                        //add EventLog
                        var spValue  = 'CCP' + Volt.KPIMapper.getIndexFormat(itemIndex + 1);
						Volt.KPIMapper.addEventLog('VIEWGAME', {
				            d : {
				                cp : 'G07_COUPON',
				                appid : appId,
				                sp:spValue,
				                content:'n/a',
				                inputby:'',
				            }
				        });
									
                        EventMediator.trigger("ENTER_INTO_DETAIL_FROM_POPUP");
                        if(itemBGColor){
                            var bgColor = JSON.parse(itemBGColor);
                            Backbone.history.navigate('detail/' + appId, {
                                trigger : true,
                                bgColor : bgColor
                            });
                        } else {
                            Backbone.history.navigate('detail/' + appId, {
                                trigger : true
                            });
                        }
                    }
                }, 200, appId, JSON.stringify(itemBGColor), installed);

                Backbone.history.back();
            };

            gridView.fromFocusChangeStart = function(parent, parentWidth, parentHeight, data) {
                Utils.Timer.clearTimeOut();
            };

            gridView.toFocusChangeEnd = function(parent, parentWidth, parentHeight, data) {
                //this.onTextScrollEnd(parent);
                Utils.Timer.setTimerOut();
            };

			gridView.focusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
				Volt.log('[select-games-popup.js] gridView.focusChanged ,fromItemIndex = ' + fromItemIndex + ',,,toItemIndex = ' + toItemIndex);
				if(toItemIndex >= 0 && toGroupIndex >= 0){
					var data = gridList.allGroupDataArr[toGroupIndex][toItemIndex];
					var voiceText = '';
		
					if(-1 == fromItemIndex){
						var gameCouts = Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>',CouponBoxModel.get("coupon_list").at(itemIndex).get('game_list_count'));
						voiceText += SelectGamesTemplate.title.children[0].text + ', ' + SelectGamesTemplate.description.children[0].text + ',' + gameCouts + ',';
					}

					voiceText += data.title + '.';
					VoiceGuide.getVoiceGuide(voiceText);
				}
			};
			
            this.grid = gridView.render().widget;
            this.grid.focusable = true;
            this.setWidget(this.grid);
            this.widget.created = true;
        }

        print('[select-games-popup.js] gameGridView render end');
        return this;
    },

    events : {
        NAV_FOCUS : 'onFocus',
        NAV_BLUR : 'onBlur'
    },

    onSelect : function() {
        //Backbone.history.navigate('detail/' + this.model.get('id'), {trigger: true });
    },

    onFocus : function(widget) {
        print('[select-games-popup.js] gameGridView.onFocus');
        if (this.grid) {
            widget = this.grid;
            Volt.Nav.focus(this.grid);
            widget.onFocus();
        }
    },
    
    onBlur : function(widget) {
        print('[select-games-popup.js] gameGridView.onBlur');
        if (widget) {
            if (selectGamesSelf.gameView.grid) {
                widget.onBlur();
            }
        }
    },

    destroy : function() {
        if(selectGamesSelf.gameView.grid){
            selectGamesSelf.gameView.grid.destroy();
        }
    }
});

//template of button area
var buttonView = PanelCommon.BaseView.extend({
    template : SelectGamesTemplate.button,
    btn1 : null,
	btnListener : new ButtonListener(),
	
    render : function() {
        print('[select-games-popup.js] buttonView.render');
        selectGamesSelf.btnView = this;
        //var that = this;
        this.btnListener.onButtonClicked = function(button,type){
        	selectGamesSelf.btnView.onSelectCloseButton();
        };
        
    	var btnStyle = {
		style : CommonDefine.Winset.BUTTON_IMAGE_O_STYLE_F_FOCUS1,
		buttonType : CommonDefine.Winset.BUTTON_TEXT,
		};
        this.setWidget(PanelCommon.loadTemplate(this.template,btnStyle));
        this.btn1 = this.widget.getDescendant("cancelBtn");
        this.btn1.addListener(selectGamesSelf.btnView.btnListener);
        return this;
    },
    events : {
        'NAV_FOCUS #Close' : 'onFocusCloseButton',
    },

    onSelectCloseButton : function(widget) {
        print('[select-games-popup.js] buttonView.onSelect');
       	Backbone.history.back();
        Utils.Timer.clearTimeOut();
    },

    onFocusCloseButton : function(widget) {
        print('[select-games-popup.js] buttonView.focus');
        var voiceGuide = Volt.i18n.t('COM_SID_CLOSE') + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
        VoiceGuide.getVoiceGuide(voiceGuide);
        this.btn1.setFocus();
        Utils.Timer.setTimerOut();
    },
    
    destroy : function(){
        Volt.log('[select-games-popup.js] buttonView destroy');
        if(this.btn1){
            this.btn1.destroy();
            this.btn1 = null;
        }
        if(this.widget){
            this.widget.destroyChildren();
            this.widget.destroy();
            this.widget = null;
        }
    }
});

exports = SelectGamesPopup;
