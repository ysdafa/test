var DeviceModel = Volt.require('app/models/device-model.js');
var voltapi     = Volt.require("voltapi.js");//add test api by chenry
var Mediator    = Volt.require('app/common/event-mediator.js');
var CommonDefine= Volt.require('app/common/common-define.js');

var bReady = false;
var ServerController = {
    
    init :function(){
        Mediator.on(CommonDefine.Event.WAS_READY, this.onWASReady, this);
    },
    
    onWASReady : function(){
        Volt.log('onWASReady.......');
        if (false === voltapi.rest.isOpened()) {
            Volt.log('rest client is not opened');
            bReady = voltapi.rest.init();
        }
        Mediator.trigger('SERVER_API_READY');
    },
    
    onRestReady: function(is_success){
        Volt.log('onRestReady......., success or not:::'+is_success);
        var retry = 0;
        bReady = is_success;
        if(is_success){
            Volt.log('rest initialize success');
            Mediator.trigger('SERVER_API_READY');
        } else {
            Volt.log('rest initialize fail, retry:::'+retry);
            if(retry < 1){
                voltapi.rest.initAsync(this.onRestReady);
                retry++;
            }
        }
    },
    
    isReady : function(){
        return bReady;
    },

    callAPI : function(requestInfo, param) {
        Volt.log('[Server-controller] callAPI() [' + requestInfo.type + '] ' + requestInfo.url);
        
        if(!bReady){
            Volt.log('Server API is not ready, must wait for ok!!!!');
            return;
        }
        
        var onSuccess  = param.success;
        var onError    = param.error;
        var onComplete = param.complete;
        var bodyData;
        
        voltapi.rest.clearParam();
        voltapi.rest.clearBody();

        //set related
        voltapi.rest.setContentType("json");
        voltapi.rest.setSmartTVHeader(true);
        voltapi.rest.setHeader("Country",   DeviceModel.get("countryCode"));
        voltapi.rest.setHeader("Language",  DeviceModel.get("languageCode"));
        voltapi.rest.setHeader("ModelID",   DeviceModel.get("modelId"));
        voltapi.rest.setHeader("Bluetooth", DeviceModel.get("bluetooth"));
        voltapi.rest.setHeader("Resolution",DeviceModel.get("resolutionY"));
           
        
        if(requestInfo.type == 'PUT' || requestInfo.type == 'POST') {
            bodyData = JSON.stringify(param.bodyValue);
            print('[Server-controller] body value is:' + bodyData);
            voltapi.rest.setBody(bodyData);
        }

        voltapi.rest.sendAsync(requestInfo.type, requestInfo.url,
            function(data, status, response) {
                onSuccess(data,status,response);
            },
            function(response, status, exception) {
                onError(response, status, exception);
            },
            function(response, status) {
                onComplete(response, status);		
            },
			function(id){
				//something need to be done
			}
        );
    },

    cancel : function() {
        if (true === voltapi.rest.isOpened()) {
            print('[Server-controller] Cancel');
            voltapi.rest.cancel();
        }
    },

    // get a service url by serviceType
    getServiceUrl : function(serviceType) {
        if (serviceType == "development") {
            return "osbstg.samsungcloudsolution.com";
        } else if (serviceType == "oprating") {
            return "osb.samsungcloudsolution.com";
        } else if (serviceType == "developing") {
            return "54.254.101.89";
        }
    },

    // get a host by serviceType
    getHost : function(serviceType) {
        if (serviceType == "development") {
            return "gamestg.internetat.tv";
        } else if (serviceType == "oprating") {
            return "game.internetat.tv";
        } else if (serviceType == "developing") {
            return "54.254.101.89";
        }
    }
}

exports = ServerController;