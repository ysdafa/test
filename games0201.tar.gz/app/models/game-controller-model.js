/**
 * @author sunlj
 */
var Backbone = Volt.require("modules/backbone.js");

var GameControllerModel = Backbone.Model.extend({
	defaults : {
		'page' : null,
		'section_type' : null,
		'page_section' : null,
		'controller_name' : null,
		'controller_url' : null,
		'controller_url_list' : [],

	},
	
	initialize : function (models, options) {},

	fetch : function (options) {
		var self = this;
		var controller_url_list = self.get("controller_url_list");
	}
})

	exports = GameControllerModel;