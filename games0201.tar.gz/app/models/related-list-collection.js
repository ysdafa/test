var Backbone = Volt.require("lib/volt-backbone.js");
var RelatedListModel = Volt.require("app/models/related-list-model.js");

var RelatedListCollection = Backbone.Collection.extend({
        model : RelatedListModel,
        
    });

exports = RelatedListCollection;
