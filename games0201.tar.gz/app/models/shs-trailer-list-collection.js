var Backbone = Volt.require("lib/volt-backbone.js");
var ShsTraillerListModel = Volt.require("app/models/shs-trailer-list-model.js");

var ShsTrailerListCollection = Backbone.Collection.extend({
        model : ShsTraillerListModel,
        
    });

exports = ShsTrailerListCollection;
