var Backbone = Volt.require("lib/volt-backbone.js");
var GenreListCollection = Volt.require("app/models/genre-collection.js");
/** @lends GamesModel.prototype */
var GenreModel = Backbone.Model.extend({
    defaults : {
        'stat' : null,    //'ok'   
        'category_id' : null,
		'category_name' : null,
        'genre_list_cnt' : null
    },
    initialize : function(models, options) {
        this.set('genre_list', new GenreListCollection());
    },

    fetch:function(options){
            
    },
            
    parse:function(data){
    	var parsonData = JSON.parse(data);
		if(!parsonData.rsp.hasOwnProperty('C0060')){
			return;
		}
    	this.set('category_id',   parsonData.rsp.C0060.category_id);
		this.set('category_name', parsonData.rsp.C0060.category_name);
		this.set('genre_list_cnt',parsonData.rsp.C0060.list_cnt);
           
        var genre_list = this.get('genre_list');
        genre_list.reset(parsonData.rsp.C0060.list_data);
            
    }
});
exports = new GenreModel();