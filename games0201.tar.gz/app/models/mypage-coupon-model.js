var Backbone = Volt.require("lib/volt-backbone.js");
var CouponCollection = Volt.require("app/models/coupon-collection.js");
var ServerController = Volt.require('app/controller/server-controller.js');
var Q = Volt.require('modules/q.js');

/** @lends GamesModel.prototype */
var MyPageCouponModel = Backbone.Model.extend({
    defaults : {
        'coupon_list_cnt' : null,
    },
    
    initialize : function(models, options) {
        this.set('coupon_list', new CouponCollection());
    },  
    
    fetch: function(options){
        var deferred =  Q.defer()
        , self = this;
       
		var _rest = "game/user/v2/coupon/coupons";
		print("[mypage-coupon-model.js] process a get request:" + _rest);
		ServerController.callAPI({
		        type: 'GET',
		        url: _rest
		    },
		    {
		    	bodyValue: {},
				success : function(data, status, response) {
		            print("[mypage-coupon-model.js] success result:" + data);
		            self.parse(data,status,response);  
		            deferred.resolve();    
		        },
		        error : function(response, status, exception) {
		            print("[mypage-coupon-model.js] error result:" + exception + JSON.stringify(response));
		        	deferred.reject(exception);
		        },
		        complete: function(response, status) {   
		            print("[mypage-coupon-model.js] " + status);	
		        }
		    }
		);
        return deferred.promise;
    },

	post: function() {



    },
    
    parse: function(data){
        var parseData = JSON.parse(data);
        this.set('coupon_list_cnt', parseData.rsp.coupon_list_cnt);
		
        var mypage_coupon_list = this.get('coupon_list');
        mypage_coupon_list.reset(parseData.rsp.coupon_list);
    },
});
exports = new MyPageCouponModel();