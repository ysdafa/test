var Backbone = Volt.require("lib/volt-backbone.js");
var RelatedListModel = Backbone.Model.extend({
    defaults : {
          'thumbnail_url' : null, 
          'related_app_id' : null
    },
    initialize : function(models, options) {

    },
    parse : function(response) {

    }
})

var initialize = function() {

}
function onKeyEvent(keycode) {

}

exports = RelatedListModel; 