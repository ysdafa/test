var Backbone = Volt.require("lib/volt-backbone.js");
var GameListCollection = Volt.require("app/models/game-list-collection.js");
var ServerController = Volt.require('app/controller/server-controller.js');
var Q=Volt.require("modules/q.js");
/** @lends GamesModel.prototype */
var GenreModel = Backbone.Model.extend({
	defaults : {
		'stat' : null, //'ok'
		'category_id' : null,
		'list_cnt' : null,
		'genre_group_name' : null,
		'genre_group_id' : null,
        'genre_group_cnt': null,
        'genre_group_list': null,
	},
	initialize : function(models, options) {
		this.set('data_list', new GameListCollection());
        this.set('genre_group_list', new GameListCollection());
	},

    fetch:function(options){
		var deferred =  Q.defer();
		var self = this;

		var _rest;
		if(options == null || options == undefined) {
			_rest = "game/recommend/v2/main/categories";
		} else {
			if(options.path != undefined && options.path != null && options.path != '') {
				_rest = "game/recommend/v2/main/category/" + options.path;
			} else {
				print("[genre-detail-model.js] error: lack url path param ");
				return;        
			}
		}
		print("[genre-detail-model.js] process a get request:" + _rest);
		
		ServerController.callAPI({
		        type: 'GET',
		        url: _rest
		    },
		    {
		    	bodyValue: {},
				success : function(data, status, response) {
		            print("[genre-detail-model.js] success result:" + data);
                            var id = options.path.split('?')[0];
                            print('id::::::::'+id);
		            self.parse(data,id);  
		            deferred.resolve();    
		        },
		        error : function(response, status, exception) {
		            print("[genre-detail-model.js] error result:" + exception + JSON.stringify(response));
		        	deferred.reject(response);
		        },
		        complete: function(response, status) {   
		            print("[genre-detail-model.js] " + status);	
		        }
		    }
		);
        return deferred.promise;      
    },
         
	stopRequestData : function() {
		ServerController.cancel();
	},
	
	parse : function(data, id) {
		var parsonData = JSON.parse(data);
		if(parsonData.rsp && parsonData.rsp[id] && parsonData.rsp[id].hasOwnProperty('list_cnt')){
		    this.set('list_cnt', parsonData.rsp[id].list_cnt);
	        var data_list = this.get('data_list');
	        data_list.reset(parsonData.rsp[id].list_data);
        }
	},
	
	parseGenre : function(data) {
		var parsonData = JSON.parse(data);
		this.set('genre_group_name', parsonData.rsp.genre_group_name);
		this.set('genre_group_id', parsonData.rsp.genre_group_id);
                this.set('genre_group_cnt', parsonData.rsp.genre_group_cnt);
                var data_list = this.get('genre_group_list');
		data_list.reset(parsonData.rsp.genre_group_list);
	},

	clear : function() {
		print("[-----------] clear data");
		this.set('genre_group_cnt', 0);
		var data_list = this.get('genre_group_list');
		data_list.reset(null);
	}
});
exports = GenreModel;
