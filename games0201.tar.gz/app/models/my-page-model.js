var Backbone = Volt.require("lib/volt-backbone.js");
var GameListCollection = Volt.require("app/models/game-list-collection.js");
var ServerController = Volt.require('app/controller/server-controller.js');
var voltApiWrapper = Volt.require("app/common/voltapi-wrapper.js");
var Q = Volt.require('modules/q.js');
var localStorage      = Volt.require("lib/volt-local-storage.js");

/** @lends GamesModel.prototype */
var MyPageModel = Backbone.Model.extend({
    defaults : {
		'category_id' : null,
		'category_name' : null,
        'game_list_cnt' : null,
        'nick_name':null,
        'coupon_count':null,
    },
    
    initialize : function(models, options) {
        this.set('game_list', new GameListCollection());
    },  
    
    fetch:function(options){
        var deferred =  Q.defer()
        , self = this;

		var _rest = "game/user/v2/installed/games";
		//set native game list as param
		var nativeList = voltApiWrapper.getNativeGameList();
		var param = '';
		if(nativeList.length > 0) {
			param = '?app_ids=';
			for(var i = 0; i < nativeList.length; i++) {
				print('nativeList[' + i + ']=' + nativeList[i] + ' ' + nativeList[i].appID);
				param = param + nativeList[i].appID;
				if(i < nativeList.length - 1) {
					param = param + '%2c';
				}
			}
		}
		_rest = _rest + param;
		print("[my-page-model.js] process a get request:" + _rest);
		ServerController.callAPI({
		        type: 'GET',
		        url: _rest
            },{
                bodyValue: {},
                success : function(data, status, response) {
                    print("[my-page-model.js] success result:" + data);
                    self.parse(data,status,response);  
                    deferred.resolve();    
                },
                error : function(response, status, exception) {
                    print("[my-page-model.js] error result:" + exception + JSON.stringify(response));
                    deferred.reject(response);
                },
                complete: function(response, status) {   
                    print("[my-page-model.js] " + status);	
                }
            }
		);
        return deferred.promise;
    },

    fetchMyPage: function(path){
        var deferred =  Q.defer()
		, self = this;
		print("[my-page-model.js] fetchMyPage fetch1");
		var _rest;
	 
		   if(path != undefined && path != null && path != '') {
		       _rest = "game/recommend/v2/main/category/" + path;
		   } else {
		      print("[my-page-model.js] fetchMyPage error: lack url path param ");
		      return;        
		   }
		

		print("[my-page-model.js] process a request");
		ServerController.callAPI({
	            type: 'GET',
	            url: _rest
	        },{
	        	bodyValue: {},
				success : function(data, status, response) {
	                print("[[my-page-model.js]------------fetchMyPage callback-----------] success result:" + data);
		            self.parseMyPage(data,status,response);
		            deferred.resolve();    
	            },
	            error : function(response, status, exception) {
	                print("[[my-page-model.js]------------fetchMyPage callback-----------] error result:" + exception + JSON.stringify(response));
	            	deferred.reject(response);
	            },
	            complete: function(response, status) {   
	                print("[[my-page-model.js]------------fetchMyPage completeCallback-----------] " + status);	
	            }
	        }
		);

        return deferred.promise;
    },
    
    parse: function(data,status,response){
		var parsonData = JSON.parse(data);
		this.set('game_list_cnt', parsonData.rsp.game_list_cnt);
        
        var mypage_list = this.get('game_list');
        mypage_list.reset(parsonData.rsp.game_list);
    },
    
    parseMyPage: function(data,status,response){
        Volt.log("[my-page-model.js] parseMyPage ");
        var parsonData = JSON.parse(data);
		if(!parsonData.rsp.hasOwnProperty('C0070')){
			return;
		}
		
        this.set('category_name', parsonData.rsp.C0070.category_name);
		this.set('nick_name',     parsonData.rsp.C0070.mypage.nick_name);
        this.set('coupon_count',  parsonData.rsp.C0070.mypage.coupon_count);
        
        var caching = localStorage.getItem('main-category');
        var strCaching = JSON.stringify(caching);
        if(caching && strCaching.length > 0){
            var parsonCache = JSON.parse(caching);
            var cachNickName = parsonCache.rsp.C0070.mypage.nick_name;
            Volt.log("[my-page-model.js] parseMyPage  cachNickName =" + cachNickName);
            Volt.log("[my-page-model.js] parseMyPage  realNickName =" + this.get('nick_name'));
            if (cachNickName != this.get('nick_name')) {
                parsonCache.rsp.C0070.mypage.nick_name = this.get('nick_name');
                localStorage.setItem('main-category', JSON.stringify(parsonCache));
            }
        }
    }
});
exports = new MyPageModel();