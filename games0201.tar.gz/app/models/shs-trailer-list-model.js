var Backbone = Volt.require("lib/volt-backbone.js");
var ShsTraillerListModel = Backbone.Model.extend({
    defaults : {
          'source_type' : null,
          'screenshot_url' : null, 
          'trailer_id' : null,
          'trailer_title' : null
    },
    initialize : function(models, options) {

    },
    parse : function(response) {

    }
})

var initialize = function() {

}
function onKeyEvent(keycode) {

}

exports = ShsTraillerListModel; 