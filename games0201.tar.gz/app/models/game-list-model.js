var Backbone = Volt.require("lib/volt-backbone.js");
var ControllerListCollection = Volt.require("app/models/controller-list-collection.js");
var GameListModel = Backbone.Model.extend({
    defaults : {
          'no' : null,
          'fix_game' : null, 
          'game_title' : null, 
          'app_id' : null,
          'genre' : null,
          'rating' : null,
          'description' : null,
          'thumbnail_url' : null,
          'app_icon_url' : null,
          'size' : null,     
          'price' : null,
          'currency' : null,
          'game_age_rating' : null, 
          'version' : null, 
          'downloadable' : null,
          'controller_list' : null
    },
    initialize : function(models, options) {
        this.set('controller_list', new ControllerListCollection());
        var controller_list = this.get('controller_list');
        if(models.controller_list) {
            controller_list.reset(models.controller_list);
//            print('%%%%%%%%%%%%% GameListModel initialize - controller_list ' + JSON.stringify(models.controller_list));
        }
        if(models.size_comp && models.size_uncomp){
//            Volt.log("[game-list-model.js] recount size");
            models.size = parseInt(models.size_comp) + parseInt(models.size_uncomp) + 10;
            this.set('size', models.size);
        }
    },
    parse : function(response) {
    }
});

var initialize = function() {

};
function onKeyEvent(keycode) {

}

exports = GameListModel; 