/**
 * @author tiansx
 * @20140702
 */

var Backbone = Volt.require("lib/volt-backbone.js");

//var CouponBoxModel = Volt.require('app/models/coupon-box-model.js');

var CouponGamesCollection = Backbone.Collection.extend({
//    model: CouponBoxModel,
    
    mode: {
        MODE_TEST: 3,
    },
        
    fetch: function(mode) {
        //if (mode == this.mode.MODE_TEST) {
         //   print("Jenny coupon-collection === couponGamesList");
            this.reset(__couponGamesList);
        //}        
        
    },
});

exports = new CouponGamesCollection();


var __couponGamesList = [
{
    couponId:'0',    
    subTitle:"30% off event!",              
    imgurl1:Volt.BASE_PATH +'images/1080/games/1.jpg',
    title1:"No Man Land",
    rcolor1:{r:82, g:72, b:36},
    imgurl2:Volt.BASE_PATH +'images/1080/games/1.jpg',
    title2:"Iron Man",
    rcolor2:{r:255, g:177, b:92},
    imgurl3:Volt.BASE_PATH +'images/1080/games/1.jpg',  
    title3:"Tom & Jerry",       
    rcolor3:{r:51, g:97, b:255},
},
{
    couponId:'1',
    subTitle:"30% off event!", 
    imgurl1:Volt.BASE_PATH +'images/1080/games/1.jpg',
    title1:"Iron Man",
    rcolor1:{r:255, g:177, b:92},
    imgurl2:Volt.BASE_PATH +'images/1080/games/1.jpg',
    title2:"Tom & Jerry",
    rcolor2:{r:51, g:97, b:255},
},
{
    couponId:'2',
    subTitle:"30% off event!", 
    imgurl1:Volt.BASE_PATH +'images/1080/games/1.jpg',
    title1:"Reloaded",
    rcolor1:{r:108, g:233, b:133},
},
{
    couponId:'3',    
    subTitle:"30% off event!", 
    imgurl1:Volt.BASE_PATH +'images/1080/games/1.jpg',
    title1:"Reloaded",
    rcolor1:{r:108, g:233, b:133},
    imgurl2:Volt.BASE_PATH +'images/1080/games/1.jpg',
    title2:"Lord of the Rings",
    rcolor2:{r:0, g:152, b:135},
    imgurl3:Volt.BASE_PATH +'images/1080/games/1.jpg',
    title3:"Death Race",
    rcolor3:{r:171, g:171, b:169},
},
{
    couponId:'4',
    subTitle:"30% off event!", 
    imgurl1:Volt.BASE_PATH +'images/1080/games/1.jpg',
    title1:"Death Race",
    rcolor1:{r:171, g:171, b:169},
    imgurl2:Volt.BASE_PATH +'images/1080/games/1.jpg',
    title2:"The Oxford Murders",
    rcolor2:{r:0, g:0, b:0}
}
];
