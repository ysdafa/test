var Backbone = Volt.require("lib/volt-backbone.js");
var GameListModel = Volt.require("app/models/game-list-model.js");

var GameListCollection = Backbone.Collection.extend({
        model : GameListModel,
        
    });

exports = GameListCollection;
