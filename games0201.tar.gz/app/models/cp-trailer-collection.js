var Backbone = Volt.require("lib/volt-backbone.js");
var CPTraillerListModel = Volt.require("app/models/cp-trailer-list-model.js");

var CPTrailerListCollection = Backbone.Collection.extend({
        model : CPTraillerListModel,
        
    });

exports = CPTrailerListCollection;
