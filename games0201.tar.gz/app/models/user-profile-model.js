/**
 * @author tiansx
 * @20140722
 */
var Backbone = Volt.require("modules/backbone.js");
var ServerController = Volt.require('app/controller/server-controller.js');
var Q=Volt.require('modules/q.js');
/** @lends GamesModel.prototype */
var UserProfileModel = Backbone.Model.extend({
    defaults : {
        'stat' : null,    //'ok'   
        'nick_name' : null,
        'thumbnail_url':null,
        'email_id':null,
        'message_count' : null,
        'coupon_count' : null, 
    },
    initialize : function(models, options) {
    	self = this;
        //this.set('mypage_list', new GameListCollection());
    },
        
    fetch:function(options) {
		var deffered=Q.defer();
		var _rest = "game/user/v2/profile";
		print("[user-profile-model.js] process a get request:" + _rest);
		ServerController.callAPI({
		        type: 'GET',
		        url: _rest
		    },
		    {
		    	bodyValue: {},
				success : function(data, status, response) {
		            print("[user-profile-model.js] success result:" + data);
		            self.parse(data,status,response);  
		            deffered.resolve();    
		        },
		        error : function(response, status, exception) {
		            print("[user-profile-model.js] error result:" + exception + JSON.stringify(response));
		        	deffered.reject(exception);
		        },
		        complete: function(response, status) {   
		            print("[user-profile-model.js] " + status);	
		        }
		    }
		);
        return deffered.promise;
    },

	put: function(nick_name){
		var defferd=Q.defer();

		var _rest = "game/user/v2/profile"; 
		print("[user-profile-model.js] process a put request:" + _rest);
		
		ServerController.callAPI({
		        type: 'PUT',
		        url: _rest
		    },
		    {
		    	bodyValue: {'nick_name': nick_name},
				success : function(data, status, response) {
		            print("[user-profile-model.js] put success result:" + data);
		            self.set('nick_name', nick_name);
		            defferd.resolve(data);    
		        },
		        error : function(response, status, exception) {
		            print("[user-profile-model.js] put error result:" + status + JSON.stringify(response));
		        	defferd.reject(response);
		        },
		        complete: function(response, status) {   
		            print("[user-profile-model.js] put" + status);	
		        }
		    }
		);
        return defferd.promise;


    },
    
    parse:function(data, status, response){
        var parsonData = JSON.parse(data);
        this.set('nick_name',parsonData.rsp.nick_name);
        this.set('thumbnail_url',parsonData.rsp.thumbnail_url);
        this.set('email_id',parsonData.rsp.email_id);
        this.set('message_count',parsonData.rsp.message_count);
        this.set('coupon_count',parsonData.rsp.coupon_count);
    },
});
exports = new UserProfileModel();