/**
 * @author tiansx 
 * @20140613
 */

var Backbone = Volt.require("lib/volt-backbone.js");
var CouponListModel = Volt.require('app/models/coupon-list-model.js');

var CouponCollection = Backbone.Collection.extend({
    model:CouponListModel,
});

exports = CouponCollection;
