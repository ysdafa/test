var Backbone = Volt.require("lib/volt-backbone.js");
var ControllerListCollection = Volt.require("app/models/controller-list-collection.js");
var ShsTrailerListCollection = Volt.require("app/models/shs-trailer-list-collection.js");
//var YouTuBeTrailerListCollection = Volt.require("app/models/youtube-trailer-collection.js");
var CPTrailerListCollection = Volt.require("app/models/cp-trailer-collection.js");
var ScreenShotListCollection = Volt.require("app/models/screen-shot-collection.js");
var RelatedListCollection = Volt.require("app/models/related-list-collection.js");
var ServerController = Volt.require('app/controller/server-controller.js');
var voltApiWrapper = Volt.require("app/common/voltapi-wrapper.js");
var Q = Volt.require('modules/q.js');
/** @lends GamesModel.prototype */
var DetailModel = Backbone.Model.extend({
    defaults : {
        'stat' : null,    //'ok'   
        'app_id' : null,  //"Merry Charistmas"     
        'thumbnail_url' : null,
        'source_type' : null,
        'trailer_id' : null,
        'trailer_id_kpi' : null,
        'trailer_title' : null,
        'app_icon_url' : null,
        'hot_new' : null,
        'game_title' : null,
        'game_age_rating' : null,
        'age_rating_url' : null,
        'rating' : null,
        'my_rating' : null,
        'genre' : null,
        'updated_date' : null,
        'size' : null,
        'install_size' : null,
        'total_size' : null,
        'developer' : null,
        'developer_email' : null,
        'language' : null,
        'price' : null,
        'description' : null,
        'shs_trailer_list_cnt' : null,
        'youtube_trailer_list_cnt' : null,
        'share_message' : null,
        'downloadble' : null,
        'version' :null
    },
    
    initialize : function(models, options) {
    	deatailModel = this;
        this.set('controller_list', new ControllerListCollection());
        this.set('shs_trailer_list', new ShsTrailerListCollection());
        //this.set('youtube_trailer_list', new YouTuBeTrailerListCollection());
        this.set('cp_trailer_list', new CPTrailerListCollection());
        this.set('screenshot_list', new ScreenShotListCollection());
        this.set('related_list', new RelatedListCollection());
    },
     
	fetch:function(options) {
    
		var self = this;
		var defferd=Q.defer();

		var _rest;
		if(options.appId == null || options.appId == undefined) {
			Volt.log("[detail-model.js] error: lack param appId ");
			return;
		} else {
			_rest = "game/content/v2/detail/" + options.appId; 
		}
		Volt.log("[detail-model.js] process a get request:" + _rest);
		
		ServerController.callAPI({
		        type: 'GET',
		        url: _rest
		    },
		    {
		    	bodyValue: {},
				success : function(data, status, response) {
		            Volt.log("[detail-model.js] success result:" + data);
		            self.parse(data,status,response);  
		            defferd.resolve();    
		        },
		        error : function(response, status, exception) {
		            Volt.log("[detail-model.js] error result:" + exception + JSON.stringify(response));
		        	defferd.reject(response);
		        },
		        complete: function(response, status) {   
		            Volt.log("[detail-model.js] " + status);	
		        }
		    }
		);
        return defferd.promise;
    },
    stopRequestData:function(){
    	ServerController.cancel();
    },
	put:function(appId,ratingNum) {
    
       var self = this;
       var defferd=Q.defer();

	   var _rest;
		if(appId == null || appId == undefined) {
			Volt.log("[detail-model.js] error: lack param appId ");
		    return;
		} else {
			_rest = "game/user/v2/rate_game"; 
		}
		Volt.log("[detail-model.js] process a put request:" + _rest);
		
		ServerController.callAPI({
		        type: 'PUT',
		        url: _rest
		    },
		    {
		    	bodyValue: {app_id: appId,
							rating:	ratingNum},
				success : function(data, status, response) {
		            Volt.log("[detail-model.js] success result:" + data);
		            deatailModel.set('my_rating', String(ratingNum));
		            defferd.resolve();    
		        },
		        error : function(response, status, exception) {
		            Volt.log("[detail-model.js] error result:" + exception + JSON.stringify(response));
		        	defferd.reject(exception);
		        },
		        complete: function(response, status) {   
		            Volt.log("[detail-model.js] " + status);	
		        }
		    }
		);
        return defferd.promise;
    },

	fetchDynamicInfo:function(options) {
    
		var self = this;
		var defferd=Q.defer();

		var _rest;
		if(options.appId == null || options.appId == undefined) {
			Volt.log("[detail-model.js] error: lack param appId ");
			return;
		} else {
			_rest = "game/content/v2/detail/" + options.appId + '/dynamic_info';
		}
		Volt.log("[detail-model.js] process a get request:" + _rest);
		
		ServerController.callAPI({
		        type: 'GET',
		        url: _rest
		    },
		    {
		    	bodyValue: {},
				success : function(data, status, response) {
		            Volt.log("[detail-model.js] success result:" + data);
					var dataResult = JSON.parse(data);
		            deatailModel.set('rating', dataResult.rating); 
		            defferd.resolve();    
		        },
		        error : function(response, status, exception) {
		            Volt.log("[detail-model.js] error result:" + exception + JSON.stringify(response));
		        	defferd.reject(response);
		        },
		        complete: function(response, status) {   
		            Volt.log("[detail-model.js] " + status);	
		        }
		    }
		);
        return defferd.promise;
    },
    
    parse:function(data, status, response){
    
        deatailModel = this;
        var parsonData = JSON.parse(data);
        deatailModel.set('app_id',parsonData.rsp.app_id);
        deatailModel.set('thumbnail_url',parsonData.rsp.thumbnail_url);
        deatailModel.set('source_type',parsonData.rsp.source_type);
        deatailModel.set('trailer_id',parsonData.rsp.trailer_id);
        deatailModel.set('trailer_id_kpi',parsonData.rsp.trailer_id_kpi);
        deatailModel.set('trailer_title',parsonData.rsp.trailer_title);
        deatailModel.set('app_icon_url',parsonData.rsp.app_icon_url);
        deatailModel.set('hot_new',parsonData.rsp.hot_new);
        deatailModel.set('game_title',parsonData.rsp.game_title);
        deatailModel.set('game_age_rating',parsonData.rsp.game_age_rating);
        deatailModel.set('age_rating_url',parsonData.rsp.age_rating_url);
        deatailModel.set('rating',parsonData.rsp.rating);
        deatailModel.set('my_rating',parsonData.rsp.my_rating);
        deatailModel.set('genre',parsonData.rsp.genre);
        var genres = deatailModel.get('genre').split('/');
        if(genres.length > 3){
            var tempGenre = deatailModel.get('genre');
            var index1 = tempGenre.indexOf('/', -1);
            var index2 = tempGenre.indexOf('/', index1 + 1);
            var index3 = tempGenre.indexOf('/', index2 + 1);
            tempGenre = tempGenre.substr(0, index3);
            deatailModel.set('genre', tempGenre);
        }
        deatailModel.set('updated_date',CovertToStandardDate(parsonData.rsp.updated_date));
        deatailModel.set('size',parsonData.rsp.size);
        deatailModel.set('developer',parsonData.rsp.developer);
        deatailModel.set('developer_email',parsonData.rsp.developer_email);
        deatailModel.set('language',parsonData.rsp.language);
        var languages = deatailModel.get('language').split(',');
        if(languages.length > 3) {
            var tempLanguage = deatailModel.get('language');
            var index1 = tempLanguage.indexOf(',', -1);
            var index2 = tempLanguage.indexOf(',', index1 + 1);
            var index3 = tempLanguage.indexOf(',', index2 + 1);
            tempLanguage = tempLanguage.substr(0, index3 + 1);
            tempLanguage += "...";
            deatailModel.set('language', tempLanguage);
        }
        deatailModel.set('price',parsonData.rsp.price);
        deatailModel.set('description',parsonData.rsp.description);
        deatailModel.set('currency',parsonData.rsp.currency);
        deatailModel.set('shs_trailer_list_cnt',parsonData.rsp.shs_trailer_list_cnt);
        //deatailModel.set('youtube_trailer_list_cnt',parsonData.rsp.youtube_trailer_list_cnt);
        deatailModel.set('cp_trailer_list_cnt',parsonData.rsp.cp_trailer_list_cnt);
        deatailModel.set('share_message',parsonData.rsp.share_message);
        deatailModel.set('downloadable',parsonData.rsp.downloadable);
        deatailModel.set('version',parsonData.rsp.version);
        if(voltApiWrapper.isWidgetInstalled(parsonData.rsp.app_id)){
			deatailModel.set('size',parsonData.rsp.size_uncomp);
        } else {
			deatailModel.set('size',parseInt(parsonData.rsp.size_uncomp) + parseInt(parsonData.rsp.size_comp) + 10);
        }
        deatailModel.set('install_size',parsonData.rsp.size_uncomp);
        deatailModel.set('total_size',parseInt(parsonData.rsp.size_uncomp) + parseInt(parsonData.rsp.size_comp) + 10);
        var controller_list = deatailModel.get('controller_list');
        controller_list.reset(parsonData.rsp.controller_list);
        var shs_trailer_list = deatailModel.get('shs_trailer_list');
        shs_trailer_list.reset(parsonData.rsp.shs_trailer_list);
        var cp_trailer_list = deatailModel.get('cp_trailer_list');
        cp_trailer_list.reset(parsonData.rsp.cp_trailer_list);
        var screenshot_list = deatailModel.get('screenshot_list');
        screenshot_list.reset(parsonData.rsp.screenshot_list);
        var related_list = deatailModel.get('related_list');
        related_list.reset(parsonData.rsp.related_list);
    }
})

var CovertToStandardDate = function(date){
	if(typeof date != 'string')
	{
		return date;
	}
	var standardDate = date.substring(0,4) + '-'
					 + date.substring(4,6) + '-'
					 + date.substring(6);
	Volt.log("[detail-model] date is :" + date + " return value is:" + standardDate);
	return standardDate;
}
exports = new DetailModel();