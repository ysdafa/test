var EventMediator  = Volt.require('app/common/event-mediator.js');
var voltapi        = Volt.require('voltapi.js');
var CommonDefine   = Volt.require('app/common/common-define.js');
var _              = Volt.require("modules/underscore.js")._;

var stateNetwork  = true;
var bReady        = false;

var Network = {
    
    init: function() {
        EventMediator.on(CommonDefine.Event.NETWORK_READY, _.bind(this.onNetworkInitialized,this)); 

        EventMediator.on(CommonDefine.Event.GAMES_NETWORK_CHANGED,
            function(status) {
                Volt.log('network status changed to : [' + status + ']');
            },
            this);
    },
       
    onNetworkInitialized: function() {
        Volt.log('onNetworkInitialized');
        this.initNetwork();
        this.addNetworkListener();
        bReady = true;
    },
    
    isReady: function() {
        return bReady;
    },

    getNetWorkState: function() {
        return stateNetwork;
    },

    setNetWorkState: function(status) {
        stateNetwork = status;
    },

    initNetwork: function() {
        if (false == voltapi.network.checkNetworkStatus()) {
            Volt.log('network is disconnected');
            stateNetwork = false;
        } else {
            Volt.log('network is connected');
            stateNetwork = true;
        }
    },

    addNetworkListener: function () {
        voltapi.network.networkConnectionListener(
            function (type) {
                Volt.log("[app.js] network onconnect, type is " + type); // type 0:cable, 1: wireless, 2: gateway
                if (type == 0 || type == 1 || type == 2) {
                    if (false == stateNetwork) {
                        stateNetwork = true;
                        EventMediator.trigger(CommonDefine.Event.GAMES_NETWORK_CHANGED, stateNetwork);
                    }
                }
            },
            function (type) {
                Volt.log("[app.js] network ondisconnect, type is " + type);
                if (type == 0 && voltapi.network.checkPhysicalConnection(0) > 0) {
                    Volt.log("[app.js] wireless network onconnect");
                    return;
                }
                if (type == 1 && voltapi.network.checkPhysicalConnection(1) > 0) {
                    Volt.log("[app.js] cable network onconnect");
                    return;
                }
                if (stateNetwork) {
                    stateNetwork = false;
                    EventMediator.trigger(CommonDefine.Event.GAMES_NETWORK_CHANGED, stateNetwork);
                }
            }
        );
        Volt.log('[app.js] networksStatus: ' + stateNetwork);
    }
}

exports = Network;

