var DeviceModel 	  = Volt.require('app/models/device-model.js');

var VoiceGuide = {
    
    getVoiceGuide : function (voiceText) {
        Volt.log('[voiceGuide.js] getVoiceGuide text : ' + voiceText);
        if (1 != DeviceModel.get('tts')) {
            Volt.log('[voiceGuide.js] getVoiceGuide don not call TTS');
            return;
        }

        if(voiceText){
            Volt.log('[voiceGuide.js] getVoiceGuide Volt.bQueuingPlay = ' + Volt.bQueuingPlay);
            if(Volt.bQueuingPlay){
                TTS.queuingPlay(voiceText);
            }else{
                TTS.setText(voiceText);
                TTS.play();
            }
        }
    },

    stopVoiceGuide : function (voiceText) {
        Volt.log('[voiceGuide.js] stopVoiceGuide ..... ');
        TTS.stop();
    },
}

exports = VoiceGuide;