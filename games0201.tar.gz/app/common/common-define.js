

var CommonDefines = {
    Const: {
        MENU_ANIM_DURATION :                200,
        CONTENT_ANIM_DURATION:              500,
        POPUP_LOADING:						0,
        VIEW_LOADING:						1,
        SWITCH_WHILE_LOADING:               2,
        HALO_ITEM_ALL_SAME:					0,
        HALO_ITEM_NOT_ALL_SAME:				1,
        UPDATE_ITEMS:                       3,
        VD_MEMORY:                          0,
        NO_CONTENT_GENERAL:					0,
        NO_CONTENT_WITH_BTN:				1,
        NO_CONTENT_COUPON:					2,
        OPTION_MENU:						0,
        LONG_PRESS_MENU:					1,
    },
    
    Winset:{
    	MESSAGEBOX_TITLE_BUTTON_1LINE:		1,
		MESSAGEBOX_TITLE_BUTTON_2_8LINE:	2,
		MESSAGEBOX_NOTITLE_BUTTON_1LINE:	3,
		MESSAGEBOX_NOTITLE_BUTTON_2_8LINE:	4,
    	MESSAGEBOX_EXTENSION_ONE_BUTTON:	11,
    	MESSAGEBOX_BACKGROUND_STYLE_B_1:	2,
    	MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1: 5,
    	
    	POPUP_RATING_STYLE_B: 				1,
    	
    	BUTTON_IMAGE_O_STYLE_E : 			6,
    	BUTTON_IMAGE_O_STYLE_F_FOCUS1 : 	7,
    	BUTTON_TEXT : 						1,
		BUTTON_ICON : 						2,
		
		HighContrast_Background :           1,
		
		SCROLL_VERTICAL:					3,
		SCROLL_HORIZONTAL:					4,
    },
    
    ThumbnailStyle : {
        THUMB_STYLE_BLANK :                 0x00,
        THUMB_STYLE_IMAGE :                 0x01,
        THUMB_STYLE_ICON :                  0x02,
        THUMB_STYLE_TEXT :                  0x04,
        THUMB_STYLE_PROGRESSBAR :           0x08,
        THUMB_STYLE_CHECKBOX :              0x10,
        THUMB_STYLE_INFO :                  0x20,
        THUMB_STYLE_SCROLLPLAYER:           0x40,
        THUMB_STYLE_VIDEO :                 0x80,
    },
  
    Event: {
        GAME_CONTROLLER_GUIDE_POPUP:        'GAME_CONTROLLER_GUIDE_POPUP',
        SIGNIN_POPUP:                       'SIGNIN_POPUP',
        GAMES_EXIT:                         'GAMES_EXIT',
        
        GAMES_ON_HIDE:                      'GAMES_ON_HIDE',
        GAMES_ON_PAUSE:                     'GAMES_ON_PAUSE',
        GAMES_ON_RESUME:                    'GAMES_ON_RESUME',
        GAMES_ON_DEACTIVATE:				'GAMES_ON_DEACTIVATE',
        GAMES_ON_ACTIVATE:					'GAMES_ON_ACTIVATE',
        GAMES_ON_PAUSE_FOR_MOREINFO:        'GAMES_ON_PAUSE_FOR_MOREINFO',
        GAMES_ON_RESUME_FOR_MOREINFO:       'GAMES_ON_RESUME_FOR_MOREINFO',
        INPUT_POPUP:                        'INPUT_POPUP',
        SELECT_POPUP:                       'SELECT_POPUP',

		OPTION_MENU_POPUP :                 'OPTION_MENU_POPUP',
        EVENT_MORE_DESCRIPTION_CLOSE_CLICKED:'EVENT_MORE_DESCRIPTION_CLOSE_CLICKED',
        UPDATE_STORAGE:						'UPDATE_STORAGE',
        EVENT_SORT:                         'EVENT_SORT',
        MY_RATING:                          'MY_RATING',   
        WAS_READY:                          'WAS_READY',
        NETWORK_READY:                      'NETWORK_READY',
        GAMES_NETWORK_CHANGED:              'GAMES_NETWORK_CHANGED',

        BEGIN_DOWNLOAD:                     'BEGIN_DOWNLOAD',
        DOWNLOAD_PROGRESS:                  'EVENT_DOWNLOAD_PROGRESS',
        INSTALL_PROGRESS:                   'EVENT_INSTALL_PROGRESS',
        INSTALL:                            'EVENT_INSTALL',
        DOWNLOAD_CANCELED:                  'EVENT_DOWNLOAD_CANCELED',
        UNINSTALL_PROGRESS: 				'EVENT_UNINSTALL_PROGRESS',
        UNINSTALL:                          'EVENT_UNINSTALL',
        SIGN_STATE_UPDATE:                  'SIGN_STATE_UPDATE',
        INSTALL_FAIL:						'INSTALL_FAIL',
        INSTALL_FAIL_APPSYNC_NOT_COMPLETE:  'INSTALL_FAIL_APPSYNC_NOT_COMPLETE',
		
        MSGBOX_BUTTON:						'MSGBOX_BUTTON',
        SELECT_BTN1:						'SELECT_BTN1',
        SELECT_BTN2:						'SELECT_BTN2',
        
        EVENT_CLOSE_POPUP:                  'EVENT_CLOSE_POPUP',
        EVENT_DELETE_SUCCESS:				'EVENT_DELETE_SUCCESS',
        EVENT_FINISH_CPINSTALL:				'EVENT_FINISH_CPINSTALL',
        GAME_CONTROLLER_GUIDE :				'GAME_CONTROLLER_GUIDE',
	    EVENT_UPDATE_WIDGET_COLOR:          'EVENT_UPDATE_WIDGET_COLOR',

        CHANGE_COUNTRY_CODE:                'CHANGE_COUNTRY_CODE',
        CHANGE_LANGUAGE:                    'CHANGE_LANGUAGE',
		CHANGE_VISIBLE_CURSOR:              'CHANGE_VISIBLE_CURSOR',
        CHANGE_HIGH_CONTRAST:               'CHANGE_HIGH_CONTRAST',
        CHANGE_TTS:                         'EVENT_CHANGE_TTS',
		HIDE_TITLE:                         'HIDE_TITLE',
		SHOW_TITLE:                         'SHOW_TITLE',
		
		UPDATE_SUBVIEW_EVENTFLAG:			'UPDATE_SUBVIEW_EVENTFLAG',
		REGISTER_COUPON:                    'REGISTER_COUPON',
		EDIT_NICK_NAME:                     'EDIT_NICK_NAME',
        EDIT_NICK_NAME_POPUP_YBUT:          'EDIT_NICK_NAME_POPUP_YBUT',
        EDIT_NICK_NAME_RESPONSE  :          'EDIT_NICK_NAME_RESPONSE',
		CONNECT_USB:                        'EVENT_CONNECT_USB',
        DISCONNECT_USB:                     'EVENT_DISCONNECT_USB',
        MAIN_CATEGORY_CACHE_DATA:			'MAIN_CATEGORY_CACHE_DATA',
        UPDATE_FOR_REAL_DATA:				'UPDATE_FOR_REAL_DATA',
        UPDATE_FOR_CACHE_DATA:              'UPDATE_FOR_CACHE_DATA',
        MAIN_CATEGORY_OFF_EVENT:            'MAIN_CATEGORY_OFF_EVENT',
        MAIN_CATEGORY_ON_EVENT:             'MAIN_CATEGORY_ON_EVENT',
        CLOSE_RATING_POPUP:					'CLOSE_RATING_POPUP',
		MSG_POPUP_TIMEOUT: 					'MSG_POPUP_TIMEOUT',
		DESTROY_MENU:						'DESTROY_MENU',
		DESTROY_LONG_PRESS_MENU:			'DESTROY_LONG_PRESS_MENU',
		DESTORY_OPTION_MENU:				'DESTORY_OPTION_MENU',
		NETWORK_ERROR:						'NETWORK_ERROR',
		LONG_PRESS:							'LONG_PRESS',
		SET_ROOT_COMPLETE :                 'SET_ROOT_COMPLETE',
		READY_SHOW_DELETEPOPUP :            'READY_SHOW_DELETEPOPUP',
		GRID_LONG_PRESS:					'GRID_LONG_PRESS',
        
        VIDEO_ACTOR_HIDE :                  'VIDEO_ACTOR_HIDE',
        MEMORY_APP_CHANGE :                 'MEMORY_APP_CHANGE',
        CHANGE_MLS:                         'CHANGE_MLS',
        NO_NEED_BACK_WHEN_CUT_LOADING:      'NO_NEED_BACK_WHEN_CUT_LOADING',
        CHANGE_FOCUS_ZOOM:                  'CHANGE_FOCUS_ZOOM'
    },

	vconf: {
        SYSTEM_SETTINGS_KEY_SYSTEM_MENU_LANGUAGE:   'db/menu_widget/language',
        SYSTEM_MENU_SYSTEM_MENU_LANGUAGE:           'db/menu/system/menu_language',
        SYSTEM_SETTINGS_KEY_AUDIO_DESCRIPTION:      'db/menu/system/accessibility/audio_description',
        SYSTEM_SETTINGS_KEY_HIGHCONTRAST:           'db/menu/system/accessibility/highcontrast',
        SYSTEM_SETTINGS_KEY_FOCUSZOOM:              'db/menu/system/accessibility/focuszoom',
        SYSTEM_COMSS_ATOKEN:              	    	'db/comss/atoken',
        SYSTEM_COMSS_DUID:  			    		'db/comss/duid',
        SYSTEM_COMSS_COUNTRYCODE:                   'db/comss/countrycode',
        SYSTEM_COMSS_MODELID:                       'db/comss/modelid',
        SYSTEM_RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE:  'memory/window_system/input/cursor_visible',
        SYSTEM_MENU_ACCESSIBILITY_TTS:				'db/menu/accessibility/tts',
        SYSTEM_ACCESSIBILITY_HIGHCONTRAST:          'db/menu/system/accessibility/highcontrast',
        SYSTEM_MEMORY_VOLT_PANEL_HIDE:              'memory/volt/panel_hide',
        SYSTEM_COUNTRY_CODE:                        'db/comss/countrycode',
        SYSTEM_WAS_APP_CHANGE:                      'memory/was/app_change',
        SYSTEM_MLS_STATE:                           'memory/mls/state'
    },
    
    WAS: {
        // Event
        WAS_DEFAULT:                        1000,
        WAS_MANAGER_INSTALL:                2000,
        WAS_MANAGER_UPDATE:                 2001,
        WAS_MANAGER_INSTALL_PROGRESS:       2002,
        WAS_MANAGER_UNINSTALL:              2003,
        WAS_MANAGER_UNINSTALL_PROGRESS:     2004,
        WAS_MANAGER_DOWNLOAD:               2005,
        WAS_MANAGER_DOWNLOAD_PROGRESS:      2006,
        WAS_MANAGER_DOWNLOAD_CANCELED:      2007,
        WAS_MANAGER_LAUNCH:                 2008,
        WAS_MANAGER_REQUEST_APP_COUNT:      2009,
        WAS_TOKEN_ATOKEN_CHANGE:            3000,
        WAS_SSO_REQUEST_ACCESS_TOKEN:       4000,
        WAS_SSO_STATE_CHANGE:               4001,
        WAS_SSO_SHOW_POPUP:                 4002,
        WAS_AD_START:                       5000,
        WAS_AD_PLAY:                        5001,

        // Type
        ORSAY_MYAPP_NORMAL:                 1,
        ORSAY_MYAPP_RACH:                   2,
        ORSAY_MYAPP_SDK:                    4,
        ORSAY_MYAPP:                        15,
        ORSAY_RECOMMENDED:                  240,
        TIZEN_MYAPP:                        3840,
        TIZEN_RECOMMENDED:                  61440,
        ALL_APP:                            65535,

        // State
        APP_EXIST:                          0,
        APP_NEEDINSTALL:                    1,
        APP_NEEDUPDATE:                     2,
        
        // Category
        CATEGORY_VIDEO:                     1,
        CATEGORY_SPORT:                     2,
        CATEGORY_KID:                       4,
        CATEGORY_EDUCATION:                 8,
        CATEGORY_GAME:                      16,
        CATEGORY_LIFECYCLE:                 32,
        CATEGORY_INFORMATION:               64,
        CATEGORY_ALL:                       65535,
        
        // View Mode
        VIEWMODE_MOSTLYPLAYED:              0,
        VIEWMODE_CUSTOM:                    1,
        
        // Sync Status
        NEED_SYNC:                          0,
        NOT_NEED_SYNC:                      1,
    },

    AppInstallMgr: {
        // Install Status    
        STATUS_INSTALL_READY:                0,
        STATUS_DOWNLOAD_PROGRESS:            1,
        STATUS_DOWNLOAD_RESULT:              2,
        STATUS_INSTALL_PROGRESS:             3,

        // Error
        //Install and update
        WAS_R_ERR_APP_INSTALL:              -3,
        WAS_R_ERR_APP_INSTALL_PARAS:        -4,
        WAS_R_ERR_APP_PKG_PATH:             -5,
        WAS_R_ERR_APP_UNKNOWN_PKG_TYPE:     -6,
        WAS_R_ERR_EXTRACT_CONFIG_FILE:      -7,
        WAS_R_ERR_EXTRACT_ICON_FILE:        -8,
        WAS_R_ERR_NO_ENOUGH_SPACE:          -9,
        WAS_R_ERR_APP_WAS_INSTALLED:        -10,
        //Download
        WAS_R_ERR_APP_DOWNLOAD:             -16,
        WAS_R_ERR_APP_DOWNLOAD_PARAS:       -17,
        WAS_R_ERR_REQUEST_DOWNLOAD_INFO:    -18,
        WAS_R_ERR_APP_NOT_DOWNLOADING:      -19,
        WAS_R_ERR_APP_CANCEL_DOWNLOAD:      -20
    },

	MsgBoxType: {
		MSGBOX_TYPE_NONE:                   -1,
		MSGBOX_TYPE_CONNECT_SEVER_ERROR:     0,
		MSGBOX_TYPE_COUPON_EXPIRED:			 1,
		MSGBOX_TYPE_DLD_BEFORE_RATE:		 2,
		MSGBOX_TYPE_INSTALL_FACEBOOK:		 3,
		MSGBOX_TYPE_INSTALL_YOUTUBE:		 4,
		MSGBOX_TYPE_ADD_TO_FAVORITE:		 5,
		MSGBOX_TYPE_UPDATE_NEW_VERSION:		 6,
		MSGBOX_TYPE_GAME_CENTER:			 7,
		MSGBOX_TYPE_SIGIN_COUPON:            8,
		MSGBOX_TYPE_SIGIN_MESSAGE:           9,
		MSGBOX_TYPE_SIGIN_VERSION:           10,
		MSGBOX_TYPE_SIGIN_INSTALLED:         11,
		MSGBOX_TYPE_DELETE_CHECK:		     12,
		MSGBOX_TYPE_DELETE_SUNCCESS:		 13,
        MSGBOX_TYPE_APPSYNC_NOT_COMPLETE:    14,
        MSGBOX_TYPE_NETWORK_ERROR:           15,
        MSGBOX_TYPE_COUPON_USED:			 16,
        MSGBOX_TYPE_INSTALL_FAIL:    		 17,
        MSGBOX_TYPE_REQUIRE_NETWORK:         18,
        MSGBOX_TYPE_FAIL_REGISTER_COUPON:    19,
        MSGBOX_TYPE_INVALID_COUPON:          20,
        MSGBOX_TYPE_DELETE_FAIL :            21,
        MSGBOX_TYPE_FAIL_REGISTER_NICKNAME:  22,
        MSGBOX_TYPE_NICKNAME_CONFLICT :      23,
    },
    
    GridListThumbnailStyle : {
        THUMBNAIL2 : 0,
        DETAIL_RELATED : 1,
        GAME_CONTROLLER_GUIDE : 2,
        COUPON_BOX_VIEW : 3,
        MESSAGE_BOX_VIEW : 4,
        MYPAGE_LEFT : 5,
        DETAIL_SCREEN_SHOT : 6,
        DETAIL_BIG_THUMBNAIL : 7,
        THUMBNAIL4 : 8,
        MYPAGE_PROFILE : 9,
        MYPAGE_THUMBNAIL : 10,
    },

    Magic: {
        SHOW_VERSION: '12321',
        SHOW_PROCMEMORY: '777',
        CHANGE_ISSTORAGEENOUGH: '81234',
    },
};

exports = CommonDefines;


