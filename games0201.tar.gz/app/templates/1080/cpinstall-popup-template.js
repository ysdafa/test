var CPInstallPopupTemplate = {
    container : {
        parent:scene,
        type: 'widget',
       
        x: 0, y: scene.height *(1 - 0.287037)/2, width: scene.width, height : scene.height * 0.287037,
        color : Volt.hexToRgb('#0f1826',85),
        children : [
            {
                type : 'widget',
                id : 'description-container',
                x : scene.width * (1 - 0.40625)/2, y : scene.height * 0.047222, width : scene.width * 0.40625, height : scene.height * 0.036111,
                color : Volt.hexToRgb('#ffffff',0),
            },
            {
                type : 'widget',
                x : scene.width * (1 - 0.40625)/2, y : scene.height * 0.122222, width : scene.width * 0.40625, height : 2,
                id : 'progressbar-container',
                color : Volt.hexToRgb('#ffffff',0),
                horizontalAlignment : 'center',
            },
            {
                type : 'widget',
                x : scene.width * (1 - 0.40625)/2, y : scene.height * 0.185185, width : scene.width * 0.40625 , height : scene.height * 0.061111,
                id : 'button-container',
                color : Volt.hexToRgb('#ffffff',0),
            }
        ]
    },
    description: {
        type: 'widget',
        x: 0, y: 0, width: scene.width * 0.40625, height: scene.height * 0.036111,
        color: Volt.hexToRgb('#0f1826',0),
        children:[
        {
            type: 'text',
            x: 0, y: 0, width: scene.width * 0.40625, height: scene.height * 0.036111,
            horizontalAlignment : 'center',
            verticalAlignment : 'center',
            textColor : Volt.hexToRgb('#ffffff',100),
            text : 'Downloading...',
            font : 'Samsung SVD_Light 34px'
        },
        /*
        {
            type: 'text',
            id:"progress",
            x: 0, y: 39, width: 780, height: 20,
            horizontalAlignment : 'center',
            verticalAlignment : 'center',
            textColor : Volt.hexToRgb('#ffffff',100),
            text : 'Total(2/10)',
            font : 'Samsung SVD_Light 34px'
        }
        */
        ]
    },
    
    progressBar: {
        type: 'widget',        
        x: 0, y: 0, width: scene.width * 0.40625, height: 2,
        color : Volt.hexToRgb('#000000',0),
        id:'progressBar',        
    },
            
    button:{
        type : 'widget',
        x : 0, y : 0, width : scene.width * 0.40625, height : scene.height * 0.061111,
        color : Volt.hexToRgb('#000000',0),
        children : [{
            type : 'widget',
            id : 'Cancel',
            custom : {'focusable' : true,},
            x : scene.width * (0.40625 - 0.140625)/2, y : 0,
            width : scene.width * 0.140625, height : scene.height * 0.061111,
            color : Volt.hexToRgb('#ffffff',0),
            
            children:[{
                type : 'WinsetBtn',
                style : '{{style}}',
                buttonType : '{{buttonType}}',
                id : 'cancelBtn',
                x : 0,
                y : 0,
                width : scene.width * 0.140625,
                height : scene.height * 0.061111,
                text : Volt.i18n.t('COM_SID_CANCEL'),
            }]

        }],
    }
};

exports = CPInstallPopupTemplate;