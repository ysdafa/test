var noContentTemplate = {
    general: {
        type: 'widget',
        x: 0, y: 0,    
        width: scene.width, height: scene.height*0.8,
        color: Volt.hexToRgb('#dfdfdf'),
        children: [
            {
                type: 'text',
                x: 0, y: scene.height*0.357407,
                anchor: {x: 0.5, y: 0},
                origin: {x: 0.5, y: 0},
                width: scene.width-2*scene.width*0.046875, height: scene.height*0.044444*2,
                font: 'SVD Light ' + (35*scene.height/1080) + 'px',
                textColor: Volt.hexToRgb('#000000', 255*0.6),
                verticalAlignment: 'center',
                horizontalAlignment: 'center',
                color: Volt.hexToRgb('#dfdfdf'),
            }
        ],
    },
    
    myPage: {
        type: 'widget',
        x: 0, y: 0,
        width: scene.width, height: scene.height*0.8,
        color: Volt.hexToRgb('#dfdfdf'),
        children: [
            {
                type: 'text',
                x: 0, y: scene.height*(1-0.39074)/2,
                origin: {x: 0.5, y: 0},
                anchor: {x: 0.5, y: 0},
                width: scene.width*(1-0.046875*2) , height: scene.height*0.044444*2,
                font: 'SVD Light ' + (35*scene.height/1080) + 'px',
                textColor: Volt.hexToRgb('#000000', 255*0.6),
                verticalAlignment: 'center',
                horizontalAlignment: 'center',
            },
            {
                type: 'widget',
                x: 0, y: 0-scene.height*(1-0.39074)/2,
                origin: {x: 0.5, y: 1},
                anchor: {x: 0.5, y: 1},
                width: scene.width*0.140104, height: scene.height*0.060185,
                color: {r: 0, g: 0, b: 0, a: 0},
                //custom: {focusable: true,},              
            }
        ]
        
    },
    
    coupon: { 
        type: 'widget',
        x: 0, y: 0,
        width: scene.width, height: scene.height*(1-0.133333),
        color: Volt.hexToRgb('#dfdfdf'),
        children: [
            {
                type: 'text',
                x: 0, y:scene.height*(1-0.133333-0.044444*2)/2,
                anchor: {x: 0.5, y: 0},
                origin: {x: 0.5, y: 0},
                width: scene.width - scene.width*0.046875*2, height: scene.height*0.044444*2,
                font: 'SVD Light ' + (35*scene.height/1080) + 'px',
                textColor: Volt.hexToRgb('#000000', 153),
                verticalAlignment: 'center',
                horizontalAlignment: 'center',            
            },
        ]
    },
    
    
    button: {
        type: 'WinsetBtn',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        x: 0,
        y: 0,
        width: scene.width*0.140104,
        height: scene.height*0.060185,
        text: "",
    }

}
    
exports = noContentTemplate;

