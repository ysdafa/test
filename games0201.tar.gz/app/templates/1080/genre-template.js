var GenreTemplate = {
    container: {
        parent: scene,
        type: 'widget',
        x: 0, y: 0, width: 1920, height: 1080,
        color: Volt.hexToRgb('#f2f2f2'),
        children: [
            {
                id: 'genre-header-container',
                type: 'widget',
                x: 0, y: 0, width: 1920, height: 144,
                color: Volt.hexToRgb('#0f1826')
            },{
                id: 'genre-content-container',
                type: 'widget',
                x: 0, y: 144, width: 1920, height: 936,
                color: Volt.hexToRgb('#ffffff'),
            },{
                id: 'genre-popup-container',
                type: 'widget',
                x: 0, y: 0, width: 1920, height: 1080,
                color: Volt.hexToRgb('#000000',0),
            }
        ]
    },
};

exports = GenreTemplate;
