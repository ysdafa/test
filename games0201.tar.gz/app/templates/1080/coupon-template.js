var CouponTemplate = {
    container: {
        parent: scene,
        type: 'widget',
        x: 0, y: 0, width: scene.width, height: scene.height,
        color: Volt.hexToRgb('#f2f2f2'),
        children: [
            {
                id: 'coupon-header-container',
                type: 'widget',
                x: 0, y: 0, width: scene.width, height: scene.height * 0.133333,
                color: Volt.hexToRgb('#0f1826')
            },  {
                id: 'coupon-content-container', 
                type: 'widget',
                x: 0, y: scene.height * 0.133333, width: scene.width, height: scene.height * 0.866667,
                color: Volt.hexToRgb('#ffffff'),
            },
            {
                id: 'coupon-popup-container',
                type: 'widget',
                x: 0, y: 0, width: scene.width, height: scene.height,
                color: Volt.hexToRgb('#000000',0),
            }
        ]
    },

    header: {
        type: 'widget', x: 0, y: 0, width: scene.width, height: scene.height * 0.133333,
        color: Volt.hexToRgb('#0f1826'),
        children: [
            {
                id : "coupon-box-title",
                type: 'text', x: scene.width * 0.018750, y: 0, width: scene.width * 0.378125, height: scene.height * 0.133333,
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#ffffff'),
                opacity: 204,
                font : '50px',
                text : Volt.i18n.t('TV_SID_COUPONS'),
            },
            {
                type : 'widget',
                id : 'coupon-box-back-icon-area',
                x : 0, y : 0, width : scene.width * 0.052083, height : scene.height * 0.133333,
                color : {r:0,g:0,b:0,a:0},
                children : [
				{
					type:'widget',
					id:'coupon-back-icon-line',
					x:scene.width * 0.052083 - 1,
					y:0,
					width:1,
					height:scene.height * 0.133333,
					opacity: 26,
					color : Volt.hexToRgb('#ffffff'),
				},]
            },
            { //x:1623,width:292
                type: 'widget', x: scene.width * 0.84375, y: 0, width: scene.width * 0.151041, height: scene.height * 0.133333,
                color: Volt.hexToRgb('#000000', 0),
                id: 'coupon-header-icon-schedule',
                custom: { 'focusable': true },
            },
            {
            	type:'widget',
				id:'coupon-header-icon-schedule-line',
				x:scene.width - scene.width * 0.052083,
				y:0,
				width:1,
				height:scene.height * 0.133333,
				opacity: 26,
				color : Volt.hexToRgb('#ffffff'),
            
            }
        ]
    },

   content:{
        x : 0,
        y : 0,
        width : scene.width,
        height : scene.height * 0.866667,
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : 0,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0
    },
    
    registerBtn : {
        id : 'coupon-header-icon-schedule-image',
        icon: {src:Volt.getRemoteUrl('images/1080/common/comn_icon_topmenu_plus.png'),x:(scene.width * 0.052083 - 36)/2,y:(scene.height * 0.133333 - 36)/2,width:36,height:36},
        color : {r : 0,g : 0,b : 0,a:0},
        width: scene.width * 0.052083 - 1 ,
        height: scene.height * 0.133333 ,
        x: 198,
        y: 0
      },
      
    backBtn:{
        id : 'coupon-box-back-icon',
        x : 0,
        y : 0,
        width : scene.width * 0.051563,
        height : scene.height * 0.133333,
        icon : {src:Volt.getRemoteUrl('images/1080/common/comn_icon_tm_return.png'),
        x:(scene.width * 0.051563 - 36) / 2,y : (scene.height * 0.133333 - 36) / 2,
        width : 36, height : 36,},
        color: { r: 0, g: 0, b: 0, a: 0 },
   },

	toolTip : {
        type : 'WinsetToolTip',
        x : '{{x}}',
        y : '{{y}}',
        width : '{{w}}',
        height : 62,
        style : '{{style}}',
        nResoultionStyle : '{{nResoultionStyle}}',
        text : '{{text}}',
        tailPostion: '{{tailPostion}}',
        //parent : scene
    }
 
};

exports = CouponTemplate;
