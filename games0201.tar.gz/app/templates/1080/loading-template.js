var LoadingTemplate = {
	dimWgt : {
		type : 'widget',
		id : 'loadDim',
		x : 0,
		y : 0,
		parent : scene,
		width : scene.width,
		height : scene.height,
		color : {
			r : 0,
			g : 0,
			b : 0,
			a : 255 * 0.6
		},
		children : [{
			type : 'widget',
			id : 'pupLoadingBg',
			x : scene.width * (1 - 0.012963 - 0.177083),
			y : scene.height * 0.015741,
			width : scene.width * 0.177083,
			height : scene.height * 0.116667,
			color : Volt.hexToRgb('#0F1826', 85),
			children : [{
				type : 'WinsetLoading',
				id : 'popupLoading',
				x : (scene.width * 0.177083 - 201) / 2,
				y : scene.height * 0.017593,
				style : '{{style14}}',
				text:Volt.i18n.t('COM_TV_SID_LOADING'),
			}]
		}, {
			type : 'WinsetLoading',
			id : "viewLoading",
			x : (scene.width - 301) / 2,
			y : (scene.height - 58) / 2,
			style : '{{style20}}',
			text:Volt.i18n.t('COM_TV_SID_LOADING'),
		}]
	},
};
exports = LoadingTemplate;
