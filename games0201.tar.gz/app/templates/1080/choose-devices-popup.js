/**
 * @author tiansx
 * @20140703
 */
var ChooseDevicesTemplate = {
    container : {
        parent:scene,
        type : 'widget',
        custom : {
            'focusable' : false,
            'onKeyEvent' : null
        },
        x : 0,
        y : scene.height * (1 - 0.718519) / 2,
        width : scene.width,
        height : scene.height * 0.718519,
        color : Volt.hexToRgb('#0f1826', 85),
        children : [{
            type : 'text',
            id : 'choose-devices-title',
            x : scene.width * (1 - 0.584375) / 2,
            width : scene.width * 0.584375,
            height : scene.height * 0.089815,
            textColor : Volt.hexToRgb('#ffffff'),
            font : 'Samsung SVD_Medium 46px',
            text : Volt.i18n.t('COM_SID_CHOOSE_WHERE_WANT_TO_INSTALL_GAME'),
            horizontalAlignment : 'center',
            verticalAlignment : 'center',
            color : Volt.hexToRgb('#0f1826', 0)
        }, {
            type : 'widget',
            id : 'choose-devices-line',
            x : scene.width * (1 - 0.584375) / 2,
            y : scene.height * 0.089815,
            width : scene.width * 0.584375,
            height : 1,
            color : Volt.hexToRgb('#ffffff', 30)
        }, {
            type : 'widget',
            id : 'selected-device-container',
            x : scene.width * 0.208333,
            y : scene.height * 0.139815,
            width : scene.width * (0.198438 * 2 + 0.010938),
            height : scene.height * 0.044444,
            width : scene.width,
            height : scene.height * 0.718519,
            color : Volt.hexToRgb('#0f1826', 0),
            children : [{
                type : 'text',
                id : "device-name",
                width : scene.width * 0.198438,
                height : scene.height * 0.044444,
                horizontalAlignment : 'left',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#ffffff', 100),
                text : 'Device name',
                font : 'Samsung SVD_Light 34px'
            }, {
                type : 'text',
                id : "device-memory",
                x : scene.width * (0.198438 + 0.010938),
                width : scene.width * 0.198438,
                height : scene.height * 0.044444,
                horizontalAlignment : 'right',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#ffffff', 100),
                text : 'Memory',
                font : 'Samsung SVD_Light 34px'
            }]
        }, {
            type : 'widget',
            id : 'devices-container',
            width : scene.width,
            height : scene.height * 0.718519,
            color : Volt.hexToRgb('#0f1826', 0)
        }, {
            type : 'widget',
            id : 'button-container',
            x : scene.width * 0.651563,
            y : scene.height * 0.170370,
            width : scene.width * 0.140625,
            height : scene.height * (0.718519 - 0.170370 - 0.079630),
            color : Volt.hexToRgb('#0f1826', 0)
        }]
    },

    chooseArea : {
        subListProperty : {
            width : scene.width,
            height : scene.height * 0.718519,
            color : Volt.hexToRgb('#000000', 0),
            singleLineListWidth : scene.width * 0.423958,
            singleLineListHeight : scene.height * 0.066667 * 5,
        },
        singleLineListPosition : {
            x : scene.width * 0.199479,
            y : scene.height * (0.139815 + 0.044444 + 0.018519 + 0.080556)
        },
        upArrow : {
            ArrowDirection : "upArrow",
            x : scene.width * (0.199479 * 2 + 0.423958 - 0.407292) / 2,
            y : scene.height * (0.139815 + 0.044444 + 0.018519),
            width : scene.width * 0.407292,
            height : scene.height * 0.080556,
            arrowNormalImagePath : Volt.getRemoteUrl('images/1080/popup_arrow_up.png')
        },
        downArrow : {
            ArrowDirection : "downArrow",
            x : scene.width * (0.199479 * 2 + 0.423958 - 0.407292) / 2,
            y : scene.height * (0.139815 + 0.044444 + 0.018519 + 0.080556 + 0.066667 * 5),
            width : scene.width * 0.407292,
            height : scene.height * 0.080556,
            arrowNormalImagePath : Volt.getRemoteUrl('images/1080/popup_arrow_down.png')
        },
        itemProperty : {
            itemSpace : scene.height * 0.066667,
            itemGap : 0
        },
        deviceInfo : {
            image2 : {
                x : scene.width * 0.005729,
                y : (scene.height * 0.066667 - 40) / 2,
                width : 40,
                height : 40,
                focusedImagePath : Volt.getRemoteUrl('images/1080/g_popup_icon_usb_f.png'),
                normalImagePath : Volt.getRemoteUrl('images/1080/g_popup_icon_usb_n.png'),
                dimImagePath : Volt.getRemoteUrl('images/1080/g_popup_icon_usb_n.png'),
                dimAlpha : 102
            },
            text : {
                x : scene.width * (0.005729 + 0.006250) + 40,
                y : 0,
                width : scene.width * 0.198438,
                height : scene.height * 0.066667,
                hAlign : "horizontal_align_left",
                vAlign : "vertical_align_middle",
                itemTextString : ""
            },
            text2 : {
                x : scene.width * (0.005729 + 0.006250 + 0.198438 + 0.006250) + 40,
                y : 0,
                width : scene.width * ((0.423958 - 0.008333) - (0.005729 + 0.006250 + 0.198438 + 0.006250)) - 40,
                height : scene.height * 0.066667,
                hAlign : "horizontal_align_right",
                vAlign : "vertical_align_middle",
                itemTextString : ""
            },
        },
        
        normal : {
            item : {
                itemBGNormalColor : Volt.hexToRgb('#ffffff', 0),
                itemBGFocusedColor : Volt.hexToRgb('#ffffff', 95),
                itemBGDimColor : Volt.hexToRgb('#ffffff', 0)
            },
            text : {
                itemTextNormalColor : Volt.hexToRgb('#ffffff', 100),
                itemTextFocusedColor : Volt.hexToRgb('#464646', 100),
                itemTextSelectedColor : Volt.hexToRgb('#ffc21f', 100),
                itemTextDimColor : Volt.hexToRgb('#ffffff', 30),
                itemTextNormalFont : "SamsungSmart_Medium 34px",
                itemTextFocusedFont : "SamsungSmart_Medium 40px",
                itemTextSelectedFont : "SamsungSmart_Medium 40px",
                itemTextDimFont : "SamsungSmart_Medium 34px"
            }
        },
        
        highContrast : {
            item1st : {
                itemBGNormalColor : Volt.hexToRgb('#0d0d0d', 100),
                itemBGFocusedColor : Volt.hexToRgb('#ffffff', 95),
                itemBGDimColor : Volt.hexToRgb('#0d0d0d', 100),
            },
            item2nd : {
                itemBGNormalColor : Volt.hexToRgb('#252525', 100),
                itemBGFocusedColor : Volt.hexToRgb('#ffffff', 95),
                itemBGDimColor : Volt.hexToRgb('#252525', 100),
            },
            text : {
                itemTextNormalColor : Volt.hexToRgb('#ffffff', 100),
                itemTextFocusedColor : Volt.hexToRgb('#000000', 100),
                itemTextSelectedColor : Volt.hexToRgb('#ffc21f', 100),
                itemTextDimColor : Volt.hexToRgb('#ffffff', 30),
                itemTextNormalFont : "SamsungSmart_Medium 34px",
                itemTextFocusedFont : "SamsungSmart_Medium 40px",
                itemTextSelectedFont : "SamsungSmart_Medium 40px",
                itemTextDimFont : "SamsungSmart_Medium 34px",
            }
        },
        enlarge : {
            text : {
            }
        }
    },

    button : {
        type : 'widget',
        width : scene.width * 0.140625,
        height : scene.height * (0.718519 - 0.170370 - 0.079630),
        color : Volt.hexToRgb('#0f1826', 0),
        children : [{
            type : 'widget',
            id : 'Cancel',
            custom : {
                'focusable' : true,
            },
            y : scene.height * (0.718519 - 0.170370 - 0.079630 - 0.061111) / 2,
            width : scene.width * 0.140625,
            height : scene.height * 0.061111,
            color : Volt.hexToRgb('#ffffff', 0),
            children : [{
                type : 'WinsetBtn',
                style : '{{style}}',
                buttonType : '{{buttonType}}',
                id : 'cancelBtn',
                x : 0,
                y : 0,
                width : scene.width * 0.140625,
                height : scene.height * 0.061111,
                text : Volt.i18n.t('COM_SID_CANCEL')
            }]
        }]
    }
};

exports = ChooseDevicesTemplate;
