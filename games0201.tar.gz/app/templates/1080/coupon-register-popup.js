var CouponRegisterTemplate = {
    container : {
        parent:scene,
        type: 'widget',
		custom : {
			'focusable' : true,
			'onKeyEvent' : null
		},
        x: 0, y: scene.height * (1 - 0.357407)/2, width: scene.width, height : scene.height * 0.357407, //386
        color : Volt.hexToRgb('#0f1826',85),  
        children : [
            {
                type : 'widget',
                id : 'title-container',
                x : scene.width * (1 - 0.584375)/2, y : 0, width : scene.width * 0.584375, height : scene.height * 0.089815,              
                opacity:216,
                color : Volt.hexToRgb('#0f1826',0),
            }, {
                type : 'widget',
                id : 'line-container',
                x : scene.width * (1 - 0.584375)/2, y : scene.height * 0.089815, width : scene.width * 0.584375, height : scene.height * 0.0185185,
                opacity:216,
                color : Volt.hexToRgb('#0f1826',0),
            }, {
                type : 'widget',
                x : scene.width * 0.296875, y : scene.height * 0.131481, width : scene.width * 0.584375, height : scene.height * 0.075925,
                id : 'input-text-field-container',
                color : Volt.hexToRgb('#0f1826',0),
                horizontalAlignment : 'center',
                opacity:216,
            }, {
                type : 'widget',
                x : scene.width * (1 - 0.584375)/2, y :scene.height * 0.264814, width : scene.width * 0.584375 , height : scene.height * 0.061111,
                id : 'button-container',
                color : Volt.hexToRgb('#0f1826',0),
                opacity:216,
            }
        ]
    },
    title: {
        type: 'widget',
        x: 0, y: 0, width: scene.width * 0.584375, height: scene.height * 0.089815,
        color: Volt.hexToRgb('#0f1826',0),
        children:[
        {
            type: 'text',
            x: 0, y: 0, width: scene.width * 0.584375, height: scene.height * 0.089815,
            horizontalAlignment : 'center',
            verticalAlignment : 'center',
            textColor : Volt.hexToRgb('#ffffff'),
            opacity: 229,
            text : 'Title',
            font : 'Samsung SVD_Medium 46px'
        }]
    },
    
    line:{
        type: 'widget',
        x: 0, y: 0, width: scene.width * 0.584375, height: scene.height * 0.0185185,
        color: Volt.hexToRgb('#0f1826',0),
        children:[
         {
            type:"widget",
            x: scene.width * (0.584375 - 0.428125)/2, y: 0, width: scene.width * 0.428125, height: 1,
            color : Volt.hexToRgb('#ffffff'),
            opacity: 76,
          }
        ]
    },
    
    inputBox:{
	    type: 'WinsetInputBox',
		custom : {'focusable' : true,},
	    x:0,
	    y:0,
	    width: scene.width * 0.40625, 
	    height: scene.height * 0.053704,
	    color : Volt.hexToRgb('#ffffff',0),
    },
            
    button:{
        type : 'widget',
        x : 0, y : 0, width : scene.width * 0.584375, height : scene.height * 0.061111,
        color : Volt.hexToRgb('#0f1826',0),
        children: [
            {
                type : 'widget',
                id : 'Done',
                custom : {'focusable' : true,},
                x:scene.width * (0.584375 - 0.140625 - 0.146875)/2,y:0,
                width: scene.width * 0.140625,height: scene.height * 0.061111,
                color : Volt.hexToRgb('#ffffff',0),
                children : [{
                	type : 'WinsetBtn',
					style : '{{style}}',
					buttonType : '{{buttonType}}',
					id : "doneBtn",
					x : 0,y : 0,
		            width : scene.width * 0.140625,
		            height : scene.height * 0.061111,
		            text : Volt.i18n.t('UID_DONE'),
                }]
            }, {
                type : 'widget',
                id : 'Cancel',
                custom : {'focusable' : true,},
                x : scene.width * (0.584375 - 0.140625 - 0.146875)/2 + scene.width * 0.146875, y : 0, 
                width : scene.width * 0.140625, height : scene.height * 0.061111,
                color : Volt.hexToRgb('#ffffff',0),
                children :[{
                	type : 'WinsetBtn',
					style : '{{style}}',
					buttonType : '{{buttonType}}',
                	id : 'cancelBtn',
                	x : 0,
		            y : 0,
		            width : scene.width * 0.140625,
		            height : scene.height * 0.061111,
		            text : Volt.i18n.t('COM_SID_CANCEL'),
                }]
            },
        ],
    }	
};

exports = CouponRegisterTemplate;


