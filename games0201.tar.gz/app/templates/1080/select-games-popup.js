/**
 * @author tiansx
 * @20140701
 */
var SelectGamesTemplate = {
    container : {
        parent: scene,
        type: 'widget',
        custom : {
            'focusable' : true,
            'onKeyEvent' : null
        },
        x: 0, y: scene.height * (1 - 0.783333)/2, width: scene.width, height : scene.height * 0.783333,
        color : Volt.hexToRgb('#0f1826',85),
        children : [
            {
                type : 'widget',
                id : 'title-container',
                x : scene.width * (1 - 0.584375)/2, y : 0, width : scene.width * 0.584375, height : scene.height * 0.089815,
                opacity:216,
                color : Volt.hexToRgb('#0f1826',0),
            },
            {
                type : 'widget',
                id : 'line-container',
                x : scene.width * (1 - 0.584375)/2, y : scene.height * 0.089815, width : scene.width * 0.584375, height : scene.height * 0.0185185,
                opacity:216,
                color : Volt.hexToRgb('#0f1826',0),
            },
            
            {
                type : 'widget',
                id : 'description-container',
                x : scene.width * (1 - 0.584375)/2, y :scene.height * 0.125, width : scene.width * 0.584375, height : scene.height * 0.037037 * 3 + 10,
                color : Volt.hexToRgb('#0f1826',0),
                opacity:216,
            },
            
            {
                type : 'widget',
                x : scene.width * (1 - 0.584375)/2, y : scene.height * 0.268518, width : scene.width * 0.584375, height : scene.height * 0.377778,
                id : 'grid-container',
                color : Volt.hexToRgb('#0f1826',0),
                opacity:216,
            },
            {
                type : 'widget',
                x : scene.width * (1 - 0.584375)/2, y : scene.height * 0.694444, width : scene.width * 0.584375 , height : scene.height * 0.061111,
                id : 'button-container',
                color : Volt.hexToRgb('#0f1826',0),
                opacity:216,
            }
        ]
    },
    
    title: {
        type: 'widget',
        x: 0, y: 0, width: scene.width * 0.584375, height: scene.height * 0.089815,
        color: Volt.hexToRgb('#0f1826',0),
        children:[
        {
            type: 'text',
            x: 0, y: 0, width: scene.width * 0.584375, height: scene.height * 0.089815,
            horizontalAlignment : 'center',
            verticalAlignment : 'center',
            textColor : Volt.hexToRgb('#ffffff'),
            opacity: 229,
            text : 'Title',
            font : 'Samsung SVD_Medium 46px'
        }]
    },
    
    line:{
        type: 'widget',
        x: 0, y: 0, width: scene.width * 0.584375, height: scene.height * 0.0185185,
        color: Volt.hexToRgb('#0f1826',0),
        children:[
         {
            type:"widget",
            x: scene.width * (0.584375 - 0.428125)/2, y: 0, width: scene.width * 0.428125, height: 1,
            color : Volt.hexToRgb('#a0a0a0'),
            opacity: 76,
          }
        ]
    },
    
    description: {
        type: 'widget',
        x: 0, y: 0, width: scene.width * 0.584375, height: scene.height * 0.037037 * 3 + 10,
        color: Volt.hexToRgb('#0f1826',0),
        children:[
        {
            type: 'text',
            x: 0, y: 0, width: scene.width * 0.584375, height: scene.height * 0.037037 * 3 + 10,
            horizontalAlignment : 'center',
            verticalAlignment : 'center',
            textColor : Volt.hexToRgb('#ffffff'),
            opacity: 153,
            text : 'Description',
            font : 'Samsung SVD_Light 34px'
        }]
    },

   grid1:{
        x : scene.width * (1 - 0.584375)/2,
        y : 0,
        width : scene.width * 0.16875,
        height : scene.height * 0.377778,
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : 0,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0
    },
    
    grid2:{
        x : scene.width * 0.1234375,
        y : 0,
        width : scene.width * 0.16875 * 2,
        height : scene.height * 0.377778,
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : 0,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0
    },
    
    grid3:{
        x : scene.width * 0.0390625,
        y : 0,
        width : scene.width * 0.16875 * 3,
        height : scene.height * 0.377778,
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : 0,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0
    },

    button:{
        type : 'widget',
        id : 'Close',
        custom : {'focusable' : true,},
        x : 0, y : 0, width : scene.width * 0.140625, height : scene.height * 0.061111,
        color : Volt.hexToRgb('#ffffff',0),
        children:[{
        	type : 'WinsetBtn',
        	style : '{{style}}',
			buttonType : '{{buttonType}}',
            id : 'cancelBtn',
            x : scene.width *(0.584375 - 0.140625) /2, y : 0,
            text: Volt.i18n.t('COM_SID_CLOSE'),
            width : scene.width * 0.140625, height : scene.height * 0.061111,
        }]
                
    }
  
};

exports = SelectGamesTemplate;
